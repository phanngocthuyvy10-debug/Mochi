# Kiểm tra bản 5.0.1

Đã chạy trong môi trường kiểm tra:
- `node --check` cho toàn bộ JavaScript: đạt.
- Chạy engine với FD và CR dữ liệu giả: đạt.
- Thực thi buildWorkbook với bộ ghi sheet trong bộ nhớ: cột Seller ID đúng `r.sid`, giữ số 0 đầu; partner_code được xuất riêng: đạt.
- Thực thi hàm dựng cột của FD / CR / Tồn lâu và hàm openAfter trong Node VM với DOM giả: có mã sao chép và Seller ID trong chi tiết; partner_code riêng: đạt.
- Kiểm tra tìm kiếm hậu mãi chứa r.sid: đạt.
- Kiểm tra đủ tệp gốc trong gói ZIP và 11 endpoint trong inventory: đạt.

Dữ liệu kiểm tra là dữ liệu giả. Chưa kiểm tra trình duyệt thật, hiển thị bằng ảnh chụp, phiên Chrome extension hoặc API TikiNOW thật. Không tuyên bố đây là toàn bộ API của dịch vụ; đây là toàn bộ endpoint tìm thấy trong mã nguồn ZIP.

## Kiểm tra bổ sung bản 5.0.2

- Thực thi runListJob + orderSpec + pullWindow với API giả: 1.001 đơn delivered tải đủ 2 trang, truyền đúng seller, ngày tạo và trạng thái; đạt.
- Tổng đơn hủy lớn không ngăn tải tập delivered nằm trong giới hạn; đạt.
- Lịch sử tất cả trạng thái vẫn áp dụng giới hạn và không truyền bộ lọc trạng thái khi được phép tải; đạt.
- Chế độ Đang mở vẫn chỉ truyền các trạng thái chưa kết thúc; đạt.
- Nút tải hoàn tất chuyển chế độ, xóa bộ lọc cũ và chỉ đồng bộ Đơn hàng theo tài khoản chọn; đạt.
- FD/CR giữ nguyên sau lượt tải đơn hoàn tất; đạt.

Chưa kiểm tra với API TikiNOW thật hoặc Chrome có đăng nhập.
