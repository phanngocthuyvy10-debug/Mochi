# Đơn hàng hoàn tất — bản 5.0.2

Trong Danh sách đơn, bấm **Tải đơn hàng hoàn tất**. Nút chuyển sang Theo ngày, trạng thái delivered, rồi tải riêng Đơn hàng cho tài khoản đang chọn (hoặc tất cả nếu không lọc tài khoản). Xóa các bộ lọc cũ trên danh sách để không che đơn hoàn tất. Tab Đã hoàn thành luôn hiển thị kể cả khi bằng 0.

Khoảng ngày lọc theo **ngày tạo đơn**, không phải ngày giao xong. Mặc định 30 ngày; muốn đơn tạo trước đó thì chọn Từ/Đến trước khi tải. Chỉ lấy delivered, không gồm đơn hủy. Có phân trang và chia khoảng khi chạm trần API; giới hạn số đơn theo cài đặt vẫn áp dụng. Lần đồng bộ thay danh sách Đơn hàng đã lưu của các tài khoản được tải, giữ FD/CR. Muốn cả đơn mở + hoàn tất + huỷ: chọn Đơn hàng: Tất cả trạng thái, Theo ngày, rồi Đồng bộ.

Không cần API mới: dùng GET /fulfillment/1.0/orders với filters.status=delivered cùng bộ lọc seller và ngày tạo. File ZIP không chứa phiên đăng nhập hoặc dữ liệu đơn thật.

Cập nhật bằng cách chép các tệp bản 5.0.2 vào thư mục extension cũ rồi Reload tại chrome://extensions để giữ extension ID. Dữ liệu cache không tự biến thành lịch sử; bấm nút tải trên sau khi cập nhật.

---

# Seller ID, API và UI — TikiNOW Operations Hub 5.0.2

## Vì sao FD không thấy seller ID?

Bản 5.0.0 đã giữ seller ID ở `r.sid` (từ `item.__sid`, được gắn theo tài khoản khi đồng bộ) nhưng không có cột này trong bảng FD và phần chi tiết. Excel còn gắn nhãn “Mã seller” cho `partner_code`; trường đó không phải seller ID của tài khoản.

Seller ID thực tế không có sẵn trong ZIP. `tokens.js` đọc `data.seller_id` (hoặc `seller_id` ở gốc) từ `GET https://tikinowcenter.tikinow.vn/api/user?include=permissions,roles`, rồi lưu vào `chrome.storage.local.accounts`. Trang Tài khoản vốn đã hiển thị seller ID. Không cần gửi token/cookie để xem mã này.

## Bản sửa đã kèm theo

- Thêm cột Seller ID có thể sao chép, sắp xếp ở FD, CR và Tồn lâu / trễ.
- Thêm Seller ID vào phần chi tiết hậu mãi; FD hiển thị riêng mã đối tác (partner_code).
- Cho phép tìm hậu mãi theo Seller ID.
- Excel FD và CR có cột Seller ID lấy đúng `r.sid`, giữ dạng chuỗi. Đổi nhãn trường partner_code thành “Mã đối tác (partner_code)”.
- Giữ toàn bộ các màn hình, CSS, engine KPI, xuất Excel, icon và PDF từ ZIP gốc. Không thêm API mới hay gọi dữ liệu thật.

## 11 endpoint có trong mã nguồn

Đây là toàn bộ endpoint API tìm thấy trong JavaScript được cung cấp, không phải khẳng định toàn bộ API nội bộ của TikiNOW. Các số dòng dưới đây tham chiếu bản gốc 5.0.0. Tất cả dùng Bearer token của tài khoản đang đăng nhập. `POST base-info` đặt thêm `Content-Type: application/json`.

### 1. Xác định seller ID và tài khoản

`GET https://tikinowcenter.tikinow.vn/api/user`

- Tham số: include=permissions,roles
- Nguồn: `tokens.js:27`

### 2. Danh sách đơn / tra mã đơn đối tác

`GET https://api.tikinow.vn/fulfillment/1.0/orders`

- Tham số: filters.seller_id; filters.extra.is_tnsl_order=true; filters.created_at.from/to; filters.status; sort_by=created_at|desc; page.page_number; page.per_page=1000. Tra mã: filters.order_code (lô 150), page.per_page=500.
- Nguồn: `app.js:230,405`

### 3. Đếm đơn

`GET https://api.tikinow.vn/fulfillment/1.0/orders/counts`

- Tham số: filters.seller_id; filters.extra.is_tnsl_order=true; filters.created_at.from/to
- Nguồn: `app.js:326`

### 4. Chi tiết đơn

`GET https://api.tikinow.vn/fulfillment/1.0/orders/{order_code}`

- Tham số: order_code được encodeURIComponent trong path
- Nguồn: `app.js:705`

### 5. Danh sách FD

`GET https://api.tikinow.vn/fulfillment/1.0/inbound-shipments/fds/list`

- Tham số: filters.seller_id VÀ seller_id; page.page_number; page.per_page=50; filters.status (phân cách dấu phẩy) HOẶC filters.created_from/to (YYYY-MM-DD)
- Nguồn: `engine.js:21; app.js:244`

### 6. Chi tiết FD

`GET https://api.tikinow.vn/fulfillment/1.0/inbound-shipments/fds/detail`

- Tham số: code={fd_code}; code gốc không truyền seller_id riêng, dùng token tài khoản
- Nguồn: `app.js:386,831`

### 7. Danh sách CR

`GET https://api.tikinow.vn/tnc-ams/v1/cr/search`

- Tham số: seller_id; page; size=100; ordering=-created_at; created_at__gte/lte; status__in (một trạng thái mỗi lượt)
- Nguồn: `engine.js:29; app.js:260`

### 8. Chi tiết CR

`GET https://api.tikinow.vn/tnc-ams/v1/cr/detail/{cr_code}`

- Tham số: seller_id; cr_code được encodeURIComponent trong path
- Nguồn: `app.js:387,831`

### 9. Tên / hình / giá sản phẩm

`POST https://api.tikinow.vn/business/v1/product/base-info`

- Tham số: JSON body: {"skus": ["<SKU>"], "seller_id": <SELLER_ID_NUMBER>}; tối đa 100 SKU/lô trong mã
- Nguồn: `app.js:420`

### 10. Kiểm tra bằng chứng đóng gói

`GET https://api.tikinow.vn/tnc-ams/v1/check-evidence-documents`

- Tham số: seller_id; order_code; is_video_pack=true; bỏ qua khi đơn LM
- Nguồn: `app.js:708`

### 11. Lấy bằng chứng theo đơn

`GET https://api.tikinow.vn/tnc-ams/v1/evidence-documents-request`

- Tham số: seller_id; order_code
- Nguồn: `app.js:709,834`

Các giới hạn trong mã: FD 50 dòng/trang; CR 100 dòng/trang và chia khoảng ngày khi chạm trần 10.000; đơn hàng 1.000 dòng/trang và chia khoảng khi chạm trần 10.000. Đây là cấu hình/giả định của extension, chưa được xác nhận lại với máy chủ. Mã giới hạn đồng thời mặc định 6, timeout 30 giây, tối đa 5 lần thử; xử lý 401/403 và 429.

Domain ảnh `https://salt.tikicdn.com/ts/` không được tính là một endpoint API. Các URL `/new#/...` là đường dẫn UI. Quyền `https://*.tikinow.vn/*` trong manifest không cho biết thêm endpoint nào.

## UI có trong gói

| Màn hình | Nội dung |
| --- | --- |
| Tổng quan | Tổng hợp đơn và hậu mãi, trạng thái, kho / vận chuyển |
| Danh sách đơn | Tìm kiếm, lọc, chi tiết đơn, nhãn vận chuyển và bằng chứng |
| KPI dịch vụ | KPI đơn hàng và hậu mãi theo engine / tài liệu PDF đi kèm |
| Giao thất bại · FD | Danh sách FD, kho, hạn, SKU, lịch sử; bản sửa thêm Seller ID |
| Thu hồi · CR | Trạng thái thu hồi, vận chuyển, giải pháp, sản phẩm |
| Tồn lâu / trễ | Danh sách hậu mãi trễ và bộ lọc |
| Tài khoản | Tên, seller ID, thời hạn phiên, đồng bộ từng tài khoản |
| Cài đặt | Các tuỳ chọn đồng bộ, KPI, xuất dữ liệu và giao diện |

Thành phần dùng chung: bộ lọc tài khoản, đồng bộ đang mở / theo ngày, chọn đơn hàng / FD / CR, tiến độ và nút dừng, drawer chi tiết, chế độ sáng / tối, xuất Excel.

Mã UI nằm trong `app.html`, `app.css`, `app.js`; phụ thuộc `tokens.js`, `engine.js`, `kpi-engine.js`, `xlsx-lite.js`. Đây là UI của extension trong ZIP, không phải toàn bộ website TikiNOW Center. Các route Center được liên kết: `tnsl-order/list`, `aftersales/failed-delivery`, `aftersales/request-return/list` dưới `https://tikinowcenter.tikinow.vn/new#/`.

## Cài và xem Seller ID

1. Giải nén ZIP. Chrome → `chrome://extensions` → bật Developer mode → Load unpacked → chọn thư mục có `manifest.json`. Nếu đã cài bản cũ bằng Load unpacked, cập nhật các tệp trong thư mục cũ rồi bấm Reload để giữ cùng extension ID và dữ liệu cục bộ. Không cần gỡ bản cũ.
2. Đăng nhập TikiNOW Center bằng tài khoản của bạn, mở extension → Tài khoản → Quét lại đăng nhập nếu cần.
3. Xem Seller ID ở Tài khoản hoặc cột Seller ID trong FD. Bấm mã để sao chép. Có thể cần đồng bộ nếu chưa có dữ liệu.

Không có phiên Chrome đăng nhập trong môi trường kiểm tra nên chưa kiểm chứng API thực tế, dữ liệu thật hoặc hiển thị trên Chrome. Xem `VALIDATION.md` để biết chính xác các kiểm tra đã chạy.
