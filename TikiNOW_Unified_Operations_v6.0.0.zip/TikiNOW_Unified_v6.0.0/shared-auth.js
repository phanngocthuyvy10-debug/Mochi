/* Single account store; verified seller identity, local token aliases for legacy engines. */
(function (root) {
  'use strict';
  const inflight = new Map(); let serial = Promise.resolve();
  const raw = token => String(token || '').replace(/^Bearer\s+/i, '').trim();
  async function mirrorAccounts(removedIds) {
    const data = await chrome.storage.local.get(['accounts', 'tokens']);
    const accounts = data.accounts || {}, prev = data.tokens || {}, tokens = Object.assign({}, prev);
    for (const sid of removedIds || []) delete tokens[sid];
    for (const [sid, a] of Object.entries(accounts)) if (!a || a.dead || !a.tk) delete tokens[sid];
    for (const [sid, a] of Object.entries(accounts)) if (a && a.tk && !a.dead) {
      const header = 'Bearer ' + raw(a.tk), old = prev[sid];
      tokens[sid] = { token: header, at: old && old.token === header ? old.at : a.savedAt || Date.now(), first_seen_at: a.firstSeenAt || a.savedAt || Date.now() };
    }
    if (JSON.stringify(tokens) !== JSON.stringify(prev)) await chrome.storage.local.set({ tokens });
    return tokens;
  }
  async function acceptCaptured(sid, value) {
    const tk = raw(value); sid = String(sid || ''); if (!sid || !tk) return;
    const previous = (await getAccounts())[sid];
    if (previous && previous.tk === tk && !previous.dead) return;
    const key = sid + ':' + tk;
    if (inflight.has(key)) return inflight.get(key);
    const work = (async () => {
      const verified = await readAccount(tk);
      if (String(verified.sellerId) !== sid) throw new Error('Seller token không khớp request; không liên kết tài khoản.');
      const next = serial.then(async () => {
        const all = await getAccounts(), old = all[sid] || {};
        all[sid] = Object.assign({ firstSeenAt: old.firstSeenAt || Date.now() }, old, verified);
        await chrome.storage.local.set({ accounts: all });
      });
      serial = next.catch(() => {}); await next;
    })().finally(() => inflight.delete(key));
    inflight.set(key, work); return work;
  }
  async function commandTokens() {
    const all = await getAccounts(), tokens = {};
    for (const [sid, a] of Object.entries(all)) if (tokenAlive(a)) tokens[sid] = { token: 'Bearer ' + raw(a.tk), at: a.savedAt || 0, first_seen_at: a.firstSeenAt || 0 };
    return tokens;
  }
  async function bootstrap() {
    const d = await chrome.storage.local.get(['accounts', 'tokens']);
    // Upgrade an existing Command Center install without inventing ownership.
    await Promise.allSettled(Object.entries(d.tokens || {}).map(([sid, t]) => acceptCaptured(sid, t.token)));
    await mirrorAccounts();
  }
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.accounts) {
      const ch = changes.accounts, next = ch.newValue || {}, removed = Object.keys(ch.oldValue || {}).filter(sid => !next[sid]);
      serial = serial.then(() => mirrorAccounts(removed)).catch(() => {});
    }
  });
  chrome.runtime.onMessage.addListener((msg,sender,respond)=>{
    if (!msg || msg.type !== 'UNIFIED_REFRESH_ACCOUNTS') return false;
    bootstrap().then(()=>respond({ok:true}),()=>respond({ok:false})); return true;
  });
  root.UnifiedAuth = { acceptCaptured, commandTokens, mirrorAccounts, bootstrap };
  bootstrap().catch(() => {});
})(self);
