/* =============================================================
 * Tách preflix từ mã đầu đơn (external_order_code / ref_code)
 * + map sang Master "Mã đầu đơn". PORT Y HỆT logic notebook billing.
 * Dùng chung: dashboard/extension (browser) và Node.
 * ============================================================= */
(function (root) {
  // split kiểu pandas .str.split(sep, n=n, expand): tối đa n+1 phần, phần cuối giữ nguyên phần dư
  function splitN(s, sep, n) {
    const out = []; let idx = 0;
    for (let i = 0; i < n; i++) {
      const p = s.indexOf(sep, idx);
      if (p < 0) break;
      out.push(s.slice(idx, p)); idx = p + sep.length;
    }
    out.push(s.slice(idx));
    return out;
  }

  // Y hệt build_preflix_fast trong notebook
  function buildPreflix(code) {
    let base = String(code == null ? '' : code).trim();
    const us = base.indexOf('_');
    const left = us < 0 ? base : base.slice(0, us);           // partition('_')[0]
    const parts = splitN(left, '-', 2);                        // split('-', n=2)
    const p1 = parts[0] || '', p2 = parts[1] || '', p3 = parts[2] || '';
    const custom = p1.startsWith('RT') ? p2 : p1;
    const x = (custom === 'LDP' || custom === 'CUS' || custom === 'LDPLUXHAN') ? (p1 + '-' + p2) : custom;
    const p3f = p3.split('-', 1)[0] || '';                     // p3.split('-', n=1)[0]
    const pre = x.startsWith('RT') ? (p2 + '-' + p3f) : x;
    return pre === '' ? null : pre;
  }

  // Map 1 đơn -> {gb, brand, channel, platform, ...} theo preflix + rule override
  function mapByRefCode(refCode, sellerId, lut) {
    lut = lut || root.TNSL_PREFIX_MAP || {};
    const pre = buildPreflix(refCode);
    let m = pre ? (lut[pre] || null) : null;
    // clone để không sửa lut gốc khi override
    const out = m ? Object.assign({}, m) : { gb: null, brand: null, channel: null, platform: null, opollo: null, pcn: null };
    out.preflix = pre;

    const code = String(refCode == null ? '' : refCode).trim().toUpperCase();
    // Override LDPLUXHAN-HO/SHU/YSL
    if (code.startsWith('LDPLUXHAN-HO')) { out.gb = 'LVN LUXE'; out.brand = 'LVN LUXE'; out.channel = 'Non-Tiktok'; }
    else if (code.startsWith('LDPLUXHAN-SHU')) { out.gb = 'LVN LUXE'; out.brand = 'SHU'; out.channel = 'Non-Tiktok'; }
    else if (code.startsWith('LDPLUXHAN-YSL')) { out.gb = 'LVN LUXE'; out.brand = 'YSL'; out.channel = 'Non-Tiktok'; }
    // Override seller_id chứa 337148 -> Affiliate Sample
    if (sellerId != null && String(sellerId).indexOf('337148') >= 0) {
      out.gb = 'AFFILIATE SAMPLE'; out.brand = 'AFFILIATE SAMPLE'; out.channel = 'Affiliate';
    }
    out.mapped = !!m || code.startsWith('LDPLUXHAN-') || (sellerId != null && String(sellerId).indexOf('337148') >= 0);
    return out;
  }

  const API = { buildPreflix, mapByRefCode, splitN };
  root.TNSL_PREFIX = API;
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
})(typeof self !== 'undefined' ? self : this);
