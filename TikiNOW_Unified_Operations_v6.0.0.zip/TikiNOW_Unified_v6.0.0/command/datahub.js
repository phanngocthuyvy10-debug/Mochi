/* =============================================================
 * TikiNOW Data Trust Hub v2.2.0
 * Local-first raw vault + full order sync + API-time journey + export.
 * No token or order data is sent outside the user's browser.
 * ============================================================= */
(function (root) {
  "use strict";

  const CFG = root.TNSL_CONFIG || {};
  const API_BASE = (CFG.api && CFG.api.base) || "https://api.tikinow.vn/fulfillment/1.0";
  const DB_NAME = "tikinow_ops_data_hub_v2";
  const DB_VERSION = 2;
  const FINAL_STATUSES = new Set(["delivered", "canceled", "cancelled", "returned", "completed"]);
  const DEFAULT_STATUSES = ["awaiting_confirmation", "processing", "shipping", "delivered", "canceled"];
  /* Status còn phải xử lý — dùng cho chế độ Backlog. Lấy theo config để khớp
     đúng định nghĩa backlog của từng đơn vị vận hành. */
  const BACKLOG_STATUSES = (root.TNSL_CONFIG && Array.isArray(root.TNSL_CONFIG.backlogStatuses)
    && root.TNSL_CONFIG.backlogStatuses.length)
    ? root.TNSL_CONFIG.backlogStatuses.slice()
    : ["awaiting_confirmation", "processing"];
  const EXCEL_MAX_ROWS = 800000;

  const STATE = {
    db: null,
    syncing: false,
    abortController: null,
    catalog: [],
    visibleOrders: [],
    trust: null,
    counters: { listed: 0, detailed: 0, errors: 0 }
  };

  const CANONICAL_STEPS = [
    { key: "received", label: "Tiếp nhận đơn", re: /(awaiting_confirmation|waiting_confirm|received|order_received|tnsl_received|cho.*xac nhan|tiep nhan)/i },
    { key: "confirmed", label: "Xác nhận", re: /(confirmed|order_verified|verified|xac nhan)/i },
    { key: "ready_to_pick", label: "Sẵn sàng lấy hàng", re: /(ready_for_pickup|ready_to_pick|ready_to_ship|san sang lay)/i },
    { key: "picking_started", label: "Bắt đầu lấy hàng", re: /(^picking$|pick_started|picking_started|dang lay hang)/i },
    { key: "packing_started", label: "Bắt đầu đóng gói", re: /(^packing$|pack_started|packing_started|dang dong goi)/i },
    { key: "packed", label: "Đóng gói xong", re: /(^packed$|packing_completed|pack_completed|packaged|dong goi xong)/i },
    { key: "handover", label: "Bàn giao ĐVVC", re: /(handover_to_3pl|handover_to_carrier|handover_to_delivery|handed_over|ban giao.*van chuyen)/i },
    { key: "carrier_pickup", label: "ĐVVC nhận hàng", re: /(picked_up|pickup_success|carrier_received|carrier_pickup|don vi van chuyen.*nhan)/i },
    { key: "in_transit", label: "Đang vận chuyển", re: /(in_transit|transporting|shipping|dang van chuyen)/i },
    { key: "out_for_delivery", label: "Đang giao", re: /(out_for_delivery|delivering|dang giao)/i },
    { key: "first_attempt", label: "Giao lần đầu", re: /(first_attempt|delivery_attempt|first_delivery_attempt|giao.*lan dau)/i },
    { key: "delivered", label: "Giao thành công", re: /(^delivered$|logi_successful|delivery_success|giao hang thanh cong)/i },
    { key: "return_started", label: "Bắt đầu hoàn", re: /(return_processing|returning|return_started|chuyen hoan)/i },
    { key: "returned", label: "Hoàn thành hoàn", re: /(^returned$|return_completed|hoan hang)/i },
    { key: "canceled", label: "Hủy đơn", re: /(canceled|cancelled|cancel_success|huy don)/i }
  ];

  const STEP_LABEL = Object.fromEntries(CANONICAL_STEPS.map(x => [x.key, x.label]));

  function $(id) { return document.getElementById(id); }
  function esc(v) {
    return String(v == null ? "" : v).replace(/[&<>"']/g, c => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", "\"": "&quot;", "'": "&#39;"
    })[c]);
  }
  function nfmt(v) { return Number(v || 0).toLocaleString("vi-VN"); }
  function text(v) { return v == null ? "" : String(v); }
  function bool(v) {
    if (typeof v === "string") return /^(true|1|yes|y|co|có)$/i.test(v.trim());
    return v === true || v === 1;
  }
  function clampCell(v) {
    if (v == null) return "";
    const s = typeof v === "object" ? JSON.stringify(v) : String(v);
    return s.length > 32700 ? s.slice(0, 32680) + "…[TRUNCATED_IN_EXCEL]" : s;
  }
  function stripVN(v) {
    return text(v).normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/đ/g, "d").replace(/Đ/g, "D").toLowerCase();
  }
  function accountName(sid) {
    return (CFG.accountNames && CFG.accountNames[String(sid)]) || String(sid || "N/A");
  }
  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
  function nowIso() { return new Date().toISOString(); }
  function apiDate(d) {
    const p = x => String(x).padStart(2, "0");
    return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
  }
  function localDisplay(v) {
    const d = parseApiTime(v);
    return d ? d.toLocaleString("vi-VN", { hour12: false }) : text(v) || "—";
  }
  function log(message, type) {
    const box = $("dhLog");
    if (!box) return;
    const li = document.createElement("li");
    li.className = type || "";
    li.textContent = `[${new Date().toLocaleTimeString("vi-VN", { hour12: false })}] ${message}`;
    box.prepend(li);
    while (box.children.length > 160) box.lastElementChild.remove();
  }
  /* v2.3.3 — phát sự kiện tiến độ cho shell dựng thanh trạng thái "đã xong chưa". */
  function emit(evt, data) {
    try { if (typeof root.TNSL_ON_SYNC === "function") root.TNSL_ON_SYNC(evt, data || {}); }
    catch (_) {}
  }

  function setProgress(done, total, label) {
    const pct = total > 0 ? Math.min(100, Math.round(done * 100 / total)) : 0;
    const bar = $("dhProgressBar");
    const status = $("dhProgressText");
    if (bar) bar.style.width = `${pct}%`;
    if (status) status.textContent = `${label || "Đang xử lý"} · ${nfmt(done)}/${nfmt(total)} · ${pct}%`;
    emit("progress", { done, total, pct, label: label || "Đang xử lý" });
  }
  function setSyncUi(busy) {
    STATE.syncing = busy;
    ["dhSmartSync", "dhFullSync", "dhSyncCatalog", "dhExportExcel", "dhBackupJson", "dhFetchOrder", "dhRetryFailures"]
      .forEach(id => { if ($(id)) $(id).disabled = busy; });
    if ($("dhStop")) $("dhStop").disabled = !busy;
    if ($("dhSyncPulse")) $("dhSyncPulse").classList.toggle("live", busy);
  }

  function runtimeMessage(msg) {
    return new Promise(resolve => {
      try {
        chrome.runtime.sendMessage(msg, response => {
          if (chrome.runtime.lastError) return resolve(null);
          resolve(response);
        });
      } catch (_) { resolve(null); }
    });
  }

  function openDb() {
    if (STATE.db) return Promise.resolve(STATE.db);
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = () => {
        const db = req.result;
        const tx = req.transaction;
        const ensureStore = (name, options) => db.objectStoreNames.contains(name)
          ? tx.objectStore(name)
          : db.createObjectStore(name, options);
        const ensureIndex = (store, name, keyPath) => {
          if (!store.indexNames.contains(name)) store.createIndex(name, keyPath, { unique: false });
        };
        const orders = ensureStore("orders", { keyPath: "pk" });
        ensureIndex(orders, "order_code", "order_code");
        ensureIndex(orders, "ref_code", "ref_code");
        ensureIndex(orders, "seller_id", "seller_id");
        ensureIndex(orders, "status", "status");
        ensureIndex(orders, "source_updated_at", "source_updated_at");
        const resources = ensureStore("resources", { keyPath: "pk" });
        ensureIndex(resources, "resource_key", "resource_key");
        ensureIndex(resources, "captured_at", "captured_at");
        const runs = ensureStore("sync_runs", { keyPath: "id" });
        ensureIndex(runs, "started_at", "started_at");
        ensureStore("meta", { keyPath: "key" });
        const snapshots = ensureStore("snapshots", { keyPath: "pk" });
        ensureIndex(snapshots, "order_pk", "order_pk");
        ensureIndex(snapshots, "captured_at", "captured_at");
        const failures = ensureStore("sync_failures", { keyPath: "pk" });
        ensureIndex(failures, "state", "state");
        ensureIndex(failures, "order_pk", "order_pk");
        ensureIndex(failures, "last_failed_at", "last_failed_at");
      };
      req.onsuccess = () => { STATE.db = req.result; resolve(req.result); };
      req.onerror = () => reject(req.error || new Error("Không mở được IndexedDB"));
    });
  }

  function txDone(tx) {
    return new Promise((resolve, reject) => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error || new Error("IndexedDB transaction failed"));
      tx.onabort = () => reject(tx.error || new Error("IndexedDB transaction aborted"));
    });
  }

  async function bulkPut(storeName, rows) {
    if (!rows || !rows.length) return;
    const db = await openDb();
    for (let start = 0; start < rows.length; start += 400) {
      const tx = db.transaction(storeName, "readwrite");
      const st = tx.objectStore(storeName);
      rows.slice(start, start + 400).forEach(row => st.put(row));
      await txDone(tx);
    }
  }

  async function getAll(storeName) {
    if (storeName === "orders" && root.UnifiedAnalysis) return root.UnifiedAnalysis.normalized();
    const db = await openDb();
    return new Promise((resolve, reject) => {
      const req = db.transaction(storeName, "readonly").objectStore(storeName).getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
  }

  async function countStore(storeName) {
    if (storeName === "orders" && root.UnifiedAnalysis) return root.UnifiedAnalysis.snapshot().items.length;
    const db = await openDb();
    return new Promise((resolve, reject) => {
      const req = db.transaction(storeName, "readonly").objectStore(storeName).count();
      req.onsuccess = () => resolve(req.result || 0);
      req.onerror = () => reject(req.error);
    });
  }

  async function deleteRows(storeName, keys) {
    if (!keys || !keys.length) return;
    const db = await openDb();
    const tx = db.transaction(storeName, "readwrite");
    const st = tx.objectStore(storeName);
    keys.forEach(key => st.delete(key));
    await txDone(tx);
  }

  async function putMeta(key, value) {
    await bulkPut("meta", [{ key, value, updated_at: nowIso() }]);
  }

  async function clearAllData() {
    if (STATE.db) { STATE.db.close(); STATE.db = null; }
    await new Promise((resolve, reject) => {
      const req = indexedDB.deleteDatabase(DB_NAME);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
      req.onblocked = () => reject(new Error("Database đang được tab khác sử dụng"));
    });
    await openDb();
  }

  function getPath(obj, path) {
    if (!obj) return undefined;
    const parts = path.split(".");
    let cur = obj;
    for (const part of parts) {
      if (cur == null || typeof cur !== "object" || !(part in cur)) return undefined;
      cur = cur[part];
    }
    return cur;
  }

  function pick(obj, paths, fallback) {
    for (const path of paths) {
      const v = getPath(obj, path);
      if (v !== undefined && v !== null && v !== "") return v;
    }
    return fallback;
  }

  function parseApiTime(v) {
    if (v == null || v === "") return null;
    if (typeof v === "number") {
      const ms = v < 100000000000 ? v * 1000 : v;
      const d = new Date(ms);
      return isNaN(d.getTime()) ? null : d;
    }
    const s = String(v).trim();
    if (!s) return null;
    if (/^\d{10,13}$/.test(s)) {
      const n = Number(s); const d = new Date(s.length === 10 ? n * 1000 : n);
      return isNaN(d.getTime()) ? null : d;
    }
    const hasZone = /(?:Z|[+-]\d{2}:?\d{2})$/i.test(s);
    let normalized = /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}/.test(s) ? s.replace(" ", "T") : s;
    if (/^\d{4}-\d{2}-\d{2}$/.test(normalized)) normalized += "T00:00:00";
    const d = new Date(hasZone ? normalized : `${normalized}+07:00`);
    return isNaN(d.getTime()) ? null : d;
  }

  function isoOf(v) {
    const d = parseApiTime(v);
    return d ? d.toISOString() : "";
  }

  function unwrapRecords(json) {
    if (!json) return [];
    const candidates = [json.data, json.items, json.results, json.orders, json.rows, json];
    for (const d of candidates) {
      if (Array.isArray(d)) return d;
      if (d && typeof d === "object") {
        const numeric = Object.keys(d).filter(k => /^\d+$/.test(k));
        if (numeric.length) return numeric.sort((a, b) => Number(a) - Number(b)).map(k => d[k]);
        for (const k of ["items", "results", "orders", "rows", "data"]) {
          if (Array.isArray(d[k])) return d[k];
        }
      }
    }
    return [];
  }

  function unwrapDetail(json) {
    if (!json || typeof json !== "object") return json;
    for (const c of [json.order, json.result]) {
      if (c && typeof c === "object" && !Array.isArray(c)) return c;
    }
    if (json.data && typeof json.data === "object" && !Array.isArray(json.data)) {
      const d = json.data;
      for (const c of [d.order, d.result, d.item]) {
        if (c && typeof c === "object" && !Array.isArray(c)) return c;
      }
      if (d.order_code || d.ref_code || d.histories || d.history || Object.keys(json).length <= 4) return d;
    }
    return json;
  }

  function pagingOf(json) {
    return json && (json.paging || json.pagination || (json.meta && json.meta.pagination)) || {};
  }

  async function fetchJson(url, token, init) {
    const options = init || {};
    if (root.UnifiedAnalysis && String(options.method || "GET").toUpperCase() !== "GET") throw new Error("Endpoint ghi dữ liệu không được tự chạy trong chế độ hợp nhất.");
    const retries = options.retries == null
      ? ((CFG.api && CFG.api.retries) == null ? 3 : Number(CFG.api.retries))
      : options.retries;
    const timeoutMs = options.timeoutMs || (CFG.api && CFG.api.timeoutMs) || 25000;
    let lastError;
    for (let attempt = 0; attempt <= retries; attempt++) {
      const globalSignal = STATE.abortController && STATE.abortController.signal;
      if (globalSignal && globalSignal.aborted) throw new DOMException("Đã dừng", "AbortError");
      const requestController = new AbortController();
      let timedOut = false;
      const relayAbort = () => requestController.abort();
      if (globalSignal) globalSignal.addEventListener("abort", relayAbort, { once: true });
      const timer = setTimeout(() => { timedOut = true; requestController.abort(); }, timeoutMs);
      try {
        const headers = new Headers(options.headers || {});
        if (token) headers.set("Authorization", token);
        if (!headers.has("Accept")) headers.set("Accept", "application/json, text/plain, */*");
        if (!headers.has("Cache-Control")) headers.set("Cache-Control", "no-cache");
        if (options.body && !headers.has("Content-Type")) headers.set("Content-Type", "application/json");
        const res = await fetch(url, {
          method: options.method || "GET",
          headers,
          body: options.body || undefined,
          signal: requestController.signal
        });
        if (res.status === 401 || res.status === 403) {
          const e = new Error(`TOKEN_OR_PERMISSION_${res.status}`); e.code = res.status; throw e;
        }
        if (res.status === 429 || res.status >= 500) {
          const e = new Error(`HTTP ${res.status}`); e.code = res.status;
          const retryAfter = res.headers && res.headers.get ? Number(res.headers.get("retry-after")) : 0;
          e.retryAfterMs = retryAfter > 0 ? retryAfter * 1000 : 0;
          throw e;
        }
        if (!res.ok) { const e = new Error(`HTTP ${res.status}`); e.code = res.status; throw e; }
        if (res.status === 204) return null;
        const contentType = text(res.headers && res.headers.get && res.headers.get("content-type")).toLowerCase();
        const rawText = await res.text();
        const trimmed = rawText.trim();
        if (/text\/html|application\/xhtml/i.test(contentType) || /^\s*(?:<!doctype\s+html|<html\b)/i.test(trimmed)) {
          const titleMatch = trimmed.match(/<title[^>]*>([^<]{0,160})<\/title>/i);
          const finalUrl = text(res.url || url);
          const e = new Error(`API trả HTML thay vì JSON · HTTP ${res.status}${titleMatch ? ` · ${titleMatch[1].trim()}` : ""}`);
          e.code = "HTML_RESPONSE";
          e.httpStatus = res.status;
          e.contentType = contentType;
          e.finalUrl = finalUrl;
          e.redirected = !!res.redirected;
          e.systemic = true;
          throw e;
        }
        if (!trimmed) {
          const e = new Error(`API trả body rỗng · HTTP ${res.status}`);
          e.code = "EMPTY_RESPONSE"; e.httpStatus = res.status; e.systemic = true; throw e;
        }
        try { return JSON.parse(trimmed); }
        catch (_) {
          const e = new Error(`API trả dữ liệu không phải JSON · HTTP ${res.status} · ${contentType || "unknown content-type"}`);
          e.code = "INVALID_JSON"; e.httpStatus = res.status; e.contentType = contentType; e.systemic = true; throw e;
        }
      } catch (e) {
        if (e && e.name === "AbortError") {
          if (globalSignal && globalSignal.aborted) throw new DOMException("Đã dừng", "AbortError");
          if (timedOut) { const t = new Error(`TIMEOUT_${timeoutMs}ms`); t.code = "TIMEOUT"; e = t; }
          else throw e;
        }
        if (e && e.code >= 400 && e.code < 500 && e.code !== 429) throw e;
        lastError = e;
        if (attempt < retries) {
          const backoff = (e && e.retryAfterMs) || (450 * Math.pow(2, attempt) + Math.round(Math.random() * 180));
          await sleep(backoff);
        }
      } finally {
        clearTimeout(timer);
        if (globalSignal) globalSignal.removeEventListener("abort", relayAbort);
      }
    }
    throw lastError || new Error("API request failed");
  }

  function historyArrays(detail) {
    const candidates = [
      detail && detail.histories,
      detail && detail.history,
      detail && detail.timeline,
      detail && detail.status_histories,
      detail && detail.order_status_histories,
      detail && detail.events,
      detail && detail.delivery && detail.delivery.histories,
      detail && detail.delivery && detail.delivery.timeline,
      detail && detail.shipment && detail.shipment.histories,
      detail && detail.shipment && detail.shipment.events
    ];
    const out = [], seenArrays = new Set(), seenObjects = new Set();
    const addArray = v => {
      if (!Array.isArray(v) || seenArrays.has(v)) return;
      seenArrays.add(v); out.push(...v);
    };
    candidates.forEach(v => {
      if (Array.isArray(v)) addArray(v);
      else if (v && typeof v === "object") Object.values(v).forEach(addArray);
    });
    let visited = 0;
    function walk(v, depth) {
      if (!v || typeof v !== "object" || depth > 6 || visited++ > 5000 || seenObjects.has(v)) return;
      seenObjects.add(v);
      for (const [key, child] of Object.entries(v)) {
        if (Array.isArray(child)) {
          const sample = child.find(x => x && typeof x === "object");
          const keys = sample ? Object.keys(sample).join(" ") : "";
          if (/(histor|timeline|event|status.*log|tracking.*update|activity)/i.test(key)
            || (/(created_at|event_at|timestamp|time|date)/i.test(keys) && /(status|code|event|action|state)/i.test(keys))) addArray(child);
          child.slice(0, 3).forEach(x => walk(x, depth + 1));
        } else if (child && typeof child === "object") walk(child, depth + 1);
      }
    }
    walk(detail, 0);
    return out.filter(x => x && typeof x === "object");
  }

  function eventCode(h) {
    return text(pick(h, ["sub_status", "sub_status_code", "status", "status_code", "code", "event_code", "type", "action", "name", "state"], "unknown"));
  }
  function eventLabel(h, code) {
    return text(pick(h, ["description", "description_vi", "message", "title", "label", "note", "content", "reason"], code));
  }
  function eventTime(h) {
    return pick(h, ["created_at", "event_at", "event_time", "occurred_at", "happened_at", "action_at", "timestamp", "time", "date", "updated_at", "status_at"], "");
  }
  function canonicalOf(code, label) {
    const hay = stripVN(`${code} ${label}`);
    const hit = CANONICAL_STEPS.find(x => x.re.test(hay));
    return hit ? hit.key : "other";
  }

  function extractEvents(detail, listOrder) {
    const raw = historyArrays(detail || {});
    let events = raw.map((h, i) => {
      const code = eventCode(h);
      const label = eventLabel(h, code);
      const atApi = eventTime(h);
      return {
        event_index_api: i + 1,
        canonical_step: canonicalOf(code, label),
        canonical_label: STEP_LABEL[canonicalOf(code, label)] || "Sự kiện khác",
        status_code: code,
        event_label: label,
        event_at_api: text(atApi),
        event_at_iso: isoOf(atApi),
        actor: text(pick(h, ["actor", "created_by", "user", "source", "provider"], "")),
        reason: text(pick(h, ["reason", "reason_text", "failure_reason", "cancel_reason"], "")),
        source: "api_history",
        raw: h
      };
    });

    const created = pick(detail || {}, ["created_at", "order_created_at"], pick(listOrder || {}, ["created_at", "order_created_at"], ""));
    if (created) {
      const hasSame = events.some(e => e.event_at_api === text(created) && ["received", "confirmed"].includes(e.canonical_step));
      if (!hasSame) events.push({
        event_index_api: 0,
        canonical_step: "received",
        canonical_label: STEP_LABEL.received,
        status_code: "@order_created_at",
        event_label: "TikiNOW tiếp nhận / tạo đơn",
        event_at_api: text(created),
        event_at_iso: isoOf(created),
        actor: "TikiNOW API",
        reason: "",
        source: "order.created_at",
        raw: { created_at: created }
      });
    }

    const unique = new Map();
    events.forEach(e => {
      const fp = [e.status_code, e.event_at_api, e.event_label, e.reason].map(text).join("\u001f");
      if (!unique.has(fp)) unique.set(fp, e);
    });
    events = Array.from(unique.values());
    events.sort((a, b) => {
      const ta = parseApiTime(a.event_at_api), tb = parseApiTime(b.event_at_api);
      if (ta && tb && ta.getTime() !== tb.getTime()) return ta - tb;
      if (ta && !tb) return -1;
      if (!ta && tb) return 1;
      return a.event_index_api - b.event_index_api;
    });
    const attemptByStep = {}, attemptByCode = {};
    events.forEach((e, i) => {
      e.sequence = i + 1;
      attemptByStep[e.canonical_step] = (attemptByStep[e.canonical_step] || 0) + 1;
      attemptByCode[e.status_code] = (attemptByCode[e.status_code] || 0) + 1;
      e.canonical_attempt_no = attemptByStep[e.canonical_step];
      e.status_attempt_no = attemptByCode[e.status_code];
      e.minutes_from_previous_event = i ? diffMin(events[i - 1].event_at_api, e.event_at_api) : null;
    });
    return events;
  }

  function diffMin(a, b) {
    const da = parseApiTime(a), db = parseApiTime(b);
    return da && db ? Math.round((db - da) / 60000) : null;
  }

  function journeyFrom(events) {
    const wide = {};
    CANONICAL_STEPS.forEach(step => {
      const e = events.find(x => x.canonical_step === step.key && x.event_at_api);
      wide[`${step.key}_at_api`] = e ? e.event_at_api : "";
      wide[`${step.key}_at_iso`] = e ? e.event_at_iso : "";
    });
    const pairs = [
      ["received", "ready_to_pick", "received_to_ready_min"],
      ["ready_to_pick", "picking_started", "ready_to_picking_min"],
      ["picking_started", "packing_started", "picking_to_packing_min"],
      ["packing_started", "packed", "packing_duration_min"],
      ["packed", "handover", "packed_to_handover_min"],
      ["handover", "carrier_pickup", "handover_to_pickup_min"],
      ["carrier_pickup", "first_attempt", "pickup_to_first_attempt_min"],
      ["handover", "delivered", "lastmile_duration_min"],
      ["received", "handover", "fulfillment_duration_min"],
      ["received", "delivered", "end_to_end_duration_min"]
    ];
    pairs.forEach(([a, b, key]) => { wide[key] = diffMin(wide[`${a}_at_api`], wide[`${b}_at_api`]); });
    const core = ["received", "ready_to_pick", "picking_started", "packing_started", "packed", "handover", "delivered"];
    wide.timeline_completeness_pct = Math.round(core.filter(k => wide[`${k}_at_api`]).length * 100 / core.length);
    const last = [...events].reverse().find(e => e.event_at_api);
    wide.last_event_code = last ? last.status_code : "";
    wide.last_event_label = last ? last.event_label : "";
    wide.last_event_at_api = last ? last.event_at_api : "";
    return wide;
  }

  function itemArrays(order) {
    const direct = [
      order && order.items,
      order && order.products,
      order && order.order_items,
      order && order.line_items,
      order && order.delivery && order.delivery.items
    ];
    for (const v of direct) if (Array.isArray(v)) return v;
    if (order && Array.isArray(order.packages)) {
      return order.packages.flatMap(p => Array.isArray(p.items) ? p.items : []);
    }
    return [];
  }

  function normalizeItems(order, pk) {
    return itemArrays(order || {}).map((it, i) => ({
      order_pk: pk,
      line_no: i + 1,
      sku: text(pick(it, ["sku", "product_sku", "master_sku", "seller_sku"], "")),
      seller_product_code: text(pick(it, ["seller_product_code", "product_code", "seller_sku"], "")),
      product_id: text(pick(it, ["product_id", "id"], "")),
      product_name: text(pick(it, ["name", "product_name", "title"], "")),
      quantity: Number(pick(it, ["quantity", "qty", "requested_quantity"], 0) || 0),
      packed_quantity: Number(pick(it, ["packed_quantity", "fulfilled_quantity"], 0) || 0),
      price: Number(pick(it, ["price", "unit_price", "sale_price"], 0) || 0),
      grade: text(pick(it, ["grade", "stock_grade", "inventory_grade"], "")),
      gc: text(pick(it, ["gc", "goods_condition", "condition"], "")),
      raw: it
    }));
  }

  function countPaths(obj, cap) {
    let count = 0;
    const seen = new Set();
    function walk(v, depth) {
      if (v == null || depth > 8 || count >= (cap || 5000)) return;
      if (typeof v !== "object") { count++; return; }
      if (seen.has(v)) return;
      seen.add(v);
      if (Array.isArray(v)) { if (v.length) walk(v[0], depth + 1); return; }
      Object.keys(v).forEach(k => { count++; walk(v[k], depth + 1); });
    }
    walk(obj, 0);
    return count;
  }

  function stableStringify(value) {
    const seen = new Set();
    function walk(v) {
      if (v == null || typeof v !== "object") return v;
      if (seen.has(v)) return "[Circular]";
      seen.add(v);
      let out;
      if (Array.isArray(v)) out = v.map(walk);
      else {
        out = {};
        Object.keys(v).sort().forEach(k => { out[k] = walk(v[k]); });
      }
      seen.delete(v);
      return out;
    }
    return JSON.stringify(walk(value == null ? null : value));
  }

  function hashRaw(value) {
    const s = stableStringify(value) || "null";
    let h = 2166136261, h2 = 2246822507;
    for (let i = 0; i < s.length; i++) {
      h ^= s.charCodeAt(i);
      h = Math.imul(h, 16777619);
      h2 ^= s.charCodeAt(i);
      h2 = Math.imul(h2, 3266489909);
    }
    const hex = n => (`00000000${(n >>> 0).toString(16)}`).slice(-8);
    return `${hex(h)}${hex(h2)}`;
  }

  function comparableFlat(value, prefix, out, depth) {
    out = out || {}; depth = depth || 0;
    if (value == null || typeof value !== "object" || depth > 8) {
      out[prefix || "value"] = value == null ? null : value;
      return out;
    }
    if (Array.isArray(value)) { out[prefix || "value"] = JSON.stringify(value); return out; }
    Object.keys(value).forEach(k => comparableFlat(value[k], prefix ? `${prefix}.${k}` : k, out, depth + 1));
    return out;
  }

  function changedFields(before, after) {
    if (!before) return ["@created"];
    const a = comparableFlat(before), b = comparableFlat(after);
    return Array.from(new Set([...Object.keys(a), ...Object.keys(b)]))
      .filter(k => JSON.stringify(a[k]) !== JSON.stringify(b[k]))
      .slice(0, 500);
  }

  const VIDEO_FILE_RE = /\.(?:mp4|m4v|mov|webm|m3u8|avi|mkv|3gp|mpeg|mpg)(?:$|[?#])/i;
  const IMAGE_FILE_RE = /\.(?:jpe?g|png|gif|webp|svg|bmp|heic)(?:$|[?#])/i;
  const MEDIA_CONTEXT_RE = /(?:video|media|clip|record|recording|attachment|evidence|proof|camera|cctv|packing|package|unbox|unpack|open.?box|khui|dong.?goi|mo.?hang)/i;

  function httpVideoUrl(value, context, parent, baseUrl) {
    const raw = text(value).trim();
    if (!/^(?:https?:)?\/\//i.test(raw) && !/^\//.test(raw)) return "";
    let url = raw.startsWith("//") ? `https:${raw}` : raw;
    if (/^\//.test(url)) {
      try { url = new URL(url, baseUrl || API_BASE).toString(); }
      catch (_) { return ""; }
    }
    if (IMAGE_FILE_RE.test(url)) return "";
    const mime = text(parent && pick(parent, ["mime_type", "mimeType", "content_type", "contentType", "type"], ""));
    const obviousVideo = VIDEO_FILE_RE.test(url) || /video|mpegurl/i.test(mime);
    if (!obviousVideo && /(?:thumbnail|thumb|image|photo|poster|preview|avatar|icon|cover)(?:_|\.|\[|\s|$)/i.test(context)) return "";
    if (!obviousVideo && !MEDIA_CONTEXT_RE.test(context)) return "";
    try {
      const u = new URL(url);
      return /^https?:$/i.test(u.protocol) ? u.toString() : "";
    } catch (_) { return ""; }
  }

  function videoCategory(value) {
    const hint = stripVN(value).replace(/[_/.-]+/g, " ");
    if (/(?:unbox|unpack|open\s*box|khui|mo\s*(?:hop|hang|kien)|khach\s*mo|kiem\s*tra\s*hang)/i.test(hint)) return "unboxing";
    if (/(?:packing|packaged?|dong\s*goi|fulfill(?:ment)?\s*video|warehouse\s*video)/i.test(hint)) return "packing";
    return "other";
  }

  function canonicalVideoUrl(value) {
    try {
      const u = new URL(value);
      Array.from(u.searchParams.keys()).forEach(key => {
        if (/(?:authorization|auth|access[_-]?key|token|signature|sig|expires?|credential|policy|key-pair-id|x-amz-|x-goog-)/i.test(key)) u.searchParams.delete(key);
      });
      u.searchParams.sort();
      u.hash = "";
      return u.toString();
    } catch (_) { return text(value); }
  }

  function extractVideos(detail, listOrder, mediaPayloads) {
    const roots = [];
    if (detail && typeof detail === "object") roots.push({ value: detail, source: "order_detail", endpoint: "" });
    if (listOrder && typeof listOrder === "object") roots.push({ value: listOrder, source: "order_list", endpoint: "" });
    (Array.isArray(mediaPayloads) ? mediaPayloads : []).forEach((entry, index) => {
      const wrapped = entry && typeof entry === "object" && Object.prototype.hasOwnProperty.call(entry, "payload");
      roots.push({
        value: wrapped ? entry.payload : entry,
        source: text(wrapped && entry.source || "media_api"),
        endpoint: text(wrapped && (entry.endpoint || entry.route || entry.url) || ""),
        requestUrl: text(wrapped && (entry.request_url || entry.requestUrl) || ""),
        capturedAt: text(wrapped && entry.captured_at || ""),
        rootIndex: index
      });
    });

    const found = new Map();
    const seenObjects = new Set();
    let visited = 0;
    function add(value, path, parent, meta) {
      const siblingHint = parent && typeof parent === "object" ? [
        pick(parent, ["type", "kind", "category", "video_type", "media_type"], ""),
        pick(parent, ["title", "label", "name", "description", "note"], "")
      ].join(" ") : "";
      const context = `${path} ${siblingHint} ${meta.endpoint || ""}`;
      const url = httpVideoUrl(value, context, parent, meta.requestUrl);
      if (!url) return;
      const category = videoCategory(context);
      const row = {
        category,
        category_label: category === "packing" ? "Video đóng gói" : category === "unboxing" ? "Video khui hàng" : "Video khác",
        url,
        label: text(parent && pick(parent, ["title", "label", "name", "description", "file_name", "filename"], "")),
        created_at_api: text(parent && pick(parent, ["created_at", "recorded_at", "uploaded_at", "event_at", "timestamp", "time"], "")),
        provider: text(parent && pick(parent, ["provider", "source", "vendor", "storage", "camera"], "")),
        source: meta.source,
        source_path: path,
        source_endpoint: meta.endpoint || "",
        source_request_url: meta.requestUrl || "",
        captured_at: meta.capturedAt || ""
      };
      const key = canonicalVideoUrl(url);
      const current = found.get(key);
      if (!current || (current.category === "other" && category !== "other") || (current.source !== "media_api" && meta.source === "media_api")) found.set(key, row);
    }
    function walk(value, path, depth, meta, parent) {
      if (value == null || depth > 10 || visited++ > 12000) return;
      if (typeof value === "string") { add(value, path, parent, meta); return; }
      if (typeof value !== "object" || seenObjects.has(value)) return;
      seenObjects.add(value);
      if (Array.isArray(value)) {
        value.forEach((child, i) => walk(child, `${path}[${i}]`, depth + 1, meta, value));
        return;
      }
      Object.entries(value).forEach(([key, child]) => walk(child, path ? `${path}.${key}` : key, depth + 1, meta, value));
    }
    roots.forEach((entry, i) => walk(entry.value, entry.source || `root${i}`, 0, entry, null));
    return Array.from(found.values()).sort((a, b) => {
      const rank = { packing: 0, unboxing: 1, other: 2 };
      return (rank[a.category] - rank[b.category]) || text(a.created_at_api).localeCompare(text(b.created_at_api));
    });
  }

  function normalizeOrder(listOrder, detail, sellerId, mediaPayloads) {
    const source = detail && typeof detail === "object" ? detail : (listOrder || {});
    const list = listOrder || {};
    const orderCode = text(pick(source, ["order_code", "code", "order_id"], pick(list, ["order_code", "code", "order_id"], "")));
    const pk = `${sellerId}|${orderCode || pick(source, ["id"], crypto.randomUUID())}`;
    const events = extractEvents(source, list);
    const journey = journeyFrom(events);
    const items = normalizeItems(source, pk);
    const videos = extractVideos(detail, list, mediaPayloads);
    const packingVideos = videos.filter(v => v.category === "packing");
    const unboxingVideos = videos.filter(v => v.category === "unboxing");
    const otherVideos = videos.filter(v => v.category === "other");
    const prefixMap = root.TNSL_PREFIX && root.TNSL_PREFIX.mapByRefCode
      ? root.TNSL_PREFIX.mapByRefCode(pick(source, ["ref_code"], pick(list, ["ref_code"], "")), sellerId)
      : null;

    const warehouse = pick(source, ["warehouse.name", "warehouse.code", "warehouse.id", "warehouse"], pick(list, ["warehouse.name", "warehouse.code", "warehouse"], ""));
    const carrier = pick(source, [
      "extra.delivery_partner", "extra.partner", "delivery.carrier", "delivery.partner",
      "delivery.provider", "delivery.tracking.delivered_by", "shipping_partner"
    ], pick(list, ["extra.delivery_partner", "extra.partner", "delivery.tracking.delivered_by"], ""));
    const tracking = pick(source, [
      "tracking_code", "tracking_no", "delivery.tracking.tracking_code", "delivery.tracking.code",
      "delivery.tracking.awb", "shipment.tracking_code"
    ], pick(list, ["tracking_code", "delivery.tracking.tracking_code"], ""));
    const promised = pick(source, [
      "delivery.promised_delivery_date", "delivery.promised_delivery_at", "delivery.estimated_delivery_date",
      "delivery.estimated_delivery_at", "promised_delivery_date", "promised_delivery_at",
      "estimated_delivery_date", "estimated_delivery_at", "extra.promised_delivery_date"
    ], "");

    return {
      pk,
      seller_id: String(sellerId),
      account_name: accountName(sellerId),
      order_code: orderCode,
      ref_code: text(pick(source, ["ref_code", "partner_order_code", "marketplace_order_code"], pick(list, ["ref_code"], ""))),
      internal_id: text(pick(source, ["id", "order_id"], pick(list, ["id"], ""))),
      status: text(pick(source, ["status"], pick(list, ["status"], ""))),
      sub_status: text(pick(source, ["sub_status"], pick(list, ["sub_status"], ""))),
      fulfillment_type: text(pick(source, ["fulfillment_type", "fulfillment.type"], pick(list, ["fulfillment_type"], ""))),
      platform: text(pick(source, ["extra.platform", "platform", "sales_channel.platform"], prefixMap && prefixMap.platform || "Tiki")),
      channel: text(pick(source, ["extra.channel", "channel", "sales_channel.name"], prefixMap && prefixMap.opollo || "")),
      group_brand: text(prefixMap && prefixMap.gb || ""),
      brand: text(prefixMap && prefixMap.brand || ""),
      prefix: text(prefixMap && prefixMap.preflix || (root.TNSL_PREFIX && root.TNSL_PREFIX.buildPreflix ? root.TNSL_PREFIX.buildPreflix(pick(source, ["ref_code"], "")) : "")),
      warehouse: text(typeof warehouse === "object" ? (warehouse.name || warehouse.code || warehouse.id || "") : warehouse),
      carrier: text(typeof carrier === "object" ? (carrier.name || carrier.code || carrier.id || "") : carrier),
      tracking_no: text(tracking),
      partner_tracking_id: text(pick(source, ["partner_tracking_id", "delivery.tracking.partner_tracking_id", "delivery.tracking.id", "shipment.id", "shipment_id"], "")),
      created_at_api: text(pick(source, ["created_at", "order_created_at"], pick(list, ["created_at"], ""))),
      updated_at_api: text(pick(source, ["updated_at"], pick(list, ["updated_at"], ""))),
      promised_delivery_at_api: text(promised),
      recipient_name: text(pick(source, ["delivery.address.full_name", "delivery.recipient.name", "recipient.name", "shipping_address.full_name", "receiver_name"], "")),
      recipient_phone: text(pick(source, ["delivery.address.phone", "delivery.recipient.phone", "recipient.phone", "shipping_address.phone", "receiver_phone"], "")),
      recipient_province: text(pick(source, ["delivery.address.province", "shipping_address.province", "recipient.province"], "")),
      recipient_district: text(pick(source, ["delivery.address.district", "shipping_address.district", "recipient.district"], "")),
      recipient_address: text(pick(source, ["delivery.address.full_address", "delivery.address.address", "shipping_address.full_address", "shipping_address.address"], "")),
      address_type: text(pick(source, ["delivery.address.type", "shipping_address.type", "address_type"], "")),
      delivery_instruction: text(pick(source, ["delivery.instruction", "delivery.note", "shipping_note", "delivery_instruction", "note"], "")),
      cod_amount: Number(pick(source, ["payment.cod_amount", "cod_amount", "delivery.cod_amount", "collect_on_delivery"], 0) || 0),
      order_total: Number(pick(source, ["payment.total", "total", "total_amount", "grand_total"], 0) || 0),
      currency: text(pick(source, ["payment.currency", "currency"], "VND")),
      packing_method: text(pick(source, ["packing.method", "packing_method", "extra.packing_method"], "")),
      pickup_partner: text(pick(source, ["pickup.partner", "extra.pickup_partner", "delivery.pickup_partner"], "")),
      packing_only: bool(pick(source, ["is_packing_only", "packing_only", "extra.is_packing_only"], false)),
      co_inspection: bool(pick(source, ["is_co_inspection", "allow_inspection", "co_inspection", "extra.is_co_inspection"], false)),
      product_sku_count: items.length,
      total_quantity: items.reduce((s, x) => s + (x.quantity || 0), 0),
      sku_list: items.map(x => x.sku).filter(Boolean).join(" | "),
      video_count: videos.length,
      packing_video_count: packingVideos.length,
      unboxing_video_count: unboxingVideos.length,
      other_video_count: otherVideos.length,
      packing_video_urls: packingVideos.map(v => v.url),
      unboxing_video_urls: unboxingVideos.map(v => v.url),
      other_video_urls: otherVideos.map(v => v.url),
      video_hash: hashRaw(videos.map(v => ({ category: v.category, url: canonicalVideoUrl(v.url), source_path: v.source_path }))),
      media_sync_status: Array.isArray(mediaPayloads) && mediaPayloads.length ? "success" : "embedded_only",
      media_synced_at: Array.isArray(mediaPayloads) && mediaPayloads.length ? nowIso() : "",
      has_detail: !!detail,
      detail_sync_status: detail ? "success" : "not_fetched",
      detail_sync_error: "",
      last_detail_attempt_at: detail ? nowIso() : "",
      api_field_count: countPaths(source, 10000),
      raw_hash: hashRaw(detail || listOrder || {}),
      source_updated_at: text(pick(list, ["updated_at"], pick(source, ["updated_at"], ""))),
      synced_at: nowIso(),
      journey,
      events,
      items,
      videos,
      raw_list: listOrder || null,
      raw_detail: detail || null,
      raw_media: Array.isArray(mediaPayloads) ? mediaPayloads : []
    };
  }

  function detailFailureKey(sellerId, orderCode) { return `detail|${sellerId}|${orderCode}`; }

  async function persistOrders(rows, existingMap, failureMap) {
    const snapshots = [], resolvedFailures = [];
    for (const row of rows || []) {
      const old = existingMap && existingMap.get(row.pk);
      const detailSucceeded = row.detail_sync_status === "success";
      if (detailSucceeded && row.has_detail && (!old || row.raw_hash !== old.raw_hash)) {
        const fields = changedFields(old && old.raw_detail, row.raw_detail);
        snapshots.push({
          pk: `${row.pk}|${row.synced_at}|${row.raw_hash}|${crypto.randomUUID()}`,
          order_pk: row.pk,
          seller_id: row.seller_id,
          order_code: row.order_code,
          captured_at: row.synced_at,
          raw_hash: row.raw_hash,
          previous_hash: old && old.raw_hash || "",
          change_type: old ? "updated" : "created",
          status_from: old && old.status || "",
          status_to: row.status,
          sub_status_from: old && old.sub_status || "",
          sub_status_to: row.sub_status,
          changed_field_count: fields.length,
          changed_fields: fields,
          raw_detail: row.raw_detail
        });
        if (old) STATE.counters.changed = (STATE.counters.changed || 0) + 1;
      }
      if (detailSucceeded) resolvedFailures.push(detailFailureKey(row.seller_id, row.order_code));
    }
    if (snapshots.length) await bulkPut("snapshots", snapshots);
    await bulkPut("orders", rows);
    if (resolvedFailures.length) await deleteRows("sync_failures", resolvedFailures);
    if (failureMap) resolvedFailures.forEach(key => failureMap.delete(key));
    if (existingMap) rows.forEach(row => existingMap.set(row.pk, row));
  }

  /* v2.3.2 — sức khỏe token theo từng account.
     Ghi lại account nào vừa chạy được, account nào 401/403 cần đăng nhập lại. */
  const ACCOUNT_HEALTH_KEY = "tnslAccountHealth";
  async function noteAccountHealth(sid, res) {
    try {
      const store = await chrome.storage.local.get(ACCOUNT_HEALTH_KEY);
      const map = store[ACCOUNT_HEALTH_KEY] || {};
      const prev = map[String(sid)] || {};
      map[String(sid)] = res.ok
        ? { ...prev, lastOkAt: Date.now(), needsRelogin: false, lastErrCode: null, lastMessage: null }
        : { ...prev, lastErrAt: Date.now(), lastErrCode: res.code || null,
            lastMessage: text(res.message).slice(0, 200), needsRelogin: !!res.relogin };
      await chrome.storage.local.set({ [ACCOUNT_HEALTH_KEY]: map });
    } catch (_) {}
  }

  async function selectedTokens() {
    const all = await runtimeMessage({ type: "GET_TOKENS" }) || {};
    const { accountSel = [] } = await chrome.storage.local.get("accountSel");
    let picked = all;
    if (Array.isArray(accountSel) && accountSel.length) {
      const allowed = new Set(accountSel.map(String));
      picked = Object.fromEntries(Object.entries(all).filter(([sid]) => allowed.has(String(sid))));
    }
    /* Hook v2.3.2: autopilot dùng để chỉ tự-sync các account còn sống,
       tránh gõ 401 vào account đã hết hạn mỗi 10 phút. Sync thủ công không set hook
       nên vẫn thử toàn bộ account như cũ. */
    if (typeof root.TNSL_SYNC_FILTER === "function") {
      try {
        const kept = root.TNSL_SYNC_FILTER(Object.keys(picked));
        if (Array.isArray(kept)) {
          const keep = new Set(kept.map(String));
          const filtered = Object.fromEntries(Object.entries(picked).filter(([sid]) => keep.has(String(sid))));
          if (Object.keys(filtered).length) picked = filtered;
        }
      } catch (_) {}
    }
    return picked;
  }

  function syncOptions(mode, flags) {
    const days = Math.max(1, Number($("dhDays") && $("dhDays").value || 30));
    const fromRaw = $("dhFrom") && $("dhFrom").value || "2020-01-01";
    const fromInput = /^\d{4}-\d{2}-\d{2}$/.test(fromRaw) ? fromRaw : "2020-01-01";
    const now = new Date();
    const scope = (flags && flags.scope) || "all";
    /* Backlog = đơn CHƯA XONG, và đơn kẹt lâu nhất mới là đơn đáng lo nhất.
       Cắt cửa sổ theo created_at N ngày sẽ giấu mất chính những đơn đó,
       nên chế độ Backlog luôn quét toàn thời gian. Chi phí thấp vì chỉ có
       2 status chưa xong và không gọi detail. */
    const fromDate = (mode === "full" || scope === "backlog")
      ? new Date(`${fromInput}T00:00:00+07:00`)
      : new Date(now.getTime() - days * 86400000);
    return {
      mode,
      days,
      from: apiDate(fromDate),
      to: apiDate(now),
      perPage: Math.min(200, Math.max(20, Number($("dhPerPage") && $("dhPerPage").value || 100))),
      maxPages: Math.min(5000, Math.max(1, Number($("dhMaxPages") && $("dhMaxPages").value || 500))),
      concurrency: Math.min(20, Math.max(1, Number($("dhConcurrency") && $("dhConcurrency").value || 8))),
      includeCatalog: mode === "full",
      forceRetries: !!(flags && flags.forceRetries),
      /* scope='backlog' → chỉ status chưa xong, không gọi detail, không gọi media, không catalog. */
      scope: (flags && flags.scope) || "all",
      skipDetail: !!(flags && flags.scope === "backlog" && !flags.withDetail)
    };
  }

  function orderListUrl(sid, status, page, opts) {
    const u = new URL(`${API_BASE}/orders`);
    u.searchParams.set("filters.created_at.from", opts.from);
    u.searchParams.set("filters.created_at.to", opts.to);
    u.searchParams.set("filters.seller_id", sid);
    u.searchParams.set("seller_id", sid);
    if (status) u.searchParams.set("filters.status", status);
    u.searchParams.set("page.page_number", page);
    u.searchParams.set("page.per_page", opts.perPage);
    u.searchParams.set("sort_by", "created_at|desc");
    return u.toString();
  }

  function normalizeStatusCounts(raw) {
    if (Array.isArray(raw)) {
      const out = {};
      raw.forEach(row => {
        const code = text(pick(row, ["status", "status_code", "code", "key", "name"], ""));
        if (code) out[code] = row;
      });
      return out;
    }
    return raw && typeof raw === "object" ? raw : {};
  }

  async function dynamicStatuses(sid, token, opts) {
    const u = new URL(`${API_BASE}/orders/counts`);
    u.searchParams.set("filters.created_at.from", opts.from);
    u.searchParams.set("filters.created_at.to", opts.to);
    u.searchParams.set("filters.seller_id", sid);
    u.searchParams.set("seller_id", sid);
    const json = await fetchJson(u.toString(), token);
    const rawStatuses = pick(json, ["data.statuses", "statuses", "data.counts", "counts"], {});
    const statuses = normalizeStatusCounts(rawStatuses);
    const keys = Object.keys(statuses || {}).filter(Boolean);
    return { statuses: keys.length ? keys : DEFAULT_STATUSES, counts: statuses };
  }

  async function pullAllOrdersForSeller(sid, token, opts) {
    let statusInfo;
    try { statusInfo = await dynamicStatuses(sid, token, opts); }
    catch (e) {
      log(`${accountName(sid)}: không đọc được counts, dùng bộ status chuẩn (${e.message})`, "warn");
      STATE.counters.errors++;
      statusInfo = { statuses: DEFAULT_STATUSES, counts: {}, countsError: e && e.message || String(e) };
    }
    /* v2.4 — CHẾ ĐỘ BACKLOG: chỉ kéo status còn phải xử lý.
       delivered + canceled là hai status phình to nhất theo thời gian và
       hoàn toàn vô dụng cho việc quản backlog. Bỏ chúng đi là phần tiết kiệm lớn nhất. */
    const statusSet = opts.scope === "backlog"
      ? BACKLOG_STATUSES.slice()
      : Array.from(new Set([...statusInfo.statuses, ...DEFAULT_STATUSES]));
    if (opts.scope === "backlog") {
      log(`${accountName(sid)}: chế độ Backlog — chỉ kéo ${statusSet.join(", ")} (bỏ delivered/canceled).`, "ok");
    }
    const byCode = new Map(), coverage = [];
    if (statusInfo.countsError) coverage.push({
      seller_id: String(sid), account_name: accountName(sid), status: "@counts",
      expected: null, pulled: null, delta: null, pages_pulled: 0,
      truncated: false, error: statusInfo.countsError, complete: false
    });

    for (const status of statusSet) {
      let page = 1, pagesPulled = 0, truncated = false, error = "";
      const statusCodes = new Set();
      const countObj = statusInfo.counts && statusInfo.counts[status];
      const expectedRaw = countObj && typeof countObj === "object"
        ? (countObj.total_order ?? countObj.total ?? countObj.count)
        : countObj;
      const expectedNumber = expectedRaw == null || expectedRaw === "" ? null : Number(expectedRaw);
      const expected = expectedNumber != null && Number.isFinite(expectedNumber) ? expectedNumber : null;
      try {
        /* v2.4.1 — trang 1 để biết tổng số trang, phần còn lại kéo SONG SONG.
           Trước đây mỗi trang phải chờ trang trước xong + nghỉ 60ms, nên thời
           gian tỉ lệ thẳng với số trang. */
        const absorb = batch => {
          batch.forEach(o => {
            const code = text(pick(o, ["order_code", "code", "order_id", "id"], ""));
            if (!code) return;
            statusCodes.add(code);
            const old = byCode.get(code);
            byCode.set(code, old ? { ...old, ...o } : o);
          });
          STATE.counters.listed += batch.length;
        };

        const firstJson = await fetchJson(orderListUrl(sid, status, 1, opts), token);
        const firstBatch = unwrapRecords(firstJson); pagesPulled++;
        absorb(firstBatch);
        const pg0 = pagingOf(firstJson);
        const totalPage = Number(pg0.total_page || pg0.total_pages || 0);
        log(`${accountName(sid)} · ${status} · trang 1${totalPage ? `/${totalPage}` : ""} · ${nfmt(firstBatch.length)} dòng`);

        let lastPage = totalPage > 0
          ? totalPage
          : (firstBatch.length >= opts.perPage ? opts.maxPages : 1);
        if (lastPage > opts.maxPages) {
          lastPage = opts.maxPages; truncated = true; STATE.counters.errors++;
          log(`${accountName(sid)} · ${status}: chạm Max pages (${opts.maxPages}); tăng giới hạn để lấy tiếp.`, "warn");
        }

        if (lastPage > 1 && totalPage > 0) {
          const conc = Math.max(1, Math.min(10, Number(CFG.api && CFG.api.pageConcurrency) || 5));
          const rest = [];
          for (let p = 2; p <= lastPage; p++) rest.push(p);
          let cursor = 0;
          const workers = Array.from({ length: Math.min(conc, rest.length) }, async () => {
            while (cursor < rest.length) {
              if (STATE.abortController && STATE.abortController.signal.aborted) return;
              const p = rest[cursor++];
              const json = await fetchJson(orderListUrl(sid, status, p, opts), token);
              const b = unwrapRecords(json); pagesPulled++;
              absorb(b);
              if (p % 10 === 0 || p === lastPage) {
                log(`${accountName(sid)} · ${status} · trang ${p}/${lastPage} · ${nfmt(statusCodes.size)} mã đơn`);
              }
            }
          });
          await Promise.all(workers);
        } else if (lastPage > 1) {
          /* API không trả total_page: buộc phải tuần tự, dừng khi gặp trang ngắn. */
          page = 2;
          while (page <= lastPage) {
            const json = await fetchJson(orderListUrl(sid, status, page, opts), token);
            const b = unwrapRecords(json); pagesPulled++;
            absorb(b);
            if (!b.length || b.length < opts.perPage) break;
            page++;
          }
        }
      } catch (e) {
        if (e && (e.name === "AbortError" || e.code === 401 || e.code === 403)) throw e;
        error = e && e.message || String(e); STATE.counters.errors++;
        log(`${accountName(sid)} · ${status}: list lỗi ${error}`, "err");
      }
      const pulled = statusCodes.size;
      const complete = !error && !truncated && (expected == null || pulled === expected);
      coverage.push({
        seller_id: String(sid), account_name: accountName(sid), status,
        expected, pulled, delta: expected == null ? null : pulled - expected,
        pages_pulled: pagesPulled, truncated, error, complete
      });
    }
    return { orders: Array.from(byCode.values()), counts: statusInfo.counts, statuses: statusSet, coverage };
  }

  async function pullUpdatedLane(sid, token, opts) {
    if (opts.mode !== "smart") return { orders: [], coverage: null };
    const byCode = new Map(); let page = 1, pagesPulled = 0, error = "", truncated = false;
    try {
      while (page <= Math.min(opts.maxPages, 500)) {
        const u = new URL(`${API_BASE}/orders`);
        u.searchParams.set("filters.updated_at.from", opts.from);
        u.searchParams.set("filters.updated_at.to", opts.to);
        u.searchParams.set("filters.seller_id", sid);
        u.searchParams.set("seller_id", sid);
        u.searchParams.set("page.page_number", page);
        u.searchParams.set("page.per_page", opts.perPage);
        u.searchParams.set("sort_by", "updated_at|desc");
        const json = await fetchJson(u.toString(), token, { retries: 1 });
        const batch = unwrapRecords(json); pagesPulled++;
        STATE.counters.listed += batch.length;
        batch.forEach(o => {
          const code = text(pick(o, ["order_code", "code", "order_id", "id"], ""));
          if (code) byCode.set(code, o);
        });
        const pg = pagingOf(json), totalPage = Number(pg.total_page || pg.total_pages || 0);
        if (page >= Math.min(opts.maxPages, 500) && (totalPage ? page < totalPage : batch.length >= opts.perPage)) truncated = true;
        if (!batch.length || (totalPage ? page >= totalPage : batch.length < opts.perPage)) break;
        page++;
        const delay = Number(CFG.api && CFG.api.pageDelayMs);
        if (delay > 0) await sleep(delay);
      }
      log(`${accountName(sid)} · updated_at lane: ${nfmt(byCode.size)} đơn thay đổi.`);
    } catch (e) {
      if (e && (e.name === "AbortError" || e.code === 401 || e.code === 403)) throw e;
      error = e && e.message || String(e);
      log(`${accountName(sid)}: API chưa hỗ trợ updated_at lane (${error}); tracked-open refresh vẫn tiếp tục.`, "warn");
    }
    return {
      orders: Array.from(byCode.values()),
      coverage: { seller_id: String(sid), account_name: accountName(sid), status: "@updated_at_lane", expected: null, pulled: byCode.size, delta: null, pages_pulled: pagesPulled, truncated, error, complete: !error && !truncated }
    };
  }

  async function runPool(items, concurrency, worker) {
    let cursor = 0;
    const workers = Array.from({ length: Math.min(concurrency, Math.max(1, items.length)) }, async () => {
      while (cursor < items.length) {
        if (STATE.abortController && STATE.abortController.signal.aborted) throw new DOMException("Đã dừng", "AbortError");
        const index = cursor++;
        await worker(items[index], index);
      }
    });
    await Promise.all(workers);
  }

  function cleanListOrder(order) {
    if (!order || !order.__force_detail) return order;
    const clean = { ...order }; delete clean.__force_detail; return clean;
  }

  const DETAIL_RESERVED_SEGMENTS = new Set(["counts", "count", "search", "export", "exports", "batch", "summary", "statistics"]);

  function detailRouteFailureKey(sellerId) { return `detail_route|${sellerId}`; }

  function detailIdentifiers(order) {
    const values = [
      { kind: "order_code", value: text(pick(order, ["order_code", "code"], "")) },
      { kind: "internal_id", value: text(pick(order, ["id", "internal_id", "order_id"], "")) }
    ];
    const seen = new Set();
    return values.filter(x => x.value && !seen.has(x.value) && seen.add(x.value));
  }

  function observedDetailRecords(catalog) {
    return (catalog || []).filter(rec => {
      if (!rec || !["GET", "POST"].includes(rec.method) || !rec.url) return false;
      try { if (new URL(rec.url).hostname !== new URL(API_BASE).hostname) return false; }
      catch (_) { return false; }
      if (/(cancel|create|update|delete|submit|confirm|approve|reject|dispatch|handover|upload|import|mutation|action)/i.test(rec.pathKey || rec.url)) return false;
      if (rec.method === "POST" && rec.kind !== "detail") return false;
      const schemaHint = [...(rec.schemaPaths || []), ...(rec.responseKeys || [])].join(" ");
      return rec.kind === "detail"
        || /\/orders\/:(?:order_code|order_id|id)(?:\/|$)/i.test(rec.pathKey || "")
        || (/\/(?:orders?|order-details?)\//i.test(rec.pathKey || "")
          && /:(?:order_code|order_id|id)(?:\/|$)/i.test(rec.pathKey || "")
          && /(order_code|ref_code|histories|timeline|order_status)/i.test(schemaHint))
        || /\/orders\/(?!counts(?:\/|$)|search(?:\/|$)|export(?:\/|$))[^/]+\/(?:detail|view|history|timeline|events)(?:\/|$)/i.test(rec.pathKey || "")
        || (/\/orders\/(?:detail|view)(?:\/|$)/i.test(rec.pathKey || "") && /(?:order_code|order_id|\bid)=/i.test(rec.url));
    }).sort((a, b) => Number(b.lastSeenAt || b.at || 0) - Number(a.lastSeenAt || a.at || 0)).slice(0, 5);
  }

  function observedMediaRecords(catalog) {
    return (catalog || []).filter(rec => {
      if (!rec || !["GET", "POST"].includes(rec.method) || !rec.url) return false;
      try { if (new URL(rec.url).hostname !== new URL(API_BASE).hostname) return false; }
      catch (_) { return false; }
      const route = text(rec.pathKey || rec.url);
      if (/(?:cancel|create|update|delete|submit|confirm|approve|reject|dispatch|handover|upload|import|mutation|action)(?:\/|$)/i.test(route)) return false;
      const hints = `${route} ${rec.title || ""} ${(rec.schemaPaths || []).join(" ")} ${(rec.responseKeys || []).join(" ")}`;
      const strongMedia = /(?:video(?:_url|s)?|packing.?video|unbox(?:ing)?.?video|unpack.?video|open.?box|media|attachment|evidence|proof|recording|camera|khui|dong.?goi)/i.test(hints);
      if (rec.kind !== "media" && !strongMedia) return false;
      if (rec.method === "POST" && rec.kind !== "media") return false;
      if (rec.method === "POST" && !/(?:query|search|list|detail|view|media|video|evidence|proof|playback|download|url)/i.test(route)) return false;
      return true;
    }).sort((a, b) => Number(b.lastSeenAt || b.at || 0) - Number(a.lastSeenAt || a.at || 0)).slice(0, 6);
  }

  function detailBodyForIdentifier(raw, identifier, sid) {
    if (!raw) return { body: raw || "", changed: false };
    try {
      const parsed = JSON.parse(raw);
      let changed = false;
      function walk(v, depth) {
        if (!v || typeof v !== "object" || depth > 8) return;
        if (Array.isArray(v)) { v.forEach(x => walk(x, depth + 1)); return; }
        Object.keys(v).forEach(key => {
          const normalized = key.replace(/[^a-z0-9]/gi, "").toLowerCase();
          if (["ordercode", "orderid"].includes(normalized) || (normalized === "id" && depth <= 1)) {
            v[key] = identifier; changed = true;
          } else if (["sellerid", "merchantid"].includes(normalized)) {
            v[key] = sid;
          } else walk(v[key], depth + 1);
        });
      }
      walk(parsed, 0);
      return { body: JSON.stringify(parsed), changed };
    } catch (_) {
      try {
        const params = new URLSearchParams(raw); let changed = false;
        for (const key of ["order_code", "orderCode", "order_id", "orderId", "id"]) {
          if (params.has(key)) { params.set(key, identifier); changed = true; }
        }
        for (const key of ["seller_id", "sellerId", "merchant_id", "merchantId"]) if (params.has(key)) params.set(key, sid);
        return { body: params.toString(), changed };
      } catch (_) { return { body: raw, changed: false }; }
    }
  }

  function observedDetailRequest(rec, identifier, sid) {
    let u;
    try { u = new URL(rec.url); } catch (_) { return null; }
    const actual = u.pathname.split("/");
    const template = text(rec.pathKey || u.pathname).split("?")[0].split("/");
    let changed = false;
    for (let i = 0; i < Math.min(actual.length, template.length); i++) {
      if (/^:(?:order_code|order_id|id|code)$/i.test(template[i])) {
        actual[i] = encodeURIComponent(identifier);
        changed = true;
      }
    }
    if (!changed) {
      const orderIndex = actual.findIndex(x => x.toLowerCase() === "orders");
      const current = orderIndex >= 0 ? text(actual[orderIndex + 1]).toLowerCase() : "";
      if (orderIndex >= 0 && current && !DETAIL_RESERVED_SEGMENTS.has(current)) {
        actual[orderIndex + 1] = encodeURIComponent(identifier);
        changed = true;
      }
    }
    const queryKey = ["order_code", "order_id", "id", "code"].find(k => u.searchParams.has(k));
    if (queryKey) { u.searchParams.set(queryKey, identifier); changed = true; }
    const bodyMeta = detailBodyForIdentifier(rec.requestBody || "", identifier, sid);
    changed = changed || bodyMeta.changed;
    if (!changed) return null;
    u.pathname = actual.join("/");
    if (u.searchParams.has("filters.seller_id")) u.searchParams.set("filters.seller_id", sid);
    u.searchParams.set("seller_id", sid);
    return {
      url: u.toString(),
      method: rec.method || "GET",
      body: rec.method === "POST" ? bodyMeta.body : undefined,
      headers: rec.requestContentType ? { "Content-Type": rec.requestContentType } : undefined
    };
  }

  function mediaIdentity(order, sid) {
    const source = order || {};
    const unique = values => Array.from(new Set(values.map(text).filter(Boolean))).slice(0, 4);
    const collections = paths => paths.flatMap(path => {
      const value = pick(source, [path], []);
      return Array.isArray(value) ? value : value && typeof value === "object" ? [value] : [];
    });
    const idsFrom = (rows, keys) => unique(rows.flatMap(row => keys.map(key => pick(row, [key], ""))));
    const packages = collections(["packages", "delivery.packages", "fulfillment.packages"]);
    const shipments = collections(["shipments", "delivery.shipments", "fulfillment.shipments"]);
    const parcels = collections(["parcels", "delivery.parcels", "fulfillment.parcels"]);
    return {
      seller_id: String(sid),
      order_code: text(pick(source, ["order_code", "code"], "")),
      internal_id: text(pick(source, ["id", "internal_id", "order_id", "fulfillment_order_id"], "")),
      ref_code: text(pick(source, ["ref_code", "partner_order_code", "marketplace_order_code"], "")),
      tracking_no: text(pick(source, ["tracking_no", "tracking_code", "delivery.tracking.tracking_code", "delivery.tracking.code", "delivery.tracking.awb", "shipment.tracking_code"], "")),
      partner_tracking_id: text(pick(source, ["partner_tracking_id", "delivery.tracking.partner_tracking_id", "delivery.tracking.id"], "")),
      package_ids: idsFrom(packages, ["id", "package_id", "code", "package_code"]),
      shipment_ids: unique([
        pick(source, ["shipment_id", "shipment.id", "delivery.shipment_id"], ""),
        ...idsFrom(shipments, ["id", "shipment_id", "code", "tracking_code"])
      ]),
      parcel_ids: idsFrom(parcels, ["id", "parcel_id", "code", "tracking_code"])
    };
  }

  function mediaIdentityVariants(order, sid, rec) {
    const base = mediaIdentity(order, sid);
    const hint = stripVN(`${rec.pathKey || rec.url} ${rec.requestBody || ""}`);
    const target = /(?:package[_-]?id|\/packages?\/|:package)/i.test(hint) ? "package"
      : /(?:shipment[_-]?id|\/shipments?\/|:shipment)/i.test(hint) ? "shipment"
      : /(?:parcel[_-]?id|\/parcels?\/|:parcel)/i.test(hint) ? "parcel" : "order";
    const values = target === "package" ? base.package_ids : target === "shipment" ? base.shipment_ids : target === "parcel" ? base.parcel_ids : [];
    if (!values.length) return [{ ...base, variant_kind: target, variant_value: base.order_code || base.internal_id }];
    return values.map(value => ({ ...base, [`${target}_id`]: value, variant_kind: `${target}_id`, variant_value: value }));
  }

  function mediaFieldValue(field, identity, previousSegment) {
    let key = text(field).replace(/^:/, "").replace(/[^a-z0-9]/gi, "").toLowerCase();
    key = key.replace(/^filters?/, "");
    const previous = text(previousSegment).replace(/[^a-z0-9]/gi, "").toLowerCase();
    if (["sellerid", "merchantid"].includes(key)) return identity.seller_id;
    if (["ordercode", "code"].includes(key) && !["packages", "shipments", "parcels"].includes(previous)) return identity.order_code;
    if (["orderid", "fulfillmentorderid"].includes(key)) return identity.internal_id || identity.order_code;
    if (["refcode", "partnerordercode", "marketplaceordercode"].includes(key)) return identity.ref_code;
    if (["trackingcode", "trackingno", "trackingnumber", "awb"].includes(key)) return identity.tracking_no;
    if (["partnertrackingid"].includes(key)) return identity.partner_tracking_id || identity.tracking_no;
    if (["packageid", "packagecode"].includes(key)) return identity.package_id || identity.package_ids[0] || "";
    if (["shipmentid", "shipmentcode"].includes(key)) return identity.shipment_id || identity.shipment_ids[0] || "";
    if (["parcelid", "parcelcode"].includes(key)) return identity.parcel_id || identity.parcel_ids[0] || "";
    if (key === "id") {
      if (/packages?/.test(previous)) return identity.package_id || identity.package_ids[0] || "";
      if (/shipments?/.test(previous)) return identity.shipment_id || identity.shipment_ids[0] || "";
      if (/parcels?/.test(previous)) return identity.parcel_id || identity.parcel_ids[0] || "";
      return identity.internal_id || identity.order_code;
    }
    return "";
  }

  function mediaBodyForIdentity(raw, identity) {
    if (!raw) return { body: "", changed: false };
    try {
      const parsed = JSON.parse(raw); let changed = false;
      function walk(value, depth, parentKey) {
        if (!value || typeof value !== "object" || depth > 8) return;
        if (Array.isArray(value)) { value.forEach(x => walk(x, depth + 1, parentKey)); return; }
        Object.keys(value).forEach(key => {
          const replacement = mediaFieldValue(key, identity, parentKey || "");
          if (replacement && !/(?:seller|merchant)/i.test(key)) { value[key] = replacement; changed = true; }
          else if (replacement) value[key] = replacement;
          else walk(value[key], depth + 1, key);
        });
      }
      walk(parsed, 0, "");
      return { body: JSON.stringify(parsed), changed };
    } catch (_) {
      try {
        const params = new URLSearchParams(raw); let changed = false;
        for (const key of Array.from(params.keys())) {
          const replacement = mediaFieldValue(key, identity, "");
          if (!replacement) continue;
          params.set(key, replacement);
          if (!/(?:seller|merchant)/i.test(key)) changed = true;
        }
        return { body: params.toString(), changed };
      } catch (_) { return { body: raw, changed: false }; }
    }
  }

  function observedMediaRequest(rec, identity) {
    let u;
    try { u = new URL(rec.url); } catch (_) { return null; }
    const actual = u.pathname.split("/");
    const template = text(rec.pathKey || u.pathname).split("?")[0].split("/");
    let changed = false;
    for (let i = 0; i < Math.min(actual.length, template.length); i++) {
      if (!/^:[a-z0-9_-]+$/i.test(template[i])) continue;
      const replacement = mediaFieldValue(template[i], identity, template[i - 1] || actual[i - 1]);
      if (replacement) { actual[i] = encodeURIComponent(replacement); changed = true; }
    }
    if (!changed) {
      for (const [container, value] of [["orders", identity.order_code || identity.internal_id], ["packages", identity.package_id], ["shipments", identity.shipment_id], ["parcels", identity.parcel_id]]) {
        const index = actual.findIndex(x => x.toLowerCase() === container);
        const current = index >= 0 ? text(actual[index + 1]).toLowerCase() : "";
        if (index >= 0 && current && value && !DETAIL_RESERVED_SEGMENTS.has(current)) {
          actual[index + 1] = encodeURIComponent(value); changed = true; break;
        }
      }
    }
    for (const key of Array.from(u.searchParams.keys())) {
      const replacement = mediaFieldValue(key, identity, "");
      if (!replacement) continue;
      u.searchParams.set(key, replacement);
      if (!/(?:seller|merchant)/i.test(key)) changed = true;
    }
    const bodyMeta = mediaBodyForIdentity(rec.requestBody || "", identity);
    changed = changed || bodyMeta.changed;
    if (!changed) return null;
    u.pathname = actual.join("/");
    if (u.searchParams.has("filters.seller_id")) u.searchParams.set("filters.seller_id", identity.seller_id);
    u.searchParams.set("seller_id", identity.seller_id);
    return {
      url: u.toString(), method: rec.method || "GET",
      body: rec.method === "POST" ? bodyMeta.body : undefined,
      headers: rec.requestContentType ? { "Content-Type": rec.requestContentType } : undefined
    };
  }

  function mediaCandidates(order, sid, catalog, routeState) {
    const out = [];
    for (const rec of observedMediaRecords(catalog)) {
      for (const identity of mediaIdentityVariants(order, sid, rec)) {
        const request = observedMediaRequest(rec, identity);
        if (!request) continue;
        const templateKey = `media|${rec.key || rec.pathKey}`;
        const variant = `${identity.variant_kind || "order"}:${identity.variant_value || identity.order_code || "id"}`;
        out.push({
          key: `${templateKey}|${variant}`,
          instanceKey: `${templateKey}|${variant}`,
          templateKey,
          label: `${rec.method} ${rec.pathKey || rec.url} · ${variant}`,
          categoryHint: videoCategory(`${rec.pathKey || rec.url} ${(rec.schemaPaths || []).join(" ")}`),
          ...request
        });
      }
    }
    const unique = [], seen = new Set();
    out.forEach(x => {
      const signature = `${x.method || "GET"}|${x.url}|${x.body || ""}`;
      if (!seen.has(signature)) { seen.add(signature); unique.push(x); }
    });
    if (routeState && Array.isArray(routeState.preferredKeys)) {
      const preferred = new Set(routeState.preferredKeys);
      unique.sort((a, b) => Number(preferred.has(b.templateKey)) - Number(preferred.has(a.templateKey)));
    }
    return unique.slice(0, 10);
  }

  async function fetchOrderMedia(order, sid, token, catalog, routeState) {
    routeState = routeState || {};
    routeState.bad = routeState.bad || {};
    routeState.preferredKeys = Array.isArray(routeState.preferredKeys) ? routeState.preferredKeys : [];
    const candidates = mediaCandidates(order, sid, catalog, routeState);
    if (!candidates.length) return { attempted: false, payloads: [], successCount: 0, errorCount: 0, routes: [] };
    const completedInstances = new Set();
    const payloads = [], routes = [];
    let errorCount = 0;
    for (const candidate of candidates) {
      if (completedInstances.has(candidate.instanceKey) || Number(routeState.bad[candidate.templateKey] || 0) >= 3) continue;
      try {
        const payload = await fetchJson(candidate.url, token, {
          retries: 0,
          method: candidate.method || "GET",
          body: candidate.body,
          headers: candidate.headers
        });
        if (payload == null || typeof payload !== "object") {
          const e = new Error("Media endpoint không trả JSON object");
          e.code = "INVALID_MEDIA_SHAPE"; throw e;
        }
        completedInstances.add(candidate.instanceKey);
        if (!routeState.preferredKeys.includes(candidate.templateKey)) routeState.preferredKeys.push(candidate.templateKey);
        payloads.push({
          source: "media_api",
          endpoint: candidate.label,
          request_url: candidate.url,
          category_hint: candidate.categoryHint,
          captured_at: nowIso(),
          payload
        });
        routes.push(candidate.label);
      } catch (e) {
        if (e && e.name === "AbortError") throw e;
        routeState.bad[candidate.templateKey] = Number(routeState.bad[candidate.templateKey] || 0) + 1;
        errorCount++;
      }
    }
    return { attempted: true, payloads, successCount: payloads.length, errorCount, routes };
  }

  function mergeMediaPayloads(previous, fresh) {
    const oldRows = Array.isArray(previous) ? previous : [];
    const newRows = Array.isArray(fresh) ? fresh : [];
    if (!newRows.length) return oldRows;
    const replaced = new Set(newRows.map(x => text(x && x.endpoint)).filter(Boolean));
    return [...oldRows.filter(x => !replaced.has(text(x && x.endpoint))), ...newRows].slice(-12);
  }

  function detailCandidates(order, sid, catalog, routeState) {
    const out = [];
    const ids = detailIdentifiers(order);
    for (const rec of observedDetailRecords(catalog)) {
      for (const id of ids) {
        const request = observedDetailRequest(rec, id.value, sid);
        if (request) out.push({
          key: `observed|${rec.key || rec.pathKey}|${id.kind}`,
          label: `observed ${rec.method} ${rec.pathKey || rec.url} · ${id.kind}`,
          ...request
        });
      }
    }
    for (const id of ids) {
      out.push({
        key: `default|${id.kind}`,
        label: `default /orders/:identifier · ${id.kind}`,
        url: `${API_BASE}/orders/${encodeURIComponent(id.value)}?seller_id=${encodeURIComponent(sid)}`,
        method: "GET"
      });
    }
    const unique = [], seen = new Set();
    out.forEach(x => {
      const signature = `${x.method || "GET"}|${x.url}|${x.body || ""}`;
      if (!seen.has(signature)) { seen.add(signature); unique.push(x); }
    });
    if (routeState && routeState.preferredKey) unique.sort((a, b) => Number(b.key === routeState.preferredKey) - Number(a.key === routeState.preferredKey));
    return unique.slice(0, 12);
  }

  function detailShapeOk(detail) {
    if (!detail || typeof detail !== "object" || Array.isArray(detail)) return false;
    return !!(pick(detail, ["order_code", "code", "order_id", "id", "status", "sub_status", "created_at"], "")
      || historyArrays(detail).length || itemArrays(detail).length);
  }

  async function fetchOrderDetail(order, sid, token, catalog, routeState) {
    const targetCode = text(pick(order, ["order_code", "code"], ""));
    const candidates = detailCandidates(order, sid, catalog, routeState);
    if (!candidates.length) {
      const e = new Error("Không dựng được detail endpoint từ order/API Catalog");
      e.code = "NO_DETAIL_ROUTE"; e.systemic = true; throw e;
    }
    const errors = [];
    for (const candidate of candidates) {
      try {
        const json = await fetchJson(candidate.url, token, {
          retries: 0,
          method: candidate.method || "GET",
          body: candidate.body,
          headers: candidate.headers
        });
        const detail = unwrapDetail(json);
        if (!detailShapeOk(detail)) {
          const shapeError = new Error("Endpoint không trả order-detail JSON");
          shapeError.code = "INVALID_DETAIL_SHAPE"; shapeError.systemic = true; throw shapeError;
        }
        const actualCode = text(pick(detail, ["order_code", "code"], ""));
        if (targetCode && actualCode && targetCode !== actualCode) {
          const mismatch = new Error(`Detail route trả nhầm order ${actualCode}`);
          mismatch.code = "DETAIL_ORDER_MISMATCH"; mismatch.systemic = true; throw mismatch;
        }
        if (routeState) {
          routeState.preferredKey = candidate.key;
          routeState.preferredLabel = candidate.label;
          routeState.successes = Number(routeState.successes || 0) + 1;
        }
        return { detail, route: candidate };
      } catch (e) {
        if (e && (e.name === "AbortError" || e.code === 401 || e.code === 403)) throw e;
        errors.push({ candidate, error: e });
      }
    }
    const systemic = errors.some(x => x.error && x.error.systemic);
    const sample = errors.find(x => x.error && x.error.systemic) || errors[0];
    const e = new Error(sample && sample.error ? sample.error.message : "Detail endpoint không khả dụng");
    e.code = systemic ? "DETAIL_ROUTE_UNAVAILABLE" : (sample && sample.error && sample.error.code || "DETAIL_FETCH_FAILED");
    e.httpStatus = sample && sample.error && (sample.error.httpStatus || sample.error.code) || "";
    e.systemic = systemic;
    e.candidate_count = candidates.length;
    throw e;
  }

  async function enrichDetails(listRows, sid, token, opts, existingMap, failureMap, apiCatalog, routeState) {
    /* v2.4 — CHẾ ĐỘ BACKLOG: bỏ hẳn bước gọi detail từng đơn.
       Detail là thứ đắt nhất (1 request/đơn) nhưng backlog triage chỉ cần
       mã đơn, tuổi đơn, status/sub_status, kho, ĐVVC — toàn bộ đã có trong list API.
       Journey/timeline chỉ cần khi soi một đơn cụ thể, và Order 360° vẫn tra được
       theo yêu cầu bằng nút "Tra API mã đơn". */
    if (opts.skipDetail) {
      const rows = listRows.map(o => {
        const code = text(pick(o, ["order_code", "code", "order_id", "id"], ""));
        const pk = `${sid}|${code}`;
        const old = existingMap.get(pk);
        const row = normalizeOrder(o, old && old.raw_detail ? old.raw_detail : null, sid, null);
        row.detail_sync_status = old && old.has_detail ? "cached" : "skipped";
        row.has_detail = !!(old && old.has_detail);
        return row;
      }).filter(r => r.order_code);
      log(`${accountName(sid)}: chế độ Backlog — bỏ qua ${nfmt(listRows.length)} lượt gọi detail API.`, "ok");
      return {
        rows,
        routeLabel: "skipped_backlog_mode",
        coverage: {
          seller_id: String(sid), account_name: accountName(sid), status: "@detail",
          expected: 0, pulled: 0, delta: 0, pages_pulled: 0, truncated: false,
          error: "", complete: true, skipped: "backlog_mode"
        },
        mediaCoverage: {
          seller_id: String(sid), account_name: accountName(sid), status: "@media",
          expected: 0, pulled: 0, delta: 0, pages_pulled: 0, truncated: false,
          error: "", complete: true, route_count: 0, orders_attempted: 0, videos_found: 0
        }
      };
    }

    const work = listRows.filter(o => {
      const code = text(pick(o, ["order_code", "code", "order_id", "id"], ""));
      if (!code) return false;
      if (o.__force_detail) return true;
      if (opts.mode === "full") return true;
      const old = existingMap.get(`${sid}|${code}`);
      const updated = text(pick(o, ["updated_at"], ""));
      const status = text(pick(o, ["status"], "")).toLowerCase();
      if (!old || !old.has_detail) return true;
      if (!FINAL_STATUSES.has(status)) return true;
      return updated && updated !== old.source_updated_at;
    });

    let completed = 0, successful = 0, systemicFailures = 0, circuitError = null;
    let mediaAttempted = 0, mediaSuccessful = 0, mediaVideos = 0, mediaErrors = 0;
    routeState = routeState || {};
    routeState.media = routeState.media || {};
    const result = [], failures = [];
    setProgress(0, work.length, `Đang lấy detail ${accountName(sid)}`);

    const processOrder = async order => {
      if (circuitError) return;
      const code = text(pick(order, ["order_code", "code", "order_id", "id"], ""));
      const cleanOrder = cleanListOrder(order);
      const old = existingMap.get(`${sid}|${code}`);
      try {
        const fetched = await fetchOrderDetail(cleanOrder, sid, token, apiCatalog, routeState);
        const detail = fetched.detail;
        const mediaResult = await fetchOrderMedia({ ...cleanOrder, ...detail }, sid, token, apiCatalog, routeState.media);
        if (mediaResult.attempted) mediaAttempted++;
        if (mediaResult.successCount) mediaSuccessful++;
        mediaErrors += mediaResult.errorCount || 0;
        const mediaPayloads = mediaResult.successCount
          ? mergeMediaPayloads(old && old.raw_media, mediaResult.payloads)
          : (old && old.raw_media || []);
        const normalized = normalizeOrder(cleanOrder, detail, sid, mediaPayloads);
        normalized.media_sync_status = !mediaResult.attempted ? (mediaPayloads.length ? "cached" : "not_observed")
          : mediaResult.successCount ? (mediaResult.errorCount ? "partial" : "success")
          : (mediaPayloads.length ? "cached_after_error" : "failed");
        normalized.media_synced_at = mediaResult.successCount ? nowIso() : (old && old.media_synced_at || "");
        normalized.media_routes = mediaResult.routes || [];
        mediaVideos += normalized.video_count || 0;
        result.push(normalized);
        const failureKey = detailFailureKey(sid, code);
        if (failureMap && failureMap.has(failureKey)) STATE.counters.retried = (STATE.counters.retried || 0) + 1;
        STATE.counters.detailed++; successful++; systemicFailures = 0;
      } catch (e) {
        if (e && (e.name === "AbortError" || e.code === 401 || e.code === 403)) throw e;
        STATE.counters.errors++;
        if (e && e.systemic) {
          systemicFailures++;
          if (systemicFailures >= 3 && successful === 0) circuitError = e;
        }
        const partial = normalizeOrder(cleanOrder, null, sid);
        const failedRow = old ? {
          ...old,
          status: partial.status || old.status,
          sub_status: partial.sub_status || old.sub_status,
          updated_at_api: partial.updated_at_api || old.updated_at_api,
          source_updated_at: partial.source_updated_at || old.source_updated_at,
          raw_list: cleanOrder,
          synced_at: partial.synced_at
        } : partial;
        failedRow.detail_sync_status = "failed";
        failedRow.detail_sync_error = e && e.message || String(e);
        failedRow.last_detail_attempt_at = nowIso();
        result.push(failedRow);
        const key = detailFailureKey(sid, code), prev = failureMap && failureMap.get(key);
        const attempts = Number(prev && prev.attempt_count || 0) + 1;
        const failure = {
          pk: key,
          order_pk: `${sid}|${code}`,
          seller_id: String(sid),
          account_name: accountName(sid),
          order_code: code,
          operation: "order_detail",
          state: [400, 404].includes(e && e.code) ? "blocked" : "pending",
          attempt_count: attempts,
          first_failed_at: prev && prev.first_failed_at || nowIso(),
          last_failed_at: nowIso(),
          next_retry_at: new Date(Date.now() + Math.min(3600000, Math.pow(2, attempts) * 30000)).toISOString(),
          http_code: e && e.code || "",
          last_error: e && e.message || String(e),
          systemic: !!(e && e.systemic),
          candidate_count: Number(e && e.candidate_count || 0)
        };
        failures.push(failure); if (failureMap) failureMap.set(key, failure);
        log(`${code}: detail lỗi ${e.message}`, "err");
      } finally {
        completed++;
        if (completed % 5 === 0 || completed === work.length) {
          setProgress(completed, work.length, `Detail ${accountName(sid)}`);
        }
      }
    };

    // Calibration tuần tự: học route đúng bằng tối đa 3 đơn trước khi mở pool.
    // Nếu API trả HTML/gateway đồng loạt, circuit breaker dừng storm ngay tại đây.
    const remaining = work.slice();
    let calibration = 0;
    while (remaining.length && !routeState.preferredKey && calibration < 3 && !circuitError) {
      calibration++;
      await processOrder(remaining.shift());
    }
    if (!circuitError && remaining.length) await runPool(remaining, opts.concurrency, processOrder);

    const routeKey = detailRouteFailureKey(sid);
    if (circuitError) {
      const prev = failureMap && failureMap.get(routeKey);
      const attempts = Number(prev && prev.attempt_count || 0) + 1;
      const routeFailure = {
        pk: routeKey,
        order_pk: "",
        seller_id: String(sid),
        account_name: accountName(sid),
        order_code: "",
        operation: "order_detail_route",
        state: "blocked",
        attempt_count: attempts,
        first_failed_at: prev && prev.first_failed_at || nowIso(),
        last_failed_at: nowIso(),
        next_retry_at: "",
        http_code: circuitError.code || "DETAIL_ROUTE_UNAVAILABLE",
        last_error: circuitError.message,
        action: "Mở TikiNOW Center → mở chi tiết 1 đơn để API Observer học endpoint; kiểm tra đăng nhập/token rồi bấm Retry gaps.",
        systemic: true
      };
      failures.push(routeFailure);
      if (failureMap) failureMap.set(routeKey, routeFailure);
      log(`${accountName(sid)}: CIRCUIT BREAKER đã dừng detail sau ${completed} request lỗi hệ thống. ${routeFailure.action}`, "err");
    } else if (routeState.successes) {
      await deleteRows("sync_failures", [routeKey]);
      if (failureMap) failureMap.delete(routeKey);
      log(`${accountName(sid)}: detail route OK · ${routeState.preferredLabel || "default"}.`, "ok");
    }
    if (failures.length) await bulkPut("sync_failures", failures);

    const fetchedCodes = new Set(result.map(x => x.order_code));
    listRows.forEach(order => {
      const code = text(pick(order, ["order_code", "code", "order_id", "id"], ""));
      if (!code || fetchedCodes.has(code)) return;
      const old = existingMap.get(`${sid}|${code}`);
      if (old) {
        // Giữ raw detail đã có nhưng cập nhật list/status mới nhất.
        result.push({
          ...old,
          ...normalizeOrder(cleanListOrder(order), old.raw_detail, sid, old.raw_media || []),
          raw_detail: old.raw_detail,
          has_detail: true,
          detail_sync_status: "cached",
          detail_sync_error: old.detail_sync_error || "",
          last_detail_attempt_at: old.last_detail_attempt_at || ""
        });
      } else result.push(normalizeOrder(cleanListOrder(order), null, sid, []));
    });
    setProgress(work.length, work.length, `Detail ${accountName(sid)}`);
    const detailErrors = failures.filter(x => x.operation === "order_detail").length;
    return {
      rows: result,
      routeLabel: routeState.preferredLabel || "",
      coverage: {
        seller_id: String(sid), account_name: accountName(sid), status: "@detail",
        expected: work.length, pulled: successful, delta: successful - work.length,
        pages_pulled: 0, truncated: !!circuitError,
        error: circuitError ? circuitError.message : (detailErrors ? `${detailErrors} order detail lỗi` : ""),
        complete: !circuitError && detailErrors === 0 && successful === work.length
      },
      mediaCoverage: {
        seller_id: String(sid), account_name: accountName(sid), status: "@media",
        expected: observedMediaRecords(apiCatalog).length ? work.length : 0,
        pulled: mediaSuccessful,
        delta: observedMediaRecords(apiCatalog).length ? mediaSuccessful - work.length : 0,
        pages_pulled: 0,
        truncated: false,
        error: mediaErrors ? `${mediaErrors} media probe lỗi; link cũ vẫn được giữ` : "",
        complete: !mediaAttempted || mediaSuccessful === mediaAttempted,
        route_count: observedMediaRecords(apiCatalog).length,
        orders_attempted: mediaAttempted,
        videos_found: mediaVideos
      }
    };
  }

  function safeCatalogRead(rec) {
    if (root.UnifiedAnalysis && rec && rec.method !== "GET") return false;
    if (!rec || !rec.url || !["list", "report"].includes(rec.kind)) return false;
    if (/(cancel|create|update|delete|submit|confirm|approve|reject|dispatch|handover|upload|import|mutation|action)/i.test(rec.pathKey || rec.url)) return false;
    if (rec.method === "GET") return true;
    if (rec.method !== "POST") return false;
    return /(report|search|list|query|analytics|count|base-info|export|summary|statistics)/i.test(rec.pathKey || rec.url);
  }

  function postBodyForPage(raw, path, page) {
    if (!raw || !path) return raw || "";
    try {
      const body = JSON.parse(raw);
      const parts = path.split(".");
      let cur = body;
      for (let i = 0; i < parts.length - 1; i++) {
        if (!cur[parts[i]] || typeof cur[parts[i]] !== "object") cur[parts[i]] = {};
        cur = cur[parts[i]];
      }
      cur[parts[parts.length - 1]] = page;
      return JSON.stringify(body);
    } catch (_) { return raw; }
  }

  /* =========================================================================
   * v2.6 — MỌI MỤC TIKINOW CENTER, GỘP THEO NHIỀU ACCOUNT
   *
   * API Observer vốn đã học mọi endpoint của tikinowcenter.tikinow.vn khi bạn
   * mở từng mục (Tồn kho, Thanh toán, Khiếu nại, Hậu mãi, Sản phẩm...).
   * Nhưng replay cũ chỉ chạy bằng ĐÚNG account đã học route đó. Phần dưới đây
   * thay seller_id trong URL/body rồi chạy lại cho TỪNG account đang chọn,
   * nên một lần bấm Nạp là ra dữ liệu gộp của mọi account.
   * ====================================================================== */
  const SELLER_KEYS = ["seller_id", "sellerId", "merchant_id", "merchantId",
                       "filters.seller_id", "filters.sellerId"];

  function sellerizeBody(raw, sid) {
    if (!raw) return undefined;
    try {
      const parsed = JSON.parse(raw);
      const walk = (v, depth) => {
        if (!v || typeof v !== "object" || depth > 6) return;
        if (Array.isArray(v)) { v.forEach(x => walk(x, depth + 1)); return; }
        Object.keys(v).forEach(k => {
          if (SELLER_KEYS.indexOf(k) >= 0 && (typeof v[k] !== "object" || v[k] === null)) v[k] = sid;
          else walk(v[k], depth + 1);
        });
      };
      walk(parsed, 0);
      return JSON.stringify(parsed);
    } catch (_) {
      try {
        const params = new URLSearchParams(raw);
        SELLER_KEYS.forEach(k => { if (params.has(k)) params.set(k, sid); });
        return params.toString();
      } catch (_) { return raw; }
    }
  }

  /* Đổi endpoint đã học sang chạy cho một account khác. */
  function sellerizeRequest(rec, sid) {
    let u;
    try { u = new URL(rec.url); } catch (_) { return null; }
    let touched = false;
    SELLER_KEYS.forEach(k => { if (u.searchParams.has(k)) { u.searchParams.set(k, sid); touched = true; } });
    /* Nhiều endpoint TikiNOW nhận seller_id dạng query dù lần bắt đầu không có. */
    if (!touched) u.searchParams.set("seller_id", sid);
    return {
      url: u.toString(),
      method: rec.method || "GET",
      body: rec.method === "POST" ? sellerizeBody(rec.requestBody || "", sid) : undefined,
      headers: rec.requestContentType ? { "Content-Type": rec.requestContentType } : undefined
    };
  }

  /* Kéo một mục cho TẤT CẢ account đang chọn, lưu tách theo seller_id. */
  async function syncSectionForAllAccounts(recKey, flags) {
    const catalog = await runtimeMessage({ type: "GET_API_CATALOG" }) || [];
    const rec = catalog.find(x => x && x.key === recKey);
    if (!rec) throw new Error("Chưa học endpoint này. Mở mục đó trên TikiNOW Center một lần.");
    if (!safeCatalogRead(rec)) throw new Error("Endpoint này không được phép replay (chỉ GET list/report hoặc POST truy vấn).");

    const tokens = await selectedTokens();
    const sids = Object.keys(tokens);
    if (!sids.length) { const e = new Error("NO_TOKEN"); e.code = "NO_TOKEN"; throw e; }

    const opts = syncOptions("smart", flags || {});
    setSyncUi(true);
    STATE.abortController = new AbortController();
    const perAccount = [];
    let total = 0, index = 0;
    emit("run", { phase: "start", accounts: sids.length, mode: "section" });
    try {
      for (const sid of sids) {
        index++;
        emit("account", { phase: "start", sellerId: sid, name: accountName(sid), index, total: sids.length });
        let rows = 0, err = "";
        try {
          const req = sellerizeRequest(rec, sid);
          if (!req) throw new Error("Không dựng được request cho account này");
          const maxPages = Math.min(opts.maxPages, 200);
          let page = 1;
          while (page <= maxPages) {
            const u = new URL(req.url);
            if (req.method === "GET" && rec.pageParam) u.searchParams.set(rec.pageParam, page);
            const body = req.method === "POST"
              ? postBodyForPage(req.body || "", rec.pageBodyPath, page)
              : undefined;
            const json = await fetchJson(u.toString(), tokens[sid].token, {
              method: req.method, body: body || undefined, headers: req.headers
            });
            const batch = unwrapRecords(json);
            rows += batch.length;
            await bulkPut("resources", [{
              pk: `${rec.key}|${sid}|${page}`,
              resource_key: rec.key, path_key: rec.pathKey, seller_id: sid,
              method: rec.method, kind: rec.kind, page, row_count: batch.length,
              captured_at: nowIso(), raw: json
            }]);
            setProgress(rows, rows, `${sectionLabel(rec)} · ${accountName(sid)}`);
            const pg = pagingOf(json);
            const totalPage = Number(pg.total_page || pg.total_pages || 0);
            const hasPaging = rec.method === "GET" ? !!rec.pageParam : !!rec.pageBodyPath;
            if (rec.kind !== "list" || !hasPaging || !batch.length || (totalPage && page >= totalPage)) break;
            if (!totalPage && rec.perPage && batch.length < rec.perPage) break;
            page++;
          }
          log(`${sectionLabel(rec)} · ${accountName(sid)}: ${nfmt(rows)} dòng.`, "ok");
          emit("account", { phase: "done", sellerId: sid, name: accountName(sid), index, total: sids.length, savedOrders: rows });
        } catch (e) {
          if (e && e.name === "AbortError") throw e;
          err = text(e && e.message).slice(0, 160);
          const relogin = e && (e.code === 401 || e.code === 403);
          await noteAccountHealth(sid, { ok: false, code: e && e.code, message: err, relogin });
          log(`${sectionLabel(rec)} · ${accountName(sid)}: ${relogin ? "TOKEN HẾT HẠN" : "lỗi"} ${err}`, "err");
          emit("account", { phase: "error", sellerId: sid, name: accountName(sid), index, total: sids.length, needsRelogin: !!relogin });
        }
        total += rows;
        perAccount.push({ seller_id: sid, account: accountName(sid), rows, error: err });
      }
    } finally {
      STATE.abortController = null;
      setSyncUi(false);
      emit("run", { phase: "end", status: "success", accounts: sids.length, listed: total });
    }
    return { key: rec.key, rows: total, perAccount };
  }

  /* Tên mục theo menu TikiNOW Center, suy từ path đã chuẩn hoá. */
  const SECTION_RULES = [
    [/\/orders?\/counts/i,                         "Đơn hàng · Thống kê"],
    [/\/orders?\b/i,                               "Đơn hàng"],
    [/return-shipment|\/returns?\b|refund/i,        "Hậu mãi · Hoàn / Trả"],
    [/claim|compensat|complain|khieu|boi-?thuong/i,  "Khiếu nại & Bồi thường"],
    [/inventor|\bstock|ton-?kho|warehouse-?stock/i,  "Tồn kho"],
    [/product|\bsku\b|catalog|item/i,               "Sản phẩm"],
    [/payment|finance|invoice|billing|settle|thanh-?toan/i, "Thanh toán"],
    [/report|analytic|statistic|dashboard|bao-?cao/i, "Báo cáo & Phân tích"],
    [/user|account|role|permission|nguoi-?dung/i,     "Quản lý nhóm người dùng"],
    [/media|video|image|photo/i,                      "Media / Video"]
  ];
  function sectionLabel(rec) {
    const path = text(rec && rec.pathKey);
    const hit = SECTION_RULES.find(([re]) => re.test(path));
    if (hit) return hit[1];
    const title = text(rec && rec.title).replace(/\s*[-–|]\s*TikiNOW Center\s*$/i, "").trim();
    return title || "Khác";
  }

  /* Danh mục mọi mục đã học + tình trạng dữ liệu theo account. */
  async function listSections() {
    const [catalog, resources, tokens] = await Promise.all([
      runtimeMessage({ type: "GET_API_CATALOG" }), getAll("resources"), selectedTokens()
    ]);
    const cat = (catalog || []).filter(safeCatalogRead);
    const bySection = new Map();
    const stats = new Map();
    resources.forEach(r => {
      const k = r.resource_key;
      if (!stats.has(k)) stats.set(k, { rows: 0, accounts: new Set(), at: "" });
      const st = stats.get(k);
      st.rows += Number(r.row_count || 0);
      if (r.seller_id) st.accounts.add(String(r.seller_id));
      if (!st.at || text(r.captured_at) > st.at) st.at = text(r.captured_at);
    });
    cat.forEach(rec => {
      const label = sectionLabel(rec);
      if (!bySection.has(label)) bySection.set(label, []);
      const st = stats.get(rec.key) || { rows: 0, accounts: new Set(), at: "" };
      bySection.get(label).push({
        key: rec.key, method: rec.method, pathKey: rec.pathKey, kind: rec.kind,
        title: text(rec.title).replace(/\s*[-–|]\s*TikiNOW Center\s*$/i, "").trim(),
        hits: rec.hits || 0, learnedOn: String(rec.sellerId || ""),
        rows: st.rows, accounts: Array.from(st.accounts), capturedAt: st.at
      });
    });
    return {
      sections: Array.from(bySection.entries())
        .map(([label, items]) => ({ label, items: items.sort((a, b) => b.hits - a.hits) }))
        .sort((a, b) => a.label.localeCompare(b.label, "vi")),
      accountCount: Object.keys(tokens).length,
      accounts: Object.keys(tokens).map(sid => ({ sellerId: sid, name: accountName(sid) }))
    };
  }

  /* Dữ liệu gộp của một mục, có cột Account. */
  async function sectionRows(recKey) {
    const resources = (await getAll("resources")).filter(r => r.resource_key === recKey);
    const out = [];
    resources.sort((a, b) => (a.seller_id + "").localeCompare(b.seller_id + "") || (a.page - b.page));
    resources.forEach(r => {
      const recs = unwrapRecords(r.raw);
      const base = { Account: accountName(r.seller_id), SellerID: r.seller_id, Trang: r.page };
      if (recs.length) recs.forEach(x => out.push({ ...base, ...flattenRaw(x) }));
      else out.push({ ...base, ...flattenRaw(r.raw) });
    });
    return out;
  }

  async function syncOneCatalogEndpoint(rec, tokens, opts) {
    if (!safeCatalogRead(rec)) return { skipped: true, rows: 0 };
    if (/\/fulfillment\/1\.0\/orders(?:\/counts)?$/i.test(rec.pathKey || "")) return { skipped: true, rows: 0 };
    const sid = String(rec.sellerId || (() => { try { return new URL(rec.url).searchParams.get("seller_id") || ""; } catch (_) { return ""; } })());
    const tokenRec = tokens[sid] || Object.values(tokens)[0];
    if (!tokenRec || !tokenRec.token) return { skipped: true, rows: 0 };
    const maxPages = Math.min(opts.maxPages, 500);
    let page = 1, rowsTotal = 0;
    while (page <= maxPages) {
      const u = new URL(rec.url);
      if (rec.method === "GET" && rec.pageParam) u.searchParams.set(rec.pageParam, page);
      const requestBody = rec.method === "POST"
        ? postBodyForPage(rec.requestBody || "", rec.pageBodyPath, page)
        : undefined;
      const json = await fetchJson(u.toString(), tokenRec.token, {
        method: rec.method,
        body: requestBody || undefined,
        headers: rec.requestContentType ? { "Content-Type": rec.requestContentType } : undefined
      });
      const rows = unwrapRecords(json);
      rowsTotal += rows.length;
      await bulkPut("resources", [{
        pk: `${rec.key}|${sid || "default"}|${page}`,
        resource_key: rec.key,
        path_key: rec.pathKey,
        seller_id: sid,
        method: rec.method,
        kind: rec.kind,
        page,
        row_count: rows.length,
        captured_at: nowIso(),
        raw: json
      }]);
      const pg = pagingOf(json);
      const totalPage = Number(pg.total_page || pg.total_pages || rec.totalPage || 0);
      const hasPagingControl = rec.method === "GET" ? !!rec.pageParam : !!rec.pageBodyPath;
      if (rec.kind !== "list" || !hasPagingControl || !rows.length || (totalPage && page >= totalPage)) break;
      if (!totalPage && rec.perPage && rows.length < rec.perPage) break;
      page++;
      await sleep(80);
    }
    return { skipped: false, rows: rowsTotal };
  }

  async function syncCatalog(tokens, opts) {
    const catalog = await runtimeMessage({ type: "GET_API_CATALOG" }) || [];
    const safe = catalog.filter(safeCatalogRead);
    let done = 0, totalRows = 0;
    log(`API catalog: ${safe.length}/${catalog.length} endpoint read-only đủ điều kiện đồng bộ.`);
    for (const rec of safe) {
      if (STATE.abortController && STATE.abortController.signal.aborted) throw new DOMException("Đã dừng", "AbortError");
      try {
        const r = await syncOneCatalogEndpoint(rec, tokens, opts);
        totalRows += r.rows || 0;
        log(`${rec.key}: ${r.skipped ? "bỏ qua (đã có collector riêng)" : `${nfmt(r.rows)} dòng`}`);
      } catch (e) {
        if (e && e.name === "AbortError") throw e;
        STATE.counters.errors++;
        log(`${rec.key}: ${e.message}`, "err");
      }
      done++;
      setProgress(done, safe.length, "Đồng bộ API catalog");
    }
    return { endpointCount: safe.length, rows: totalRows };
  }

  function storedOrderAsList(o, force) {
    const raw = o && o.raw_list && typeof o.raw_list === "object" ? { ...o.raw_list } : {
      order_code: o.order_code, ref_code: o.ref_code, status: o.status, sub_status: o.sub_status,
      created_at: o.created_at_api, updated_at: o.updated_at_api, fulfillment_type: o.fulfillment_type,
      warehouse: o.warehouse, extra: { delivery_partner: o.carrier, platform: o.platform, channel: o.channel }
    };
    if (force) raw.__force_detail = true;
    return raw;
  }

  function mergeSmartClosure(pulledOrders, updatedOrders, existingMap, failureMap, sid, opts) {
    const byCode = new Map();
    [...(pulledOrders || []), ...(updatedOrders || [])].forEach(o => {
      const code = text(pick(o, ["order_code", "code", "order_id", "id"], ""));
      if (!code) return;
      const old = byCode.get(code); byCode.set(code, old ? { ...old, ...o } : o);
    });
    if (opts.mode !== "smart") return Array.from(byCode.values());
    const watchCutoff = Date.now() - Math.min(45, Math.max(7, opts.days || 30)) * 86400000;
    let trackedOpen = 0, lifecycleWatch = 0, retryAdded = 0;
    for (const old of existingMap.values()) {
      if (String(old.seller_id) !== String(sid) || !old.order_code) continue;
      const final = FINAL_STATUSES.has(text(old.status).toLowerCase());
      const updatedAt = parseApiTime(old.updated_at_api || old.source_updated_at);
      const watchFinal = text(old.status).toLowerCase() === "delivered" && updatedAt && updatedAt.getTime() >= watchCutoff;
      if (!final || watchFinal) {
        if (!byCode.has(old.order_code)) byCode.set(old.order_code, storedOrderAsList(old, true));
        else if (watchFinal) byCode.get(old.order_code).__force_detail = true;
        if (!final) trackedOpen++; else lifecycleWatch++;
      }
    }
    for (const failure of failureMap.values()) {
      if (String(failure.seller_id) !== String(sid) || !failure.order_code) continue;
      const due = !failure.next_retry_at || Date.parse(failure.next_retry_at) <= Date.now();
      const retryable = failure.state === "pending" && (opts.forceRetries || due);
      const forceBlocked = opts.forceRetries && failure.state === "blocked";
      if (!retryable && !forceBlocked) continue;
      const old = existingMap.get(`${sid}|${failure.order_code}`);
      const base = old ? storedOrderAsList(old, true) : { order_code: failure.order_code, __force_detail: true };
      byCode.set(failure.order_code, { ...(byCode.get(failure.order_code) || {}), ...base, __force_detail: true });
      retryAdded++;
    }
    log(`${accountName(sid)} · closure: refresh ${trackedOpen} đơn mở cũ, watch ${lifecycleWatch} delivered, retry ${retryAdded} lỗi.`);
    return Array.from(byCode.values());
  }

  async function syncAll(mode, flags) {
    if (root.UnifiedAnalysis) { await root.UnifiedAnalysis.sync(); return refreshHub(); }
    if (STATE.syncing) return;
    const opts = syncOptions(mode, flags);
    const tokens = await selectedTokens();
    const sellerIds = Object.keys(tokens);
    if (!sellerIds.length) {
      /* v2.3.3: KHÔNG dùng alert() ở đây. Auto-sync chạy nền, một hộp thoại chặn
         sẽ treo cả UI và làm thanh trạng thái kẹt ở "Đang chạy…" vô thời hạn. */
      log("Chưa có token. Mở TikiNOW Center, đăng nhập rồi switch từng account cần đồng bộ.", "err");
      emit("run", { phase: "end", status: "no_token", accounts: 0, orders: 0 });
      const e = new Error("NO_TOKEN");
      e.code = "NO_TOKEN";
      throw e;
    }

    setSyncUi(true);
    STATE.abortController = new AbortController();
    STATE.counters = { listed: 0, detailed: 0, errors: 0, changed: 0, retried: 0 };
    if ($("dhLog")) $("dhLog").innerHTML = "";
    const run = {
      id: crypto.randomUUID(),
      mode,
      trigger: opts.forceRetries ? "retry_gaps" : mode,
      started_at: nowIso(),
      finished_at: "",
      status: "running",
      from: opts.from,
      to: opts.to,
      seller_ids: sellerIds,
      listed: 0,
      detailed: 0,
      errors: 0,
      retried: 0,
      catalog_rows: 0,
      changed_orders: 0,
      coverage: [],
      account_summaries: []
    };
    await bulkPut("sync_runs", [run]);

    try {
      const [existing, existingFailures, apiCatalog] = await Promise.all([
        getAll("orders"), getAll("sync_failures"), runtimeMessage({ type: "GET_API_CATALOG" })
      ]);
      const existingMap = new Map(existing.map(o => [o.pk, o]));
      const failureMap = new Map(existingFailures.map(f => [f.pk, f]));
      log(`${mode === "full" ? "FULL HISTORY" : "SMART SYNC"}: ${sellerIds.length} account · ${opts.from} → ${opts.to}`);
      emit("run", { phase: "start", accounts: sellerIds.length, mode });
      let accIndex = 0;
      for (const sid of sellerIds) {
        accIndex++;
        try {
        emit("account", { phase: "start", sellerId: String(sid), name: accountName(sid),
                          index: accIndex, total: sellerIds.length });
        log(`Bắt đầu account ${accountName(sid)} (${sid})`, "ok");
        const pulled = await pullAllOrdersForSeller(sid, tokens[sid].token, opts);
        const updatedLane = await pullUpdatedLane(sid, tokens[sid].token, opts);
        const closureOrders = mergeSmartClosure(pulled.orders, updatedLane.orders, existingMap, failureMap, sid, opts);
        run.coverage.push(...pulled.coverage, ...(updatedLane.coverage ? [updatedLane.coverage] : []));
        log(`${accountName(sid)}: ${nfmt(closureOrders.length)} đơn trong closure · ${pulled.statuses.length} status API.`, "ok");
        const beforeChanged = STATE.counters.changed;
        const routeState = {};
        const enriched = await enrichDetails(closureOrders, sid, tokens[sid].token, opts, existingMap, failureMap, apiCatalog || [], routeState);
        const rows = enriched.rows;
        run.coverage.push(enriched.coverage, enriched.mediaCoverage);
        await persistOrders(rows, existingMap, failureMap);
        run.account_summaries.push({
          seller_id: String(sid), listed_unique: pulled.orders.length, closure_orders: closureOrders.length,
          saved_orders: rows.length, changed_orders: STATE.counters.changed - beforeChanged,
          detail_route: enriched.routeLabel || "unresolved", detail_expected: enriched.coverage.expected,
          detail_pulled: enriched.coverage.pulled, detail_complete: enriched.coverage.complete,
          media_routes: enriched.mediaCoverage.route_count,
          media_orders_pulled: enriched.mediaCoverage.pulled,
          videos_found: enriched.mediaCoverage.videos_found
        });
        run.last_checkpoint = { seller_id: String(sid), finished_at: nowIso() };
        await bulkPut("sync_runs", [run]);
        await putMeta("last_checkpoint", { run_id: run.id, ...run.last_checkpoint });
        log(`${accountName(sid)}: đã lưu ${nfmt(rows.length)} order record + raw detail + timeline.`, "ok");
        if (enriched.mediaCoverage.route_count) {
          log(`${accountName(sid)}: media API ${nfmt(enriched.mediaCoverage.pulled)}/${nfmt(enriched.mediaCoverage.orders_attempted)} đơn · tìm thấy ${nfmt(enriched.mediaCoverage.videos_found)} link video.`, enriched.mediaCoverage.error ? "warn" : "ok");
        } else {
          log(`${accountName(sid)}: chưa học media route — mở 1 video đóng gói + 1 video khui hàng trên TikiNOW rồi Smart Sync lại.`, "warn");
        }
        await noteAccountHealth(sid, { ok: true });
        emit("account", { phase: "done", sellerId: String(sid), name: accountName(sid),
                          index: accIndex, total: sellerIds.length, savedOrders: rows.length });
        } catch (accErr) {
          /* v2.3.2 — CÁCH LY THEO ACCOUNT.
             Trước đây một account token hết hạn (401) làm chết cả run, các account
             sau không bao giờ được sync. Nay lỗi của một account không lan sang account khác. */
          if (accErr && accErr.name === "AbortError") throw accErr;
          const code = accErr && accErr.code;
          const relogin = code === 401 || code === 403;
          run.status = "partial";
          run.account_errors = run.account_errors || [];
          run.account_errors.push({
            seller_id: String(sid), code: code || "", message: text(accErr && accErr.message).slice(0, 200),
            needs_relogin: relogin, at: nowIso()
          });
          await noteAccountHealth(sid, { ok: false, code, message: accErr && accErr.message, relogin });
          log(relogin
            ? `${accountName(sid)}: TOKEN HẾT HẠN (HTTP ${code}). Mở TikiNOW Center và switch sang account này một lần để lấy token mới. Các account khác vẫn chạy tiếp.`
            : `${accountName(sid)}: lỗi ${text(accErr && accErr.message).slice(0, 160)} — bỏ qua account này, chạy tiếp account sau.`, "err");
          STATE.counters.errors++;
          emit("account", { phase: "error", sellerId: String(sid), name: accountName(sid),
                            index: accIndex, total: sellerIds.length,
                            needsRelogin: relogin, code: code || "" });
        }
      }

      if (opts.includeCatalog) {
        const catalogResult = await syncCatalog(tokens, opts);
        run.catalog_rows = catalogResult.rows;
      }
      const hardGaps = run.coverage.filter(x => !["@updated_at_lane", "@media"].includes(x.status) && !x.complete);
      /* v2.3.2: account lỗi cũng phải kéo run xuống partial — không được báo
         "hoàn tất" khi có account chưa đồng bộ được. */
      const accErrs = (run.account_errors || []).length;
      const reloginErrs = (run.account_errors || []).filter(x => x.needs_relogin).length;
      run.status = (hardGaps.length || accErrs) ? "partial" : "success";
      if (accErrs) {
        log(`Đồng bộ PARTIAL: ${accErrs} account không đồng bộ được`
          + (reloginErrs ? ` (${reloginErrs} account cần đăng nhập lại)` : "")
          + (hardGaps.length ? ` · còn ${hardGaps.length} coverage gap` : "")
          + ". Xem panel Sức khỏe account.", "warn");
      } else {
        log(hardGaps.length
          ? `Đồng bộ PARTIAL: còn ${hardGaps.length} coverage gap; xem Data Trust Center.`
          : "Đồng bộ hoàn tất. Dữ liệu raw và timeline đã lưu cục bộ.", hardGaps.length ? "warn" : "ok");
      }
    } catch (e) {
      if (e && e.name === "AbortError") {
        run.status = "stopped";
        log("Đã dừng đồng bộ theo yêu cầu. Phần đã kéo vẫn được giữ.", "warn");
      } else {
        run.status = "failed";
        run.error = e && e.message || String(e);
        log(`Đồng bộ dừng do lỗi: ${run.error}`, "err");
      }
    } finally {
      run.finished_at = nowIso();
      run.listed = STATE.counters.listed;
      run.detailed = STATE.counters.detailed;
      run.errors = STATE.counters.errors;
      run.retried = STATE.counters.retried;
      run.changed_orders = STATE.counters.changed;
      run.failure_queue = await countStore("sync_failures");
      await bulkPut("sync_runs", [run]);
      STATE.abortController = null;
      setSyncUi(false);
      await refreshHub();
      emit("run", {
        phase: "end", status: run.status,
        accounts: (run.seller_ids || []).length,
        accountErrors: (run.account_errors || []).length,
        needRelogin: (run.account_errors || []).filter(x => x.needs_relogin).length,
        listed: run.listed, detailed: run.detailed, changed: run.changed_orders,
        errors: run.errors, finishedAt: run.finished_at
      });
    }
  }

  function flattenRaw(value, prefix, out, depth) {
    out = out || {};
    depth = depth || 0;
    if (value == null) { if (prefix) out[prefix] = ""; return out; }
    if (Array.isArray(value)) {
      out[prefix || "value"] = clampCell(value);
      return out;
    }
    if (typeof value !== "object") {
      out[prefix || "value"] = value;
      return out;
    }
    if (depth > 10) { out[prefix || "value"] = clampCell(value); return out; }
    Object.keys(value).forEach(k => {
      const key = prefix ? `${prefix}.${k}` : k;
      const v = value[k];
      if (Array.isArray(v)) out[key] = clampCell(v);
      else if (v && typeof v === "object") flattenRaw(v, key, out, depth + 1);
      else out[key] = v == null ? "" : v;
    });
    return out;
  }

  function orderMasterRow(o) {
    return {
      SellerID: o.seller_id,
      Account: o.account_name,
      OrderCode: o.order_code,
      PartnerOrderCode: o.ref_code,
      InternalID: o.internal_id,
      Status: o.status,
      SubStatus: o.sub_status,
      FulfillmentType: o.fulfillment_type,
      Platform: o.platform,
      Channel: o.channel,
      GroupBrand: o.group_brand,
      Brand: o.brand,
      Prefix: o.prefix,
      Warehouse: o.warehouse,
      Carrier: o.carrier,
      TrackingNo: o.tracking_no,
      PartnerTrackingID: o.partner_tracking_id,
      OrderCreatedAt_API: o.created_at_api,
      UpdatedAt_API: o.updated_at_api,
      PromisedDeliveryAt_API: o.promised_delivery_at_api,
      ReceiverName: o.recipient_name,
      ReceiverPhone: o.recipient_phone,
      ReceiverProvince: o.recipient_province,
      ReceiverDistrict: o.recipient_district,
      ReceiverAddress: o.recipient_address,
      AddressType: o.address_type,
      DeliveryInstruction: o.delivery_instruction,
      CODAmount: o.cod_amount,
      OrderTotal: o.order_total,
      Currency: o.currency,
      PackingMethod: o.packing_method,
      PickupPartner: o.pickup_partner,
      PackingOnly: o.packing_only,
      CoInspection: o.co_inspection,
      ProductSKUCount: o.product_sku_count,
      TotalQuantity: o.total_quantity,
      SKUList: o.sku_list,
      VideoCount: o.video_count || 0,
      PackingVideoCount: o.packing_video_count || 0,
      UnboxingVideoCount: o.unboxing_video_count || 0,
      OtherVideoCount: o.other_video_count || 0,
      PackingVideoURLs: (o.packing_video_urls || []).join(" | "),
      UnboxingVideoURLs: (o.unboxing_video_urls || []).join(" | "),
      OtherVideoURLs: (o.other_video_urls || []).join(" | "),
      MediaSyncStatus: o.media_sync_status || "",
      MediaSyncedAt: o.media_synced_at || "",
      HasDetail: o.has_detail,
      DetailSyncStatus: o.detail_sync_status,
      DetailSyncError: o.detail_sync_error,
      LastDetailAttemptAt: o.last_detail_attempt_at,
      APIFieldCount: o.api_field_count,
      RawHash: o.raw_hash,
      TimelineCompletenessPct: o.journey && o.journey.timeline_completeness_pct,
      LastEventCode: o.journey && o.journey.last_event_code,
      LastEventLabel: o.journey && o.journey.last_event_label,
      LastEventAt_API: o.journey && o.journey.last_event_at_api,
      SyncedAt: o.synced_at
    };
  }

  function journeyWideRow(o) {
    return { SellerID: o.seller_id, OrderCode: o.order_code, PartnerOrderCode: o.ref_code, ...(o.journey || {}) };
  }

  function eventRows(o) {
    return (o.events || []).map(e => ({
      SellerID: o.seller_id,
      Account: o.account_name,
      OrderCode: o.order_code,
      PartnerOrderCode: o.ref_code,
      Sequence: e.sequence,
      CanonicalAttemptNo: e.canonical_attempt_no,
      StatusAttemptNo: e.status_attempt_no,
      MinutesFromPreviousEvent: e.minutes_from_previous_event,
      CanonicalStep: e.canonical_step,
      CanonicalLabel: e.canonical_label,
      StatusCode_API: e.status_code,
      EventLabel_API: e.event_label,
      EventAt_API: e.event_at_api,
      EventAt_ISO: e.event_at_iso,
      Actor_API: e.actor,
      Reason_API: e.reason,
      Source: e.source,
      RawEventJSON: clampCell(e.raw)
    }));
  }

  function itemRows(o) {
    return (o.items || []).map(it => ({
      SellerID: o.seller_id,
      OrderCode: o.order_code,
      PartnerOrderCode: o.ref_code,
      LineNo: it.line_no,
      SKU: it.sku,
      SellerProductCode: it.seller_product_code,
      ProductID: it.product_id,
      ProductName: it.product_name,
      Quantity: it.quantity,
      PackedQuantity: it.packed_quantity,
      Price: it.price,
      Grade: it.grade,
      GoodsCondition: it.gc,
      RawItemJSON: clampCell(it.raw)
    }));
  }

  function videoRows(o) {
    return (o.videos || []).map((video, index) => ({
      SellerID: o.seller_id,
      Account: o.account_name,
      OrderCode: o.order_code,
      PartnerOrderCode: o.ref_code,
      VideoNo: index + 1,
      VideoType: video.category,
      VideoTypeLabel: video.category_label,
      VideoURL: video.url,
      Label: video.label,
      CreatedAt_API: video.created_at_api,
      Provider: video.provider,
      Source: video.source,
      SourcePath: video.source_path,
      SourceEndpoint: video.source_endpoint,
      SourceRequestURL: video.source_request_url,
      CapturedAt: video.captured_at || o.media_synced_at || o.synced_at
    }));
  }

  function safeSheetName(name, used) {
    let base = String(name || "Data").replace(/[\\/?*\[\]:]/g, "_").slice(0, 31) || "Data";
    let candidate = base, i = 2;
    while (used.has(candidate)) {
      const suffix = `_${i++}`;
      candidate = base.slice(0, 31 - suffix.length) + suffix;
    }
    used.add(candidate);
    return candidate;
  }

  function autoCols(rows) {
    const keys = Object.keys(rows[0] || {});
    return keys.map(k => {
      let w = Math.max(10, Math.min(34, k.length + 2));
      for (let i = 0; i < Math.min(250, rows.length); i++) w = Math.max(w, Math.min(48, text(rows[i][k]).length + 2));
      return { wch: w };
    });
  }

  function appendRows(wb, used, name, rows) {
    if (!rows || !rows.length) return;
    for (let start = 0, part = 1; start < rows.length; start += EXCEL_MAX_ROWS, part++) {
      const chunk = rows.slice(start, start + EXCEL_MAX_ROWS);
      const sheetName = safeSheetName(part === 1 ? name : `${name}_${part}`, used);
      const ws = XLSX.utils.json_to_sheet(chunk);
      ws["!cols"] = autoCols(chunk);
      const range = XLSX.utils.decode_range(ws["!ref"] || "A1:A1");
      ws["!autofilter"] = { ref: XLSX.utils.encode_range(range) };
      XLSX.utils.book_append_sheet(wb, ws, sheetName);
    }
  }

  async function exportExcel() {
    if (typeof XLSX === "undefined") return alert("Thư viện Excel chưa tải được. Hãy reload extension.");
    setSyncUi(true);
    log("Đang dựng workbook đầy đủ…");
    try {
      const [orders, resources, runs, catalog, snapshots, failures] = await Promise.all([
        getAll("orders"), getAll("resources"), getAll("sync_runs"), runtimeMessage({ type: "GET_API_CATALOG" }),
        getAll("snapshots"), getAll("sync_failures")
      ]);
      const trust = buildDataTrust(orders, failures, catalog || [], runs);
      const wb = XLSX.utils.book_new();
      wb.Props = { Title: "TikiNOW Ops Data Hub", Subject: "Full API export", Author: "OnPoint Logistics", CreatedDate: new Date() };
      const used = new Set();
      appendRows(wb, used, "00_README", [{
        Package: "TikiNOW Ops Command Center v2.2.0 · Video Evidence Hub",
        ExportedAt: nowIso(),
        Orders: orders.length,
        APIResources: resources.length,
        DataTrustScore: trust.score,
        DataTrustGrade: trust.grade,
        PackingVideos: trust.packingVideos,
        UnboxingVideos: trust.unboxingVideos,
        Note: "Các cột *_API là timestamp/giá trị lấy trực tiếp từ API. Sheet 14_Order_Videos chứa link video đóng gói/khui hàng và nguồn API; signed URL có thể hết hạn nên nên đồng bộ lại trước khi mở."
      }]);
      appendRows(wb, used, "01_Orders_Master", orders.map(orderMasterRow));
      appendRows(wb, used, "02_Journey_Wide", orders.map(journeyWideRow));
      appendRows(wb, used, "03_Journey_Events", orders.flatMap(eventRows));
      appendRows(wb, used, "04_Order_Items", orders.flatMap(itemRows));
      appendRows(wb, used, "05_Raw_Orders_Flat", orders.map(o => ({
        SellerID: o.seller_id,
        OrderCode: o.order_code,
        ...flattenRaw(o.raw_detail || o.raw_list || {})
      })));
      appendRows(wb, used, "06_API_Catalog", (catalog || []).map(x => ({
        Method: x.method, Endpoint: x.pathKey, Kind: x.kind, Status: x.status, SellerID: x.sellerId,
        Total: x.total, TotalPages: x.totalPage, Hits: x.hits,
        FirstSeenAt: x.firstSeenAt ? new Date(x.firstSeenAt).toISOString() : "",
        LastSeenAt: x.lastSeenAt ? new Date(x.lastSeenAt).toISOString() : "",
        SchemaVersion: x.schemaVersion || 1, NewFields: (x.newFields || []).join(" | "), RemovedFields: (x.removedFields || []).join(" | "),
        SchemaPaths: (x.schemaPaths || []).join(" | "), RequestBody: clampCell(x.requestBody || "")
      })));
      appendRows(wb, used, "07_Sync_Log", runs.sort((a, b) => text(b.started_at).localeCompare(text(a.started_at))));
      appendRows(wb, used, "08_Data_Quality", [
        { Metric: "Data Trust Score", Value: trust.score, Target: 95, Status: trust.score >= 95 ? "PASS" : "ACTION" },
        { Metric: "Detail coverage %", Value: trust.detailPct, Target: 100, Status: trust.detailPct === 100 ? "PASS" : "ACTION" },
        { Metric: "Counts reconciliation %", Value: trust.reconPct, Target: 100, Status: trust.reconPct === 100 ? "PASS" : "ACTION" },
        { Metric: "Timeline completeness %", Value: trust.timelinePct, Target: 95, Status: trust.timelinePct >= 95 ? "PASS" : "REVIEW" },
        { Metric: "Known event mapping %", Value: trust.knownPct, Target: 100, Status: trust.knownPct === 100 ? "PASS" : "REVIEW" },
        { Metric: "Retry health %", Value: trust.retryHealth, Target: 100, Status: trust.retryHealth === 100 ? "PASS" : "ACTION" },
        { Metric: "Freshness score", Value: trust.freshness, Target: 85, Status: trust.freshness >= 85 ? "PASS" : "STALE" },
        { Metric: "Packing video links", Value: trust.packingVideos, Target: "informational", Status: "INFO" },
        { Metric: "Unboxing video links", Value: trust.unboxingVideos, Target: "informational", Status: "INFO" },
        { Metric: "Orders with video evidence", Value: trust.videoOrders, Target: "informational", Status: "INFO" },
        ...trust.issues.map(x => ({ Metric: x.key, Value: x.count, Target: 0, Status: x.severity, Detail: x.title, Action: x.action }))
      ]);
      const coverageRows = runs.flatMap(run => (run.coverage || []).map(x => ({ RunID: run.id, RunMode: run.mode, RunStartedAt: run.started_at, ...x })));
      appendRows(wb, used, "09_Sync_Coverage", coverageRows.length ? coverageRows : [{ Status: "NO_SYNC_COVERAGE" }]);
      appendRows(wb, used, "10_Unknown_Events", trust.unknownRows.length ? trust.unknownRows : [{ Status: "NO_UNKNOWN_EVENTS" }]);
      appendRows(wb, used, "11_Order_Changes", snapshots.length ? snapshots.map(s => ({
        SellerID: s.seller_id, OrderCode: s.order_code, CapturedAt: s.captured_at, ChangeType: s.change_type,
        StatusFrom: s.status_from, StatusTo: s.status_to, SubStatusFrom: s.sub_status_from, SubStatusTo: s.sub_status_to,
        RawHash: s.raw_hash, PreviousHash: s.previous_hash, ChangedFieldCount: s.changed_field_count,
        ChangedFields: (s.changed_fields || []).join(" | ")
      })) : [{ Status: "NO_SNAPSHOTS" }]);
      appendRows(wb, used, "12_Retry_Queue", failures.length ? failures : [{ Status: "EMPTY_RETRY_QUEUE" }]);
      const driftRows = (catalog || []).filter(x => (x.newFields || []).length || (x.removedFields || []).length).map(x => ({
        Method: x.method, Endpoint: x.pathKey, SchemaVersion: x.schemaVersion, SchemaChangedAt: x.schemaChangedAt ? new Date(x.schemaChangedAt).toISOString() : "",
        NewFields: (x.newFields || []).join(" | "), RemovedFields: (x.removedFields || []).join(" | ")
      }));
      appendRows(wb, used, "13_Schema_Drift", driftRows.length ? driftRows : [{ Status: "NO_SCHEMA_DRIFT" }]);
      const videos = orders.flatMap(videoRows);
      appendRows(wb, used, "14_Order_Videos", videos.length ? videos : [{ Status: "NO_VIDEO_LINKS_DISCOVERED", Action: "Mở video đóng gói và video khui hàng trên TikiNOW một lần, sau đó chạy Smart Sync." }]);

      const grouped = new Map();
      resources.forEach(r => {
        if (!grouped.has(r.resource_key)) grouped.set(r.resource_key, []);
        const records = unwrapRecords(r.raw);
        if (records.length) grouped.get(r.resource_key).push(...records.map(flattenRaw));
        else grouped.get(r.resource_key).push(flattenRaw(r.raw));
      });
      // Hook v2.3: sheet mở rộng do insight.js cung cấp (field & endpoint coverage).
      if (typeof root.TNSL_EXTRA_SHEETS === "function") {
        try {
          const extra = await root.TNSL_EXTRA_SHEETS();
          (extra || []).forEach(s => {
            if (s && s.name && Array.isArray(s.rows)) {
              appendRows(wb, used, s.name, s.rows.length ? s.rows : [{ Status: "NO_DATA" }]);
            }
          });
        } catch (e) { log(`Sheet mở rộng lỗi (bỏ qua): ${e.message}`, "err"); }
      }

      let apiIndex = 1;
      for (const [key, rows] of grouped) {
        const tail = key.split(" ").pop().split("/").filter(Boolean).slice(-2).join("_") || `Resource_${apiIndex}`;
        appendRows(wb, used, `API_${String(apiIndex).padStart(2, "0")}_${tail}`, rows);
        apiIndex++;
      }

      const stamp = new Date().toISOString().replace(/[:T]/g, "-").slice(0, 19);
      XLSX.writeFile(wb, `TikiNOW_Ops_DataHub_FULL_${stamp}.xlsx`, { compression: true });
      log(`Đã xuất ${nfmt(orders.length)} đơn, ${nfmt(orders.flatMap(eventRows).length)} event, ${nfmt(videos.length)} video và ${grouped.size} API resource.`, "ok");
    } catch (e) {
      log(`Xuất Excel lỗi: ${e.message}`, "err");
      alert(`Không xuất được Excel: ${e.message}`);
    } finally { setSyncUi(false); }
  }

  function downloadBlob(blob, filename) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = filename; a.style.display = "none";
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 30000);
  }

  async function backupJson() {
    setSyncUi(true);
    log("Đang tạo backup raw JSON (không chứa token)…");
    try {
      const [orders, resources, runs, catalog, snapshots, failures] = await Promise.all([
        getAll("orders"), getAll("resources"), getAll("sync_runs"), runtimeMessage({ type: "GET_API_CATALOG" }),
        getAll("snapshots"), getAll("sync_failures")
      ]);
      const payload = JSON.stringify({
        format: "TikiNOW Ops Data Trust Hub Backup v2.2.0 · Video Evidence Hub",
        exported_at: nowIso(),
        catalog: catalog || [],
        orders,
        resources,
        sync_runs: runs,
        snapshots,
        sync_failures: failures
      });
      const stamp = new Date().toISOString().replace(/[:T]/g, "-").slice(0, 19);
      if (typeof CompressionStream !== "undefined") {
        const stream = new Blob([payload], { type: "application/json" }).stream().pipeThrough(new CompressionStream("gzip"));
        const gz = await new Response(stream).blob();
        downloadBlob(gz, `TikiNOW_Ops_DataHub_RAW_${stamp}.json.gz`);
      } else downloadBlob(new Blob([payload], { type: "application/json" }), `TikiNOW_Ops_DataHub_RAW_${stamp}.json`);
      log("Backup raw hoàn tất.", "ok");
    } catch (e) {
      log(`Backup lỗi: ${e.message}`, "err");
    } finally { setSyncUi(false); }
  }

  function completenessClass(pct) {
    return pct >= 85 ? "good" : pct >= 55 ? "warn" : "bad";
  }

  function buildDataTrust(orders, failures, catalog, runs) {
    const latest = [...(runs || [])].sort((a, b) => text(b.started_at).localeCompare(text(a.started_at)))[0] || null;
    const coverage = latest && Array.isArray(latest.coverage) ? latest.coverage : [];
    const listCoverage = coverage.filter(x => !["@updated_at_lane", "@detail", "@media"].includes(x.status));
    const reconRows = listCoverage.filter(x => x.expected != null);
    const reconOk = reconRows.filter(x => x.complete).length;
    const reconciliationGaps = listCoverage.filter(x => !x.complete && (x.expected != null || x.error || x.truncated));
    const reconPct = reconRows.length ? Math.round(reconOk * 100 / reconRows.length) : (orders.length ? 50 : 0);
    const detailed = orders.filter(o => o.has_detail).length;
    const detailPct = orders.length ? Math.round(detailed * 100 / orders.length) : 0;
    const delivered = orders.filter(o => text(o.status).toLowerCase() === "delivered");
    const timelineBase = delivered.length ? delivered : orders;
    const timelinePct = timelineBase.length
      ? Math.round(timelineBase.reduce((s, o) => s + Number(o.journey && o.journey.timeline_completeness_pct || 0), 0) / timelineBase.length)
      : 0;
    const events = orders.flatMap(o => (o.events || []).map(e => ({ ...e, order_code: o.order_code, seller_id: o.seller_id })));
    const unknownEvents = events.filter(e => e.canonical_step === "other");
    const packingVideos = orders.reduce((sum, o) => sum + Number(o.packing_video_count || 0), 0);
    const unboxingVideos = orders.reduce((sum, o) => sum + Number(o.unboxing_video_count || 0), 0);
    const videoOrders = orders.filter(o => Number(o.video_count || 0) > 0).length;
    const knownPct = events.length ? Math.round((events.length - unknownEvents.length) * 100 / events.length) : 0;
    const pendingFailures = (failures || []).filter(f => f.state === "pending");
    const blockedFailures = (failures || []).filter(f => f.state === "blocked");
    const routeFailures = (failures || []).filter(f => f.operation === "order_detail_route");
    const blockedOrderFailures = blockedFailures.filter(f => f.operation !== "order_detail_route");
    const orderFailureCount = (failures || []).filter(f => f.operation === "order_detail").length;
    const retryHealth = routeFailures.length ? 0 : (orders.length ? Math.max(0, Math.round(100 - orderFailureCount * 100 / orders.length)) : 0);
    const lastFinished = latest && parseApiTime(latest.finished_at || latest.started_at);
    const ageH = lastFinished ? (Date.now() - lastFinished.getTime()) / 3600000 : Infinity;
    const freshness = ageH <= 6 ? 100 : ageH <= 24 ? 85 : ageH <= 48 ? 60 : ageH <= 168 ? 30 : 0;
    const score = orders.length ? Math.round(detailPct * .25 + reconPct * .25 + timelinePct * .15 + knownPct * .10 + retryHealth * .10 + freshness * .15) : 0;
    const grade = score >= 95 ? "A+" : score >= 90 ? "A" : score >= 82 ? "B" : score >= 70 ? "C" : score >= 55 ? "D" : "F";
    const schemaDrift = (catalog || []).filter(x => (x.newFields || []).length || (x.removedFields || []).length);
    const unknownMap = {};
    unknownEvents.forEach(e => {
      const key = e.status_code || "unknown";
      const g = unknownMap[key] || (unknownMap[key] = { status_code: key, event_label: e.event_label, count: 0, sample_order: e.order_code });
      g.count++;
    });
    const deliveredMissingEvent = delivered.filter(o => !(o.journey && o.journey.delivered_at_api));
    const missingTracking = orders.filter(o => /^(shipping|delivered)$/i.test(text(o.status)) && !o.tracking_no);
    const staleOpen = orders.filter(o => {
      if (FINAL_STATUSES.has(text(o.status).toLowerCase())) return false;
      const d = parseApiTime(o.journey && o.journey.last_event_at_api || o.updated_at_api || o.created_at_api);
      return d && Date.now() - d.getTime() > 72 * 3600000;
    });
    const issues = [];
    const addIssue = (sev, key, count, title, action) => { if (count) issues.push({ severity: sev, key, count, title, action }); };
    addIssue("P1", "reconciliation", reconciliationGaps.length, "Counts/list API chưa khớp hoặc bị gián đoạn", "Tăng Max pages hoặc chạy Full Sync lại");
    addIssue("P1", "detail_route", routeFailures.length, "Detail API trả HTML / route không khả dụng", "Mở chi tiết 1 đơn trên TikiNOW để Observer học endpoint, kiểm tra token rồi Retry gaps");
    addIssue("P1", "retry", pendingFailures.length, "Detail API đang chờ retry", "Bấm Retry gaps / Smart Sync");
    addIssue("P1", "missing_detail", orders.length - detailed, "Đơn chưa có raw detail", "Chạy Smart Sync để bù detail");
    addIssue("P2", "schema_drift", schemaDrift.length, "Endpoint có schema mới/thay đổi", "Kiểm tra API Catalog và Data Dictionary");
    addIssue("P2", "unknown_events", Object.keys(unknownMap).length, "Event code API chưa được map", "Dùng sheet Unknown_Events để bổ sung mapping");
    addIssue("P2", "delivered_no_event", deliveredMissingEvent.length, "Đơn delivered thiếu mốc delivered trong history", "Đối soát raw detail/API timeline");
    addIssue("P2", "stale_open", staleOpen.length, "Đơn mở không có event mới >72 giờ", "Ưu tiên xử lý backlog kẹt");
    addIssue("P3", "missing_tracking", missingTracking.length, "Đơn shipping/delivered thiếu tracking", "Kiểm tra field vận chuyển hoặc carrier mapping");
    addIssue("P3", "blocked", blockedOrderFailures.length, "Detail bị 400/404 hoặc không có quyền", "Kiểm tra order/account hoặc quyền API");
    return {
      score, grade, detailPct, reconPct, timelinePct, knownPct, retryHealth, freshness, ageH,
      packingVideos, unboxingVideos, videoOrders,
      latestRun: latest, reconRows, reconOk, reconciliationGaps, pendingFailures, blockedFailures, routeFailures, schemaDrift,
      unknownRows: Object.values(unknownMap).sort((a, b) => b.count - a.count),
      deliveredMissingEvent, missingTracking, staleOpen, issues
    };
  }

  function renderTrust(trust) {
    STATE.trust = trust;
    if ($("dhTrustScore")) $("dhTrustScore").textContent = trust.score;
    if ($("dhTrustGrade")) { $("dhTrustGrade").textContent = trust.grade; $("dhTrustGrade").className = `grade g-${trust.grade.replace("+", "p")}`; }
    if ($("dhRecon")) $("dhRecon").textContent = `${trust.reconOk}/${trust.reconRows.length}`;
    if ($("dhUnknown")) $("dhUnknown").textContent = nfmt(trust.unknownRows.length);
    if ($("dhFailure")) $("dhFailure").textContent = nfmt(trust.pendingFailures.length + trust.blockedFailures.length);
    if ($("dhSchemaDrift")) $("dhSchemaDrift").textContent = nfmt(trust.schemaDrift.length);
    if ($("dhChanges")) $("dhChanges").textContent = nfmt(trust.latestRun && trust.latestRun.changed_orders || 0);
    if ($("dhFreshness")) $("dhFreshness").textContent = isFinite(trust.ageH) ? (trust.ageH < 1 ? "<1h" : `${Math.round(trust.ageH)}h`) : "—";
    if ($("dhPackingVideos")) $("dhPackingVideos").textContent = nfmt(trust.packingVideos);
    if ($("dhUnboxingVideos")) $("dhUnboxingVideos").textContent = nfmt(trust.unboxingVideos);
    const box = $("dhTrustIssues");
    if (box) box.innerHTML = trust.issues.length ? trust.issues.slice(0, 8).map(x => `
      <div class="dh-trust-issue ${esc(x.severity)}"><span>${esc(x.severity)}</span><div><b>${esc(x.title)}</b><small>${esc(x.action)}</small></div><strong>${nfmt(x.count)}</strong></div>`).join("")
      : `<div class="dh-trust-perfect">✓ Không phát hiện data gap trọng yếu.</div>`;
  }

  function videoChipHtml(order) {
    const videos = order.videos || [];
    if (!videos.length) return `<span class="dh-video-empty">Chưa thấy</span>`;
    const first = category => videos.find(v => v.category === category);
    const chips = [];
    const packing = first("packing"), unboxing = first("unboxing"), other = first("other");
    if (packing) chips.push(`<a class="dh-video-chip packing" href="${esc(packing.url)}" target="_blank" rel="noreferrer" title="Mở video đóng gói">📦 ${nfmt(order.packing_video_count || 1)}</a>`);
    if (unboxing) chips.push(`<a class="dh-video-chip unboxing" href="${esc(unboxing.url)}" target="_blank" rel="noreferrer" title="Mở video khui hàng">🎬 ${nfmt(order.unboxing_video_count || 1)}</a>`);
    if (other) chips.push(`<a class="dh-video-chip other" href="${esc(other.url)}" target="_blank" rel="noreferrer" title="Mở video khác">＋${nfmt(order.other_video_count || 1)}</a>`);
    return `<div class="dh-video-chips">${chips.join("")}</div>`;
  }

  function renderOrderTable(rows) {
    STATE.visibleOrders = rows;
    const body = $("dhOrderRows");
    if (!body) return;
    body.innerHTML = rows.length ? rows.map(o => {
      const pct = o.journey && o.journey.timeline_completeness_pct || 0;
      return `<tr>
        <td><button class="dh-link" data-order-pk="${esc(o.pk)}">${esc(o.order_code || "—")}</button><small>${esc(o.ref_code || "")}</small></td>
        <td>${esc(o.account_name)}</td>
        <td><span class="dh-status">${esc(o.status || "—")}</span><small>${esc(o.sub_status || "")}</small></td>
        <td>${esc(o.warehouse || "—")}</td>
        <td>${esc(o.carrier || "—")}</td>
        <td>${esc(localDisplay(o.created_at_api))}</td>
        <td>${esc(o.journey && o.journey.last_event_label || "—")}<small>${esc(localDisplay(o.journey && o.journey.last_event_at_api))}</small></td>
        <td>${videoChipHtml(o)}</td>
        <td><span class="dh-complete ${completenessClass(pct)}">${pct}%</span></td>
      </tr>`;
    }).join("") : `<tr><td colspan="9" class="empty">Chưa có dữ liệu phù hợp.</td></tr>`;
  }

  async function searchOrders() {
    const all = await getAll("orders");
    const q = stripVN($("dhSearch") && $("dhSearch").value || "");
    const status = $("dhStatusFilter") && $("dhStatusFilter").value || "";
    const rows = all.filter(o => {
      if (status && o.status !== status) return false;
      if (!q) return true;
      return stripVN([o.order_code, o.ref_code, o.tracking_no, o.recipient_phone, o.channel, o.brand, o.warehouse,
        ...(o.videos || []).flatMap(v => [v.category, v.category_label, v.url, v.label])].join(" ")).includes(q);
    }).sort((a, b) => text(b.created_at_api).localeCompare(text(a.created_at_api))).slice(0, 300);
    renderOrderTable(rows);
    if ($("dhOrderCount")) $("dhOrderCount").textContent = `Hiển thị ${nfmt(rows.length)} / ${nfmt(all.length)} đơn`;
  }

  async function fetchOrderDirect() {
    if (STATE.syncing) return;
    const code = text($("dhSearch") && $("dhSearch").value).trim();
    if (!code) return alert("Nhập mã đơn TikiNOW cần tra API.");
    const tokens = await selectedTokens();
    if (!Object.keys(tokens).length) return alert("Chưa có token TikiNOW.");
    setSyncUi(true); STATE.abortController = new AbortController();
    let found = 0;
    try {
      const [existingRows, failureRows, apiCatalog] = await Promise.all([
        getAll("orders"), getAll("sync_failures"), runtimeMessage({ type: "GET_API_CATALOG" })
      ]);
      const existingMap = new Map(existingRows.map(o => [o.pk, o]));
      const failureMap = new Map(failureRows.map(f => [f.pk, f]));
      for (const [sid, t] of Object.entries(tokens)) {
        try {
          const old = existingMap.get(`${sid}|${code}`);
          const probe = old ? storedOrderAsList(old, false) : { order_code: code };
          const routeState = {};
          const fetched = await fetchOrderDetail(probe, sid, t.token, apiCatalog || [], routeState);
          const detail = fetched.detail;
          const mediaResult = await fetchOrderMedia({ ...probe, ...detail }, sid, t.token, apiCatalog || [], routeState.media || (routeState.media = {}));
          const actualCode = text(pick(detail, ["order_code", "code", "order_id"], ""));
          if (!actualCode) continue;
          const mediaPayloads = mediaResult.successCount
            ? mergeMediaPayloads(old && old.raw_media, mediaResult.payloads)
            : (old && old.raw_media || []);
          const normalized = normalizeOrder(probe, detail, sid, mediaPayloads);
          normalized.media_sync_status = mediaResult.successCount ? (mediaResult.errorCount ? "partial" : "success")
            : mediaResult.attempted ? (mediaPayloads.length ? "cached_after_error" : "failed")
            : (mediaPayloads.length ? "cached" : "not_observed");
          normalized.media_synced_at = mediaResult.successCount ? nowIso() : (old && old.media_synced_at || "");
          normalized.media_routes = mediaResult.routes || [];
          await persistOrders([normalized], existingMap, failureMap);
          await deleteRows("sync_failures", [detailRouteFailureKey(sid)]);
          found++;
          log(`${actualCode}: đã lấy detail từ ${accountName(sid)} · ${routeState.preferredLabel || "default"} · ${normalized.video_count || 0} video.`, "ok");
        } catch (e) {
          if (e && e.name === "AbortError") throw e;
          if (![400, 404].includes(e && e.code)) log(`${accountName(sid)}: ${e.message}`, "warn");
        }
      }
    } finally {
      STATE.abortController = null; setSyncUi(false); await refreshHub(); await searchOrders();
    }
    if (!found) alert("Chưa lấy được detail. Nếu log báo HTML/route: mở đúng chi tiết 1 đơn trên TikiNOW Center, quay lại và bấm Tra API mã đơn lần nữa.");
  }

  function showOrder(pk) {
    const order = STATE.visibleOrders.find(o => o.pk === pk);
    if (!order) return;
    const drawer = $("dhDrawer");
    const content = $("dhDrawerContent");
    if (!drawer || !content) return;
    let previous = null;
    const timeline = (order.events || []).map(e => {
      const mins = previous ? diffMin(previous.event_at_api, e.event_at_api) : null;
      previous = e;
      return `<div class="dh-event ${e.canonical_step !== "other" ? "canonical" : ""}">
        <span class="dh-event-dot"></span>
        <div><b>${esc(e.canonical_label || e.event_label)}</b><small>${esc(e.status_code)} · ${esc(e.source)}</small>
        <p>${esc(e.event_at_api || "Không có timestamp")}${mins != null ? ` <em>+${nfmt(mins)} phút</em>` : ""}</p>
        ${e.event_label && e.event_label !== e.canonical_label ? `<span>${esc(e.event_label)}</span>` : ""}</div>
      </div>`;
    }).join("");
    const videoEvidence = (order.videos || []).map((video, index) => `
      <article class="dh-video-card ${esc(video.category)}">
        <div class="dh-video-icon">${video.category === "packing" ? "📦" : video.category === "unboxing" ? "🎬" : "▶"}</div>
        <div class="dh-video-meta">
          <b>${esc(video.category_label || "Video")}${video.label ? ` · ${esc(video.label)}` : ""}</b>
          <small>${esc(video.created_at_api || video.captured_at || "Không có timestamp")} · ${esc(video.source || "API")}</small>
          <code title="${esc(video.source_path || "")}">${esc(video.source_endpoint || video.source_path || "embedded order detail")}</code>
        </div>
        <div class="dh-video-actions">
          <a href="${esc(video.url)}" target="_blank" rel="noreferrer">Mở video ↗</a>
          <button class="ghost dh-copy-video" data-video-index="${index}">Copy link</button>
        </div>
      </article>`).join("");
    const master = orderMasterRow(order);
    content.innerHTML = `
      <div class="dh-drawer-head">
        <div><span class="dh-eyebrow">ORDER 360°</span><h2>#${esc(order.order_code)}</h2><p>${esc(order.ref_code)} · ${esc(order.account_name)}</p></div>
        <button id="dhDrawerClose" class="ghost">✕</button>
      </div>
      <div class="dh-order-hero">
        <div><span>Trạng thái</span><b>${esc(order.status)} / ${esc(order.sub_status)}</b></div>
        <div><span>Kho</span><b>${esc(order.warehouse || "—")}</b></div>
        <div><span>ĐVVC</span><b>${esc(order.carrier || "—")}</b></div>
        <div><span>Tracking</span><b>${esc(order.tracking_no || "—")}</b></div>
      </div>
      <section class="dh-video-evidence">
        <div class="dh-video-head"><div><span class="dh-eyebrow">VIDEO EVIDENCE</span><h3>Đóng gói & khui hàng · ${nfmt(order.video_count || 0)} link</h3></div>
        <small>${nfmt(order.packing_video_count || 0)} đóng gói · ${nfmt(order.unboxing_video_count || 0)} khui hàng · ${esc(order.media_sync_status || "chưa học API")}</small></div>
        <div class="dh-video-list">${videoEvidence || `<div class="dh-video-onboard"><b>Chưa tìm thấy link video cho đơn này.</b><span>Mở video đóng gói và video khui hàng của một đơn trên TikiNOW một lần, sau đó bấm “Tra API mã đơn” hoặc Smart Sync.</span></div>`}</div>
      </section>
      <div class="dh-drawer-grid">
        <div class="dh-timeline"><h3>API Timeline · ${(order.events || []).length} events</h3>${timeline || `<div class="empty">API detail chưa trả history.</div>`}</div>
        <div class="dh-master"><h3>Order Master</h3>${Object.entries(master).map(([k, v]) => `<div><span>${esc(k)}</span><b>${esc(v)}</b></div>`).join("")}</div>
      </div>
      <details class="dh-raw"><summary>Raw API detail · ${nfmt(order.api_field_count)} fields</summary><pre id="dhRawJson"></pre></details>`;
    const pre = content.querySelector("#dhRawJson");
    if (pre) pre.textContent = JSON.stringify(order.raw_detail || order.raw_list || {}, null, 2);
    drawer.classList.add("open");
    content.querySelector("#dhDrawerClose").onclick = () => drawer.classList.remove("open");
    content.querySelectorAll(".dh-copy-video").forEach(button => {
      button.onclick = async () => {
        const video = (order.videos || [])[Number(button.dataset.videoIndex)];
        if (!video) return;
        try {
          if (navigator.clipboard && navigator.clipboard.writeText) await navigator.clipboard.writeText(video.url);
          else {
            const area = document.createElement("textarea"); area.value = video.url; document.body.appendChild(area); area.select(); document.execCommand("copy"); area.remove();
          }
          button.textContent = "Đã copy ✓";
        } catch (_) { button.textContent = "Copy lỗi"; }
      };
    });
  }

  function renderCatalog(catalog) {
    STATE.catalog = catalog || [];
    const body = $("dhApiRows");
    if (!body) return;
    body.innerHTML = STATE.catalog.length ? STATE.catalog.slice(0, 150).map((r, i) => `<tr>
      <td><code>${esc(r.method)}</code></td>
      <td><b>${esc(r.pathKey)}</b>${(r.newFields || []).length || (r.removedFields || []).length ? `<span class="dh-drift">schema v${nfmt(r.schemaVersion || 1)} · +${nfmt((r.newFields || []).length)} / -${nfmt((r.removedFields || []).length)}</span>` : ""}<small>${esc(r.title || "")}</small></td>
      <td><span class="dh-kind">${esc(r.kind)}</span></td>
      <td>${nfmt((r.schemaPaths || []).length)}</td>
      <td>${r.total == null ? "—" : nfmt(r.total)}</td>
      <td>${r.lastSeenAt ? esc(new Date(r.lastSeenAt).toLocaleString("vi-VN")) : "—"}</td>
      <td>${r.kind === "media" ? `<span class="dh-lock dh-media-auto">auto/đơn</span>` : safeCatalogRead(r) ? `<button class="ghost dh-api-sync" data-api-index="${i}">Kéo</button>` : `<span class="dh-lock">metadata only</span>`}</td>
    </tr>`).join("") : `<tr><td colspan="7" class="empty">Mở các màn hình TikiNOW Center để hệ thống tự học endpoint/API schema.</td></tr>`;
  }

  async function syncCatalogOnly() {
    if (STATE.syncing) return;
    const tokens = await selectedTokens();
    if (!Object.keys(tokens).length) return alert("Chưa có token TikiNOW.");
    setSyncUi(true); STATE.abortController = new AbortController();
    try { await syncCatalog(tokens, syncOptions("smart")); log("Đồng bộ API catalog hoàn tất.", "ok"); }
    catch (e) { log(e.name === "AbortError" ? "Đã dừng." : `Lỗi: ${e.message}`, e.name === "AbortError" ? "warn" : "err"); }
    finally { STATE.abortController = null; setSyncUi(false); await refreshHub(); }
  }

  async function syncCatalogIndex(i) {
    const rec = STATE.catalog[i];
    if (!rec) return;
    const tokens = await selectedTokens();
    setSyncUi(true); STATE.abortController = new AbortController();
    try {
      const r = await syncOneCatalogEndpoint(rec, tokens, syncOptions("smart"));
      log(`${rec.key}: đã lưu ${nfmt(r.rows)} dòng raw.`, "ok");
    } catch (e) { log(`${rec.key}: ${e.message}`, "err"); }
    finally { STATE.abortController = null; setSyncUi(false); await refreshHub(); }
  }

  async function refreshHub() {
    await openDb();
    const [orders, resourcesCount, runs, catalog, tokens, failures, snapshotCount] = await Promise.all([
      getAll("orders"), countStore("resources"), getAll("sync_runs"),
      runtimeMessage({ type: "GET_API_CATALOG" }), selectedTokens(), getAll("sync_failures"), countStore("snapshots")
    ]);
    const detailed = orders.filter(o => o.has_detail).length;
    const events = orders.reduce((s, o) => s + (o.events || []).length, 0);
    const packingVideos = orders.reduce((s, o) => s + Number(o.packing_video_count || 0), 0);
    const unboxingVideos = orders.reduce((s, o) => s + Number(o.unboxing_video_count || 0), 0);
    const avgComplete = orders.length ? Math.round(orders.reduce((s, o) => s + (o.journey && o.journey.timeline_completeness_pct || 0), 0) / orders.length) : 0;
    const last = runs.sort((a, b) => text(b.started_at).localeCompare(text(a.started_at)))[0];
    if ($("dhKpiOrders")) $("dhKpiOrders").textContent = nfmt(orders.length);
    if ($("dhKpiDetails")) $("dhKpiDetails").textContent = `${nfmt(detailed)} / ${nfmt(orders.length)}`;
    if ($("dhKpiEvents")) $("dhKpiEvents").textContent = nfmt(events);
    if ($("dhKpiCoverage")) $("dhKpiCoverage").textContent = `${avgComplete}%`;
    if ($("dhKpiApis")) $("dhKpiApis").textContent = nfmt((catalog || []).length);
    if ($("dhKpiResources")) $("dhKpiResources").textContent = nfmt(resourcesCount);
    if ($("dhKpiPackingVideos")) $("dhKpiPackingVideos").textContent = nfmt(packingVideos);
    if ($("dhKpiUnboxingVideos")) $("dhKpiUnboxingVideos").textContent = nfmt(unboxingVideos);
    renderTrust(buildDataTrust(orders, failures, catalog || [], runs));
    if ($("dhTokenCount")) $("dhTokenCount").textContent = `${Object.keys(tokens).length} account online`;
    if ($("dhLastSync")) $("dhLastSync").textContent = last
      ? `${last.status} · ${localDisplay(last.finished_at || last.started_at)} · ${nfmt(last.detailed)} details`
      : "Chưa đồng bộ";
    try {
      const est = await navigator.storage.estimate();
      if ($("dhStorage")) $("dhStorage").textContent = `${(Number(est.usage || 0) / 1048576).toFixed(1)} MB · ${nfmt(snapshotCount)} snapshots`;
    } catch (_) {}

    const statuses = Array.from(new Set(orders.map(o => o.status).filter(Boolean))).sort();
    const statusSel = $("dhStatusFilter");
    if (statusSel) {
      const current = statusSel.value;
      statusSel.innerHTML = `<option value="">Tất cả status</option>` + statuses.map(s => `<option value="${esc(s)}">${esc(s)}</option>`).join("");
      if (statuses.includes(current)) statusSel.value = current;
    }
    renderCatalog(catalog || []);
    const recent = orders.sort((a, b) => text(b.created_at_api).localeCompare(text(a.created_at_api))).slice(0, 100);
    renderOrderTable(recent);
    if ($("dhOrderCount")) $("dhOrderCount").textContent = `100 đơn mới nhất / ${nfmt(orders.length)}`;
  }

  async function init() {
    await openDb();
    document.querySelectorAll(".tab").forEach(tab => {
      tab.addEventListener("click", () => {
        const hub = $("viewDatahub");
        if (hub) hub.style.display = tab.dataset.view === "datahub" ? "" : "none";
        if (tab.dataset.view === "datahub") refreshHub();
      });
    });
    if ($("dhSmartSync")) $("dhSmartSync").onclick = () => syncAll("smart");
    if ($("dhRetryFailures")) $("dhRetryFailures").onclick = () => syncAll("smart", { forceRetries: true });
    if ($("dhFullSync")) $("dhFullSync").onclick = () => syncAll("full");
    if ($("dhSyncCatalog")) $("dhSyncCatalog").onclick = syncCatalogOnly;
    if ($("dhStop")) $("dhStop").onclick = () => { if (STATE.abortController) STATE.abortController.abort(); };
    if ($("dhExportExcel")) $("dhExportExcel").onclick = exportExcel;
    if ($("dhBackupJson")) $("dhBackupJson").onclick = backupJson;
    if ($("dhSearchBtn")) $("dhSearchBtn").onclick = searchOrders;
    if ($("dhFetchOrder")) $("dhFetchOrder").onclick = fetchOrderDirect;
    if ($("dhSearch")) $("dhSearch").addEventListener("keydown", e => { if (e.key === "Enter") searchOrders(); });
    if ($("dhStatusFilter")) $("dhStatusFilter").onchange = searchOrders;
    if ($("dhClearData")) $("dhClearData").onclick = async () => {
      if (!confirm("Xóa toàn bộ raw data, timeline và lịch sử sync đang lưu trên máy? Không thể hoàn tác.")) return;
      await clearAllData(); log("Đã xóa Data Hub local.", "warn"); await refreshHub();
    };
    if ($("dhClearCatalog")) $("dhClearCatalog").onclick = async () => {
      if (!confirm("Xóa API catalog đã tự học? Dữ liệu đơn/raw vault không bị xóa.")) return;
      await runtimeMessage({ type: "CLEAR_API_CATALOG" }); await refreshHub();
    };
    if ($("dhOrderRows")) $("dhOrderRows").addEventListener("click", e => {
      const b = e.target.closest("[data-order-pk]"); if (b) showOrder(b.dataset.orderPk);
    });
    if ($("dhApiRows")) $("dhApiRows").addEventListener("click", e => {
      const b = e.target.closest("[data-api-index]"); if (b) syncCatalogIndex(Number(b.dataset.apiIndex));
    });
    if ($("dhDrawer")) $("dhDrawer").addEventListener("click", e => { if (e.target === $("dhDrawer")) $("dhDrawer").classList.remove("open"); });
    if (!root.UnifiedAnalysis) await refreshHub();
  }

  root.TikiDataHub = {
    syncSmart: () => syncAll("smart"),
    retryGaps: () => syncAll("smart", { forceRetries: true }),
    syncFull: () => syncAll("full"),
    /* Chế độ Backlog: chỉ status chưa xong, không detail, không media, không catalog. */
    syncBacklog: () => syncAll("smart", { scope: "backlog" }),
    /* v2.6: mọi mục TikiNOW Center, gộp nhiều account */
    listSections,
    syncSection: key => syncSectionForAllAccounts(key),
    sectionRows,
    /* v2.7: nguồn dữ liệu cho bộ nối chéo */
    orderRows: async () => (await getAll("orders")).map(orderMasterRow),
    orderCount: () => countStore("orders"),
    /* Backlog + detail cho đúng những đơn backlog (khi cần timeline để soi nghẽn). */
    syncBacklogDeep: () => syncAll("smart", { scope: "backlog", withDetail: true }),
    refresh: refreshHub,
    exportExcel,
    backupJson,
    normalizeOrder,
    extractEvents,
    journeyFrom,
    extractVideos,
    videoCategory
  };

  init().catch(e => {
    console.error("Tiki Data Hub init", e);
    log(`Data Hub init lỗi: ${e.message}`, "err");
  });
})(self);
