/* ============ Dashboard controller ============ */
const CFG = self.TNSL_CONFIG, E = self.BacklogEngine, C = self.Collector;
let ROWS = [], SUMMARY = null, SORT = { key: 'age_h', dir: -1 }, FILTER = {};

const $ = s => document.querySelector(s);
const el = (t, c, h) => { const e = document.createElement(t); if (c) e.className = c; if (h != null) e.innerHTML = h; return e; };
const fmtN = n => (n == null ? '—' : n.toLocaleString('vi-VN'));

const FLAG_ORDER = ['no_label','confirm_overdue','processing_overdue','handover_overdue','shipping_stuck','issue_return'];
const FLAG_CLASS = { no_label:'t-blue', confirm_overdue:'t-amber', processing_overdue:'t-amber',
  handover_overdue:'t-red', shipping_stuck:'t-red', issue_return:'t-purple' };

/* ---- SLA editor ---- */
function renderSLA() {
  const box = $('#slaBox'); box.innerHTML = '';
  const defs = [['confirm_h','Xác nhận'],['processing_h','Xử lý'],['handover_h','Bàn giao'],['shipping_h','Vận chuyển']];
  defs.forEach(([k, lab]) => {
    const wrap = el('label', null, lab + ' ≤');
    const inp = el('input'); inp.type = 'number'; inp.value = CFG.sla[k]; inp.min = 1;
    inp.onchange = () => { CFG.sla[k] = +inp.value || CFG.sla[k]; recompute(); };
    wrap.appendChild(inp); wrap.appendChild(document.createTextNode('h')); box.appendChild(wrap);
  });
}

/* ---- Token / collect ---- */
let ACCOUNT_SEL = null; // null = tất cả account; Set(sid) = chỉ các account được chọn
async function loadAccountSel(){
  try { const { accountSel } = await chrome.storage.local.get('accountSel');
    ACCOUNT_SEL = (Array.isArray(accountSel) && accountSel.length) ? new Set(accountSel.map(String)) : null;
  } catch(e){ ACCOUNT_SEL = null; }
}
async function getAllTokens() {
  if (typeof chrome === 'undefined' || !chrome.runtime) return {};
  return new Promise(res => chrome.runtime.sendMessage({ type: 'GET_TOKENS' }, r => res(r || {})));
}
async function getTokens() {
  const all = await getAllTokens();
  if (!ACCOUNT_SEL) return all;
  const out = {}; Object.keys(all).forEach(sid => { if (ACCOUNT_SEL.has(String(sid))) out[sid] = all[sid]; });
  return out;
}

async function refresh() {
  const btn = $('#refreshBtn'); btn.disabled = true;
  if (self.__DEMO) { RAW = self.__DEMO; recompute(); $('#status').textContent = 'CHẾ ĐỘ DEMO · dữ liệu mẫu'; btn.disabled = false; return; }
  const tokens = await getTokens();
  const ids = Object.keys(tokens);
  if (!ids.length) {
    $('#status').textContent = 'Chưa bắt được token nào.';
    $('#tokenWarn').innerHTML = warnBox('Chưa có token. Mở TikiNOW Center, đăng nhập (và switch qua từng account cần theo dõi) rồi bấm “Kéo dữ liệu”.');
    btn.disabled = false; return;
  }
  $('#tokenWarn').innerHTML = '';
  $('#status').textContent = `Đang kéo ${ids.length} account…`;
  const res = await C.collectAll(tokens, {
    onProgress: (sid, st, n) => { $('#status').textContent = `Account ${nameOf(sid)} · ${st}: ${n} đơn…`; }
  });
  RAW = res;
  const errIds = Object.keys(res.errors);
  recompute();
  const short = Object.keys(res.pulled || {}).filter(sid =>
    res.truncated[sid] || ((res.expected[sid] || 0) - (res.pulled[sid] || 0)) > Math.max(5, (res.expected[sid]||0)*0.02));
  const totalPulled = Object.values(res.pulled||{}).reduce((a,b)=>a+b,0);
  const totalExp = Object.values(res.expected||{}).reduce((a,b)=>a+b,0);
  let warn = errIds.length ? warnBox('Lỗi ở account: ' + errIds.map(i => `${nameOf(i)} (${res.errors[i]})`).join('; ')) : '';
  if (short.length) warn += warnBox('Kéo CHƯA đủ ở: ' + short.map(i => `${nameOf(i)} (kéo ${fmtN(res.pulled[i])}/${fmtN(res.expected[i])}${res.truncated[i]?' · chạm trần trang':''})`).join('; ') + '. Tăng <code>maxPagesPerAccount</code> trong config.js nếu chạm trần, hoặc refresh token account đó.');
  $('#tokenWarn').innerHTML = warn;
  const wlabel = (CFG.dateRange && CFG.dateRange.mode === 'all') ? 'Toàn thời gian' : `${res.window.from.slice(0,10)} → ${res.window.to.slice(0,10)}`;
  $('#status').textContent = `Cập nhật ${new Date().toLocaleTimeString('vi-VN')} · kéo ${fmtN(totalPulled)}/${fmtN(totalExp)} đơn · ${wlabel}`;
  btn.disabled = false;
}
let RAW = { rawBySeller: {}, counts: {}, errors: {}, window: {} };

function nameOf(sid) { return (CFG.accountNames && CFG.accountNames[sid]) || sid; }
function warnBox(msg) { return `<div class="panel" style="border-color:var(--amber);margin-bottom:16px">⚠️ ${msg}</div>`; }

/* ---- Compute + render ---- */
function recompute() {
  const all = E.normalizeAll(RAW.rawBySeller, CFG, new Date());
  ROWS = all.filter(r => r.is_backlog);
  SUMMARY = E.summarize(ROWS, CFG);
  renderAll();
}

function renderAll() { renderBacklogInsight(); renderCards(); renderBrandBreakdown(); renderFlagBars(); renderBucketBars(); renderAccTable(); renderWhTable(); renderFilters(); renderOrders(); }

function renderCards() {
  const s = SUMMARY, c = $('#cards'); c.innerHTML = '';
  const items = [
    ['blue', s.total, 'Tổng đơn backlog'],
    ['red', s.byFlag.no_label, 'Chưa có nhãn VC'],
    ['red', s.byFlag.handover_overdue, 'Chưa bàn giao'],
    ['amber', s.byFlag.processing_overdue + s.byFlag.confirm_overdue, 'Xử lý/XN quá SLA'],
    ['red', s.byFlag.shipping_stuck, 'Kẹt vận chuyển'],
    ['purple', s.byFlag.issue_return, 'Lỗi hàng / hoàn'],
    ['amber', s.byBucket.gt72, 'Đơn > 72h']
  ];
  items.forEach(([cls, n, l]) => { const d = el('div', 'card ' + cls); d.appendChild(el('div', 'n', fmtN(n))); d.appendChild(el('div', 'l', l)); c.appendChild(d); });
}

function bars(container, entries, total, colorFn) {
  const box = $(container); box.innerHTML = '';
  const max = Math.max(1, ...entries.map(e => e[1]));
  entries.forEach(([lab, val]) => {
    const row = el('div', 'bar');
    row.appendChild(el('div', 'lab', lab));
    const track = el('div', 'track'); const fill = el('div', 'fill');
    fill.style.width = (val / max * 100) + '%'; fill.style.background = colorFn(lab, val);
    track.appendChild(fill); row.appendChild(track);
    row.appendChild(el('div', 'val', fmtN(val))); box.appendChild(row);
  });
}
function renderFlagBars() {
  bars('#flagBars', FLAG_ORDER.map(k => [E.FLAG_LABELS[k], SUMMARY.byFlag[k]]), SUMMARY.total,
    lab => lab.includes('nhãn') || lab.includes('bàn giao') || lab.includes('Kẹt') ? 'var(--red)'
         : lab.includes('hoàn') ? 'var(--purple)' : 'var(--amber)');
}
function renderBucketBars() {
  const map = { '< 24h':'var(--green)', '24–48h':'#fcd34d', '48–72h':'var(--amber)', '> 72h':'var(--red)' };
  bars('#bucketBars', CFG.agingBuckets.map(b => [b.label, SUMMARY.byBucket[b.key]]), SUMMARY.total, lab => map[lab] || 'var(--blue)');
}

function tableFrom(headers, rows) {
  const t = el('table'); const thead = el('thead'); const tr = el('tr');
  headers.forEach(h => tr.appendChild(el('th', null, h))); thead.appendChild(tr); t.appendChild(thead);
  const tb = el('tbody'); rows.forEach(r => { const x = el('tr'); r.forEach(c => x.appendChild(el('td', null, c))); tb.appendChild(x); }); t.appendChild(tb);
  return t;
}
function renderAccTable() {
  const box = $('#accTable'); box.innerHTML = '';
  if (self.UnifiedAnalysis) { const rows = Object.keys(RAW.rawBySeller || {}).map(sid => [nameOf(sid),fmtN((RAW.rawBySeller[sid] || []).length)]); box.appendChild(tableFrom(['Tài khoản','Backlog trong dữ liệu đã lưu'],rows)); return; }
  const sellers = Object.keys(RAW.pulled || {});
  if (sellers.length) {
    const rows = sellers.map(sid => {
      const backlog = ROWS.filter(r => r.seller_id === sid).length;
      const pulled = (RAW.pulled[sid] || 0), exp = (RAW.expected[sid] || 0);
      const shortN = exp - pulled;
      const flag = (RAW.truncated && RAW.truncated[sid]) ? '<span style="color:var(--red)">chạm trần</span>'
        : (shortN > Math.max(5, exp*0.02)) ? `<span style="color:var(--red)">-${fmtN(shortN)}</span>`
        : '<span style="color:var(--green)">✓ đủ</span>';
      return { s: [nameOf(sid), fmtN(backlog), fmtN(pulled), fmtN(exp), flag], b: backlog };
    }).sort((a,b)=>b.b-a.b).map(x=>x.s);
    box.appendChild(tableFrom(['Account','Backlog','Kéo về','Kỳ vọng','Đủ?'], rows));
  } else {
    const rows = Object.entries(SUMMARY.byAccount).sort((a,b)=>b[1].backlog-a[1].backlog)
      .map(([acc, v]) => [acc, fmtN(v.backlog), fmtN(v.total)]);
    box.appendChild(tableFrom(['Account','Backlog','Tổng kéo về'], rows.length?rows:[['—','0','0']]));
  }
}
function renderWhTable() {
  const box = $('#whTable'); box.innerHTML = '';
  const wh = Object.entries(SUMMARY.byWarehouse).sort((a,b)=>b[1]-a[1]).slice(0,8).map(([k,v])=>['Kho', k, fmtN(v)]);
  const pf = Object.entries(SUMMARY.byPlatform).sort((a,b)=>b[1]-a[1]).slice(0,8).map(([k,v])=>['Sàn', k, fmtN(v)]);
  box.appendChild(tableFrom(['Loại','Tên','Backlog'], [...wh, ...pf].length?[...wh,...pf]:[['—','—','0']]));
}

/* ---- Filters + order table ---- */
function uniq(key) { return [...new Set(ROWS.map(r => r[key]).filter(Boolean))].sort(); }
function renderFilters() {
  const box = $('#filters'); box.innerHTML = '';
  const mk = (key, label, opts) => {
    const s = el('select'); s.appendChild(el('option', null, label));
    opts.forEach(o => { const op = el('option', null, o); op.value = o; if (FILTER[key]===o) op.selected=true; s.appendChild(op); });
    s.onchange = () => { FILTER[key] = s.value || null; renderOrders(); }; box.appendChild(s);
  };
  mk('brand','— Brand —', uniq('brand'));
  mk('group_brand','— Group brand —', uniq('group_brand'));
  mk('channel_map','— Channel —', uniq('channel_map'));
  mk('account','— Account —', uniq('account'));
  mk('warehouse','— Kho —', uniq('warehouse'));
  mk('platform','— Sàn —', uniq('platform'));
  const fs = el('select'); fs.appendChild(el('option', null, '— Loại backlog —'));
  FLAG_ORDER.forEach(k => { const op = el('option', null, E.FLAG_LABELS[k]); op.value = k; if (FILTER.flag===k) op.selected=true; fs.appendChild(op); });
  fs.onchange = () => { FILTER.flag = fs.value || null; renderOrders(); }; box.appendChild(fs);
  const clr = el('button', 'ghost', 'Xoá lọc'); clr.style.padding='6px 10px'; clr.onclick = () => { FILTER = {}; renderFilters(); renderOrders(); }; box.appendChild(clr);
}
function filtered() {
  return ROWS.filter(r =>
    (!FILTER.account || r.account === FILTER.account) &&
    (!FILTER.brand || r.brand === FILTER.brand) &&
    (!FILTER.group_brand || r.group_brand === FILTER.group_brand) &&
    (!FILTER.channel_map || r.channel_map === FILTER.channel_map) &&
    (!FILTER.warehouse || r.warehouse === FILTER.warehouse) &&
    (!FILTER.platform || r.platform === FILTER.platform) &&
    (!FILTER.flag || r.flags.includes(FILTER.flag)));
}
const COLS = [
  ['order_code','Mã đơn'], ['ref_code','Mã đối tác'], ['brand','Brand'], ['group_brand','Group brand'], ['channel_map','Channel'], ['opollo_channel','Opollo Channel'], ['account','Account'],
  ['sub_label','Trạng thái'], ['age_h','Tuổi (h)'], ['stage_age_h','Ở khâu (h)'],
  ['warehouse','Kho'], ['platform','Sàn'], ['carrier','ĐVVC'], ['flags','Cờ backlog']
];
function renderOrders() {
  const t = $('#ordTable'); t.innerHTML = '';
  const data = filtered().sort((a,b) => {
    const k = SORT.key; let av=a[k], bv=b[k];
    if (typeof av==='number'||typeof bv==='number'){av=av??-1;bv=bv??-1;return (av-bv)*SORT.dir;}
    return String(av).localeCompare(String(bv))*SORT.dir;
  });
  const thead = el('thead'); const tr = el('tr');
  COLS.forEach(([k, lab]) => { const th = el('th', null, lab + (SORT.key===k?(SORT.dir<0?' ▾':' ▴'):''));
    th.onclick = () => { if(SORT.key===k)SORT.dir*=-1;else{SORT.key=k;SORT.dir=-1;} renderOrders(); }; tr.appendChild(th); });
  thead.appendChild(tr); t.appendChild(thead);
  const tb = el('tbody');
  if (!data.length) { const tr2 = el('tr'); const td = el('td'); td.colSpan = COLS.length; td.className='empty';
    td.textContent = ROWS.length? 'Không có đơn khớp bộ lọc.' : 'Chưa có dữ liệu — bấm “Kéo dữ liệu”.'; tr2.appendChild(td); tb.appendChild(tr2); }
  data.slice(0, 500).forEach(r => {
    const tr2 = el('tr');
    COLS.forEach(([k]) => {
      if (k === 'flags') { const td = el('td'); r.flags.forEach(f => td.appendChild(el('span','tag '+(FLAG_CLASS[f]||'t-blue'), E.FLAG_LABELS[f]))); tr2.appendChild(td); }
      else if (k === 'age_h') { const td = el('td','age '+(r.bucket||''), r.age_h==null?'—':r.age_h); tr2.appendChild(td); }
      else tr2.appendChild(el('td', null, r[k] == null ? '—' : r[k]));
    });
    tb.appendChild(tr2);
  });
  t.appendChild(tb);
}

/* ---- CSV ---- */
function toCSV() {
  const head = COLS.map(c => c[1]).join(',');
  const lines = filtered().map(r => COLS.map(([k]) =>
    k==='flags' ? '"'+r.flags.map(f=>E.FLAG_LABELS[f]).join(' | ')+'"'
    : '"'+String(r[k]==null?'':r[k]).replace(/"/g,'""')+'"').join(','));
  return head + '\n' + lines.join('\n');
}
function downloadCSV() {
  const blob = new Blob(['﻿' + toCSV()], { type: 'text/csv' });
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob);
  a.download = `tikinow-backlog-${new Date().toISOString().slice(0,10)}.csv`; a.click();
}

/* ---- init ---- */
if($('#refreshBtn')) $('#refreshBtn').onclick = refresh;
if($('#csvBtn')) $('#csvBtn').onclick = downloadCSV;
window.addEventListener('error', function(e){
  try{ var b=document.body; if(!b) return; var id='__err'; var d=document.getElementById(id)||document.createElement('div');
    d.id=id; d.style.cssText='position:fixed;bottom:0;left:0;right:0;z-index:99999;background:#7f1d1d;color:#fff;padding:8px 12px;font:12px system-ui'; 
    d.textContent='⚠ Lỗi: '+(e.message||'')+' — thử: đóng tab, reload extension ở chrome://extensions, mở Dashboard lại.'; b.appendChild(d);
  }catch(_){} });
try {
  renderSLA(); recompute();
  // Video Evidence/Data Trust Hub v2.2.0 là màn hình mặc định: không tự kéo backlog legacy khi vừa mở app.
  // Director sẽ tải khi người dùng chuyển tab hoặc bấm cập nhật.
  if ($('#viewDirector') && $('#viewDirector').style.display !== 'none') dirRefresh(false);
  else if ($('#dirStatus')) $('#dirStatus').textContent = 'Chưa tải · mở tab Director để cập nhật';
}
catch(e){ console.error('init', e); var d=document.createElement('div');
  d.style.cssText='margin:20px;padding:14px;border:1px solid #ef4444;border-radius:8px;color:#fca5a5;background:#1e293b;font:13px system-ui';
  d.textContent='Lỗi khởi tạo: '+e.message+'. Hãy đóng tab này, vào chrome://extensions bấm reload extension, rồi mở Dashboard lại.';
  (document.body||document.documentElement).appendChild(d); }

/* ================= TAB SWITCHING ================= */
let RAW_PROD = { rawBySeller: {}, errors: {}, window: {} }, PROD = null, PROD_WH = '', PROD_LOADED = false;
document.querySelectorAll('.tab').forEach(t => t.onclick = () => {
  document.querySelectorAll('.tab').forEach(x => x.classList.remove('active'));
  t.classList.add('active');
  const v = t.dataset.view;
  $('#viewBacklog').style.display = v === 'backlog' ? '' : 'none';
  $('#viewProd').style.display = v === 'prod' ? '' : 'none';
  $('#viewCycle').style.display = v === 'cycle' ? '' : 'none';
  $('#viewDirector').style.display = v === 'director' ? '' : 'none';
  $('#viewAtRisk').style.display = v === 'atrisk' ? '' : 'none';
  if (v === 'prod' && !PROD_LOADED) prodRefresh();
  if (v === 'cycle' && !CYC_LOADED) cycRefresh();
  $('#viewFlow').style.display = v === 'flow' ? '' : 'none';
  $('#viewTrend').style.display = v === 'trend' ? '' : 'none';
  $('#viewRshipment').style.display = v === 'rshipment' ? '' : 'none';
  $('#viewShip').style.display = v === 'ship' ? '' : 'none';
  $('#viewOutcome').style.display = v === 'outcome' ? '' : 'none';
  $('#viewExport').style.display = v === 'export' ? '' : 'none';
  if (v === 'ship' && !SHIP_LOADED) shipRefresh();
  if (v === 'outcome' && !OUT_LOADED) outRefresh();
  if (v === 'export') expRefresh();
  if (v === 'trend') trendRefresh();
  if (v === 'director') dirRefresh(false);
  if (v === 'atrisk') arRefresh();
  if (v === 'flow') flowRefresh();
  if (v === 'rshipment') rsInit();
});

/* ================= PRODUCTIVITY ================= */
async function prodRefresh() {
  const btn = $('#prodRefreshBtn'); btn.disabled = true;
  $('#prodStatus').textContent = 'Đang kéo…';
  if (self.__DEMO_PROD) { RAW_PROD = self.__DEMO_PROD; PROD_LOADED = true; computeProd();
    $('#prodStatus').textContent = 'CHẾ ĐỘ DEMO'; btn.disabled = false; return; }
  const tokens = await getTokens();
  if (!Object.keys(tokens).length) { $('#prodStatus').textContent = 'Chưa có token — sang tab Backlog kéo trước.'; btn.disabled = false; return; }
  RAW_PROD = await C.collectProductivity(tokens, {
    onProgress: (sid, st, n) => { $('#prodStatus').textContent = `${nameOf(sid)} · ${st}: ${n}…`; }
  });
  PROD_LOADED = true;
  computeProd();
  const total = Object.values(RAW_PROD.rawBySeller).reduce((a, b) => a + b.length, 0);
  const w = RAW_PROD.window || {};
  $('#prodStatus').textContent = `Kéo ${fmtN(total)} đơn · ${(w.from||'').slice(0,10)} → ${(w.to||'').slice(0,10)}`;
  btn.disabled = false;
}

function prodOrders() {
  const all = [];
  for (const sid of Object.keys(RAW_PROD.rawBySeller || {})) all.push(...RAW_PROD.rawBySeller[sid]);
  return PROD_WH ? all.filter(o => whCode(o) === PROD_WH) : all;
}
function whCode(o){ const w=o.warehouse; if(!w) return 'N/A'; if(typeof w==='string') return w; return w.code||w.name||w.id||'N/A'; }

// Map mã kho -> tên thân thiện (vd 'tbn1' -> 'WH-TanBinh1') để hiển thị dễ đọc.
let WH_NAMES = {};
function buildWhNames() {
  WH_NAMES = {};
  for (const sid of Object.keys(RAW_PROD.rawBySeller || {}))
    for (const o of RAW_PROD.rawBySeller[sid]) {
      const w = o.warehouse;
      if (w && typeof w === 'object' && w.code) WH_NAMES[w.code] = w.name || w.code;
    }
}
function whLabel(code){ return WH_NAMES[code] || code; }

function computeProd() {
  buildWhNames();
  PROD = E.buildProductivity(prodOrders(), CFG, new Date());
  if ($('#prodThresh').value === '' || $('#prodThresh').dataset.auto !== '0') {
    $('#prodThresh').value = PROD.lowThresh; $('#prodThresh').dataset.auto = '1';
  }
  buildWhDropdown();
  renderProd();
}

function buildWhDropdown() {
  const sel = $('#prodWh'); const cur = sel.value;
  // sắp theo TÊN kho cho dễ tìm
  const whs = [...new Set(prodAllWarehouses())].sort((a,b)=>whLabel(a).localeCompare(whLabel(b)));
  sel.innerHTML = '<option value="">— Tất cả kho —</option>' + whs.map(w => `<option value="${w}">${whLabel(w)}</option>`).join('');
  sel.value = cur;
}
function prodAllWarehouses() {
  const all = []; for (const sid of Object.keys(RAW_PROD.rawBySeller || {})) for (const o of RAW_PROD.rawBySeller[sid]) all.push(whCode(o));
  return all;
}

function effThresh(){ const v = parseInt($('#prodThresh').value, 10); return isNaN(v) ? PROD.lowThresh : v; }

function renderProd() {
  if (!PROD) return;
  renderProdInsight();
  const thr = effThresh();
  // KPI cards
  const activeHrsPerDay = (PROD.activeTo - PROD.activeFrom + 1);
  const avgPerHour = Math.round(PROD.totals.activity / Math.max(1, PROD.days.length * activeHrsPerDay));
  const low = countLow(thr);
  const c = $('#prodCards'); c.innerHTML = '';
  [['blue', fmtN(PROD.totals.activity), 'Throughput (thao tác)'],
   ['green', fmtN(PROD.totals.dispatched), 'Đơn xuất (dispatch)'],
   ['amber', fmtN(PROD.totals.inflow), 'Đơn vào (inflow)'],
   ['blue', fmtN(avgPerHour), 'TB / giờ làm việc'],
   ['purple', PROD.peak.hour==null?'—':`${PROD.peak.hour}h`, `Giờ đỉnh (${fmtN(PROD.peak.activity)})`],
   ['red', fmtN(low), 'Giờ low-performance']
  ].forEach(([cls, n, l]) => { const d = el('div', 'card ' + cls); d.appendChild(el('div', 'n', n)); d.appendChild(el('div', 'l', l)); c.appendChild(d); });

  renderHeatmap(thr);
  renderProdDaily(thr);
  renderProdWh();
  renderHourlyBalance();
  renderPackForecast();
}

/* ---- Inflow vs Outbound theo giờ ---- */
function renderHourlyBalance(){
  if(!PROD || !$('#hbTable')) return;
  const HB = E.buildHourlyBalance(PROD, CFG);
  if(!HB){ if($('#hbHead')) $('#hbHead').innerHTML=''; return; }
  const pin = HB.peakIn.hour, pout = HB.peakOut.hour, lag = HB.phaseLagH;
  const st = HB.peakCarry > 0 ? (lag && lag>0 ? 'amber' : 'amber') : 'green';
  // Khuyến nghị theo độ lệch pha (đúng bản chất: ùn do xử lý trễ hơn nhịp đơn tới)
  let rec = '';
  if (pin!=null && pout!=null) {
    if (lag > 0) rec = `Đơn <b>dồn về</b> đỉnh lúc <b>${pin}h</b> nhưng <b>xuất mạnh</b> mãi <b>${pout}h</b> (trễ ${lag} giờ) → dồn người/ưu tiên đóng <b>sớm hơn</b>, kéo công suất về khung <b>${pin}h–${pout}h</b> để không ùn.`;
    else if (lag < 0) rec = `Xuất đỉnh (${pout}h) SỚM hơn đơn về đỉnh (${pin}h) → nhịp xử lý đang tốt, canh giữ công suất quanh ${pin}h.`;
    else rec = `Nhịp vào & xuất khá đồng pha quanh ${pin}h.`;
  }
  $('#hbHead').innerHTML = `<div class="banner ${st}" style="margin-bottom:12px"><span class="dot"></span>
    <span class="big">${HB.peakCarry>0?'Có ùn theo giờ':'Dòng chảy cân'}</span>
    <span style="color:var(--mut);font-weight:600">TB/ngày: vào ${fmtN(HB.totIn)} · xuất ${fmtN(HB.totOut)} · <b>ùn (WIP) đỉnh ${fmtN(HB.peakCarry)} lúc ${HB.peakHour!=null?HB.peakHour+'h':'—'}</b></span></div>`
    + (rec ? `<div style="font-size:12px;margin-bottom:4px">🕒 ${rec}</div>` : '')
    + `<div style="font-size:11px;color:var(--mut)">⚠ Đây là <b>nhịp dòng chảy</b> (đơn vào ≠ đơn ra cùng giờ do có lead-time). Con số <b>“cần thêm mấy người”</b> lấy ở mục <b>Công suất vs Hạn SLA</b> bên dưới (tính theo hạn đóng gói) — đó mới là tín hiệu bố trí người chuẩn.</div>`;
  // Bars: nền = WIP ùn luỹ kế (đỏ); overlay 2 cột mảnh Vào (xanh dương) / Xuất (xanh lá).
  const fb = el('div','fbar');
  const mxBar = Math.max(1, ...HB.active.map(r=>Math.max(r.inflow, r.outbound)));
  const mxCarry = Math.max(1, HB.peakCarry);
  HB.active.forEach(r=>{
    const col = el('div','col');
    col.appendChild(el('div','cap', r.carry? ('ùn '+r.carry):''));
    const wrap = el('div'); wrap.style.cssText='flex:1;position:relative;display:flex;gap:2px;align-items:flex-end;width:100%';
    // nền WIP
    const bg = el('div'); bg.style.cssText=`position:absolute;left:0;right:0;bottom:0;height:${Math.round((r.carry||0)/mxCarry*100)}%;background:rgba(239,68,68,.18);border-radius:3px 3px 0 0`;
    const bi = el('div'); bi.style.cssText=`position:relative;flex:1;background:var(--blue);border-radius:3px 3px 0 0;height:${Math.round(r.inflow/mxBar*100)}%;min-height:2px`; bi.title='Đơn vào '+r.inflow;
    const bo = el('div'); bo.style.cssText=`position:relative;flex:1;background:var(--green);border-radius:3px 3px 0 0;height:${Math.round(r.outbound/mxBar*100)}%;min-height:2px`; bo.title='Đơn xuất '+r.outbound;
    wrap.appendChild(bg); wrap.appendChild(bi); wrap.appendChild(bo);
    col.appendChild(wrap);
    col.appendChild(el('div','hr', r.hour+'h'));
    fb.appendChild(col);
  });
  $('#hbBars').innerHTML=''; $('#hbBars').appendChild(fb);
  const rows = HB.active.map(r=>[ r.hour+'h', fmtN(r.inflow), fmtN(r.outbound),
    (r.net<0?`<span style="color:#fca5a5">${r.net}</span>`:(r.net>0?`<span style="color:#4ade80">+${r.net}</span>`:'0')),
    r.carry>0?`<b style="color:#fcd34d">${fmtN(r.carry)}</b>`:'0', fmtN(r.throughput),
    r.carry>=HB.peakCarry&&r.carry>0?'<span class="tag t-red">Ùn đỉnh</span>':(r.net<0?'<span class="tag t-amber">Đang phình</span>':(r.carry>0?'<span class="tag t-amber">Còn ùn</span>':'<span class="tag t-blue">Thoát</span>')) ]);
  $('#hbTable').innerHTML=''; $('#hbTable').appendChild(tableFrom(['Giờ','Đơn vào','Đơn xuất','Nhịp (ra−vào)','WIP ùn (luỹ kế)','Thao tác/giờ','Trạng thái'], rows));
}

/* ---- Công suất vs Hạn đóng gói ---- */
let PF = null;
function renderPackForecast() {
  if (!PROD) return;
  const capV = parseInt($('#pfCap').value, 10);
  const horizon = Math.max(1, parseInt($('#pfHorizon').value, 10) || 12);
  const perPerson = Math.max(1, parseInt($('#pfPerPerson').value, 10) || 12);
  PF = E.buildPackForecast(prodOrders(), PROD, CFG, new Date(), {
    capacity: (!isNaN(capV) && capV > 0) ? capV : null, horizonHours: horizon, perPersonRate: perPerson
  });

  // Verdict banner
  const bad = PF.predictedLate + PF.overdueNow;
  const st = PF.verdict;
  const msg = st === 'green' ? 'KỊP SLA ĐÓNG GÓI' : (st === 'amber' ? 'CÓ RỦI RO TRỄ' : 'SẼ TRỄ SLA — CẦN HÀNH ĐỘNG');
  const capNote = PF.capManual ? 'công suất nhập tay' : 'công suất tự đo (median đơn xuất/giờ)';
  $('#pfVerdict').innerHTML = `<div class="banner ${st}" style="margin-bottom:14px"><span class="dot"></span>
    <span class="big">${msg}</span>
    <span style="color:var(--mut);font-weight:600">${fmtN(PF.pending)} đơn chờ đóng · công suất ${fmtN(PF.cap)}/giờ (${capNote}) · dự báo ${fmtN(bad)} đơn trễ</span></div>`;

  // KPI
  const gapCls = PF.gap > 0 ? 'red' : 'green';
  $('#pfKpi').innerHTML = `
    <div class="k blue"><div class="v">${fmtN(PF.cap)}</div><div class="t">Công suất đóng/giờ (đo ${fmtN(PF.capMeasured)})</div></div>
    <div class="k ${PF.overdueNow ? 'red' : 'green'}"><div class="v">${fmtN(PF.overdueNow)}</div><div class="t">Đã QUÁ HẠN đóng (cần làm ngay)</div></div>
    <div class="k ${PF.predictedLate ? 'red' : 'green'}"><div class="v">${fmtN(PF.predictedLate)}</div><div class="t">Dự báo TRỄ nếu giữ nhịp</div></div>
    <div class="k ${gapCls}"><div class="v">${PF.gap > 0 ? '+' + fmtN(PF.gap) : '0'}</div><div class="t">Cần bù (đơn/giờ) — cần ${fmtN(PF.requiredRate)}/giờ</div></div>
    <div class="k ${PF.peopleNeeded ? 'amber' : 'green'}"><div class="v">${PF.peopleNeeded ? '+' + fmtN(PF.peopleNeeded) : '0'}</div><div class="t">≈ người cần thêm (${PF.perPerson} đơn/người/giờ)</div></div>`;

  // Bars: đơn tới hạn theo giờ (đỏ nếu dồn quá tải luỹ kế)
  const fb = el('div', 'fbar'); const maxD = Math.max(1, PF.cap, ...PF.hours.map(h => h.due));
  PF.hours.forEach(h => {
    const col = el('div', 'col' + (h.short > 0 ? ' hot' : ''));
    col.appendChild(el('div', 'cap', h.due ? fmtN(h.due) : ''));
    const bar = el('div', 'bar2'); bar.style.height = (h.due / maxD * 100) + '%';
    col.appendChild(bar);
    col.appendChild(el('div', 'hr', h.hour + 'h'));
    fb.appendChild(col);
  });
  $('#pfBars').innerHTML = ''; $('#pfBars').appendChild(fb);

  // Per-WH table
  const rows = PF.perWh.slice(0, 30).map(w => [
    whLabel(w.wh),
    fmtN(w.pending),
    w.overdue ? `<span class="age gt72">${fmtN(w.overdue)}</span>` : '0',
    w.due2h ? `<span class="age h24_48">${fmtN(w.due2h)}</span>` : '0',
    fmtN(w.cap),
    w.gap > 0 ? `<b style="color:var(--red)">+${fmtN(w.gap)}/h</b>` : '<span style="color:var(--green)">đủ</span>',
    w.people > 0 ? `<b style="color:var(--amber)">+${fmtN(w.people)}</b>` : '—'
  ]);
  $('#pfWh').innerHTML = '';
  $('#pfWh').appendChild(tableFrom(['Kho', 'Chờ đóng', 'Quá hạn', 'Đến hạn ≤2h', 'CS/giờ', 'Cần bù', '+Người'],
    rows.length ? rows : [['—', '0', '0', '0', '0', 'đủ', '—']]));
}
['#pfCap', '#pfHorizon', '#pfPerPerson'].forEach(id => {
  const e = $(id); if (e) e.addEventListener('input', () => { if (PROD) renderPackForecast(); });
});

function countLow(thr) {
  let n = 0; PROD.days.forEach(d => { for (let h = PROD.activeFrom; h <= PROD.activeTo; h++) if (PROD.grid[d][h].activity < thr) n++; });
  return n;
}

function heatColor(v, max) {
  if (v <= 0) return '#0b1220';
  const r = Math.min(1, v / (max || 1));
  return `hsl(145, 58%, ${28 + r * 42}%)`; // xanh: thấp tối, cao sáng
}
function renderHeatmap(thr) {
  const metric = $('#prodMetric').value;
  const t = $('#prodHeat'); t.innerHTML = '';
  // max của metric để scale màu
  let max = 1;
  PROD.days.forEach(d => { for (let h = 0; h < 24; h++) max = Math.max(max, PROD.grid[d][h][metric]); });
  const thead = el('thead'); const htr = el('tr'); htr.appendChild(el('th', null, ''));
  for (let h = 0; h < 24; h++) htr.appendChild(el('th', null, h)); thead.appendChild(htr); t.appendChild(thead);
  const tb = el('tbody');
  PROD.days.forEach(d => {
    const tr = el('tr'); tr.appendChild(el('td', 'd', d.slice(5))); // MM-DD
    for (let h = 0; h < 24; h++) {
      const cell = PROD.grid[d][h]; const v = cell[metric];
      const td = el('td');
      const div = el('div', 'cell' + (v === 0 ? ' zero' : ''), v || '');
      const inActive = h >= PROD.activeFrom && h <= PROD.activeTo;
      if (metric === 'activity' && inActive && cell.activity < thr) div.classList.add('low');
      div.style.background = heatColor(v, max);
      div.title = `${d} ${h}h · throughput ${cell.activity} · inflow ${cell.inflow} · dispatch ${cell.dispatched}`;
      td.appendChild(div); tr.appendChild(td);
    }
    tb.appendChild(tr);
  });
  t.appendChild(tb);
  $('#prodLegend').innerHTML =
    `<span><span class="swatch" style="background:${heatColor(1,max)}"></span>thấp</span>
     <span><span class="swatch" style="background:${heatColor(max,max)}"></span>cao</span>
     <span><span class="swatch" style="outline:2px solid var(--red);background:#0b1220"></span>low-performance (throughput &lt; ${thr}/giờ, khung ${PROD.activeFrom}–${PROD.activeTo}h)</span>
     <span style="color:var(--mut)">median ${PROD.median}/giờ</span>`;
}

function renderProdDaily(thr) {
  const box = $('#prodDaily'); box.innerHTML = '';
  const rows = PROD.daily.map(d => {
    let lowH = 0; for (let h = PROD.activeFrom; h <= PROD.activeTo; h++) if (PROD.grid[d.day][h].activity < thr) lowH++;
    const lowTag = lowH ? `<span style="color:var(--red);font-weight:700">${lowH}</span>` : '<span style="color:var(--green)">0</span>';
    return [d.day, fmtN(d.activity), fmtN(d.dispatched), fmtN(d.inflow), lowTag];
  });
  box.appendChild(tableFrom(['Ngày','Throughput','Dispatch','Inflow','Giờ low'], rows));
}
function renderProdWh() {
  const box = $('#prodWhTable'); box.innerHTML = '';
  const activeHrs = Math.max(1, (PROD.activeTo - PROD.activeFrom + 1) * PROD.days.length);
  const rows = Object.entries(PROD.byWh).sort((a,b)=>b[1].activity-a[1].activity)
    .map(([w, v]) => [whLabel(w), fmtN(v.activity), fmtN(Math.round(v.activity/activeHrs)), fmtN(v.dispatched), fmtN(v.inflow)]);
  box.appendChild(tableFrom(['Kho','Throughput','TB/giờ','Dispatch','Inflow'], rows.length?rows:[['—','0','0','0','0']]));
}

/* prod controls */
if($('#prodRefreshBtn')) $('#prodRefreshBtn').onclick = prodRefresh;
$('#prodWh').onchange = () => { PROD_WH = $('#prodWh').value; computeProd(); };
$('#prodMetric').onchange = () => renderProd();
$('#prodThresh').oninput = () => { $('#prodThresh').dataset.auto = '0'; renderProd(); };

/* ================= CYCLE-TIME (từ lúc tạo) ================= */
let CYC = null, CYC_LOADED = false, CYC_RAW = { orders: [] };
function minLabel(m){ if(m==null) return '—'; if(m<60) return m+'′'; const h=Math.floor(m/60), mm=m%60; return h+'h'+(mm?(' '+mm+'′'):''); }

// Hiện tiến trình cycle lên cả tab Cycle và tab SLA (SLA dùng chung dữ liệu này).
function cycSetStatus(t){ if($('#cycStatus')) $('#cycStatus').textContent=t; if($('#viewSla') && $('#viewSla').style.display!=='none' && $('#slaStatus')) $('#slaStatus').textContent=t; }
async function cycRefresh(){
  const btn = $('#cycRefreshBtn'); if(btn) btn.disabled = true;
  if ($('#cycSla').value === '') $('#cycSla').value = CFG.cycle.dwellTargetH;
  if (self.__DEMO_CYCLE) { CYC_RAW = self.__DEMO_CYCLE; CYC_LOADED = true; computeCyc(); cycSetStatus('CHẾ ĐỘ DEMO'); if(btn) btn.disabled=false; return; }
  try {
    const tokens = await getTokens();
    if (!Object.keys(tokens).length) { cycSetStatus('Chưa có token — sang tab Backlog kéo trước.'); return; }
    cycSetStatus('Đang kéo danh sách… (' + Object.keys(tokens).length + ' account)');
    CYC_RAW = await C.collectCycleTimes(tokens, {
      onPhase: (m) => { cycSetStatus(m); },
      onDetailProgress: (sid, n, total) => { cycSetStatus(`${nameOf(sid)}: kéo chi tiết ${n}/${total}…`); }
    });
    CYC_LOADED = true;
    computeCyc();
    const errs = Object.keys(CYC_RAW.errors || {});
    cycSetStatus(`${fmtN(CYC_RAW.orders.length)} đơn · cache ${fmtN(CYC_RAW.cacheSize||0)}` + (errs.length ? ' · lỗi: ' + errs.map(nameOf).join(', ') : ''));
  } catch(e){
    cycSetStatus('Lỗi kéo cycle-time: ' + (e && e.message || e) + ' — thử lại, hoặc giảm số account.');
  } finally { if(btn) btn.disabled = false; }
}
if($('#cycRefreshBtn')) $('#cycRefreshBtn').onclick = cycRefresh;
$('#cycSla').oninput = () => { CFG.cycle.dwellTargetH = parseInt($('#cycSla').value,10) || CFG.cycle.dwellTargetH; computeCyc(); };

function computeCyc(){ CYC = E.buildCycleStats(CYC_RAW.orders, CFG, new Date()); renderCyc(); }

function renderCyc(){
  if (!CYC) return;
  renderCycInsight();
  const c = $('#cycCards'); c.innerHTML='';
  const slaPct = CYC.withinSLA==null ? '—' : Math.round(CYC.withinSLA*100)+'%';
  [['blue', minLabel(CYC.dwellMedian), 'Dwell trung vị (tạo→bàn giao)'],
   ['amber', minLabel(CYC.dwellP90), 'Dwell P90'],
   ['green', slaPct, `Đạt SLA (≤${CFG.cycle.dwellTargetH}h)`],
   ['red', fmtN(CYC.breachCount), 'Đơn trễ SLA'],
   ['purple', CYC.bottleneck?CYC.bottleneck.label:'—', `Khâu nghẽn (${CYC.bottleneck?minLabel(CYC.bottleneck.median):'—'})`],
   ['blue', fmtN(CYC.measured), 'Đơn đo được']
  ].forEach(([cls,n,l])=>{ const d=el('div','card '+cls); d.appendChild(el('div','n',n)); d.appendChild(el('div','l',l)); c.appendChild(d); });

  // Stage bars (median minutes)
  const box=$('#cycStages'); box.innerHTML='';
  const max=Math.max(1,...CYC.stageStats.map(s=>s.median));
  CYC.stageStats.forEach(s=>{
    const row=el('div','bar');
    row.appendChild(el('div','lab', s.label));
    const track=el('div','track'); const fill=el('div','fill');
    fill.style.width=(s.median/max*100)+'%';
    fill.style.background = (CYC.bottleneck && s.key===CYC.bottleneck.key) ? 'var(--red)' : 'var(--blue)';
    track.appendChild(fill); row.appendChild(track);
    row.appendChild(el('div','val', minLabel(s.median)));
    box.appendChild(row);
  });

  renderCycHeat();
  // slowest table
  const st=$('#cycSlow'); st.innerHTML='';
  const rows=CYC.slowest.map(r=>[r.order_code, r.ref_code||'—', r.warehouse, `<span class="age ${r.breach?'gt72':''}">${minLabel(r.dwell_min)}</span>`,
    r.stages.pick!=null?minLabel(r.stages.pick):'—', r.stages.handover_wait!=null?minLabel(r.stages.handover_wait):'—']);
  st.appendChild(tableFrom(['Mã đơn','Mã đối tác','Kho','Dwell','Lấy hàng','Chờ bàn giao'], rows.length?rows:[['—','—','—','—','—','—']]));
  // wh table
  const wb=$('#cycWh'); wb.innerHTML='';
  const wr=CYC.whStats.map(w=>[w.wh, fmtN(w.n), minLabel(w.avg), w.breach?`<span style="color:var(--red)">${fmtN(w.breach)}</span>`:'0']);
  wb.appendChild(tableFrom(['Kho','Đơn','Dwell TB','Trễ SLA'], wr.length?wr:[['—','0','—','0']]));
}

function renderCycHeat(){
  const t=$('#cycHeat'); t.innerHTML='';
  let max=1; CYC.days.forEach(d=>{for(let h=0;h<24;h++)max=Math.max(max,CYC.grid[d][h]);});
  const thead=el('thead'); const htr=el('tr'); htr.appendChild(el('th',null,''));
  for(let h=0;h<24;h++) htr.appendChild(el('th',null,h)); thead.appendChild(htr); t.appendChild(thead);
  const tb=el('tbody');
  CYC.days.forEach(d=>{ const tr=el('tr'); tr.appendChild(el('td','d',d.slice(5)));
    for(let h=0;h<24;h++){ const v=CYC.grid[d][h]; const td=el('td'); const div=el('div','cell'+(v===0?' zero':''), v||'');
      div.style.background = v<=0?'#0b1220':`hsl(210,70%,${30+Math.min(1,v/max)*45}%)`;
      div.title=`${d} ${h}h · ${v} đơn bàn giao`; td.appendChild(div); tr.appendChild(td); }
    tb.appendChild(tr); });
  t.appendChild(tb);
  $('#cycLegend').innerHTML=`<span><span class="swatch" style="background:hsl(210,70%,35%)"></span>ít</span><span><span class="swatch" style="background:hsl(210,70%,72%)"></span>nhiều</span><span style="color:var(--mut)">đếm theo mốc BÀN GIAO thật</span>`;
}

/* ================= CONTROL TOWER ================= */
let CTL = null;
async function ctlRefresh(force){
  const btn = $('#ctlRefreshBtn'); if (btn) btn.disabled = true;
  $('#ctlStatus').textContent = 'Đang quét…';
  const haveBacklog = Object.keys(RAW.rawBySeller || {}).length > 0;
  if (force || !haveBacklog) await refresh();
  if (force || !PROD_LOADED) await prodRefresh();
  computeCtl();
  $('#ctlStatus').textContent = 'Cập nhật ' + new Date().toLocaleTimeString('vi-VN') +
    (CYC_LOADED ? ' · gồm cycle-time' : ' · (mở tab ⏱ để thêm tín hiệu cycle-time)');
  if (btn) btn.disabled = false;
}
if($('#ctlRefreshBtn')) $('#ctlRefreshBtn').onclick = () => ctlRefresh(true); // đã gộp vào Director

function computeCtl(){
  if ((CYC_RAW.orders||[]).length && !SLA_PK) { try { computeSla(); } catch(e){} }
  CTL = E.buildControlTower({ rows: ROWS, summary: SUMMARY, prod: PROD, cyc: CYC, pk: SLA_PK, dl: SLA_DL }, CFG, new Date());
  renderCtl();
}

function renderCtl(){
  if (!CTL) return;
  if (!$('#ctlFeed')) return; // Control Tower đã gộp vào Director
  const st = CTL.status;
  const msg = st === 'red' ? 'CẦN XỬ LÝ NGAY' : st === 'amber' ? 'CÓ CẢNH BÁO' : 'ỔN ĐỊNH';
  $('#ctlBanner').innerHTML =
    `<div class="banner ${st}"><span class="dot"></span>
       <span class="big">${msg}</span>
       <span style="color:var(--mut);font-weight:600">P1: ${CTL.counts.P1} · P2: ${CTL.counts.P2} · P3: ${CTL.counts.P3} · Tổng backlog ${fmtN(CTL.totalBacklog)}</span></div>`;

  // Feed
  const feed = $('#ctlFeed'); feed.innerHTML = '';
  if (!CTL.callouts.length) { feed.innerHTML = '<div class="empty" style="color:var(--green)">✓ Không có call-out — mọi thứ trong ngưỡng.</div>'; }
  CTL.callouts.forEach(c => {
    const d = el('div', 'callout ' + c.sev);
    d.innerHTML = `<span class="sev">${c.sev}</span>
      <div class="body"><div class="title">${c.title} <span style="color:var(--mut);font-weight:500">· ${c.cat} · ${c.scope}</span></div>
        <div class="detail">${c.detail}</div>
        <div class="action">→ <b>${c.action}</b></div></div>
      <div class="cnt">${fmtN(c.count)}</div>`;
    feed.appendChild(d);
  });

  // Health matrix
  const hb = $('#ctlHealth'); hb.innerHTML = '';
  if (!CTL.health.length) { hb.innerHTML = '<div class="empty">Chưa có dữ liệu kho.</div>'; return; }
  const t = el('table', 'hmat'); const thead = el('thead');
  thead.innerHTML = '<tr><th style="text-align:left">Kho</th><th>Backlog</th><th>Chưa bàn giao</th><th>Chưa nhãn</th><th>Lỗi/hoàn</th></tr>';
  t.appendChild(thead);
  const tb = el('tbody');
  CTL.health.forEach(h => {
    const tr = el('tr');
    tr.innerHTML = `<td style="text-align:left">${h.wh}</td>
      <td><span class="cellc ${h.c_backlog}" title="${h.backlog} đơn"></span> <span style="font-size:11px;color:var(--mut)">${fmtN(h.backlog)}</span></td>
      <td><span class="cellc ${h.c_handover}" title="${h.detail.handover_overdue}"></span></td>
      <td><span class="cellc ${h.c_label}" title="${h.detail.no_label}"></span></td>
      <td><span class="cellc ${h.c_issue}" title="${h.detail.issue}"></span></td>`;
    tb.appendChild(tr);
  });
  t.appendChild(tb); hb.appendChild(t);
}

/* ================= SLA (đóng gói + vận chuyển) ================= */
let SLA_LOADED = false, SLA_PK = null, SLA_DL = null;
const SLA_STATE = { on_time:{t:'Đúng hạn',c:'t-blue'}, late:{t:'Trễ (đã xong)',c:'t-amber'},
  overdue:{t:'QUÁ HẠN — chưa xong',c:'t-red'}, pending:{t:'Trong hạn',c:''}, in_transit:{t:'Đang giao',c:''} };

async function slaRefresh(){
  const btn = $('#slaRefreshBtn'); if(btn) btn.disabled = true;
  $('#slaStatus').textContent = 'Đang chuẩn bị dữ liệu (kéo cycle-time, có thể lâu nếu nhiều account)…';
  try {
    if (!CYC_LOADED) await cycRefresh(); // dùng chung dữ liệu detail
    computeSla();
    SLA_LOADED = true;
    $('#slaStatus').textContent = `Trên ${fmtN((CYC_RAW.orders||[]).length)} đơn · cập nhật ${new Date().toLocaleTimeString('vi-VN')}`;
  } catch(e){
    $('#slaStatus').textContent = 'Lỗi: ' + (e && e.message || e) + ' — bấm “↻ Tính SLA” để thử lại.';
  } finally { if(btn) btn.disabled = false; }
}
if($('#slaRefreshBtn')) $('#slaRefreshBtn').onclick = () => { SLA_LOADED = false; slaRefresh(); };

function computeSla(){
  const orders = CYC_RAW.orders || [];
  SLA_PK = E.buildPackingSLA(orders, CFG, new Date());
  SLA_DL = E.buildDeliverySLA(orders, CFG, new Date());
  SLA_SCORE = E.buildCarrierScorecard(orders, flatBacklog(), CFG, new Date());
  renderSla();
}

function rateCard(rate, target){
  const pct = rate==null ? '—' : Math.round(rate*1000)/10 + '%';
  const cls = rate==null ? 'blue' : (rate>=target ? 'green' : 'red');
  return { pct, cls };
}
function stateTag(st){ const s=SLA_STATE[st]||{t:st,c:''}; return `<span class="tag ${s.c}">${s.t}</span>`; }
function overLabel(m){ if(m==null) return '—'; if(m<60) return m+'′'; const h=Math.floor(m/60),mm=m%60; return h+'h'+(mm?(' '+mm+'′'):''); }

let SLA_SCORE=null;
function renderSla(){
  if(!$('#slaPkCards')) return; // tab SLA đã bỏ; vẫn giữ SLA_PK/DL cho Director
  renderSlaInsight(); renderScorecard();
  // ---- Packing ----
  const rc = rateCard(SLA_PK.rate, SLA_PK.target);
  const pc = $('#slaPkCards'); pc.innerHTML='';
  [[rc.cls, rc.pct, `On-time (mục tiêu ${Math.round(SLA_PK.target*100)}%)`],
   ['red', fmtN(SLA_PK.overdueOpen), 'Quá hạn CHƯA xong'],
   ['amber', fmtN(SLA_PK.lateDone), 'Trễ (đã xong)'],
   ['blue', fmtN(SLA_PK.measured), 'Đơn đo được']
  ].forEach(([c,n,l])=>{ const d=el('div','card '+c); d.appendChild(el('div','n',n)); d.appendChild(el('div','l',l)); pc.appendChild(d); });
  const pl = $('#slaPkLate'); pl.innerHTML='';
  const prows = SLA_PK.lateList.slice(0,300).map(r=>[r.order_code, r.ref_code||'—', r.channel, (r.created_at||'').slice(5,16), (r.deadline||'').slice(5), `<span class="age gt72">${overLabel(r.over)}</span>`, stateTag(r.state), r.warehouse||'—']);
  pl.appendChild(tableFrom(['Mã đơn','Mã đối tác','Kênh','Tạo','Hạn đóng gói','Trễ','Trạng thái','Kho'], prows.length?prows:[['—','—','—','—','—','—','—','—']]));
  const pch = $('#slaPkCh'); pch.innerHTML='';
  const chrows = SLA_PK.byChannel.sort((a,b)=>(a.rate??1)-(b.rate??1)).map(v=>[v.channel, fmtN(v.measured), v.rate==null?'—':(Math.round(v.rate*1000)/10+'%'), fmtN(v.late), fmtN(v.overdue)]);
  pch.appendChild(tableFrom(['Kênh','Đo được','On-time','Trễ','Quá hạn'], chrows.length?chrows:[['—','0','—','0','0']]));

  // ---- Delivery ----
  const rd = rateCard(SLA_DL.rate, SLA_DL.target);
  const dc = $('#slaDlCards'); dc.innerHTML='';
  [[rd.cls, rd.pct, `On-time (mục tiêu ${Math.round(SLA_DL.target*100)}%)`],
   ['red', fmtN(SLA_DL.overdueOpen), 'Quá hạn CHƯA giao'],
   ['amber', fmtN(SLA_DL.lateDone), 'Giao trễ'],
   ['blue', fmtN(SLA_DL.measured), 'Đơn đo được']
  ].forEach(([c,n,l])=>{ const d=el('div','card '+c); d.appendChild(el('div','n',n)); d.appendChild(el('div','l',l)); dc.appendChild(d); });
  const dl = $('#slaDlLate'); dl.innerHTML='';
  const drows = SLA_DL.lateList.slice(0,300).map(r=>[r.order_code, r.ref_code||'—', r.carrier, (r.promised||'').slice(0,10), (r.delivered||'').slice(5,16)||'—', `<span class="age gt72">${overLabel(r.over)}</span>`, stateTag(r.state), r.warehouse||'—']);
  dl.appendChild(tableFrom(['Mã đơn','Mã đối tác','ĐVVC','Hạn giao','Giao lúc','Trễ','Trạng thái','Kho'], drows.length?drows:[['—','—','—','—','—','—','—','—']]));
  const dca = $('#slaDlCar'); dca.innerHTML='';
  const carrows = SLA_DL.byCarrier.sort((a,b)=>(a.rate??1)-(b.rate??1)).map(v=>[v.carrier, fmtN(v.measured), v.rate==null?'—':(Math.round(v.rate*1000)/10+'%'), fmtN(v.late), fmtN(v.overdue)]);
  dca.appendChild(tableFrom(['ĐVVC','Đo được','On-time','Trễ','Quá hạn'], carrows.length?carrows:[['—','0','—','0','0']]));
}

/* ================= SẮP TRỄ (at-risk) + TẢI vs NĂNG LỰC ================= */
let AR = null, CAP = null, AR_LOADED = false, arTimer = null;
const AR_LABEL = { overdue:'Quá hạn', critical:'Nguy cấp', warning:'Cảnh báo', watch:'Theo dõi' };
function flatBacklog(){ const a=[]; for(const sid of Object.keys(RAW.rawBySeller||{})) a.push(...RAW.rawBySeller[sid]); return a; }
function fmtRemain(m){ const neg=m<0, a=Math.abs(m), h=Math.floor(a/60), mm=a%60; const body=(h?h+'h ':'')+mm+'′'; return (neg?'trễ ':'còn ')+body; }

async function arRefresh(){
  const btn=$('#arRefreshBtn'); btn.disabled=true; $('#arStatus').textContent='Đang tính…';
  if(!Object.keys(RAW.rawBySeller||{}).length) await refresh();
  if(!PROD_LOADED) await prodRefresh();
  if(!SHIP_LOADED){ try{ await shipRefresh(); }catch(e){} } // để có "Quá hạn giao (theo promised)"
  computeAR(); AR_LOADED=true;
  $('#arStatus').textContent='Cập nhật '+new Date().toLocaleTimeString('vi-VN')+' · giao hàng lấy từ đơn shipping hiện tại';
  btn.disabled=false; startArTimer();
}
if($('#arRefreshBtn')) $('#arRefreshBtn').onclick=arRefresh;
function startArTimer(){ if(arTimer)clearInterval(arTimer); arTimer=setInterval(()=>{ if($('#viewAtRisk').style.display!=='none') computeAR(); if($('#viewDirector').style.display!=='none'){ computeAR(); renderDirector(); } }, 60000); }
function computeAR(){ const deliveryOpen=(RAW_SHIP&&RAW_SHIP.orders)||[]; AR=E.buildAtRisk(flatBacklog(), deliveryOpen, CFG, new Date()); CAP=E.buildCapacity(flatBacklog(), PROD, CFG, new Date()); if($('#viewAtRisk')) renderAR(); }

function capCards(box){
  if(!CAP) return; box.innerHTML='';
  const clear = CAP.hoursToClear===Infinity ? '∞ (không kịp)' : CAP.hoursToClear+'h';
  const items=[['Đơn đang chờ xử lý', fmtN(CAP.open)],['Năng lực xử lý', fmtN(CAP.capPerHour)+'/giờ'],
    ['Nhịp đơn vào', (CAP.inboundPerHour==null?'—':fmtN(CAP.inboundPerHour)+'/giờ')],
    ['Net', (CAP.net>=0?'+':'')+fmtN(CAP.net)+'/giờ'],['Giải phóng backlog', clear]];
  items.forEach(([l,v])=>{ const m=el('span','m'); m.innerHTML=`${l}: <b>${v}</b>`; box.appendChild(m); });
}
function bChips(bk){ return ['overdue','critical','warning','watch'].map(k=>`<span class="chip ${k}">${AR_LABEL[k]}: ${bk[k]||0}</span>`).join(''); }
function subLabel(s){ return (CFG.subStatusMap && CFG.subStatusMap[s] && CFG.subStatusMap[s].label) || s || '—'; }
function fmtDur(m){ if(m==null) return '—'; if(m<60) return m+'′'; const h=Math.floor(m/60), mm=m%60; return h+'h'+(mm?(' '+mm+'′'):''); }

function renderAR(){
  if(!AR) return;
  renderArInsight();
  capCards($('#arCap'));
  $('#arPkChips').innerHTML=bChips(AR.packing.buckets);
  const pk=$('#arPkTable'); pk.innerHTML='';
  const prows=AR.packing.list.slice(0,400).map(r=>[r.order_code, r.ref_code||'—', r.channel, r.warehouse||'—', (r.deadline||'').slice(5),
    `<span class="remain ${r.bucket}">${fmtRemain(r.remain)}</span>`, r.no_label?'<span class="tag t-red">Chưa nhãn</span>':'']);
  pk.appendChild(tableFrom(['Mã đơn','Mã đối tác','Kênh','Kho','Hạn đóng gói','Còn lại','Cờ'], prows.length?prows:[['—','—','—','—','—','—','—']]));
  // Kẹt bàn giao (đã đóng xong, chưa giao ĐVVC)
  if(AR.handover){
    $('#arHoChips').innerHTML=bChips(AR.handover.buckets);
    const ho=$('#arHoTable'); ho.innerHTML='';
    const horows=AR.handover.list.slice(0,400).map(r=>[r.order_code, r.ref_code||'—', whLabel(r.warehouse)||'—', r.carrier||'—', subLabel(r.sub),
      fmtDur(r.stuck_min), `<span class="remain ${r.bucket}">${fmtRemain(r.remain)}</span>`]);
    ho.appendChild(tableFrom(['Mã đơn','Mã đối tác','Kho','ĐVVC','Trạng thái','Kẹt đã','Tới hạn'], horows.length?horows:[['—','—','—','—','—','—','—']]));
  }
  $('#arDlChips').innerHTML=bChips(AR.delivery.buckets);
  const dl=$('#arDlTable'); dl.innerHTML='';
  const drows=AR.delivery.list.slice(0,400).map(r=>[r.order_code, r.ref_code||'—', r.carrier, whLabel(r.warehouse)||'—', (r.promised||'').slice(0,10),
    `<span class="remain ${r.bucket}">${fmtRemain(r.remain)}</span>`]);
  dl.appendChild(tableFrom(['Mã đơn','Mã đối tác','ĐVVC','Kho','Hạn giao','Còn lại'], drows.length?drows:[['—','—','—','—','—','— (cần dữ liệu tab SLA)']]));
  // ⏰ Quá hạn giao (theo promised) nhưng chưa giao — từ đơn đang vận chuyển
  const ov=$('#arOverdue'); if(ov){ ov.innerHTML='';
    const list=(SHIP&&SHIP.overdueDeliver)||[];
    // chip theo MỨC ĐỘ trễ (over_h): >72h Quá hạn · 48-72h Nguy cấp · 24-48h Cảnh báo · ≤24h Theo dõi
    const ob={overdue:0,critical:0,warning:0,watch:0};
    list.forEach(r=>{ const o=r.over_h||0; if(o>72)ob.overdue++; else if(o>48)ob.critical++; else if(o>24)ob.warning++; else ob.watch++; });
    if($('#arOverdueChips')) $('#arOverdueChips').innerHTML = bChips(ob);
    const orows=list.slice(0,400).map(r=>[r.order_code, r.ref_code||'—', r.carrier||'—', whLabel(r.warehouse)||'—',
      (r.promised||'').slice(0,10), `<span class="age gt72">${fmtDur((r.over_h||0)*60)}</span>`, r.state||'']);
    ov.appendChild(tableFrom(['Mã đơn','Mã đối tác','ĐVVC','Kho','Hạn giao','Quá hạn','Trạng thái'],
      orows.length?orows:[['—','—','—','—','—','—', SHIP_LOADED?'(không có đơn quá hạn giao)':'(bấm ↻ để nạp đơn vận chuyển)']]));
  }
}

/* ================= DIRECTOR (one-pager focus vận hành) ================= */
let DIR_LOADED=false;
async function dirRefresh(force){
  const btn=$('#dirRefreshBtn'); if(btn)btn.disabled=true; $('#dirStatus').textContent='Đang cập nhật…';
  if(force || !Object.keys(RAW.rawBySeller||{}).length) await refresh();
  if(force) await prodRefresh();   // năng suất nặng -> chỉ khi bấm "Cập nhật toàn cảnh"
  computeAR(); computeCtl(); renderDirector();
  if(force && !CYC_LOADED){ $('#dirStatus').textContent='Đang tính SLA (kéo chi tiết)…'; await cycRefresh(); }
  if(CYC_LOADED){ computeSla(); computeAR(); computeCtl(); }
  renderDirector(); DIR_LOADED=true;
  $('#dirStatus').textContent='Cập nhật '+new Date().toLocaleTimeString('vi-VN')+(CYC_LOADED?'':' · SLA: bấm “Cập nhật toàn cảnh” để tính');
  if(btn)btn.disabled=false;
}
if($('#dirRefreshBtn')) $('#dirRefreshBtn').onclick=()=>dirRefresh(true);

function pctCls(rate,target){ if(rate==null) return ['—','blue']; return [Math.round(rate*1000)/10+'%', rate>=target?'green':'red']; }

function renderDirector(){
  const st = CTL ? CTL.status : 'green';
  const msg = st==='red'?'CẦN XỬ LÝ NGAY':st==='amber'?'CÓ CẢNH BÁO':'ỔN ĐỊNH';
  $('#dirBanner').innerHTML=`<div class="banner ${st}"><span class="dot"></span><span class="big">${msg}</span>
    <span style="color:var(--mut);font-weight:600">${CTL?`P1 ${CTL.counts.P1} · P2 ${CTL.counts.P2}`:''}</span></div>`;

  const [pkPct,pkCls]=pctCls(SLA_PK?SLA_PK.rate:null, CFG.slaFulfillment.kpiTarget);
  const [dlPct,dlCls]=pctCls(SLA_DL?SLA_DL.rate:null, CFG.slaDelivery.kpiTarget);
  const kpi=$('#dirKpi'); kpi.innerHTML='';
  const cards=[
    [pkCls, pkPct, `On-time ĐÓNG GÓI (đích ${Math.round(CFG.slaFulfillment.kpiTarget*100)}%)`],
    [dlCls, dlPct, `On-time GIAO HÀNG (đích ${Math.round(CFG.slaDelivery.kpiTarget*100)}%)`],
    ['blue', SUMMARY?fmtN(SUMMARY.backlog):'—', 'Backlog đang tồn'],
    ['red', AR?fmtN(AR.packing.actNow):'—', 'Sắp trễ đóng gói (≤30′+quá hạn)'],
    ['amber', AR?fmtN(AR.packing.buckets.overdue):'—', 'Đã quá hạn đóng gói'],
    ['blue', PROD?fmtN(PROD.totals.dispatched):'—', 'Đơn đã xuất (7 ngày)']
  ];
  cards.forEach(([c,v,t])=>{ const d=el('div','k '+c); d.appendChild(el('div','v',v)); d.appendChild(el('div','t',t)); kpi.appendChild(d); });

  capCards($('#dirCap'));

  const dec=$('#dirDecisions'); dec.innerHTML='';
  if(!CTL || !CTL.callouts.length){ dec.innerHTML='<div class="empty" style="color:var(--green)">✓ Không có việc gấp.</div>'; }
  else CTL.callouts.slice(0,20).forEach(c=>{ const d=el('div','deci');
    d.innerHTML=`<span class="p">${c.sev}</span><div><b>${c.title}</b> <span style="color:var(--mut)">(${fmtN(c.count)})</span><div style="color:var(--mut);font-size:12px">→ ${c.action}</div></div>`; dec.appendChild(d); });

  const hb=$('#dirHealth'); hb.innerHTML='';
  if(CTL && CTL.health.length){
    const t=el('table','hmat'); t.innerHTML='<thead><tr><th style="text-align:left">Kho</th><th>Backlog</th><th>Bàn giao</th><th>Nhãn</th><th>Lỗi</th></tr></thead>';
    const tb=el('tbody');
    CTL.health.forEach(hh=>{ const tr=el('tr'); tr.innerHTML=`<td style="text-align:left">${hh.wh}</td>
      <td><span class="cellc ${hh.c_backlog}"></span> <span style="font-size:11px;color:var(--mut)">${fmtN(hh.backlog)}</span></td>
      <td><span class="cellc ${hh.c_handover}"></span></td><td><span class="cellc ${hh.c_label}"></span></td><td><span class="cellc ${hh.c_issue}"></span></td>`; tb.appendChild(tr); });
    t.appendChild(tb); hb.appendChild(t);
  } else hb.innerHTML='<div class="empty">Chưa có dữ liệu kho.</div>';
}

/* ================= CẢNH BÁO Zalo/Slack (P1) ================= */
const SEVN = { P1:3, P2:2, P3:1 };
let alertTimer = null;

async function loadAlertCfg(){
  try{ if(typeof chrome!=='undefined' && chrome.storage){ const {alerting}=await chrome.storage.local.get('alerting'); if(alerting) Object.assign(CFG.alerting, alerting); } }catch(e){}
  $('#alWebhook').value = CFG.alerting.webhookUrl||'';
  $('#alType').value = CFG.alerting.type||'slack';
  $('#alEvery').value = CFG.alerting.autoEveryMin||0;
  try{ if(typeof chrome!=='undefined' && chrome.storage){ const {backend}=await chrome.storage.local.get('backend'); if(backend){ $('#beUrl').value=backend.url||''; $('#beKey').value=backend.key||''; if($('#beEnabled')) $('#beEnabled').checked=backend.enabled===true; } } }catch(e){}
  startAlertTimer();
}
async function saveAlertCfg(){
  CFG.alerting.webhookUrl = $('#alWebhook').value.trim();
  CFG.alerting.type = $('#alType').value;
  CFG.alerting.autoEveryMin = parseInt($('#alEvery').value,10)||0;
  try{ if(typeof chrome!=='undefined' && chrome.storage) await chrome.storage.local.set({alerting:CFG.alerting}); }catch(e){}
  const beUrl=($('#beUrl').value||'').trim(), beKey=($('#beKey').value||'').trim(), beEnabled=!!($('#beEnabled')&&$('#beEnabled').checked&&beUrl);
  try{ if(typeof chrome!=='undefined' && chrome.storage){ await chrome.storage.local.set({backend:{url:beUrl,key:beKey,enabled:beEnabled}}); if(beEnabled) await ensureHostPerm(beUrl); } }catch(e){}
  $('#alertStatus').textContent='Đã lưu cấu hình'+(beEnabled?' + backend relay đang bật':'')+'.'; startAlertTimer();
}
function startAlertTimer(){ if(self.UnifiedAnalysis) return; if(alertTimer)clearInterval(alertTimer); const m=CFG.alerting.autoEveryMin; if(m>0) alertTimer=setInterval(()=>sendAlert(false), m*60000); }

async function ensureHostPerm(url){
  try{ if(typeof chrome==='undefined' || !chrome.permissions) return true;
    const origin=new URL(url).origin+'/*';
    if(await chrome.permissions.contains({origins:[origin]})) return true;
    return await chrome.permissions.request({origins:[origin]});
  }catch(e){ return true; }
}
async function sendAlert(manual){
  const A=CFG.alerting;
  if(!A.webhookUrl){ if(manual) $('#alertStatus').textContent='Chưa có webhook — dán URL và Lưu.'; return; }
  if(!CTL) computeCtl();
  const list=(CTL?CTL.callouts:[]).filter(c=>SEVN[c.sev]>=SEVN[A.minSeverity||'P1']);
  if(!list.length){ $('#alertStatus').textContent='Không có cảnh báo ≥'+(A.minSeverity||'P1')+' lúc '+new Date().toLocaleTimeString('vi-VN'); return; }
  const lines=list.map(c=>`• [${c.sev}] ${c.title} (${fmtN(c.count)}) → ${c.action}`);
  const text=`🚨 TikiNOW Ops — cảnh báo ${A.minSeverity||'P1'}+ · ${new Date().toLocaleString('vi-VN')}\n`+lines.join('\n');
  const ok=await ensureHostPerm(A.webhookUrl);
  if(!ok){ $('#alertStatus').textContent='Chưa được cấp quyền gửi tới host webhook.'; return; }
  try{
    await fetch(A.webhookUrl,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(A.type==='slack'?{text}:{text,callouts:list})});
    $('#alertStatus').textContent=`Đã gửi ${list.length} cảnh báo lúc ${new Date().toLocaleTimeString('vi-VN')}`;
  }catch(e){ $('#alertStatus').textContent='Lỗi gửi: '+e.message+' (kiểm tra webhook/quyền host).'; }
}
if($('#alSaveBtn')){ $('#alSaveBtn').onclick=saveAlertCfg; $('#alSendBtn').onclick=()=>sendAlert(true); loadAlertCfg(); }

/* ================= FLOW & NGHẼN ================= */
let FLOW = null, FLOW_LOADED = false;
const STAGE_ORDER = [['wait_pick','Chờ lấy'],['picking','Đang lấy'],['packing','Đang đóng gói'],['packed','Chờ bàn giao']];
async function flowRefresh(){
  const btn=$('#flowRefreshBtn'); btn.disabled=true; $('#flowStatus').textContent='Đang phân tích…';
  if($('#flowCap').value==='') $('#flowCap').value=CFG.flow.packCapacityPerHour;
  if(!Object.keys(RAW.rawBySeller||{}).length) await refresh();
  if(self.__DEMO_CYCLE && !CYC_LOADED){ CYC_RAW=self.__DEMO_CYCLE; CYC_LOADED=true; computeCyc(); }
  computeFlow(); FLOW_LOADED=true;
  $('#flowStatus').textContent='Cập nhật '+new Date().toLocaleTimeString('vi-VN')+(CYC_LOADED?' · dùng cycle-time thật':' · (mở tab ⏱ để dùng thời gian khâu thật)');
  btn.disabled=false;
}
if($('#flowRefreshBtn')) $('#flowRefreshBtn').onclick=flowRefresh;
$('#flowCap').oninput=()=>{ CFG.flow.packCapacityPerHour=parseInt($('#flowCap').value,10)||CFG.flow.packCapacityPerHour; if(FLOW_LOADED) computeFlow(); };
let FIFO=null;
function computeFlow(){ const cap=parseInt($('#flowCap').value,10)||CFG.flow.packCapacityPerHour;
  const inflow = E.buildInflowForecast(PROD, CFG, new Date());
  FLOW=E.buildFlow(flatBacklog(), CYC, CFG, new Date(), cap, inflow);
  FIFO=E.buildFifo(CYC_RAW.orders||[], flatBacklog(), CFG, new Date());
  renderFlow(); renderFifo(); }

function renderFlow(){
  if(!FLOW) return;
  // diagnosis banner
  const st = FLOW.congest?'red':(FLOW.primary==='packed'?'amber':'amber');
  $('#flowDiag').innerHTML=`<div class="banner ${FLOW.congest?'red':'amber'}"><span class="dot"></span>
    <span class="big" style="font-size:16px">${FLOW.diagnosis}</span>
    <span style="color:var(--mut);font-weight:600">Khâu dồn nhất: ${FLOW.primaryLabel}</span></div>`;
  // WIP funnel
  const wb=$('#flowWip'); wb.innerHTML=''; const wrap=el('div','funnel');
  const maxW=Math.max(1,...STAGE_ORDER.map(([k])=>FLOW.wip[k]||0));
  STAGE_ORDER.forEach(([k,lab])=>{ const v=FLOW.wip[k]||0; const row=el('div','bar');
    row.appendChild(el('div','lab',lab));
    const track=el('div','track'); const fill=el('div','fill'); fill.style.width=(v/maxW*100)+'%';
    fill.style.background = (k===FLOW.primary)?'var(--red)':'var(--blue)'; track.appendChild(fill); row.appendChild(track);
    row.appendChild(el('div','val',fmtN(v))); wrap.appendChild(row); });
  wb.appendChild(wrap);
  // feasibility
  const kip = FLOW.packing.miss===0;
  $('#flowFeas').innerHTML=`
    <div class="kpiBig" style="margin:0">
      <div class="k ${kip?'green':'red'}"><div class="v">${kip?'KỊP':fmtN(FLOW.packing.miss)}</div><div class="t">${kip?'Đủ năng lực kịp SLA':'đơn dự kiến TRỄ SLA đóng gói'}</div></div>
      <div class="k blue"><div class="v">${fmtN(FLOW.packing.due)}</div><div class="t">Đơn phải xong (chưa bàn giao)</div></div>
      <div class="k amber"><div class="v">${FLOW.packing.firstMiss?FLOW.packing.firstMiss.slice(5):'—'}</div><div class="t">Bắt đầu vỡ SLA lúc</div></div>
      <div class="k blue"><div class="v">${fmtN(FLOW.packing.capPerHour)}</div><div class="t">Năng lực/giờ (giả định)</div></div>
    </div>`;
  // forecast bars
  const peakTxt = FLOW.peak? `Đỉnh dồn: <b>${FLOW.peak.label}</b> (~${fmtN(FLOW.peak.count)} đơn ở bàn giao)` : '';
  const congTxt = FLOW.congestHour? ` · Nguy cơ NGHẼN từ <b style="color:var(--red)">${FLOW.congestHour}</b>` : ' · Chưa thấy nghẽn trong khung dự báo';
  const inflowTxt = FLOW.inflowUsed? ' · <span style="color:var(--mut)">(đã gồm dự báo đơn mới theo giờ)</span>' : '';
  $('#flowPeak').innerHTML = peakTxt + congTxt + inflowTxt;
  const fb=el('div','fbar'); const maxF=Math.max(1,...FLOW.forecast.map(f=>f.count));
  FLOW.forecast.forEach(f=>{ const col=el('div','col'+(f.count>(CFG.flow.congestThreshold||150)?' hot':''));
    const cap=el('div','cap',f.count?fmtN(f.count):''); const bar=el('div','bar2'); bar.style.height=(f.count/maxF*100)+'%';
    const hr=el('div','hr',f.label); col.appendChild(cap); col.appendChild(bar); col.appendChild(hr); fb.appendChild(col); });
  $('#flowForecast').innerHTML=''; $('#flowForecast').appendChild(fb);
  // carriers
  const cb=$('#flowCarriers'); cb.innerHTML='';
  const rows=FLOW.carriers.map((c,i)=>[ (i===0?'🔴 ':'')+c.carrier, fmtN(c.count), c.avgWait+'′', c.maxWait+'′',
    i===0&&c.count>0?'<b style="color:var(--red)">PUSH LẤY HÀNG NGAY</b>':(c.count>50?'Theo dõi':'') ]);
  cb.appendChild(tableFrom(['ĐVVC','Đơn chờ bàn giao','Chờ TB','Chờ lâu nhất','Hành động'], rows.length?rows:[['—','0','—','—','—']]));
}


function renderFifo(){
  if(!FIFO) return;
  if(!FIFO.dispatched){ $('#fifoHead').innerHTML='<span style="color:var(--mut)">Cần dữ liệu Cycle-time (mở tab ⏱ và kéo) để chấm FIFO theo mốc bàn giao thật.</span>';
    $('#fifoStuck').innerHTML=''; $('#fifoLane').innerHTML=''; return; }
  const pct = FIFO.adherence==null?'—':Math.round(FIFO.adherence*1000)/10+'%';
  const cls = FIFO.adherence==null?'blue':(FIFO.adherence>=0.9?'green':FIFO.adherence>=0.75?'amber':'red');
  $('#fifoHead').innerHTML=`<div class="kpiBig" style="margin:0">
    <div class="k ${cls}"><div class="v">${pct}</div><div class="t">Tuân thủ FIFO (bàn giao đúng thứ tự sẵn sàng)</div></div>
    <div class="k red"><div class="v">${fmtN(FIFO.stuck.length)}</div><div class="t">Đơn đang KẸT ngoài FIFO</div></div>
    <div class="k amber"><div class="v">${fmtN(FIFO.violations)}</div><div class="t">Lần bàn giao vượt thứ tự (đã xảy ra)</div></div>
    <div class="k blue"><div class="v">${fmtN(FIFO.dispatched)}</div><div class="t">Đơn đã bàn giao đo được</div></div>
  </div>`;
  const st=$('#fifoStuck'); st.innerHTML='';
  const srows=FIFO.stuck.slice(0,300).map(r=>[r.order_code, r.ref_code||'—', r.wh, r.carrier,
    `<span class="age gt72">${fmtN(r.wait_min)}′</span>`, `<b style="color:var(--red)">${fmtN(r.overtaken_by)}</b>`]);
  st.appendChild(tableFrom(['Mã đơn','Mã đối tác','Kho','ĐVVC','Chờ (phút)','Bị vượt bởi'], srows.length?srows:[['—','—','—','—','—','✓ không có']]));
  const ln=$('#fifoLane'); ln.innerHTML='';
  const lrows=FIFO.byLane.slice(0,50).map(l=>[l.wh, l.carrier, fmtN(l.dispatched), fmtN(l.violations),
    l.adherence==null?'—':`<span style="color:${l.adherence>=0.9?'var(--green)':l.adherence>=0.75?'var(--amber)':'var(--red)'}">${Math.round(l.adherence*100)}%</span>`]);
  ln.appendChild(tableFrom(['Kho','ĐVVC','Đã bàn giao','Vượt thứ tự','Tuân thủ'], lrows.length?lrows:[['—','—','0','0','—']]));
}


/* ===== Insight "Đọc nhanh — cần làm gì" ===== */
function insightBanner(elId, sev, html){
  const box=$(elId); if(!box) return;
  box.innerHTML=`<div class="banner ${sev}" style="margin-bottom:14px"><span class="dot"></span>
    <span style="font-size:14px;font-weight:600;line-height:1.5">${html}</span></div>`;
}
function renderProdInsight(){
  const P=PROD; if(!P||!P.days||!P.days.length){ return; }
  const today=P.days[P.days.length-1]; const h=new Date().getHours();
  let weak=[]; for(let hr=P.activeFrom;hr<=P.activeTo;hr++){ if(P.grid[today][hr].activity < P.lowThresh) weak.push(hr+'h'); }
  const todayTotal=P.daily[P.daily.length-1].activity;
  const prior=P.daily.slice(0,-1); const priorAvg=prior.length?Math.round(prior.reduce((a,b)=>a+b.activity,0)/prior.length):null;
  const delta=priorAvg?Math.round((todayTotal-priorAvg)/priorAvg*100):null;
  const curAct=(h>=P.activeFrom&&h<=P.activeTo)?P.grid[today][h].activity:null;
  const curLow=curAct!=null && curAct<P.lowThresh;
  const sev=(weak.length>=3||curLow||(delta!=null&&delta<-15))?'red':(weak.length>0||(delta!=null&&delta<0))?'amber':'green';
  const parts=[];
  parts.push(`Hôm nay xử lý <b>${fmtN(todayTotal)}</b> thao tác${delta!=null?` (<b>${delta>=0?'+':''}${delta}%</b> so với TB ${fmtN(priorAvg)}/ngày)`:''}.`);
  if(curAct!=null) parts.push(curLow?`Giờ hiện tại ${h}h <b style="color:var(--red)">ĐANG TỤT</b> (${curAct}<${P.lowThresh}/giờ).`:`Giờ hiện tại ${h}h: ${curAct}/giờ — ổn.`);
  if(weak.length) parts.push(`Giờ yếu: <b>${weak.join(', ')}</b>.`);
  const action = sev==='red' ? (curLow?'→ Kiểm tra line/nhân sự NGAY tại giờ này.':'→ Dồn người vào khung giờ yếu, rà lại phân ca.')
    : sev==='amber' ? '→ Theo dõi khung giờ yếu, chuẩn bị tăng lực.' : '→ Nhịp tốt, giữ nguyên.';
  insightBanner('#prodInsight', sev, parts.join(' ')+` <span style="color:var(--green)">${action}</span>`);
}
function renderCycInsight(){
  const C=CYC; if(!C){ return; }
  if(!C.measured){ insightBanner('#cycInsight','amber','Chưa đủ dữ liệu — bấm “Kéo cycle-time”. → Cần vài chục đơn đã bàn giao để đo.'); return; }
  const totalStage=C.stageStats.reduce((a,x)=>a+x.median,0);
  const bn=C.bottleneck; const share=totalStage?Math.round(bn.median/totalStage*100):0;
  const slaPct=C.withinSLA!=null?Math.round(C.withinSLA*100):null;
  const sev=(C.withinSLA!=null&&C.withinSLA<0.8)?'red':(C.withinSLA!=null&&C.withinSLA<0.95)?'amber':'green';
  const parts=[];
  parts.push(`Từ tạo → bàn giao: trung vị <b>${minLabel(C.dwellMedian)}</b>${slaPct!=null?`, <b>${slaPct}%</b> đạt SLA (đích ≤${CFG.cycle.dwellTargetH}h)`:''}.`);
  parts.push(`Khâu nghẽn: <b>${bn.label}</b> (${minLabel(bn.median)}/đơn, ~${share}% tổng thời gian).`);
  const action=`→ Dồn nguồn lực vào khâu <b>${bn.label}</b>.`+(C.breachCount?` Có <b>${fmtN(C.breachCount)}</b> đơn vượt SLA cần đẩy ngay.`:'');
  insightBanner('#cycInsight', sev, parts.join(' ')+` <span style="color:var(--green)">${action}</span>`);
}


/* ===== Insight action-first cho Backlog / SLA / Sắp trễ ===== */
const FLAG_ACTION={ no_label:'Xử lý tạo vận đơn / kiểm tra kết nối ĐVVC', handover_overdue:'Đẩy bàn giao ngay, hối ĐVVC tới lấy',
  processing_overdue:'Tăng lực khâu xử lý (pick/pack)', confirm_overdue:'Xác nhận đơn nhanh', shipping_stuck:'Đối soát ĐVVC các đơn treo', issue_return:'Tách luồng xử lý sự cố, gán người phụ trách' };
function renderBacklogInsight(){
  const S=SUMMARY; if(!S){ return; }
  if(!S.backlog){ insightBanner('#blInsight','green','Không có đơn backlog. → Giữ nhịp.'); return; }
  const flags=Object.entries(S.byFlag).sort((a,b)=>b[1]-a[1]).filter(([k,v])=>v>0);
  const top=flags[0]; const wh=Object.entries(S.byWarehouse).sort((a,b)=>b[1]-a[1])[0];
  const sev=(S.byFlag.no_label>0||S.byFlag.handover_overdue>0)?'red':'amber';
  const parts=[`Tổng <b>${fmtN(S.backlog)}</b> đơn backlog.`];
  if(top) parts.push(`Vấn đề lớn nhất: <b>${E.FLAG_LABELS[top[0]]}</b> (${fmtN(top[1])} đơn).`);
  if(wh) parts.push(`Kho nặng nhất: <b>${wh[0]}</b> (${fmtN(wh[1])}).`);
  if(S.byBucket.gt72) parts.push(`<b>${fmtN(S.byBucket.gt72)}</b> đơn đã tồn >72h.`);
  const action= top? (FLAG_ACTION[top[0]]||'Ưu tiên xử lý nhóm lớn nhất') : 'Giải phóng đơn cũ trước';
  insightBanner('#blInsight', sev, parts.join(' ')+` <span style="color:var(--green)">→ ${action}.</span>`);
}
function renderSlaInsight(){
  if(!SLA_PK||!SLA_DL){ return; }
  const pk=SLA_PK, dl=SLA_DL;
  const pkPct=pk.rate!=null?Math.round(pk.rate*1000)/10:null, dlPct=dl.rate!=null?Math.round(dl.rate*1000)/10:null;
  const pkBad=pk.rate!=null&&pk.rate<pk.target, dlBad=dl.rate!=null&&dl.rate<dl.target;
  const sev=(pkBad||dlBad)?'red':'green';
  const worstCh=(pk.byChannel||[]).filter(c=>c.measured>0).sort((a,b)=>(a.rate??1)-(b.rate??1))[0];
  const worstCar=(dl.byCarrier||[]).filter(c=>c.measured>0).sort((a,b)=>(a.rate??1)-(b.rate??1))[0];
  const exTxt=(pk.excluded||dl.excluded)?` <span style="color:var(--mut)">(net sau loại trừ ${fmtN((pk.excluded||0)+(dl.excluded||0))} đơn; thô: đóng gói ${pk.rateGross==null?'—':Math.round(pk.rateGross*100)+'%'})</span>`:'';
  const parts=[`Đóng gói on-time <b>${pkPct==null?'—':pkPct+'%'}</b> (đích ${Math.round(pk.target*100)}%), giao <b>${dlPct==null?'—':dlPct+'%'}</b> (đích ${Math.round(dl.target*100)}%).`+exTxt];
  if(pkBad&&worstCh) parts.push(`Kênh yếu nhất: <b>${worstCh.channel}</b> (${Math.round(worstCh.rate*100)}%).`);
  if(dlBad&&worstCar) parts.push(`ĐVVC yếu nhất: <b>${worstCar.carrier}</b> (${Math.round(worstCar.rate*100)}%).`);
  const acts=[]; if(pkBad) acts.push(`đẩy ${fmtN(pk.overdueOpen)} đơn quá hạn đóng gói`); if(dlBad) acts.push('đối soát ĐVVC trễ nhiều');
  const action= acts.length?('→ '+acts.join('; ')+'.'):'→ Đang đạt KPI, giữ nhịp.';
  insightBanner('#slaInsight', sev, parts.join(' ')+` <span style="color:var(--green)">${action}</span>`);
}
function renderArInsight(){
  if(!AR){ return; }
  const actNow=AR.packing.actNow, over=AR.packing.buckets.overdue;
  const sev=(over>0||actNow>0)?'red':'green';
  const parts=[`<b>${fmtN(actNow)}</b> đơn sắp trễ đóng gói (${fmtN(over)} đã quá hạn, ${fmtN(AR.packing.buckets.critical)} còn ≤30′).`];
  if(CAP){ const clear=CAP.hoursToClear===Infinity?'KHÔNG kịp với nhịp hiện tại':`~${CAP.hoursToClear}h`;
    parts.push(`Năng lực ${fmtN(CAP.capPerHour)}/giờ, đang vào ${CAP.inboundPerHour==null?'—':fmtN(CAP.inboundPerHour)+'/giờ'} → giải phóng backlog ${clear}.`); }
  if(AR.delivery && AR.delivery.actNow) parts.push(`<b>${fmtN(AR.delivery.actNow)}</b> đơn sắp trễ giao.`);
  const action= (over>0)?'→ Đẩy ngay nhóm quá hạn + ≤30′; nếu tải vào > năng lực thì tăng ca.':(actNow>0?'→ Ưu tiên nhóm ≤30′ trước cutoff.':'→ Trong tầm kiểm soát.');
  insightBanner('#arInsight', sev, parts.join(' ')+` <span style="color:var(--green)">${action}</span>`);
}

/* ================= PRO: scorecard + tìm đơn + Trend + export ================= */
function renderScorecard(){
  const box=$('#slaScorecard'); if(!box) return;
  if(!SLA_SCORE||!SLA_SCORE.length){ box.innerHTML='<div class="empty">Chưa có dữ liệu (cần cycle-time / SLA).</div>'; return; }
  const rows=SLA_SCORE.map((r,i)=>[(i===0?'🔴 ':'')+r.carrier, fmtN(r.waiting), r.avg_wait+'′', fmtN(r.delivered),
    r.deliver_ontime==null?'—':Math.round(r.deliver_ontime*100)+'%', fmtN(r.late), r.dwell_h==null?'—':r.dwell_h+'h',
    `<b style="color:${r.score<70?'var(--red)':r.score<90?'var(--amber)':'var(--green)'}">${r.score}</b>`]);
  box.innerHTML=''; box.appendChild(tableFrom(['ĐVVC','Chờ bàn giao','Chờ TB','Đã giao','On-time','Trễ','Dwell TB','Điểm'], rows));
}

/* ---- Tìm đơn toàn cục ---- */
function globalSearch(q){
  q=(q||'').trim().toLowerCase(); const box=$('#searchResults');
  if(!q){ box.style.display='none'; box.innerHTML=''; return; }
  const seen={}, res=[];
  const add=(o,src,extra)=>{ const code=String(o.order_code||''); if(!code||seen[code]) return; const ref=String(o.ref_code||'');
    if(code.toLowerCase().includes(q)||ref.toLowerCase().includes(q)){ seen[code]=1; res.push({code,ref,src,extra}); } };
  flatBacklog().forEach(o=>add(o,'Backlog',(o.sub_status||o.status||'')+' · '+((o.warehouse&&(o.warehouse.code||o.warehouse.name))||'')));
  (CYC_RAW.orders||[]).forEach(o=>add(o,'Chi tiết',(o.ms&&o.ms.delivered)?'Đã giao':((o.ms&&o.ms.handover_to_3pl)?'Đã bàn giao':'—')));
  box.style.display='block'; box.innerHTML='';
  const close=el('button','ghost','✕'); close.style.cssText='padding:3px 9px;float:right'; close.onclick=()=>{ box.style.display='none'; $('#globalSearch').value=''; };
  box.appendChild(close);
  if(!res.length){ box.appendChild(el('div',null,`Không thấy đơn khớp “${q}”. (Mở tab có dữ liệu tương ứng trước để tra sâu hơn.)`)); return; }
  box.appendChild(el('div',null,`<span style="color:var(--mut)">Kết quả: ${res.length}</span>`));
  box.appendChild(tableFrom(['Mã đơn','Mã đối tác','Nguồn','Trạng thái / Kho'], res.slice(0,40).map(r=>[r.code,r.ref||'—',r.src,r.extra||'—'])));
}
if($('#globalSearch')) $('#globalSearch').oninput=(e)=>globalSearch(e.target.value);

/* ---- Trend tab (đọc backend) ---- */
async function getBackend(){ try{ if(typeof chrome!=='undefined'&&chrome.storage){ const {backend}=await chrome.storage.local.get('backend'); return backend; } }catch(e){} return null; }
async function trendRefresh(){
  const be=await getBackend();
  if(!be||!be.url){ $('#trendStatus').textContent='Chưa cấu hình Backend URL (thanh 🔔 ở tab Director).'; $('#trendBanner').innerHTML=''; return; }
  const base=be.url.replace(/\/$/,''); $('#trendStatus').textContent='Đang tải…';
  try{
    const [state,trend,wbr]=await Promise.all([
      fetch(base+'/api/state').then(r=>r.json()).catch(()=>null),
      fetch(base+'/api/trend?n=100').then(r=>r.json()).catch(()=>[]),
      fetch(base+'/api/wbr').then(r=>r.json()).catch(()=>null)]);
    renderTrend(state,trend,wbr); $('#trendStatus').textContent='Cập nhật '+new Date().toLocaleTimeString('vi-VN');
  }catch(e){ $('#trendStatus').textContent='Lỗi tải backend: '+e.message+' (kiểm tra URL/quyền host).'; }
}
$('#trendRefreshBtn') && ($('#trendRefreshBtn').onclick=trendRefresh);
function renderTrend(state,trend,wbr){
  if(state&&state.status){ const st=state.status;
    $('#trendBanner').innerHTML=`<div class="banner ${st}" style="margin-bottom:14px"><span class="dot"></span><span class="big">${st==='red'?'CẦN XỬ LÝ':st==='amber'?'CẢNH BÁO':'ỔN ĐỊNH'}</span><span style="color:var(--mut);font-weight:600">Backlog ${fmtN((state.summary&&state.summary.backlog)||0)} · P1 ${state.counts.P1}</span></div>`; }
  const good=['pack_ontime','deliver_ontime','fifo']; const wb=$('#trendWbr'); wb.innerHTML='';
  if(wbr&&wbr.metrics&&wbr.metrics.length){ wb.appendChild(tableFrom(['Chỉ số','Tuần này','Tuần trước','Δ'], wbr.metrics.map(m=>{
    const up=m.delta>0; const col=m.delta==null?'':(((good.includes(m.key)?up:!up))?'color:var(--green)':'color:var(--red)');
    return [m.label, m.cur==null?'—':fmtN(m.cur), m.prev==null?'—':fmtN(m.prev), `<span style="${col}">${m.delta==null?'—':(up?'+':'')+m.delta+'%'}</span>`]; }))); }
  else wb.innerHTML='<div class="empty">Chưa đủ 2 tuần dữ liệu để so.</div>';
  const cols=[['ts','Lúc'],['backlog','Backlog'],['P1','P1'],['no_label','Chưa nhãn'],['handover_overdue','Chưa bàn giao'],['aging_gt72','>72h'],['atrisk_pack','Sắp trễ'],['pack_ontime','Đóng gói%'],['deliver_ontime','Giao%'],['fifo','FIFO%']];
  const rows=(trend||[]).slice().reverse().map(r=>cols.map(c=>c[0]==='ts'?new Date(r.ts).toLocaleString('vi-VN'):(r[c[0]]==null?'—':fmtN(r[c[0]]))));
  $('#trendTable').innerHTML=''; $('#trendTable').appendChild(tableFrom(cols.map(c=>c[1]), rows.length?rows:[cols.map(()=>'—')]));
}

/* ---- Export CSV chung ---- */
function exportCSV(filename, headers, rows){
  const esc=v=>'"'+String(v==null?'':v).replace(/<[^>]+>/g,'').replace(/"/g,'""')+'"';
  const csv=headers.map(esc).join(',')+'\n'+rows.map(r=>r.map(esc).join(',')).join('\n');
  const blob=new Blob(['﻿'+csv],{type:'text/csv'}); const a=document.createElement('a');
  a.href=URL.createObjectURL(blob); a.download=filename+'-'+new Date().toISOString().slice(0,10)+'.csv'; a.click();
}
/* Xuất TOÀN BỘ backlog tab Sắp trễ → 1 file Excel, mỗi nhóm 1 sheet (không cắt 400 dòng như trên UI) */
window.__exportAtRisk=()=>{
  if(!AR){ alert('Chưa có dữ liệu — bấm “↻ Tính sắp trễ” trước.'); return; }
  const now=new Date();
  const lvl=b=>AR_LABEL[b]||b||'';
  const ovLvl=h=>h>72?'overdue':h>48?'critical':h>24?'warning':'watch';
  const pk=AR.packing.list||[], ho=(AR.handover&&AR.handover.list)||[], dl=AR.delivery.list||[];
  const ov=(SHIP&&SHIP.overdueDeliver)||[];
  const bl=(ROWS&&ROWS.length)?ROWS:[];

  const S_PK=pk.map(r=>({ 'Mã đơn':r.order_code, 'Mã đối tác':r.ref_code||'', 'Kênh':r.channel||'', 'Kho':whLabel(r.warehouse)||'',
    'Tạo lúc':r.created_at||'', 'Hạn đóng gói':r.deadline||'', 'Còn lại (phút)':r.remain, 'Mức':lvl(r.bucket),
    'Trạng thái':subLabel(r.sub), 'Chưa nhãn':r.no_label?'x':'' }));
  const S_HO=ho.map(r=>({ 'Mã đơn':r.order_code, 'Mã đối tác':r.ref_code||'', 'Kho':whLabel(r.warehouse)||'', 'ĐVVC':r.carrier||'',
    'Trạng thái':subLabel(r.sub), 'Kẹt (phút)':r.stuck_min, 'Tới hạn (phút)':r.remain, 'Mức':lvl(r.bucket) }));
  const S_OV=ov.map(r=>({ 'Mã đơn':r.order_code, 'Mã đối tác':r.ref_code||'', 'ĐVVC':r.carrier||'', 'Kho':whLabel(r.warehouse)||'',
    'Hạn giao':(r.promised||'').slice(0,10), 'Quá hạn (giờ)':r.over_h, 'Mức':lvl(ovLvl(r.over_h||0)), 'Trạng thái':r.state||'' }));
  const S_DL=dl.map(r=>({ 'Mã đơn':r.order_code, 'Mã đối tác':r.ref_code||'', 'ĐVVC':r.carrier||'', 'Kho':whLabel(r.warehouse)||'',
    'Hạn giao':(r.promised||'').slice(0,10), 'Còn lại (phút)':r.remain, 'Mức':lvl(r.bucket) }));
  const S_BL=bl.map(r=>({ 'Mã đơn':r.order_code, 'Mã đối tác':r.ref_code||'', 'Trạng thái':r.sub_label||r.sub_status||'',
    'Kho':whLabel(r.warehouse)||'', 'ĐVVC':r.carrier||'', 'Kênh':r.platform||'', 'Tuổi (h)':r.age_h, 'Ở khâu (h)':r.stage_age_h,
    'Cờ':(r.flags||[]).map(f=>(E.FLAG_LABELS&&E.FLAG_LABELS[f])||f).join(' | ') }));

  // Tổng quan: số đơn theo mức cho từng nhóm
  const cnt=(rows)=>{ const o={overdue:0,critical:0,warning:0,watch:0}; rows.forEach(r=>{ const k=Object.keys(AR_LABEL).find(k=>AR_LABEL[k]===r['Mức']); if(k)o[k]++; }); return o; };
  const sumRow=(name,rows)=>{ const c=cnt(rows); return { 'Nhóm':name, 'Tổng':rows.length, 'Quá hạn':c.overdue, 'Nguy cấp':c.critical, 'Cảnh báo':c.warning, 'Theo dõi':c.watch }; };
  const S_SUM=[ sumRow('Đóng gói sắp trễ',S_PK), sumRow('Kẹt bàn giao',S_HO), sumRow('Quá hạn giao (chưa giao)',S_OV), sumRow('Giao sắp trễ',S_DL),
    { 'Nhóm':'Toàn bộ backlog', 'Tổng':S_BL.length } ];
  if(CAP) S_SUM.push({}, { 'Nhóm':'Năng lực/giờ', 'Tổng':CAP.capPerHour }, { 'Nhóm':'Nhịp đơn vào/giờ', 'Tổng':CAP.inboundPerHour==null?'':CAP.inboundPerHour },
    { 'Nhóm':'Giải phóng backlog (h)', 'Tổng':CAP.hoursToClear===Infinity?'Không kịp':CAP.hoursToClear });
  S_SUM.push({}, { 'Nhóm':'Xuất lúc', 'Tổng':now.toLocaleString('vi-VN') });

  // Theo kho × nhóm
  const wh={}; const add=(rows,col)=>rows.forEach(r=>{ const k=r['Kho']||'—'; wh[k]=wh[k]||{'Kho':k,'Đóng gói sắp trễ':0,'Kẹt bàn giao':0,'Quá hạn giao':0,'Giao sắp trễ':0,'Backlog':0}; wh[k][col]++; });
  add(S_PK,'Đóng gói sắp trễ'); add(S_HO,'Kẹt bàn giao'); add(S_OV,'Quá hạn giao'); add(S_DL,'Giao sắp trễ'); add(S_BL,'Backlog');
  const S_WH=Object.values(wh).sort((a,b)=>(b['Đóng gói sắp trễ']+b['Kẹt bàn giao']+b['Quá hạn giao'])-(a['Đóng gói sắp trễ']+a['Kẹt bàn giao']+a['Quá hạn giao']));

  const stamp=now.getFullYear()+String(now.getMonth()+1).padStart(2,'0')+String(now.getDate()).padStart(2,'0')+'_'+String(now.getHours()).padStart(2,'0')+String(now.getMinutes()).padStart(2,'0');
  xlsxDownload([
    { name:'Tổng quan', rows:S_SUM },
    { name:'Theo kho', rows:S_WH },
    { name:'Đóng gói sắp trễ', rows:S_PK },
    { name:'Kẹt bàn giao', rows:S_HO },
    { name:'Quá hạn giao', rows:S_OV.length?S_OV:[{ 'Ghi chú': SHIP_LOADED?'Không có đơn quá hạn giao':'Chưa nạp đơn vận chuyển — bấm ↻ Tính sắp trễ' }] },
    { name:'Giao sắp trễ', rows:S_DL },
    { name:'Toàn bộ backlog', rows:S_BL }
  ], `TNSL_SapTre_Backlog_${stamp}.xlsx`);
};
if($('#arExportBtn')) $('#arExportBtn').onclick=window.__exportAtRisk;
window.__exportSlaPk=()=>{ if(!SLA_PK) return; exportCSV('sla-dong-goi-tre',['Mã đơn','Mã đối tác','Kênh','Hạn','Trễ(phút)','Trạng thái','Kho'],
  SLA_PK.lateList.map(r=>[r.order_code,r.ref_code,r.channel,r.deadline,r.over,r.state,r.warehouse])); };


function renderBrandBreakdown(){
  if(!$('#brandTable')) return;
  const bb=E.buildBrandBreakdown(ROWS);
  const cols5=['Backlog','Chưa nhãn','Chưa bàn giao','>72h'];
  function fill(id, label, list){ if(!$(id)) return; const rows=list.slice(0,15).map(x=>[x.key, fmtN(x.backlog), fmtN(x.no_label), fmtN(x.handover_overdue), fmtN(x.aging_gt72)]);
    $(id).innerHTML=''; $(id).appendChild(tableFrom([label,...cols5], rows.length?rows:[['—','0','0','0','0']])); }
  fill('#brandTable','Brand', bb.byBrand);
  fill('#groupBrandTable','Group brand', bb.byGroupBrand);
  fill('#channelTable','Channel', bb.byChannel);
  fill('#opolloTable','Opollo Channel', bb.byOpollo);
}

/* ================= PHIẾU RÚT HÀNG -> EXCEL ================= */
let RS_BUSY = false;

async function rsInit() {
  const tokens = await getTokens();
  const ids = Object.keys(tokens);
  const box = $('#rsTokens');
  if (!box) return;
  box.innerHTML = '';
  if (!ids.length) {
    box.innerHTML = '<div class="card amber"><div class="n">0</div><div class="l">Chưa có token — mở TikiNOW Center</div></div>';
    return;
  }
  ids.forEach(id => {
    const ageMin = Math.round((Date.now() - tokens[id].at) / 60000);
    const fresh = ageMin < 30;
    const c = el('div', 'card ' + (fresh ? 'green' : 'amber'));
    c.innerHTML = `<div class="n" style="font-size:15px">${nameOf(id)}</div><div class="l">token ${fresh ? 'mới ' + ageMin + '′' : 'cũ ' + ageMin + '′'} · seller ${id}</div>`;
    box.appendChild(c);
  });
}

function rsLog(msg, color) {
  const li = document.createElement('li');
  if (color) li.style.color = color;
  const t = new Date().toLocaleTimeString('vi-VN');
  li.textContent = `[${t}] ${msg}`;
  $('#rsLog').appendChild(li);
  $('#rsLog').scrollTop = $('#rsLog').scrollHeight;
}

function rsBuildAndDownload(res) {
  const { shipments, detailsById, skuMap } = res;
  const detailRows = [], summaryRows = [];
  const contact = d => {
    const c = d && d.delivery_info && d.delivery_info.contact;
    return c ? [c.name, c.phone].filter(Boolean).join(' - ') : '';
  };
  shipments.forEach(s => {
    const d = detailsById[s.shipment_id] || s;
    const items = (d && d.items) || [];
    const acc = nameOf(s.__sid);
    let gcTotal = 0;
    items.forEach(it => {
      const info = skuMap[String(it.sku)] || {};
      const base = {
        'Account': acc,
        'Ma phieu rut hang': s.shipment_code || '',
        'Ma phieu nha ban': s.ref_code || '',
        'Trang thai': s.status_vi || s.status || '',
        'Kho ban dau': s.pickup_warehouse_code || '',
        'Kho nhan hang': s.warehouse_code || '',
        'Ngay tao': s.created_at || '',
        'Nguoi tao': s.created_by || '',
        'Ghi chu phieu': s.note || '',
        'SKU': it.sku || '',
        'Ten san pham': info.name || '',
        'Ma san pham': info.code || '',
        'Master SKU': info.master_sku || '',
        'SL yeu cau': it.expected_quantity != null ? it.expected_quantity : '',
        'SL xac nhan': it.confirmed_quantity != null ? it.confirmed_quantity : '',
        'SL tu choi': it.rejected_quantity != null ? it.rejected_quantity : '',
        'SL da nhan': it.received_quantity != null ? it.received_quantity : '',
        'SL thanh ly': it.liquidated_quantity != null ? it.liquidated_quantity : '',
        'Ly do tu choi': it.rejected_reason || '',
        'Ghi chu SP': it.note || ''
      };
      const grades = Array.isArray(it.grades) ? it.grades : [];
      let emitted = 0;
      grades.forEach(g => {
        const codes = Array.isArray(g.gc_codes) ? g.gc_codes : [];
        if (codes.length) codes.forEach(gc => { detailRows.push(Object.assign({}, base, { 'Grade': g.grade || '', 'Ma GC': gc })); emitted++; gcTotal++; });
        else { detailRows.push(Object.assign({}, base, { 'Grade': g.grade || '', 'Ma GC': '' })); emitted++; }
      });
      if (!emitted) {
        const codes = Array.isArray(it.gc_codes) ? it.gc_codes : [];
        if (codes.length) codes.forEach(gc => { detailRows.push(Object.assign({}, base, { 'Grade': '', 'Ma GC': gc })); gcTotal++; });
        else detailRows.push(Object.assign({}, base, { 'Grade': '', 'Ma GC': '' }));
      }
    });
    summaryRows.push({
      'Account': acc,
      'Ma phieu rut hang': s.shipment_code || '',
      'Ma phieu nha ban': s.ref_code || '',
      'Trang thai': s.status_vi || s.status || '',
      'Loai': s.type || '',
      'Kho ban dau': s.pickup_warehouse_code || '',
      'Kho nhan hang': s.warehouse_code || '',
      'Nguoi lien he': contact(d),
      'SL yeu cau': s.expected_quantity != null ? s.expected_quantity : '',
      'SL xac nhan': s.confirmed_quantity != null ? s.confirmed_quantity : '',
      'SL tu choi': s.rejected_quantity != null ? s.rejected_quantity : '',
      'SL da nhan': s.received_quantity != null ? s.received_quantity : '',
      'SL thanh ly': s.liquidated_quantity != null ? s.liquidated_quantity : '',
      'So dong SP': items.length,
      'Tong ma GC': gcTotal,
      'Ghi chu': s.note || '',
      'Shipping plan': s.shipping_plan || '',
      'Ngay tao': s.created_at || '',
      'Nguoi tao': s.created_by || '',
      'Cap nhat cuoi': s.updated_at || '',
      'Nguoi cap nhat': s.updated_by || ''
    });
  });

  const autoW = (ws, rows) => {
    if (!rows.length) return;
    ws['!cols'] = Object.keys(rows[0]).map(k => {
      let w = k.length;
      for (const r of rows) { const v = r[k] == null ? '' : String(r[k]); if (v.length > w) w = v.length; }
      return { wch: Math.min(Math.max(w + 2, 8), 50) };
    });
  };
  const wb = XLSX.utils.book_new();
  const ws1 = XLSX.utils.json_to_sheet(detailRows.length ? detailRows : [{ 'Ghi chu': 'Khong co du lieu' }]);
  const ws2 = XLSX.utils.json_to_sheet(summaryRows.length ? summaryRows : [{ 'Ghi chu': 'Khong co du lieu' }]);
  autoW(ws1, detailRows); autoW(ws2, summaryRows);
  XLSX.utils.book_append_sheet(wb, ws1, 'Chi tiet SP');
  XLSX.utils.book_append_sheet(wb, ws2, 'Tong hop phieu');

  const buf = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
  const blob = new Blob([buf], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  const d = new Date(), p = n => String(n).padStart(2, '0');
  const stamp = `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}_${p(d.getHours())}${p(d.getMinutes())}`;
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `TNC_PhieuRutHang_${stamp}.xlsx`;
  a.click();
  return { detail: detailRows.length, summary: summaryRows.length };
}

async function rsExport() {
  if (RS_BUSY) return;
  const btn = $('#rsExportBtn');
  const tokens = await getTokens();
  const ids = Object.keys(tokens);
  $('#rsLog').innerHTML = ''; $('#rsProgress').textContent = '';
  if (!ids.length) { rsLog('Chưa có token nào. Mở TikiNOW Center → Phiếu rút hàng → Tìm kiếm.', '#fca5a5'); return; }

  RS_BUSY = true; btn.disabled = true; btn.textContent = 'Đang xử lý…';
  const status = $('#rsStatus').value || '';
  const days = Math.max(0, parseInt($('#rsDays').value, 10) || 0);
  const dateField = $('#rsDateField').value || 'created_at';
  const maxShipments = Math.max(10, parseInt($('#rsMax').value, 10) || 3000);
  const scopeTxt = (days > 0 ? `${days} ngày (${dateField === 'updated_at' ? 'cập nhật' : 'tạo'})` : 'toàn thời gian') + (status ? ' · ' + status : ' · mọi trạng thái');
  rsLog(`Bắt đầu xuất (${ids.length} account · ${scopeTxt} · tối đa ${maxShipments})…`);
  try {
    const res = await C.collectReturnShipments(tokens, {
      status, days, dateField, maxShipments,
      onProgress: (sid, msg) => { $('#rsProgress').textContent = `${nameOf(sid)}: ${msg}`; }
    });
    Object.keys(res.errors || {}).forEach(sid => rsLog(`Lỗi ${nameOf(sid)}: ${res.errors[sid]}`, '#fca5a5'));
    if (res.capped) rsLog(`⚠ Đã chạm ngưỡng tối đa ${res.cap} phiếu (tổng khớp filter ~${fmtN(res.grandTotal)}). Thu hẹp số ngày/trạng thái hoặc tăng “Tối đa” nếu cần thêm.`, '#fcd34d');
    rsLog(`Đã kéo ${res.shipments.length} phiếu, tra cứu ${Object.keys(res.skuMap).length} SKU.`);
    if (!res.shipments.length) { rsLog('Không có phiếu nào để xuất.', '#fcd34d'); return; }
    $('#rsProgress').textContent = 'Đang tạo file Excel…';
    const out = rsBuildAndDownload(res);
    $('#rsProgress').textContent = '';
    rsLog(`Xong! Xuất ${out.summary} phiếu, ${out.detail} dòng chi tiết. File đã tải về.`, '#4ade80');
  } catch (e) {
    $('#rsProgress').textContent = '';
    rsLog('Lỗi: ' + (e && e.message || e), '#fca5a5');
  } finally {
    RS_BUSY = false; btn.disabled = false; btn.textContent = '⤓ Xuất Excel (phiếu + chi tiết SKU/GC)';
  }
}

if ($('#rsExportBtn')) $('#rsExportBtn').onclick = rsExport;

/* ============ Xoá cache cycle-time ============ */
if ($('#cycClearBtn')) $('#cycClearBtn').onclick = async () => {
  try { await C.clearCycleCache(); } catch(e){}
  CYC_LOADED = false; CYC_RAW = { orders: [] }; SLA_LOADED = false;
  cycSetStatus('Đã xoá cache chi tiết đơn. Bấm “↻ Kéo cycle-time” để kéo lại từ đầu.');
};

/* ============ Bộ chọn ACCOUNT (áp cho mọi tab) ============ */
async function updateAcctBtn(){
  const all = await getAllTokens(); const total = Object.keys(all).length;
  await loadAccountSel();
  const n = ACCOUNT_SEL ? [...ACCOUNT_SEL].filter(s => all[s]).length : total;
  if ($('#acctBtn')) $('#acctBtn').textContent = '⚙ Account (' + (ACCOUNT_SEL ? (n + '/' + total) : ('tất cả ' + total)) + ')';
}
async function openAcctPanel(){
  await loadAccountSel();
  const all = await getAllTokens();
  const ids = Object.keys(all).sort((a,b)=>nameOf(a).localeCompare(nameOf(b)));
  const box = $('#acctList'); box.innerHTML = '';
  if (!ids.length){ box.innerHTML = '<div style="color:var(--mut)">Chưa có account nào — mở TikiNOW Center để extension bắt token.</div>'; }
  ids.forEach(sid => {
    const checked = !ACCOUNT_SEL || ACCOUNT_SEL.has(String(sid));
    const l = el('label'); l.style.cssText = 'display:flex;gap:8px;align-items:center;cursor:pointer';
    l.innerHTML = `<input type="checkbox" class="acctChk" value="${sid}" ${checked?'checked':''}> <span>${nameOf(sid)} <em style="color:var(--mut);font-style:normal">· ${sid}</em></span>`;
    box.appendChild(l);
  });
  $('#acctPanel').style.display = 'block';
}
function closeAcctPanel(){ if($('#acctPanel')) $('#acctPanel').style.display='none'; }
if ($('#acctBtn')) $('#acctBtn').onclick = (e) => { e.stopPropagation(); const p=$('#acctPanel'); if(p.style.display==='block') closeAcctPanel(); else openAcctPanel(); };
if ($('#acctAll')) $('#acctAll').onclick = () => document.querySelectorAll('.acctChk').forEach(c=>c.checked=true);
if ($('#acctNone')) $('#acctNone').onclick = () => document.querySelectorAll('.acctChk').forEach(c=>c.checked=false);
if ($('#acctPanel')) $('#acctPanel').addEventListener('click', e=>e.stopPropagation());
document.addEventListener('click', ()=>{ if($('#acctPanel') && $('#acctPanel').style.display==='block') closeAcctPanel(); });
if ($('#acctSave')) $('#acctSave').onclick = async () => {
  const chks = [...document.querySelectorAll('.acctChk')];
  const sel = chks.filter(c=>c.checked).map(c=>c.value);
  // chọn hết hoặc bỏ hết -> coi như TẤT CẢ (lưu rỗng)
  const store = (sel.length===0 || sel.length===chks.length) ? [] : sel;
  try { await chrome.storage.local.set({ accountSel: store }); } catch(e){}
  await updateAcctBtn(); closeAcctPanel();
  // reset để các tab kéo lại theo lựa chọn mới
  PROD_LOADED=false; CYC_LOADED=false; SHIP_LOADED=false; OUT_LOADED=false; AR_LOADED=false; SLA_LOADED=false; DIR_LOADED=false;
  RAW = { rawBySeller:{}, counts:{}, errors:{}, window:{} };
  $('#status').textContent = 'Đã đổi account theo dõi — bấm “↻ Kéo dữ liệu” để cập nhật.';
};
loadAccountSel().then(updateAcctBtn);

/* ================= VẬN CHUYỂN & HOÀN ================= */
let RAW_SHIP = { orders: [], errors: {} }, SHIP = null, SHIP_LOADED = false;
async function shipRefresh(){
  const btn = $('#shipRefreshBtn'); if (btn) btn.disabled = true;
  $('#shipStatus').textContent = 'Đang kéo…';
  const tokens = await getTokens();
  if (!Object.keys(tokens).length){ $('#shipStatus').textContent = 'Chưa có token — mở TikiNOW / switch account.'; if (btn) btn.disabled = false; return; }
  RAW_SHIP = await C.collectShipping(tokens, { onProgress:(sid,msg)=>{ $('#shipStatus').textContent = `${nameOf(sid)} · ${msg}`; } });
  SHIP = E.buildShipping(RAW_SHIP.orders, CFG, new Date());
  SHIP_LOADED = true;
  renderShip();
  const err = Object.keys(RAW_SHIP.errors || {});
  $('#shipStatus').textContent = `Kéo ${fmtN(SHIP.total)} đơn đang vận chuyển · có hạn giao ${fmtN(RAW_SHIP.promisedCount||0)} · thiếu hạn ${fmtN(RAW_SHIP.missingPromised||0)} · ${new Date().toLocaleTimeString('vi-VN')}` + (err.length ? ` · lỗi: ${err.map(nameOf).join(', ')}` : '');
  if (btn) btn.disabled = false;
}
if ($('#shipRefreshBtn')) $('#shipRefreshBtn').onclick = () => { SHIP_LOADED = false; shipRefresh(); };

function renderShip(){
  if (!SHIP) return;
  const c = $('#shipCards'); c.innerHTML = '';
  const stuckN = SHIP.stuck.length, retN = SHIP.returning.length, odN = SHIP.overdueDeliver.length;
  [['blue', fmtN(SHIP.total), 'Đang vận chuyển'],
   ['blue', fmtN(SHIP.state.delivering), 'Đang giao'],
   ['amber', fmtN(SHIP.state.transit), 'Trung chuyển / mới bàn giao'],
   ['amber', fmtN(SHIP.state.storing), 'Lưu tại ĐVVC'],
   ['purple', fmtN(SHIP.state.returning), 'Đang chuyển hoàn'],
   ['red', fmtN(stuckN), `Kẹt > ${SHIP.shH}h`],
   ['red', fmtN(odN), 'Quá hạn giao']
  ].forEach(([cls,n,l])=>{ const d=el('div','card '+cls); d.appendChild(el('div','n',n)); d.appendChild(el('div','l',l)); c.appendChild(d); });

  const bits = [];
  if (stuckN) bits.push(`<b style="color:#fca5a5">${stuckN}</b> đơn kẹt > ${SHIP.shH}h`);
  if (retN) bits.push(`<b style="color:#d8b4fe">${retN}</b> đơn đang chuyển hoàn`);
  if (odN) bits.push(`<b style="color:#fca5a5">${odN}</b> đơn quá hạn giao`);
  $('#shipInsight').innerHTML = bits.length ? `<div class="banner ${(stuckN||odN)?'red':'amber'}" style="margin-bottom:14px"><span class="dot"></span><span class="big">Cần xử lý</span><span style="color:var(--mut);font-weight:600">${bits.join(' · ')}</span></div>` : `<div class="banner green" style="margin-bottom:14px"><span class="dot"></span><span class="big">Ổn</span><span style="color:var(--mut);font-weight:600">Không có đơn kẹt/quá hạn giao</span></div>`;

  const stab = $('#shipStuck'); stab.innerHTML = '';
  stab.appendChild(tableFrom(['Mã đơn','Mã đối tác','ĐVVC','Kho','Trạng thái','Tuổi đơn','Ở khâu'],
    SHIP.stuck.length ? SHIP.stuck.slice(0,300).map(r=>[r.order_code, r.ref_code||'—', r.carrier, r.warehouse||'—', r.state, fmtDur((r.age_h||0)*60), r.stage_h!=null?fmtDur(r.stage_h*60):'—'])
                      : [['—','—','—','—','—','—','—']]));

  const rtab = $('#shipReturn'); rtab.innerHTML = '';
  rtab.appendChild(tableFrom(['Mã đơn','Mã đối tác','ĐVVC','Kho','Tuổi đơn','Đang hoàn'],
    SHIP.returning.length ? SHIP.returning.slice(0,300).map(r=>[r.order_code, r.ref_code||'—', r.carrier, r.warehouse||'—', r.age_h!=null?fmtDur(r.age_h*60):'—', r.stage_h!=null?fmtDur(r.stage_h*60):'—'])
                          : [['—','—','—','—','—','—']]));

  const otab = $('#shipOverdue'); otab.innerHTML = '';
  otab.appendChild(tableFrom(['Mã đơn','Mã đối tác','ĐVVC','Hạn giao','Quá hạn','Trạng thái'],
    SHIP.overdueDeliver.length ? SHIP.overdueDeliver.slice(0,300).map(r=>[r.order_code, r.ref_code||'—', r.carrier, (r.promised||'').slice(0,10), `<span class="age gt72">${fmtDur((r.over_h||0)*60)}</span>`, r.state])
                               : [['—','—','—','—','—','—']]));

  const ctab = $('#shipCarrier'); ctab.innerHTML = '';
  ctab.appendChild(tableFrom(['ĐVVC','Tổng','Đang giao','Trung chuyển','Lưu ĐVVC','Chuyển hoàn','Kẹt'],
    SHIP.carriers.length ? SHIP.carriers.map((v,i)=>[ (i===0&&v.stuck>0?'🔴 ':'')+v.carrier, fmtN(v.total), fmtN(v.delivering), fmtN(v.transit), fmtN(v.storing),
        v.returning?`<span style="color:#d8b4fe;font-weight:700">${fmtN(v.returning)}</span>`:'0', v.stuck?`<b style="color:#fca5a5">${fmtN(v.stuck)}</b>`:'0'])
                         : [['—','0','0','0','0','0','0']]));
}

/* ================= KẾT QUẢ GIAO & ĐVVC ================= */
let OUT = null, OUT_LOADED = false;
const pctOr = (r)=> r==null?'—':(Math.round(r*1000)/10)+'%';
async function outRefresh(){
  const btn = $('#outRefreshBtn'); if (btn) btn.disabled = true;
  $('#outStatus').textContent = 'Đang tính…';
  const tokens = await getTokens();
  if (!Object.keys(tokens).length){ $('#outStatus').textContent = 'Chưa có token — mở TikiNOW / switch account.'; if (btn) btn.disabled = false; return; }
  const days = Math.max(1, parseInt($('#outDays').value,10) || 30);
  const data = await C.collectOutcomes(tokens, { days, onProgress:(sid,msg)=>{ $('#outStatus').textContent = `${nameOf(sid)} · ${msg}`; } });
  OUT = E.buildOutcomes(data, CFG, new Date());
  OUT_LOADED = true;
  renderOutcome();
  const err = Object.keys(data.errors||{});
  $('#outStatus').textContent = `${days} ngày · mẫu ${fmtN(OUT.sampleDelivered)} giao + ${fmtN(OUT.sampleCanceled)} huỷ · ${new Date().toLocaleTimeString('vi-VN')}` + (err.length?` · lỗi: ${err.map(nameOf).join(', ')}`:'');
  if (btn) btn.disabled = false;
}
if ($('#outRefreshBtn')) $('#outRefreshBtn').onclick = () => { OUT_LOADED = false; outRefresh(); };

function renderOutcome(){
  if (!OUT) return;
  const succ = OUT.successRate, sc = succ==null?'blue':(succ>=0.95?'green':(succ>=0.9?'amber':'red'));
  $('#outKpi').innerHTML = `
    <div class="k ${sc}"><div class="v">${pctOr(succ)}</div><div class="t">Tỷ lệ giao thành công</div></div>
    <div class="k green"><div class="v">${fmtN(OUT.totals.delivered)}</div><div class="t">Đã giao thành công</div></div>
    <div class="k red"><div class="v">${fmtN(OUT.totals.canceled)}</div><div class="t">Thất bại / huỷ (${pctOr(OUT.failRate)})</div></div>
    <div class="k blue"><div class="v">${fmtN(OUT.totals.shipping)}</div><div class="t">Đang vận chuyển</div></div>
    <div class="k amber"><div class="v">${fmtN(OUT.totals.awaiting_confirmation)}</div><div class="t">Chờ xác nhận</div></div>`;

  const rt = $('#outReasons'); rt.innerHTML='';
  rt.appendChild(tableFrom(['Lý do','Số đơn','%'],
    OUT.reasons.length ? OUT.reasons.slice(0,40).map(r=>[r.reason, fmtN(r.n), pctOr(r.n/Math.max(1,OUT.sampleCanceled))]) : [['—','0','—']]));

  const st = $('#outStages'); st.innerHTML='';
  const maxS = Math.max(1, ...OUT.stages.map(s=>s.n));
  st.innerHTML = OUT.stages.length ? OUT.stages.slice(0,10).map(s=>`
    <div class="bar"><div class="lab">${s.stage}</div><div class="track"><div class="fill" style="width:${Math.round(s.n/maxS*100)}%;background:var(--red)"></div></div><div class="val">${fmtN(s.n)}</div></div>`).join('') : '<div class="empty">—</div>';

  const ct = $('#outCarrier'); ct.innerHTML='';
  ct.appendChild(tableFrom(['ĐVVC','Tổng KQ','Đã giao','Thất bại','Tỷ lệ TC','On-time giao','Lead-time TB'],
    OUT.byCarrier.length ? OUT.byCarrier.map((c,i)=>[ (i===0&&c.failed>0?'🔴 ':'')+c.key, fmtN(c.total), fmtN(c.delivered),
        c.failed?`<b style="color:#fca5a5">${fmtN(c.failed)}</b>`:'0',
        `<span style="color:${c.successRate>=0.95?'#4ade80':(c.successRate>=0.9?'#fcd34d':'#fca5a5')};font-weight:700">${pctOr(c.successRate)}</span>`,
        pctOr(c.onTimeRate), c.leadH!=null?c.leadH+'h':'—']) : [['—','0','0','0','—','—','—']]));

  const wt = $('#outWh'); wt.innerHTML='';
  wt.appendChild(tableFrom(['Kho','Tổng KQ','Đã giao','Thất bại','Tỷ lệ TC','On-time giao','Lead-time TB'],
    OUT.byWarehouse.length ? OUT.byWarehouse.map(c=>[whLabel(c.key), fmtN(c.total), fmtN(c.delivered),
        c.failed?`<b style="color:#fca5a5">${fmtN(c.failed)}</b>`:'0', pctOr(c.successRate), pctOr(c.onTimeRate), c.leadH!=null?c.leadH+'h':'—']) : [['—','0','0','0','—','—','—']]));
}

/* ================= XUẤT EXCEL THEO TAB ĐANG XEM ================= */
function xlsxDownload(sheets, filename){
  const wb = XLSX.utils.book_new();
  const used = {};
  sheets.forEach(s => {
    const rows = (s.rows && s.rows.length) ? s.rows : [{ 'Ghi chú': 'Không có dữ liệu' }];
    const ws = XLSX.utils.json_to_sheet(rows);
    const keys = Object.keys(rows[0]);
    ws['!cols'] = keys.map(k => { let w = k.length; for (const r of rows){ const v = r[k]==null?'':String(r[k]); if (v.length>w) w=v.length; } return { wch: Math.min(Math.max(w+2,8),52) }; });
    let name = (s.name||'Sheet').replace(/[\\/?*\[\]:]/g,' ').slice(0,31);
    while (used[name]) name = (name.slice(0,28) + '_' + (used[name.slice(0,28)] = (used[name.slice(0,28)]||1)+1)).slice(0,31);
    used[name] = 1;
    XLSX.utils.book_append_sheet(wb, ws, name);
  });
  const buf = XLSX.write(wb, { bookType:'xlsx', type:'array' });
  const blob = new Blob([buf], { type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = filename; a.click();
}
function sheetsForView(v){
  switch(v){
    case 'backlog': {
      const src = (typeof filtered==='function') ? filtered() : ROWS;
      return [{ name:'Backlog', rows: src.map(r=>({
        'Mã đơn':r.order_code, 'Mã đối tác':r.ref_code||'', 'Trạng thái':r.sub_label||r.sub_status||'', 'Kho':r.warehouse||'',
        'ĐVVC':r.carrier||'', 'Tuổi (h)':r.age_h, 'Ở khâu (h)':r.stage_age_h, 'Kênh':r.platform||'',
        'Cờ':(r.flags||[]).map(f=>(E.FLAG_LABELS&&E.FLAG_LABELS[f])||f).join(' | ')
      })) }];
    }
    case 'prod': {
      if (!PROD) return null;
      const s=[{ name:'Năng suất theo kho', rows:Object.entries(PROD.byWh).map(([w,v])=>({ 'Kho':whLabel(w), 'Throughput':v.activity, 'Dispatch':v.dispatched, 'Inflow':v.inflow })) },
               { name:'Theo ngày', rows:PROD.daily }];
      if (PF){ s.push({ name:'Kịp hạn đóng gói theo giờ', rows:PF.hours.map(h=>({ 'Giờ':h.hour+'h', 'Đơn tới hạn':h.due, 'Công suất/giờ':h.cap, 'Thiếu luỹ kế':h.short })) });
               s.push({ name:'Kịp hạn theo kho', rows:PF.perWh.map(w=>({ 'Kho':whLabel(w.wh), 'Chờ đóng':w.pending, 'Quá hạn':w.overdue, 'Đến hạn ≤2h':w.due2h, 'Công suất/giờ':w.cap, 'Cần/giờ':w.req, 'Bù/giờ':w.gap, 'Người cần thêm':w.people })) }); }
      return s;
    }
    case 'cycle': return CYC ? [
      { name:'Đơn chậm nhất', rows:(CYC.slowest||[]).map(r=>({ 'Mã đơn':r.order_code, 'Mã đối tác':r.ref_code||'', 'Kho':r.warehouse||'', 'Dwell (phút)':r.dwell_min, 'Vượt SLA':r.breach?'x':'' })) },
      { name:'Khâu (trung vị phút)', rows:(CYC.stageStats||[]).map(s=>({ 'Khâu':s.label, 'Trung vị (phút)':s.median, 'Số đơn':s.n })) },
      { name:'Theo kho', rows:(CYC.whStats||[]).map(w=>({ 'Kho':whLabel(w.wh), 'Số đơn':w.n, 'Dwell TB (phút)':w.avg, 'Vượt SLA':w.breach })) }] : null;
    case 'sla': {
      if (!SLA_PK && !SLA_DL) return null; const s=[];
      if (SLA_PK){ s.push({ name:'Đóng gói trễ', rows:SLA_PK.lateList }); s.push({ name:'Đóng gói theo kênh', rows:SLA_PK.byChannel }); }
      if (SLA_DL){ s.push({ name:'Giao trễ', rows:SLA_DL.lateList }); s.push({ name:'Giao theo ĐVVC', rows:SLA_DL.byCarrier }); }
      return s;
    }
    case 'atrisk': return AR ? [
      { name:'Đóng gói sắp trễ', rows:AR.packing.list },
      { name:'Kẹt bàn giao', rows:(AR.handover&&AR.handover.list)||[] },
      { name:'Giao sắp trễ', rows:AR.delivery.list }] : null;
    case 'ship': return SHIP ? [
      { name:'Kẹt vận chuyển', rows:SHIP.stuck },
      { name:'Đang chuyển hoàn', rows:SHIP.returning },
      { name:'Quá hạn giao', rows:SHIP.overdueDeliver },
      { name:'Theo ĐVVC', rows:SHIP.carriers }] : null;
    case 'outcome': return OUT ? [
      { name:'Tổng hợp', rows:[{ 'Tỷ lệ giao thành công':pctOr(OUT.successRate), 'Đã giao':OUT.totals.delivered, 'Thất bại/huỷ':OUT.totals.canceled, 'Đang ship':OUT.totals.shipping, 'Chờ xác nhận':OUT.totals.awaiting_confirmation, 'Cửa sổ (ngày)':OUT.days }] },
      { name:'Lý do thất bại', rows:OUT.reasons },
      { name:'Khâu thất bại', rows:OUT.stages },
      { name:'ĐVVC', rows:OUT.byCarrier.map(c=>({ 'ĐVVC':c.key, 'Tổng KQ':c.total, 'Đã giao':c.delivered, 'Thất bại':c.failed, 'Tỷ lệ TC':pctOr(c.successRate), 'On-time':pctOr(c.onTimeRate), 'Lead-time (h)':c.leadH })) },
      { name:'Theo kho', rows:OUT.byWarehouse.map(c=>({ 'Kho':whLabel(c.key), 'Tổng KQ':c.total, 'Đã giao':c.delivered, 'Thất bại':c.failed, 'Tỷ lệ TC':pctOr(c.successRate), 'On-time':pctOr(c.onTimeRate), 'Lead-time (h)':c.leadH })) }] : null;
    default: return null;
  }
}
function exportCurrentTab(){
  const tab = document.querySelector('.tab.active'); const v = tab ? tab.dataset.view : '';
  if (v === 'rshipment'){ alert('Tab Phiếu rút hàng có nút “Xuất Excel” riêng ở trong tab.'); return; }
  const sheets = sheetsForView(v);
  if (!sheets){ alert('Tab này chưa có dữ liệu để xuất — bấm “↻ Kéo/Tính” trong tab trước đã.'); return; }
  xlsxDownload(sheets, `TNSL_${v}_${new Date().toISOString().slice(0,10)}.xlsx`);
}
if ($('#xlsxBtn')) $('#xlsxBtn').onclick = exportCurrentTab;

/* ================= XUẤT DỮ LIỆU BẤT KỲ (bắt endpoint trang đang xem) ================= */
let EXP_BUSY = false;
function expLog(msg, cls){ const li=document.createElement('li');
  if(cls==='err') li.style.color='#fca5a5'; else if(cls==='ok') li.style.color='#4ade80';
  li.textContent = '['+new Date().toLocaleTimeString('vi-VN')+'] '+msg; $('#expLog').appendChild(li); $('#expLog').scrollTop=$('#expLog').scrollHeight; }
function extractRecords(j){ if(!j) return []; const d=j.data;
  if(Array.isArray(d)) return d;
  if(d && typeof d==='object'){ const nk=Object.keys(d).filter(k=>/^\d+$/.test(k)); if(nk.length) return nk.map(k=>d[k]); if(Array.isArray(d.items)) return d.items; }
  return Array.isArray(j)?j:[]; }
function flattenRec(obj, prefix, out, depth){ out=out||{}; prefix=prefix||''; depth=depth||0;
  if(obj==null || typeof obj!=='object'){ out[prefix||'value']=obj==null?'':obj; return out; }
  for(const k in obj){ const v=obj[k]; const key=prefix?prefix+'.'+k:k;
    if(v==null){ out[key]=''; }
    else if(Array.isArray(v)){ out[key]=v.map(x=>(x&&typeof x==='object')?JSON.stringify(x):x).join(' | ').slice(0,800); }
    else if(typeof v==='object'){ if(depth<3) flattenRec(v,key,out,depth+1); else out[key]=JSON.stringify(v).slice(0,800); }
    else out[key]=v;
  } return out; }

async function expRefresh(){
  const { tnslExports } = await chrome.storage.local.get('tnslExports');
  const list = (tnslExports && tnslExports.list) || [];
  const box = $('#expList'); box.innerHTML='';
  if(!list.length){ box.innerHTML='<div class="empty">Chưa bắt được trang nào. Mở 1 trang danh sách trên TikiNOW Center, bấm Tìm kiếm/lật trang, rồi bấm “Làm mới”.</div>'; return; }
  const tbl=el('table'); const thead=el('thead'); const htr=el('tr');
  ['Trang (endpoint)','Loại','Tiêu đề','Số dòng','Bắt lúc','Xuất'].forEach(h=>htr.appendChild(el('th',null,h))); thead.appendChild(htr); tbl.appendChild(thead);
  const tb=el('tbody');
  list.forEach((rec,i)=>{ const tr=el('tr');
    tr.appendChild(el('td',null,rec.name));
    tr.appendChild(el('td',null, rec.kind==='report'?'<span class="tag t-purple">Báo cáo</span>':'<span class="tag t-blue">Danh sách</span>'));
    tr.appendChild(el('td',null,(rec.title||'').replace(/ - TikiNOW Center$/,'')||'—'));
    tr.appendChild(el('td',null, rec.kind==='report'?'—':(rec.total!=null?fmtN(rec.total):'?')));
    tr.appendChild(el('td',null, rec.at?new Date(rec.at).toLocaleTimeString('vi-VN'):'—'));
    const td=el('td'); const b=el('button','ghost'); b.style.padding='5px 10px'; b.textContent='⤓ Kéo & Xuất';
    b.onclick=()=>exportEndpoint(rec, b); td.appendChild(b); tr.appendChild(td);
    tb.appendChild(tr); });
  tbl.appendChild(tb); box.appendChild(tbl);
  $('#expStatus').textContent = `${list.length} trang · cập nhật ${new Date().toLocaleTimeString('vi-VN')}`;
}
if($('#expRefreshBtn')) $('#expRefreshBtn').onclick = expRefresh;

// Báo cáo (object tổng hợp) -> nhiều sheet: mảng thành sheet, object có mảng con tách sheet, số liệu phẳng gộp "Tổng quan".
function reportToSheets(d){
  const sheets=[]; const flatTop={};
  for(const k in (d||{})){
    const v=d[k];
    if(Array.isArray(v)){ sheets.push({ name:k, rows:v.map(x=>(x&&typeof x==='object')?flattenRec(x):{value:x}) }); }
    else if(v && typeof v==='object'){
      let hasArr=false;
      for(const kk in v){ if(Array.isArray(v[kk])){ hasArr=true; sheets.push({ name:k+'_'+kk, rows:v[kk].map(x=>(x&&typeof x==='object')?flattenRec(x):{value:x}) }); } }
      if(!hasArr) sheets.push({ name:k, rows:[flattenRec(v)] });
    } else { flatTop[k]=v; }
  }
  if(Object.keys(flatTop).length) sheets.unshift({ name:'Tổng quan', rows:[flatTop] });
  return sheets;
}
async function exportEndpoint(rec, btn){
  if(EXP_BUSY) return; EXP_BUSY=true; if(btn){ btn.disabled=true; btn.textContent='Đang kéo…'; }
  $('#expLog').innerHTML=''; $('#expProgress').textContent='';
  const fname = `TNSL_${rec.name.replace(/[^\w]+/g,'_').replace(/^_|_$/g,'').slice(0,50)}_${new Date().toISOString().slice(0,10)}.xlsx`;
  try{
    let auth = rec.auth;
    if(!auth){ const tokens=await getTokens(); let sid=rec.sellerId||null; try{ const eu=new URL(rec.url); sid=sid||eu.searchParams.get('seller_id')||eu.searchParams.get('filters.seller_id'); }catch(e){}
      auth = (sid && tokens[sid] && tokens[sid].token) || (Object.values(tokens)[0] && Object.values(tokens)[0].token); }
    if(!auth){ expLog('Không có token — mở lại TikiNOW rồi thử lại.', 'err'); return; }
    const u = new URL(rec.url);
    const hasPage = u.searchParams.has('page.page_number');
    // Lấy trang 1 để quyết định kiểu (list vs report)
    if(hasPage) u.searchParams.set('page.page_number', 1);
    expLog(`Bắt đầu: ${rec.name}`);
    let r1; try{ r1=await fetch(u.toString(), {headers:{Authorization:auth}}); }catch(e){ expLog('Lỗi mạng: '+e.message,'err'); return; }
    if(r1.status===401||r1.status===403){ expLog('Token hết hạn/không có quyền ('+r1.status+') — mở lại trang trên TikiNOW rồi Làm mới.','err'); return; }
    if(!r1.ok){ expLog('HTTP '+r1.status,'err'); return; }
    const j1=await r1.json();
    const rows1=extractRecords(j1);
    const dataObj=j1&&j1.data;
    const isReport = (rec.kind==='report') || (rows1.length===0 && dataObj && typeof dataObj==='object' && !Array.isArray(dataObj));

    if(isReport){
      const sheets=reportToSheets(dataObj||{});
      if(!sheets.length){ expLog('Báo cáo không có dữ liệu.','err'); return; }
      xlsxDownload(sheets, fname);
      expLog(`Xong! Xuất báo cáo ${sheets.length} sheet.`, 'ok');
      return;
    }

    // ----- LIST: gom trang 1 rồi kéo tiếp -----
    let all=rows1.slice(); const totalPage=rec.totalPage||(j1.paging&&j1.paging.total_page)||1;
    const maxPages=Math.min(hasPage?(totalPage||500):1, 500);
    $('#expProgress').textContent=`Trang 1/${hasPage?totalPage:1} · ${all.length} dòng`;
    for(let p=2;p<=maxPages;p++){
      u.searchParams.set('page.page_number', p);
      let r; try{ r=await fetch(u.toString(), {headers:{Authorization:auth}}); }catch(e){ expLog('Lỗi mạng trang '+p+': '+e.message,'err'); break; }
      if(!r.ok){ expLog('HTTP '+r.status+' tại trang '+p,'err'); break; }
      const j=await r.json(); const rows=extractRecords(j);
      all=all.concat(rows);
      $('#expProgress').textContent=`Trang ${p}/${totalPage} · ${all.length} dòng`;
      if(rows.length===0) break;
      await new Promise(rr=>setTimeout(rr,60));
    }
    if(!all.length){ expLog('Không có dữ liệu để xuất.','err'); return; }
    expLog(`Đã kéo ${all.length} dòng. Đang tạo Excel…`);
    const flat=all.map(x=>flattenRec(x));
    const sheetName=(rec.name.split('/').filter(Boolean).pop()||'data').slice(0,28);
    xlsxDownload([{name:sheetName, rows:flat}], fname);
    expLog(`Xong! Xuất ${all.length} dòng (${Object.keys(flat[0]||{}).length} cột).`, 'ok');
  }catch(e){ expLog('Lỗi: '+(e&&e.message||e),'err'); }
  finally{ EXP_BUSY=false; if(btn){ btn.disabled=false; btn.textContent='⤓ Kéo & Xuất'; } }
}
