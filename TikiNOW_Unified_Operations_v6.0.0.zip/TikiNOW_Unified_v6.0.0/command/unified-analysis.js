/* The analytic engines consume the Hub cache; no duplicate order HTTP pipeline. */
(function (root) {
  'use strict';
  const hub = () => { if (parent === root || !parent.UnifiedHub) throw new Error('Mở từ giao diện Unified Operations.'); return parent.UnifiedHub; };
  const snap = () => hub().snapshot();
  const get = (o, p) => p.split('.').reduce((v, k) => v == null ? null : v[k], o);
  let normalizedCache = { key: '', rows: [] };
  function selectedItems(tokens) {
    const s = snap(), allowed = tokens ? new Set(Object.keys(tokens)) : null;
    return { s, items: allowed ? s.items.filter(it => allowed.has(String(it.sid))) : s.items };
  }
  function sourceRow(it, s) { const d = s.details.get(it.key); return d && d.detail ? Object.assign({}, it.row, d.detail) : it.row; }
  function windowOf(s) {
    const metas = [...new Set(s.items.map(x => String(x.sid)))].map(sid => s.metadata[sid + '|orders']).filter(Boolean);
    return { from: metas.some(x => x.mode === 'open') ? '2020-01-01' : metas.map(x => x.from).filter(Boolean).sort()[0] || '', to: metas.map(x => x.to).filter(Boolean).sort().at(-1) || new Date().toISOString().slice(0,10) };
  }
  function countStatuses(rows) { const out = {}; for (const r of rows) { const key = r.status || 'unknown'; (out[key] || (out[key] = { total_order: 0 })).total_order++; } return out; }
  function grouped(tokens, statuses) {
    const { s, items } = selectedItems(tokens), rawBySeller = {};
    for (const it of items) { const row = sourceRow(it, s); if (!statuses || statuses.includes(row.status)) (rawBySeller[it.sid] || (rawBySeller[it.sid] = [])).push(row); }
    const counts = {}, pulled = {}, expected = {}, truncated = {};
    for (const sid of Object.keys(rawBySeller)) { counts[sid] = countStatuses(rawBySeller[sid]); pulled[sid] = expected[sid] = rawBySeller[sid].length; truncated[sid] = false; }
    return { rawBySeller, counts, pulled, expected, truncated, errors: {}, timing: {}, window: windowOf(s) };
  }
  function shippingRow(it, s) {
    const r = sourceRow(it, s);
    return { order_code: r.order_code, ref_code: r.ref_code, status: r.status, sub_status: r.sub_status, fulfillment_type: r.fulfillment_type, carrier: get(r, 'extra.delivery_partner') || get(r, 'extra.partner') || get(r, 'delivery.tracking.delivered_by'), warehouse: get(r, 'warehouse.name') || get(r, 'warehouse.code') || r.warehouse, created_at: r.created_at, updated_at: r.updated_at, promised: get(r,'delivery.promised_delivery_date'), sid: it.sid };
  }
  async function normalized(limit) {
    const s = snap(), key = s.revision + '|' + s.selected + '|' + (limit || 'all');
    if (normalizedCache.key === key) return normalizedCache.rows;
    const input = limit ? s.items.slice(0, limit) : s.items, rows = [];
    for (let i = 0; i < input.length; i++) {
      const it = input[i], d = s.details.get(it.key), sources = d && d.extra && d.extra.evidenceSources || [];
      const media = sources.filter(x => x.ok).map(x => ({ source: 'media_api', endpoint: x.id, payload: { data: parent.OrderInspect.links(x.payload, it.row.order_code, it.sid).map(v => ({ order_code: it.row.order_code, seller_id: it.sid, type: v.label, url: v.url, created_at: v.at })) } }));
      rows.push(root.TikiDataHub.normalizeOrder(it.row, d && d.detail, it.sid, media));
      if (i && i % 500 === 0) await new Promise(r => setTimeout(r, 0));
    }
    normalizedCache = { key, rows }; return rows;
  }
  const original = root.Collector;
  Object.assign(original, {
    collectAll: async tokens => grouped(tokens, (root.TNSL_CONFIG || {}).backlogStatuses || ['awaiting_confirmation','processing']),
    collectProductivity: async tokens => grouped(tokens),
    collectCycleTimes: async tokens => {
      const { s, items } = selectedItems(tokens), orders = [];
      for (const it of items) {
        const row = sourceRow(it, s); if (!Array.isArray(row.histories) || !row.histories.length) continue;
        const shaped = shippingRow(it, s); shaped.ms = root.BacklogEngine.firstMilestones(row.histories); shaped.platform = get(row, 'extra.platform') || get(row,'extra.placed_on'); orders.push(shaped);
      }
      return { orders, errors: {}, window: windowOf(s), cacheSize: orders.length };
    },
    collectShipping: async tokens => {
      const { s, items } = selectedItems(tokens), orders = items.filter(it => sourceRow(it,s).status === 'shipping').map(it => shippingRow(it,s));
      const promisedCount = orders.filter(x => x.promised).length; return { orders, errors: {}, promisedCount, missingPromised: orders.length - promisedCount };
    },
    collectOutcomes: async tokens => {
      const { s, items } = selectedItems(tokens), rows = items.map(it => shippingRow(it,s)), countsBySeller = {};
      for (const sid of new Set(rows.map(x => x.sid))) countsBySeller[sid] = countStatuses(rows.filter(x => x.sid === sid));
      return { countsBySeller, canceled: rows.filter(x => ['canceled','cancelled'].includes(x.status)), delivered: rows.filter(x => x.status === 'delivered'), errors: {}, window: windowOf(s), days: s.settings.days || 30 };
    },
    pullCounts: async sid => countStatuses(snap().items.filter(x => String(x.sid) === String(sid)).map(x => x.row)),
    pullStatus: async (sid, token, status) => ({ orders: snap().items.filter(x => String(x.sid) === String(sid) && (!status || x.row.status === status)).map(x => x.row), truncated: false })
  });
  let rendered = '';
  async function open(view, force) {
    const s = snap(), key = view + '|' + s.revision + '|' + s.selected;
    for (const [sid, a] of Object.entries(s.accounts)) if (a.name) root.TNSL_CONFIG.accountNames[sid] = a.name;
    document.documentElement.setAttribute('data-theme', parent.document.documentElement.getAttribute('data-theme') || 'dark');
    root.TNSLShell.goto(view);
    await new Promise(r=>setTimeout(r,0));
    if (rendered === key && !force) return;
    normalizedCache.key = ''; if (root.TNSLInsight) root.TNSLInsight.invalidate();
    const all = ['refresh', 'prodRefresh', 'cycRefresh', 'shipRefresh', 'outRefresh'];
    // Rendering an analytic screen never invokes remote order synchronization.
    if (['backlog','flow','prod','cycle','outcome','trend'].includes(view)) {
      await root.refresh();
      const fn = { flow:'flowRefresh', prod:'prodRefresh', cycle:'cycRefresh', outcome:'outRefresh', trend:'trendRefresh' }[view];
      if (view === 'trend') root.UnifiedDailyTrend();
      else if (fn && typeof root[fn] === 'function') await root[fn]();
    } else if (root.TNSLInsight && ['fields','endpoints'].includes(view)) await root.TNSLInsight.onView(view);
    rendered = key;
  }
  root.UnifiedAnalysis = { normalized, open, sync: () => hub().syncOrders(), snapshot: snap };
})(window);
// Local daily summary replaces the optional remote backend dashboard.
window.UnifiedDailyTrend = function () {
  const s = parent.UnifiedHub.snapshot(), days = new Map();
  for (const it of s.items) {
    const r = it.row, parsed = parent.TNKPI.date(r.created_at), date = parsed ? new Date(+parsed+7*3600e3).toISOString().slice(0,10) : 'Thiếu ngày';
    const b = days.get(date) || {total:0,delivered:0,canceled:0,open:0}; b.total++;
    if(r.status==='delivered')b.delivered++;else if(['canceled','cancelled'].includes(r.status))b.canceled++;else b.open++;
    days.set(date,b);
  }
  const esc=x=>String(x).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  document.getElementById('viewTrend').innerHTML='<div class="panel"><h2>Xu hướng theo ngày tạo</h2><p>Trạng thái hiện tại của tập đơn đã lưu; không phải số giao thành công phát sinh trong từng ngày.</p><table><thead><tr><th>Ngày tạo</th><th>Tổng đơn</th><th>Hiện hoàn tất</th><th>Hiện hủy</th><th>Còn mở</th></tr></thead><tbody>'+[...days].sort((a,b)=>b[0].localeCompare(a[0])).map(([day,b])=>'<tr><td>'+esc(day)+'</td><td>'+b.total+'</td><td>'+b.delivered+'</td><td>'+b.canceled+'</td><td>'+b.open+'</td></tr>').join('')+'</tbody></table></div>';
};
