/* =============================================================================
 * TikiNOW Ops Command Center — DATA FUSION v2.7
 *
 * Thứ TikiNOW Center KHÔNG BAO GIỜ làm được: nối chéo các mục với nhau.
 * Trên web, Đơn hàng / Thanh toán / Khiếu nại / Tồn kho là bốn trang rời,
 * mỗi trang một account. Ở đây chúng nằm chung một kho, nên trả lời được
 * những câu hỏi ra tiền:
 *
 *   "Đơn nào ĐÃ GIAO mà CHƯA có trong Thanh toán?"      -> tiền đang treo
 *   "Khiếu nại nào đã mở mà chưa thấy bồi thường?"       -> quyền lợi bị bỏ
 *   "Đơn nào trễ mà CHƯA hề mở khiếu nại?"               -> bỏ sót quyền lợi
 *   "SKU nào có trong Sản phẩm mà không có Tồn kho?"     -> hàng chết
 *
 * Điểm cốt lõi: KHÔNG bắt người dùng biết tên field. Hệ thống tự dò cặp cột
 * nào của hai tập dữ liệu thực sự TRÙNG GIÁ TRỊ với nhau, rồi xếp hạng.
 * Tên cột có đổi, API có thay schema, nó vẫn tìm ra khóa nối.
 * ========================================================================== */
(function (root) {
  "use strict";

  const $ = id => document.getElementById(id);
  const esc = s => String(s == null ? "" : s)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  const nfmt = n => Number(n || 0).toLocaleString("vi-VN");

  const STATE = { sets: null, rows: {}, result: null, busy: false };

  /* Cột không bao giờ dùng làm khóa nối — chúng trùng nhau ở mọi tập. */
  const KEY_BLOCKLIST = /^(account|sellerid|seller_id|trang|page|status|sub_status|created_at|updated_at|type|kind|state|note|message|currency|unit)$/i;
  /* Cột có tên gợi ý là định danh — được cộng điểm. */
  const KEY_HINT = /(order[_-]?code|order[_-]?id|ma[_-]?don|tracking|awb|waybill|sku|barcode|product[_-]?code|item[_-]?code|claim|ticket|invoice|shipment|ref[_-]?code|^id$|_id$|code$)/i;

  /* --------------------------------------------------------- NGUỒN DỮ LIỆU */
  async function listDatasets() {
    const H = root.TikiDataHub;
    const out = [];
    try {
      const n = await H.orderCount();
      out.push({ id: "__orders__", label: "Đơn hàng (vault)", rows: n, source: "vault" });
    } catch (_) {}
    try {
      const d = await H.listSections();
      d.sections.forEach(sec => sec.items.forEach(it => {
        if (it.rows > 0) out.push({
          id: it.key, label: sec.label + " · " + (it.title || it.pathKey),
          rows: it.rows, source: "section"
        });
      }));
    } catch (_) {}
    return out;
  }

  async function rowsOf(id) {
    if (STATE.rows[id]) return STATE.rows[id];
    const H = root.TikiDataHub;
    const rows = id === "__orders__" ? await H.orderRows() : await H.sectionRows(id);
    STATE.rows[id] = rows;
    return rows;
  }

  /* ------------------------------------------------- DÒ KHÓA NỐI TỰ ĐỘNG */
  const norm = v => {
    if (v == null) return "";
    const s = String(v).trim();
    if (!s || s === "null" || s === "undefined" || s === "0") return "";
    return s.toUpperCase();
  };

  function columnProfile(rows, cap) {
    cap = cap || 800;
    const sample = rows.slice(0, cap);
    const cols = new Map();
    sample.forEach(r => Object.keys(r).forEach(k => {
      const v = norm(r[k]);
      if (!v) return;
      if (!cols.has(k)) cols.set(k, { values: new Set(), filled: 0 });
      const c = cols.get(k);
      c.filled++;
      if (c.values.size < 4000) c.values.add(v);
    }));
    const out = [];
    cols.forEach((c, k) => {
      if (KEY_BLOCKLIST.test(k)) return;
      const uniq = c.values.size / Math.max(1, c.filled);
      /* Khóa nối phải gần như duy nhất. Cột trạng thái, số lượng... bị loại ở đây. */
      if (uniq < 0.45) return;
      out.push({ col: k, values: c.values, uniq, filled: c.filled });
    });
    return out;
  }

  /* Xếp hạng cặp cột theo mức TRÙNG GIÁ TRỊ thật, không theo tên. */
  function rankKeyPairs(aRows, bRows) {
    const A = columnProfile(aRows), B = columnProfile(bRows);
    const pairs = [];
    A.forEach(a => B.forEach(b => {
      let hit = 0;
      const small = a.values.size <= b.values.size ? a : b;
      const big = small === a ? b : a;
      small.values.forEach(v => { if (big.values.has(v)) hit++; });
      if (!hit) return;
      const overlap = hit / Math.max(1, small.values.size);
      const bonus = (KEY_HINT.test(a.col) ? 0.12 : 0) + (KEY_HINT.test(b.col) ? 0.12 : 0)
                  + (a.col.toLowerCase() === b.col.toLowerCase() ? 0.1 : 0);
      pairs.push({ a: a.col, b: b.col, overlap, hit, score: overlap + bonus });
    }));
    pairs.sort((x, y) => y.score - x.score);
    return pairs.slice(0, 12);
  }

  /* --------------------------------------------------------------- JOIN */
  function runJoin(aRows, bRows, aCol, bCol, op) {
    const bIndex = new Map();
    bRows.forEach(r => {
      const v = norm(r[bCol]);
      if (!v) return;
      if (!bIndex.has(v)) bIndex.set(v, []);
      bIndex.get(v).push(r);
    });
    const out = [];
    const seenA = new Set();
    aRows.forEach(r => {
      const v = norm(r[aCol]);
      if (!v) return;
      seenA.add(v);
      const match = bIndex.get(v);
      if (op === "only_a" && !match) out.push({ ...r, __khop: "chỉ có ở A" });
      else if (op === "both" && match) out.push({ ...r, __khop: "có ở cả hai", __so_dong_B: match.length });
    });
    if (op === "only_b") {
      bRows.forEach(r => {
        const v = norm(r[bCol]);
        if (v && !seenA.has(v)) out.push({ ...r, __khop: "chỉ có ở B" });
      });
    }
    return out;
  }

  /* ------------------------------------------------------------ PRESET */
  /* Mỗi preset tự tìm tập dữ liệu phù hợp theo tên mục, nên không vỡ khi
     endpoint đổi path. Thiếu tập nào thì nói rõ cần nạp mục nào. */
  const PRESETS = [
    { id: "tien-treo", icon: "₫", title: "Tiền đang treo",
      q: "Đơn ĐÃ GIAO mà chưa thấy trong Thanh toán",
      why: "Mỗi dòng ở đây là tiền đã làm xong việc nhưng chưa về. Đây là con số để đi đòi.",
      a: /^__orders__$/, aName: "Đơn hàng (vault)",
      b: /thanh toán|payment|invoice|settle/i, bName: "Thanh toán",
      op: "only_a", filterA: r => /deliver|giao/i.test(String(r.Status || "")) },
    { id: "boi-thuong-thieu", icon: "⚖", title: "Bồi thường chưa về",
      q: "Khiếu nại đã mở mà chưa thấy trong Thanh toán / bồi thường",
      why: "Khiếu nại được duyệt nhưng tiền chưa vào đối soát — rất dễ rơi nếu không ai rà.",
      a: /khiếu nại|claim|complain|compensat/i, aName: "Khiếu nại & Bồi thường",
      b: /thanh toán|payment|invoice|settle/i, bName: "Thanh toán",
      op: "only_a" },
    { id: "bo-sot-khieu-nai", icon: "⚠", title: "Bỏ sót quyền khiếu nại",
      q: "Đơn trễ / hoàn / huỷ mà CHƯA hề mở khiếu nại",
      why: "Đơn đủ điều kiện đền bù nhưng không ai mở ticket. Tiền bỏ trên bàn.",
      a: /^__orders__$/, aName: "Đơn hàng (vault)",
      b: /khiếu nại|claim|complain/i, bName: "Khiếu nại & Bồi thường",
      op: "only_a", filterA: r => /cancel|return|huy|hoan|fail/i.test(String(r.Status || "") + String(r.SubStatus || "")) },
    { id: "hang-chet", icon: "▣", title: "SKU không có tồn kho",
      q: "SKU có trong Sản phẩm mà không thấy ở Tồn kho",
      why: "Hàng đang bán nhưng kho không có — nguồn gốc của huỷ đơn và phạt.",
      a: /sản phẩm|product|sku|catalog/i, aName: "Sản phẩm",
      b: /tồn kho|inventor|stock/i, bName: "Tồn kho",
      op: "only_a" },
    { id: "doi-soat-kho", icon: "⇄", title: "Lệch Đơn hàng ↔ Tồn kho",
      q: "Đơn chưa xong mà SKU không còn trong Tồn kho",
      why: "Báo trước những đơn sắp huỷ vì hết hàng, trước khi khách hủy.",
      a: /^__orders__$/, aName: "Đơn hàng (vault)",
      b: /tồn kho|inventor|stock/i, bName: "Tồn kho",
      op: "only_a" }
  ];

  function matchSet(re, sets) {
    return sets.find(s => re.test(s.id) || re.test(s.label));
  }

  async function runPreset(id) {
    const ps = PRESETS.find(p => p.id === id);
    if (!ps) return;
    const sets = STATE.sets || [];
    const A = matchSet(ps.a, sets), B = matchSet(ps.b, sets);
    if (!A || !B) {
      const missing = [!A && ps.aName, !B && ps.bName].filter(Boolean).join(" và ");
      setStatus("Chưa đủ dữ liệu: cần nạp " + missing + " ở mục “Mục TikiNOW Center” trước.");
      if (root.TNSLShell) root.TNSLShell.toast("Thiếu dữ liệu",
        "Câu hỏi này cần " + missing + ". Vào Dữ liệu → Mục TikiNOW Center và bấm Nạp mục đó.", "warn");
      return;
    }
    await compute(A.id, B.id, null, null, ps.op, ps);
  }

  async function compute(aId, bId, aCol, bCol, op, preset) {
    if (STATE.busy) return;
    STATE.busy = true;
    setStatus("Đang nối dữ liệu…");
    try {
      let aRows = await rowsOf(aId);
      const bRows = await rowsOf(bId);
      if (preset && preset.filterA) aRows = aRows.filter(preset.filterA);
      if (!aRows.length || !bRows.length) {
        setStatus("Một trong hai tập chưa có dòng nào.");
        STATE.result = null; renderResult(); return;
      }
      let pairs = [];
      if (!aCol || !bCol) {
        pairs = rankKeyPairs(aRows, bRows);
        if (!pairs.length) {
          setStatus("Không tìm thấy cột nào trùng giá trị giữa hai tập — hai mục này có thể không liên quan nhau.");
          STATE.result = null; renderResult(); return;
        }
        aCol = pairs[0].a; bCol = pairs[0].b;
      }
      const rows = runJoin(aRows, bRows, aCol, bCol, op);
      STATE.result = {
        aId, bId, aCol, bCol, op, rows, pairs,
        aCount: aRows.length, bCount: bRows.length,
        title: preset ? preset.title : "Kết quả nối",
        q: preset ? preset.q : "",
        why: preset ? preset.why : ""
      };
      renderResult();
      setStatus(nfmt(rows.length) + " dòng · nối bằng " + aCol + " ↔ " + bCol);
    } catch (e) {
      setStatus("Lỗi: " + e.message);
    } finally { STATE.busy = false; }
  }

  /* -------------------------------------------------------------- RENDER */
  function setStatus(t) { const e = $("fuStatus"); if (e) e.textContent = t || ""; }

  function renderPresets() {
    const box = $("fuPresets");
    if (!box) return;
    const sets = STATE.sets || [];
    box.innerHTML = PRESETS.map(p => {
      const A = matchSet(p.a, sets), B = matchSet(p.b, sets);
      const ready = !!(A && B);
      const missing = [!A && p.aName, !B && p.bName].filter(Boolean).join(" · ");
      return '<div class="fu-card' + (ready ? "" : " off") + '" data-preset="' + p.id + '">' +
        '<div class="fu-ic">' + p.icon + "</div>" +
        '<div class="fu-body"><b>' + esc(p.title) + "</b>" +
        '<span class="fu-q">' + esc(p.q) + "</span>" +
        '<small class="fu-why">' + esc(p.why) + "</small>" +
        (ready ? '<span class="fu-ready">Sẵn sàng — bấm để chạy</span>'
               : '<span class="fu-miss">Cần nạp: ' + esc(missing) + "</span>") +
        "</div></div>";
    }).join("");
  }

  function renderSelectors() {
    const sets = STATE.sets || [];
    const opts = sets.map(s => '<option value="' + esc(s.id) + '">' + esc(s.label) +
      " (" + nfmt(s.rows) + ")</option>").join("");
    ["fuA", "fuB"].forEach((id, i) => {
      const el = $(id);
      if (!el) return;
      const keep = el.value;
      el.innerHTML = opts;
      if (keep) el.value = keep;
      else if (sets[i]) el.value = sets[i].id;
    });
  }

  function renderResult() {
    const wrap = $("fuResult");
    const r = STATE.result;
    if (!wrap) return;
    if (!r) { wrap.hidden = true; return; }
    wrap.hidden = false;
    $("fuResTitle").textContent = r.title + (r.q ? " — " + r.q : "");
    $("fuResMeta").innerHTML =
      '<span class="fu-kpi"><b>' + nfmt(r.rows.length) + "</b> dòng kết quả</span>" +
      '<span class="fu-kpi">A: ' + nfmt(r.aCount) + " dòng</span>" +
      '<span class="fu-kpi">B: ' + nfmt(r.bCount) + " dòng</span>" +
      '<span class="fu-kpi">khóa nối: <code>' + esc(r.aCol) + "</code> ↔ <code>" + esc(r.bCol) + "</code></span>" +
      (r.why ? '<div class="fu-why-box">' + esc(r.why) + "</div>" : "");

    const alt = $("fuAltKeys");
    if (alt) {
      alt.innerHTML = r.pairs.length > 1
        ? "Khóa nối khác hệ thống tìm thấy: " + r.pairs.slice(1, 5).map(p =>
            '<button class="fu-alt" data-a="' + esc(p.a) + '" data-b="' + esc(p.b) + '">' +
            esc(p.a) + " ↔ " + esc(p.b) + " (" + Math.round(p.overlap * 100) + "% trùng)</button>").join(" ")
        : "";
    }

    const rows = r.rows;
    const head = $("fuHead"), body = $("fuBody");
    if (!rows.length) {
      head.innerHTML = "<tr><th>—</th></tr>";
      body.innerHTML = '<tr><td><div class="empty">Không có dòng nào khớp điều kiện. Đây là tin tốt.</div></td></tr>';
      return;
    }
    const freq = new Map();
    rows.slice(0, 400).forEach(x => Object.keys(x).forEach(k => {
      if (x[k] !== "" && x[k] != null) freq.set(k, (freq.get(k) || 0) + 1);
    }));
    const lead = ["Account", "__khop", r.aCol].filter(k => freq.has(k));
    const rest = Array.from(freq.entries()).filter(([k]) => lead.indexOf(k) < 0)
      .sort((a, b) => b[1] - a[1]).slice(0, 12).map(([k]) => k);
    const cols = lead.concat(rest);
    head.innerHTML = "<tr>" + cols.map(c =>
      "<th>" + esc(c === "__khop" ? "Khớp" : c) + "</th>").join("") + "</tr>";
    body.innerHTML = rows.slice(0, 500).map(x =>
      "<tr>" + cols.map(c => "<td>" + esc(String(x[c] == null ? "" : x[c]).slice(0, 110)) + "</td>").join("") + "</tr>"
    ).join("");
  }

  function toCsv(rows) {
    if (!rows.length) return "";
    const cols = Array.from(rows.reduce((s, r) => { Object.keys(r).forEach(k => s.add(k)); return s; }, new Set()));
    const cell = v => {
      const s = v == null ? "" : String(v);
      return /[",\n;]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
    };
    return [cols.join(",")].concat(rows.map(r => cols.map(c => cell(r[c])).join(","))).join("\n");
  }

  /* ------------------------------------------------------------- REFRESH */
  async function refresh() {
    setStatus("Đang đọc nguồn dữ liệu…");
    try {
      STATE.sets = await listDatasets();
      STATE.rows = {};
      renderPresets(); renderSelectors();
      const n = STATE.sets.length;
      setStatus(n
        ? n + " tập dữ liệu sẵn sàng để nối"
        : "Chưa có tập dữ liệu nào. Nạp Đơn hàng hoặc một mục ở “Mục TikiNOW Center” trước.");
    } catch (e) { setStatus("Lỗi: " + e.message); }
  }

  function bind() {
    const pb = $("fuPresets");
    if (pb) pb.addEventListener("click", e => {
      const c = e.target.closest("[data-preset]");
      if (c && !c.classList.contains("off")) runPreset(c.dataset.preset);
    });
    const run = $("fuRun");
    if (run) run.onclick = () => compute($("fuA").value, $("fuB").value, null, null, $("fuOp").value, null);
    const rs = $("fuRescan"); if (rs) rs.onclick = refresh;
    const alt = $("fuAltKeys");
    if (alt) alt.addEventListener("click", e => {
      const b = e.target.closest(".fu-alt");
      if (!b || !STATE.result) return;
      const r = STATE.result;
      compute(r.aId, r.bId, b.dataset.a, b.dataset.b, r.op, null);
    });
    const ex = $("fuExport");
    if (ex) ex.onclick = () => {
      if (!STATE.result || !STATE.result.rows.length) return;
      const blob = new Blob(["﻿" + toCsv(STATE.result.rows)], { type: "text/csv;charset=utf-8" });
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = "TNSL_NoiCheo_" + (STATE.result.title || "ketqua").replace(/[^A-Za-z0-9]+/g, "_") + ".csv";
      document.body.appendChild(a); a.click();
      setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500);
    };
  }

  root.TNSLFusion = {
    onView: () => { if (!STATE.sets) refresh(); else { renderPresets(); renderSelectors(); renderResult(); } },
    refresh, runPreset, compute, rankKeyPairs, runJoin, listDatasets, PRESETS
  };

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", bind);
  else bind();
})(self);
