/* =============================================================================
 * TikiNOW Ops Command Center — SITE MAP v2.8
 *
 * Sơ đồ đầy đủ tikinowcenter.tikinow.vn. Trả lời hai câu:
 *   1. Extension đã học được những mục nào, còn thiếu mục nào
 *   2. Bấm một nút để nó TỰ ĐI HỌC HẾT các mục còn thiếu
 *
 * Phân biệt rõ trang CÓ DỮ LIỆU (danh sách, báo cáo — đáng học) với trang
 * THAO TÁC (form tạo đơn, import — mở cũng không có gì để lấy). Không bắt
 * người dùng mở 23 trang khi chỉ 14 trang có dữ liệu.
 * ========================================================================== */
(function (root) {
  "use strict";

  const $ = id => document.getElementById(id);
  const esc = s => String(s == null ? "" : s)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

  const BASE = "https://tikinowcenter.tikinow.vn/new#";

  /* kind: "data" = có danh sách/báo cáo để kéo · "form" = trang thao tác, bỏ qua */
  const MAP = [
    { group: "Tổng quan", items: [
      { r: "/dashboard",  n: "Chỉ số vận hành (SLA scorecard)", kind: "data",
        note: "Bảng KPI D/W/M — Tiki chỉ cho xem hiện tại, extension giữ được lịch sử" }
    ]},
    { group: "Đơn hàng", items: [
      { r: "/tnsl-order/list", n: "Danh sách đơn hàng", kind: "data" },
      { r: "/tnsl-order/fulfillment/create", n: "ĐH đóng gói · Tạo đơn mới", kind: "form" },
      { r: "/tnsl-order/fulfillment/import", n: "ĐH đóng gói · Tạo hàng loạt", kind: "form" },
      { r: "/tnsl-order/fulfillment/import-advanced", n: "ĐH đóng gói · Hàng loạt nâng cao", kind: "form" },
      { r: "/tnsl-order/last-mile/create", n: "ĐH chỉ vận chuyển · Tạo đơn mới", kind: "form" },
      { r: "/tnsl-order/last-mile/import", n: "ĐH chỉ vận chuyển · Tạo hàng loạt", kind: "form" },
      { r: "/tnsl-order/last-mile/import-advanced", n: "ĐH chỉ vận chuyển · Hàng loạt nâng cao", kind: "form" },
      { r: "/tnsl-order/last-mile/print-label", n: "ĐH chỉ vận chuyển · In tem hàng loạt", kind: "form" },
      { r: "/tnsl-order/fulfillment-b2b/create", n: "ĐH đóng gói B2B · Tạo đơn mới", kind: "form" },
      { r: "/tnsl-order/last-mile-b2b/create", n: "ĐH chỉ vận chuyển B2B · Tạo đơn mới", kind: "form" }
    ]},
    { group: "Sản phẩm", items: [
      { r: "/products/list-new", n: "Danh sách sản phẩm", kind: "data" },
      { r: "/products/manage-export-product", n: "Quản lý xuất sản phẩm", kind: "data" },
      { r: "/products/create-new", n: "Tạo mới / cập nhật sản phẩm", kind: "form" },
      { r: "/products/configs-special", n: "Cấu hình đặc biệt", kind: "data" }
    ]},
    { group: "Tồn kho", items: [
      { r: "/warehouse-management/seller-inventory", n: "Thông tin kho đối tác", kind: "data" },
      { r: "/warehouse-management/inbound", n: "Phiếu gửi hàng", kind: "data" },
      { r: "/warehouse-management/outbound", n: "Phiếu rút hàng", kind: "data" },
      { r: "/warehouse-management/stock-transfer/list", n: "Phiếu luân chuyển · Danh sách", kind: "data" },
      { r: "/warehouse-management/stock-transfer/import", n: "Phiếu luân chuyển · Đăng nhiều phiếu", kind: "form" }
    ]},
    { group: "Báo cáo & Phân tích", items: [
      { r: "/reporting-analysis/inventory-report/new", n: "Báo cáo tồn kho", kind: "data" },
      { r: "/reporting-analysis/inventory-report/sale-days", n: "Số ngày tồn kho", kind: "data" },
      { r: "/reporting-analysis/inventory-report/aging-stock", n: "Tuổi tồn", kind: "data",
        note: "Hàng nằm lâu = tiền chết. Nối với Đơn hàng để biết SKU nào nên đẩy" },
      { r: "/reporting-analysis/inventory-report/expiration", n: "Hạn sử dụng", kind: "data",
        note: "Cảnh báo cận date trước khi phải huỷ" },
      { r: "/reporting-analysis/customer-return-report/list", n: "Báo cáo Huỷ / Trả hàng", kind: "data" }
    ]},
    { group: "Khiếu nại & Bồi thường", items: [
      { r: "/claim", n: "Danh sách yêu cầu", kind: "data", loose: true,
        note: "Route chưa có trong sơ đồ — mở mục này trên web một lần là tự học" },
      { r: "/claim/import", n: "Tạo hàng loạt", kind: "form", loose: true }
    ]},
    { group: "Hậu mãi", items: [
      { r: "/aftersales/failed-delivery", n: "Danh sách ĐH giao thất bại", kind: "data",
        note: "Nguồn chính của khiếu nại — nối với Khiếu nại để tìm đơn bỏ sót" },
      { r: "/aftersales", n: "Yêu cầu thu hồi", kind: "data", loose: true }
    ]},
    { group: "Quản lý nhóm người dùng", items: [
      { r: "/user", n: "Quản lý nhóm người dùng", kind: "data", loose: true }
    ]}
  ];

  const STATE = { catalog: [], learning: false, stop: false, progress: "" };

  function msg(type, extra) {
    return new Promise(res => {
      try { chrome.runtime.sendMessage(Object.assign({ type }, extra || {}), r => { void chrome.runtime.lastError; res(r); }); }
      catch (_) { res(null); }
    });
  }

  const normRoute = r => String(r || "").replace(/^#/, "").split("?")[0].replace(/\/+$/, "").toLowerCase();

  function learnedRoutes() {
    const set = new Set();
    STATE.catalog.forEach(c => { if (c && c.route) set.add(normRoute(c.route)); });
    return set;
  }

  function isLearned(item, learned) {
    const want = normRoute(item.r);
    if (learned.has(want)) return true;
    for (const got of learned) {
      if (got.startsWith(want) || (item.loose && got.indexOf(want.split("/")[1] || "@@") >= 0)) return true;
    }
    return false;
  }

  function dataItems() {
    const out = [];
    MAP.forEach(g => g.items.forEach(it => { if (it.kind === "data") out.push(it); }));
    return out;
  }

  /* --------------------------------------------------------------- RENDER */
  function render() {
    const box = $("smList");
    if (!box) return;
    const learned = learnedRoutes();
    const data = dataItems();
    const done = data.filter(it => isLearned(it, learned));
    const pct = data.length ? Math.round(done.length / data.length * 100) : 0;

    const head = $("smCover");
    if (head) head.innerHTML =
      '<div class="sm-bar"><i style="width:' + pct + '%"></i></div>' +
      '<div class="sm-cover-txt"><b>' + done.length + "/" + data.length + "</b> mục có dữ liệu đã học · " +
      pct + "%" + (done.length < data.length
        ? ' — còn <b>' + (data.length - done.length) + "</b> mục chưa học"
        : " — đã phủ hết") + "</div>";

    box.innerHTML = MAP.map(g => {
      const rows = g.items.map(it => {
        const ok = isLearned(it, learned);
        const form = it.kind === "form";
        return '<tr class="' + (form ? "sm-form" : (ok ? "sm-ok" : "sm-miss")) + '">' +
          '<td><span class="sm-dot"></span>' + esc(it.n) +
            (it.note ? '<br><small class="sm-note">' + esc(it.note) + "</small>" : "") + "</td>" +
          '<td><code class="sm-route">' + esc(it.r) + "</code></td>" +
          "<td>" + (form
            ? '<span class="sm-tag form">trang thao tác</span>'
            : ok ? '<span class="sm-tag ok">đã học</span>'
                 : '<span class="sm-tag miss">chưa học</span>') + "</td>" +
          '<td><button class="ghost sm-open" data-route="' + esc(it.r) + '">↗ Mở</button></td>' +
        "</tr>";
      }).join("");
      return '<div class="sec-group"><h4>' + esc(g.group) + "</h4>" +
        '<div class="dh-table-wrap"><table class="dh-table"><tbody>' + rows + "</tbody></table></div></div>";
    }).join("");
  }

  function setProgress(t) {
    STATE.progress = t || "";
    const e = $("smProgress");
    if (e) { e.textContent = t || ""; e.hidden = !t; }
    const b = $("smLearnAll");
    if (b) b.textContent = STATE.learning ? "■ Dừng học" : "✦ Học hết trang còn thiếu";
  }

  /* --------------------------------------------- TỰ ĐI HỌC HẾT CÁC TRANG */
  /* Mở MỘT tab, lần lượt đổi route trong chính tab đó. SPA không reload nên
     nhanh; observer trong content script bắt request của từng trang. */
  async function learnAll() {
    if (STATE.learning) { STATE.stop = true; return; }
    const learned = learnedRoutes();
    const todo = dataItems().filter(it => !isLearned(it, learned) && !it.loose);
    const loose = dataItems().filter(it => it.loose && !isLearned(it, learned));
    if (!todo.length) {
      if (root.TNSLShell) root.TNSLShell.toast("Đã phủ hết",
        loose.length ? "Còn " + loose.length + " mục chưa có route chuẩn — mở thủ công một lần." : "Mọi mục có dữ liệu đều đã học.", "ok");
      return;
    }
    STATE.learning = true; STATE.stop = false;
    setProgress("Chuẩn bị mở " + todo.length + " trang…");

    let tabId = null;
    try {
      const tab = await new Promise(res => chrome.tabs.create({ url: BASE + todo[0].r, active: false }, res));
      tabId = tab && tab.id;
      if (!tabId) throw new Error("Không mở được tab");
      await new Promise(r => setTimeout(r, 6000));   // chờ SPA khởi động + đăng nhập

      for (let i = 0; i < todo.length; i++) {
        if (STATE.stop) break;
        const it = todo[i];
        setProgress("Đang học " + (i + 1) + "/" + todo.length + ": " + it.n);
        await new Promise(res => chrome.tabs.update(tabId, { url: BASE + it.r }, () => { void chrome.runtime.lastError; res(); }));
        await new Promise(r => setTimeout(r, 4500));  // chờ trang gọi API xong
        STATE.catalog = (await msg("GET_API_CATALOG")) || [];
        render();
      }
    } catch (e) {
      if (root.TNSLShell) root.TNSLShell.toast("Không tự học được", e.message, "err");
    } finally {
      if (tabId) { try { chrome.tabs.remove(tabId); } catch (_) {} }
      STATE.learning = false;
      setProgress("");
      await refresh();
      const after = learnedRoutes();
      const still = dataItems().filter(it => !isLearned(it, after));
      if (root.TNSLShell) root.TNSLShell.toast(
        STATE.stop ? "Đã dừng" : "Học xong",
        still.length ? "Còn " + still.length + " mục chưa học — có thể cần quyền hoặc mục đó không dùng API danh sách."
                     : "Đã phủ hết mục có dữ liệu. Sang “Mục TikiNOW Center” để nạp.",
        still.length ? "warn" : "ok");
    }
  }

  async function refresh() {
    STATE.catalog = (await msg("GET_API_CATALOG")) || [];
    render();
  }

  function bind() {
    const box = $("smList");
    if (box) box.addEventListener("click", e => {
      const b = e.target.closest(".sm-open");
      if (!b) return;
      const url = BASE + b.dataset.route;
      try { chrome.tabs.create({ url, active: true }); } catch (_) { window.open(url, "_blank", "noreferrer"); }
    });
    const l = $("smLearnAll"); if (l) l.onclick = learnAll;
    const r = $("smRescan"); if (r) r.onclick = refresh;
  }

  root.TNSLSiteMap = {
    onView: () => { refresh(); },
    refresh, learnAll, MAP, dataItems,
    _isLearned: isLearned, _learnedRoutes: learnedRoutes, _setCatalog: c => { STATE.catalog = c; }
  };

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", bind);
  else bind();
})(self);
