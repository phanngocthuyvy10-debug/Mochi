/* =============================================================
 * TikiNOW API Observer v2 — ISOLATED world
 * Nhận catalog metadata từ MAIN world, xác thực rồi chuyển background.
 * Đồng thời duy trì tnslExports để tab Xuất dữ liệu v1 vẫn hoạt động.
 * ============================================================= */
(function () {
  "use strict";
  const API_HOST = "api.tikinow.vn";

  function friendly(path) {
    return String(path || "").replace(/^\/+/, "") || "API";
  }

  function validRecord(d) {
    if (!d || d.__tiki_ops_api_v2 !== true || !d.url) return null;
    let u;
    try { u = new URL(d.url); } catch (_) { return null; }
    if (u.hostname !== API_HOST) return null;
    const method = String(d.method || "GET").toUpperCase();
    if (!/^(GET|POST|PUT|PATCH|DELETE|HEAD)$/.test(method)) return null;
    return {
      url: u.toString(),
      method,
      pathKey: String(d.pathKey || u.pathname).slice(0, 400),
      sellerId: d.sellerId == null ? null : String(d.sellerId).slice(0, 80),
      kind: String(d.kind || "unknown").slice(0, 30),
      status: Number(d.status || 0),
      requestBody: typeof d.requestBody === "string" ? d.requestBody.slice(0, 65536) : "",
      requestContentType: String(d.requestContentType || "").slice(0, 120),
      responseKeys: Array.isArray(d.responseKeys) ? d.responseKeys.slice(0, 200).map(String) : [],
      schemaPaths: Array.isArray(d.schemaPaths) ? d.schemaPaths.slice(0, 500).map(String) : [],
      total: d.total == null ? null : Number(d.total),
      perPage: d.perPage == null ? null : Number(d.perPage),
      totalPage: d.totalPage == null ? null : Number(d.totalPage),
      pageParam: d.pageParam ? String(d.pageParam).slice(0, 80) : null,
      sizeParam: d.sizeParam ? String(d.sizeParam).slice(0, 80) : null,
      pageBodyPath: d.pageBodyPath ? String(d.pageBodyPath).slice(0, 80) : null,
      sizeBodyPath: d.sizeBodyPath ? String(d.sizeBodyPath).slice(0, 80) : null,
      at: Number(d.at || Date.now()),
      title: String(d.title || "").slice(0, 200)
    };
  }

  async function updateLegacyExport(rec) {
    if (rec.method !== "GET" || !["list", "report"].includes(rec.kind)) return;
    try {
      const { tnslExports } = await chrome.storage.local.get("tnslExports");
      const state = tnslExports || { list: [] };
      const legacy = {
        pathKey: rec.pathKey,
        name: friendly(rec.pathKey),
        kind: rec.kind,
        url: rec.url,
        auth: null,
        sellerId: rec.sellerId,
        total: rec.total,
        perPage: rec.perPage,
        totalPage: rec.totalPage,
        at: rec.at,
        title: rec.title || ""
      };
      state.last = legacy;
      const others = (state.list || []).filter(x => x.pathKey !== legacy.pathKey);
      state.list = [legacy, ...others].slice(0, 50);
      await chrome.storage.local.set({ tnslExports: state });
    } catch (_) {}
  }

  window.addEventListener("message", ev => {
    if (ev.source !== window) return;
    const rec = validRecord(ev.data);
    if (!rec) return;
    try { chrome.runtime.sendMessage({ type: "SAVE_API_CAPTURE", record: rec }); } catch (_) {}
    updateLegacyExport(rec);
  }, false);
})();
