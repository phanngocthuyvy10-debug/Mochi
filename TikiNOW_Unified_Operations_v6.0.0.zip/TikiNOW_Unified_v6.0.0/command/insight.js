/* =============================================================================
 * TikiNOW Ops Command Center — INSIGHT v3
 * "Get all what Tiki have" — ba màn hình chứng minh mức khai thác dữ liệu:
 *   1. Field Explorer     — mọi JSON path Tiki trả về, fill-rate, đã khai thác hay chưa
 *   2. Endpoint Coverage  — endpoint đã học vs đã thực sự replay/lưu dữ liệu
 *   3. Video Evidence Hub — toàn bộ link video đóng gói/khui hàng theo đơn
 * Read-only trên IndexedDB của Data Hub. Không gọi API, không ghi dữ liệu.
 * ========================================================================== */
(function (root) {
  "use strict";

  const DB_NAME = "tikinow_ops_data_hub_v2";
  const $ = id => document.getElementById(id);
  const MAX_SCAN = 1500;          // số đơn tối đa đưa vào quét field (đủ đại diện, không treo UI)
  const MAX_DEPTH = 8;
  const MAX_PATHS = 4000;

  const CACHE = { orders: null, at: 0, fields: null, endpoints: null, videos: null };

  /* ------------------------------------------------------------ utilities */
  const esc = s => String(s == null ? "" : s)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  const nfmt = n => Number(n || 0).toLocaleString("vi-VN");
  const pct = (a, b) => b ? Math.round(a / b * 1000) / 10 : 0;

  function openDb() {
    return new Promise((resolve, reject) => {
      const r = indexedDB.open(DB_NAME);
      r.onsuccess = () => resolve(r.result);
      r.onerror = () => reject(r.error || new Error("Không mở được IndexedDB"));
    });
  }
  async function getAll(store) {
    if (store === "orders" && root.UnifiedAnalysis) return root.UnifiedAnalysis.normalized(MAX_SCAN);
    const db = await openDb();
    if (!db.objectStoreNames.contains(store)) return [];
    return new Promise((resolve, reject) => {
      const q = db.transaction(store, "readonly").objectStore(store).getAll();
      q.onsuccess = () => resolve(q.result || []);
      q.onerror = () => reject(q.error);
    });
  }
  function runtimeMessage(msg) {
    return new Promise(resolve => {
      try {
        chrome.runtime.sendMessage(msg, r => { void chrome.runtime.lastError; resolve(r); });
      } catch (_) { resolve(null); }
    });
  }

  async function orders() {
    if (CACHE.orders && Date.now() - CACHE.at < 60000) return CACHE.orders;
    CACHE.orders = await getAll("orders");
    CACHE.at = Date.now();
    return CACHE.orders;
  }

  function download(name, text, mime) {
    const blob = new Blob(["﻿" + text], { type: mime || "text/csv;charset=utf-8" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob); a.download = name;
    document.body.appendChild(a); a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500);
  }
  function toCsv(rows) {
    if (!rows.length) return "";
    const cols = Object.keys(rows[0]);
    const cell = v => {
      const s = v == null ? "" : String(v);
      return /[",\n;]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
    };
    return [cols.join(",")].concat(rows.map(r => cols.map(c => cell(r[c])).join(","))).join("\n");
  }

  /* ====================================================================== */
  /*                            FIELD EXPLORER                              */
  /* ====================================================================== */

  /* Leaf key mà pipeline chuẩn hóa chắc chắn đang tiêu thụ (ngoài value-match). */
  const KNOWN_LEAVES = new Set([
    "order_code", "code", "order_id", "id", "ref_code", "partner_order_code", "marketplace_order_code",
    "status", "sub_status", "fulfillment_type", "created_at", "updated_at", "order_created_at",
    "tracking_code", "tracking_no", "awb", "partner_tracking_id", "shipment_id",
    "warehouse", "name", "provider", "source", "vendor", "storage",
    "histories", "history", "timeline", "events", "logs", "items",
    "promised_delivery_date", "promised_delivery_at", "estimated_delivery_date", "estimated_delivery_at",
    "url", "link", "video_url", "media_url", "file_url", "path"
  ]);

  function typeOf(v) {
    if (v === null || v === undefined) return "null";
    if (Array.isArray(v)) return "array";
    const t = typeof v;
    if (t !== "string") return t;
    if (/^\d{4}-\d{2}-\d{2}([ T]\d{2}:\d{2})/.test(v)) return "datetime";
    if (/^https?:\/\//i.test(v)) return "url";
    return "string";
  }
  const isEmpty = v => v === null || v === undefined || v === "" ||
    (Array.isArray(v) && !v.length) ||
    (typeof v === "object" && !Array.isArray(v) && !Object.keys(v).length);

  /** Làm phẳng object thành path -> value. Mảng gộp bằng [] để không nổ path. */
  function walk(obj, prefix, out, depth) {
    if (depth > MAX_DEPTH || out.size > MAX_PATHS) return;
    if (obj === null || typeof obj !== "object") { out.set(prefix || "$", obj); return; }
    if (Array.isArray(obj)) {
      out.set((prefix || "$") + "[]#len", obj.length);
      for (let i = 0; i < Math.min(obj.length, 3); i++) walk(obj[i], (prefix || "$") + "[]", out, depth + 1);
      return;
    }
    const keys = Object.keys(obj);
    if (!keys.length && prefix) out.set(prefix, {});
    for (const k of keys) {
      const p = prefix ? prefix + "." + k : k;
      walk(obj[k], p, out, depth + 1);
    }
  }

  /** Tập giá trị đã được pipeline chuẩn hóa đưa lên record — dùng để chấm "đã khai thác". */
  function consumedValues(order) {
    const set = new Set();
    const skip = new Set(["raw_detail", "raw_list", "raw_media", "videos", "events", "items"]);
    for (const k of Object.keys(order)) {
      if (skip.has(k)) continue;
      const v = order[k];
      if (v == null || v === "") continue;
      if (typeof v === "object") continue;
      set.add(String(v));
    }
    (order.events || []).slice(0, 60).forEach(e => {
      ["status_code", "event_at_api", "label", "actor", "reason"].forEach(k => {
        if (e && e[k] != null && e[k] !== "") set.add(String(e[k]));
      });
    });
    (order.videos || []).forEach(v => { if (v && v.url) set.add(String(v.url)); });
    return set;
  }

  function scanFields(all, source) {
    const sample = all.slice(0, MAX_SCAN);
    const stat = new Map();   // path -> {present, filled, types:Set, samples:Set, used, sample}
    let scanned = 0;

    for (const o of sample) {
      let raw = null;
      if (source === "list") raw = o.raw_list;
      else if (source === "both") raw = Object.assign({}, o.raw_list || {}, o.raw_detail || {});
      else raw = o.raw_detail || null;
      if (!raw || typeof raw !== "object") continue;
      scanned++;

      const flat = new Map();
      walk(raw, "", flat, 0);
      const used = consumedValues(o);

      for (const [p, v] of flat) {
        let s = stat.get(p);
        if (!s) { s = { present: 0, filled: 0, types: new Set(), samples: new Set(), used: 0, sample: "" }; stat.set(p, s); }
        s.present++;
        if (!isEmpty(v)) {
          s.filled++;
          s.types.add(typeOf(v));
          if (s.samples.size < 60 && typeof v !== "object") s.samples.add(String(v).slice(0, 120));
          if (!s.sample) s.sample = typeof v === "object" ? JSON.stringify(v).slice(0, 120) : String(v).slice(0, 120);
          if (typeof v !== "object" && used.has(String(v))) s.used++;
        }
      }
    }

    const rows = [];
    for (const [p, s] of stat) {
      const leaf = p.split(".").pop().replace(/\[\]|#len$/g, "");
      const usedByLeaf = KNOWN_LEAVES.has(leaf);
      // "đã khai thác" khi >=40% lần xuất hiện có giá trị lọt vào record chuẩn hóa,
      // hoặc leaf nằm trong danh sách field pipeline chắc chắn đọc.
      const usedRatio = s.filled ? s.used / s.filled : 0;
      rows.push({
        path: p,
        type: Array.from(s.types).join("|") || "—",
        present: s.present,
        filled: s.filled,
        fill: pct(s.filled, scanned || 1),
        distinct: s.samples.size >= 60 ? "60+" : s.samples.size,
        used: usedRatio >= 0.4 || usedByLeaf,
        usedRatio: Math.round(usedRatio * 100),
        sample: s.sample
      });
    }
    rows.sort((a, b) => b.fill - a.fill || a.path.localeCompare(b.path));
    return { rows, scanned, total: all.length };
  }

  async function buildFields(force) {
    const src = ($("fxSource") || {}).value || "detail";
    if (CACHE.fields && CACHE.fields.src === src && !force) return CACHE.fields;
    const all = await orders();
    const r = scanFields(all, src);
    CACHE.fields = Object.assign({ src }, r);
    return CACHE.fields;
  }

  function renderFields(data) {
    const q = (($("fxSearch") || {}).value || "").toLowerCase().trim();
    const usage = ($("fxUsage") || {}).value || "";
    const minFill = Number(($("fxMinFill") || {}).value || 0);
    const hideEmpty = ($("fxHideEmpty") || {}).checked;

    let rows = data.rows;
    if (hideEmpty) rows = rows.filter(r => r.filled > 0);
    if (q) rows = rows.filter(r => r.path.toLowerCase().indexOf(q) >= 0);
    if (usage === "used") rows = rows.filter(r => r.used);
    if (usage === "unused") rows = rows.filter(r => !r.used);
    if (minFill > 0) rows = rows.filter(r => r.fill >= minFill);

    const totalFilled = data.rows.filter(r => r.filled > 0);
    const usedN = totalFilled.filter(r => r.used).length;
    const stats = $("fxStats");
    if (stats) stats.innerHTML = `
      <div class="fx-stat"><div class="v">${nfmt(data.rows.length)}</div><div class="t">JSON path Tiki trả về</div></div>
      <div class="fx-stat"><div class="v">${nfmt(totalFilled.length)}</div><div class="t">Path có dữ liệu thật</div></div>
      <div class="fx-stat on"><div class="v">${nfmt(usedN)}</div><div class="t">Đã khai thác</div></div>
      <div class="fx-stat off"><div class="v">${nfmt(totalFilled.length - usedN)}</div><div class="t">Chưa khai thác</div></div>
      <div class="fx-stat acc"><div class="v">${pct(usedN, totalFilled.length)}%</div><div class="t">Mức khai thác field</div></div>
      <div class="fx-stat"><div class="v">${nfmt(data.scanned)}</div><div class="t">Đơn đã quét / ${nfmt(data.total)}</div></div>`;

    const st = $("fxStatus");
    if (st) st.textContent = `${nfmt(rows.length)} path hiển thị · quét ${nfmt(data.scanned)} đơn · nguồn ${data.src}`;

    const body = $("fxRows");
    if (!body) return;
    if (!rows.length) {
      body.innerHTML = '<tr><td colspan="6"><div class="empty">Không có path nào khớp bộ lọc. Nếu vault còn rỗng, hãy chạy ⟳ Đồng bộ trước.</div></td></tr>';
      return;
    }
    body.innerHTML = rows.slice(0, 1200).map(r => {
      const cls = r.fill >= 80 ? "hi" : r.fill < 20 ? "lo" : "";
      return `<tr>
        <td><span class="fx-path" title="${esc(r.path)}">${esc(r.path)}</span></td>
        <td><span class="fx-type">${esc(r.type)}</span></td>
        <td><span class="fx-meter"><span class="mt"><span class="mf ${cls}" style="width:${r.fill}%"></span></span>
            <span class="mv">${r.fill}%</span></span></td>
        <td>${esc(r.distinct)}</td>
        <td><span class="fx-used ${r.used ? "yes" : "no"}">${r.used ? "đã dùng" : "bỏ ngỏ"}</span></td>
        <td><span class="fx-sample" title="${esc(r.sample)}">${esc(r.sample)}</span></td>
      </tr>`;
    }).join("");
  }

  async function refreshFields(force) {
    const st = $("fxStatus"); if (st) st.textContent = "Đang quét raw vault…";
    try { renderFields(await buildFields(force)); }
    catch (e) { if (st) st.textContent = "Lỗi quét: " + e.message; }
  }

  /* ====================================================================== */
  /*                          ENDPOINT COVERAGE                             */
  /* ====================================================================== */

  const MUTATION_RE = /(create|update|delete|remove|submit|confirm|approve|reject|cancel|dispatch|handover|import|upload|assign|action|mutate|print|split|merge)/i;

  async function buildEndpoints(force) {
    if (CACHE.endpoints && !force) return CACHE.endpoints;
    const [catalog, resources, all] = await Promise.all([
      runtimeMessage({ type: "GET_API_CATALOG" }), getAll("resources"), orders()
    ]);
    const cat = catalog || [];
    const byPath = new Map();
    resources.forEach(r => {
      const k = r.path_key || r.resource_key || "";
      byPath.set(k, (byPath.get(k) || 0) + Number(r.row_count || 0));
    });

    const detailOk = all.filter(o => o.has_detail).length;
    const mediaOk = all.filter(o => o.media_synced_at).length;

    const rows = cat.map(c => {
      const path = c.pathKey || c.key || "";
      const method = String(c.method || "GET").toUpperCase();
      const kind = c.kind || "unknown";
      const storedRows = byPath.get(path) || 0;
      let state, note;
      if (["PUT", "PATCH", "DELETE"].indexOf(method) >= 0 || MUTATION_RE.test(path)) {
        state = "locked"; note = "Endpoint mutation/action — hệ thống luôn khóa, không replay.";
      } else if (kind === "detail") {
        state = detailOk ? "used" : "gap";
        note = detailOk ? `Đang dùng cho detail routing (${nfmt(detailOk)} đơn có raw detail).`
                        : "Đã học nhưng chưa đơn nào lấy được detail — chạy Smart Sync.";
      } else if (kind === "media") {
        state = mediaOk ? "used" : "gap";
        note = mediaOk ? `Đang dùng cho media/video (${nfmt(mediaOk)} đơn có media response).`
                       : "Đã học route video nhưng chưa kéo được payload — mở thử 1 video rồi Smart Sync.";
      } else if (storedRows > 0) {
        state = "used"; note = `Đã replay và lưu ${nfmt(storedRows)} dòng raw.`;
      } else {
        state = "gap"; note = "Đã học schema nhưng CHƯA replay lần nào — bấm Kéo để lấy dữ liệu.";
      }
      return {
        method, path, kind, state, note,
        hits: c.hits || 0,
        total: c.total || 0,
        storedRows,
        schemaVersion: c.schemaVersion || 1,
        drift: ((c.newFields || []).length + (c.removedFields || []).length),
        lastSeen: c.lastSeenAt ? new Date(c.lastSeenAt) : null,
        index: cat.indexOf(c)
      };
    });

    rows.sort((a, b) => {
      const w = { gap: 0, used: 1, locked: 2 };
      return w[a.state] - w[b.state] || b.hits - a.hits;
    });
    CACHE.endpoints = { rows, detailOk, mediaOk, orderCount: all.length };
    return CACHE.endpoints;
  }

  function renderEndpoints(data) {
    const q = (($("epSearch") || {}).value || "").toLowerCase().trim();
    const filter = ($("epState") || {}).value || "";
    let rows = data.rows;
    if (q) rows = rows.filter(r => (r.path + " " + r.kind).toLowerCase().indexOf(q) >= 0);
    if (filter) rows = rows.filter(r => r.state === filter);

    const used = data.rows.filter(r => r.state === "used").length;
    const gap = data.rows.filter(r => r.state === "gap").length;
    const locked = data.rows.filter(r => r.state === "locked").length;
    const tot = data.rows.length || 1;

    const stats = $("epStats");
    if (stats) stats.innerHTML = `
      <div class="fx-stat"><div class="v">${nfmt(data.rows.length)}</div><div class="t">Endpoint đã học</div></div>
      <div class="fx-stat on"><div class="v">${nfmt(used)}</div><div class="t">Đã khai thác</div></div>
      <div class="fx-stat off"><div class="v">${nfmt(gap)}</div><div class="t">Học rồi nhưng bỏ ngỏ</div></div>
      <div class="fx-stat"><div class="v">${nfmt(locked)}</div><div class="t">Bị khóa (mutation)</div></div>
      <div class="fx-stat acc"><div class="v">${pct(used, tot - locked || 1)}%</div><div class="t">Mức khai thác endpoint</div></div>`;

    const bar = $("epBar");
    if (bar) bar.innerHTML =
      `<i class="used" style="width:${used / tot * 100}%"></i>` +
      `<i class="learned" style="width:${gap / tot * 100}%"></i>` +
      `<i class="idle" style="width:${locked / tot * 100}%"></i>`;

    const st = $("epStatus");
    if (st) st.textContent = `${nfmt(rows.length)} endpoint hiển thị · vault đang giữ ${nfmt(data.orderCount)} đơn`;

    const body = $("epRows");
    if (!body) return;
    if (!rows.length) {
      body.innerHTML = '<tr><td colspan="10"><div class="empty">Chưa học được endpoint nào. Mở lần lượt các màn hình trên TikiNOW Center để Observer ghi nhận.</div></td></tr>';
      return;
    }
    const badge = s => s === "used" ? '<span class="fx-used yes">đã khai thác</span>'
      : s === "gap" ? '<span class="fx-used no">bỏ ngỏ</span>'
      : '<span class="tag t-purple">khóa</span>';
    body.innerHTML = rows.map(r => `
      <tr${r.state === "gap" ? ' class="ep-row-gap"' : ""}>
        <td><b>${esc(r.method)}</b></td>
        <td><span class="fx-path" title="${esc(r.note)}">${esc(r.path)}</span></td>
        <td><span class="dh-kind">${esc(r.kind)}</span></td>
        <td>${nfmt(r.hits)}</td>
        <td>${nfmt(r.storedRows || r.total)}</td>
        <td>v${r.schemaVersion}</td>
        <td>${r.drift ? '<span class="dh-drift">' + r.drift + " field</span>" : "—"}</td>
        <td>${r.lastSeen ? esc(r.lastSeen.toLocaleString("vi-VN")) : "—"}</td>
        <td>${badge(r.state)}</td>
        <td>${r.state === "gap" && r.kind !== "detail" && r.kind !== "media"
          ? `<button class="ghost dh-api-sync" data-ep="${r.index}">Kéo</button>` : ""}</td>
      </tr>`).join("");
  }

  async function refreshEndpoints(force) {
    const st = $("epStatus"); if (st) st.textContent = "Đang đối chiếu catalog…";
    try { renderEndpoints(await buildEndpoints(force)); }
    catch (e) { if (st) st.textContent = "Lỗi: " + e.message; }
  }

  /* ====================================================================== */
  /*                         VIDEO EVIDENCE HUB                             */
  /* ====================================================================== */

  const CAT_LABEL = { packing: "Đóng gói", unboxing: "Khui hàng", other: "Khác" };

  async function buildVideos(force) {
    if (CACHE.videos && !force) return CACHE.videos;
    const all = await orders();
    const rows = [];
    all.forEach(o => {
      (o.videos || []).forEach(v => rows.push({
        pk: o.pk, order_code: o.order_code, ref_code: o.ref_code,
        account: o.account_name || o.seller_id, status: o.status,
        warehouse: o.warehouse, carrier: o.carrier,
        media_status: o.media_sync_status || "",
        category: v.category || "other",
        source: v.source || "", provider: v.provider || "",
        created_at: v.created_at_api || v.captured_at || "",
        url: v.url || "", label: v.label || "", source_path: v.source_path || ""
      }));
    });
    rows.sort((a, b) => String(b.created_at).localeCompare(String(a.created_at)));
    const withVideo = all.filter(o => (o.video_count || 0) > 0).length;
    CACHE.videos = {
      rows, orderCount: all.length, withVideo,
      packing: rows.filter(r => r.category === "packing").length,
      unboxing: rows.filter(r => r.category === "unboxing").length,
      notObserved: all.filter(o => o.media_sync_status === "not_observed").length
    };
    return CACHE.videos;
  }

  function renderVideos(data) {
    const q = (($("evSearch") || {}).value || "").toLowerCase().trim();
    const cat = ($("evCat") || {}).value || "";
    const ms = ($("evMedia") || {}).value || "";
    let rows = data.rows;
    if (q) rows = rows.filter(r => (r.order_code + " " + r.ref_code + " " + r.warehouse + " " +
      r.carrier + " " + r.provider).toLowerCase().indexOf(q) >= 0);
    if (cat) rows = rows.filter(r => r.category === cat);
    if (ms) rows = rows.filter(r => r.media_status === ms);

    const stats = $("evStats");
    if (stats) stats.innerHTML = `
      <div class="fx-stat"><div class="v">${nfmt(data.rows.length)}</div><div class="t">Tổng link video</div></div>
      <div class="fx-stat acc"><div class="v">${nfmt(data.packing)}</div><div class="t">Video đóng gói</div></div>
      <div class="fx-stat acc"><div class="v">${nfmt(data.unboxing)}</div><div class="t">Video khui hàng</div></div>
      <div class="fx-stat on"><div class="v">${nfmt(data.withVideo)}</div><div class="t">Đơn có video / ${nfmt(data.orderCount)}</div></div>
      <div class="fx-stat off"><div class="v">${nfmt(data.notObserved)}</div><div class="t">Đơn chưa học route media</div></div>`;

    const st = $("evStatus");
    if (st) st.textContent = data.rows.length
      ? `${nfmt(rows.length)} link hiển thị · signed URL có thể hết hạn, đồng bộ lại trước khi đối soát.`
      : "Chưa quan sát được link video nào. Mở thử một video đóng gói và một video khui hàng trên TikiNOW rồi chạy ⟳ Đồng bộ.";

    const body = $("evRows");
    if (!body) return;
    if (!rows.length) {
      body.innerHTML = '<tr><td colspan="8"><div class="empty">Không có link video khớp bộ lọc.</div></td></tr>';
      return;
    }
    body.innerHTML = rows.slice(0, 1500).map(r => `
      <tr>
        <td><span class="dh-link" data-order-pk="${esc(r.pk)}">${esc(r.order_code || "—")}</span>
            ${r.ref_code ? '<br><small class="dh-kind">' + esc(r.ref_code) + "</small>" : ""}</td>
        <td>${esc(r.account)}</td>
        <td><span class="dh-status">${esc(r.status || "—")}</span></td>
        <td><span class="dh-video-chip ${esc(r.category)}">${esc(CAT_LABEL[r.category] || r.category)}</span></td>
        <td><span class="dh-kind">${esc(r.source)}</span></td>
        <td>${esc(r.provider || "—")}</td>
        <td>${esc(r.created_at || "—")}</td>
        <td>
          <a href="${esc(r.url)}" target="_blank" rel="noreferrer" class="dh-link">Mở</a>
          <button class="ghost dh-copy-video" data-url="${esc(r.url)}">⧉ Copy</button>
        </td>
      </tr>`).join("");
  }

  async function refreshVideos(force) {
    const st = $("evStatus"); if (st) st.textContent = "Đang gom link video…";
    try { renderVideos(await buildVideos(force)); }
    catch (e) { if (st) st.textContent = "Lỗi: " + e.message; }
  }

  /* ====================================================================== */
  /*                        EXCEL SHEET MỞ RỘNG                             */
  /* ====================================================================== */
  /* datahub.js gọi hook này khi dựng workbook Excel Full. */
  root.TNSL_EXTRA_SHEETS = async function () {
    const out = [];
    try {
      const f = await buildFields(true);
      out.push({
        name: "15_Field_Coverage",
        rows: f.rows.map(r => ({
          JSONPath: r.path, Type: r.type, FillRatePct: r.fill,
          OrdersScanned: f.scanned, Present: r.present, Filled: r.filled,
          DistinctSamples: r.distinct, Exploited: r.used ? "yes" : "no",
          ExploitedRatioPct: r.usedRatio, SampleValue: r.sample
        }))
      });
    } catch (_) {}
    try {
      const e = await buildEndpoints(true);
      out.push({
        name: "16_Endpoint_Coverage",
        rows: e.rows.map(r => ({
          Method: r.method, Endpoint: r.path, Kind: r.kind, State: r.state,
          Hits: r.hits, StoredRows: r.storedRows, ApiTotal: r.total,
          SchemaVersion: r.schemaVersion, DriftFields: r.drift,
          LastSeen: r.lastSeen ? r.lastSeen.toISOString() : "", Note: r.note
        }))
      });
    } catch (_) {}
    return out;
  };

  /* ====================================================================== */
  /*                              BINDINGS                                  */
  /* ====================================================================== */
  function bind() {
    ["fxSearch", "fxUsage", "fxMinFill", "fxHideEmpty"].forEach(id => {
      const el = $(id); if (!el) return;
      el.addEventListener(el.tagName === "INPUT" && el.type !== "checkbox" ? "input" : "change",
        () => { if (CACHE.fields) renderFields(CACHE.fields); });
    });
    const fs = $("fxSource"); if (fs) fs.onchange = () => refreshFields(true);
    const fr = $("fxRescan"); if (fr) fr.onclick = () => { CACHE.orders = null; refreshFields(true); };
    const fe = $("fxExport"); if (fe) fe.onclick = async () => {
      const d = await buildFields(false);
      download("TNSL_Field_Coverage_" + new Date().toISOString().slice(0, 10) + ".csv",
        toCsv(d.rows.map(r => ({
          json_path: r.path, type: r.type, fill_rate_pct: r.fill, present: r.present,
          filled: r.filled, distinct: r.distinct, exploited: r.used ? "yes" : "no",
          exploited_ratio_pct: r.usedRatio, sample: r.sample
        }))));
    };

    ["epSearch", "epState"].forEach(id => {
      const el = $(id); if (!el) return;
      el.addEventListener(id === "epSearch" ? "input" : "change",
        () => { if (CACHE.endpoints) renderEndpoints(CACHE.endpoints); });
    });
    const er = $("epRescan"); if (er) er.onclick = () => refreshEndpoints(true);
    const ee = $("epExport"); if (ee) ee.onclick = async () => {
      const d = await buildEndpoints(false);
      download("TNSL_Endpoint_Coverage_" + new Date().toISOString().slice(0, 10) + ".csv",
        toCsv(d.rows.map(r => ({
          method: r.method, endpoint: r.path, kind: r.kind, state: r.state, hits: r.hits,
          stored_rows: r.storedRows, schema_version: r.schemaVersion, drift_fields: r.drift,
          last_seen: r.lastSeen ? r.lastSeen.toISOString() : "", note: r.note
        }))));
    };
    const epb = $("epRows");
    if (epb) epb.addEventListener("click", e => {
      const b = e.target.closest("[data-ep]"); if (!b) return;
      const proxy = document.querySelector('#dhApiRows [data-api-index="' + b.dataset.ep + '"]');
      if (proxy) { proxy.click(); if (root.TNSLShell) root.TNSLShell.toast("Đang kéo endpoint", "Theo dõi tiến trình ở Dữ liệu → Vault & Trust.", "ok"); }
      else if (root.TNSLShell) root.TNSLShell.toast("Chưa kéo được", "Mở Dữ liệu → Vault & Trust và bấm Kéo ở dòng tương ứng.", "warn");
    });

    ["evSearch", "evCat", "evMedia"].forEach(id => {
      const el = $(id); if (!el) return;
      el.addEventListener(id === "evSearch" ? "input" : "change",
        () => { if (CACHE.videos) renderVideos(CACHE.videos); });
    });
    const ec = $("evCopyAll"); if (ec) ec.onclick = async () => {
      const d = await buildVideos(false);
      const txt = d.rows.map(r => r.order_code + "\t" + (CAT_LABEL[r.category] || r.category) + "\t" + r.url).join("\n");
      try { await navigator.clipboard.writeText(txt); if (root.TNSLShell) root.TNSLShell.toast("Đã copy", nfmt(d.rows.length) + " link vào clipboard.", "ok"); }
      catch (_) { if (root.TNSLShell) root.TNSLShell.toast("Không copy được", "Trình duyệt chặn clipboard.", "err"); }
    };
    const ex = $("evExport"); if (ex) ex.onclick = async () => {
      const d = await buildVideos(false);
      download("TNSL_Order_Videos_" + new Date().toISOString().slice(0, 10) + ".csv", toCsv(d.rows));
    };
    const evb = $("evRows");
    if (evb) evb.addEventListener("click", async e => {
      const c = e.target.closest(".dh-copy-video");
      if (c) {
        try { await navigator.clipboard.writeText(c.dataset.url); c.textContent = "✓ Đã copy"; setTimeout(() => { c.textContent = "⧉ Copy"; }, 1600); } catch (_) {}
        return;
      }
      const o = e.target.closest("[data-order-pk]");
      if (o) {
        const proxy = document.querySelector('#dhOrderRows [data-order-pk="' + o.dataset.orderPk + '"]');
        if (proxy) proxy.click();
        else if (root.TNSLShell) root.TNSLShell.toast("Chưa mở được hồ sơ đơn", "Vào Bằng chứng → Order 360° và tìm mã đơn này.", "warn");
      }
    });
  }

  /* gọi bởi shell khi chuyển sang view mới */
  function onView(view) {
    if (view === "fields") refreshFields(false);
    else if (view === "endpoints") refreshEndpoints(false);
    else if (view === "evidence") refreshVideos(false);
  }
  function invalidate() {
    CACHE.orders = null; CACHE.fields = null; CACHE.endpoints = null; CACHE.videos = null;
    const v = root.TNSLShell && root.TNSLShell.STATE.view;
    if (v) onView(v);
  }

  root.TNSLInsight = { onView, invalidate, buildFields, buildEndpoints, buildVideos };

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", bind);
  else bind();
})(self);
