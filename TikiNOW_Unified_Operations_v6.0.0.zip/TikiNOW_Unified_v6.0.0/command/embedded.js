(function (root) {
  'use strict';
  if (parent === root || !parent.UnifiedHub) { location.replace('../app.html'); return; }
  root.getTokens = async () => Object.fromEntries([...new Set(parent.UnifiedHub.snapshot().items.map(x=>String(x.sid)))].map(sid=>[sid,{token:''}]));
  root.addEventListener('unified-analysis-ready', () => {
    root.TNSLShell.STATE.auto.enabled = false;
    root.TNSLShell.STATE.auto.autoOpen = false;
  });
})(window);
