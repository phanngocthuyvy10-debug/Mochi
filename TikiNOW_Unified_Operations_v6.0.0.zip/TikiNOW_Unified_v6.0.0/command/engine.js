/* =============================================================
 * TikiNOW Backlog Tracker — ENGINE (thuần, không phụ thuộc DOM)
 * Chuẩn hoá đơn + tính aging + gắn cờ backlog + tổng hợp.
 * Dùng chung cho dashboard (browser) và test (node).
 * ============================================================= */
(function (root) {
  const HOUR = 3600 * 1000;

  // TikiNOW trả created_at dạng "2026-07-25 23:21:07" (giờ VN, +07).
  function parseVN(ts) {
    if (!ts) return null;
    if (ts instanceof Date) return ts;
    const m = String(ts).match(/(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2}):(\d{2})/);
    if (!m) { const d = new Date(ts); return isNaN(d) ? null : d; }
    // Ép về UTC bằng cách trừ offset +07:00 -> mốc thời gian tuyệt đối chuẩn.
    return new Date(Date.UTC(+m[1], +m[2]-1, +m[3], +m[4]-7, +m[5], +m[6]));
  }

  function hoursBetween(a, b) {
    if (!a || !b) return null;
    return (b.getTime() - a.getTime()) / HOUR;
  }

  // Có NHÃN VẬN CHUYỂN chưa? (đã tạo shipping label / có mã vận đơn ngoài)
  // LƯU Ý: field o.labels KHÔNG phải nhãn VC — đó là tag nghiệp vụ
  // (vd 'tnsl_partner_order') và luôn rỗng ở API list. Nhãn VC thật nằm ở
  // extra.shipping_label_url + extra.external_shipping_code.
  function nonEmpty(v) { return v != null && String(v).trim() !== ''; }
  function hasLabel(o) {
    const e = o.extra || {};
    if (nonEmpty(e.shipping_label_url)) return true;   // URL nhãn đã tạo
    if (nonEmpty(e.external_shipping_code)) return true; // mã vận đơn ĐVVC (AWB)
    const t = (o.delivery && o.delivery.tracking) || null; // fallback nếu có
    if (t && (nonEmpty(t.tracking_code) || nonEmpty(t.code) || nonEmpty(t.awb))) return true;
    return false;
  }

  function platformOf(o) {
    const e = o.extra || {};
    return e.platform || e.sale_channel || e.channel || o.sale_channel || 'N/A';
  }
  // Đơn có KHÂU ĐÓNG GÓI hay không. "last_miles" = ĐH chỉ vận chuyển (giao chặng cuối),
  // KHÔNG qua kho đóng gói -> phải loại khỏi mọi thống kê ĐÓNG GÓI (SLA/sắp trễ/năng suất đóng).
  function hasPackingStage(o) { return String(o.fulfillment_type || '') !== 'last_miles'; }
  function warehouseOf(o) {
    const w = o.warehouse;
    if (!w) return 'N/A';
    if (typeof w === 'string') return w;
    return w.code || w.name || w.id || 'N/A';
  }
  function carrierOf(o) {
    const e = o.extra || {};
    const d = o.delivery || {};
    // ĐVVC thật nằm ở extra.delivery_partner (vd 'SPX Express'); delivery.* thường trống
    return e.delivery_partner || e.partner || d.carrier || d.partner || d.provider || d.shipping_partner || 'N/A';
  }

  // Chuẩn hoá 1 đơn + tính toán aging/cờ.
  function normalize(o, cfg, now, sellerId) {
    now = now || new Date();
    const created = parseVN(o.created_at);
    const updated = parseVN(o.updated_at) || created;
    const ageH = hoursBetween(created, now);       // tuổi đơn
    const stageAgeH = hoursBetween(updated, now);  // ~thời gian ở khâu hiện tại
    const sub = o.sub_status || '';
    const subInfo = (cfg.subStatusMap && cfg.subStatusMap[sub]) || null;
    const stage = subInfo ? subInfo.stage
      : (o.status === 'awaiting_confirmation' ? 'confirm'
       : o.status === 'shipping' ? 'shipping'
       : o.status === 'processing' ? 'process' : (o.status || 'other'));
    const isIssue = !!(o.is_item_issue || o.is_holding) || stage === 'issue';

    // ---- Cờ backlog ----
    const flags = [];
    // 1) Chưa có nhãn vận chuyển (đơn đang xử lý mà chưa tạo label)
    if (o.status === 'processing' && !hasLabel(o)) flags.push('no_label');
    // 2) Chờ xác nhận quá SLA
    if (stage === 'confirm' && ageH != null && ageH > cfg.sla.confirm_h) flags.push('confirm_overdue');
    // 3) Khâu xử lý (pick/pack) quá SLA
    if (stage === 'process' && ageH != null && ageH > cfg.sla.processing_h) flags.push('processing_overdue');
    // 4) Chưa bàn giao ĐVVC quá SLA (đã đóng gói xong nhưng chưa lên đường)
    if (stage === 'handover' && stageAgeH != null && stageAgeH > cfg.sla.handover_h) flags.push('handover_overdue');
    // 5) Kẹt vận chuyển quá lâu
    if (stage === 'shipping' && stageAgeH != null && stageAgeH > cfg.sla.shipping_h) flags.push('shipping_stuck');
    // 6) Lỗi hàng / hoàn / holding
    if (isIssue) flags.push('issue_return');

    // Map Brand/Channel từ ref_code (logic notebook billing) — guarded
    const _pm = (root.TNSL_PREFIX && root.TNSL_PREFIX.mapByRefCode) ? root.TNSL_PREFIX.mapByRefCode(o.ref_code, sellerId) : null;

    // Aging bucket
    let bucket = null;
    for (const b of cfg.agingBuckets) {
      if (ageH != null && ageH >= b.min && ageH < b.max) { bucket = b.key; break; }
    }

    return {
      seller_id: String(sellerId != null ? sellerId : (o.seller_id || '')),
      account: (cfg.accountNames && cfg.accountNames[String(sellerId)]) || String(sellerId || o.seller_id || ''),
      order_code: o.order_code,
      ref_code: o.ref_code,
      brand: _pm ? _pm.brand : null,
      group_brand: _pm ? _pm.gb : null,
      channel_map: _pm ? _pm.channel : null,
      platform_map: _pm ? _pm.platform : null,
      opollo_channel: _pm ? _pm.opollo : null,
      platform_channel: _pm ? _pm.pcn : null,
      preflix: _pm ? _pm.preflix : null,
      status: o.status,
      sub_status: sub,
      sub_label: subInfo ? subInfo.label : (sub || o.status),
      stage,
      created_at: o.created_at,
      updated_at: o.updated_at,
      age_h: ageH == null ? null : Math.round(ageH * 10) / 10,
      stage_age_h: stageAgeH == null ? null : Math.round(stageAgeH * 10) / 10,
      bucket,
      has_label: hasLabel(o),
      platform: platformOf(o),
      warehouse: warehouseOf(o),
      carrier: carrierOf(o),
      grand_total: o.grand_total,
      qty: Array.isArray(o.items) ? o.items.reduce((s, it) => s + (it.quantity || 0), 0) : null,
      is_issue: isIssue,
      flags,
      is_backlog: flags.length > 0,
      severity: flags.length // xếp hạng ưu tiên đơn giản
    };
  }

  function normalizeAll(rawBySeller, cfg, now) {
    now = now || new Date();
    const out = [];
    for (const sellerId of Object.keys(rawBySeller || {})) {
      for (const o of rawBySeller[sellerId] || []) out.push(normalize(o, cfg, now, sellerId));
    }
    return out;
  }

  // Tổng hợp cho dashboard.
  function summarize(rows, cfg) {
    const flagKeys = ['no_label','confirm_overdue','processing_overdue','handover_overdue','shipping_stuck','issue_return'];
    const s = {
      total: rows.length,
      backlog: rows.filter(r => r.is_backlog).length,
      byFlag: {}, byBucket: {}, byAccount: {}, byWarehouse: {}, byPlatform: {},
      oldest: null
    };
    flagKeys.forEach(k => s.byFlag[k] = 0);
    cfg.agingBuckets.forEach(b => s.byBucket[b.key] = 0);
    let maxAge = -1;
    for (const r of rows) {
      r.flags.forEach(f => { s.byFlag[f] = (s.byFlag[f] || 0) + 1; });
      if (r.bucket) s.byBucket[r.bucket]++;
      const acc = r.account || r.seller_id;
      s.byAccount[acc] = s.byAccount[acc] || { total: 0, backlog: 0 };
      s.byAccount[acc].total++; if (r.is_backlog) s.byAccount[acc].backlog++;
      s.byWarehouse[r.warehouse] = (s.byWarehouse[r.warehouse] || 0) + (r.is_backlog ? 1 : 0);
      s.byPlatform[r.platform] = (s.byPlatform[r.platform] || 0) + (r.is_backlog ? 1 : 0);
      if (r.age_h != null && r.age_h > maxAge) { maxAge = r.age_h; s.oldest = r; }
    }
    return s;
  }

  const FLAG_LABELS = {
    no_label: 'Chưa có nhãn vận chuyển',
    confirm_overdue: 'Chờ xác nhận quá SLA',
    processing_overdue: 'Xử lý quá SLA',
    handover_overdue: 'Chưa bàn giao ĐVVC',
    shipping_stuck: 'Kẹt vận chuyển',
    issue_return: 'Lỗi hàng / hoàn'
  };

  // ================= NĂNG SUẤT KHO =================
  function ymd(d){const p=n=>String(n).padStart(2,'0');return `${d.getFullYear()}-${p(d.getMonth()+1)}-${p(d.getDate())}`;}
  function isDispatched(o){
    const s=o.status, sub=String(o.sub_status||'');
    if(s==='shipping'||s==='delivered') return true;
    return /handover|picked|dispatch|carrier|transit|out_for_delivery/.test(sub);
  }
  function median(arr){ if(!arr.length) return 0; const a=[...arr].sort((x,y)=>x-y); const m=Math.floor(a.length/2); return a.length%2?a[m]:(a[m-1]+a[m])/2; }

  // orders: mảng đơn thô (nhiều status). Trả grid giờ×ngày + tổng hợp + low-perf.
  function buildProductivity(orders, cfg, now){
    now = now || new Date();
    const P = cfg.productivity || {};
    const [aFrom, aTo] = P.activeHours || [6,22];
    const wd = P.windowDays || 7;
    const days = [];
    for(let i=wd-1;i>=0;i--){ days.push(ymd(new Date(now.getTime()-i*86400000))); }
    const dayset = new Set(days);
    const blank = ()=>({inflow:0, activity:0, dispatched:0});
    const grid = {}; days.forEach(d=>{ grid[d]={}; for(let h=0;h<24;h++) grid[d][h]=blank(); });
    const byWh = {};
    let totIn=0, totAct=0, totDisp=0;
    for(const o of (orders||[])){
      const wh = (function(){ const w=o.warehouse; if(!w) return 'N/A'; if(typeof w==='string') return w; return w.code||w.name||w.id||'N/A'; })();
      byWh[wh] = byWh[wh] || {inflow:0, activity:0, dispatched:0};
      const c = parseVN(o.created_at), u = parseVN(o.updated_at) || c;
      if(c){ const dc=ymd(c); if(dayset.has(dc)){ grid[dc][c.getHours()].inflow++; totIn++; byWh[wh].inflow++; } }
      if(u){ const du=ymd(u); if(dayset.has(du)){ const h=u.getHours(); grid[du][h].activity++; totAct++; byWh[wh].activity++;
        if(isDispatched(o)){ grid[du][h].dispatched++; totDisp++; byWh[wh].dispatched++; } } }
    }
    // Low-performance: throughput (activity) trong khung giờ làm việc
    const activeVals=[]; days.forEach(d=>{ for(let h=aFrom;h<=aTo;h++) activeVals.push(grid[d][h].activity); });
    const med = median(activeVals.filter(v=>v>0));
    const lowThresh = (P.lowPerfMode==='target' && P.targetPerHour) ? P.targetPerHour : Math.max(1, Math.round(med*(P.lowPerfRatio||0.5)));
    const lowCells=[];
    days.forEach(d=>{ for(let h=aFrom;h<=aTo;h++){ const a=grid[d][h].activity; if(a<lowThresh) lowCells.push({day:d,hour:h,activity:a}); } });
    const daily = days.map(d=>{ let inf=0,act=0,disp=0; for(let h=0;h<24;h++){inf+=grid[d][h].inflow;act+=grid[d][h].activity;disp+=grid[d][h].dispatched;} return {day:d,inflow:inf,activity:act,dispatched:disp}; });
    // peak
    let peak={day:null,hour:null,activity:-1}; days.forEach(d=>{ for(let h=0;h<24;h++){ if(grid[d][h].activity>peak.activity) peak={day:d,hour:h,activity:grid[d][h].activity}; } });
    return { days, grid, byWh, daily, totals:{inflow:totIn,activity:totAct,dispatched:totDisp},
      lowThresh, median:med, activeFrom:aFrom, activeTo:aTo, lowCount:lowCells.length, lowCells, peak };
  }

  // ===== CÂN BẰNG INFLOW vs OUTBOUND THEO GIỜ (giờ nào thiếu người) =====
  // Trung bình theo giờ-trong-ngày qua cửa sổ; net = outbound - inflow (âm = dồn ứ, thiếu người).
  function buildHourlyBalance(prod, cfg){
    if (!prod || !prod.days || !prod.days.length) return null;
    const aF = prod.activeFrom, aT = prod.activeTo, days = prod.days;
    const rows = [];
    for (let h = 0; h < 24; h++) {
      let inSum=0, outSum=0, thrSum=0;
      days.forEach(d => { const g = prod.grid[d][h]; inSum+=g.inflow; outSum+=g.dispatched; thrSum+=g.activity; });
      const n = days.length || 1;
      const inflow = Math.round(inSum/n), outbound = Math.round(outSum/n), throughput = Math.round(thrSum/n);
      rows.push({ hour:h, inflow, outbound, throughput, net: outbound - inflow, carry: null });
    }
    // Cumulative Flow: backlog dồn luỹ kế (WIP) = Σvào − Σxuất trong khung giờ làm việc (TB 1 ngày).
    let cin = 0, cout = 0, peakCarry = 0, peakHour = null;
    for (let h = aF; h <= aT; h++) {
      cin += rows[h].inflow; cout += rows[h].outbound;
      rows[h].cumIn = Math.round(cin); rows[h].cumOut = Math.round(cout);
      rows[h].carry = Math.max(0, Math.round(cin - cout)); // WIP đang ùn cuối giờ h
      if (rows[h].carry > peakCarry) { peakCarry = rows[h].carry; peakHour = h; }
    }
    const active = rows.filter(r => r.hour>=aF && r.hour<=aT);
    // Đỉnh nhịp VÀO và nhịp XUẤT + độ lệch pha (giờ vào đỉnh sớm hơn xuất đỉnh = ùn).
    let peakIn = {hour:null,v:-1}, peakOut = {hour:null,v:-1};
    active.forEach(r => { if (r.inflow > peakIn.v) peakIn = {hour:r.hour, v:r.inflow}; if (r.outbound > peakOut.v) peakOut = {hour:r.hour, v:r.outbound}; });
    const phaseLagH = (peakIn.hour!=null && peakOut.hour!=null) ? (peakOut.hour - peakIn.hour) : null; // >0 = xuất trễ hơn vào
    // Giờ QUEUE ĐANG PHÌNH (vào > xuất) — chỉ là nhịp, không phải "cần người" tuyệt đối.
    const growing = active.filter(r => r.net < 0).sort((a,b)=>a.net-b.net);
    const draining = active.filter(r => r.net > 0).sort((a,b)=>b.net-a.net);
    const totIn = active.reduce((s,r)=>s+r.inflow,0), totOut = active.reduce((s,r)=>s+r.outbound,0);
    return { rows, active, growing, draining, activeFrom:aF, activeTo:aT, peakCarry, peakHour, peakIn, peakOut, phaseLagH, totIn, totOut, days: days.length };
  }

  // ===== DỰ BÁO KỊP HẠN ĐÓNG GÓI (năng suất/giờ vs hạn đóng gói tiêu chuẩn) =====
  // Trả lời: với công suất đóng gói hiện tại (đơn/giờ), pack queue có kịp hạn không,
  // giờ nào & kho nào thiếu công suất, cần bù bao nhiêu đơn/giờ (≈ mấy người).
  function packDeadlineOf(o, cfg){
    const e = o.extra || {};
    if (nonEmpty(e.ecom_pack_deadline)) { const d = parseVN(e.ecom_pack_deadline); if (d) return d; }
    return fulfillmentDeadline(o.created_at, normChannel(platformOf(o)), cfg);
  }
  // Đơn còn CHỜ ĐÓNG GÓI = đang xử lý, CHƯA có nhãn/AWB, và chưa đóng xong/bàn giao.
  function needsPacking(o){
    if (o.status !== 'processing') return false;
    if (!hasPackingStage(o)) return false; // ĐH chỉ vận chuyển -> không có khâu đóng gói
    const sub = String(o.sub_status || '');
    return !/packed|ready_to_handover|handover_to_carrier|picked_up|in_transit|out_for_delivery|delivered/.test(sub);
  }

  // orders: mảng đơn (dùng data tab Năng suất); prod: kết quả buildProductivity.
  // opts: { capacity? (đơn/giờ, ép tay), horizonHours=12, perPersonRate=12 (đơn/người/giờ) }
  function buildPackForecast(orders, prod, cfg, now, opts){
    now = now || new Date(); opts = opts || {};
    const H = Math.max(1, opts.horizonHours || 12);
    const perPerson = Math.max(1, opts.perPersonRate || 12);
    const activeHrs = prod ? (prod.activeTo - prod.activeFrom + 1) : 16;

    // Công suất đo được = median đơn XUẤT/giờ trong khung giờ làm việc; fallback về TB.
    const dispVals = [];
    if (prod && prod.days) prod.days.forEach(d=>{ for(let h=prod.activeFrom;h<=prod.activeTo;h++){ const v=prod.grid[d][h].dispatched; if(v>0) dispVals.push(v); } });
    let capMeasured = median(dispVals);
    if (!capMeasured || capMeasured < 1) {
      const totDisp = prod ? prod.totals.dispatched : 0;
      capMeasured = prod ? Math.round(totDisp / Math.max(1, prod.days.length * activeHrs)) : 0;
      if (!capMeasured) capMeasured = prod ? prod.median : 0;
    }
    const capManual = !!(opts.capacity && opts.capacity > 0);
    const cap = capManual ? opts.capacity : Math.max(1, capMeasured);

    const nowT = now.getTime();
    const pend = [];
    for (const o of (orders || [])) {
      if (!needsPacking(o)) continue;
      const dl = packDeadlineOf(o, cfg); if (!dl) continue;
      pend.push({ code:o.order_code, ref:o.ref_code, wh:warehouseOf(o), ch:channelLabel(normChannel(platformOf(o))), dl:dl.getTime() });
    }
    pend.sort((a,b)=>a.dl-b.dl);
    const overdueNow = pend.filter(p=>p.dl < nowT).length;

    // EDF: đơn hạng r (1-based, theo hạn tăng dần) sẽ đóng xong ~ now + r/cap giờ.
    let predictedLate = 0, requiredRate = cap;
    pend.forEach((p,i)=>{
      const rank = i+1;
      const packAt = nowT + (rank/cap)*3600000;
      if (packAt > p.dl) predictedLate++;
      const hoursLeft = (p.dl - nowT)/3600000;
      if (hoursLeft > 0) { const need = Math.ceil(rank/hoursLeft); if (need > requiredRate) requiredRate = need; }
    });

    // Dự báo theo từng giờ tới: đơn tới hạn trong giờ + thiếu hụt luỹ kế.
    const base = new Date(now.getFullYear(),now.getMonth(),now.getDate(),now.getHours(),0,0);
    const hours = [];
    for (let i=0;i<H;i++){ const s=base.getTime()+i*3600000, e=s+3600000;
      const due = pend.filter(p=>p.dl>=s && p.dl<e).length;
      hours.push({ hour:new Date(s).getHours(), due, s }); }
    let cumDue=0, cumCap=0;
    hours.forEach((h,i)=>{ if(i===0) h.due += overdueNow; cumDue+=h.due; cumCap+=cap; h.cap=cap; h.cumDue=cumDue; h.cumCap=cumCap; h.short=Math.max(0,cumDue-cumCap); });

    // Theo kho: pending, sắp/đã quá hạn, công suất đo, cần bù, ≈ người.
    // Công suất kho = công suất hệ (cap) chia theo TỶ TRỌNG đơn xuất của kho (nhất quán với cap hệ).
    const totDispAll = prod ? Math.max(1, prod.totals.dispatched) : 1;
    const whCapAvg = {};
    if (prod && prod.byWh) Object.keys(prod.byWh).forEach(w=>{
      const share = prod.byWh[w].dispatched / totDispAll;
      whCapAvg[w] = Math.max(1, Math.round(cap * share));
    });
    const whMap = {};
    pend.forEach(p=>{ const w=whMap[p.wh]||(whMap[p.wh]={wh:p.wh,pending:0,due2h:0,overdue:0}); w.pending++; if(p.dl<nowT)w.overdue++; else if(p.dl-nowT<=2*3600000)w.due2h++; });
    const perWh = Object.values(whMap).map(w=>{
      const c = whCapAvg[w.wh] || 1;
      const list = pend.filter(p=>p.wh===w.wh); let req=c;
      list.forEach((p,i)=>{ const hl=(p.dl-nowT)/3600000; if(hl>0){ const n=Math.ceil((i+1)/hl); if(n>req)req=n; } });
      const gap=Math.max(0,req-c); const people=Math.ceil(gap/perPerson);
      return { wh:w.wh, pending:w.pending, due2h:w.due2h, overdue:w.overdue, cap:c, req, gap, people };
    }).sort((a,b)=>(b.overdue-a.overdue)||(b.gap-a.gap)||(b.due2h-a.due2h));

    const bad = predictedLate + overdueNow;
    const verdict = bad===0 ? 'green' : (bad <= Math.max(5, pend.length*0.05) ? 'amber' : 'red');
    const gap = Math.max(0, requiredRate - cap);
    return { cap, capMeasured, capManual, pending:pend.length, overdueNow, predictedLate,
      requiredRate, gap, peopleNeeded:Math.ceil(gap/perPerson), perPerson, hours, perWh, verdict, horizon:H };
  }

  // ================= CYCLE-TIME (đo từ lúc tạo, dùng histories) =================
  // Gom mốc đầu tiên cho mỗi mã trạng thái từ mảng histories.
  function firstMilestones(histories){
    const f={};
    for(const h of histories||[]){
      const k=h.sub_status||h.status;
      if(!k) continue;
      if(!f[k] || h.created_at < f[k]) f[k]=h.created_at;
    }
    return f;
  }
  function pct(arr,p){ if(!arr.length) return null; const a=[...arr].sort((x,y)=>x-y); const i=Math.min(a.length-1, Math.floor(p/100*a.length)); return a[i]; }
  function med(arr){ return pct(arr,50); }

  // orders: [{order_code, warehouse, created_at, ms:{code:ts}}]
  function buildCycleStats(orders, cfg, now){
    now=now||new Date();
    const CY=cfg.cycle;
    const msCode = {}; CY.milestones.forEach(m=>msCode[m.key]=m.code);
    function tsOf(o, key){
      const code=msCode[key];
      const raw = code==='@created' ? o.created_at : (o.ms && o.ms[code]);
      return raw ? parseVN(raw) : null;
    }
    const per=[]; // per-order tính toán
    const stageVals={}; CY.stages.forEach(s=>stageVals[s.key]=[]);
    const dwellVals=[];
    for(const o of orders||[]){
      const rec={order_code:o.order_code, ref_code:o.ref_code, warehouse:whName(o.warehouse), stages:{}, dwell_min:null, handover_at:null, breach:false};
      CY.stages.forEach(s=>{
        const a=tsOf(o,s.from), b=tsOf(o,s.to);
        if(a&&b){ const mn=(b-a)/60000; if(mn>=0){ rec.stages[s.key]=Math.round(mn); stageVals[s.key].push(mn); } }
      });
      const c=tsOf(o,'created'), hv=tsOf(o,'handover');
      if(c&&hv){ const mn=(hv-c)/60000; if(mn>=0){ rec.dwell_min=Math.round(mn); rec.handover_at=hv; dwellVals.push(mn);
        rec.breach = mn > (CY.dwellTargetH*60); } }
      per.push(rec);
    }
    // Aggregate theo khâu
    const stageStats=CY.stages.map(s=>({key:s.key,label:s.label,
      median: Math.round(med(stageVals[s.key])||0), p90: Math.round(pct(stageVals[s.key],90)||0), n: stageVals[s.key].length}));
    const dwellMedian=Math.round(med(dwellVals)||0), dwellP90=Math.round(pct(dwellVals,90)||0);
    const withinSLA = dwellVals.length ? dwellVals.filter(v=>v<=CY.dwellTargetH*60).length/dwellVals.length : null;
    // Bottleneck = khâu có median lớn nhất
    let bottleneck=null; stageStats.forEach(st=>{ if(!bottleneck||st.median>bottleneck.median) bottleneck=st; });
    // Throughput theo mốc BÀN GIAO thật (ngày x giờ)
    const wd=CY.windowDays||3; const days=[];
    for(let i=wd-1;i>=0;i--) days.push(ymd(new Date(now.getTime()-i*86400000)));
    const dayset=new Set(days); const grid={}; days.forEach(d=>{grid[d]={}; for(let h=0;h<24;h++) grid[d][h]=0;});
    let dispatched=0;
    per.forEach(r=>{ if(r.handover_at){ const d=ymd(r.handover_at); if(dayset.has(d)){ grid[d][r.handover_at.getHours()]++; dispatched++; } } });
    // Slowest orders
    const slowest=per.filter(r=>r.dwell_min!=null).sort((a,b)=>b.dwell_min-a.dwell_min).slice(0,20);
    const byWh={};
    per.forEach(r=>{ if(r.dwell_min!=null){ byWh[r.warehouse]=byWh[r.warehouse]||{n:0,sum:0,breach:0}; byWh[r.warehouse].n++; byWh[r.warehouse].sum+=r.dwell_min; if(r.breach) byWh[r.warehouse].breach++; } });
    const whStats=Object.entries(byWh).map(([w,v])=>({wh:w,n:v.n,avg:Math.round(v.sum/v.n),breach:v.breach})).sort((a,b)=>b.avg-a.avg);
    return { n:per.length, measured:dwellVals.length, dwellMedian, dwellP90, withinSLA,
      stageStats, bottleneck, days, grid, dispatched, slowest, whStats,
      targetMin: CY.dwellTargetH*60, breachCount: per.filter(r=>r.breach).length };
  }
  function whName(w){ if(!w) return 'N/A'; if(typeof w==='string') return w; return w.name||w.code||w.id||'N/A'; }

  // ================= CONTROL TOWER (call-out) =================
  const SEV_RANK = { P1:3, P2:2, P3:1 };
  function buildControlTower(ctx, cfg, now){
    now = now || new Date();
    const T = (cfg.controlTower && cfg.controlTower.thresholds) || {};
    const rows = (ctx && ctx.rows) || [];
    const sum = (ctx && ctx.summary) || { byFlag:{}, byBucket:{} };
    const prod = ctx && ctx.prod, cyc = ctx && ctx.cyc;
    const callouts = [];
    const add = (sev, cat, title, detail, action, count, scope) =>
      callouts.push({ sev, cat, title, detail, action, count: count||0, scope: scope||'Toàn hệ thống' });

    const bf = sum.byFlag || {};
    // --- BACKLOG ---
    if ((bf.no_label||0) > (T.no_label||20))
      add('P1','Backlog','Nhiều đơn CHƯA CÓ NHÃN vận chuyển', `${bf.no_label} đơn chưa tạo được vận đơn`, 'Kiểm tra kết nối ĐVVC / tạo nhãn hàng loạt', bf.no_label);
    if ((bf.handover_overdue||0) > (T.handover_overdue||20))
      add('P1','Bàn giao','Tồn đơn CHƯA BÀN GIAO quá SLA', `${bf.handover_overdue} đơn đóng gói xong chưa giao ĐVVC`, 'Đẩy bàn giao ngay, hối ĐVVC tới lấy', bf.handover_overdue);
    if ((bf.shipping_stuck||0) > (T.shipping_stuck||15))
      add('P2','Vận chuyển','Đơn KẸT vận chuyển', `${bf.shipping_stuck} đơn lăn bánh quá lâu`, 'Đối soát với ĐVVC các đơn treo', bf.shipping_stuck);
    const gt72 = (sum.byBucket && sum.byBucket.gt72) || 0;
    if (gt72 > (T.aging_gt72||30))
      add('P2','Aging','Cụm đơn tồn > 72h', `${gt72} đơn quá 72h chưa xong`, 'Ưu tiên giải phóng đơn cũ nhất trước', gt72);
    if ((bf.issue_return||0) > (T.issue_return||15))
      add('P2','Sự cố','Nhiều đơn LỖI/HOÀN', `${bf.issue_return} đơn lỗi hàng/holding`, 'Tách luồng xử lý sự cố, gán người phụ trách', bf.issue_return);

    // --- theo KHO ---
    const perWh = {};
    rows.forEach(r => { const w=r.warehouse||'N/A';
      perWh[w] = perWh[w] || { backlog:0, no_label:0, handover_overdue:0, shipping_stuck:0, aging_gt72:0, issue:0 };
      perWh[w].backlog++;
      r.flags.forEach(f=>{ if(f==='no_label')perWh[w].no_label++; if(f==='handover_overdue')perWh[w].handover_overdue++;
        if(f==='shipping_stuck')perWh[w].shipping_stuck++; if(f==='issue_return')perWh[w].issue++; });
      if(r.bucket==='gt72') perWh[w].aging_gt72++;
    });
    Object.entries(perWh).forEach(([w,v])=>{ if(v.backlog > (T.backlog_per_wh||200))
      add('P2','Kho', `Kho ${w} quá tải backlog`, `${v.backlog} đơn tồn tại kho ${w}`, 'Tăng ca/điều nhân lực về kho này', v.backlog, w); });

    // --- NĂNG SUẤT ---
    if (prod && prod.days && prod.days.length){
      const today = prod.days[prod.days.length-1];
      let lowH=0; for(let h=prod.activeFrom;h<=prod.activeTo;h++){ if(prod.grid[today][h].activity < prod.lowThresh) lowH++; }
      const curH = now.getHours();
      if (curH>=prod.activeFrom && curH<=prod.activeTo && prod.grid[today][curH] && prod.grid[today][curH].activity < prod.lowThresh)
        add('P1','Năng suất','Năng suất ĐANG TỤT (giờ hiện tại)', `Giờ ${curH}h chỉ ${prod.grid[today][curH].activity} thao tác (< ngưỡng ${prod.lowThresh})`, 'Kiểm tra line/nhân sự ngay tại chỗ', prod.grid[today][curH].activity);
      if (lowH >= (T.prod_low_hours_today||3))
        add('P2','Năng suất', `Hôm nay có ${lowH} giờ dưới năng suất`, `Nhiều khung giờ throughput < ${prod.lowThresh}/giờ`, 'Rà lại phân ca theo giờ cao điểm', lowH);
    }

    // --- CYCLE-TIME ---
    if (cyc && cyc.measured){
      if (cyc.withinSLA!=null && cyc.withinSLA < (T.cycle_sla_pct||0.8))
        add('P1','Cycle', 'Tỷ lệ đạt SLA dwell THẤP', `Chỉ ${Math.round(cyc.withinSLA*100)}% đơn đạt SLA tạo→bàn giao`, 'Truy khâu nghẽn, đặt lại chuẩn thời gian', cyc.breachCount);
      if (cyc.bottleneck && cyc.bottleneck.median > (T.cycle_stage_min||60))
        add('P2','Cycle', `Khâu nghẽn: ${cyc.bottleneck.label}`, `Trung vị ${cyc.bottleneck.median}′ ở khâu ${cyc.bottleneck.label}`, 'Dồn nguồn lực vào đúng khâu này', cyc.bottleneck.median);
    }

    // --- SLA ---
    const pk = ctx && ctx.pk, dl = ctx && ctx.dl;
    if (pk && pk.measured){
      if (pk.rate!=null && pk.rate < pk.target)
        add('P1','SLA','On-time ĐÓNG GÓI dưới KPI', `On-time ${Math.round(pk.rate*100)}% < mục tiêu ${Math.round(pk.target*100)}%`, 'Truy kênh/kho trễ nhất, dọn đơn quá hạn', (pk.lateDone||0)+(pk.overdueOpen||0));
      if ((pk.overdueOpen||0) > (T.sla_pack_overdue||10))
        add('P1','SLA','Đơn QUÁ HẠN đóng gói chưa xong', `${pk.overdueOpen} đơn vượt hạn đóng gói mà chưa bàn giao`, 'Ưu tiên bàn giao ngay các đơn này', pk.overdueOpen);
    }
    if (dl && dl.measured){
      if (dl.rate!=null && dl.rate < dl.target)
        add('P1','SLA','On-time GIAO HÀNG dưới KPI', `On-time ${Math.round(dl.rate*100)}% < mục tiêu ${Math.round(dl.target*100)}%`, 'Đối soát ĐVVC có tỷ lệ trễ cao', (dl.lateDone||0)+(dl.overdueOpen||0));
      if ((dl.overdueOpen||0) > (T.sla_deliver_overdue||10))
        add('P2','SLA','Đơn QUÁ HẠN giao chưa xong', `${dl.overdueOpen} đơn vượt hạn giao`, 'Hối ĐVVC, chủ động báo khách', dl.overdueOpen);
    }

    callouts.sort((a,b)=> (SEV_RANK[b.sev]-SEV_RANK[a.sev]) || (b.count-a.count));

    // Ma trận sức khoẻ theo kho
    const wh = (cfg.controlTower && cfg.controlTower.whHealth) || { green:50, amber:150 };
    const colorBacklog = n => n<=wh.green?'green':n<=wh.amber?'amber':'red';
    const health = Object.entries(perWh).sort((a,b)=>b[1].backlog-a[1].backlog).map(([w,v])=>({
      wh:w, backlog:v.backlog,
      c_backlog: colorBacklog(v.backlog),
      c_handover: v.handover_overdue===0?'green':(v.handover_overdue<10?'amber':'red'),
      c_label: v.no_label===0?'green':(v.no_label<10?'amber':'red'),
      c_issue: v.issue===0?'green':(v.issue<5?'amber':'red'),
      detail:v
    }));

    const p1 = callouts.filter(c=>c.sev==='P1').length, p2 = callouts.filter(c=>c.sev==='P2').length;
    const status = p1>0?'red':(p2>0?'amber':'green');
    return { callouts, health, counts:{P1:p1, P2:p2, P3:callouts.filter(c=>c.sev==='P3').length}, status,
      totalBacklog: sum.total||rows.length, generatedAt: now };
  }

  // ================= SLA ĐÓNG GÓI + VẬN CHUYỂN =================
  function rawParts(str){ const m=String(str||'').match(/(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2}):(\d{2})/) || String(str||'').match(/(\d{4})-(\d{2})-(\d{2})/); if(!m) return null; return {y:+m[1],mo:+m[2],d:+m[3],H:+(m[4]||0),Min:+(m[5]||0),S:+(m[6]||0)}; }
  function vnClock(y,mo,d,H,Min,S){ return new Date(Date.UTC(y,mo-1,d,H-7,Min||0,S||0)); } // giờ VN (+07) -> tuyệt đối
  function isWorkday(dt, holidays){ return dt.getDay()!==0 && !(holidays||[]).includes(ymd(dt)); } // loại CN + lễ (T7 vẫn làm)
  function addWorkingDays(y,mo,d,n,holidays){
    let cur=new Date(y,mo-1,d);
    if(n<=0){ while(!isWorkday(cur,holidays)) cur.setDate(cur.getDate()+1); return cur; }
    let added=0; while(added<n){ cur.setDate(cur.getDate()+1); if(isWorkday(cur,holidays)) added++; }
    return cur;
  }
  function normChannel(p){ const x=String(p||''); if(/lazada/i.test(x))return'Lazada'; if(/shopee/i.test(x))return'Shopee'; if(/tiktok/i.test(x))return'TikTok Shop'; return '_default'; }
  function channelLabel(c){ return c==='_default'?'Khác':c; }

  function fulfillmentDeadline(createdStr, channel, cfg){
    const P=rawParts(createdStr); if(!P) return null;
    const S=cfg.slaFulfillment; const buckets=S.channels[channel]||S.channels._default;
    let b=buckets.find(x=>P.H < x.toHour) || buckets[buckets.length-1];
    const dd=addWorkingDays(P.y,P.mo,P.d,b.dayOffset,S.holidays);
    return vnClock(dd.getFullYear(), dd.getMonth()+1, dd.getDate(), b.h, 0, 0);
  }
  function endOfDayVN(str){ const P=rawParts(str); if(!P) return null; return vnClock(P.y,P.mo,P.d,23,59,59); }
  // Hạn GIAO theo promised: nếu có GIỜ cụ thể -> dùng đúng giờ (chính xác); chỉ có ngày -> cuối ngày.
  function promiseDeadline(str){ if(!str) return null; if(/\d{1,2}:\d{2}/.test(String(str))){ const d=parseVN(str); if(d) return d; } return endOfDayVN(str); }
  function fmtVN(dt){ if(!dt) return null; const v=new Date(dt.getTime()+7*3600000); const p=n=>String(n).padStart(2,'0'); return `${v.getUTCFullYear()}-${p(v.getUTCMonth()+1)}-${p(v.getUTCDate())} ${p(v.getUTCHours())}:${p(v.getUTCMinutes())}`; }

  function isExcluded(order_code, dateStr, cfg){
    const X=cfg.slaExclusions; if(!X||!X.enabled) return false;
    if(X.manualCodes && X.manualCodes.indexOf(order_code)>=0) return true;
    if(X.peakDays && X.peakDays.length){ const d=String(dateStr||'').slice(0,10); if(X.peakDays.indexOf(d)>=0) return true; }
    return false;
  }
  // Chuỗi tên kho an toàn (tránh in ra "[object Object]").
  function whStr(w){ if(!w) return 'N/A'; if(typeof w==='string') return w; return w.name||w.code||w.id||'N/A'; }
  // Thời điểm ĐÃ ĐÓNG GÓI XONG / rời kho: quét nhiều mã mốc (histories dùng mã khác nhau).
  function packDoneTs(o){
    const ms=o.ms||{};
    for(const k of ['handover_to_3pl','handover_to_carrier','handover','ready_to_handover','picked_up']){
      if(ms[k]){ const t=parseVN(ms[k]); if(t) return t; }
    }
    let earliest=null;
    for(const k in ms){
      if(/handover|picked_up|pickup|in_transit|transit|delivering|out_for_delivery|delivered|shipping|logi_driver/i.test(k)){
        const t=parseVN(ms[k]); if(t && (!earliest || t<earliest)) earliest=t;
      }
    }
    return earliest;
  }
  function buildPackingSLA(orders, cfg, now){
    now=now||new Date(); const T=cfg.slaFulfillment.kpiTarget;
    const recs=[]; const byCh={};
    for(const o of orders||[]){
      if(!o.created_at) continue;
      if(!hasPackingStage(o)) continue; // ĐH chỉ vận chuyển (last_miles) -> không đo SLA đóng gói
      const channel=normChannel(o.platform);
      const deadline = nonEmpty((o.extra||{}).ecom_pack_deadline) ? parseVN(o.extra.ecom_pack_deadline) : fulfillmentDeadline(o.created_at, channel, cfg);
      if(!deadline) continue;
      // Đây là đơn ĐÃ shipping/delivered -> chắc chắn đã đóng gói xong. Tìm mốc bàn giao;
      // nếu thiếu mốc thì coi ĐÃ XONG (không rõ giờ), KHÔNG bao giờ là "quá hạn chưa xong".
      const comp = packDoneTs(o);
      let state, over=null;
      if(comp){ const late=comp>deadline; state=late?'late':'on_time'; if(late) over=Math.round((comp-deadline)/60000); }
      else { state='done_untimed'; }
      byCh[channel]=byCh[channel]||{measured:0,onTime:0,late:0,overdue:0};
      if(state==='on_time'||state==='late'){ byCh[channel].measured++; if(state==='on_time')byCh[channel].onTime++; else byCh[channel].late++; }
      recs.push({order_code:o.order_code, ref_code:o.ref_code, channel:channelLabel(channel), warehouse:whStr(o.warehouse), created_at:o.created_at, deadline:fmtVN(deadline), completion:comp?fmtVN(comp):null, state, over, excluded:isExcluded(o.order_code,o.created_at,cfg)});
    }
    const done=recs.filter(r=>r.state==='on_time'||r.state==='late');
    const net=done.filter(r=>!r.excluded);
    const measured=net.length, onTime=net.filter(r=>r.state==='on_time').length;
    const measuredGross=done.length, onTimeGross=done.filter(r=>r.state==='on_time').length;
    const overdueOpen=recs.filter(r=>r.state==='overdue').length;
    const lateDone=recs.filter(r=>r.state==='late').length;
    const lateList=recs.filter(r=>r.state==='overdue'||r.state==='late').sort((a,b)=>(a.state===b.state?0:(a.state==='overdue'?-1:1))||0).sort((a,b)=>(b.over||0)-(a.over||0));
    const byChannel=Object.entries(byCh).map(([c,v])=>({channel:channelLabel(c), measured:v.measured, onTime:v.onTime, late:v.late, overdue:v.overdue, rate:v.measured?v.onTime/v.measured:null}));
    return { measured, onTime, rate: measured?onTime/measured:null, rateGross: measuredGross?onTimeGross/measuredGross:null, excluded: measuredGross-measured, overdueOpen, lateDone, lateList, byChannel, target:T };
  }

  function buildDeliverySLA(orders, cfg, now){
    now=now||new Date(); const T=cfg.slaDelivery.kpiTarget;
    const recs=[]; const byC={};
    for(const o of orders||[]){
      if(!o.promised) continue;
      const deadline=promiseDeadline(o.promised); if(!deadline) continue;
      const del = (o.ms && o.ms.delivered) ? parseVN(o.ms.delivered) : null;
      let state, over=null;
      if(del){ const late=del>deadline; state=late?'late':'on_time'; if(late) over=Math.round((del-deadline)/60000); }
      else { if(now>deadline){ state='overdue'; over=Math.round((now-deadline)/60000); } else state='in_transit'; }
      const carrier=o.carrier||'N/A';
      byC[carrier]=byC[carrier]||{measured:0,onTime:0,late:0,overdue:0};
      if(state==='on_time'||state==='late'){ byC[carrier].measured++; if(state==='on_time')byC[carrier].onTime++; else byC[carrier].late++; }
      if(state==='overdue') byC[carrier].overdue++;
      recs.push({order_code:o.order_code, ref_code:o.ref_code, carrier, warehouse:o.warehouse, promised:o.promised, delivered:o.ms&&o.ms.delivered||null, state, over, excluded:isExcluded(o.order_code,o.promised,cfg)});
    }
    const done=recs.filter(r=>r.state==='on_time'||r.state==='late');
    const net=done.filter(r=>!r.excluded);
    const measured=net.length, onTime=net.filter(r=>r.state==='on_time').length;
    const measuredGross=done.length, onTimeGross=done.filter(r=>r.state==='on_time').length;
    const overdueOpen=recs.filter(r=>r.state==='overdue').length;
    const lateDone=recs.filter(r=>r.state==='late').length;
    const lateList=recs.filter(r=>r.state==='overdue'||r.state==='late').sort((a,b)=>(b.over||0)-(a.over||0));
    const byCarrier=Object.entries(byC).map(([c,v])=>({carrier:c, measured:v.measured, onTime:v.onTime, late:v.late, overdue:v.overdue, rate:v.measured?v.onTime/v.measured:null}));
    return { measured, onTime, rate: measured?onTime/measured:null, rateGross: measuredGross?onTimeGross/measuredGross:null, excluded: measuredGross-measured, overdueOpen, lateDone, lateList, byCarrier, target:T };
  }

  // ================= SẮP TRỄ (at-risk) + TẢI vs NĂNG LỰC =================
  function bucketByRemain(remain, W){
    return remain<0?'overdue': remain<=W.critical?'critical': remain<=W.warning?'warning': remain<=W.watch?'watch':'ok';
  }
  // backlogOrders: đơn thô status processing/awaiting (chưa bàn giao). cycOrders: đơn detail (cho phần giao).
  function buildAtRisk(backlogOrders, cycOrders, cfg, now){
    now=now||new Date();
    const Wp=cfg.atRisk.packWindows, Wd=cfg.atRisk.deliverWindows;
    const pkList=[], pkB={overdue:0,critical:0,warning:0,watch:0,ok:0};
    for(const o of backlogOrders||[]){
      const st=o.status;
      if(st!=='processing' && st!=='awaiting_confirmation') continue; // chưa bàn giao
      if(!hasPackingStage(o)) continue; // ĐH chỉ vận chuyển (last_miles) -> không có khâu đóng gói
      const sub=String(o.sub_status||'');
      // ĐÃ đóng gói xong / bàn giao / vận chuyển -> KHÔNG còn ở khâu đóng gói.
      if(st==='processing' && /packed|ready_to_handover|handover_to_carrier|picked_up|in_transit|out_for_delivery|delivered/.test(sub)) continue;
      const channel=normChannel(platformOf(o));
      const ex=o.extra||{};
      const deadline = nonEmpty(ex.ecom_pack_deadline) ? parseVN(ex.ecom_pack_deadline) : fulfillmentDeadline(o.created_at, channel, cfg);
      if(!deadline) continue;
      const remain=Math.round((deadline-now)/60000);
      const b=bucketByRemain(remain,Wp); pkB[b]++;
      if(b!=='ok') pkList.push({order_code:o.order_code, ref_code:o.ref_code, channel:channelLabel(channel), warehouse:warehouseOf(o),
        created_at:o.created_at, deadline:fmtVN(deadline), remain, bucket:b,
        no_label:(st==='processing' && !hasLabel(o)), sub:o.sub_status||''});
    }
    pkList.sort((a,b)=>a.remain-b.remain);

    // ---- KẸT BÀN GIAO: đã đóng gói xong nhưng CHƯA giao ĐVVC (kẹt ở khu đóng/bàn giao) ----
    const Wh={critical:60,warning:180,watch:360}; // phút tới hạn bàn giao = lúc đóng xong + handover_h
    const hoList=[], hoB={overdue:0,critical:0,warning:0,watch:0,ok:0};
    for(const o of backlogOrders||[]){
      if(o.status!=='processing') continue;
      if(!hasPackingStage(o)) continue; // last_miles không có bước đóng/bàn giao ở kho
      const sub=String(o.sub_status||'');
      if(!/packed|ready_to_handover|handover_to_carrier/.test(sub)) continue; // đã đóng xong, chờ giao ĐVVC
      const packedAt=parseVN(o.updated_at)||parseVN(o.created_at); if(!packedAt) continue;
      const deadline=new Date(packedAt.getTime()+(cfg.sla.handover_h||12)*3600000);
      const remain=Math.round((deadline-now)/60000);
      const b=bucketByRemain(remain,Wh); hoB[b]++;
      if(b!=='ok') hoList.push({order_code:o.order_code, ref_code:o.ref_code, warehouse:warehouseOf(o), carrier:carrierOf(o),
        sub:o.sub_status||'', stuck_min:Math.round((now-packedAt)/60000), remain, bucket:b});
    }
    hoList.sort((a,b)=>a.remain-b.remain);

    const dlList=[], dlB={overdue:0,critical:0,warning:0,watch:0,ok:0};
    for(const o of cycOrders||[]){
      if(o.ms && o.ms.delivered) continue; if(!o.promised) continue;
      const deadline=promiseDeadline(o.promised); if(!deadline) continue;
      const remain=Math.round((deadline-now)/60000);
      const b=bucketByRemain(remain,Wd); dlB[b]++;
      if(b!=='ok') dlList.push({order_code:o.order_code, ref_code:o.ref_code||null, carrier:o.carrier||'N/A', warehouse:o.warehouse, promised:o.promised, remain, bucket:b});
    }
    dlList.sort((a,b)=>a.remain-b.remain);
    return { packing:{buckets:pkB, list:pkList, total:pkList.length, actNow:pkB.overdue+pkB.critical},
             handover:{buckets:hoB, list:hoList, total:hoList.length, actNow:hoB.overdue+hoB.critical},
             delivery:{buckets:dlB, list:dlList, total:dlList.length, actNow:dlB.overdue+dlB.critical} };
  }

  // Tải vs năng lực: đơn đang chờ xử lý vs năng lực/giờ và nhịp đơn vào.
  function buildCapacity(backlogOrders, prod, cfg, now){
    now=now||new Date();
    const whs={};
    let open=0;
    for(const o of backlogOrders||[]){
      if(o.status==='processing'||o.status==='awaiting_confirmation'){ open++; const w=warehouseOf(o); whs[w]=(whs[w]||0)+1; }
    }
    const nWh=Math.max(1, Object.keys(whs).length);
    let capPerHour = (cfg.capacity.perHourPerWh||40) * nWh;
    if(cfg.capacity.useProdMedian && prod && prod.median>0) capPerHour = prod.median; // median throughput toàn hệ (đã gộp giờ)
    // nhịp đơn vào giờ gần nhất (từ prod inflow hôm nay, các giờ hoạt động)
    let inboundPerHour=null;
    if(prod && prod.days && prod.days.length){
      const today=prod.days[prod.days.length-1]; let sum=0,c=0;
      for(let h=prod.activeFrom;h<=prod.activeTo;h++){ sum+=prod.grid[today][h].inflow; c++; }
      inboundPerHour = c? Math.round(sum/c) : null;
    }
    const net = capPerHour - (inboundPerHour||0);
    const hoursToClear = net>0 ? Math.round(open/net*10)/10 : Infinity;
    return { open, byWh:whs, capPerHour, inboundPerHour, net, hoursToClear };
  }

  // ================= FLOW & NGHẼN =================
  function buildFlow(backlog, cyc, cfg, now, capPerHour, inflow){
    now=now||new Date(); const F=cfg.flow;
    capPerHour = capPerHour || F.packCapacityPerHour || 120;
    const stageOf={}; F.stages.forEach(s=>s.subs.forEach(x=>stageOf[x]=s.key));
    const wip={}; F.stages.forEach(s=>wip[s.key]=0);
    const packedByCarrier={}; const inPickPack=[];
    for(const o of backlog||[]){
      const st=o.status;
      if(st!=='processing' && st!=='awaiting_confirmation') continue;
      const sub=o.sub_status||'';
      let sk=stageOf[sub]; if(!sk) sk='wait_pick';
      wip[sk]=(wip[sk]||0)+1;
      if(sk==='packed'){ const c=carrierOf(o); const rec=packedByCarrier[c]||(packedByCarrier[c]={count:0,waitSum:0,maxWait:0});
        const u=parseVN(o.updated_at)||parseVN(o.created_at); const w=u?Math.max(0,Math.round((now-u)/60000)):0;
        rec.count++; rec.waitSum+=w; rec.maxWait=Math.max(rec.maxWait,w); }
      if(sk==='wait_pick'||sk==='picking'||sk==='packing') inPickPack.push(sk);
    }
    // medians từ cycle-time (fallback config)
    const sm=(k,def)=>{ if(cyc&&cyc.stageStats){ const s=cyc.stageStats.find(x=>x.key===k); if(s&&s.median) return s.median; } return def; };
    const pickMed=sm('pick',F.defaultPickMin), packMed=sm('pack',F.defaultPackMin), hoMed=sm('handover_wait',F.defaultHandoverMin);
    // Dự báo dồn ra BÀN GIAO theo giờ
    const N=F.forecastHours||12; const forecast=[];
    const baseHour=new Date(now.getTime()); baseHour.setMinutes(0,0,0);
    for(let i=0;i<N;i++){ const h=new Date(baseHour.getTime()+i*3600000); forecast.push({hour:h.getHours(), label:h.getHours()+'h', count:0, ts:h.getTime()}); }
    // Hàng từ pick/pack sẽ tới bàn giao ở giờ nào (theo est)
    const readyBucket=new Array(N).fill(0);
    inPickPack.forEach(sk=>{ const est= sk==='wait_pick'?(pickMed+packMed): sk==='picking'?packMed: packMed*0.5;
      let idx=Math.floor((now.getTime()+est*60000 - baseHour.getTime())/3600000); if(idx<0)idx=0; if(idx>=N)idx=N-1; readyBucket[idx]++; });
    // Đơn MỚI dự báo đổ vào (inflow) sẽ tới bàn giao sau lead-time pick+pack
    let inflowUsed=false;
    if(inflow && inflow.length){ inflowUsed=true; const leadH=Math.max(0,Math.round((pickMed+packMed)/60));
      inflow.forEach((f,i)=>{ const idx=i+leadH; if(idx>=0 && idx<N) readyBucket[idx]+=(f.predicted||0); }); }
    // Mô phỏng HÀNG ĐỢI tại bàn giao: ùn sẵn + hàng tới - nhịp ĐVVC lấy (capPerHour)
    const handoverCap=capPerHour; let queue=wip.packed||0; let congestHour=null;
    forecast.forEach((f,i)=>{ queue+=readyBucket[i]; f.arrive=readyBucket[i]; f.count=queue; /* pile trong giờ */
      if(congestHour==null && queue>(F.congestThreshold||150)) congestHour=f.label;
      const out=Math.min(queue,handoverCap); f.cleared=out; queue-=out; f.queue=queue; });
    let peak=null; forecast.forEach(f=>{ if(!peak||f.count>peak.count) peak=f; });
    // Packing có kịp SLA không (mô phỏng EDD: xử lý theo hạn gần nhất, năng lực capPerHour)
    const due=[]; for(const o of backlog||[]){ if(o.status!=='processing'&&o.status!=='awaiting_confirmation') continue;
      const dl=fulfillmentDeadline(o.created_at, normChannel(platformOf(o)), cfg); if(dl) due.push(dl.getTime()); }
    due.sort((a,b)=>a-b);
    const perOrderMin = capPerHour>0 ? 60/capPerHour : 9999;
    let t=now.getTime(), miss=0, firstMiss=null;
    for(const dl of due){ t += perOrderMin*60000; if(t>dl){ miss++; if(!firstMiss) firstMiss=dl; } }
    // Nghẽn theo ĐVVC (đơn chờ bàn giao)
    const carriers=Object.entries(packedByCarrier).map(([c,v])=>({carrier:c,count:v.count,avgWait:Math.round(v.waitSum/Math.max(1,v.count)),maxWait:v.maxWait})).sort((a,b)=>b.count-a.count);
    // Chẩn đoán nghẽn
    const orderKeys=['wait_pick','picking','packing','packed'];
    let primary=orderKeys[0]; orderKeys.forEach(k=>{ if((wip[k]||0)>(wip[primary]||0)) primary=k; });
    const labelOf=k=>(F.stages.find(s=>s.key===k)||{}).label||k;
    let diagnosis='';
    const upstream=(wip.wait_pick||0)+(wip.picking||0);
    if(primary==='packed') diagnosis='Nghẽn ở BÀN GIAO/SORT — đơn đóng xong ùn chờ ĐVVC lấy. Push ĐVVC.';
    else if((primary==='wait_pick'||primary==='picking') && (wip.packing||0) < upstream*0.3) diagnosis='Nghẽn PICK/LẤY HÀNG — đóng gói đang bị "đói" hàng ở dưới. Dồn người khâu lấy.';
    else if(primary==='packing') diagnosis='Nghẽn ĐÓNG GÓI — trạm đóng không kịp nhịp. Tăng bàn đóng/nhân lực.';
    else diagnosis='Dòng chảy tương đối cân bằng.';
    const congest = (wip[primary]||0) > (F.congestThreshold||150);
    return { wip, forecast, peak, packing:{ due:due.length, miss, firstMiss: firstMiss?fmtVN(new Date(firstMiss)):null, capPerHour },
      carriers, primary, primaryLabel:labelOf(primary), diagnosis, congest, congestHour, pickMed, packMed, hoMed, inflowUsed };
  }

  // Profile inflow theo giờ-trong-ngày (trung bình lịch sử) -> dự báo N giờ tới
  function buildInflowForecast(prod, cfg, now){
    now=now||new Date(); const N=(cfg.flow&&cfg.flow.forecastHours)||12;
    const sum=new Array(24).fill(0), cnt=new Array(24).fill(0);
    if(prod && prod.days){ prod.days.forEach(d=>{ for(let h=0;h<24;h++){ sum[h]+=prod.grid[d][h].inflow; cnt[h]++; } }); }
    const avg=sum.map((x,h)=>cnt[h]?Math.round(x/cnt[h]):0);
    const base=new Date(now.getTime()); base.setMinutes(0,0,0);
    const out=[]; for(let i=0;i<N;i++){ const h=new Date(base.getTime()+i*3600000); out.push({hour:h.getHours(), label:h.getHours()+'h', predicted:avg[h.getHours()], ts:h.getTime()}); }
    return out;
  }

  // ================= FIFO BÀN GIAO =================
  function laneKey(wh,car){ return (wh||'?')+' | '+(car||'?'); }
  function buildFifo(cyc, backlog, cfg, now){
    now=now||new Date();
    const disp=[];
    for(const o of cyc||[]){
      if(!(o.ms && o.ms.packed && o.ms.handover_to_3pl)) continue;
      const rT=parseVN(o.ms.packed), hT=parseVN(o.ms.handover_to_3pl); if(!rT||!hT) continue;
      disp.push({wh:whName(o.warehouse), carrier:o.carrier||'N/A', readyT:rT.getTime(), hoT:hT.getTime(), order_code:o.order_code, ref_code:o.ref_code});
    }
    const wait=[];
    for(const o of backlog||[]){
      if(o.status!=='processing') continue;
      const sub=String(o.sub_status||''); if(!/packed|ready_to_handover|handover_to_carrier/.test(sub)) continue;
      const rt=parseVN(o.updated_at)||parseVN(o.created_at); if(!rt) continue;
      wait.push({wh:warehouseOf(o), carrier:carrierOf(o), readyT:rt.getTime(), order_code:o.order_code, ref_code:o.ref_code, wait_min:Math.max(0,Math.round((now-rt)/60000))});
    }
    const lanes={};
    disp.forEach(d=>{ const k=laneKey(d.wh,d.carrier); (lanes[k]=lanes[k]||{wh:d.wh,carrier:d.carrier,disp:[]}).disp.push(d); });
    let totalDisp=0,totalVic=0; const byLane=[];
    for(const k in lanes){ const L=lanes[k]; L.disp.sort((a,b)=>a.hoT-b.hoT);
      let maxReady=-Infinity,vic=0; L.disp.forEach(d=>{ if(d.readyT<maxReady) vic++; if(d.readyT>maxReady)maxReady=d.readyT; });
      L.maxReady=Math.max.apply(null,L.disp.map(d=>d.readyT));
      totalDisp+=L.disp.length; totalVic+=vic;
      byLane.push({lane:k,wh:L.wh,carrier:L.carrier,dispatched:L.disp.length,violations:vic,adherence:L.disp.length?1-vic/L.disp.length:null});
    }
    byLane.sort((a,b)=>(a.adherence==null?1:a.adherence)-(b.adherence==null?1:b.adherence));
    const stuck=[];
    wait.forEach(w=>{ const L=lanes[laneKey(w.wh,w.carrier)]; const mrd=L?L.maxReady:-Infinity;
      if(w.readyT<mrd){ const by=L.disp.filter(d=>d.readyT>w.readyT).length;
        stuck.push({order_code:w.order_code, ref_code:w.ref_code, wh:w.wh, carrier:w.carrier, wait_min:w.wait_min, overtaken_by:by}); } });
    stuck.sort((a,b)=>b.wait_min-a.wait_min);
    return { adherence: totalDisp?1-totalVic/totalDisp:null, dispatched:totalDisp, violations:totalVic, byLane, stuck, waiting:wait.length };
  }

  // ===== Carrier scorecard (chấm điểm ĐVVC) =====
  function buildCarrierScorecard(cyc, backlog, cfg, now){
    now=now||new Date(); const card={};
    const get=c=>card[c]||(card[c]={carrier:c, waiting:0, waitSum:0, delivered:0, ontime:0, late:0, dwellSum:0, dwellN:0});
    for(const o of backlog||[]){ if(o.status!=='processing') continue; const sub=String(o.sub_status||''); if(!/packed|ready_to_handover|handover_to_carrier/.test(sub)) continue;
      const g=get(carrierOf(o)); g.waiting++; const u=parseVN(o.updated_at)||parseVN(o.created_at); if(u) g.waitSum+=Math.max(0,(now-u)/60000); }
    for(const o of cyc||[]){ if(!o.promised) continue; const g=get(o.carrier||'N/A'); const dl=promiseDeadline(o.promised); const del=o.ms&&o.ms.delivered?parseVN(o.ms.delivered):null;
      if(del){ g.delivered++; if(del<=dl) g.ontime++; else g.late++; const cr=parseVN(o.created_at); if(cr){ g.dwellSum+=(del-cr)/3600000; g.dwellN++; } } }
    const rows=Object.values(card).map(g=>{ const ot=g.delivered?g.ontime/g.delivered:null; const avgWait=g.waiting?Math.round(g.waitSum/g.waiting):0;
      const score=Math.round((ot==null?100:ot*100) - g.waiting*0.2 - avgWait/30);
      return {carrier:g.carrier, waiting:g.waiting, avg_wait:avgWait, delivered:g.delivered, deliver_ontime:ot, late:g.late, dwell_h:g.dwellN?Math.round(g.dwellSum/g.dwellN*10)/10:null, score}; });
    rows.sort((a,b)=>a.score-b.score); // tệ nhất lên đầu để ép
    return rows;
  }
  // ===== WBR: so tuần này vs tuần trước từ snapshot trend =====
  function buildWbr(snapshots, now){
    now=now||new Date(); const wk=7*86400000, cur=[], prev=[];
    (snapshots||[]).forEach(s=>{ const age=now-new Date(s.ts).getTime(); if(age<=wk) cur.push(s); else if(age<=2*wk) prev.push(s); });
    const avg=(arr,k)=>arr.length?Math.round(arr.reduce((a,b)=>a+(b[k]||0),0)/arr.length):null;
    const keys=[['backlog','Backlog'],['P1','Call-out P1'],['no_label','Chưa nhãn'],['handover_overdue','Chưa bàn giao'],['aging_gt72','Đơn >72h'],['atrisk_pack','Sắp trễ đóng gói'],['packing_miss','Dự báo trễ SLA'],['pack_ontime','On-time đóng gói %'],['deliver_ontime','On-time giao %'],['fifo','FIFO %']];
    const metrics=keys.filter(([k])=>cur.some(s=>s[k]!=null)||prev.some(s=>s[k]!=null)).map(([k,label])=>{ const c=avg(cur,k), p=avg(prev,k); const d=(c!=null&&p)?Math.round((c-p)/p*100):null; return {key:k,label,cur:c,prev:p,delta:d}; });
    return { generatedAt: now.toISOString(), samples:{cur:cur.length,prev:prev.length}, metrics };
  }
  // ===== Breakdown backlog theo Brand / Channel / Group brand =====
  function buildBrandBreakdown(rows){
    const brand={}, channel={}, gb={}, opollo={};
    const bump=(map,key)=>{ key=(key==null||key==='')?'(chưa map)':key; return map[key]||(map[key]={key, backlog:0, no_label:0, handover_overdue:0, aging_gt72:0, issue:0}); };
    (rows||[]).forEach(r=>{
      [[brand,r.brand],[channel,r.channel_map],[gb,r.group_brand],[opollo,r.opollo_channel]].forEach(([map,key])=>{
        const o=bump(map,key); o.backlog++;
        (r.flags||[]).forEach(f=>{ if(f==='no_label')o.no_label++; if(f==='handover_overdue')o.handover_overdue++; if(f==='issue_return')o.issue++; });
        if(r.bucket==='gt72') o.aging_gt72++;
      });
    });
    const arr=m=>Object.values(m).sort((a,b)=>b.backlog-a.backlog);
    return { byBrand:arr(brand), byChannel:arr(channel), byGroupBrand:arr(gb), byOpollo:arr(opollo) };
  }
  // ================= VẬN CHUYỂN & HOÀN (last-mile monitoring) =================
  const SHIP_LABEL = { delivering:'Đang giao', transit:'Đang trung chuyển / mới bàn giao', storing:'Lưu tại ĐVVC', returning:'Đang chuyển hoàn' };
  function shipStateOf(sub){
    const s = String(sub || '');
    if (/return|hoan/i.test(s)) return 'returning';
    if (/storing|storage|luu_kho/i.test(s)) return 'storing';
    if (/delivering|out_for_delivery|dang_giao/i.test(s)) return 'delivering';
    return 'transit'; // '', in_transit, mới bàn giao ĐVVC
  }
  // orders: kết quả collectShipping (status shipping).
  function buildShipping(orders, cfg, now){
    now = now || new Date();
    const shH = (cfg.sla && cfg.sla.shipping_h) || 72;
    const state = { delivering:0, transit:0, storing:0, returning:0 };
    const stuck = [], returning = [], overdueDeliver = [];
    const byC = {};
    for (const o of (orders || [])) {
      const stt = shipStateOf(o.sub_status); state[stt]++;
      const created = parseVN(o.created_at), updated = parseVN(o.updated_at) || created;
      const ageH = created ? (now - created) / HOUR : null;
      const stageH = updated ? (now - updated) / HOUR : null;
      const c = o.carrier || 'N/A';
      const g = byC[c] || (byC[c] = { carrier:c, total:0, delivering:0, transit:0, storing:0, returning:0, stuck:0 });
      g.total++; g[stt]++;
      const isStuck = (stt !== 'returning') && ageH != null && ageH > shH;
      if (isStuck) { g.stuck++; stuck.push({ order_code:o.order_code, ref_code:o.ref_code, carrier:c, warehouse:o.warehouse, state:SHIP_LABEL[stt], age_h:Math.round(ageH), stage_h:stageH!=null?Math.round(stageH):null }); }
      if (stt === 'returning') returning.push({ order_code:o.order_code, ref_code:o.ref_code, carrier:c, warehouse:o.warehouse, age_h:ageH!=null?Math.round(ageH):null, stage_h:stageH!=null?Math.round(stageH):null });
      const pr = o.promised ? promiseDeadline(o.promised) : null;
      if (pr && now > pr) overdueDeliver.push({ order_code:o.order_code, ref_code:o.ref_code, carrier:c, warehouse:o.warehouse, promised:o.promised, over_h:Math.round((now-pr)/HOUR), state:SHIP_LABEL[stt] });
    }
    stuck.sort((a,b)=>b.age_h-a.age_h);
    returning.sort((a,b)=>(b.stage_h||0)-(a.stage_h||0));
    overdueDeliver.sort((a,b)=>b.over_h-a.over_h);
    const carriers = Object.values(byC).sort((a,b)=>(b.stuck-a.stuck)||(b.returning-a.returning)||(b.total-a.total));
    return { total:(orders||[]).length, state, stuck, returning, overdueDeliver, carriers, shH, labels:SHIP_LABEL };
  }

  // ================= KẾT QUẢ GIAO & ĐVVC (outcomes) =================
  function failReasonOf(o){
    const ci=o.cancel_info||{};
    const txt=(ci.reason_text||ci.comment||'Khác'); const code=ci.reason_code||'';
    return { text:String(txt).trim()||'Khác', code:String(code), stage:ci.main_state||ci.status||'' };
  }
  function buildOutcomes(data, cfg, now){
    now=now||new Date();
    data=data||{};
    const counts=data.countsBySeller||{}, canceled=data.canceled||[], delivered=data.delivered||[];
    // Tổng theo counts (chính xác toàn cục)
    const tot={delivered:0,canceled:0,shipping:0,awaiting_confirmation:0,processing:0};
    Object.values(counts).forEach(s=>{ Object.keys(tot).forEach(k=>{ tot[k]+=((s[k]&&s[k].total_order)||0); }); });
    const finished=tot.delivered+tot.canceled;
    const successRate=finished?tot.delivered/finished:null;
    const failRate=finished?tot.canceled/finished:null;

    // Lý do thất bại (mẫu canceled)
    const reasonMap={}, stageMap={};
    canceled.forEach(o=>{ const r=failReasonOf(o); const key=(r.code?('['+r.code+'] '):'')+r.text;
      reasonMap[key]=(reasonMap[key]||0)+1; if(r.stage) stageMap[r.stage]=(stageMap[r.stage]||0)+1; });
    const reasons=Object.entries(reasonMap).map(([reason,n])=>({reason,n})).sort((a,b)=>b.n-a.n);
    const stages=Object.entries(stageMap).map(([stage,n])=>({stage,n})).sort((a,b)=>b.n-a.n);

    // Deep-dive theo ĐVVC (mẫu delivered vs canceled)
    const byC={}, byW={};
    function cg(map,k){ return map[k]||(map[k]={key:k, delivered:0, failed:0, onTime:0, promisedN:0, leadSum:0, leadN:0}); }
    delivered.forEach(o=>{ const c=o.carrier||'N/A', w=o.warehouse||'N/A';
      [cg(byC,c),cg(byW,w)].forEach(g=>{ g.delivered++;
        const del=parseVN(o.updated_at), cr=parseVN(o.created_at);
        if(o.promised){ const dl=promiseDeadline(o.promised); if(dl&&del){ g.promisedN++; if(del<=dl) g.onTime++; } }
        if(del&&cr){ g.leadSum+=(del-cr)/HOUR; g.leadN++; }
      }); });
    canceled.forEach(o=>{ const c=o.carrier||'N/A', w=o.warehouse||'N/A'; cg(byC,c).failed++; cg(byW,w).failed++; });
    function finalize(map){ return Object.values(map).map(g=>{ const total=g.delivered+g.failed;
      return { key:g.key, total, delivered:g.delivered, failed:g.failed,
        successRate: total?g.delivered/total:null,
        onTimeRate: g.promisedN?g.onTime/g.promisedN:null,
        leadH: g.leadN?Math.round(g.leadSum/g.leadN*10)/10:null };
    }).sort((a,b)=>(b.failed-a.failed)||(b.total-a.total)); }

    return { window:data.window, days:data.days,
      totals:tot, finished, successRate, failRate,
      sampleCanceled:canceled.length, sampleDelivered:delivered.length,
      reasons, stages, byCarrier:finalize(byC), byWarehouse:finalize(byW) };
  }

  const API = { parseVN, hoursBetween, normalize, normalizeAll, summarize, FLAG_LABELS, buildProductivity, buildHourlyBalance, buildPackForecast, buildShipping, buildOutcomes, ymd, firstMilestones, buildCycleStats, buildControlTower, fulfillmentDeadline, buildPackingSLA, buildDeliverySLA, buildAtRisk, buildCapacity, buildFlow, buildInflowForecast, buildFifo, buildCarrierScorecard, buildWbr, isExcluded, buildBrandBreakdown };
  root.BacklogEngine = API;
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
})(typeof self !== 'undefined' ? self : this);
