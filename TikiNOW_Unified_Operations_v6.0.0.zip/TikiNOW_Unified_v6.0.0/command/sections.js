/* =============================================================================
 * TikiNOW Ops Command Center — SECTIONS v2.6
 * "Gộp all tab vụ trên tikinowcenter.tikinow.vn vô 1 extension"
 *
 * API Observer đã tự học mọi endpoint của TikiNOW Center khi bạn mở từng mục.
 * Màn hình này biến đống endpoint đó thành danh mục theo đúng menu của trang,
 * và cho phép nạp TỪNG MỤC cho TẤT CẢ account đang chọn chỉ bằng một nút.
 *
 * Không tự kéo gì. Chỉ chạy khi bạn bấm.
 * ========================================================================== */
(function (root) {
  "use strict";

  const $ = id => document.getElementById(id);
  const esc = s => String(s == null ? "" : s)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  const nfmt = n => Number(n || 0).toLocaleString("vi-VN");

  const STATE = { data: null, openKey: null, rows: null, busy: false };

  function ageText(iso) {
    if (!iso) return "chưa nạp";
    const ms = Date.now() - Date.parse(iso);
    if (!Number.isFinite(ms)) return "chưa nạp";
    const m = Math.floor(ms / 60000);
    if (m < 1) return "vừa xong";
    if (m < 60) return m + "′ trước";
    const h = Math.floor(m / 60);
    if (h < 24) return h + "h trước";
    return Math.floor(h / 24) + "d trước";
  }

  function setStatus(t) { const e = $("secStatus"); if (e) e.textContent = t || ""; }

  /* --------------------------------------------------------------- RENDER */
  function render() {
    const d = STATE.data;
    const box = $("secList");
    if (!box) return;
    if (!d) { box.innerHTML = '<div class="empty">Đang đọc danh mục…</div>'; return; }

    const totalItems = d.sections.reduce((s, x) => s + x.items.length, 0);
    const loaded = d.sections.reduce((s, x) => s + x.items.filter(i => i.rows > 0).length, 0);
    const stats = $("secStats");
    if (stats) stats.innerHTML =
      '<div class="fx-stat"><div class="v">' + d.sections.length + '</div><div class="t">Mục đã học</div></div>' +
      '<div class="fx-stat"><div class="v">' + totalItems + '</div><div class="t">Endpoint có thể nạp</div></div>' +
      '<div class="fx-stat on"><div class="v">' + loaded + '</div><div class="t">Đã có dữ liệu</div></div>' +
      '<div class="fx-stat acc"><div class="v">' + d.accountCount + '</div><div class="t">Account đang chọn</div></div>';

    if (!totalItems) {
      box.innerHTML = '<div class="empty">Chưa học được mục nào.<br><br>' +
        'Mở <b>tikinowcenter.tikinow.vn</b>, bấm lần lượt qua các mục bạn muốn dùng ' +
        '(Đơn hàng, Tồn kho, Thanh toán, Khiếu nại & Bồi thường, Hậu mãi, Sản phẩm…). ' +
        'Extension tự ghi lại endpoint của từng mục, rồi quay lại đây bấm <b>↻ Quét lại</b>.</div>';
      return;
    }

    box.innerHTML = d.sections.map(sec => {
      const rows = sec.items.map(it => {
        const has = it.rows > 0;
        const accTxt = it.accounts.length
          ? it.accounts.length + "/" + d.accountCount + " account"
          : "—";
        return '<tr>' +
          '<td><span class="fx-path" title="' + esc(it.key) + '">' + esc(it.title || it.pathKey) + '</span>' +
            '<br><small class="dh-kind">' + esc(it.method) + " " + esc(it.pathKey) + '</small></td>' +
          '<td><span class="dh-kind">' + esc(it.kind) + '</span></td>' +
          '<td>' + accTxt + '</td>' +
          '<td>' + (has ? nfmt(it.rows) : "—") + '</td>' +
          '<td>' + esc(ageText(it.capturedAt)) + '</td>' +
          '<td class="sec-act">' +
            '<button class="db-go" data-load="' + esc(it.key) + '">' +
              (has ? "↻ Nạp lại" : "⤓ Nạp") + '</button>' +
            (has ? '<button class="ghost db-go" data-view="' + esc(it.key) + '">Xem</button>' : "") +
          '</td>' +
        '</tr>';
      }).join("");
      return '<div class="sec-group"><h4>' + esc(sec.label) +
        ' <span class="sec-count">' + sec.items.length + ' endpoint</span></h4>' +
        '<div class="dh-table-wrap"><table class="dh-table"><thead><tr>' +
        '<th>Mục / endpoint</th><th>Loại</th><th>Account có dữ liệu</th><th>Dòng</th><th>Nạp lúc</th><th></th>' +
        '</tr></thead><tbody>' + rows + '</tbody></table></div></div>';
    }).join("");
  }

  function renderRows() {
    const wrap = $("secRowsWrap");
    const rows = STATE.rows;
    if (!wrap) return;
    if (!rows) { wrap.hidden = true; return; }
    wrap.hidden = false;
    const title = $("secRowsTitle");
    if (title) title.textContent = STATE.openKey + " · " + nfmt(rows.length) + " dòng (gộp mọi account)";
    const body = $("secRows");
    if (!rows.length) {
      body.innerHTML = '<tr><td><div class="empty">Chưa có dòng nào.</div></td></tr>';
      $("secRowsHead").innerHTML = "<tr><th>—</th></tr>";
      return;
    }
    /* Cột: Account trước, rồi các cột có dữ liệu, giới hạn cho dễ đọc. */
    const freq = new Map();
    rows.slice(0, 400).forEach(r => Object.keys(r).forEach(k => {
      if (r[k] !== "" && r[k] != null) freq.set(k, (freq.get(k) || 0) + 1);
    }));
    const lead = ["Account", "SellerID", "Trang"].filter(k => freq.has(k));
    const rest = Array.from(freq.entries())
      .filter(([k]) => lead.indexOf(k) < 0)
      .sort((a, b) => b[1] - a[1]).slice(0, 14).map(([k]) => k);
    const cols = lead.concat(rest);
    $("secRowsHead").innerHTML = "<tr>" + cols.map(c => "<th>" + esc(c) + "</th>").join("") + "</tr>";
    body.innerHTML = rows.slice(0, 500).map(r =>
      "<tr>" + cols.map(c => "<td>" + esc(String(r[c] == null ? "" : r[c]).slice(0, 120)) + "</td>").join("") + "</tr>"
    ).join("");
  }

  /* ---------------------------------------------------------------- LOAD */
  async function refresh() {
    setStatus("Đang đọc danh mục…");
    try {
      STATE.data = await root.TikiDataHub.listSections();
      render();
      setStatus(STATE.data.accountCount
        ? STATE.data.accountCount + " account đang chọn · mỗi lần Nạp sẽ kéo cho tất cả rồi gộp lại"
        : "Chưa có account nào — đăng nhập TikiNOW Center trước");
    } catch (e) { setStatus("Lỗi đọc danh mục: " + e.message); }
  }

  async function loadSection(key) {
    if (STATE.busy) return;
    STATE.busy = true;
    setStatus("Đang nạp " + key + " cho mọi account…");
    try {
      const r = await root.TikiDataHub.syncSection(key);
      const bad = r.perAccount.filter(a => a.error);
      if (root.TNSLShell) root.TNSLShell.toast(
        "Đã nạp " + nfmt(r.rows) + " dòng",
        r.perAccount.map(a => a.account + ": " + nfmt(a.rows)).join(" · ") +
        (bad.length ? " · " + bad.length + " account lỗi" : ""),
        bad.length ? "warn" : "ok");
      await refresh();
      if (STATE.openKey === key) await viewSection(key);
    } catch (e) {
      const msg = e && e.code === "NO_TOKEN"
        ? "Chưa có account nào. Mở TikiNOW Center và đăng nhập trước."
        : (e && e.message) || "lỗi không rõ";
      if (root.TNSLShell) root.TNSLShell.toast("Không nạp được", msg, "err");
      setStatus(msg);
    } finally { STATE.busy = false; }
  }

  async function viewSection(key) {
    STATE.openKey = key;
    setStatus("Đang mở dữ liệu gộp…");
    try {
      STATE.rows = await root.TikiDataHub.sectionRows(key);
      renderRows();
      setStatus(nfmt(STATE.rows.length) + " dòng gộp từ mọi account");
    } catch (e) { setStatus("Lỗi: " + e.message); }
  }

  function toCsv(rows) {
    if (!rows.length) return "";
    const cols = Array.from(rows.reduce((s, r) => { Object.keys(r).forEach(k => s.add(k)); return s; }, new Set()));
    const cell = v => {
      const s = v == null ? "" : String(v);
      return /[",\n;]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
    };
    return [cols.join(",")].concat(rows.map(r => cols.map(c => cell(r[c])).join(","))).join("\n");
  }

  function bind() {
    const list = $("secList");
    if (list) list.addEventListener("click", e => {
      const l = e.target.closest("[data-load]");
      if (l) return loadSection(l.dataset.load);
      const v = e.target.closest("[data-view]");
      if (v) return viewSection(v.dataset.view);
    });
    const r = $("secRescan"); if (r) r.onclick = refresh;
    const o = $("secOpenTiki");
    if (o) o.onclick = () => {
      try { chrome.tabs.create({ url: "https://tikinowcenter.tikinow.vn/", active: true }); }
      catch (_) { window.open("https://tikinowcenter.tikinow.vn/", "_blank", "noreferrer"); }
    };
    const x = $("secExport"); if (x) x.onclick = () => {
      if (!STATE.rows || !STATE.rows.length) return;
      const blob = new Blob(["﻿" + toCsv(STATE.rows)], { type: "text/csv;charset=utf-8" });
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = "TNSL_" + String(STATE.openKey).replace(/[^A-Za-z0-9]+/g, "_").slice(0, 60) + ".csv";
      document.body.appendChild(a); a.click();
      setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500);
    };
    const c = $("secRowsClose"); if (c) c.onclick = () => { STATE.rows = null; STATE.openKey = null; renderRows(); };
  }

  root.TNSLSections = {
    onView: () => { if (!STATE.data) refresh(); else render(); },
    refresh, loadSection
  };

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", bind);
  else bind();
})(self);
