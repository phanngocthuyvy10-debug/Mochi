/* =============================================================
 * TikiNOW Backlog Tracker — CONFIG
 * Chỉnh file này để khai báo account, SLA và ngưỡng aging.
 * ============================================================= */
(function (root) {
  const CONFIG = {
    api: {
      base: 'https://api.tikinow.vn/fulfillment/1.0',
      ordersPath: '/orders',
      countsPath: '/orders/counts',
      perPage: 100,             // đơn / trang khi kéo
      pageConcurrency: 5,       // số trang kéo SONG SONG (1 = tuần tự như bản cũ).
                                // Tăng lên 8 nếu mạng khoẻ; giảm về 2-3 nếu API trả 429.
      maxPagesPerAccount: 500,  // trần AN TOÀN chống vòng lặp vô hạn
      timeoutMs: 20000,         // hết hạn 1 request -> huỷ & thử lại (chống treo)
      retries: 2,               // số lần thử lại khi timeout/5xx/429
      pageDelayMs: 0            // v2.4.1: pool song song đã tự giới hạn tải,
                                // không cần nghỉ giữa các trang nữa. Đặt >0 nếu bị throttle.
    },

    // Cửa sổ ngày ĐẶT HÀNG. Backlog cần thấy cả đơn CŨ (aging cao) nên mặc định TOÀN THỜI GIAN.
    dateRange: {
      mode: 'all',            // 'all' = toàn thời gian | 'days' = N ngày gần đây
      days: 30,               // dùng khi mode='days'
      allTimeFrom: '2020-01-01 00:00:00'
    },

    // seller_id được extension TỰ ĐỘNG bắt khi bạn đăng nhập / switch account.
    // Ở đây chỉ đặt TÊN GỢI NHỚ cho từng seller_id (điền dần sau khi thấy id).
    // Account đã xác nhận: 337145 (operation_tnsl3).
    accountNames: {},

    // Trạng thái coi là BACKLOG để kéo về. Bỏ delivered/canceled cho nhẹ.
    // Chỉ kéo nhóm CẦN ACTION của kho (nhẹ & nhanh). 'shipping' (đang vận chuyển) đã có ở
    // luồng chi tiết (SLA/Cycle) nên bỏ khỏi đây để tránh kéo hàng nghìn đơn all-time gây treo.
    backlogStatuses: ['awaiting_confirmation', 'processing'],

    // SLA theo GIỜ — chỉnh theo chuẩn vận hành của bạn.
    sla: {
      confirm_h: 4,     // chờ xác nhận > ngưỡng = trễ
      processing_h: 24, // khâu xử lý (pick/pack) > ngưỡng = trễ
      handover_h: 12,   // đóng gói xong -> bàn giao ĐVVC > ngưỡng = trễ bàn giao
      shipping_h: 72    // đã giao ĐVVC nhưng còn lăn bánh > ngưỡng = kẹt
    },

    agingBuckets: [
      { key: 'lt24',   label: '< 24h',  min: 0,  max: 24 },
      { key: 'h24_48', label: '24–48h', min: 24, max: 48 },
      { key: 'h48_72', label: '48–72h', min: 48, max: 72 },
      { key: 'gt72',   label: '> 72h',  min: 72, max: Infinity }
    ],

    // ------- Tab NĂNG SUẤT KHO -------
    productivity: {
      windowDays: 3,               // số ngày gần đây để đo (nhẹ hơn cho account lớn)
      statuses: ['awaiting_confirmation','processing','shipping','delivered'], // gồm cả delivered để đo output
      activeHours: [6, 22],        // khung giờ đánh giá năng suất (bỏ ca đêm khi tính low-perf)
      lowPerfMode: 'median',       // 'median' = thấp so với median | 'target' = thấp hơn ngưỡng cố định
      lowPerfRatio: 0.5,           // (mode median) giờ low nếu < 50% median throughput
      targetPerHour: 30            // (mode target) throughput tối thiểu / giờ
    },

    // ------- FLOW & NGHẼN (dòng chảy khâu + dự báo bàn giao) -------
    flow: {
      packCapacityPerHour: 120,     // năng lực đóng gói/xuất (đơn/giờ) toàn hệ — chỉnh theo thực tế
      useDispatchRate: true,        // ưu tiên nhịp XUẤT thực đo (dispatched/giờ) nếu có
      forecastHours: 12,            // dự báo dồn bàn giao trong N giờ tới
      defaultPickMin: 20, defaultPackMin: 6, defaultHandoverMin: 8, // fallback nếu chưa có cycle-time
      congestThreshold: 150,        // WIP 1 khâu vượt ngưỡng này -> cảnh báo nghẽn
      stages: [
        { key:'wait_pick', label:'Chờ lấy',      subs:['ready_for_pickup','awaiting_confirmation','awaiting_order_verification','order_verified','waiting_confirm',''] },
        { key:'picking',   label:'Đang lấy',      subs:['picking'] },
        { key:'packing',   label:'Đang đóng gói', subs:['packing'] },
        { key:'packed',    label:'Chờ bàn giao',  subs:['packed','ready_to_handover','handover_to_carrier'] }
      ]
    },

    // ------- SẮP TRỄ (at-risk) + TẢI vs NĂNG LỰC -------
    atRisk: {
      packWindows:     { critical: 30, warning: 60, watch: 120 },   // phút tới hạn ĐÓNG GÓI
      deliverWindows:  { critical: 360, warning: 1440, watch: 2880 } // phút tới hạn GIAO
    },
    capacity: {
      perHourPerWh: 40,   // năng lực xử lý ước tính (đơn/giờ/kho) — chỉnh theo thực tế; auto lấy median throughput nếu có
      useProdMedian: true // ưu tiên throughput median thực đo từ tab Năng suất
    },

    // ------- CẢNH BÁO Zalo/Slack (call-out P1) -------
    alerting: {
      webhookUrl: '',        // dán Incoming Webhook (Slack) hoặc endpoint nhận JSON {text}
      type: 'slack',         // 'slack' | 'generic'
      minSeverity: 'P1',     // chỉ bắn từ mức này trở lên
      autoEveryMin: 0        // >0 = tự bắn định kỳ khi dashboard đang mở (vd 30)
    },

    // ------- SLA ĐÓNG GÓI (Fulfillment) + SLA VẬN CHUYỂN -------
    slaFulfillment: {
      kpiTarget: 0.96,           // KPI cam kết 96%
      holidays: [],              // 'YYYY-MM-DD' — CN tự động loại; thêm lễ ở đây
      // Bảng cutoff theo kênh: mỗi bucket {toHour (giờ tạo < toHour), dayOffset (working days), h (giờ hạn)}
      channels: {
        'Lazada':      [ { toHour:14, dayOffset:0, h:19 }, { toHour:20, dayOffset:1, h:13 }, { toHour:24, dayOffset:1, h:19 } ],
        'Shopee':      [ { toHour:16, dayOffset:0, h:20 }, { toHour:24, dayOffset:1, h:11 } ],
        'TikTok Shop': [ { toHour:18, dayOffset:0, h:20 }, { toHour:24, dayOffset:1, h:11 } ],
        '_default':    [ { toHour:13, dayOffset:0, h:19 }, { toHour:19, dayOffset:1, h:13 }, { toHour:24, dayOffset:1, h:19 } ]
      }
    },
    slaDelivery: {
      kpiTarget: 0.95            // dùng delivery.promised_delivery_date của TikiNOW
    },

    // Loại trừ SLA hợp lệ (lỗi không do TKN) -> KPI net công bằng
    slaExclusions: {
      enabled: true,
      peakDays: [],        // 'YYYY-MM-DD' megasale/SBD vượt baseline
      manualCodes: []      // order_code được miễn trừ (API chậm/thiếu tem do sàn/handover trễ ĐVVC...)
    },

    // ------- CONTROL TOWER (call-out cảnh báo có ưu tiên) -------
    controlTower: {
      thresholds: {
        no_label: 20,             // > N đơn chưa có nhãn VC  -> P1
        handover_overdue: 20,     // > N đơn chưa bàn giao quá SLA -> P1
        shipping_stuck: 15,       // > N đơn kẹt vận chuyển -> P2
        aging_gt72: 30,           // > N đơn > 72h -> P2
        issue_return: 15,         // > N đơn lỗi/hoàn -> P2
        backlog_per_wh: 200,      // 1 kho > N backlog -> P2
        prod_low_hours_today: 3,  // >= N giờ low hôm nay -> P2
        cycle_sla_pct: 0.8,       // % đạt SLA dwell < 80% -> P1
        cycle_stage_min: 60,      // 1 khâu median > 60' -> P2 (chỉ đích danh khâu)
        sla_pack_overdue: 10,     // > N đơn quá hạn đóng gói chưa xong -> P1
        sla_deliver_overdue: 10   // > N đơn quá hạn giao chưa xong -> P2
      },
      // Ngưỡng màu sức khoẻ theo kho (số đơn backlog)
      whHealth: { green: 50, amber: 150 } // <=50 xanh, <=150 vàng, >150 đỏ
    },

    // ------- Tab CYCLE-TIME (đo từ lúc tạo, dùng histories chi tiết) -------
    cycle: {
      windowDays: 3,                          // đơn BÀN GIAO trong N ngày gần nhất
      sourceStatuses: ['shipping','delivered'], // đơn đã rời kho (có mốc bàn giao)
      maxOrders: 1500,                        // trần số đơn kéo detail / lần (bảo vệ)
      concurrency: 6,                         // số request detail song song
      dwellTargetH: 24,                       // SLA: tạo -> bàn giao <= ngưỡng này
      // Thứ tự mốc + mã sub_status tương ứng ('@created' = order.created_at)
      milestones: [
        { key:'created',  label:'Tiếp nhận',     code:'@created' },
        { key:'ready',    label:'Sẵn sàng lấy',  code:'ready_for_pickup' },
        { key:'picking',  label:'Bắt đầu lấy',   code:'picking' },
        { key:'packing',  label:'Bắt đầu đóng',  code:'packing' },
        { key:'packed',   label:'Đóng xong',     code:'packed' },
        { key:'handover', label:'Bàn giao ĐVVC', code:'handover_to_3pl' }
      ],
      // Khâu = khoảng giữa 2 mốc liên tiếp
      stages: [
        { key:'wait_ready',    from:'created',  to:'ready',    label:'Chờ sẵn sàng' },
        { key:'wait_pick',     from:'ready',    to:'picking',  label:'Chờ lấy hàng' },
        { key:'pick',          from:'picking',  to:'packing',  label:'Lấy hàng' },
        { key:'pack',          from:'packing',  to:'packed',   label:'Đóng gói' },
        { key:'handover_wait', from:'packed',   to:'handover', label:'Chờ bàn giao' }
      ]
    },

    // Map sub_status (mã máy -> nhãn VN + nhóm khâu). Mã lạ sẽ hiện nguyên bản.
    subStatusMap: {
      awaiting_confirmation: { label: 'Chờ TikiNOW xác nhận',    stage: 'confirm' },
      waiting_confirm:       { label: 'Chờ xác nhận',            stage: 'confirm' },
      ready_for_pickup:      { label: 'Sẵn sàng lấy hàng',       stage: 'process' },
      picking:               { label: 'Đang lấy hàng',           stage: 'process' },
      packing:               { label: 'Đang đóng gói',           stage: 'process' },
      packed:                { label: 'Đóng gói xong',           stage: 'handover' },
      ready_to_handover:     { label: 'Chờ bàn giao ĐVVC',       stage: 'handover' },
      handover_to_carrier:   { label: 'Bàn giao cho ĐVVC',       stage: 'handover' },
      picked_up:             { label: 'ĐVVC lấy hàng thành công', stage: 'shipping' },
      in_transit:            { label: 'Đang trung chuyển',       stage: 'shipping' },
      out_for_delivery:      { label: 'Đang trên đường giao',    stage: 'shipping' },
      delivered:             { label: 'Đã giao',                 stage: 'done' },
      returned:              { label: 'Hoàn hàng',               stage: 'issue' },
      return_processing:     { label: 'Đang xử lý hoàn',         stage: 'issue' }
    }
  };
  if (root.TNSL_CONFIG_OVERRIDE) {
    const o = root.TNSL_CONFIG_OVERRIDE;
    if (o.accountNames) Object.assign(CONFIG.accountNames, o.accountNames);
    if (o.controlTowerThresholds) Object.assign(CONFIG.controlTower.thresholds, o.controlTowerThresholds);
  }
  root.TNSL_CONFIG = CONFIG;
  if (typeof module !== 'undefined' && module.exports) module.exports = CONFIG;
})(typeof self !== 'undefined' ? self : this);
