/* =============================================================
 * Collector — kéo đơn backlog từ API cho từng seller_id đã có token.
 * Chạy trong dashboard (extension origin) nên host_permissions
 * cho phép fetch cross-origin, bỏ qua CORS.
 * ============================================================= */
(function (root) {
  const CFG = root.TNSL_CONFIG;

  function fmtDate(d) {
    const p = n => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${p(d.getMonth()+1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
  }

  // Cửa sổ ngày đặt hàng theo config.dateRange
  function computeWindow() {
    const now = new Date();
    const to = fmtDate(new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59));
    const dr = CFG.dateRange || { mode: 'all', allTimeFrom: '2020-01-01 00:00:00' };
    let from;
    if (dr.mode === 'days') {
      const d = new Date(now.getTime() - (dr.days || 30) * 86400000);
      from = fmtDate(new Date(d.getFullYear(), d.getMonth(), d.getDate(), 0, 0, 0));
    } else {
      from = dr.allTimeFrom || '2020-01-01 00:00:00';
    }
    return { from, to };
  }

  function buildQuery({ sellerId, status, page, from, to }) {
    const p = new URLSearchParams();
    p.set('filters.created_at.from', from);
    p.set('filters.created_at.to', to);
    p.set('filters.seller_id', sellerId);
    p.set('page.page_number', page);
    p.set('page.per_page', CFG.api.perPage);
    if (status) p.set('filters.status', status);
    p.set('filters.extra.is_tnsl_order', 'true');
    p.set('sort_by', 'created_at|desc');
    p.set('seller_id', sellerId);
    return p.toString();
  }

  function sleep(ms){ return new Promise(r=>setTimeout(r, ms)); }

  /* v2.4.1 — GIỚI HẠN SONG SONG TOÀN CỤC.
     Không có nó thì `pageConcurrency=5` × 2 status = 10 request cùng lúc, và nếu
     sau này thêm status nữa thì con số tự phình — dễ ăn 429. Semaphore này khiến
     pageConcurrency có nghĩa đúng như tên: TỔNG số request đang bay tới Tiki. */
  const gate = { limit: 5, active: 0, queue: [] };
  function gateLimit() {
    const n = Number(CFG.api && CFG.api.pageConcurrency);
    return Math.max(1, Math.min(12, Number.isFinite(n) && n > 0 ? n : 5));
  }
  function acquire() {
    gate.limit = gateLimit();
    if (gate.active < gate.limit) { gate.active++; return Promise.resolve(); }
    return new Promise(res => gate.queue.push(res));
  }
  function release() {
    const next = gate.queue.shift();
    if (next) next(); else gate.active = Math.max(0, gate.active - 1);
  }

  async function apiGet(path, query, token) {
    await acquire();
    try { return await apiGetInner(path, query, token); }
    finally { release(); }
  }

  async function apiGetInner(path, query, token) {
    const url = `${CFG.api.base}${path}?${query}`;
    const retries = CFG.api.retries != null ? CFG.api.retries : 2;
    let lastErr;
    for (let attempt = 0; attempt <= retries; attempt++) {
      const ctl = new AbortController();
      const t = setTimeout(() => ctl.abort(), CFG.api.timeoutMs || 20000);
      try {
        const res = await fetch(url, { headers: { Authorization: token }, signal: ctl.signal });
        clearTimeout(t);
        if (res.status === 401) { const e = new Error('TOKEN_EXPIRED'); e.code = 401; throw e; }
        if (res.status === 429 || res.status >= 500) { lastErr = new Error('HTTP ' + res.status); await sleep(600 * (attempt + 1)); continue; }
        if (!res.ok) throw new Error('HTTP ' + res.status);
        return await res.json();
      } catch (e) {
        clearTimeout(t);
        if (e.code === 401) throw e;
        lastErr = e;
        await sleep(400 * (attempt + 1)); // timeout/mạng -> thử lại
      }
    }
    throw lastErr || new Error('request failed');
  }

  function extractOrders(json) {
    if (!json || !json.data) return [];
    const d = json.data;
    if (Array.isArray(d)) return d;
    return Object.keys(d).filter(k => /^\d+$/.test(k)).map(k => d[k]); // {"0":{...}}
  }

  // Lấy promised delivery theo nhiều shape API khác nhau. List endpoint và detail endpoint
  // không phải lúc nào cũng trả cùng cấu trúc, nên không được chỉ phụ thuộc delivery.promised_delivery_date.
  function promisedOf(o) {
    if (!o) return null;
    const d = o.delivery || {};
    const e = o.extra || {};
    return d.promised_delivery_date || d.promised_delivery_at || d.estimated_delivery_date || d.estimated_delivery_at ||
      o.promised_delivery_date || o.promised_delivery_at || o.estimated_delivery_date || o.estimated_delivery_at ||
      e.promised_delivery_date || e.promised_delivery_at || e.estimated_delivery_date || e.estimated_delivery_at || null;
  }

  // Kéo trang cho 1 status của 1 seller. maxItems>0 = dừng sớm khi đủ (đơn sort mới nhất trước).
  /* =========================================================================
   * v2.4.1 — PHÂN TRANG SONG SONG
   *
   * Bản cũ kéo tuần tự: trang 1 xong mới gọi trang 2, cộng thêm 60ms nghỉ mỗi
   * trang. Với 10.000 đơn backlog = 100 trang × (~600ms + 60ms) ≈ 66 giây cho
   * MỘT status, và các status lại chạy nối tiếp. Đó là toàn bộ lý do kéo lâu.
   *
   * Bản này gọi trang 1 để biết tổng số trang (ưu tiên paging.total_page của
   * API, không đoán theo độ dài batch), rồi kéo phần còn lại bằng pool song
   * song. Cùng lượng dữ liệu, cùng số request — chỉ khác là không xếp hàng.
   * ====================================================================== */
  function pagingOf(json) {
    return (json && (json.paging || json.pagination)) || {};
  }

  async function pullStatus(sellerId, token, status, from, to, onProgress, maxItems) {
    const perPage = Number(CFG.api.perPage) || 100;
    const maxPages = Number(CFG.api.maxPagesPerAccount) || 500;
    const conc = Math.max(1, Math.min(10, Number(CFG.api.pageConcurrency) || 5));
    const getPage = p => apiGet(CFG.api.ordersPath, buildQuery({ sellerId, status, page: p, from, to }), token);

    let first;
    try { first = await getPage(1); }
    catch (e) { if (e.code === 401) throw e; return { orders: [], truncated: true }; }

    const firstBatch = extractOrders(first);
    const all = firstBatch.slice();
    if (onProgress) onProgress(sellerId, status, all.length);

    const pg = pagingOf(first);
    const totalPageApi = Number(pg.total_page || pg.total_pages || 0);
    const totalApi = Number(pg.total || pg.total_order || 0);
    /* Ưu tiên total_page do API trả. Chỉ khi API không cho biết mới suy ra từ
       độ dài batch — cách suy luận đó sai nếu server tự giới hạn per_page. */
    let lastPage = totalPageApi > 0
      ? totalPageApi
      : (totalApi > 0 ? Math.ceil(totalApi / perPage)
                      : (firstBatch.length >= perPage ? maxPages : 1));

    if (maxItems && all.length >= maxItems) return { orders: all, truncated: false };
    if (maxItems) lastPage = Math.min(lastPage, Math.ceil(maxItems / perPage));

    let truncated = false;
    if (lastPage > maxPages) { lastPage = maxPages; truncated = true; }
    if (lastPage <= 1) return { orders: all, truncated };

    const pages = [];
    for (let p = 2; p <= lastPage; p++) pages.push(p);

    /* API không cho biết tổng số trang -> không được bắn mù N trang song song.
       Quay về tuần tự và dừng ngay khi gặp trang ngắn. */
    if (totalPageApi <= 0 && totalApi <= 0) {
      for (const p of pages) {
        let json;
        try { json = await getPage(p); }
        catch (e) { if (e.code === 401) throw e; truncated = true; break; }
        const batch = extractOrders(json);
        all.push(...batch);
        if (onProgress) onProgress(sellerId, status, all.length);
        if (batch.length < perPage) break;
        if (maxItems && all.length >= maxItems) break;
      }
      return { orders: all, truncated };
    }

    const buckets = new Map();
    await runPool(pages, conc, async p => {
      try {
        const json = await getPage(p);
        buckets.set(p, extractOrders(json));
      } catch (e) {
        if (e.code === 401) throw e;
        truncated = true;
      }
      if (onProgress) {
        let n = all.length;
        buckets.forEach(b => { n += b.length; });
        onProgress(sellerId, status, n);
      }
    });

    /* Ghép theo đúng thứ tự trang để dữ liệu không bị xáo. */
    for (let p = 2; p <= lastPage; p++) {
      const b = buckets.get(p);
      if (b) all.push(...b);
    }
    return { orders: all, truncated };
  }

  async function pullCounts(sellerId, token, from, to) {
    const q = buildQuery({ sellerId, page: 1, from, to });
    const json = await apiGet(CFG.api.countsPath, q, token);
    return (json && json.data && json.data.statuses) || {};
  }

  // Kéo backlog cho tất cả seller có token.
  async function collectAll(tokens, opts) {
    opts = opts || {};
    const win = computeWindow();
    const rawBySeller = {}, counts = {}, errors = {}, expected = {}, pulled = {}, truncated = {}, timing = {};

    for (const sellerId of Object.keys(tokens || {})) {
      const token = tokens[sellerId].token;
      rawBySeller[sellerId] = [];
      try {
        const st = await pullCounts(sellerId, token, win.from, win.to);
        counts[sellerId] = st;
        // kỳ vọng = tổng các trạng thái backlog theo counts
        expected[sellerId] = CFG.backlogStatuses.reduce((sum, s) => sum + ((st[s] && st[s].total_order) || 0), 0);

        /* v2.4.1: các status backlog chạy SONG SONG. Chúng độc lập nhau,
           không có lý do gì phải xếp hàng chờ nhau. */
        const t0 = Date.now();
        const results = await Promise.all(CFG.backlogStatuses.map(status =>
          pullStatus(sellerId, token, status, win.from, win.to, opts.onProgress)
            .catch(e => { if (e && e.code === 401) throw e; return { orders: [], truncated: true }; })
        ));
        let trunc = false;
        results.forEach(r => {
          rawBySeller[sellerId] = rawBySeller[sellerId].concat(r.orders);
          if (r.truncated) trunc = true;
        });
        pulled[sellerId] = rawBySeller[sellerId].length;
        truncated[sellerId] = trunc;
        timing[sellerId] = { ms: Date.now() - t0, orders: pulled[sellerId] };
      } catch (e) {
        errors[sellerId] = e.code === 401 ? 'Token hết hạn — mở lại TikiNOW / switch account' : e.message;
      }
    }
    return { rawBySeller, counts, errors, expected, pulled, truncated, timing, window: win };
  }

  // Kéo dữ liệu cho tab NĂNG SUẤT (gồm cả delivered, cửa sổ ngắn).
  async function collectProductivity(tokens, opts) {
    opts = opts || {};
    const P = CFG.productivity || { windowDays: 7 };
    const now = new Date();
    const to = fmtDate(new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59));
    const fromD = new Date(now.getTime() - (P.windowDays || 7) * 86400000);
    const from = fmtDate(new Date(fromD.getFullYear(), fromD.getMonth(), fromD.getDate(), 0, 0, 0));
    const statuses = P.statuses || ['awaiting_confirmation','processing','shipping','delivered'];
    const rawBySeller = {}, errors = {};
    for (const sid of Object.keys(tokens || {})) {
      const token = tokens[sid].token; rawBySeller[sid] = [];
      try {
        for (const st of statuses) {
          const r = await pullStatus(sid, token, st, from, to, opts.onProgress);
          rawBySeller[sid] = rawBySeller[sid].concat(r.orders);
        }
      } catch (e) { errors[sid] = e.code === 401 ? 'Token hết hạn — mở lại TikiNOW' : e.message; }
    }
    return { rawBySeller, errors, window: { from, to } };
  }

  // ---- CYCLE-TIME: kéo detail histories cho đơn đã rời kho ----
  async function fetchDetail(orderCode, sellerId, token) {
    const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), CFG.api.timeoutMs || 20000);
    try {
      const res = await fetch(`${CFG.api.base}${CFG.api.ordersPath}/${orderCode}?seller_id=${sellerId}`, { headers: { Authorization: token }, signal: ctl.signal });
      clearTimeout(t);
      if (res.status === 401) { const e = new Error('TOKEN_EXPIRED'); e.code = 401; throw e; }
      if (!res.ok) throw new Error('HTTP ' + res.status);
      return await res.json();
    } catch (e) { clearTimeout(t); throw e; }
  }

  async function loadCache() {
    try { if (typeof chrome !== 'undefined' && chrome.storage) { const { cycleCache = {} } = await chrome.storage.local.get('cycleCache'); return cycleCache; } } catch (e) {}
    return {};
  }
  async function saveCache(cache) {
    try { if (typeof chrome !== 'undefined' && chrome.storage) await chrome.storage.local.set({ cycleCache: cache }); } catch (e) {}
  }

  // pool chạy song song có giới hạn
  async function runPool(items, limit, worker, onEach) {
    const q = items.slice(); let active = 0, done = 0;
    return new Promise((resolve) => {
      const next = () => {
        if (!q.length && active === 0) return resolve();
        while (active < limit && q.length) {
          const it = q.shift(); active++;
          Promise.resolve(worker(it)).catch(() => null).then(() => { active--; done++; if (onEach) onEach(done); next(); });
        }
      };
      next();
    });
  }

  async function collectCycleTimes(tokens, opts) {
    opts = opts || {};
    const CY = CFG.cycle;
    const now = new Date();
    const to = fmtDate(new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59));
    const fromD = new Date(now.getTime() - (CY.windowDays || 3) * 86400000);
    const from = fmtDate(new Date(fromD.getFullYear(), fromD.getMonth(), fromD.getDate(), 0, 0, 0));

    const cache = await loadCache();
    const orders = [], errors = {};
    // 1) lấy danh sách order_code trong cửa sổ (đã rời kho)
    for (const sid of Object.keys(tokens || {})) {
      const token = tokens[sid].token;
      try {
        let base = [];
        for (const st of (CY.sourceStatuses || ['shipping','delivered'])) {
          const r = await pullStatus(sid, token, st, from, to, opts.onProgress, CY.maxOrders || 1500);
          base = base.concat(r.orders.map(o => ({ order_code: o.order_code, ref_code: o.ref_code, created_at: o.created_at, warehouse: o.warehouse, fulfillment_type: o.fulfillment_type, sid })));
        }
        // mới nhất trước, cắt trần
        base.sort((a, b) => (a.created_at < b.created_at ? 1 : -1));
        base = base.slice(0, CY.maxOrders || 1500);
        // 2) fetch detail (cache) lấy milestones.
        //    CHỈ cache đơn ĐÃ XONG (có mốc bàn giao/đã giao). Đơn còn dở -> kéo lại lần sau để cập nhật.
        const toFetch = base.filter(o => { const c = cache[o.order_code]; return !c || !c.done; });
        if (opts.onPhase) opts.onPhase(`Account ${sid}: ${base.length} đơn, cần kéo chi tiết ${toFetch.length}`);
        await runPool(toFetch, CY.concurrency || 6, async (o) => {
          const d = await fetchDetail(o.order_code, sid, token);
          const ms = (root.BacklogEngine ? root.BacklogEngine.firstMilestones(d.histories) : {});
          const done = (d.status === 'delivered') || Object.keys(ms).some(k => /handover|picked_up|delivered|logi_successful/i.test(k));
          cache[o.order_code] = {
            ms, done,
            created_at: d.created_at || o.created_at,
            fulfillment_type: d.fulfillment_type || o.fulfillment_type || null,
            ref_code: d.ref_code || o.ref_code || null,
            warehouse: (d.warehouse && (d.warehouse.name||d.warehouse.code)) || o.warehouse,
            platform: (d.extra && d.extra.platform) || null,
            promised: promisedOf(d),
            carrier: (d.extra && (d.extra.delivery_partner||d.extra.partner)) || (d.delivery && d.delivery.tracking && d.delivery.tracking.delivered_by) || null,
            _at: Date.now()
          };
        }, (n) => { if (opts.onDetailProgress) opts.onDetailProgress(sid, n, toFetch.length); });
        // 3) build danh sách cuối
        for (const o of base) {
          const c = cache[o.order_code];
          if (c) orders.push({ order_code: o.order_code, ref_code: c.ref_code, created_at: c.created_at, warehouse: c.warehouse, fulfillment_type: c.fulfillment_type || o.fulfillment_type || null, ms: c.ms, platform: c.platform, promised: c.promised, carrier: c.carrier });
        }
      } catch (e) {
        errors[sid] = e.code === 401 ? 'Token hết hạn — mở lại TikiNOW' : e.message;
      }
    }
    // Giới hạn cache (giữ ~8000 đơn mới nhất theo thời điểm cache) tránh phình storage.
    const CAP = (CY.cacheCap || 8000);
    let keys = Object.keys(cache);
    if (keys.length > CAP) {
      keys.sort((a,b)=>((cache[b]._at||0)-(cache[a]._at||0)));
      const pruned = {}; keys.slice(0, CAP).forEach(k => pruned[k] = cache[k]);
      for (const k in cache) delete cache[k];
      Object.assign(cache, pruned);
    }
    await saveCache(cache);
    return { orders, errors, window: { from, to }, cacheSize: Object.keys(cache).length };
  }
  async function clearCycleCache(){
    try { if (typeof chrome !== 'undefined' && chrome.storage) await chrome.storage.local.set({ cycleCache: {} }); } catch (e) {}
    return true;
  }

  /* =============================================================
   * PHIẾU RÚT HÀNG (return-shipments) -> data cho xuất Excel
   * Kéo toàn bộ phiếu rút hàng + chi tiết (items: SKU, GC, grade) cho mọi
   * account có token; enrich tên/mã SP qua base-info. Chạy trong dashboard.
   * ============================================================= */
  const RS_LIST_PATH = '/return-shipments';                 // dưới CFG.api.base (fulfillment/1.0)
  const RS_BASEINFO_URL = 'https://api.tikinow.vn/business/v1/product/base-info';

  function rsListQuery(sellerId, page, o) {
    const p = new URLSearchParams();
    p.set('filters.seller_id', sellerId);
    p.set('seller_id', sellerId);
    p.set('page.page_number', page);
    p.set('page.page_size', 10);        // endpoint cố định 10/trang; vẫn phân trang theo total_page
    if (o && o.status) p.set('filters.status', o.status);
    if (o && o.from && o.to) {
      const field = o.dateField === 'updated_at' ? 'updated_at' : 'created_at';
      p.set('filters.' + field + '.from', o.from);
      p.set('filters.' + field + '.to', o.to);
    }
    return p.toString();
  }

  // Cửa sổ ngày cho phiếu rút hàng: days<=0 => toàn thời gian.
  function rsWindow(days) {
    const now = new Date();
    const to = fmtDate(now);
    if (!days || days <= 0) return { from: '', to: '' };
    const d = new Date(now.getTime() - days * 86400000);
    const from = fmtDate(new Date(d.getFullYear(), d.getMonth(), d.getDate(), 0, 0, 0));
    return { from, to };
  }

  // POST base-info (khác base, có retry + xử lý 401)
  async function rsPost(url, token, body) {
    const retries = CFG.api.retries != null ? CFG.api.retries : 2;
    let lastErr;
    for (let attempt = 0; attempt <= retries; attempt++) {
      const ctl = new AbortController();
      const t = setTimeout(() => ctl.abort(), CFG.api.timeoutMs || 20000);
      try {
        const res = await fetch(url, { method: 'POST', headers: { Authorization: token, 'Content-Type': 'application/json' }, body: JSON.stringify(body), signal: ctl.signal });
        clearTimeout(t);
        if (res.status === 401) { const e = new Error('TOKEN_EXPIRED'); e.code = 401; throw e; }
        if (res.status === 429 || res.status >= 500) { lastErr = new Error('HTTP ' + res.status); await sleep(600 * (attempt + 1)); continue; }
        if (!res.ok) throw new Error('HTTP ' + res.status);
        return await res.json();
      } catch (e) { clearTimeout(t); if (e.code === 401) throw e; lastErr = e; await sleep(400 * (attempt + 1)); }
    }
    throw lastErr || new Error('request failed');
  }

  function chunk(arr, n) { const out = []; for (let i = 0; i < arr.length; i += n) out.push(arr.slice(i, i + n)); return out; }

  // Kéo phiếu rút hàng cho tất cả seller có token.
  // opts: { days=30, dateField='created_at', status?, maxShipments=3000, onProgress?(sid,msg) }
  async function collectReturnShipments(tokens, opts) {
    opts = opts || {};
    const days = opts.days != null ? opts.days : 30;
    const win = rsWindow(days);
    const qbase = { status: opts.status || '', dateField: opts.dateField || 'created_at', from: win.from, to: win.to };
    const cap = opts.maxShipments != null ? opts.maxShipments : 3000;
    const shipments = [], detailsById = {}, skuMap = {}, errors = {};
    let capped = false, grandTotal = 0;
    const prog = (sid, msg) => { if (opts.onProgress) opts.onProgress(sid, msg); };

    for (const sid of Object.keys(tokens || {})) {
      const token = tokens[sid].token;
      try {
        // 1) danh sách (phân trang, trong cửa sổ ngày, có cap)
        prog(sid, 'lấy danh sách phiếu…');
        const first = await apiGet(RS_LIST_PATH, rsListQuery(sid, 1, qbase), token);
        const paging = (first && first.paging) || {};
        const totalPage = paging.total_page || 1;
        grandTotal += (paging.total || 0);
        let list = extractOrders(first);
        for (let pg = 2; pg <= totalPage && pg <= (CFG.api.maxPagesPerAccount || 500); pg++) {
          if (shipments.length + list.length >= cap) { capped = true; break; }
          prog(sid, `danh sách phiếu: trang ${pg}/${totalPage}`);
          const j = await apiGet(RS_LIST_PATH, rsListQuery(sid, pg, qbase), token);
          list = list.concat(extractOrders(j));
          if (CFG.api.pageDelayMs) await sleep(CFG.api.pageDelayMs);
        }
        // cắt theo cap toàn cục
        if (shipments.length + list.length > cap) { list = list.slice(0, Math.max(0, cap - shipments.length)); capped = true; }
        list.forEach(s => { s.__sid = sid; shipments.push(s); });

        // 2) chi tiết từng phiếu (song song)
        prog(sid, `lấy chi tiết ${list.length} phiếu…`);
        let done = 0;
        await runPool(list, CFG.cycle && CFG.cycle.concurrency || 6, async (s) => {
          const j = await apiGet(RS_LIST_PATH + '/' + s.shipment_id, 'seller_id=' + sid, token);
          detailsById[s.shipment_id] = (j && j.data) || j;
        }, () => { done++; if (done % 5 === 0) prog(sid, `chi tiết phiếu: ${done}/${list.length}`); });

        // 3) gom SKU -> tra cứu tên/mã SP
        const skuSet = new Set();
        list.forEach(s => { const d = detailsById[s.shipment_id]; if (d && d.items) d.items.forEach(it => { if (it.sku) skuSet.add(String(it.sku)); }); });
        const skus = [...skuSet].filter(k => skuMap[k] === undefined);
        const batches = chunk(skus, 100);
        for (let b = 0; b < batches.length; b++) {
          prog(sid, `tra cứu tên SP: nhóm ${b + 1}/${batches.length}`);
          try {
            const j = await rsPost(RS_BASEINFO_URL, token, { skus: batches[b], seller_id: Number(sid) });
            const arr = Array.isArray(j) ? j : (j && j.data) || [];
            arr.forEach(p => { if (p && p.sku != null) skuMap[String(p.sku)] = { name: p.name || '', code: p.seller_product_code || '', master_sku: p.master_sku || '' }; });
          } catch (e) { if (e.code === 401) throw e; /* bỏ qua nhóm lỗi */ }
        }
      } catch (e) {
        errors[sid] = e.code === 401 ? 'Token hết hạn — mở lại TikiNOW / switch account' : e.message;
      }
      if (capped) break;
    }
    return { shipments, detailsById, skuMap, errors, capped, cap, grandTotal, window: win };
  }

  // ---- VẬN CHUYỂN & HOÀN: kéo đơn đang shipping (list-only) cho mọi account ----
  async function collectShipping(tokens, opts){
    opts = opts || {};
    const cap = opts.maxOrders || 5000;
    const statuses = opts.statuses || ['shipping'];
    const orders = [], errors = {};
    const prog = (sid, msg) => { if (opts.onProgress) opts.onProgress(sid, msg); };
    for (const sid of Object.keys(tokens || {})) {
      const token = tokens[sid].token;
      try {
        const sellerOrders = [];
        for (const status of statuses) {
          let page = 1;
          while (true) {
            if (orders.length + sellerOrders.length >= cap) break;
            const q = new URLSearchParams();
            q.set('filters.seller_id', sid); q.set('seller_id', sid);
            q.set('filters.status', status);
            q.set('filters.extra.is_tnsl_order', 'true');
            q.set('page.page_number', page); q.set('page.per_page', CFG.api.perPage);
            q.set('sort_by', 'updated_at|desc');
            const j = await apiGet(CFG.api.ordersPath, q.toString(), token);
            const batch = extractOrders(j);
            batch.forEach(o => sellerOrders.push({
              order_code: o.order_code, ref_code: o.ref_code, status: o.status, sub_status: o.sub_status,
              fulfillment_type: o.fulfillment_type,
              carrier: (o.extra && (o.extra.delivery_partner || o.extra.partner)) ||
                (o.delivery && o.delivery.tracking && o.delivery.tracking.delivered_by) || null,
              warehouse: (o.warehouse && (o.warehouse.name || o.warehouse.code)) || o.warehouse || null,
              created_at: o.created_at, updated_at: o.updated_at,
              promised: promisedOf(o), sid
            }));
            prog(sid, `${status}: ${orders.length + sellerOrders.length} đơn`);
            if (batch.length < CFG.api.perPage) break;
            page++;
            if (page > (CFG.api.maxPagesPerAccount || 500)) break;
            if (CFG.api.pageDelayMs) await sleep(CFG.api.pageDelayMs);
          }
        }

        // Một số response LIST không trả promised_delivery_date. Khi đó chỉ enrich các đơn
        // đang thiếu field bằng DETAIL endpoint để bảng quá hạn/sắp trễ không bị trắng.
        const missing = sellerOrders.filter(o => !o.promised && o.order_code);
        if (missing.length && opts.enrichMissingPromised !== false) {
          prog(sid, `bổ sung hạn giao: ${missing.length} đơn thiếu promised…`);
          const byCode = new Map(sellerOrders.map(o => [String(o.order_code), o]));
          await runPool(missing, opts.detailConcurrency || 10, async (o) => {
            try {
              const d = await fetchDetail(o.order_code, sid, token);
              const t = byCode.get(String(o.order_code));
              if (!t || !d) return;
              t.promised = promisedOf(d) || t.promised;
              t.sub_status = d.sub_status || t.sub_status;
              t.status = d.status || t.status;
              t.created_at = d.created_at || t.created_at;
              t.updated_at = d.updated_at || t.updated_at;
              t.carrier = (d.extra && (d.extra.delivery_partner || d.extra.partner)) ||
                (d.delivery && d.delivery.tracking && d.delivery.tracking.delivered_by) || t.carrier;
              t.warehouse = (d.warehouse && (d.warehouse.name || d.warehouse.code)) || t.warehouse;
            } catch (e) {
              if (e && e.code === 401) throw e;
            }
          }, (n) => { if (n % 20 === 0 || n === missing.length) prog(sid, `bổ sung hạn giao: ${n}/${missing.length}`); });
        }

        // Chỉ giữ đúng đơn chưa giao thành công. Nếu detail trả trạng thái delivered thì loại ngay.
        const openShipping = sellerOrders.filter(o => String(o.status || '').toLowerCase() !== 'delivered');
        const remain = Math.max(0, cap - orders.length);
        orders.push(...openShipping.slice(0, remain));
      } catch (e) { errors[sid] = e.code === 401 ? 'Token hết hạn — mở lại TikiNOW' : e.message; }
      if (orders.length >= cap) break;
    }
    return { orders, errors, promisedCount: orders.filter(o => !!o.promised).length, missingPromised: orders.filter(o => !o.promised).length };
  }

  // ---- KẾT QUẢ GIAO & ĐVVC: counts (nhanh) + mẫu canceled/delivered trong cửa sổ ngày ----
  function outWindow(days){
    const now=new Date();
    const to=fmtDate(now);
    const d=new Date(now.getTime()-(days||30)*86400000);
    const from=fmtDate(new Date(d.getFullYear(),d.getMonth(),d.getDate(),0,0,0));
    return { from, to };
  }
  function outQuery(sid, status, page, from, to){
    const p=new URLSearchParams();
    p.set('filters.seller_id',sid); p.set('seller_id',sid);
    p.set('filters.status',status);
    p.set('filters.created_at.from',from); p.set('filters.created_at.to',to);
    p.set('page.page_number',page); p.set('page.per_page',CFG.api.perPage);
    p.set('sort_by','created_at|desc');
    return p.toString();
  }
  async function pullSample(sid, token, status, from, to, cap, onProgress){
    let page=1, all=[];
    while(all.length<cap){
      let j; try{ j=await apiGet(CFG.api.ordersPath, outQuery(sid,status,page,from,to), token); }
      catch(e){ if(e.code===401) throw e; break; }
      const batch=extractOrders(j);
      batch.forEach(o=>all.push({
        order_code:o.order_code, ref_code:o.ref_code, status:o.status, sub_status:o.sub_status,
        fulfillment_type:o.fulfillment_type,
        carrier:(o.extra&&(o.extra.delivery_partner||o.extra.partner))||null,
        warehouse:(o.warehouse&&(o.warehouse.name||o.warehouse.code))||o.warehouse||null,
        channel:(o.extra&&o.extra.channel)||null,
        created_at:o.created_at, updated_at:o.updated_at,
        promised:promisedOf(o),
        cancel_info:o.cancel_info||null, sid
      }));
      if(onProgress) onProgress(sid, `${status}: ${all.length}`);
      if(batch.length<CFG.api.perPage) break;
      page++; if(page>(CFG.api.maxPagesPerAccount||500)) break;
      if(CFG.api.pageDelayMs) await sleep(CFG.api.pageDelayMs);
    }
    return all;
  }
  async function collectOutcomes(tokens, opts){
    opts=opts||{};
    const days=opts.days||30;
    const win=outWindow(days);
    const capC=opts.maxCanceled||3000, capD=opts.maxDelivered||4000;
    const countsBySeller={}, canceled=[], delivered=[], errors={};
    const prog=(sid,msg)=>{ if(opts.onProgress) opts.onProgress(sid,msg); };
    for(const sid of Object.keys(tokens||{})){
      const token=tokens[sid].token;
      try{
        prog(sid,'đếm trạng thái…');
        try{ countsBySeller[sid]=await pullCounts(sid, token, win.from, win.to); }catch(e){ countsBySeller[sid]={}; }
        const c=await pullSample(sid, token, 'canceled', win.from, win.to, capC, opts.onProgress);
        canceled.push(...c);
        const d=await pullSample(sid, token, 'delivered', win.from, win.to, capD, opts.onProgress);
        delivered.push(...d);
      }catch(e){ errors[sid]=e.code===401?'Token hết hạn — mở lại TikiNOW':e.message; }
    }
    return { countsBySeller, canceled, delivered, errors, window:win, days };
  }

  root.Collector = { collectAll, collectProductivity, collectCycleTimes, collectReturnShipments, collectShipping, collectOutcomes, clearCycleCache, pullStatus, pullCounts, computeWindow };
})(self);
