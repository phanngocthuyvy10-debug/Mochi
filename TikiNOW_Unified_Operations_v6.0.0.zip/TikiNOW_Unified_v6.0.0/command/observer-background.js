(function () {
/* =============================================================
 * TikiNOW Ops Command Center v2.2.0 — background service worker
 * - Bắt token theo seller_id từ request thật của TikiNOW Center.
 * - Lưu API catalog (metadata + schema, không lưu response body/PII).
 * - Token chỉ ở máy người dùng; relay backend mặc định tắt.
 * ============================================================= */
"use strict";

const API_HOST = "api.tikinow.vn";
const CATALOG_KEY = "tikiApiCatalogV2";
const CATALOG_CAP = 300;
let catalogWriteQueue = Promise.resolve();
let tokenWriteQueue = Promise.resolve();

function asText(v) {
  return v == null ? "" : String(v).trim();
}

function extractSellerId(url) {
  try {
    const u = new URL(url);
    return u.searchParams.get("filters.seller_id")
      || u.searchParams.get("seller_id")
      || u.searchParams.get("sellerId")
      || null;
  } catch (_) {
    return null;
  }
}

function normalizePath(url) {
  try {
    const u = new URL(url);
    return u.pathname
      .replace(/\/orders\/(?!counts(?:\/|$)|search(?:\/|$)|export(?:\/|$))[^/]+(?=\/|$)/i, "/orders/:order_code")
      .replace(/\/return-shipments\/[^/]+(?=\/|$)/i, "/return-shipments/:shipment_id")
      .replace(/\/[0-9]{5,}(?=\/|$)/g, "/:id")
      .replace(/\/[0-9a-f]{8}-[0-9a-f-]{20,}(?=\/|$)/ig, "/:uuid");
  } catch (_) {
    return String(url || "").split("?")[0];
  }
}

async function saveToken(sellerId, token) {
  sellerId = asText(sellerId);
  token = asText(token);
  if (!sellerId || !token) return;

  const { tokens = {} } = await chrome.storage.local.get("tokens");
  const prev = tokens[sellerId];
  const now = Date.now();
  if (prev && prev.token === token && (now - (prev.at || 0)) < 30000) return;

  tokens[sellerId] = {
    token,
    at: now,
    first_seen_at: prev && prev.first_seen_at ? prev.first_seen_at : now
  };
  await chrome.storage.local.set({ tokens });
  await UnifiedAuth.acceptCaptured(sellerId, token);
}


function mergeUnique(a, b, cap) {
  const out = new Set(Array.isArray(a) ? a : []);
  (Array.isArray(b) ? b : []).forEach(x => {
    if (out.size < cap) out.add(String(x));
  });
  return Array.from(out);
}

function sanitizeRequestBody(value) {
  const raw = typeof value === "string" ? value.slice(0, 65536) : "";
  if (!raw) return "";
  const secretKey = /(authorization|access[_-]?token|refresh[_-]?token|password|passwd|secret|cookie|session)/i;
  function scrub(v) {
    if (Array.isArray(v)) return v.map(scrub);
    if (!v || typeof v !== "object") return v;
    const out = {};
    Object.keys(v).forEach(k => { out[k] = secretKey.test(k) ? "[REDACTED]" : scrub(v[k]); });
    return out;
  }
  try { return JSON.stringify(scrub(JSON.parse(raw))).slice(0, 65536); }
  catch (_) {
    try {
      const p = new URLSearchParams(raw);
      let recognized = false;
      for (const [k] of p) { recognized = true; if (secretKey.test(k)) p.set(k, "[REDACTED]"); }
      return recognized ? p.toString().slice(0, 65536) : raw;
    } catch (_) { return raw; }
  }
}

function cleanCapture(input) {
  if (!input || !input.url) return null;
  let u;
  try { u = new URL(input.url); } catch (_) { return null; }
  if (u.hostname !== API_HOST) return null;

  const method = String(input.method || "GET").toUpperCase();
  const requestBody = sanitizeRequestBody(input.requestBody);
  const pathKey = input.pathKey || normalizePath(u.toString());

  return {
    key: `${method} ${pathKey}`,
    method,
    pathKey,
    url: u.toString(),
    sellerId: input.sellerId || extractSellerId(u.toString()),
    kind: input.kind || "unknown",
    status: Number(input.status || 0),
    total: input.total == null ? null : Number(input.total),
    perPage: input.perPage == null ? null : Number(input.perPage),
    totalPage: input.totalPage == null ? null : Number(input.totalPage),
    pageParam: input.pageParam || null,
    sizeParam: input.sizeParam || null,
    pageBodyPath: input.pageBodyPath || null,
    sizeBodyPath: input.sizeBodyPath || null,
    requestBody,
    requestContentType: String(input.requestContentType || "").slice(0, 120),
    responseKeys: mergeUnique([], input.responseKeys, 200),
    schemaPaths: mergeUnique([], input.schemaPaths, 500),
    title: String(input.title || "").slice(0, 200),
    route: String(input.route || "").slice(0, 160),
    at: Number(input.at || Date.now())
  };
}

async function mergeCatalogCapture(raw) {
  const rec = cleanCapture(raw);
  if (!rec) return { ok: false };

  const data = await chrome.storage.local.get(CATALOG_KEY);
  const list = Array.isArray(data[CATALOG_KEY]) ? data[CATALOG_KEY] : [];
  const idx = list.findIndex(x => x && x.key === rec.key);
  const now = rec.at || Date.now();

  if (idx >= 0) {
    const old = list[idx];
    const previousSchema = Array.isArray(old.lastSchemaPaths) ? old.lastSchemaPaths : (old.schemaPaths || []);
    const currentSchema = rec.schemaPaths || [];
    const newFields = currentSchema.filter(x => !previousSchema.includes(x));
    const removedFields = previousSchema.filter(x => !currentSchema.includes(x));
    const schemaChanged = currentSchema.length > 0 && (newFields.length > 0 || removedFields.length > 0);
    list[idx] = {
      ...old,
      ...rec,
      firstSeenAt: old.firstSeenAt || now,
      lastSeenAt: now,
      hits: Number(old.hits || 0) + 1,
      schemaPaths: mergeUnique(old.schemaPaths, rec.schemaPaths, 500),
      lastSchemaPaths: currentSchema.length ? currentSchema : previousSchema,
      schemaVersion: Number(old.schemaVersion || 1) + (schemaChanged ? 1 : 0),
      schemaChangedAt: schemaChanged ? now : (old.schemaChangedAt || null),
      newFields: schemaChanged ? newFields.slice(0, 200) : (old.newFields || []),
      removedFields: schemaChanged ? removedFields.slice(0, 200) : (old.removedFields || []),
      responseKeys: mergeUnique(old.responseKeys, rec.responseKeys, 200),
      requestBody: rec.requestBody || old.requestBody || "",
      route: rec.route || old.route || "",
      sellerId: rec.sellerId || old.sellerId || null,
      pageParam: rec.pageParam || old.pageParam || null,
      sizeParam: rec.sizeParam || old.sizeParam || null,
      pageBodyPath: rec.pageBodyPath || old.pageBodyPath || null,
      sizeBodyPath: rec.sizeBodyPath || old.sizeBodyPath || null,
      total: rec.total == null ? old.total : rec.total,
      totalPage: rec.totalPage == null ? old.totalPage : rec.totalPage,
      perPage: rec.perPage == null ? old.perPage : rec.perPage
    };
  } else {
    list.unshift({ ...rec, firstSeenAt: now, lastSeenAt: now, hits: 1, lastSchemaPaths: rec.schemaPaths || [], schemaVersion: 1, schemaChangedAt: null, newFields: [], removedFields: [] });
  }

  list.sort((a, b) => (b.lastSeenAt || 0) - (a.lastSeenAt || 0));
  await chrome.storage.local.set({ [CATALOG_KEY]: list.slice(0, CATALOG_CAP) });
  return { ok: true, key: rec.key };
}

/* =============================================================================
 * v2.3: LIVE SESSION WATCH — nền tảng cho auto-sync
 * Mỗi request thật tới api.tikinow.vn là bằng chứng "người dùng đang mở TikiNOW".
 * Ghi mốc hoạt động (throttle 10s) để Ops Command Center tự quyết định khi nào sync.
 * Không lưu URL đầy đủ, không lưu body, không lưu token ở đây.
 * ========================================================================== */
const ACTIVITY_KEY = "tnslActivity";
const HUB_KEY = "tnslHubHeartbeat";
const AUTOPILOT_KEY = "tnslAutopilot";
const ACTIVITY_WRITE_MS = 10000;   // throttle ghi storage
const AUTO_OPEN_COOLDOWN_MS = 1800000; // 30 phút

let lastActivityWrite = 0;
let lastAutoOpen = 0;
let openedThisSession = false;   // mở tối đa 1 tab cho mỗi vòng đời service worker

const PENDING_ACTIVITY = new Map();   // sellerId -> mốc gần nhất, gộp trước khi ghi

async function noteActivity(sellerId, path) {
  const now = Date.now();
  const sid = asText(sellerId);
  if (sid) PENDING_ACTIVITY.set(sid, now);
  if (now - lastActivityWrite < ACTIVITY_WRITE_MS) return;
  lastActivityWrite = now;
  try {
    const cur = await chrome.storage.local.get(ACTIVITY_KEY);
    const prev = cur[ACTIVITY_KEY] || {};
    const bySeller = { ...(prev.bySeller || {}) };
    for (const [k, v] of PENDING_ACTIVITY) bySeller[k] = v;
    PENDING_ACTIVITY.clear();
    await chrome.storage.local.set({
      [ACTIVITY_KEY]: {
        at: now,
        sellerId: sid || prev.sellerId || null,
        path: asText(path) || null,
        bySeller                       // account nào đang thực sự được dùng
      }
    });
  } catch (_) {}
  maybeOpenHub(now);
}

/* Nếu phiên TikiNOW đang sống mà chưa có tab Ops Command Center nào mở,
   mở một tab nền (không cướp focus) để pipeline sync có chỗ chạy.
   Người dùng tắt được ở Ops Command Center → nút ⚡ Auto. */
/* Hỏi trực tiếp xem có tab Ops Command Center nào đang mở không.
   KHÔNG dùng heartbeat theo mốc thời gian nữa: Chrome bóp timer của tab nền
   xuống ~1 lần/phút, nên một tab đang mở nhưng không được focus sẽ bị hiểu
   nhầm là đã đóng — và extension mở thêm tab trùng. sendMessage tới các trang
   extension không bị throttle nên câu trả lời luôn đúng thực tế. */
function hubIsOpen() {
  return new Promise(resolve => {
    let done = false;
    const finish = v => { if (!done) { done = true; resolve(v); } };
    setTimeout(() => finish(false), 500);
    try {
      chrome.runtime.sendMessage({ type: "PING_HUB" }, r => {
        void chrome.runtime.lastError;      // không có ai nghe => lastError, coi như chưa mở
        finish(!!(r && r.hub));
      });
    } catch (_) { finish(false); }
  });
}

async function maybeOpenHub(now) {
  try {
    const cfg = await chrome.storage.local.get([AUTOPILOT_KEY]);
    const auto = cfg[AUTOPILOT_KEY] || {};
    if (auto.enabled === false) return;
    /* OPT-IN: mặc định KHÔNG tự mở tab. Chỉ mở khi người dùng bật rõ ràng
       trong Cài đặt. Tự bật sẵn là quá xâm phạm — mỗi lần tìm kiếm trên
       TikiNOW lại nhảy ra một tab là hành vi không thể chấp nhận. */
    if (auto.autoOpen !== true) return;
    if (openedThisSession) return;                       // mỗi phiên chỉ mở tối đa 1 lần
    if (now - lastAutoOpen < AUTO_OPEN_COOLDOWN_MS) return;
    if (await hubIsOpen()) return;                       // đã có Hub -> tuyệt đối không mở thêm
    lastAutoOpen = now;
    openedThisSession = true;
    await chrome.tabs.create({ url: chrome.runtime.getURL("app.html"), active: false });
  } catch (_) {}
}

chrome.webRequest.onSendHeaders.addListener(
  details => {
    const sellerId = extractSellerId(details.url);
    noteActivity(sellerId, normalizePath(details.url));
    if (!sellerId) return;
    const authHeader = (details.requestHeaders || [])
      .find(h => String(h.name || "").toLowerCase() === "authorization");
    if (authHeader && authHeader.value) {
      tokenWriteQueue = tokenWriteQueue
        .then(() => saveToken(sellerId, authHeader.value))
        .catch(() => null);
    }
  },
  { urls: ["https://api.tikinow.vn/*"] },
  ["requestHeaders", "extraHeaders"]
);

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || !msg.type) return false;

  if (msg.type === "GET_TOKENS") {
    UnifiedAuth.commandTokens()
      .then(tokens => sendResponse(tokens))
      .catch(() => sendResponse({}));
    return true;
  }

  if (msg.type === "SAVE_API_CAPTURE") {
    catalogWriteQueue = catalogWriteQueue
      .then(() => mergeCatalogCapture(msg.record))
      .then(sendResponse)
      .catch(e => sendResponse({ ok: false, error: e && e.message }));
    return true;
  }

  if (msg.type === "GET_API_CATALOG") {
    chrome.storage.local.get(CATALOG_KEY)
      .then(data => sendResponse(Array.isArray(data[CATALOG_KEY]) ? data[CATALOG_KEY] : []))
      .catch(() => sendResponse([]));
    return true;
  }

  if (msg.type === "CLEAR_API_CATALOG") {
    chrome.storage.local.set({ [CATALOG_KEY]: [] })
      .then(() => sendResponse({ ok: true }))
      .catch(e => sendResponse({ ok: false, error: e && e.message }));
    return true;
  }

  /* v2.3: Ops Command Center hỏi "phiên TikiNOW còn sống không" để tự sync. */
  if (msg.type === "LIVE_STATUS") {
    chrome.storage.local.get(["tokens", ACTIVITY_KEY, "tnslAccountHealth"])
      .then(data => {
        const tokens = data.tokens || {};
        const tokenAt = Object.values(tokens).reduce((m, t) => Math.max(m, Number(t && t.at) || 0), 0);
        const act = data[ACTIVITY_KEY] || {};
        const bySeller = act.bySeller || {};
        const health = data.tnslAccountHealth || {};
        /* Một account được coi là "đang mở" nếu vừa có request thật, HOẶC token vừa được
           làm mới — cả hai đều chỉ xảy ra khi người dùng thực sự ở trong account đó. */
        const accounts = Object.keys(tokens).map(sid => ({
          sellerId: sid,
          tokenAt: Number(tokens[sid] && tokens[sid].at) || 0,
          firstSeenAt: Number(tokens[sid] && tokens[sid].first_seen_at) || 0,
          activityAt: Math.max(Number(bySeller[sid]) || 0, Number(tokens[sid] && tokens[sid].at) || 0),
          health: health[sid] || null
        }));
        sendResponse({
          now: Date.now(),
          lastActivityAt: Math.max(Number(act.at) || 0, tokenAt),
          lastSellerId: act.sellerId || null,
          tokenCount: accounts.length,
          lastTokenAt: tokenAt,
          accounts
        });
      })
      .catch(() => sendResponse({ now: Date.now(), lastActivityAt: 0, tokenCount: 0, lastTokenAt: 0, accounts: [] }));
    return true;
  }

  /* Ops Command Center báo "tôi đang mở" để background khỏi mở thêm tab. */
  if (msg.type === "HUB_HEARTBEAT") {
    chrome.storage.local.set({ [HUB_KEY]: { at: Date.now() } })
      .then(() => sendResponse({ ok: true }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (msg.type === "SYSTEM_STATUS") {
    chrome.storage.local.get(["tokens", CATALOG_KEY])
      .then(data => sendResponse({
        tokenCount: Object.keys(data.tokens || {}).length,
        endpointCount: Array.isArray(data[CATALOG_KEY]) ? data[CATALOG_KEY].length : 0,
        now: Date.now()
      }))
      .catch(() => sendResponse({ tokenCount: 0, endpointCount: 0, now: Date.now() }));
    return true;
  }

  return false;
});

})();
