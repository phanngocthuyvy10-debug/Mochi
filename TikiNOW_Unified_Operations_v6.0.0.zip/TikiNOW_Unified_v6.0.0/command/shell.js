/* =============================================================================
 * TikiNOW Ops Command Center — SHELL v3
 * Trách nhiệm:
 *   1. Router 5 workspace × sub-tab (ủy quyền sang tab legacy để không đụng logic cũ)
 *   2. MỘT nút đồng bộ duy nhất + registry độ tươi dữ liệu theo từng miền
 *   3. Dual theme, command palette, toast, popover
 * Không sửa dashboard.js / datahub.js / engine.js — chỉ điều phối chúng.
 * ========================================================================== */
(function (root) {
  "use strict";

  const $ = id => document.getElementById(id);
  const $$ = sel => Array.prototype.slice.call(document.querySelectorAll(sel));

  /* ------------------------------------------------------------------ IA */
  const WORKSPACES = [
    { id: "command",  label: "Điều hành",   views: ["director", "trend"] },
    { id: "execute",  label: "Vận hành ca", views: ["atrisk", "backlog", "flow", "prod"] },
    { id: "analyze",  label: "Phân tích",   views: ["cycle", "outcome", "ship"] },
    { id: "evidence", label: "Bằng chứng",  views: ["orders", "evidence"] },
    { id: "data",     label: "Dữ liệu",     views: ["sitemap", "fusion", "sections", "datahub", "fields", "endpoints", "export", "rshipment"] }
  ];

  const LEGACY_VIEWS = ["datahub", "director", "backlog", "prod", "cycle", "atrisk",
                        "flow", "trend", "ship", "outcome", "rshipment", "export"];
  const SHELL_VIEWS = { orders: "viewOrders", evidence: "viewEvidence",
                        fields: "viewFields", endpoints: "viewEndpoints",
                        sections: "viewSections", fusion: "viewFusion",
                        sitemap: "viewSitemap" };

  const VIEW_LABEL = {};
  WORKSPACES.forEach(w => w.views.forEach(v => { VIEW_LABEL[v] = v; }));
  $$(".sub").forEach(b => { VIEW_LABEL[b.dataset.view] = b.textContent.trim(); });

  /* view -> miền dữ liệu tương ứng (để chấm dot độ tươi trên sub-tab) */
  const VIEW_DOMAIN = {
    director: "director", trend: "director",
    atrisk: "risk", backlog: "backlog", flow: "flow", prod: "prod",
    cycle: "cycle", outcome: "outcome", ship: "ship",
    orders: "vault", evidence: "vault", datahub: "vault",
    fields: "vault", endpoints: "vault", export: "capture", rshipment: "vault",
    sections: "capture", fusion: "capture", sitemap: "capture"
  };

  /* --------------------------------------------------------- SYNC DOMAINS */
  const call = (name, ...args) =>
    typeof root[name] === "function" ? root[name](...args) : Promise.resolve();

  /* ---------------------------------------------------------------------
     CHẾ ĐỘ VẬN HÀNH — thứ quyết định kéo bao nhiêu dữ liệu.
       backlog : chỉ đơn CHƯA XONG. Không detail, không delivered/canceled, không vault.
       ops     : thêm năng suất, ĐVVC, cycle-time, toàn cảnh.
       audit   : thêm vault (raw + Field/Endpoint Coverage + Excel full).
     Mặc định là backlog vì 90% việc trong ca là quản đơn chưa xong.
     --------------------------------------------------------------------- */
  const SCOPES = {
    backlog: { label: "Backlog", icon: "⚡",
      desc: "Chỉ đơn chưa xong. Nhanh nhất — không gọi detail từng đơn, bỏ delivered/canceled." },
    ops: { label: "Vận hành", icon: "◐",
      desc: "Thêm năng suất, vận chuyển, ĐVVC, cycle-time, toàn cảnh." },
    audit: { label: "Audit", icon: "✦",
      desc: "Thêm vault raw, Field/Endpoint Coverage và Excel full. Chậm — chỉ dùng khi cần đối soát." }
  };

  /* Thứ tự = thứ tự chạy. Miền phụ thuộc đứng sau miền cung cấp dữ liệu cho nó. */
  const DOMAINS = [
    { key: "backlog", needsApi: true,  label: "Backlog",       weight: 3, scopes: ["backlog", "ops", "audit"],
      run: () => call("refresh") },
    { key: "ship", needsApi: true,     label: "Vận chuyển",    weight: 2, scopes: ["ops", "audit"],
      run: () => call("shipRefresh") },
    { key: "risk",     label: "Sắp trễ",       weight: 1, scopes: ["backlog", "ops", "audit"],
      run: () => call("arRefresh") },
    { key: "flow",     label: "Dòng chảy",     weight: 1, scopes: ["backlog", "ops", "audit"],
      run: () => call("flowRefresh") },
    { key: "prod", needsApi: true,     label: "Năng suất",     weight: 2, scopes: ["ops", "audit"],
      run: () => call("prodRefresh") },
    { key: "cycle", needsApi: true,    label: "Cycle",         weight: 2, scopes: ["ops", "audit"],
      run: () => call("cycRefresh") },
    { key: "outcome", needsApi: true,  label: "Kết quả giao",  weight: 2, scopes: ["ops", "audit"],
      run: () => call("outRefresh") },
    { key: "director", label: "Toàn cảnh",     weight: 1, scopes: ["ops", "audit"],
      run: () => call("dirRefresh", false) },
    { key: "vault", needsApi: true,    label: "Vault",         weight: 4, scopes: ["audit"],
      run: mode => {
        const H = root.TikiDataHub;
        if (!H) return Promise.resolve();
        if (mode === "full") return H.syncFull();
        if (mode === "retry") return H.retryGaps();
        if (mode === "vaultBacklog") return H.syncBacklog();
        return H.syncSmart();
      } },
    { key: "capture",  label: "Trang đã bắt",  weight: 1, scopes: ["audit"],
      run: () => call("expRefresh") }
  ];
  function inScope(d, scope) { return d.scopes.indexOf(scope) >= 0; }
  const DOMAIN_BY_KEY = {};
  DOMAINS.forEach(d => { DOMAIN_BY_KEY[d.key] = d; });

  const FRESH_OK_MS = 30 * 60 * 1000;      // < 30' = tươi
  const FRESH_STALE_MS = 6 * 60 * 60 * 1000; // < 6h = cũ, ngoài ra = quá cũ

  const STATE = {
    ws: "execute",
    view: "atrisk",
    running: false,
    aborted: false,
    freshness: {},              // { domain: { at, ok, err } }
    theme: "dark",
    scope: "backlog",
    auto: { enabled: false, autoOpen: false, intervalMin: 10 },
    live: { lastActivityAt: 0, tokenCount: 0, accounts: [] },
    knownSellers: [],
    autoReason: "",
    progress: { step: 0, stepTotal: 0, done: 0, total: 0, pct: 0, label: "",
                acc: { index: 0, total: 0, name: "" }, startedAt: 0 },
    lastRun: null
  };

  /* Trần thời gian cho từng miền — hết giờ thì bỏ qua, không để kẹt "Đang chạy…" mãi. */
  const DOMAIN_TIMEOUT_MS = { vault: 20 * 60000 };
  const DEFAULT_TIMEOUT_MS = 5 * 60000;

  /* Phiên TikiNOW được coi là "đang sống" nếu có request thật trong 5 phút qua. */
  const LIVE_WINDOW_MS = 5 * 60 * 1000;
  const HEARTBEAT_MS = 15000;
  const AUTOPILOT_TICK_MS = 30000;

  /* ------------------------------------------------------------- STORAGE */
  const store = {
    get(keys) {
      return new Promise(res => {
        try { chrome.storage.local.get(keys, r => res(r || {})); }
        catch (_) {
          const out = {};
          [].concat(keys).forEach(k => {
            try { out[k] = JSON.parse(localStorage.getItem("tnsl_" + k)); } catch (_) {}
          });
          res(out);
        }
      });
    },
    set(obj) {
      return new Promise(res => {
        try { chrome.storage.local.set(obj, () => res()); }
        catch (_) {
          Object.keys(obj).forEach(k => {
            try { localStorage.setItem("tnsl_" + k, JSON.stringify(obj[k])); } catch (_) {}
          });
          res();
        }
      });
    }
  };

  /* --------------------------------------------------------------- TOAST */
  function toast(title, sub, kind) {
    const box = $("toasts"); if (!box) return;
    const t = document.createElement("div");
    t.className = "toast " + (kind || "");
    t.innerHTML = `<b></b>${sub ? "<small></small>" : ""}`;
    t.querySelector("b").textContent = title;
    if (sub) t.querySelector("small").textContent = sub;
    box.appendChild(t);
    setTimeout(() => { t.style.opacity = "0"; t.style.transition = "opacity .3s"; }, 4200);
    setTimeout(() => t.remove(), 4600);
  }

  /* --------------------------------------------------------------- THEME */
  function applyTheme(theme) {
    STATE.theme = theme === "light" ? "light" : "dark";
    document.documentElement.setAttribute("data-theme", STATE.theme);
    const b = $("themeBtn");
    if (b) b.textContent = STATE.theme === "dark" ? "☀" : "☾";
    store.set({ tnslTheme: STATE.theme });
  }

  /* ------------------------------------------------------------ ROUTING */
  /* dashboard.js tự gọi prodRefresh/cycRefresh/... ngay khi chuyển tab lần đầu.
     Điều đó đi ngược "chỉ kéo khi tôi có nhu cầu", và còn gọi trùng với nút
     Nạp trên thanh dữ liệu. Bọc các hàm đó lại: trong lúc chuyển view thì
     chúng không chạy; chỉ nút Nạp (hoặc nút Đồng bộ) mới kích hoạt được. */
  let SUPPRESS_AUTOLOAD = false;
  const AUTOLOAD_FNS = ["prodRefresh", "cycRefresh", "shipRefresh", "outRefresh",
                        "expRefresh", "trendRefresh", "dirRefresh", "arRefresh",
                        "flowRefresh", "rsInit", "refresh"];
  function guardAutoLoad() {
    AUTOLOAD_FNS.forEach(fn => {
      const orig = root[fn];
      if (typeof orig !== "function" || orig.__tnslGuarded) return;
      const wrapped = function () {
        if (SUPPRESS_AUTOLOAD) return Promise.resolve();
        return orig.apply(this, arguments);
      };
      wrapped.__tnslGuarded = true;
      root[fn] = wrapped;
    });
  }

  function legacyTab(view) {
    return document.querySelector('.tabs .tab[data-view="' + view + '"]');
  }

  function hideShellViews() {
    Object.keys(SHELL_VIEWS).forEach(v => {
      const el = $(SHELL_VIEWS[v]); if (el) el.style.display = "none";
    });
  }
  function hideLegacyViews() {
    LEGACY_VIEWS.forEach(v => {
      const el = $("view" + v.charAt(0).toUpperCase() + v.slice(1));
      if (el) el.style.display = "none";
    });
    // tên section không theo camel chuẩn
    ["viewDatahub", "viewAtRisk", "viewRshipment"].forEach(id => {
      const el = $(id); if (el) el.style.display = "none";
    });
  }

  function goto(view, opts) {
    opts = opts || {};
    const ws = WORKSPACES.find(w => w.views.indexOf(view) >= 0);
    if (!ws) return;
    STATE.ws = ws.id;
    STATE.view = view;

    // nav state
    $$(".ws").forEach(b => b.classList.toggle("active", b.dataset.ws === ws.id));
    $$(".subnav").forEach(n => { n.hidden = n.dataset.subnav !== ws.id; });
    $$(".sub").forEach(b => b.classList.toggle("active", b.dataset.view === view));

    if (SHELL_VIEWS[view]) {
      hideLegacyViews();
      hideShellViews();
      const el = $(SHELL_VIEWS[view]);
      if (el) el.style.display = "";
      $$(".tabs .tab").forEach(t => t.classList.remove("active"));
      if (view === "sections") { if (root.TNSLSections) root.TNSLSections.onView(); }
      else if (view === "fusion") { if (root.TNSLFusion) root.TNSLFusion.onView(); }
      else if (view === "sitemap") { if (root.TNSLSiteMap) root.TNSLSiteMap.onView(); }
      else if (root.TNSLInsight) root.TNSLInsight.onView(view, opts);
    } else {
      hideShellViews();
      const tab = legacyTab(view);
      if (tab) {
        SUPPRESS_AUTOLOAD = true;                  // chỉ mượn phần hiện/ẩn, bỏ phần tự kéo
        try { tab.click(); }
        finally { setTimeout(() => { SUPPRESS_AUTOLOAD = false; }, 0); }
      }
    }

    paintDataBar(view);
    document.title = (VIEW_LABEL[view] || view) + " · TikiNOW Ops";
    store.set({ tnslLastView: view });
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  /* =======================================================================
   *  DATA BAR — "chỉ kéo API chỗ nào khi tôi có nhu cầu"
   *
   *  Mỗi màn hình có một thanh riêng ở đầu, nói đúng ba điều:
   *    1. Màn hình này sống bằng dữ liệu nào
   *    2. Dữ liệu đó đã nạp chưa, nạp lúc nào
   *    3. Nút nạp NGAY tại chỗ — không phải đi tìm nút sync ở đâu khác
   *
   *  Đây cũng là cách sửa lỗi "Bằng chứng trống": Order 360° sống bằng vault,
   *  mà chế độ Backlog không chạy vault, nên trước đây nó chỉ hiện bảng rỗng
   *  không giải thích gì. Giờ nó nói thẳng vault chưa nạp và cho nút nạp.
   * ==================================================================== */
  const VIEW_SECTION = {
    director: "viewDirector", trend: "viewTrend", atrisk: "viewAtRisk",
    backlog: "viewBacklog", flow: "viewFlow", prod: "viewProd",
    cycle: "viewCycle", outcome: "viewOutcome", ship: "viewShip",
    orders: "viewOrders", evidence: "viewEvidence", datahub: "viewDatahub",
    fields: "viewFields", endpoints: "viewEndpoints",
    export: "viewExport", rshipment: "viewRshipment", sections: "viewSections", fusion: "viewFusion", sitemap: "viewSitemap"
  };

  /* Miền vault rất nặng nếu kéo full. Với các màn hình chỉ cần danh sách đơn,
     mặc định nạp bằng chế độ Backlog của vault: bỏ delivered/canceled, bỏ
     detail từng đơn — nhanh gấp nhiều lần mà vẫn đủ cho Order 360°. */
  const VIEW_LOAD = {
    orders:    { domain: "vault", mode: "vaultBacklog", label: "đơn backlog vào vault" },
    evidence:  { domain: "vault", mode: "vaultBacklog", label: "đơn backlog vào vault" },
    datahub:   { domain: "vault", mode: "vaultBacklog", label: "đơn backlog vào vault" },
    fields:    { domain: "vault", mode: "vaultBacklog", label: "đơn backlog vào vault" },
    endpoints: { domain: "vault", mode: "vaultBacklog", label: "đơn backlog vào vault" },
    rshipment: { domain: "vault", mode: "vaultBacklog", label: "đơn backlog vào vault" }
  };

  function loadPlanFor(view) {
    const p = VIEW_LOAD[view];
    if (p) return p;
    const dom = VIEW_DOMAIN[view];
    const d = dom && DOMAIN_BY_KEY[dom];
    return d ? { domain: dom, mode: null, label: d.label.toLowerCase() } : null;
  }

  function ensureDataBar(view) {
    const secId = VIEW_SECTION[view];
    const sec = secId && $(secId);
    if (!sec) return null;
    let bar = sec.querySelector(":scope > .databar");
    if (!bar) {
      bar = document.createElement("div");
      bar.className = "databar";
      bar.dataset.view = view;
      sec.insertBefore(bar, sec.firstChild);
    }
    return bar;
  }

  function paintDataBar(view) {
    /* Màn hình Mục TikiNOW Center tự quản việc nạp từng mục -> không cần thanh chung. */
    if (view === "sections" || view === "fusion" || view === "sitemap") { const b0 = ensureDataBar(view); if (b0) b0.hidden = true; return; }
    const bar = ensureDataBar(view);
    if (!bar) return;
    const plan = loadPlanFor(view);
    if (!plan) { bar.hidden = true; return; }
    bar.hidden = false;

    const f = STATE.freshness[plan.domain] || {};
    const d = DOMAIN_BY_KEY[plan.domain];
    const name = d ? d.label : plan.domain;
    const busy = STATE.running && STATE.current === plan.domain;
    const blocked = levelOf(plan.domain) === "blocked";
    const has = !!f.at && !f.err;

    let cls = "databar", icon, text, btn;
    if (busy) {
      cls += " busy"; icon = "⟳";
      text = "Đang nạp " + name + "…";
      btn = "";
    } else if (blocked) {
      cls += " blocked"; icon = "🔑";
      text = "Chưa đăng nhập TikiNOW nên không nạp được. Mở TikiNOW Center, đăng nhập rồi quay lại.";
      btn = '<button class="db-go" data-act="login">↗ Mở TikiNOW Center</button>';
    } else if (f.err) {
      cls += " err"; icon = "!";
      text = name + " nạp lỗi: " + f.err;
      btn = '<button class="db-go" data-act="load">↻ Thử lại</button>';
    } else if (!has) {
      cls += " empty"; icon = "○";
      text = "Màn hình này chưa có dữ liệu. Nó đọc từ <b>" + name + "</b> — bấm để nạp "
           + plan.label + ".";
      btn = '<button class="db-go" data-act="load">⤓ Nạp dữ liệu</button>';
    } else {
      const age = Date.now() - f.at;
      cls += age < FRESH_OK_MS ? " ok" : " stale";
      icon = age < FRESH_OK_MS ? "●" : "◐";
      text = name + " · cập nhật " + ageText(age) + " trước"
           + (f.ms ? " · lần nạp mất " + elapsed(f.ms) : "");
      btn = '<button class="db-go ghost" data-act="load">↻ Nạp lại</button>';
    }
    bar.className = cls;
    bar.innerHTML = '<span class="db-ic">' + icon + '</span><span class="db-txt">' + text + "</span>" + btn;

    const b = bar.querySelector("[data-act]");
    if (b) b.onclick = () => {
      if (b.dataset.act === "login") return openTikiSetup();
      runSync({ only: plan.domain, mode: plan.mode });
    };
  }

  function paintAllDataBars() {
    if (STATE.view) paintDataBar(STATE.view);
  }

  /* ------------------------------------------------------- FRESHNESS UI */
  function ageText(ms) {
    if (ms == null) return "";
    const m = Math.floor(ms / 60000);
    if (m < 1) return "vừa xong";
    if (m < 60) return m + "′";
    const h = Math.floor(m / 60);
    if (h < 24) return h + "h";
    return Math.floor(h / 24) + "d";
  }

  /* Phân biệt "lỗi" với "bị chặn vì thiếu điều kiện".
     Bấm lại một miền đang thiếu token thì chỉ lỗi tiếp — phải chỉ đúng việc cần làm. */
  const BLOCKING_CODES = { NO_TOKEN: 1 };
  function levelOf(key) {
    const f = STATE.freshness[key];
    if (STATE.running && STATE.current === key) return "run";
    if (f && f.err && BLOCKING_CODES[f.code]) return "blocked";
    if (!f || !f.at) return "none";
    if (f.err) return "err";
    const age = Date.now() - f.at;
    if (age < FRESH_OK_MS) return "ok";
    return "stale";
  }

  function applyScope(scope, announce) {
    if (!SCOPES[scope]) scope = "backlog";
    STATE.scope = scope;
    store.set({ tnslScope: scope });
    $$(".scope-btn").forEach(b => b.classList.toggle("active", b.dataset.scope === scope));
    const n = $("scopeNote");
    if (n) n.textContent = SCOPES[scope].desc;
    paintFreshness();
    if (announce) {
      const dn = DOMAINS.filter(d => inScope(d, scope)).map(d => d.label).join(" · ");
      toast("Chế độ " + SCOPES[scope].label, "Từ giờ mỗi lần đồng bộ chỉ kéo: " + dn, "ok");
    }
  }

  function paintFreshness() {
    $$(".fchip").forEach(chip => {
      const k = chip.dataset.domain;
      const d0 = DOMAIN_BY_KEY[k];
      const off = d0 && !inScope(d0, STATE.scope);
      const lvl = levelOf(k);
      chip.className = "fchip f-" + lvl + (off ? " off-scope" : "");
      if (off) {
        const f0 = STATE.freshness[k];
        const sp = chip.querySelector("[data-age]");
        if (sp) sp.textContent = f0 && f0.at ? " · " + ageText(Date.now() - f0.at) : " · tắt";
        chip.title = d0.label + " — KHÔNG kéo trong chế độ " + SCOPES[STATE.scope].label + "."
          + "\nBấm để kéo riêng phần này một lần, hoặc đổi sang chế độ "
          + (d0.scopes.indexOf("ops") >= 0 ? "Vận hành" : "Audit") + ".";
        return;
      }
      const f = STATE.freshness[k];
      const span = chip.querySelector("[data-age]");
      if (span) span.textContent = f && f.at ? " · " + ageText(Date.now() - f.at) : "";
      const d = DOMAIN_BY_KEY[k];
      const name = d ? d.label : k;
      if (lvl === "blocked") {
        if (span) span.textContent = " · cần đăng nhập";
        chip.title = name + " — CHƯA ĐĂNG NHẬP TIKINOW.\n\n"
          + "Bấm lại nút đồng bộ sẽ chỉ lỗi tiếp, vì extension chưa có token nào.\n"
          + "Việc cần làm: mở TikiNOW Center, đăng nhập, rồi switch qua từng account cần theo dõi.\n"
          + "Extension tự bắt token — không phải khai báo gì.\n\n"
          + "Bấm chip này để mở TikiNOW Center.";
      } else if (lvl === "err") {
        chip.title = name + " — lỗi: " + (f && f.err) + "\nBấm để chạy lại riêng phần này.";
      } else {
        chip.title = name + (f && f.at
          ? " — cập nhật " + new Date(f.at).toLocaleString("vi-VN")
            + (f.ms ? " · lần chạy gần nhất mất " + elapsed(f.ms) : "")
          : " — chưa đồng bộ lần nào") + "\nBấm để đồng bộ riêng phần này.";
      }
    });
    $$(".s-dot").forEach(dot => {
      const dom = VIEW_DOMAIN[dot.dataset.dot];
      dot.className = "s-dot f-" + (dom ? levelOf(dom) : "none");
    });
    paintOverall();
    paintBadges();
    paintAllDataBars();
  }

  function elapsed(ms) {
    const s = Math.round(ms / 1000);
    if (s < 60) return s + " giây";
    return Math.floor(s / 60) + "p" + String(s % 60).padStart(2, "0");
  }
  const nfmt = n => Number(n || 0).toLocaleString("vi-VN");

  /* Câu trả lời trực tiếp cho "đã xong chưa để còn switch account". */
  function paintSwitchSafe() {
    const b = $("switchSafe");
    if (!b) return;
    if (STATE.running) {
      b.className = "switch-badge busy";
      const p = STATE.progress;
      const acc = p.acc.total ? " · account " + p.acc.index + "/" + p.acc.total : "";
      b.textContent = "⏳ Đang kéo dữ liệu" + acc + " — chưa nên switch";
      b.title = "Đang có tiến trình đồng bộ chạy. Switch account lúc này có thể làm phiên hiện tại "
        + "mất hiệu lực giữa chừng, account đang kéo sẽ bị 401 và phải chạy lại.\n"
        + "Chờ badge chuyển xanh rồi hãy switch.";
    } else {
      b.className = "switch-badge safe";
      b.textContent = "✓ An toàn switch account";
      b.title = "Không có tiến trình đồng bộ nào đang chạy. Bạn có thể switch account trên TikiNOW "
        + "ngay bây giờ — extension sẽ bắt token của account mới và tự kéo dữ liệu.";
    }
  }

  /* ------- Banner hướng dẫn khi chưa có account nào -------
     "Chưa bắt được token" là chữ xám bé xíu, không ai thấy. Đây là blocker của
     TOÀN BỘ hệ thống nên nó phải là thứ to nhất trên màn hình. */
  function openTikiSetup() {
    try { chrome.tabs.create({ url: "https://tikinowcenter.tikinow.vn/", active: true }); }
    catch (_) { window.open("https://tikinowcenter.tikinow.vn/", "_blank", "noreferrer"); }
    toast("Đã mở TikiNOW Center",
      "Đăng nhập, rồi switch qua từng account cần theo dõi (mỗi account một lần). Extension tự bắt token và quay lại đây tự kéo dữ liệu.", "ok");
  }

  function paintSetup() {
    const b = $("setupBanner");
    if (!b) return;
    const none = !STATE.live.tokenCount;
    b.hidden = !none;
    const n = $("setupNote");
    if (n && none) {
      n.textContent = STATE.freshness.vault && STATE.freshness.vault.code === "NO_TOKEN"
        ? "Lần đồng bộ vừa rồi dừng vì lý do này — bấm lại nút đồng bộ sẽ không giải quyết được."
        : "Mọi màn hình sẽ trống cho tới khi có ít nhất một account.";
    }
  }

  function paintOverall() {
    const dot = $("sbDot"), lab = $("sbLabel"), sub = $("sbSub");
    paintSwitchSafe();
    paintSetup();
    if (!dot) return;

    if (STATE.running) {
      const p = STATE.progress;
      dot.className = "sb-dot run";
      lab.textContent = "Đang đồng bộ " + p.step + "/" + p.stepTotal;
      const bits = [];
      if (STATE.currentLabel) bits.push(STATE.currentLabel);
      if (p.acc.name) bits.push(p.acc.name + " (" + p.acc.index + "/" + p.acc.total + ")");
      if (p.label) bits.push(p.label + (p.total ? " " + nfmt(p.done) + "/" + nfmt(p.total) : ""));
      if (p.startedAt) bits.push(elapsed(Date.now() - p.startedAt));
      sub.textContent = bits.length ? " · " + bits.join(" · ") : "";
      return;
    }

    const levels = DOMAINS.map(d => levelOf(d.key));
    const anyErr = levels.indexOf("err") >= 0;
    const allNone = levels.every(l => l === "none");
    const anyStale = levels.indexOf("stale") >= 0 || levels.indexOf("none") >= 0;
    const last = Math.max.apply(null, DOMAINS.map(d => (STATE.freshness[d.key] || {}).at || 0));
    const r = STATE.lastRun;

    if (allNone && !r) {
      dot.className = "sb-dot";
      lab.textContent = "Chưa đồng bộ lần nào";
      sub.textContent = STATE.live.tokenCount
        ? " · bấm ⟳ Đồng bộ để bắt đầu"
        : " · chưa có account — mở TikiNOW Center và đăng nhập trước";
      return;
    }
    /* Chưa đăng nhập thì KHÔNG được nói "đồng bộ xong" — nó chưa chạy được gì cả. */
    if (levels.indexOf("blocked") >= 0 || (r && r.status === "no_token")) {
      dot.className = "sb-dot stale";
      lab.textContent = "Chưa chạy được — thiếu account";
      sub.textContent = " · đăng nhập TikiNOW rồi switch qua từng account cần theo dõi";
      return;
    }
    if (anyErr) { dot.className = "sb-dot err"; lab.textContent = "Đồng bộ xong, có phần lỗi"; }
    else if (anyStale) { dot.className = "sb-dot stale"; lab.textContent = "Đồng bộ xong, dữ liệu chưa đủ tươi"; }
    else { dot.className = "sb-dot ok"; lab.textContent = "✓ Đồng bộ xong"; }

    const bits = [];
    if (r && r.at) bits.push("lúc " + new Date(r.at).toLocaleTimeString("vi-VN"));
    if (r && r.durationMs) bits.push("mất " + elapsed(r.durationMs));
    if (r && r.listed) bits.push(nfmt(r.listed) + " đơn");
    if (r && r.accounts) bits.push(r.accounts + " account"
      + (r.accountErrors ? " (" + r.accountErrors + " lỗi)" : ""));
    if (!bits.length && last) bits.push("lần cuối " + ageText(Date.now() - last) + " trước");
    sub.textContent = bits.length ? " · " + bits.join(" · ") : "";
  }

  /* ---- nhận sự kiện tiến độ chi tiết từ datahub ---- */
  root.TNSL_ON_SYNC = function (evt, d) {
    const p = STATE.progress;
    if (evt === "progress") {
      p.done = d.done; p.total = d.total; p.pct = d.pct; p.label = d.label;
    } else if (evt === "account") {
      if (d.phase === "start") { p.acc = { index: d.index, total: d.total, name: d.name }; }
      else if (d.phase === "done" || d.phase === "error") {
        p.acc = { index: d.index, total: d.total, name: d.name };
        p.label = ""; p.done = 0; p.total = 0;
      }
    } else if (evt === "run") {
      if (d.phase === "start") { p.acc = { index: 0, total: d.accounts || 0, name: "" }; }
      else if (d.phase === "end") {
        STATE.lastRun = {
          at: Date.now(), status: d.status,
          durationMs: p.startedAt ? Date.now() - p.startedAt : 0,
          listed: d.listed || 0, accounts: d.accounts || 0,
          accountErrors: d.accountErrors || 0, needRelogin: d.needRelogin || 0
        };
        store.set({ tnslLastRun: STATE.lastRun });
        p.acc = { index: 0, total: 0, name: "" }; p.label = ""; p.done = 0; p.total = 0;
      }
    }
    paintOverall();
  };

  function paintBadges() {
    let exec = 0;
    try {
      const AR = root.AR;
      if (AR) exec = (AR.packing ? AR.packing.actNow : 0) + (AR.handover ? AR.handover.actNow : 0);
    } catch (_) {}
    let data = 0;
    try { data = document.querySelectorAll("#dhTrustIssues .P1").length; } catch (_) {}
    setBadge("execute", exec);
    setBadge("data", data);
  }
  function setBadge(ws, n) {
    const b = document.querySelector('[data-badge="' + ws + '"]');
    if (!b) return;
    b.textContent = n > 99 ? "99+" : String(n);
    b.classList.toggle("on", n > 0);
  }

  function markDomain(key, ok, err, code, ms) {
    const prev = STATE.freshness[key] || {};
    STATE.freshness[key] = {
      ms: ms != null ? ms : prev.ms,
      /* Thiếu điều kiện đầu vào (chưa đăng nhập) KHÔNG phải là "đã đồng bộ lúc X".
         Giữ nguyên mốc thành công cũ để không nói dối về độ tươi dữ liệu. */
      at: (code === "NO_TOKEN" && prev.at) ? prev.at : Date.now(),
      ok: !!ok, err: err || null, code: code || null
    };
    store.set({ tnslFreshness: STATE.freshness });
    paintFreshness();
  }

  /* --------------------------------------------------------- ORCHESTRATOR */
  function setProgress(pct) {
    const b = $("sbBar"); if (b) b.style.width = Math.max(0, Math.min(100, pct)) + "%";
  }
  let runTicker = null;
  function setRunning(on) {
    STATE.running = on;
    const btn = $("syncNow");
    if (btn) { btn.disabled = on; btn.textContent = on ? "⟳ Đang chạy…" : "⟳ Đồng bộ"; }
    if (on) {
      if (runTicker) clearInterval(runTicker);
      runTicker = setInterval(paintOverall, 1000);   // đồng hồ chạy để thấy nó còn sống
    } else {
      if (runTicker) { clearInterval(runTicker); runTicker = null; }
      STATE.current = null; STATE.currentLabel = "";
      setTimeout(() => setProgress(0), 700);
    }
    paintFreshness();
  }

  /**
   * mode:
   *   'smart' | 'full'  — gọi API vault rồi tính lại toàn bộ báo cáo
   *   'retry'           — chỉ retry hàng đợi detail rồi tính lại
   *   'views'           — không gọi API vault, chỉ dựng lại báo cáo từ dữ liệu đang có
   *   { only: 'key' }   — đồng bộ đúng một miền
   */
  async function runSync(mode) {
    if (STATE.running) { toast("Đang có tiến trình đồng bộ", "Chờ xong hoặc bấm Dừng.", "warn"); return; }
    const only = mode && mode.only;
    const onlyMode = (mode && mode.mode) || "smart";
    let list;
    if (only) {
      list = DOMAINS.filter(d => d.key === only);          // bấm chip: chạy đúng miền đó
    } else if (mode === "full" || mode === "retry" || mode === "vaultBacklog") {
      list = DOMAINS.filter(d => d.key === "vault");        // lệnh vault chuyên biệt
    } else {
      list = DOMAINS.filter(d => inScope(d, STATE.scope));  // theo chế độ đang chọn
      if (mode === "views") list = list.filter(d => d.key !== "vault");
    }

    /* Kiểm tra điều kiện đầu vào TRƯỚC, không phụ thuộc miền nào tình cờ ném lỗi.
       Ở chế độ Backlog không có vault nên trước đây chẳng ai phát hiện thiếu token —
       sync sẽ "thành công" với 0 dòng dữ liệu, im lặng và sai. */
    const liveNow = await msg("LIVE_STATUS");
    if (liveNow) STATE.live = {
      lastActivityAt: liveNow.lastActivityAt || 0,
      tokenCount: liveNow.tokenCount || 0,
      accounts: Array.isArray(liveNow.accounts) ? liveNow.accounts : []
    };
    if (!STATE.live.tokenCount) {
      list.filter(d => d.needsApi).forEach(d =>
        markDomain(d.key, false, "Chưa đăng nhập TikiNOW — chưa bắt được account nào", "NO_TOKEN"));
      STATE.lastRun = { at: Date.now(), status: "no_token", durationMs: 0,
                        listed: 0, accounts: 0, accountErrors: 0 };
      store.set({ tnslLastRun: STATE.lastRun });
      paintSetup(); paintOverall();
      toast("Chưa có account nào",
        "Mở TikiNOW Center, đăng nhập và switch qua từng account cần theo dõi — extension tự bắt token, không cần khai báo gì.", "warn");
      return;
    }

    STATE.aborted = false;
    const t0 = Date.now();
    STATE.progress = { step: 0, stepTotal: list.length, done: 0, total: 0, pct: 0, label: "",
                       acc: { index: 0, total: 0, name: "" }, startedAt: t0 };
    setRunning(true);
    const total = list.reduce((s, d) => s + d.weight, 0) || 1;
    let done = 0, failed = 0, noToken = false, timedOut = 0;

    for (const d of list) {
      if (STATE.aborted) break;
      STATE.current = d.key;
      STATE.currentLabel = d.label;
      STATE.progress.step++;
      STATE.progress.label = ""; STATE.progress.done = 0; STATE.progress.total = 0;
      paintFreshness();
      const tDomain = Date.now();
      try {
        /* Watchdog: một miền treo không được phép khoá cả pipeline. */
        const limit = DOMAIN_TIMEOUT_MS[d.key] || DEFAULT_TIMEOUT_MS;
        let timer;
        await Promise.race([
          Promise.resolve(d.run(only ? onlyMode : mode)),
          new Promise((_, rej) => { timer = setTimeout(() => {
            const e = new Error("Quá " + Math.round(limit / 60000) + " phút chưa xong — bỏ qua bước này");
            e.code = "TIMEOUT"; rej(e);
          }, limit); })
        ]).finally(() => clearTimeout(timer));
        markDomain(d.key, true, null, null, Date.now() - tDomain);
      } catch (e) {
        const code = e && e.code;
        if (code === "NO_TOKEN") { noToken = true; break; }
        if (code === "TIMEOUT") timedOut++;
        failed++;
        markDomain(d.key, false, (e && e.message) ? e.message.slice(0, 120) : "lỗi không rõ",
                   null, Date.now() - tDomain);
      }
      done += d.weight;
      setProgress(done / total * 100);
    }

    setRunning(false);
    const dur = Date.now() - t0;

    if (noToken) {
      STATE.lastRun = { at: Date.now(), status: "no_token", durationMs: dur, listed: 0, accounts: 0, accountErrors: 0 };
      store.set({ tnslLastRun: STATE.lastRun });
      paintOverall();
      toast("Chưa có account nào", "Mở TikiNOW Center, đăng nhập và switch qua từng account cần theo dõi — extension tự bắt token, không cần khai báo gì.", "warn");
    } else if (STATE.aborted) {
      toast("Đã dừng đồng bộ", "Dữ liệu đã lấy được vẫn giữ nguyên. An toàn để switch account.", "warn");
    } else if (failed) {
      toast("Đồng bộ xong sau " + elapsed(dur) + ", có " + failed + " phần lỗi",
        (timedOut ? timedOut + " phần quá thời gian. " : "") +
        "Bấm chip màu đỏ trên thanh trạng thái để chạy lại riêng phần đó.", "warn");
    } else {
      const slow = list.map(d => ({ label: d.label, ms: (STATE.freshness[d.key] || {}).ms || 0 }))
        .sort((a, b) => b.ms - a.ms)[0];
      if (only) { /* nạp 1 miền: thanh dữ liệu của màn hình đã hiện kết quả rồi */ }
      else toast("✓ Đồng bộ xong sau " + elapsed(dur),
        (slow && slow.ms ? "Chậm nhất: " + slow.label + " " + elapsed(slow.ms) + ". " : "") +
        "An toàn để switch account.", "ok");
    }
    /* Sau mỗi lần chạy, đọc lại tình trạng account để banner/chip phản ánh đúng
       thực tế ngay lập tức, không phải chờ nhịp autopilot kế tiếp. */
    await refreshAccounts();
    paintOverall();
    if (root.TNSLInsight) root.TNSLInsight.invalidate();
  }

  /* ======================================================================= */
  /*                              AUTOPILOT                                  */
  /*  "Mở TikiNOW là dữ liệu tự về" — không cần bấm nút.                     */
  /*  Điều kiện chạy: phiên TikiNOW còn sống + vault đã quá hạn tươi         */
  /*  + không có tiến trình sync nào đang chạy.                              */
  /* ======================================================================= */
  function msg(type) {
    return new Promise(resolve => {
      try { chrome.runtime.sendMessage({ type }, r => { void chrome.runtime.lastError; resolve(r || null); }); }
      catch (_) { resolve(null); }
    });
  }

  function saveAuto() { store.set({ tnslAutopilot: STATE.auto }); }

  function paintAuto() {
    const b = $("autoBtn");
    if (b) {
      b.classList.toggle("on", !!STATE.auto.enabled);
      b.textContent = STATE.auto.enabled ? "⚡ Auto" : "⚡ Auto tắt";
      b.title = STATE.auto.enabled
        ? "Tự đồng bộ khi phiên TikiNOW đang mở. " + (STATE.autoReason || "")
        : "Auto đang tắt — phải bấm ⟳ Đồng bộ thủ công.";
    }
    const t = $("autoToggle"); if (t) t.checked = !!STATE.auto.enabled;
    const o = $("autoOpenToggle"); if (o) o.checked = !!STATE.auto.autoOpen;
    const i = $("autoInterval"); if (i && document.activeElement !== i) i.value = STATE.auto.intervalMin;
    const s = $("autoState");
    if (s) {
      const live = Date.now() - STATE.live.lastActivityAt < LIVE_WINDOW_MS;
      s.textContent = !STATE.auto.enabled ? "Đang tắt."
        : live ? "Phiên TikiNOW đang mở — tự đồng bộ mỗi " + STATE.auto.intervalMin + " phút."
        : STATE.live.tokenCount
          ? "Chưa thấy hoạt động TikiNOW. Mở TikiNOW Center là auto chạy lại."
          : "Chưa bắt được account nào. Đăng nhập TikiNOW Center trước.";
    }
  }

  function isLive() { return Date.now() - STATE.live.lastActivityAt < LIVE_WINDOW_MS; }
  function vaultAgeMs() {
    const f = STATE.freshness.vault;
    return f && f.at ? Date.now() - f.at : Infinity;
  }

  /* ---------------------------- SỨC KHỎE ACCOUNT ----------------------------
     Switch account trên TikiNOW = extension bắt thêm token cho seller_id mới,
     token cũ vẫn nằm đó nhưng sẽ hết hạn dần. Ba trạng thái:
       live         — vừa có request thật / token vừa làm mới → sync đầy đủ
       idle         — token còn nhưng account không được dùng gần đây
       needs_login  — đã 401/403 và token CHƯA được làm mới kể từ lúc đó
     Autopilot chỉ tự sync account live/idle; account needs_login bị bỏ qua để
     không gõ 401 mỗi 10 phút. Sync thủ công vẫn thử tất cả.                    */
  function accountState(a) {
    const h = a.health || {};
    if (h.needsRelogin && a.tokenAt <= (h.lastErrAt || 0)) return "needs_login";
    if (Date.now() - a.activityAt < LIVE_WINDOW_MS) return "live";
    return "idle";
  }
  function autoSyncableSellers() {
    return STATE.live.accounts.filter(a => accountState(a) !== "needs_login").map(a => a.sellerId);
  }
  function needsLoginList() {
    return STATE.live.accounts.filter(a => accountState(a) === "needs_login");
  }

  const ST_LABEL = {
    live: { t: "Đang mở", c: "t-green" },
    idle: { t: "Không hoạt động", c: "t-blue" },
    needs_login: { t: "Cần đăng nhập lại", c: "t-red" }
  };

  function accName(sid) {
    try {
      const cfg = root.TNSL_CONFIG;
      return (cfg && cfg.accountNames && cfg.accountNames[sid]) || sid;
    } catch (_) { return sid; }
  }

  function paintAccounts() {
    const box = $("acctHealthRows");
    const accs = STATE.live.accounts.slice()
      .sort((a, b) => b.activityAt - a.activityAt);
    if (box) {
      box.innerHTML = accs.length ? accs.map(a => {
        const st = accountState(a);
        const lbl = ST_LABEL[st];
        const h = a.health || {};
        return `<tr>
          <td><b>${accName(a.sellerId)}</b><br><small class="dh-kind">${a.sellerId}</small></td>
          <td><span class="tag ${lbl.c}">${lbl.t}</span></td>
          <td>${a.activityAt ? ageText(Date.now() - a.activityAt) + " trước" : "—"}</td>
          <td>${h.lastOkAt ? ageText(Date.now() - h.lastOkAt) + " trước" : "—"}</td>
          <td>${st === "needs_login"
            ? '<span class="dh-lock">HTTP ' + (h.lastErrCode || "401") + ' — mở TikiNOW và switch sang account này một lần</span>'
            : st === "idle"
              ? '<span class="dh-kind">Token còn lưu, sẽ dùng ở lần sync tới</span>'
              : '<span class="dh-complete">Đang dùng, sync đầy đủ</span>'}</td>
        </tr>`;
      }).join("")
        : '<tr><td colspan="5"><div class="empty">Chưa bắt được account nào. Mở TikiNOW Center và đăng nhập.</div></td></tr>';
    }
    const cnt = $("acctHealthCount");
    if (cnt) cnt.textContent = accs.length + " account · " + accs.filter(a => accountState(a) === "live").length + " đang mở";

    const alert = $("acctAlert");
    const bad = needsLoginList();
    if (alert) {
      alert.hidden = !bad.length;
      alert.textContent = "⚠ " + bad.length + " account cần đăng nhập lại";
      alert.title = bad.map(a => accName(a.sellerId)).join(", ") +
        " — token hết hạn. Mở TikiNOW Center và switch sang từng account này một lần.";
    }
  }

  /* Phát hiện account mới xuất hiện (vừa switch sang account chưa từng thấy). */
  function detectNewAccounts() {
    const now = STATE.live.accounts.map(a => a.sellerId);
    const known = new Set(STATE.knownSellers);
    const fresh = now.filter(s => !known.has(s));
    if (STATE.knownSellers.length && fresh.length) {
      toast("Phát hiện account mới", fresh.map(accName).join(", ") + " — đang kéo dữ liệu ngay.", "ok");
    }
    if (now.length !== STATE.knownSellers.length || fresh.length) {
      STATE.knownSellers = now;
      store.set({ tnslKnownSellers: now });
    }
    return fresh.length > 0;
  }

  async function autopilotTick(trigger) {
    const live = await msg("LIVE_STATUS");
    if (live) STATE.live = {
      lastActivityAt: live.lastActivityAt || 0,
      tokenCount: live.tokenCount || 0,
      accounts: Array.isArray(live.accounts) ? live.accounts : []
    };
    const isNew = detectNewAccounts();
    paintAuto();
    paintAccounts();
    if (root.UnifiedAnalysis || !STATE.auto.enabled || STATE.running) return;
    if (!STATE.live.tokenCount) { STATE.autoReason = "Chưa có account."; return; }
    if (!isLive()) { STATE.autoReason = "Phiên TikiNOW không hoạt động."; return; }

    const due = isNew || vaultAgeMs() >= STATE.auto.intervalMin * 60000;
    if (!due) { STATE.autoReason = "Dữ liệu còn tươi."; return; }

    /* Nếu chưa có dữ liệu account chi tiết (background bản cũ, hoặc chưa kịp ghi),
       KHÔNG lọc gì cả — thà sync đủ còn hơn đứng im. Chỉ chặn khi biết chắc
       mọi account đều cần đăng nhập lại. */
    const accs = STATE.live.accounts;
    const syncable = accs.length ? autoSyncableSellers() : null;
    if (accs.length && !syncable.length) {
      STATE.autoReason = "Mọi account đều cần đăng nhập lại.";
      paintAuto();
      return;
    }

    STATE.autoReason = "Đang tự đồng bộ…";
    toast("Auto-sync", isNew
      ? "Account mới — kéo dữ liệu ngay."
      : trigger === "boot"
        ? "Phát hiện phiên TikiNOW đang mở — đang kéo dữ liệu."
        : "Dữ liệu đã quá " + STATE.auto.intervalMin + " phút — tự làm mới.", "ok");

    /* Chỉ auto-sync account còn dùng được; sync thủ công không đặt hook này. */
    if (syncable && syncable.length < accs.length) root.TNSL_SYNC_FILTER = () => syncable;
    try { await runSync("smart"); }
    finally { root.TNSL_SYNC_FILTER = null; }
    await refreshAccounts();
  }

  async function refreshAccounts() {
    const live = await msg("LIVE_STATUS");
    if (live) STATE.live = {
      lastActivityAt: live.lastActivityAt || 0,
      tokenCount: live.tokenCount || 0,
      accounts: Array.isArray(live.accounts) ? live.accounts : []
    };
    paintAccounts(); paintAuto();
  }

  function startAutopilot() {
    /* Trả lời khi background hỏi "có Hub nào đang mở không".
       Đây mới là cách nhận biết đúng: sendMessage tới trang extension không bị
       Chrome throttle như setInterval ở tab nền. */
    try {
      chrome.runtime.onMessage.addListener((m, sender, sendResponse) => {
        if (m && m.type === "PING_HUB") { sendResponse({ hub: true }); return true; }
        return false;
      });
    } catch (_) {}

    // heartbeat giữ lại thuần để chẩn đoán, không còn dùng để quyết định mở tab
    const beat = () => msg("HUB_HEARTBEAT");
    beat();
    setInterval(beat, HEARTBEAT_MS);

    setInterval(() => autopilotTick("tick"), AUTOPILOT_TICK_MS);
    document.addEventListener("visibilitychange", () => {
      if (!document.hidden) autopilotTick("focus");
    });
    setTimeout(() => autopilotTick("boot"), 1500);
  }

  /* ------------------------------------------------------------- POPOVER */
  function positionPopover(el, anchor) {
    const r = anchor.getBoundingClientRect();
    el.style.display = "block";
    const w = el.offsetWidth;
    el.style.top = (r.bottom + 8) + "px";
    el.style.left = Math.max(10, Math.min(window.innerWidth - w - 10, r.right - w)) + "px";
  }
  function togglePopover(el, anchor) {
    if (!el) return;
    if (el.style.display === "block") { el.style.display = "none"; return; }
    $$(".popover").forEach(p => { p.style.display = "none"; });
    positionPopover(el, anchor);
  }

  /* ------------------------------------------------------- COMMAND PALETTE */
  function paletteItems() {
    const items = [];
    WORKSPACES.forEach(w => w.views.forEach(v => {
      items.push({ ic: "→", label: VIEW_LABEL[v] || v, group: w.label, run: () => goto(v) });
    }));
    items.push({ ic: "⚡", label: "Smart Sync — đơn mới + đơn đổi trạng thái", group: "Đồng bộ", run: () => runSync("smart") });
    items.push({ ic: "✦", label: "Sync Everything — kéo lại toàn bộ lịch sử", group: "Đồng bộ", run: () => runSync("full") });
    items.push({ ic: "↻", label: "Chỉ tính lại báo cáo (không gọi API)", group: "Đồng bộ", run: () => runSync("views") });
    items.push({ ic: "⛑", label: "Retry gaps — chạy lại detail đang lỗi", group: "Đồng bộ", run: () => runSync("retry") });
    DOMAINS.forEach(d => items.push({
      ic: "·", label: "Đồng bộ riêng: " + d.label, group: "Đồng bộ",
      run: () => runSync({ only: d.key })
    }));
    items.push({ ic: "⤓", label: "Excel Full (audit)", group: "Xuất", run: () => root.TikiDataHub && root.TikiDataHub.exportExcel() });
    items.push({ ic: "⤓", label: "Raw JSON.GZ backup", group: "Xuất", run: () => root.TikiDataHub && root.TikiDataHub.backupJson() });
    items.push({ ic: "⤓", label: "Excel của màn hình đang xem", group: "Xuất", run: () => { const b = $("xlsxBtn"); if (b) b.click(); } });
    Object.keys(SCOPES).forEach(k => items.push({
      ic: SCOPES[k].icon, label: "Chế độ " + SCOPES[k].label + " — " + SCOPES[k].desc,
      group: "Chế độ", run: () => applyScope(k, true)
    }));
    items.push({ ic: "⛁", label: "Vault: chỉ kéo đơn backlog (bỏ delivered/canceled, bỏ detail)",
      group: "Đồng bộ", run: () => runSync("vaultBacklog") });
    items.push({ ic: "◐", label: "Đổi giao diện sáng / tối", group: "Hệ thống", run: () => applyTheme(STATE.theme === "dark" ? "light" : "dark") });
    items.push({ ic: "⚙", label: "Chọn account theo dõi", group: "Hệ thống", run: () => { const b = $("acctBtn"); if (b) b.click(); } });
    return items;
  }

  let PAL = [], PAL_SEL = 0;
  function openPalette() {
    const box = $("cmdk"); if (!box) return;
    box.classList.add("open");
    $("cmdkInput").value = "";
    renderPalette("");
    setTimeout(() => $("cmdkInput").focus(), 20);
  }
  function closePalette() { const b = $("cmdk"); if (b) b.classList.remove("open"); }
  function renderPalette(q) {
    q = (q || "").toLowerCase().trim();
    const all = paletteItems();
    PAL = q ? all.filter(i => (i.label + " " + i.group).toLowerCase().indexOf(q) >= 0) : all;
    PAL_SEL = 0;
    const list = $("cmdkList");
    if (!PAL.length) { list.innerHTML = '<div class="cmdk-empty">Không có lệnh nào khớp.</div>'; return; }
    list.innerHTML = PAL.map((i, n) =>
      `<div class="cmdk-item${n === 0 ? " sel" : ""}" data-i="${n}">
         <span class="ci">${i.ic}</span><span></span><span class="cg">${i.group}</span></div>`).join("");
    Array.prototype.forEach.call(list.children, (el, n) => {
      el.children[1].textContent = PAL[n].label;
      el.onclick = () => { closePalette(); PAL[n].run(); };
    });
  }
  function movePalette(delta) {
    const list = $("cmdkList");
    if (!PAL.length) return;
    PAL_SEL = (PAL_SEL + delta + PAL.length) % PAL.length;
    Array.prototype.forEach.call(list.children, (el, n) => el.classList.toggle("sel", n === PAL_SEL));
    const sel = list.children[PAL_SEL];
    if (sel && sel.scrollIntoView) sel.scrollIntoView({ block: "nearest" });
  }

  /* ------------------------------------------------------------- BINDINGS */
  function bind() {
    $$(".ws").forEach(b => b.onclick = () => {
      const ws = WORKSPACES.find(w => w.id === b.dataset.ws);
      if (ws) goto(ws.views[0]);
    });
    $$(".sub").forEach(b => b.onclick = () => goto(b.dataset.view));

    const sync = $("syncNow");
    if (sync) sync.onclick = () => runSync("smart");

    const menuBtn = $("syncMenuBtn"), menu = $("syncMenu");
    if (menuBtn && menu) {
      menuBtn.onclick = e => { e.stopPropagation(); menu.classList.toggle("open"); };
      menu.addEventListener("click", e => {
        const mi = e.target.closest(".mi"); if (!mi) return;
        menu.classList.remove("open");
        const a = mi.dataset.sync;
        if (a === "stop") {
          STATE.aborted = true;
          const s = $("dhStop"); if (s && !s.disabled) s.click();
          toast("Đang dừng…", "Tiến trình sẽ ngắt sau bước hiện tại.", "warn");
        } else if (a === "excel") { const b = $("dhExportExcel"); if (b) b.click(); }
        else if (a === "json") { const b = $("dhBackupJson"); if (b) b.click(); }
        else runSync(a);
      });
    }

    /* Bấm chip: nếu miền đang bị CHẶN vì chưa đăng nhập thì retry là vô nghĩa —
       mở thẳng TikiNOW Center và nói rõ phải làm gì. */
    $$(".fchip").forEach(c => c.onclick = () => {
      const k = c.dataset.domain;
      if (levelOf(k) === "blocked") return openTikiSetup();
      runSync({ only: k });
    });

    $$(".scope-btn").forEach(b => b.onclick = () => applyScope(b.dataset.scope, true));

    const ob = $("setupOpen");
    if (ob) ob.onclick = openTikiSetup;
    const oc = $("setupCheck");
    if (oc) oc.onclick = async () => { await refreshAccounts(); paintSetup(); };

    const alert = $("acctAlert");
    if (alert) alert.onclick = () => goto("datahub");
    const arf = $("acctHealthRefresh");
    if (arf) arf.onclick = () => refreshAccounts();

    const th = $("themeBtn");
    if (th) th.onclick = () => applyTheme(STATE.theme === "dark" ? "light" : "dark");

    const ab2 = $("autoBtn");
    if (ab2) ab2.onclick = () => {
      STATE.auto.enabled = !STATE.auto.enabled;
      saveAuto(); paintAuto();
      toast(STATE.auto.enabled ? "Đã bật Auto-sync" : "Đã tắt Auto-sync",
        STATE.auto.enabled
          ? "Mở TikiNOW Center là dữ liệu tự về, không cần bấm nút."
          : "Từ giờ phải bấm ⟳ Đồng bộ thủ công.",
        STATE.auto.enabled ? "ok" : "warn");
      if (STATE.auto.enabled) autopilotTick("toggle");
    };
    const at2 = $("autoToggle");
    if (at2) at2.onchange = () => { STATE.auto.enabled = at2.checked; saveAuto(); paintAuto(); if (at2.checked) autopilotTick("toggle"); };
    const ao2 = $("autoOpenToggle");
    if (ao2) ao2.onchange = () => { STATE.auto.autoOpen = ao2.checked; saveAuto(); paintAuto(); };
    const ai2 = $("autoInterval");
    if (ai2) ai2.onchange = () => {
      STATE.auto.intervalMin = Math.max(2, Math.min(240, Number(ai2.value) || 10));
      ai2.value = STATE.auto.intervalMin; saveAuto(); paintAuto();
    };

    const st = $("settingsBtn"), sp = $("settingsPanel");
    if (st && sp) st.onclick = e => { e.stopPropagation(); togglePopover(sp, st); };

    const ab = $("acctBtn"), ap = $("acctPanel");
    if (ab && ap) {
      // dashboard.js đã gắn onclick cho acctBtn (nạp danh sách). Chỉ bổ sung định vị.
      const prev = ab.onclick;
      ab.onclick = e => {
        e.stopPropagation();
        if (sp) sp.style.display = "none";
        if (typeof prev === "function") { try { prev.call(ab, e); } catch (_) {} }
        ap.style.display = "none";
        positionPopover(ap, ab);
      };
    }

    document.addEventListener("click", e => {
      if (menu && !menu.contains(e.target) && e.target !== menuBtn) menu.classList.remove("open");
      $$(".popover").forEach(p => {
        if (p.style.display === "block" && !p.contains(e.target) &&
            !(e.target.closest && e.target.closest("#settingsBtn,#acctBtn"))) p.style.display = "none";
      });
    });

    const ck = $("cmdkBtn");
    if (ck) ck.onclick = openPalette;
    const ci = $("cmdkInput");
    if (ci) {
      ci.oninput = () => renderPalette(ci.value);
      ci.onkeydown = e => {
        if (e.key === "ArrowDown") { e.preventDefault(); movePalette(1); }
        else if (e.key === "ArrowUp") { e.preventDefault(); movePalette(-1); }
        else if (e.key === "Enter") { e.preventDefault(); const it = PAL[PAL_SEL]; closePalette(); if (it) it.run(); }
        else if (e.key === "Escape") closePalette();
      };
    }
    const cbox = $("cmdk");
    if (cbox) cbox.onclick = e => { if (e.target === cbox) closePalette(); };

    document.addEventListener("keydown", e => {
      const typing = /^(INPUT|TEXTAREA|SELECT)$/.test((e.target.tagName || ""));
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") { e.preventDefault(); openPalette(); return; }
      if (e.key === "Escape") { closePalette(); $$(".popover").forEach(p => p.style.display = "none"); return; }
      if (typing) return;
      if (e.key === "/") { e.preventDefault(); const g = $("globalSearch"); if (g) g.focus(); return; }
      if (e.key.toLowerCase() === "r" && !e.ctrlKey && !e.metaKey) { e.preventDefault(); runSync("smart"); return; }
      if (e.key >= "1" && e.key <= "5") {
        const ws = WORKSPACES[Number(e.key) - 1];
        if (ws) { e.preventDefault(); goto(ws.views[0]); }
      }
    });
  }

  /* Đổi account đang xem = dữ liệu đang hiển thị thuộc về tập account cũ.
     Đánh dấu mọi miền có gọi API là chưa nạp, để từng màn hình nói thẳng
     "cần nạp lại" thay vì hiển thị số của account khác mà không báo gì. */
  function watchAccountChange() {
    try {
      chrome.storage.onChanged.addListener((changes, area) => {
        if (area !== "local" || !changes.accountSel) return;
        DOMAINS.filter(d => d.needsApi).forEach(d => {
          const f = STATE.freshness[d.key];
          if (f) { f.at = 0; f.err = null; f.code = null; }
        });
        store.set({ tnslFreshness: STATE.freshness });
        paintFreshness();
        toast("Đã đổi account đang xem",
          "Dữ liệu cũ thuộc về account trước nên đã bỏ đánh dấu. Bấm ⤓ Nạp dữ liệu trên màn hình bạn cần.", "warn");
      });
    } catch (_) {}
  }

  /* ------------------------------------------------------------- BOOTSTRAP */
  async function boot() {
    const saved = await store.get(["tnslTheme", "tnslFreshness", "tnslLastView",
                                   "tnslAutopilot", "tnslKnownSellers", "tnslLastRun", "tnslScope"]);
    STATE.lastRun = saved.tnslLastRun || null;
    applyTheme(saved.tnslTheme || "dark");
    STATE.freshness = saved.tnslFreshness || {};
    STATE.knownSellers = Array.isArray(saved.tnslKnownSellers) ? saved.tnslKnownSellers : [];
    if (saved.tnslAutopilot) {
      STATE.auto = Object.assign(STATE.auto, saved.tnslAutopilot);
      /* Migration 2.4.2: bản trước bật sẵn "tự mở tab" và nó gây phiền —
         mỗi lần tìm kiếm trên TikiNOW lại nhảy ra một tab. Tắt một lần cho
         người dùng cũ; ai muốn vẫn bật lại được trong Cài đặt. */
      if (!saved.tnslAutopilot.v || saved.tnslAutopilot.v < 2) {
        STATE.auto.autoOpen = false;
        STATE.auto.v = 2;
        store.set({ tnslAutopilot: STATE.auto });
      }
      /* Migration 2.5: chuyển sang "chỉ kéo khi có nhu cầu" — tắt tự kéo nền.
         Mỗi màn hình có nút nạp riêng; ai muốn tự kéo vẫn bật lại được. */
      if (!saved.tnslAutopilot.v || saved.tnslAutopilot.v < 3) {
        STATE.auto.enabled = false;
        STATE.auto.v = 3;
        store.set({ tnslAutopilot: STATE.auto });
      }
    } else {
      STATE.auto.v = 3;
      store.set({ tnslAutopilot: STATE.auto });
    }
    bind();
    applyScope(saved.tnslScope || "backlog", false);
    paintAuto();

    // đồng bộ ngược: khi Data Hub tự chạy sync của nó, cập nhật độ tươi vault
    if (root.TikiDataHub) {
      ["syncSmart", "syncFull", "retryGaps"].forEach(fn => {
        const orig = root.TikiDataHub[fn];
        if (typeof orig !== "function") return;
        root.TikiDataHub[fn] = function () {
          return Promise.resolve(orig.apply(this, arguments))
            .then(r => { markDomain("vault", true, null, null); return r; })
            .catch(e => {
              const code = e && e.code;
              markDomain("vault", false,
                code === "NO_TOKEN" ? "Chưa đăng nhập TikiNOW — chưa bắt được account nào"
                                    : (e && e.message),
                code || null);
              throw e;
            });
        };
      });
    }

    const start = saved.tnslLastView && VIEW_DOMAIN[saved.tnslLastView] ? saved.tnslLastView : "backlog";
    goto(start);
    paintFreshness();
    setInterval(paintFreshness, 60000);

    guardAutoLoad();
    /* Đọc tình trạng account NGAY, đừng để banner "chưa có account" hiện nhầm
       trong lúc chờ nhịp autopilot đầu tiên. */
    await refreshAccounts();
    startAutopilot();
    watchAccountChange();

    const never = DOMAINS.every(d => !(STATE.freshness[d.key] || {}).at);
    const st = await msg("LIVE_STATUS");
    const hasAccount = st && st.tokenCount > 0;
    /* Chưa có account: banner cố định đã nói rõ rồi, không cần toast chồng lên. */
    if (!hasAccount) {
      STATE.live.tokenCount = 0;
      paintSetup();
    } else if (never && !STATE.auto.enabled) {
      toast("Chưa có dữ liệu", "Bấm ⟳ Đồng bộ (hoặc phím R) để chạy Smart Sync lần đầu.", "warn");
    }
    if (root.UnifiedAnalysis) { root.TNSLShell.ready = true; root.dispatchEvent(new Event("unified-analysis-ready")); }
  }

  root.TNSLShell = { goto, runSync, toast, paintFreshness, markDomain, autopilotTick, guardAutoLoad,
                     STATE, WORKSPACES, DOMAINS };

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();
})(self);
