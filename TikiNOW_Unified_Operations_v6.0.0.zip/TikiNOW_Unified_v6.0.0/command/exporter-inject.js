/* =============================================================
 * TikiNOW API Observer v2.2 — MAIN world
 * Quan sát fetch + XMLHttpRequest của chính TikiNOW Center để lập API catalog.
 * Chỉ gửi metadata/schema; KHÔNG gửi Authorization hay response body.
 * ============================================================= */
(function () {
  "use strict";
  const API_HOST = "api.tikinow.vn";
  const MAX_SCHEMA_PATHS = 500;

  function isApiUrl(url) {
    try { return new URL(String(url), location.href).hostname === API_HOST; }
    catch (_) { return false; }
  }

  function bodyText(body) {
    try {
      if (body == null) return "";
      if (typeof body === "string") return body.slice(0, 65536);
      if (body instanceof URLSearchParams) return body.toString().slice(0, 65536);
      if (body instanceof FormData) {
        const o = {};
        body.forEach((v, k) => { o[k] = typeof v === "string" ? v : `[File:${v.name || "file"}]`; });
        return JSON.stringify(o).slice(0, 65536);
      }
      return "";
    } catch (_) { return ""; }
  }

  function sellerFrom(url, requestBody) {
    try {
      const u = new URL(String(url), location.href);
      const q = u.searchParams.get("filters.seller_id")
        || u.searchParams.get("seller_id")
        || u.searchParams.get("sellerId");
      if (q) return q;
    } catch (_) {}
    try {
      const o = JSON.parse(requestBody || "{}");
      return o.seller_id || o.sellerId || (o.filters && o.filters.seller_id) || null;
    } catch (_) { return null; }
  }

  function normalizePath(url) {
    try {
      const u = new URL(String(url), location.href);
      return u.pathname
        .replace(/\/orders\/(?!counts(?:\/|$)|search(?:\/|$)|export(?:\/|$))[^/]+(?=\/|$)/i, "/orders/:order_code")
        .replace(/\/return-shipments\/[^/]+(?=\/|$)/i, "/return-shipments/:shipment_id")
        .replace(/\/[0-9]{5,}(?=\/|$)/g, "/:id")
        .replace(/\/[0-9a-f]{8}-[0-9a-f-]{20,}(?=\/|$)/ig, "/:uuid");
    } catch (_) { return String(url || "").split("?")[0]; }
  }

  function bodyPagingMeta(requestBody) {
    const result = { pageBodyPath: null, sizeBodyPath: null };
    if (!requestBody) return result;
    try {
      const body = JSON.parse(requestBody);
      const read = path => path.split(".").reduce((v, k) => v && typeof v === "object" ? v[k] : undefined, body);
      const pages = ["page.page_number", "pagination.page", "page_number", "pageNumber", "page_index", "pageIndex", "page"];
      const sizes = ["page.per_page", "page.page_size", "pagination.per_page", "per_page", "page_size", "pageSize", "limit"];
      result.pageBodyPath = pages.find(p => ["number", "string"].includes(typeof read(p))) || null;
      result.sizeBodyPath = sizes.find(p => ["number", "string"].includes(typeof read(p))) || null;
    } catch (_) {}
    return result;
  }

  function pagingMeta(json, url, requestBody) {
    const pg = json && (json.paging || json.pagination || (json.meta && json.meta.pagination)) || {};
    let u;
    try { u = new URL(String(url), location.href); } catch (_) { u = null; }
    const pageCandidates = ["page.page_number", "page_number", "page", "pageIndex", "page_index"];
    const sizeCandidates = ["page.per_page", "page.page_size", "per_page", "page_size", "limit"];
    const pageParam = u ? pageCandidates.find(k => u.searchParams.has(k)) || null : null;
    const sizeParam = u ? sizeCandidates.find(k => u.searchParams.has(k)) || null : null;
    return {
      total: pg.total ?? pg.total_count ?? pg.count ?? null,
      perPage: pg.per_page ?? pg.page_size ?? pg.limit ?? null,
      totalPage: pg.total_page ?? pg.total_pages ?? pg.page_count ?? null,
      pageParam,
      sizeParam,
      ...bodyPagingMeta(requestBody)
    };
  }

  function isNumericObject(v) {
    return !!(v && typeof v === "object" && !Array.isArray(v)
      && Object.keys(v).some(k => /^\d+$/.test(k)));
  }

  function mediaShapeHint(value, path) {
    if (/(?:video|media|attachment|evidence|proof|recording|camera|packing|unbox|unpack|open.?box|khui|dong.?goi)/i.test(path || "")) return true;
    const seen = new Set();
    let visited = 0, hit = false;
    function walk(v, depth) {
      if (hit || v == null || typeof v !== "object" || depth > 6 || visited++ > 600 || seen.has(v)) return;
      seen.add(v);
      if (Array.isArray(v)) { v.slice(0, 5).forEach(x => walk(x, depth + 1)); return; }
      for (const [key, child] of Object.entries(v).slice(0, 120)) {
        if (/(?:video(?:_url|s)?|packing.?video|unbox(?:ing)?.?video|unpack.?video|open.?box.?video|evidence.?video|recording.?url|clip.?url)/i.test(key)) { hit = true; return; }
        walk(child, depth + 1);
      }
    }
    walk(value, 0);
    return hit;
  }

  function classify(json, url) {
    if (!json || typeof json !== "object") return "unknown";
    let path = "";
    let parsed;
    try { parsed = new URL(String(url), location.href); path = parsed.pathname; } catch (_) {}
    const orderPart = (path.match(/\/orders\/([^/]+)/i) || [])[1] || "";
    const reserved = /^(counts?|search|exports?|batch|summary|statistics)$/i.test(orderPart);
    const queryDetail = /\/orders\/(?:detail|view)\/?$/i.test(path)
      && parsed && ["order_code", "order_id", "id", "code"].some(k => parsed.searchParams.has(k));
    if (mediaShapeHint(null, path)) return "media";
    if ((orderPart && !reserved) || queryDetail || /\/return-shipments\/[^/]+(?:\/|$)/i.test(path)) return "detail";
    const d = json.data !== undefined ? json.data : json;
    const orderObject = d && typeof d === "object" && !Array.isArray(d)
      ? (d.order && typeof d.order === "object" ? d.order : d)
      : null;
    if (orderObject && (orderObject.order_code || orderObject.ref_code || orderObject.order_id)
      && (orderObject.status || orderObject.sub_status || orderObject.histories || orderObject.history || orderObject.timeline || orderObject.items)) return "detail";
    if (mediaShapeHint(json, path)) return "media";
    if (Array.isArray(d) || isNumericObject(d)) return "list";
    if (json.paging || json.pagination) return "list";
    return d && typeof d === "object" ? "report" : "scalar";
  }

  function collectSchema(value) {
    const out = new Set();
    function walk(v, path, depth) {
      if (out.size >= MAX_SCHEMA_PATHS || depth > 7) return;
      if (v == null) { if (path) out.add(`${path}:null`); return; }
      if (Array.isArray(v)) {
        if (path) out.add(`${path}:array`);
        if (v.length) walk(v[0], path ? `${path}[]` : "[]", depth + 1);
        return;
      }
      if (typeof v === "object") {
        if (path) out.add(`${path}:object`);
        Object.keys(v).slice(0, 120).forEach(k => walk(v[k], path ? `${path}.${k}` : k, depth + 1));
        return;
      }
      if (path) out.add(`${path}:${typeof v}`);
    }
    walk(value, "", 0);
    return Array.from(out);
  }

  function emit(url, method, requestBody, requestContentType, status, json) {
    try {
      const pg = pagingMeta(json, url, requestBody);
      const data = json && json.data !== undefined ? json.data : json;
      const responseKeys = data && typeof data === "object" ? Object.keys(data).slice(0, 200) : [];
      window.postMessage({
        __tiki_ops_api_v2: true,
        url: new URL(String(url), location.href).toString(),
        method: String(method || "GET").toUpperCase(),
        pathKey: normalizePath(url),
        sellerId: sellerFrom(url, requestBody),
        kind: classify(json, url),
        status: Number(status || 0),
        requestBody: requestBody || "",
        requestContentType: requestContentType || "",
        responseKeys,
        schemaPaths: collectSchema(json),
        total: pg.total,
        perPage: pg.perPage,
        totalPage: pg.totalPage,
        pageParam: pg.pageParam,
        sizeParam: pg.sizeParam,
        pageBodyPath: pg.pageBodyPath,
        sizeBodyPath: pg.sizeBodyPath,
        at: Date.now(),
        title: document.title || "",
        /* v2.8: route SPA tại thời điểm bắt — để biết chính xác
           mục nào của TikiNOW Center đã được học. */
        route: String(location.hash || "").slice(0, 160)
      }, "*");
    } catch (_) {}
  }

  const originalFetch = window.fetch;
  if (originalFetch && !originalFetch.__tikiOpsV2) {
    const wrapped = function (input, init) {
      const url = input && typeof input === "object" && "url" in input ? input.url : input;
      const method = (init && init.method) || (input && input.method) || "GET";
      const reqBody = bodyText(init && init.body);
      let reqBodyPromise = Promise.resolve(reqBody);
      if (!reqBody && input && typeof input === "object" && typeof input.clone === "function" && !/^(GET|HEAD)$/i.test(method)) {
        try { reqBodyPromise = input.clone().text().then(x => String(x || "").slice(0, 65536)).catch(() => ""); }
        catch (_) {}
      }
      let reqType = "";
      try {
        const h = new Headers((init && init.headers) || (input && input.headers) || {});
        reqType = h.get("content-type") || "";
      } catch (_) {}
      const promise = originalFetch.apply(this, arguments);
      if (url && isApiUrl(url)) {
        promise.then(res => {
          try {
            Promise.all([res.clone().json(), reqBodyPromise])
              .then(([json, capturedBody]) => emit(url, method, capturedBody, reqType, res.status, json))
              .catch(() => {});
          } catch (_) {}
        }).catch(() => {});
      }
      return promise;
    };
    wrapped.__tikiOpsV2 = true;
    window.fetch = wrapped;
  }

  const XHR = window.XMLHttpRequest;
  if (XHR && !XHR.prototype.__tikiOpsV2) {
    const originalOpen = XHR.prototype.open;
    const originalSend = XHR.prototype.send;
    const originalSetHeader = XHR.prototype.setRequestHeader;

    XHR.prototype.open = function (method, url) {
      this.__tikiOpsMeta = { method: method || "GET", url, headers: {} };
      return originalOpen.apply(this, arguments);
    };

    XHR.prototype.setRequestHeader = function (name, value) {
      if (this.__tikiOpsMeta) this.__tikiOpsMeta.headers[String(name).toLowerCase()] = String(value);
      return originalSetHeader.apply(this, arguments);
    };

    XHR.prototype.send = function (body) {
      const meta = this.__tikiOpsMeta;
      if (meta && meta.url && isApiUrl(meta.url)) {
        const reqBody = bodyText(body);
        this.addEventListener("loadend", function () {
          try {
            let json;
            if (this.responseType === "json") json = this.response;
            else {
              if (!this.responseText) return;
              json = JSON.parse(this.responseText);
            }
            if (!json || typeof json !== "object") return;
            emit(meta.url, meta.method, reqBody, meta.headers["content-type"] || "", this.status, json);
          } catch (_) {}
        }, { once: true });
      }
      return originalSend.apply(this, arguments);
    };

    XHR.prototype.__tikiOpsV2 = true;
  }
})();
