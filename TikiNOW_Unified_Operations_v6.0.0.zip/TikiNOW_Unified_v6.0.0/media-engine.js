/* Media parser adapted from Command Center; exact URLs retained, seller/order scoping added. */
(function(root){'use strict';
const API_BASE='https://api.tikinow.vn';
const text=v=>v==null?'':String(v);
const stripVN=v=>text(v).normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/g,'d').toLowerCase();
const pick=(o,paths,fallback)=>{for(const p of paths){const v=p.split('.').reduce((a,k)=>a==null?undefined:a[k],o);if(v!=null&&v!=='')return v}return fallback};
function scoped(value, code, sid, depth, seen){
 if(value==null||typeof value!=='object')return value;
 if(depth>24)return null;
 if(value.order_code!=null&&String(value.order_code)!==String(code))return null;
 if(value.seller_id!=null&&String(value.seller_id)!==String(sid))return null;
 if(seen.has(value))return seen.get(value);
 const out=Array.isArray(value)?[]:{};seen.set(value,out);
 for(const [k,v] of Object.entries(value))out[k]=scoped(v,code,sid,depth+1,seen);
 return out;
}
  const VIDEO_FILE_RE = /\.(?:mp4|m4v|mov|webm|m3u8|avi|mkv|3gp|mpeg|mpg)(?:$|[?#])/i;
  const IMAGE_FILE_RE = /\.(?:jpe?g|png|gif|webp|svg|bmp|heic)(?:$|[?#])/i;
  const MEDIA_CONTEXT_RE = /(?:video|media|clip|record|recording|attachment|evidence|proof|camera|cctv|packing|package|unbox|unpack|open.?box|khui|dong.?goi|mo.?hang)/i;

  function httpVideoUrl(value, context, parent, baseUrl) {
    const raw = text(value).trim();
    if (!/^(?:https?:)?\/\//i.test(raw) && !/^\//.test(raw)) return "";
    let url = raw.startsWith("//") ? `https:${raw}` : raw;
    if (/^\//.test(url)) {
      try { url = new URL(url, baseUrl || API_BASE).toString(); }
      catch (_) { return ""; }
    }
    if (IMAGE_FILE_RE.test(url)) return "";
    const mime = text(parent && pick(parent, ["mime_type", "mimeType", "content_type", "contentType", "type"], ""));
    const obviousVideo = VIDEO_FILE_RE.test(url) || /video|mpegurl/i.test(mime);
    if (!obviousVideo && /(?:thumbnail|thumb|image|photo|poster|preview|avatar|icon|cover)(?:_|\.|\[|\s|$)/i.test(context)) return "";
    if (!obviousVideo && !MEDIA_CONTEXT_RE.test(context)) return "";
    try {
      const u = new URL(url);
      return /^https?:$/i.test(u.protocol) ? u.toString() : "";
    } catch (_) { return ""; }
  }

  function videoCategory(value) {
    const hint = stripVN(value).replace(/[_/.-]+/g, " ");
    if (/(?:unbox|unpack|open\s*box|khui|mo\s*(?:hop|hang|kien)|khach\s*mo|kiem\s*tra\s*hang)/i.test(hint)) return "unboxing";
    if (/(?:video\s*pack|packing|packaged?|dong\s*goi|fulfill(?:ment)?\s*video|warehouse\s*video)/i.test(hint)) return "packing";
    return "other";
  }

  function canonicalVideoUrl(value) {
    try {
      const u = new URL(value);
      Array.from(u.searchParams.keys()).forEach(key => {
        if (/(?:authorization|auth|access[_-]?key|token|signature|sig|expires?|credential|policy|key-pair-id|x-amz-|x-goog-)/i.test(key)) u.searchParams.delete(key);
      });
      u.searchParams.sort();
      u.hash = "";
      return u.toString();
    } catch (_) { return text(value); }
  }

  function extractVideos(detail, listOrder, mediaPayloads) {
    const roots = [];
    if (detail && typeof detail === "object") roots.push({ value: detail, source: "order_detail", endpoint: "" });
    if (listOrder && typeof listOrder === "object") roots.push({ value: listOrder, source: "order_list", endpoint: "" });
    (Array.isArray(mediaPayloads) ? mediaPayloads : []).forEach((entry, index) => {
      const wrapped = entry && typeof entry === "object" && Object.prototype.hasOwnProperty.call(entry, "payload");
      roots.push({
        value: wrapped ? entry.payload : entry,
        source: text(wrapped && entry.source || "media_api"),
        endpoint: text(wrapped && (entry.endpoint || entry.route || entry.url) || ""),
        requestUrl: text(wrapped && (entry.request_url || entry.requestUrl) || ""),
        capturedAt: text(wrapped && entry.captured_at || ""),
        rootIndex: index
      });
    });

    const found = new Map();
    const seenObjects = new Set();
    let visited = 0;
    function add(value, path, parent, meta) {
      const siblingHint = parent && typeof parent === "object" ? [
        pick(parent, ["type", "kind", "category", "video_type", "media_type"], ""),
        pick(parent, ["title", "label", "name", "description", "note"], "")
      ].join(" ") : "";
      const context = `${path} ${siblingHint} ${meta.endpoint || ""}`;
      const url = httpVideoUrl(value, context, parent, meta.requestUrl);
      if (!url) return;
      const category = videoCategory(context);
      const row = {
        category,
        category_label: category === "packing" ? "Video đóng gói" : category === "unboxing" ? "Video khui hàng" : "Video khác",
        url,
        label: text(parent && pick(parent, ["title", "label", "name", "description", "file_name", "filename"], "")),
        created_at_api: text(parent && pick(parent, ["created_at", "recorded_at", "uploaded_at", "event_at", "timestamp", "time"], "")),
        provider: text(parent && pick(parent, ["provider", "source", "vendor", "storage", "camera"], "")),
        source: meta.source,
        source_path: path,
        source_endpoint: meta.endpoint || "",
        source_request_url: meta.requestUrl || "",
        captured_at: meta.capturedAt || ""
      };
      const key = canonicalVideoUrl(url);
      const current = found.get(key);
      if (!current || (current.category === "other" && category !== "other") || (current.source !== "media_api" && meta.source === "media_api")) found.set(key, row);
    }
    function walk(value, path, depth, meta, parent) {
      if (value == null || depth > 10 || visited++ > 12000) return;
      if (typeof value === "string") { add(value, path, parent, meta); return; }
      if (typeof value !== "object" || seenObjects.has(value)) return;
      seenObjects.add(value);
      if (Array.isArray(value)) {
        value.forEach((child, i) => walk(child, `${path}[${i}]`, depth + 1, meta, value));
        return;
      }
      Object.entries(value).forEach(([key, child]) => walk(child, path ? `${path}.${key}` : key, depth + 1, meta, value));
    }
    roots.forEach((entry, i) => walk(entry.value, entry.source || `root${i}`, 0, entry, null));
    return Array.from(found.values()).sort((a, b) => {
      const rank = { packing: 0, unboxing: 1, other: 2 };
      return (rank[a.category] - rank[b.category]) || text(a.created_at_api).localeCompare(text(b.created_at_api));
    });
  }


root.UnifiedMedia={extract:(detail,list,payloads,code,sid)=>extractVideos(scoped(detail,code,sid,0,new WeakMap()),scoped(list,code,sid,0,new WeakMap()),(payloads||[]).map(v=>Object.assign({},v,{payload:scoped(v.payload,code,sid,0,new WeakMap())}))).filter(v=>{try{const u=new URL(v.url);return !u.username&&!u.password}catch(_){return false}})};
})(window);
