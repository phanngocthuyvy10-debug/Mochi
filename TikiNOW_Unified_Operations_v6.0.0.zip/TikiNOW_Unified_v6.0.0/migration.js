/* Explicit local import from Command Center JSON/JSON.GZ backups. Never imports credentials. */
(function(root){
 'use strict';
 function convertOrder(old){
  if(!old||typeof old!=='object')return null;
  const sid=String(old.seller_id||''),row=old.raw_list||old.raw_detail;
  if(!/^\d+$/.test(sid)||!row||!row.order_code)return null;
  const code=String(row.order_code),owner=row.seller_info&&row.seller_info.seller_id||row.seller_id;
  if(owner!=null&&String(owner)!==sid)return null;
  const key='orders|'+sid+'|'+code;
  const item={key,sk:sid+'|orders',kind:'orders',sid,acc:String(old.account_name||sid),row};
  const detail=old.raw_detail,detailOwner=detail&&(detail.seller_info&&detail.seller_info.seller_id||detail.seller_id);
  const validDetail=detail&&String(detail.order_code)===code&&(detailOwner==null||String(detailOwner)===sid);
  const sources=(Array.isArray(old.raw_media)?old.raw_media:[]).filter(x=>x&&x.payload&&typeof x.payload==='object').map(x=>({id:String(x.endpoint||x.source||'Command Center import'),ok:true,payload:x.payload}));
  return {item,detail:validDetail?{key,detail,at:Date.now(),extra:{evidenceSources:sources},evAt:sources.length?Date.now():0}:null};
 }
 async function importFile(file){
  if(BUSY)throw new Error('Đợi lượt đồng bộ hiện tại kết thúc trước khi nhập dữ liệu.');
  let stream=file.stream();if(/\.gz$/i.test(file.name))stream=stream.pipeThrough(new DecompressionStream('gzip'));
  const data=JSON.parse(await new Response(stream).text());
  if(!data||!Array.isArray(data.orders))throw new Error('Chọn backup RAW JSON/JSON.GZ được xuất từ Command Center.');
  BUSY=true;setBusyUI(true);let added=0,skipped=0;const existing=new Set(ROWS.orders.map(x=>x.key));
  try{
   for(let i=0;i<data.orders.length;i+=400){
    const items=[],details=[];
    for(const old of data.orders.slice(i,i+400)){
     const v=convertOrder(old);if(!v||existing.has(v.item.key)){skipped++;continue;}
     existing.add(v.item.key);items.push(v.item);if(v.detail)details.push(v.detail);
    }
    await storePut('rows',items);ROWS.orders.push(...items);added+=items.length;
    if(details.length){await storePut('details',details);details.forEach(d=>DET.set(d.key,d));}
    toast('Đang nhập dữ liệu cũ: '+nf(added)+' đơn mới · '+nf(skipped)+' dòng bỏ qua / đã có','',0);
    await sleep(0);
   }
   // Catalog is metadata only; background validates host and scrubs secret fields.
   for(const record of (Array.isArray(data.catalog)?data.catalog:[])){
    try{await chrome.runtime.sendMessage({type:'SAVE_API_CAPTURE',record});}catch(_){}
   }
   toast('Đã nhập '+nf(added)+' đơn · giữ nguyên '+nf(skipped)+' dòng đã có / không hợp lệ','ok',9000);
   return {added,skipped};
  }finally{BUSY=false;setBusyUI(false);await refreshAccounts();rebuild();render();}
 }
 root.UnifiedMigration={convertOrder,importFile};
})(window);
