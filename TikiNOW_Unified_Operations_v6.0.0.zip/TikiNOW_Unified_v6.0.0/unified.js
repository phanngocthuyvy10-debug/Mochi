/* A single shell and canonical order cache, with lazy analytic modules. */
(function (root) {
  'use strict';
  const views = {
    backlog: ['Backlog & cảnh báo', 'Phân tích đơn đang mở từ dữ liệu đã lưu'],
    flow: ['Luồng xử lý', 'Công đoạn, tồn và dự báo theo dữ liệu đã lưu'],
    prod: ['Năng suất kho', 'Năng suất trên phạm vi dữ liệu đã đồng bộ'],
    cycle: ['Cycle-time', 'Chỉ tính từ các mốc API đã có; thiếu mốc không được coi là hoàn tất'],
    outcome: ['Kết quả giao', 'Kết quả của tập đơn đã tải, không thay số tổng toàn bộ Center'],
    trend: ['Xu hướng theo ngày', 'Cơ cấu trạng thái hiện tại, nhóm theo ngày tạo đơn đã đồng bộ'],
    fields: ['Trường dữ liệu', 'Quét mẫu tối đa 1.500 đơn trong phạm vi tài khoản đang chọn'],
    endpoints: ['Catalog API', 'Endpoint và schema đã quan sát khi dùng TikiNOW Center'],
    sections: ['Mục Center đã học', 'Nạp tài nguyên GET đã học khi bạn yêu cầu'],
    fusion: ['Nối chéo dữ liệu', 'Nối tài nguyên API đã học với đơn đã lưu'],
    sitemap: ['Sơ đồ Center', 'Danh mục màn hình và trạng thái các API đã quan sát']
  };
  let revision = 0, framePromise, activeRoute, initialized = false;
  function snapshot() {
    const items = ACCF ? ROWS.orders.filter(x => String(x.sid) === String(ACCF)) : ROWS.orders;
    return { revision, items, details: DET, accounts: ACCOUNTS, selected: ACCF || '', metadata: META, settings: S, busy: BUSY };
  }
  function paintScope() {
    const data = snapshot(), sids = new Set(data.items.map(x => String(x.sid)));
    const scopes = [...sids].map(sid => { const m = META[sid + '|orders']; return m ? m.mode === 'open' ? 'đơn đang mở' : (m.from + ' → ' + m.to + (m.orderStatus === 'delivered' ? ' · chỉ hoàn tất' : ' · mọi trạng thái')) : 'nhập / tra cứu riêng lẻ, chưa có phạm vi đồng bộ'; });
    const box = document.querySelector('#analysisScope');
    box.innerHTML = '<p><b>' + nf(data.items.length) + ' đơn đã lưu</b> · ' + esc([...new Set(scopes)].join('; ') || 'chưa có dữ liệu') + '. Phân tích dùng chung dữ liệu, không tải lại đơn. Mở phần Đơn hàng để thay phạm vi.</p><button class="btn ghost sm" id="recomputeAnalysis">Tính lại từ dữ liệu đã lưu</button>';
    box.querySelector('button').onclick = () => show(CURRENT, true);
  }
  function loadFrame() {
    if (!framePromise) framePromise = new Promise((resolve, reject) => {
      const frame = document.querySelector('#analysisFrame');
      frame.onload = async () => {
        const started = Date.now();
        while (Date.now() - started < 15000) {
          if (frame.contentWindow.UnifiedAnalysis && frame.contentWindow.TNSLShell && frame.contentWindow.TNSLShell.ready) return resolve(frame.contentWindow);
          await new Promise(r => setTimeout(r, 40));
        }
        reject(new Error('Mô-đun phân tích chưa khởi động. Tải lại khi không còn đồng bộ.'));
      };
      frame.src = 'command/dashboard.html?unified=1';
    });
    return framePromise;
  }
  async function show(route, force) {
    const key = route.replace(/^advanced-/, ''); if (!views[key]) return;
    activeRoute = route;
    document.querySelector('#view').style.display = 'none'; document.querySelector('#advancedPanel').classList.remove('hidden');
    document.querySelectorAll('#nav button').forEach(b => b.classList.toggle('active', b.dataset.view === route));
    document.querySelector('#crumb').textContent = views[key][0]; document.querySelector('#sub').textContent = views[key][1];
    paintScope();
    try {
      const child = await loadFrame(); if (activeRoute !== route || CURRENT !== route) return;
      await child.UnifiedAnalysis.open(key, !!force);
    } catch (e) { toast(e.message, 'bad', 9000); }
  }
  function onRoute(route) {
    activeRoute = route;
    if (!route.startsWith('advanced-')) {
      document.querySelector('#advancedPanel').classList.add('hidden'); document.querySelector('#view').style.display = '';
    }
  }
  async function syncOrders() {
    if (BUSY) throw new Error('Lượt đồng bộ đang chạy.');
    await sync(ACCF || undefined, ['orders']);
    if (CURRENT.startsWith('advanced-')) await show(CURRENT, true);
  }
  async function exportAnalysis() { const child = await loadFrame(); return child.TikiDataHub.exportExcel(); }
  function changed() { revision++; if (CURRENT.startsWith('advanced-')) paintScope(); }
  function booted() { initialized = true; }
  root.UnifiedHub = { snapshot, show, changed, onRoute, syncOrders, exportAnalysis, views, booted, get initialized() { return initialized; } };
  chrome.runtime.onMessage.addListener((msg, sender, respond) => { if (msg && msg.type === 'PING_HUB') { respond({ hub: true }); return false; } });
})(window);
