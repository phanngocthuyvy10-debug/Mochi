/* TikiNOW KPI 2026. Source: supplied service indicators PDF, pp.6–16.
 * All arithmetic uses UTC+7 explicitly, regardless of computer timezone.
 * A missing actual timestamp on a completed stage is UNKNOWN, never auto-pass.
 */
(function(root){
'use strict';
const DAY=86400000, SHIFT=7*3600000;
const get=(o,p)=>p.split('.').reduce((v,k)=>v==null?undefined:v[k],o);
const pick=(o,ps)=>{for(const p of ps){const v=get(o,p);if(v!==undefined&&v!==null&&v!=='')return v;}return null;};
function date(v){
 if(v==null||v==='')return null;if(v instanceof Date)return isNaN(v)?null:v;
 if(typeof v==='number'){const d=new Date(v<1e12?v*1000:v);return isNaN(d)?null:d;}
 let s=String(v).trim();if(/^0001-/.test(s))return null;
 if(/^\d{4}-\d\d-\d\d$/.test(s))s+='T00:00:00+07:00';
 else if(/^\d{4}-\d\d-\d\d[ T]\d\d:\d\d(?::\d\d(?:\.\d+)?)?$/.test(s))s=s.replace(' ','T')+'+07:00';
 const d=new Date(s);return isNaN(d)?null:d;
}
const local=d=>new Date(+date(d)+SHIFT);
const ymd=d=>local(d).toISOString().slice(0,10);
const midnight=d=>date(ymd(d));
const at=(d,h,m=0,s=0)=>new Date(+midnight(d)+h*3600000+m*60000+s*1000);
const next=d=>new Date(+midnight(d)+DAY);
function working(d,cfg={},office=false){
 const day=local(d).getUTCDay(),key=ymd(d);
 return day!==0&&!(office&&day===6)&&!['01-01','04-30','05-01','09-02'].includes(key.slice(5))&&!(cfg.holidays||[]).includes(key);
}
function roll(d,cfg={},office=false){let t=date(d);for(let i=0;!working(t,cfg,office);i++){if(i>370)throw Error('Lịch nghỉ không hợp lệ');t=new Date(+t+DAY);}return t;}
function addDays(d,n,cfg={},office=false){let t=midnight(d);while(n>0){t=next(t);if(working(t,cfg,office))n--;}return roll(t,cfg,office);}
const eod=(d,n,cfg,office)=>at(addDays(d,n,cfg,office),23,59,59);
function addMinutes(d,n,cfg={}){
 let t=date(d);for(let guard=0;n>0;guard++){
  if(guard>10000)throw Error('Không tính được giờ làm việc');
  t=roll(t,cfg);if(t<at(t,8))t=at(t,8);
  if(t>=at(t,18)){t=at(roll(next(t),cfg),8);continue;}
  const avail=(at(t,18)-t)/60000;if(n<=avail)return new Date(+t+n*60000);n-=avail;t=at(roll(next(t),cfg),8);
 }return t;
}
const STATUS={new:'Mới',awaiting_confirmation:'Chờ xử lý',processing:'Đang xử lý',shipping:'Đang vận chuyển',delivered:'Đã hoàn thành',canceled:'Đã hủy',unpaid:'Chờ thanh toán'};
const CANCEL=new Set(['canceled','cancelled','rejected']);
function events(raw,kind){
 const source=kind==='cr'?[...(raw.cr_histories||[]),...(raw.cr_histories||[]).flatMap(x=>x.timeline||[])]:kind==='fd'?(raw.status_tracings||[]):(raw.histories||[]);
 return source.map(t=>({status:t.status||t.action||'',sub:t.sub_status||'',at:date(t.created_at||t.changed_at),label:t.status_name||t.display_status||t.status||t.action||'',note:t.comment||t.note||''})).filter(t=>t.at).sort((a,b)=>a.at-b.at);
}
function eventTime(ev,statuses,sub){return (ev.find(t=>statuses.includes(t.status)&&(!sub||sub.includes(t.sub)))||{}).at||null;}
const stamp=(r,paths,ev,sts,sub)=>date(pick(r,paths))||eventTime(ev,sts||[],sub);
function fulfillmentDue(created,channel,priority,cfg={},b2b=false,group=''){
 if(!created)return {reason:'Thiếu thời điểm tạo đơn'};
 let d=date(created),h=local(d).getUTCHours();
 if(b2b){
  if(!['FMCG','HB_FASHION'].includes(group))return {reason:'B2B cần chọn nhóm SLA theo thỏa thuận'};
  const n=group==='FMCG'?1:h<12?1:2;
  let due=at(addDays(d,n,cfg),(group==='FMCG'?h<12:h>=12)?12:23, (group==='FMCG'?h<12:h>=12)?0:59,(group==='FMCG'?h<12:h>=12)?0:59);
  if((cfg.peakDays||[]).includes(ymd(d)))due=new Date(+due+(addDays(due,1,cfg)-midnight(due)));
  return {due,target:null,source:'PDF tr.12–13 · B2B '+group};
 }
 if(priority){
  // PDF rule (90 working minutes) conflicts with hourly examples; expose selected interpretation.
  if(cfg.priorityMode==='hour_bucket'&&working(d,cfg)&&h>=8&&h<18)d=at(d,h);
  return {due:addMinutes(d,90,cfg),target:.96,source:'PDF tr.6 · 90 phút làm việc'+(cfg.priorityMode==='hour_bucket'?' (ví dụ theo giờ)':' (tính từ phút tạo)')};
 }
 const c=String(channel||'').toLowerCase();
 if(!c)return {reason:'Thiếu kênh bán; chưa áp cutoff'};
 let n=0,end;
 if(/lazada/.test(c)){n=h<14?0:1;end=h<14?19:h<20?13:19;}
 else if(/shopee/.test(c)){n=h<16?0:1;end=h<16?20:11;}
 else if(/tiktok/.test(c)){n=h<18?0:1;end=h<18?20:11;}
 else{n=h<13?0:1;end=h<13?19:h<19?13:19;}
 return {due:at(addDays(d,n,cfg),end),target:.96,source:'PDF tr.7–8 · '+channel};
}
function evaluate(id,label,start,end,rule,now,opts={}){
 const o={id,label,start:date(start),end:date(end),due:rule.due||null,target:rule.target===undefined?.95:rule.target,source:rule.source||'',state:'unknown',reason:rule.reason||'',excluded:!!opts.excluded};
 if(o.excluded){o.state='excluded';o.reason=opts.exclusion||'Đơn hủy';return o;}
 if(o.start&&o.start<date('2026-06-01')){o.reason='Ngoài thời gian áp dụng PDF (từ 06/2026)';return o;}
 if(o.end&&o.start&&o.end<o.start){o.reason='Mốc hoàn tất sớm hơn mốc bắt đầu';return o;}
 if(!o.start||!o.due){o.reason=o.reason||'Thiếu mốc bắt đầu / quy tắc';return o;}
 if(o.end)o.state=o.end<=o.due?'ontime':'late';
 else if(opts.finished){o.reason='Công đoạn đã qua nhưng API thiếu mốc hoàn tất';}
 else o.state=+now>+o.due?'overdue':'pending';
 return o;
}
const LANE_DAYS={same_cluster_inner:1,same_cluster_outer:2,cross_cluster_inner:3,cross_cluster_outer:4,same_region_inner:3,same_region_outer:4,near_region_inner:4,near_region_outer:5,hanoi_hcm_inner:5,hanoi_hcm_outer:6,far_region_inner:5,far_region_outer:6};
function order(it,cfg={}){
 const r=Object.assign({},it.row,it.det||{}),ex=r.extra||{},ev=events(r,'order'),b2b=ex.is_b2b_external===true||ex.is_b2b_external==='true';
 const type=r.fulfillment_type||'',fo=ex.is_fulfillment_only===true||ex.is_fulfillment_only==='true',lm=type==='last_miles';
 const service=b2b?(lm?'lmo-b2b':'ffo-b2b'):(lm?'lmo':'ffo');
 const code=r.order_code||'',override=(cfg.overrides||{})[it.__sid+'|'+code]||{};
 const created=date(r.created_at),channel=ex.placed_on||ex.channel||'',status=r.status||'';
 const packed=stamp(r,['packed_at','warehouse.packed_at'],ev,['processing'],['packed']);
 const confirmed=stamp(r,['confirmed_at','seller_confirmed_at'],ev,['new','awaiting_confirmation','processing'],['seller_confirmed']);
 const pickup=stamp(r,['picked_up_at','delivery.picked_up_at'],ev,['shipping'],['picked_up_from_seller','3pl_picked_up_from_seller']);
 const pickupFirst=stamp(r,['first_pickup_attempt_at','delivery.first_pickup_attempt_at'],ev,['awaiting_confirmation','processing','shipping'],['pickup_failed_1','3pl_pickup_failed_1','pickup_failed','3pl_pickup_failed','picked_up_from_seller','3pl_picked_up_from_seller']);
 const deliveryFirst=stamp(r,['first_delivery_attempt_at','delivery.first_delivery_attempt_at'],ev,['shipping','delivered'],['delivery_failed_1','3pl_delivery_failed_1','delivery_failed','3pl_delivery_failed','successful_delivery','completed','logi_partially_delivered']);
 const delivered=stamp(r,['delivered_at','delivery.delivered_at'],ev,['delivered']);
 const wh=String(pick(r,['warehouse.code','warehouse_code'])||'(chưa rõ)'),carrier=String(pick(r,['delivery.tracking.delivered_by','extra.delivery_partner'])||'');
 const priority=(override.priority===true)||/^(2h|2H|priority|express|fulfillment_2h)$/.test(String(r.shipping_plan||''));
 const ffRule=fulfillmentDue(created,channel,priority,cfg,b2b,override.b2bGroup||cfg.b2bGroup);ffRule.target=b2b?null:.96;
 const excluded=CANCEL.has(status)||!!override.exclusion;
 const opts={excluded,exclusion:override.exclusion,finished:['shipping','delivered'].includes(status)||(!lm&&/packed|ready_for_pickup|ready_to_ship|handover|picked_up|pickup_failed|waiting_for_pickup/.test(String(r.sub_status||'')))};
 const kpis=[];
 if(!lm)kpis.push(evaluate(b2b?'fulfillment_b2b':'fulfillment',b2b?'Đóng gói B2B':'Đóng gói B2C',created,packed,ffRule,cfg.now||Date.now(),opts));
 if(!fo){
  kpis.push(evaluate('pickup','Lấy hàng lần đầu',confirmed,pickupFirst,{due:confirmed?at(addDays(confirmed,local(confirmed).getUTCHours()<13?0:1,cfg),19):null,source:'PDF tr.8 / 13 · xác nhận trước 13h → 19h N'},cfg.now||Date.now(),{...opts,finished:!!pickup||status==='delivered'}));
  const lane=override.lane||'',n=LANE_DAYS[lane],office=override.office===undefined?r.delivery?.address?.delivery_address_type==='company':override.office===true;
  let due=null,reason='Cần chọn tuyến giao để tính SLA';
  if(pickup&&n!=null){if(local(pickup).getUTCHours()>=18)reason='Pickup từ 18h: PDF chưa quy định, cần xác nhận TikiNOW';else{due=eod(pickup,n+(b2b&&['hanoi_hcm_outer','far_region_outer'].includes(lane)?1:0),cfg,office);reason='';}}
  kpis.push(evaluate('delivery','Giao hàng lần đầu',pickup,deliveryFirst,{due,reason,target:.95,source:'PDF tr.8–9 / 13–14 · '+lane},cfg.now||Date.now(),{...opts,finished:status==='delivered'}));
 }
 if(override.nowHours&&created&&!b2b){
  const h=local(created).getUTCHours();let due;
  if(h<16&&working(created,cfg))due=new Date(+at(created,h,59)+Number(override.nowHours)*3600000);
  else due=at(addDays(created,1,cfg),10);
  kpis.push(evaluate('now','NOW toàn trình',created,delivered,{due,target:.95,source:'PDF tr.9–10 · tuyến '+override.nowHours+'H'},cfg.now||Date.now(),{excluded,exclusion:override.exclusion,finished:status==='delivered'}));
 }
 return {kind:'order',sid:String(it.__sid),acc:it.__acc,code,status,statusVi:STATUS[status]||status,sub:r.sub_status||'',created,updated:date(r.updated_at),channel,service,b2b,fo,lm,wh,carrier,priority,tracking:String(pick(r,['delivery.tracking.code','extra_lm_info.tracking_id'])||''),ref:r.ref_code||'',external:ex.external_shipping_code||'',qty:(r.items||[]).reduce((n,x)=>n+Number(x.qty??x.quantity??0),0),cod:r.receivable??null,items:r.items||[],boxes:r.boxes||[],histories:ev,kpis,raw:r,hasDetail:!!it.det,done:['delivered','canceled','cancelled'].includes(status),late:kpis.some(k=>k.state==='overdue'||k.state==='late'),override,apiExtra:it.apiExtra||{},errors:it.extraErrors||{}};
}
function reverse(rec,cfg={}){
 const r=rec.raw,ev=events(r,rec.kind),kind=rec.kind,key=rec.sid+'|'+rec.code,ov=(cfg.reverseOverrides||{})[key]||{};
 const t=(paths,sts)=>stamp(r,paths,ev,sts);
 const received=kind==='fd'?t(['arrived_at_fc','received_at'],['received_fully','received_at_sale_center']):t(['arrived_at_aftersales_at'],['arrived_at_aftersales','received_to_as_center']);
 const qc=t(['qc_completed_at','fc_qc_done_at'],['qc_done','fc_qc_done']);
 const asQc=t(['as_completed_qc_at'],['as_completed_qc']);
 const rein=t(['reinbound_at','fc_inbound_completed_at'],['fc_inbound_completed','reinbound']);
 const start=kind==='fd'?t(['return_requested_at'],['returned_to_sender_triggered','returned_trigger_signal']):t(['approved_at'],['approved']);
 const picked=t(['picked_up_at'],['successful_pickup','pickup_successful']);
 const returned=t(['returned_to_fc_at','retrieving_info.arrived_at_destination_date'],kind==='fd'?['returned_to_fc','arrived_at_fc']:['arrived_at_aftersales','successful_delivery']);
 const region=ov.region||'',n={same:kind==='fd'?4:3,near:kind==='fd'?5:4,far:kind==='fd'?6:5}[region];
 const now=cfg.now||Date.now(),excluded=CANCEL.has(rec.status),k=[];
 const calc=(id,label,s,e,days,finished=false,reason='')=>k.push(evaluate(id,label,s,e,{due:s&&days!=null?eod(s,days,cfg):null,reason,source:'PDF tr.10–12 / 16',target:.95},now,{excluded,finished}));
 if(kind==='cr')calc('cr_pickup','CR · lấy từ khách',start,picked,2,!!received||!!returned||rec.done);
 calc('return_transport',kind.toUpperCase()+' · hoàn về kho',kind==='fd'?start:picked,returned,n,!!received||rec.done,n==null?'Cần chọn vùng hoàn cùng / gần / xa':'');
 calc('qc',kind.toUpperCase()+' · phân loại',received,qc,1,!!rein||!!asQc||rec.done);
 if(ov.goods==='good')calc('reinbound','Nhập lại kho bán',qc,rein,1,rec.done);
 if(ov.goods==='bad')calc('as_qc','Nhập / phân loại kho hậu mãi',qc,asQc,1,rec.done);
 // Detailed p.12 takes precedence over summary p.3–4 (CR bad goods 1–5 days).
 return {sid:rec.sid,code:rec.code,acc:rec.acc,kind,kpis:k,override:ov};
}
function summarize(records){
 const out={};for(const r of records)for(const k of r.kpis){const g=out[k.id]||(out[k.id]={id:k.id,label:k.label,target:k.target,ontime:0,late:0,overdue:0,pending:0,unknown:0,excluded:0});g[k.state]++;if(g.target!==k.target)g.target=null;}
 return Object.values(out).map(g=>({...g,denominator:g.ontime+g.late,rate:g.ontime+g.late?g.ontime/(g.ontime+g.late):null}));
}
function sanitize(v){if(Array.isArray(v))return v.map(sanitize);if(!v||typeof v!=='object')return v;const out={};for(const[k,x]of Object.entries(v)){if(/token|authorization|password|cookie|secret/i.test(k))continue;out[k]=sanitize(x);}return out;}
const CATALOG=[
 ['Đơn hàng','GET','https://api.tikinow.vn/fulfillment/1.0/orders','Danh sách mọi loại, filter ngày/status/seller, phân trang'],
 ['Đơn hàng','GET','https://api.tikinow.vn/fulfillment/1.0/orders/counts','Đối chiếu tổng trạng thái'],
 ['Đơn hàng','GET','https://api.tikinow.vn/fulfillment/1.0/orders/{code}','Chi tiết, SKU, kiện, lịch sử'],
 ['Đơn hàng','GET','https://api.tikinow.vn/orders/last-miles/v1/order/get-extra-info/{code}','Thông tin LMO B2C'],
 ['Đơn hàng','GET','https://api.tikinow.vn/orders/last-miles/v1/order/get-b2b-extra-info/{code}','Thông tin LMO B2B, shipments'],
 ['Đơn hàng','GET','https://api.tikinow.vn/orders/last-miles/v1/update-cod-histories/{code}','Lịch sử COD'],
 ['Đơn hàng','GET','https://api.tikinow.vn/business/v1/box-attachment/{code}','Tệp đính kèm đơn/kiện đã giao'],
 ['Đơn hàng','GET','https://api.tikinow.vn/business/v1/request/box/extra-services','Dịch vụ thêm theo box_codes'],
 ['Đơn hàng','GET','https://api.tikinow.vn/business/v1/order/confirm-continuous/{code}','Thông tin xác nhận lỗi hàng'],
 ['Hậu mãi','GET','https://api.tikinow.vn/tnc-ams/v1/check-evidence-documents','Bằng chứng hiện có, không tạo yêu cầu tính phí'],
 ['Hậu mãi','GET','https://api.tikinow.vn/fulfillment/1.0/inbound-shipments/fds/list','Danh sách FD'],
 ['Hậu mãi','GET','https://api.tikinow.vn/fulfillment/1.0/inbound-shipments/fds/detail','Chi tiết FD'],
 ['Hậu mãi','GET','https://api.tikinow.vn/tnc-ams/v1/cr/search','Danh sách CR'],
 ['Hậu mãi','GET','https://api.tikinow.vn/tnc-ams/v1/cr/detail/{code}','Chi tiết CR'],
 ['Hậu mãi','GET','https://api.tikinow.vn/tnc-ams/v1/evidence-documents-request','Bằng chứng đã có FD/CR'],
 ['Sản phẩm','POST đọc','https://api.tikinow.vn/business/v1/product/base-info','Tra tên / ảnh SKU theo lô, kế thừa v3.1']
];
root.TNKPI={date,local,ymd,at,working,roll,addDays,eod,addMinutes,get,pick,events,fulfillmentDue,evaluate,order,reverse,summarize,sanitize,CATALOG,LANE_DAYS,STATUS};
})(typeof self!=='undefined'?self:globalThis);
