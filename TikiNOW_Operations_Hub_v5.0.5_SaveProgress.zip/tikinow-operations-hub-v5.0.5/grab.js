/* Hậu mãi Hub — chạy trên tikinowcenter.tikinow.vn (ISOLATED world).
 * Đường dự phòng: đọc cookie ACP_AUTH của trang và gửi cho service worker khi nó đổi
 * (đăng nhập / đổi tài khoản), phòng khi chrome.cookies không trả về cookie.
 */
(() => {
  let last = null;
  const push = () => {
    const m = document.cookie.match(/(?:^|;\s*)ACP_AUTH=([^;]+)/);
    const v = m ? m[1] : null;
    if (!v || v === last) return;
    last = v;
    try { chrome.runtime.sendMessage({ type: 'hm-token', value: v }).catch(() => {}); } catch (e) {}
  };
  push();
  setInterval(push, 15000);
})();
