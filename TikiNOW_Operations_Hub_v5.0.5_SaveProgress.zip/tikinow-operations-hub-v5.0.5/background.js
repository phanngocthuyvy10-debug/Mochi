/* TikiNOW Operations Hub v5 — service worker: mở app + tự lưu token mỗi khi đăng nhập TikiNOW Center. */
'use strict';
importScripts('tokens.js');

chrome.action.onClicked.addListener(async () => {
  const url = chrome.runtime.getURL('app.html');
  const tabs = await chrome.tabs.query({ url });
  if (tabs.length) { chrome.tabs.update(tabs[0].id, { active: true }); chrome.windows.update(tabs[0].windowId, { focused: true }); }
  else chrome.tabs.create({ url });
});

chrome.cookies.onChanged.addListener(({ cookie, removed }) => {
  if (removed || cookie.name !== 'ACP_AUTH' || !cookie.domain.includes('tikinow')) return;
  saveTokenFromCookie(cookie.value).catch(() => {});
});

chrome.runtime.onMessage.addListener((msg, sender) => {
  if (!msg || msg.type !== 'hm-token' || !msg.value) return;
  if (!sender.url || !sender.url.startsWith(CENTER + '/')) return;
  saveTokenFromCookie(msg.value).catch(() => {});
});

chrome.runtime.onInstalled.addListener(() => { captureFromCookies().catch(() => {}); });
chrome.runtime.onStartup.addListener(() => { captureFromCookies().catch(() => {}); });
