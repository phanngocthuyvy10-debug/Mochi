/* Hậu mãi Hub — engine (thuần dữ liệu, test được bằng Node).
 * Cấu trúc API đã kiểm chứng trên TikiNOW Center (27/10/2026):
 *  FD: GET api.tikinow.vn/fulfillment/1.0/inbound-shipments/fds/list
 *      ?filters.seller_id=&seller_id=&page.page_number=&page.per_page(<=50)
 *      &filters.status=a,b &filters.created_from=YYYY-MM-DD &filters.created_to=
 *      -> {success:"true", data:[{code, origin, partner_code, warehouse_code, receive_warehouse_code,
 *          status, note, created_at(UTC Z), updated_at, items[], status_tracings[]}], paging:{total,total_page,per_page,current_page}}
 *  CR: GET api.tikinow.vn/tnc-ams/v1/cr/search
 *      ?seller_id=&page=&size(<=100)&ordering=-created_at &status__in=x (1 mã) &created_at__gte=&created_at__lte=
 *      -> {success:true, data:[{cr_code, cr_status, order_code, cr_created_at, cr_completed_at, external_order_id,
 *          tracking_id, tnsl_ref_code, number_product, return_method_displayed, type,
 *          retrieving_info:{estimated_pickup_date, estimated_delivery_date, arrived_at_destination_date, partner_name}}],
 *          meta_data:{total_record (trần 10000), total_page, per_page, current_page}}
 */
(function (root) {
  'use strict';

  /* ---------- Hồ sơ API ---------- */
  const PROFILES = {
    fd: {
      label: 'FD', url: 'https://api.tikinow.vn/fulfillment/1.0/inbound-shipments/fds/list',
      sellerParams: ['filters.seller_id', 'seller_id'],
      pageParam: 'page.page_number', sizeParam: 'page.per_page', maxSize: 50, firstPage: 1,
      dateFrom: 'filters.created_from', dateTo: 'filters.created_to',
      statusParam: 'filters.status', statusMulti: true, cap: 0, extra: {},
      listPath: 'data', pagingPath: 'paging', totalKey: 'total', totalPageKey: 'total_page',
    },
    cr: {
      label: 'CR', url: 'https://api.tikinow.vn/tnc-ams/v1/cr/search',
      sellerParams: ['seller_id'],
      pageParam: 'page', sizeParam: 'size', maxSize: 100, firstPage: 1,
      dateFrom: 'created_at__gte', dateTo: 'created_at__lte',
      statusParam: 'status__in', statusMulti: false, cap: 10000, extra: { ordering: '-created_at' },
      listPath: 'data', pagingPath: 'meta_data', totalKey: 'total_record', totalPageKey: 'total_page',
    },
  };

  /* ---------- Trạng thái ---------- */
  const FD_STATUS = {
    open: 'Mới tạo', cancelled: 'Đã huỷ', ready_to_receive: 'Sẵn sàng nhận hàng',
    received_partially: 'Đã nhận 1 phần', received_fully: 'Đã nhận toàn bộ',
    stow_partially: 'Đã cất hàng 1 phần', stow_fully: 'Đã cất hàng toàn bộ',
    received_problem: 'Nhận hàng có SP lỗi', done: 'Hoàn tất',
  };
  const CR_STATUS = {
    waiting_for_approve: 'Chờ duyệt', approved: 'Đã duyệt', pending: 'Chờ xử lý',
    request_to_transportation: 'Đã gửi YC vận chuyển', request_failed: 'Gửi YC thất bại',
    waiting_for_picking_up: 'Chờ lấy hàng', ready_for_picking_up: 'Sẵn sàng lấy hàng', picking: 'Đang lấy hàng',
    pickup_failed: 'Lấy hàng thất bại', pickup_failed_many_times: 'Lấy thất bại nhiều lần',
    successful_pickup: 'Lấy hàng thành công', pickup_successful: 'Đã lấy hàng từ KH',
    in_transit: 'Đang trung chuyển', arrived_at_destination: 'Đã đến nơi xử lý', arrived_at_destination_hub: 'Đã đến trạm đích',
    storing: 'Đang lưu kho VC', delivering: 'Đang giao hàng', delivery_failed: 'Giao hàng thất bại', successful_delivery: 'Giao hàng thành công',
    arrived_at_aftersales: 'Đã về kho Aftersales', parcel_received: 'Đã nhận kiện', received: 'Đã nhận hàng',
    packed_in_masterbox: 'Hàng trong kiện', confirmed_in_master_box: 'Hàng trong kiện - đã XN',
    confirmed_damage: 'Hư hỏng - đã XN', confirmed_missing: 'Thất lạc - đã XN',
    on_hold: 'Tạm dừng', requested_to_continue: 'YC tiếp tục xử lý',
    returned_to_sender_triggered: 'YC hoàn hàng', returning: 'Đang trả hàng', return_failed: 'Trả hàng thất bại', returned_to_sender: 'Đã trả hàng',
    resolution_in_progress: 'Đang kiểm tra SP', resolution_in_process: 'Đang kiểm tra SP', resolution_approved: 'Đã duyệt giải pháp',
    waiting_to_review: 'Chờ kiểm tra lại giải pháp', disputing: 'Đang tranh chấp', multiple_resolution: 'Nhiều giải pháp',
    refund_in_progress: 'Đang hoàn tiền', refunded: 'Đã hoàn tiền', replaced: 'Đã đổi mới SP', warranted: 'Đã bảo hành',
    multiple_completion: 'Đã hoàn thành nhiều giải pháp', completed: 'Đã hoàn thành', canceled: 'Đã huỷ', rejected: 'Đã từ chối',
  };

  // Mặc định: trạng thái coi là KẾT THÚC (không còn pending)
  const DEFAULT_DONE = {
    fd: ['done', 'cancelled', 'stow_fully'],
    cr: ['completed', 'multiple_completion', 'canceled', 'rejected', 'refunded', 'replaced', 'warranted',
      'returned_to_sender', 'confirmed_missing', 'confirmed_damage'],
  };
  // Trạng thái pending để kéo nhanh (đã kiểm chứng có dữ liệu thật)
  const PENDING_PULL = {
    fd: ['open', 'ready_to_receive', 'received_partially', 'received_fully', 'received_problem', 'stow_partially'],
    cr: ['waiting_for_approve', 'approved', 'pending', 'request_to_transportation', 'request_failed',
      'waiting_for_picking_up', 'ready_for_picking_up', 'picking', 'pickup_failed', 'pickup_failed_many_times',
      'successful_pickup', 'pickup_successful', 'in_transit', 'arrived_at_destination', 'arrived_at_destination_hub',
      'storing', 'delivering', 'delivery_failed', 'arrived_at_aftersales', 'parcel_received', 'received',
      'on_hold', 'requested_to_continue', 'returning', 'return_failed', 'returned_to_sender_triggered',
      'resolution_in_progress', 'resolution_approved', 'waiting_to_review', 'disputing', 'multiple_resolution', 'refund_in_progress'],
  };

  // Giai đoạn (để xem đơn đang kẹt ở đâu)
  function stageOf(kind, st, isDone) {
    if (isDone) return st === 'cancelled' || st === 'canceled' || st === 'rejected' ? 'Huỷ / từ chối' : 'Hoàn tất';
    if (kind === 'fd') {
      if (st === 'open' || st === 'ready_to_receive') return 'Chờ nhận hàng';
      if (st === 'received_problem') return 'Nhận có lỗi';
      if (/^received|^stow/.test(st)) return 'Đã nhận, chờ cất';
      return 'Khác';
    }
    if (/approve|^pending$|request_|waiting_for_picking|ready_for_picking|^picking$|pickup_failed/.test(st)) return 'Chờ lấy hàng';
    if (/pickup_successful|successful_pickup|in_transit|arrived_at_destination|storing|delivering|delivery_failed|on_hold|requested_to_continue|returning|return_failed|returned_to_sender_triggered/.test(st)) return 'Đang về kho';
    if (/arrived_at_aftersales|parcel_received|^received$|packed_in|confirmed_in/.test(st)) return 'Đã về kho';
    if (/resolution|review|disput|multiple_resolution|refund_in_progress/.test(st)) return 'Đang xử lý giải pháp';
    return 'Khác';
  }
  const STAGE_ORDER = {
    fd: ['Chờ nhận hàng', 'Đã nhận, chờ cất', 'Nhận có lỗi', 'Khác'],
    cr: ['Chờ lấy hàng', 'Đang về kho', 'Đã về kho', 'Đang xử lý giải pháp', 'Khác'],
  };

  /* ---------- Ngày ---------- */
  function parseDate(v) {
    if (v == null || v === '') return null;
    if (Object.prototype.toString.call(v) === '[object Date]') return isNaN(v) ? null : v;
    if (typeof v === 'number') { const d = new Date(v < 1e12 ? v * 1000 : v); return isNaN(d) ? null : d; }
    const s = String(v).trim();
    if (!s || /^0001-01-01/.test(s)) return null;
    let m = s.match(/^(\d{1,2})[/-](\d{1,2})[/-](\d{4})(?:[ T](\d{1,2}):(\d{2})(?::(\d{2}))?)?$/);
    if (m) { const d = new Date(+m[3], +m[2] - 1, +m[1], +(m[4] || 0), +(m[5] || 0), +(m[6] || 0)); return isNaN(d) ? null : d; }
    const d = new Date(s);
    return isNaN(d) ? null : d;
  }
  const DAY = 86400000;
  function ymd(d) { const p = (n) => ('0' + n).slice(-2); return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()); }

  /* ---------- Chuẩn hoá bản ghi ---------- */
  function flatten(obj, prefix, out, depth) {
    out = out || {}; depth = depth || 0;
    if (obj == null || depth > 4) return out;
    if (typeof obj !== 'object') { if (prefix) out[prefix] = obj; return out; }
    if (Array.isArray(obj)) {
      if (obj.every((x) => x == null || typeof x !== 'object')) out[prefix] = obj.join(', ');
      else out[prefix] = obj.length + ' mục';
      return out;
    }
    for (const k in obj) flatten(obj[k], prefix ? prefix + '.' + k : k, out, depth + 1);
    return out;
  }

  // Loại bằng chứng (theo UI TikiNOW Center)
  const EVIDENCE_LABEL = { video_inbound: 'Video khui hàng', video_pack: 'Video pack đơn hàng', inspection_report: 'Biên bản bàn giao VC' };
  const IMG_BASE = 'https://salt.tikicdn.com/ts/';
  const imgUrl = (p) => (!p ? '' : /^https?:/.test(p) ? p : IMG_BASE + String(p).replace(/^\/+/, ''));
  const uniq = (a) => [...new Set(a.filter((x) => x != null && x !== ''))];

  /* Dữ liệu chi tiết: FD detail (kiện, SL từng SKU, lịch sử trạng thái), CR detail (sản phẩm, giải pháp,
   * timeline, ghi chú), bằng chứng/video, tên SP tra theo SKU. Thiếu chi tiết thì các trường để trống. */
  function enrich(rec, r, item, cfg) {
    const prod = (sku) => (cfg.products && cfg.products[item.__sid + '|' + sku]) || null;
    rec.hasDetail = !!item.det;
    rec.videos = (Array.isArray(item.ev) ? item.ev : []).map((v) => ({ type: v.type, label: EVIDENCE_LABEL[v.type] || v.type, url: v.url, at: parseDate(v.created_at) }));
    if (rec.kind === 'fd') {
      rec.items = (Array.isArray(r.items) ? r.items : []).map((x) => {
        const p = prod(x.sku);
        return { sku: x.sku, name: (p && p.name) || '', image: p ? imgUrl(p.image) : '', qty: +x.quantity || 0, matched: +x.matched_quantity || 0,
          processing: +x.processing_qty || 0, doneQty: +x.done_qty || 0, missing: +x.missing_qty || 0, status: x.status || '', note: x.note || '' };
      });
      rec.missing = rec.items.reduce((a, x) => a + x.missing, 0);
      rec.matched = rec.items.reduce((a, x) => a + x.matched, 0);
      rec.doneQty = rec.items.reduce((a, x) => a + x.doneQty, 0);
      rec.names = uniq(rec.items.map((x) => x.name)).join(' | ');
      rec.packages = (Array.isArray(r.packages) ? r.packages : []).map((p) => ({ code: p.code, status: p.status, statusVi: FD_STATUS[p.status] || p.status, transport: p.transport_code || '',
        created: parseDate(p.created_at), items: (p.items || []).map((x) => x.sku + ' ×' + (x.qty != null ? x.qty : x.quantity)).join(', ') }));
      rec.pkgCodes = rec.packages.map((p) => p.code).join(', ');
      rec.journal = r.stock_journal_code || '';
      rec.traces = (Array.isArray(r.status_tracings) ? r.status_tracings : []).map((t) => ({ at: parseDate(t.changed_at || t.created_at), status: t.status,
        label: t.display_status || FD_STATUS[t.status] || t.status, by: t.operator || '', note: t.note || '' }));
    } else {
      const res = Array.isArray(r.resolutions) ? r.resolutions : [];
      rec.products = (Array.isArray(r.products) ? r.products : []).map((p) => {
        const rs = res.find((x) => x.cr_item_id === p.id) || null;
        return { sku: p.sku, name: p.name || '', image: imgUrl(p.item_image), images: (p.images || []).map(imgUrl), price: +p.price || 0, qty: +p.qty_requested || 0,
          reason: p.reason_return || '', resolutionDetail: p.resolution_detail || '', resType: rs ? rs.resolution_type : '', resStatus: rs ? rs.status : '', counting: rs ? rs.counting_status : '' };
      });
      rec.resolutions = res.map((x) => ({ type: x.resolution_type, status: x.status, statusVi: CR_STATUS[x.status] || x.status, counting: x.counting_status || '', itemId: x.cr_item_id }));
      rec.value = rec.products.reduce((a, p) => a + p.price * p.qty, 0);
      rec.names = uniq(rec.products.map((p) => p.name)).join(' | ');
      if (rec.products.length) rec.skus = uniq(rec.products.map((p) => p.sku)).join(', ');
      rec.reasons = uniq(rec.products.map((p) => p.reason)).join(', ');
      rec.resTypes = uniq(rec.resolutions.map((x) => x.type)).join(', ');
      if (r.note) rec.note = r.note;
      rec.crNotes = (Array.isArray(r.cr_notes) ? r.cr_notes : []).map((n) => (typeof n === 'string' ? n : n && (n.note || n.content || JSON.stringify(n)))).filter(Boolean);
      const cm = r.cr_comments || {};
      rec.comment = cm.info && cm.info.note ? { note: cm.info.note, by: cm.assign_user || '', at: parseDate(cm.created_at), images: (cm.info.images || []).map(imgUrl) } : null;
      const d = r.destination_address || null;
      rec.dest = d ? [d.full_name, d.street, d.ward, d.district, d.region].filter(Boolean).join(', ') : '';
      rec.destName = d ? d.full_name || '' : '';
      rec.createdBy = r.cr_created_by || '';
      rec.orderType = r.order_type || '';
      const ev = [];
      for (const h of Array.isArray(r.cr_histories) ? r.cr_histories : []) {
        ev.push({ at: parseDate(h.created_at), status: h.status, label: CR_STATUS[h.status] || h.status, by: '', note: '' });
        for (const t of Array.isArray(h.timeline) ? h.timeline : []) ev.push({ at: parseDate(t.created_at), status: t.action, label: CR_STATUS[t.action] || t.action, by: t.operator || t.created_by || '', note: t.note || '' });
      }
      const seen = new Set();
      rec.traces = ev.filter((e) => { const k = (e.at ? e.at.getTime() : 0) + '|' + e.status; if (seen.has(k)) return false; seen.add(k); return true; });
    }
    rec.traces.sort((a, b) => (b.at ? b.at.getTime() : 0) - (a.at ? a.at.getTime() : 0));
    const last = rec.traces[0] || null;
    rec.lastEvent = last ? last.label : ''; rec.lastEventAt = last ? last.at : null; rec.lastBy = last ? last.by : '';
  }

  function normalize(item, cfg) {
    // Chi tiết (nếu đã kéo) là bản đầy đủ hơn của dòng danh sách — gộp đè lên
    const r = item.det ? Object.assign({}, item.row || {}, item.det) : item.row || {};
    const kind = item.__kind;
    const done = new Set((cfg.done && cfg.done[kind]) || DEFAULT_DONE[kind]);
    const now = cfg.now || Date.now();
    let rec;
    if (kind === 'fd') {
      const st = String(r.status || '');
      const items = Array.isArray(r.items) ? r.items : [];
      rec = {
        kind, acc: item.__acc, sid: item.__sid,
        code: r.code || '', order: r.origin || '', status: st, statusVi: FD_STATUS[st] || st,
        wh: String(r.receive_warehouse_code || r.warehouse_code || '').toUpperCase() || '(chưa rõ)',
        created: parseDate(r.created_at), updated: parseDate(r.updated_at), completed: null,
        eta: null, carrier: '', method: '', partner: r.partner_code || '', note: r.note || '',
        qty: items.reduce((a, x) => a + (+x.quantity || 0), 0),
        skus: items.map((x) => x.sku).filter(Boolean).join(', '),
        tracking: '',
      };
    } else {
      const st = String(r.cr_status || '');
      const ri = r.retrieving_info || {};
      rec = {
        kind, acc: item.__acc, sid: item.__sid,
        code: r.cr_code || '', order: r.order_code || '', status: st, statusVi: CR_STATUS[st] || st,
        wh: '', created: parseDate(r.cr_created_at), updated: null, completed: parseDate(r.cr_completed_at),
        eta: parseDate(ri.estimated_delivery_date), pickupEta: parseDate(ri.estimated_pickup_date),
        arrived: parseDate(ri.arrived_at_destination_date),
        carrier: ri.partner_name || '', method: r.return_method_displayed || r.return_method || '',
        partner: r.external_order_id || '', note: '', qty: +r.number_product || 0, skus: '',
        tracking: r.tracking_id || '', refCode: r.tnsl_ref_code || '', type: r.type || '',
      };
    }
    rec.extId = kind === 'cr' ? (r.external_order_id || '') : ((cfg.ext && cfg.ext[item.__sid + '|' + rec.order]) || '');
    rec.done = done.has(rec.status);
    rec.stage = stageOf(kind, rec.status, rec.done);
    rec.age = rec.created ? (now - rec.created.getTime()) / DAY : null;
    // Hạn: CR dùng ngày dự kiến về kho (nếu có), còn lại = ngày tạo + SLA
    const sla = kind === 'fd' ? (cfg.slaFd != null ? cfg.slaFd : 3) : (cfg.slaCr != null ? cfg.slaCr : 7);
    rec.due = kind === 'cr' && rec.eta && cfg.crUseEta !== false ? rec.eta : (rec.created ? new Date(rec.created.getTime() + sla * DAY) : null);
    rec.late = !rec.done && rec.due != null && now > rec.due.getTime();
    rec.overdue = rec.late ? (now - rec.due.getTime()) / DAY : 0;
    enrich(rec, r, item, cfg);
    rec.raw = r;
    return rec;
  }

  function prepare(raw, cfg) {
    const recs = raw.map((it) => normalize(it, cfg || {}));
    // Nối CR -> FD qua mã đơn để biết kho nhập hoàn
    const whByOrder = {};
    for (const r of recs) if (r.kind === 'fd' && r.order && r.wh && r.wh !== '(chưa rõ)') whByOrder[r.sid + '|' + r.order] = r.wh;
    for (const r of recs) if (r.kind === 'cr') r.wh = whByOrder[r.sid + '|' + r.order] || r.destName || '(chưa về kho)';
    const extByOrder = {};
    for (const r of recs) if (r.kind === 'cr' && r.extId) extByOrder[r.sid + '|' + r.order] = r.extId;
    for (const r of recs) if (r.kind === 'fd' && !r.extId) r.extId = extByOrder[r.sid + '|' + r.order] || '';
    return recs;
  }

  /* ---------- Phân tích ---------- */
  function analyze(recs) {
    const out = { fd: summarize(recs.filter((r) => r.kind === 'fd'), 'fd'), cr: summarize(recs.filter((r) => r.kind === 'cr'), 'cr') };
    const all = recs;
    out.total = all.length;
    out.pending = all.filter((r) => !r.done).length;
    out.late = all.filter((r) => r.late).length;
    out.lateList = all.filter((r) => r.late).sort((a, b) => b.overdue - a.overdue);
    const accs = {};
    for (const r of all) {
      const g = accs[r.acc] || (accs[r.acc] = { k: r.acc, fd: 0, fdPend: 0, fdLate: 0, cr: 0, crPend: 0, crLate: 0 });
      g[r.kind]++; if (!r.done) g[r.kind + 'Pend']++; if (r.late) g[r.kind + 'Late']++;
    }
    out.accs = Object.values(accs).sort((a, b) => (b.fdLate + b.crLate) - (a.fdLate + a.crLate));
    return out;
  }

  function summarize(recs, kind) {
    const stages = STAGE_ORDER[kind];
    const byWh = {}, byCarrier = {}, byStatus = {};
    const buckets = [
      { label: '< 1 ngày', min: 0, max: 1, n: 0 }, { label: '1–3 ngày', min: 1, max: 3, n: 0 },
      { label: '3–7 ngày', min: 3, max: 7, n: 0 }, { label: '7–14 ngày', min: 7, max: 14, n: 0 },
      { label: '> 14 ngày', min: 14, max: Infinity, n: 0 },
    ];
    let pending = 0, late = 0;
    for (const r of recs) {
      const s = byStatus[r.status] || (byStatus[r.status] = { code: r.status, label: r.statusVi, n: 0, pend: 0, late: 0, done: r.done });
      s.n++;
      const key = kind === 'fd' ? r.wh : (r.carrier || '(không rõ ĐVVC)');
      const grp = kind === 'fd' ? byWh : byCarrier;
      const g = grp[key] || (grp[key] = { k: key, total: 0, pending: 0, late: 0, maxAge: 0, stages: Object.fromEntries(stages.map((x) => [x, 0])) });
      g.total++;
      if (kind === 'cr' && r.wh) { const w = byWh[r.wh] || (byWh[r.wh] = { k: r.wh, total: 0, pending: 0, late: 0, maxAge: 0, stages: Object.fromEntries(stages.map((x) => [x, 0])) }); w.total++; if (!r.done) { w.pending++; w.stages[r.stage] = (w.stages[r.stage] || 0) + 1; if (r.late) w.late++; } }
      if (r.done) continue;
      pending++; g.pending++; s.pend++;
      g.stages[r.stage] = (g.stages[r.stage] || 0) + 1;
      if (r.age != null) { g.maxAge = Math.max(g.maxAge, r.age); for (const b of buckets) if (r.age >= b.min && r.age < b.max) { b.n++; break; } }
      if (r.late) { late++; g.late++; s.late++; }
    }
    const sortG = (o) => Object.values(o).sort((a, b) => b.late - a.late || b.pending - a.pending || b.total - a.total);
    return {
      total: recs.length, pending, late, stages,
      byWh: sortG(byWh), byCarrier: sortG(byCarrier),
      byStatus: Object.values(byStatus).sort((a, b) => (a.done - b.done) || b.n - a.n),
      buckets,
    };
  }

  /* ---------- Excel ---------- */
  const COLS = {
    fd: [
      ['Tài khoản', (r) => r.acc, 24], ['Seller ID', (r) => String(r.sid ?? ''), 16], ['Mã FD', (r) => r.code, 24], ['Mã đơn hàng', (r) => r.order, 14], ['Mã đơn đối tác', (r) => r.extId, 26],
      ['Trạng thái', (r) => r.statusVi, 20], ['Giai đoạn', (r) => r.stage, 18], ['Kho nhập lại', (r) => r.wh, 12],
      ['Ngày tạo', (r) => r.created, 17], ['Cập nhật', (r) => r.updated, 17], ['Tuổi (ngày)', (r) => r.age == null ? '' : { v: +r.age.toFixed(1), s: 'dn' }, 10],
      ['Hạn', (r) => r.due, 17], ['Trễ?', (r) => r.late ? { v: 'TRỄ', s: 'bad' } : (r.done ? 'Xong' : ''), 8],
      ['Quá hạn (ngày)', (r) => r.late ? { v: +r.overdue.toFixed(1), s: 'bad' } : '', 12],
      ['SL SP', (r) => r.qty, 7], ['SL khớp', (r) => r.hasDetail ? r.matched : '', 8], ['SL đã xong', (r) => r.hasDetail ? r.doneQty : '', 9],
      ['SL thiếu', (r) => r.missing ? { v: r.missing, s: 'bad' } : (r.hasDetail ? 0 : ''), 8],
      ['SKU', (r) => r.skus, 26], ['Tên sản phẩm', (r) => r.names, 40], ['Phiếu nhập / kiện', (r) => r.pkgCodes, 26],
      ['Sự kiện cuối', (r) => r.lastEvent, 26], ['Lúc', (r) => r.lastEventAt, 17], ['Người thao tác', (r) => r.lastBy, 16],
      ['Video / bằng chứng', (r) => r.videos.map((v) => v.label).join(', '), 30], ['Mã đối tác (partner_code)', (r) => r.partner, 22], ['Ghi chú', (r) => r.note, 28],
    ],
    cr: [
      ['Tài khoản', (r) => r.acc, 24], ['Seller ID', (r) => String(r.sid ?? ''), 16], ['Mã CR', (r) => r.code, 16], ['Mã đơn gốc', (r) => r.order, 14], ['Mã đơn đối tác', (r) => r.extId, 26], ['Mã thu hồi đối tác', (r) => r.refCode, 22],
      ['Trạng thái', (r) => r.statusVi, 22], ['Giai đoạn', (r) => r.stage, 20], ['Kho nhập hoàn (từ FD)', (r) => r.wh, 16],
      ['Ngày tạo', (r) => r.created, 17], ['Dự kiến lấy', (r) => r.pickupEta, 17], ['Dự kiến về', (r) => r.eta, 17],
      ['Hoàn tất lúc', (r) => r.completed, 17], ['Tuổi (ngày)', (r) => r.age == null ? '' : { v: +r.age.toFixed(1), s: 'dn' }, 10],
      ['Trễ?', (r) => r.late ? { v: 'TRỄ', s: 'bad' } : (r.done ? 'Xong' : ''), 8],
      ['Quá hạn (ngày)', (r) => r.late ? { v: +r.overdue.toFixed(1), s: 'bad' } : '', 12],
      ['ĐVVC thu hồi', (r) => r.carrier, 16], ['Phương thức', (r) => r.method, 26], ['Mã vận đơn', (r) => r.tracking, 18],
      ['SL SP', (r) => r.qty, 7], ['Loại', (r) => r.type, 8],
      ['SKU', (r) => r.skus, 24], ['Tên sản phẩm', (r) => r.names, 40], ['Giá trị (đ)', (r) => r.value || '', 13], ['Lý do trả', (r) => r.reasons, 22],
      ['Giải pháp', (r) => r.resTypes, 18], ['Điểm nhận hàng hoàn', (r) => r.dest, 34], ['Ghi chú', (r) => [r.note].concat(r.crNotes || []).filter(Boolean).join(' | '), 28],
      ['Sự kiện cuối', (r) => r.lastEvent, 24], ['Lúc', (r) => r.lastEventAt, 17], ['Người tạo', (r) => r.createdBy, 18],
      ['Video / bằng chứng', (r) => r.videos.map((v) => v.label).join(', '), 30],
    ],
  };

  function buildWorkbook(opts) {
    // opts: { X, recs, groups:[{label, recs}], sheets:{overview,late,fd,cr}, onlyPending, split, rawFields, now, sla:{fd,cr} }
    const X = opts.X, wb = X.workbook();
    const now = opts.now || Date.now();
    const all = opts.recs;
    const a = analyze(all);

    if (opts.sheets.overview) {
      const rows = [];
      const H = (arr) => arr.map((v) => ({ v, s: 'h' }));
      rows.push([{ v: 'BÁO CÁO HẬU MÃI — FD & CR', s: 't' }]);
      rows.push([{ v: 'Lập lúc ' + new Date(now).toLocaleString('vi-VN') + ' · Tài khoản: ' + (opts.accLabel || 'tất cả') +
        ' · SLA FD ' + opts.sla.fd + ' ngày, CR theo ngày dự kiến về (hoặc ' + opts.sla.cr + ' ngày)', s: 'mute' }]);
      rows.push(null);
      rows.push(H(['', 'Tổng', 'Pending', 'Trễ', '% trễ/pending']));
      for (const k of ['fd', 'cr']) { const s = a[k]; rows.push([{ v: k.toUpperCase(), s: 'b' }, s.total, s.pending, { v: s.late, s: s.late ? 'bad' : '' }, { v: s.pending ? s.late / s.pending : 0, s: 'p' }]); }
      rows.push(null);
      // FD theo kho
      const fdSt = a.fd.stages.filter((x) => a.fd.byWh.some((g) => g.stages[x]));
      rows.push([{ v: 'FD — theo kho nhập lại', s: 'b' }]);
      const hr = rows.length + 1;
      rows.push(H(['Kho', 'Tổng', 'Pending'].concat(fdSt, ['Trễ', '% trễ', 'Tồn lâu nhất (ngày)'])));
      for (const g of a.fd.byWh) rows.push([g.k, g.total, g.pending].concat(fdSt.map((x) => g.stages[x] || 0), [{ v: g.late, s: g.late ? 'bad' : '' }, { v: g.pending ? g.late / g.pending : 0, s: 'p' }, { v: +g.maxAge.toFixed(1), s: 'dn' }]));
      rows.push([{ v: 'TỔNG', s: 'sub' }, { v: a.fd.total, s: 'sub' }, { v: a.fd.pending, s: 'sub' }].concat(fdSt.map((x) => ({ v: a.fd.byWh.reduce((s, g) => s + (g.stages[x] || 0), 0), s: 'sub' })), [{ v: a.fd.late, s: 'sub' }]));
      rows.push(null);
      // CR theo giai đoạn / ĐVVC
      const crSt = a.cr.stages.filter((x) => a.cr.byCarrier.some((g) => g.stages[x]));
      rows.push([{ v: 'CR — theo đơn vị thu hồi', s: 'b' }]);
      rows.push(H(['ĐVVC', 'Tổng', 'Pending'].concat(crSt, ['Trễ', '% trễ', 'Tồn lâu nhất (ngày)'])));
      for (const g of a.cr.byCarrier) rows.push([g.k, g.total, g.pending].concat(crSt.map((x) => g.stages[x] || 0), [{ v: g.late, s: g.late ? 'bad' : '' }, { v: g.pending ? g.late / g.pending : 0, s: 'p' }, { v: +g.maxAge.toFixed(1), s: 'dn' }]));
      rows.push(null);
      rows.push([{ v: 'Theo trạng thái', s: 'b' }]);
      rows.push(H(['Loại', 'Trạng thái', 'Mã', 'Số đơn', 'Pending', 'Trễ']));
      for (const k of ['fd', 'cr']) for (const s of a[k].byStatus) rows.push([k.toUpperCase(), s.label, { v: s.code, s: 'mute' }, s.n, s.done ? { v: 'kết thúc', s: 'mute' } : s.pend, { v: s.late, s: s.late ? 'bad' : '' }]);
      rows.push(null);
      rows.push([{ v: 'Theo tài khoản', s: 'b' }]);
      rows.push(H(['Tài khoản', 'FD', 'FD pending', 'FD trễ', 'CR', 'CR pending', 'CR trễ']));
      for (const g of a.accs) rows.push([g.k, g.fd, g.fdPend, { v: g.fdLate, s: g.fdLate ? 'bad' : '' }, g.cr, g.crPend, { v: g.crLate, s: g.crLate ? 'bad' : '' }]);
      wb.sheet('Tổng quan', rows, { widths: [30, 10, 10, 14, 14, 14, 12, 10, 10, 16], merges: ['A1:J1', 'A2:J2'], headerRow: hr });
    }

    if (opts.sheets.late) {
      const rows = [['Loại', 'Tài khoản', 'Mã FD/CR', 'Mã đơn', 'Kho', 'Trạng thái', 'Giai đoạn', 'Ngày tạo', 'Hạn', 'Quá hạn (ngày)', 'Tuổi (ngày)', 'ĐVVC'].map((v) => ({ v, s: 'h' }))];
      for (const r of a.lateList) rows.push([r.kind.toUpperCase(), r.acc, r.code, r.order, r.wh, r.statusVi, r.stage, r.created, r.due,
        { v: +r.overdue.toFixed(1), s: 'bad' }, r.age == null ? '' : { v: +r.age.toFixed(1), s: 'dn' }, r.carrier]);
      wb.sheet('Đơn trễ', rows, { freeze: 1, filter: true, headerRow: 1, widths: [6, 24, 24, 14, 14, 22, 18, 17, 17, 12, 10, 16] });
    }

    for (const kind of ['fd', 'cr']) {
      if (!opts.sheets[kind]) continue;
      const groups = opts.split ? opts.groups : [{ label: 'Toàn bộ', recs: all }];
      for (const g of groups) {
        let rs = g.recs.filter((r) => r.kind === kind);
        if (opts.onlyPending) rs = rs.filter((r) => !r.done);
        if (!rs.length) continue;
        rs.sort((x, y) => (y.late - x.late) || ((y.overdue || 0) - (x.overdue || 0)) || ((x.created ? x.created.getTime() : 0) - (y.created ? y.created.getTime() : 0)));
        const cols = COLS[kind];
        let extraKeys = [];
        if (opts.rawFields) { const set = new Set(); for (const r of rs) for (const k in flatten(r.raw, '', {}, 0)) set.add(k); extraKeys = [...set].filter((k) => !/customer_info|pickup_info|\.phone|\.email|full_name/.test(k)).sort(); }
        const head = cols.map((c) => ({ v: c[0], s: 'h' })).concat(extraKeys.map((k) => ({ v: k, s: 'h' })));
        const rows = [head];
        for (const r of rs) { const f = extraKeys.length ? flatten(r.raw, '', {}, 0) : null; rows.push(cols.map((c) => { const v = c[1](r); return v == null ? '' : v; }).concat(extraKeys.map((k) => f[k] == null ? '' : f[k]))); }
        const name = (kind.toUpperCase()) + (opts.split ? ' · ' + g.label : (opts.onlyPending ? ' pending' : ' toàn bộ'));
        wb.sheet(name, rows, { freeze: 1, filter: true, headerRow: 1, widths: cols.map((c) => c[2]).concat(extraKeys.map(() => 16)) });
      }
    }

    // Sheet chi tiết dạng 1 dòng / 1 mục con
    const base = opts.onlyPending ? all.filter((r) => !r.done) : all;
    const H = (arr) => arr.map((v) => ({ v, s: 'h' }));
    const put = (name, head, rows, widths) => { if (rows.length) wb.sheet(name, [H(head)].concat(rows), { freeze: 1, filter: true, headerRow: 1, widths }); };
    if (opts.sheets.fdItems) {
      const rows = [];
      for (const r of base) if (r.kind === 'fd') for (const x of r.items) rows.push([r.acc, r.code, r.order, r.wh, r.statusVi, x.sku, x.name, x.qty, x.matched, x.processing, x.doneQty,
        x.missing ? { v: x.missing, s: 'bad' } : 0, x.status, x.note, r.pkgCodes, r.created]);
      put('FD - SKU', ['Tài khoản', 'Mã FD', 'Mã đơn', 'Kho', 'Trạng thái FD', 'SKU', 'Tên sản phẩm', 'SL', 'SL khớp', 'SL đang xử lý', 'SL xong', 'SL thiếu', 'TT dòng', 'Ghi chú', 'Phiếu nhập / kiện', 'Ngày tạo'],
        rows, [22, 22, 13, 9, 18, 16, 44, 6, 8, 11, 8, 8, 14, 20, 24, 17]);
    }
    if (opts.sheets.crProducts) {
      const rows = [];
      for (const r of base) if (r.kind === 'cr') for (const p of r.products) rows.push([r.acc, r.code, r.order, r.statusVi, r.carrier, p.sku, p.name, p.qty, p.price, p.price * p.qty, p.reason,
        p.resType, CR_STATUS[p.resStatus] || p.resStatus, p.counting, p.resolutionDetail, p.image, r.created]);
      put('CR - Sản phẩm', ['Tài khoản', 'Mã CR', 'Mã đơn gốc', 'Trạng thái CR', 'ĐVVC', 'SKU', 'Tên sản phẩm', 'SL', 'Đơn giá', 'Thành tiền', 'Lý do trả', 'Giải pháp', 'TT giải pháp', 'Kiểm đếm', 'Chi tiết giải pháp', 'Ảnh', 'Ngày tạo'],
        rows, [22, 16, 13, 20, 14, 16, 44, 6, 11, 12, 18, 16, 18, 12, 24, 40, 17]);
    }
    if (opts.sheets.timeline) {
      const rows = [];
      for (const r of base) for (const t of r.traces) rows.push([r.kind.toUpperCase(), r.acc, r.code, r.order, t.at, t.label, { v: t.status, s: 'mute' }, t.by, t.note]);
      put('Lịch sử trạng thái', ['Loại', 'Tài khoản', 'Mã FD/CR', 'Mã đơn', 'Thời điểm', 'Trạng thái', 'Mã trạng thái', 'Người thao tác', 'Ghi chú'], rows, [6, 22, 22, 13, 17, 28, 22, 18, 26]);
    }
    if (opts.sheets.videos) {
      const rows = [];
      for (const r of base) for (const v of r.videos) rows.push([r.kind.toUpperCase(), r.acc, r.code, r.order, r.wh, v.label, v.at, v.url]);
      put('Video & bằng chứng', ['Loại', 'Tài khoản', 'Mã FD/CR', 'Mã đơn', 'Kho', 'Bằng chứng', 'Ngày', 'Link'], rows, [6, 22, 22, 13, 10, 22, 17, 80]);
    }
    return wb;
  }

  function mailSummary(recs, opts) {
    const a = analyze(recs);
    const L = [];
    L.push('BÁO CÁO HẬU MÃI FD/CR — ' + new Date(opts.now || Date.now()).toLocaleString('vi-VN'));
    if (opts.accLabel) L.push('Tài khoản: ' + opts.accLabel);
    L.push('');
    L.push('FD (giao thất bại): pending ' + a.fd.pending + ' / trễ ' + a.fd.late + ' (SLA ' + opts.sla.fd + ' ngày)');
    a.fd.byWh.filter((g) => g.pending).slice(0, 12).forEach((g) => L.push('  • ' + g.k + ': pending ' + g.pending + ', trễ ' + g.late +
      ' — ' + a.fd.stages.filter((s) => g.stages[s]).map((s) => s.toLowerCase() + ' ' + g.stages[s]).join(', ') + '; tồn lâu nhất ' + g.maxAge.toFixed(1) + ' ngày'));
    L.push('');
    L.push('CR (thu hồi): pending ' + a.cr.pending + ' / trễ ' + a.cr.late + ' (quá ngày dự kiến về kho)');
    a.cr.stages.forEach((s) => { const n = a.cr.byCarrier.reduce((t, g) => t + (g.stages[s] || 0), 0); if (n) L.push('  • ' + s + ': ' + n); });
    a.cr.byCarrier.filter((g) => g.late).slice(0, 8).forEach((g) => L.push('  • ĐVVC ' + g.k + ': trễ ' + g.late + '/' + g.pending));
    if (a.accs.length > 1) { L.push(''); L.push('Theo tài khoản:'); a.accs.forEach((g) => L.push('  • ' + g.k + ': FD ' + g.fdPend + ' pending/' + g.fdLate + ' trễ · CR ' + g.crPend + ' pending/' + g.crLate + ' trễ')); }
    L.push(''); L.push('Chi tiết: xem file Excel đính kèm.');
    return L.join('\n');
  }

  root.HMEngine = { EVIDENCE_LABEL, imgUrl, PROFILES, FD_STATUS, CR_STATUS, DEFAULT_DONE, PENDING_PULL, STAGE_ORDER, parseDate, ymd, normalize, prepare, analyze, buildWorkbook, mailSummary, flatten };
})(typeof self !== 'undefined' ? self : this);
