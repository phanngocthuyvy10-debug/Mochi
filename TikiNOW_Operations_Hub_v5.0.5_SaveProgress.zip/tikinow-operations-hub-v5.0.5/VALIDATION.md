# Kiểm tra bản 5.0.1

Đã chạy trong môi trường kiểm tra:
- `node --check` cho toàn bộ JavaScript: đạt.
- Chạy engine với FD và CR dữ liệu giả: đạt.
- Thực thi buildWorkbook với bộ ghi sheet trong bộ nhớ: cột Seller ID đúng `r.sid`, giữ số 0 đầu; partner_code được xuất riêng: đạt.
- Thực thi hàm dựng cột của FD / CR / Tồn lâu và hàm openAfter trong Node VM với DOM giả: có mã sao chép và Seller ID trong chi tiết; partner_code riêng: đạt.
- Kiểm tra tìm kiếm hậu mãi chứa r.sid: đạt.
- Kiểm tra đủ tệp gốc trong gói ZIP và 11 endpoint trong inventory: đạt.

Dữ liệu kiểm tra là dữ liệu giả. Chưa kiểm tra trình duyệt thật, hiển thị bằng ảnh chụp, phiên Chrome extension hoặc API TikiNOW thật. Không tuyên bố đây là toàn bộ API của dịch vụ; đây là toàn bộ endpoint tìm thấy trong mã nguồn ZIP.

## Kiểm tra bổ sung bản 5.0.2

- Thực thi runListJob + orderSpec + pullWindow với API giả: 1.001 đơn delivered tải đủ 2 trang, truyền đúng seller, ngày tạo và trạng thái; đạt.
- Tổng đơn hủy lớn không ngăn tải tập delivered nằm trong giới hạn; đạt.
- Lịch sử tất cả trạng thái vẫn áp dụng giới hạn và không truyền bộ lọc trạng thái khi được phép tải; đạt.
- Chế độ Đang mở vẫn chỉ truyền các trạng thái chưa kết thúc; đạt.
- Nút tải hoàn tất chuyển chế độ, xóa bộ lọc cũ và chỉ đồng bộ Đơn hàng theo tài khoản chọn; đạt.
- FD/CR giữ nguyên sau lượt tải đơn hoàn tất; đạt.

Chưa kiểm tra với API TikiNOW thật hoặc Chrome có đăng nhập.

## Kiểm tra bản 5.0.3

- Mô phỏng 304.478 đơn với máy chủ cắt total ở 10.000: pullWindow chia khoảng và phân trang, thu đủ 304.478 ID duy nhất (351 request mô phỏng); đạt.
- Nâng cấu hình cũ 60.000 về 0 một lần, giữ giới hạn khác và các lựa chọn sau nâng cấp; đạt.
- Chạy lại kiểm tra 5.0.2: completed-only, nhiều trang, bộ lọc ngày/seller, giới hạn tự chọn, lịch sử mọi trạng thái, chế độ mở và nút tải riêng Đơn hàng; đạt.
- Chưa chạy API thật hoặc đo tài nguyên Chrome với tài khoản SC TEAM.

## Kiểm tra bản 5.0.4

- Parser: object/array/JSON envelope, media lồng nhau, URL không an toàn, mã đơn/seller khác, media trong chi tiết đơn; đạt.
- PRE-ORDER: boolean, label/tag, false, không rõ, mâu thuẫn; không lấy tag từ tên sản phẩm; đạt.
- Bộ tải chi tiết thực tế chạy với API giả: gọi cả hai nguồn cho đơn LM, giữ lỗi 403 riêng, giữ response object thành công, không lưu chi tiết sai mã; đạt.
- Tra mã đơn trực tiếp: lưu đúng đơn, đọc video, chặn seller không khớp trước khi lưu; đạt.
- Chẩn đoán: loại giá trị điện thoại, URL media và query ký số; đạt.
- Chạy lại kiểm tra seller ID, xuất Excel, tải completed, giữ FD/CR và mô phỏng 304.478 đơn; đạt.
- node --check toàn bộ JavaScript; đạt.

Chưa kiểm tra Chrome thật, API/video thật hoặc PRE-ORDER của đơn người dùng nêu.

## Kiểm tra bản 5.0.5

Thực thi mã lưu thật với fake-indexeddb 6.2.4: thay danh sách theo đợt, rollback khi dừng sau một đợt, rollback khi DataError giữa lượt ghi, giữ seller khác, danh sách rỗng; đạt. Lưu 280.229 bản ghi giả và kiểm tra số lượng cuối/progress chính xác; đạt. Kiểm tra helper trạng thái không hiện lỗi dừng cũ khi lượt hiện tại đang lưu; đạt. Chạy lại toàn bộ kiểm tra video, direct lookup, PRE-ORDER, giới hạn tuỳ chọn, completed, seller ID và Excel; đạt.

Không phải đo hiệu năng Chrome thật. Chưa kiểm tra trực tiếp trạng thái tab của người dùng.
