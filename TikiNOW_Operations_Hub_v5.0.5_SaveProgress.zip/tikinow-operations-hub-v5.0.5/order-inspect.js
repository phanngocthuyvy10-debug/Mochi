/* Read existing API payloads only. No request creation, auth handling or endpoint guessing. */
(function (root) {
  'use strict';
  const containers = /evidence|video|recording|media|document|attachment/i;
  const urlKeys = /^(url|file_url|video_url|video_pack_url|download_url|signed_url|playback_url|stream_url|media_url|link|video_link|file_link|download_link|playback_link|src)$/i;
  function links(payload, code, sellerId) {
    const out = new Map(), seen = new WeakSet(); let nodes = 0;
    function add(value, obj, path) {
      if (typeof value !== 'string') return;
      try {
        const u = new URL(value.trim().replace(/^["']|["']$/g, ''));
        if (!/^https?:$/.test(u.protocol) || u.username || u.password) return;
        if (!out.has(u.href)) out.set(u.href, { url: u.href, label: obj.name || obj.file_name || obj.document_name || obj.type || 'Video / bằng chứng', at: obj.created_at || null, path });
      } catch (_) {}
    }
    function visit(value, path, depth, stringMedia) {
      if (++nodes > 20000 || depth > 24 || value == null) return;
      if (typeof value === 'string') {
        if (/^\s*[\[{]/.test(value)) { try { visit(JSON.parse(value), path, depth + 1, stringMedia); } catch (_) {} }
        else if (stringMedia) add(value, {}, path);
        return;
      }
      if (typeof value !== 'object' || seen.has(value)) return;
      seen.add(value);
      if (code && value.order_code != null && String(value.order_code) !== String(code)) return;
      if (sellerId && value.seller_id != null && String(value.seller_id) !== String(sellerId)) return;
      if (Array.isArray(value)) { value.forEach((v, i) => visit(v, path + '[' + i + ']', depth + 1, stringMedia)); return; }
      for (const [key, child] of Object.entries(value)) {
        const next = path + '.' + key;
        if (urlKeys.test(key)) add(child, value, next);
        else if ((containers.test(key) || /^(data|result|results)$/i.test(key)) && typeof child === 'string' && /^https?:/i.test(child)) add(child, value, next);
        if (typeof child === 'object' || (typeof child === 'string' && /^\s*[\[{]/.test(child))) visit(child, next, depth + 1, stringMedia || containers.test(key));
      }
    }
    visit(payload, '$', 0, true);
    return [...out.values()];
  }
  function detailMedia(detail, code, sellerId) {
    const all = [], seen = new WeakSet();
    function visit(v, depth) {
      if (!v || typeof v !== 'object' || depth > 12 || seen.has(v)) return;
      seen.add(v);
      if (code && v.order_code != null && String(v.order_code) !== String(code)) return;
      if (sellerId && v.seller_id != null && String(v.seller_id) !== String(sellerId)) return;
      for (const [k, child] of Object.entries(v)) {
        if (/evidence|video|recording/i.test(k)) all.push(...links(child, code, sellerId));
        else if (child && typeof child === 'object' && !/items|products|address|customer/i.test(k)) visit(child, depth + 1);
      }
    }
    visit(detail, 0); return [...new Map(all.map(x => [x.url, x])).values()];
  }
  const preLabel = v => typeof v === 'string' && /^pre[\s_-]*order$/i.test(v.trim());
  function preorder(detail) {
    const evidence = [], seen = new WeakSet();
    function visit(v, path, depth, tagContext) {
      if (v == null || depth > 8) return;
      if (typeof v === 'string') { if (tagContext && preLabel(v)) evidence.push({ path, value: v, enabled: true }); return; }
      if (typeof v !== 'object' || seen.has(v)) return;
      seen.add(v);
      if (Array.isArray(v)) { v.forEach((x, i) => visit(x, path + '[' + i + ']', depth + 1, tagContext)); return; }
      for (const [k, x] of Object.entries(v)) {
        const at = path + '.' + k;
        if (/^(is_?)?pre_?order$/i.test(k)) {
          const val = x === true || x === 1 || x === '1' || x === 'true' ? true : x === false || x === 0 || x === '0' || x === 'false' ? false : null;
          if (val !== null) evidence.push({ path: at, value: x, enabled: val });
        } else if ((/^(order_type|type|code|label|name|value)$/i.test(k)) && (tagContext || /order_type/.test(k)) && preLabel(x)) evidence.push({ path: at, value: x, enabled: true });
        if (/^(extra|flags|attributes|metadata|tags|labels|order_tags)$/i.test(k)) visit(x, at, depth + 1, tagContext || /tags|labels/.test(k));
        else if (tagContext && x && typeof x === 'object') visit(x, at, depth + 1, true);
      }
    }
    visit(detail, '$', 0, false);
    const states = new Set(evidence.map(x => x.enabled));
    return { known: states.size === 1, value: states.size === 1 ? evidence[0].enabled : null, conflict: states.size > 1, evidence };
  }
  function shape(v, depth) {
    depth = depth || 0;
    if (v === null) return 'null';
    if (Array.isArray(v)) return { type: 'array', length: v.length, sampleShape: depth < 4 ? v.slice(0, 2).map(x => shape(x, depth + 1)) : [] };
    if (typeof v !== 'object') return typeof v;
    if (depth > 4) return 'object';
    return Object.fromEntries(Object.entries(v).slice(0, 100).filter(([k]) => !/token|cookie|authorization|password|secret/i.test(k)).map(([k, x]) => [k, shape(x, depth + 1)]));
  }
  function redact(value) {
    if (value == null) return value;
    if (typeof value === 'string') {
      if (/^https?:/i.test(value)) { try { const u = new URL(value); return u.origin + '/[media-path-redacted]' + (u.search ? '?[query-redacted]' : ''); } catch (_) {} }
      if (/Bearer\s|eyJ[A-Za-z0-9_-]+\./i.test(value)) return '[credential-redacted]';
      return value.slice(0, 500);
    }
    if (Array.isArray(value)) return value.map(redact);
    if (typeof value !== 'object') return value;
    return Object.fromEntries(Object.entries(value).filter(([k]) => !/token|cookie|authorization|password|secret|phone|email|address|recipient|customer/i.test(k)).map(([k, v]) => [k, redact(v)]));
  }
  function signals(payload) {
    const out = [], seen = new WeakSet();
    function visit(v, path, depth) {
      if (!v || typeof v !== 'object' || depth > 8 || seen.has(v) || out.length >= 100) return;
      seen.add(v);
      for (const [k, x] of Object.entries(v)) {
        if (/token|cookie|authorization|password|secret|phone|email|address|customer/i.test(k)) continue;
        if (/^(success|status|state|is_available|available|has_video|has_video_pack|is_video_pack|video_status|request_status|total|count)$/i.test(k) && (typeof x === 'boolean' || typeof x === 'number' || typeof x === 'string')) out.push({ path: path + '.' + k, value: typeof x === 'string' ? x.slice(0, 120) : x });
        if (x && typeof x === 'object') visit(x, path + '.' + k, depth + 1);
      }
    }
    visit(payload, '$', 0); return out;
  }
  function report(code, sid, sources, detail) {
    return redact({ order_code: code, seller_id: sid, checked_at: new Date().toISOString(), preorder: preorder(detail), order_shape: shape(detail), sources: (sources || []).map(s => ({ id: s.id, ok: s.ok, error: s.error || null, response_shape: s.ok ? shape(s.payload) : null, signals: s.ok ? signals(s.payload) : [], links: s.ok ? links(s.payload, code, sid) : [] })) });
  }
  root.OrderInspect = { links, detailMedia, preorder, shape, report };
})(typeof self !== 'undefined' ? self : this);
