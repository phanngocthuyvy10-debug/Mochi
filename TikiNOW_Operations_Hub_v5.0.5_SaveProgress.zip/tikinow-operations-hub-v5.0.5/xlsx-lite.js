/* xlsx-lite — ghi file .xlsx nhiều sheet, không cần thư viện ngoài.
 * Hỗ trợ: style header, ngày giờ, số, %, tô màu ô, độ rộng cột, freeze dòng đầu, autofilter.
 * Nén bằng CompressionStream('deflate-raw') (Chrome 103+), tự lùi về STORE nếu không có.
 *
 * API:
 *   const wb = XLSXLite.workbook();
 *   wb.sheet('Tên', rows, { widths:[..], freeze:1, filter:true, merges:['A1:D1'] });
 *     rows: mảng các dòng; mỗi ô là string | number | Date | null | {v, s}
 *     s (style): 'h' header, 't' tiêu đề, 'b' đậm, 'd' ngày giờ, 'n' số, 'p' %,
 *                'bad' đỏ, 'warn' cam, 'ok' xanh, 'mute' xám, 'sub' dòng tổng
 *   const blob = await wb.toBlob();
 */
(function (root) {
  'use strict';

  const STYLE_IDX = { '': 0, h: 1, t: 2, b: 3, d: 4, n: 5, p: 6, bad: 7, warn: 8, ok: 9, mute: 10, sub: 11, dn: 12 };

  const STYLES_XML =
    '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
    '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">' +
    '<numFmts count="2"><numFmt numFmtId="164" formatCode="dd/mm/yyyy hh:mm"/><numFmt numFmtId="165" formatCode="0.0"/></numFmts>' +
    '<fonts count="6">' +
      '<font><sz val="10"/><name val="Arial"/></font>' +                                   // 0 thường
      '<font><b/><sz val="10"/><color rgb="FFFFFFFF"/><name val="Arial"/></font>' +        // 1 header trắng
      '<font><b/><sz val="14"/><color rgb="FF0F2A3D"/><name val="Arial"/></font>' +        // 2 tiêu đề
      '<font><b/><sz val="10"/><name val="Arial"/></font>' +                               // 3 đậm
      '<font><b/><sz val="10"/><color rgb="FFB42318"/><name val="Arial"/></font>' +        // 4 đỏ
      '<font><sz val="10"/><color rgb="FF667085"/><name val="Arial"/></font>' +            // 5 xám
    '</fonts>' +
    '<fills count="7">' +
      '<fill><patternFill patternType="none"/></fill>' +
      '<fill><patternFill patternType="gray125"/></fill>' +
      '<fill><patternFill patternType="solid"><fgColor rgb="FF0F2A3D"/></patternFill></fill>' +   // 2 header
      '<fill><patternFill patternType="solid"><fgColor rgb="FFFDECEA"/></patternFill></fill>' +   // 3 đỏ nhạt
      '<fill><patternFill patternType="solid"><fgColor rgb="FFFEF4E6"/></patternFill></fill>' +   // 4 cam nhạt
      '<fill><patternFill patternType="solid"><fgColor rgb="FFE8F6EF"/></patternFill></fill>' +   // 5 xanh nhạt
      '<fill><patternFill patternType="solid"><fgColor rgb="FFEEF2F6"/></patternFill></fill>' +   // 6 dòng tổng
    '</fills>' +
    '<borders count="2"><border/><border>' +
      '<left style="thin"><color rgb="FFD0D5DD"/></left><right style="thin"><color rgb="FFD0D5DD"/></right>' +
      '<top style="thin"><color rgb="FFD0D5DD"/></top><bottom style="thin"><color rgb="FFD0D5DD"/></bottom>' +
    '</border></borders>' +
    '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>' +
    '<cellXfs count="13">' +
      '<xf numFmtId="0" fontId="0" fillId="0" borderId="1" applyBorder="1"><alignment vertical="top"/></xf>' +                                          // 0
      '<xf numFmtId="0" fontId="1" fillId="2" borderId="1" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment vertical="center" wrapText="1"/></xf>' + // 1 h
      '<xf numFmtId="0" fontId="2" fillId="0" borderId="0" applyFont="1"/>' +                                                                             // 2 t
      '<xf numFmtId="0" fontId="3" fillId="0" borderId="1" applyFont="1" applyBorder="1"/>' +                                                             // 3 b
      '<xf numFmtId="164" fontId="0" fillId="0" borderId="1" applyNumberFormat="1" applyBorder="1"/>' +                                                   // 4 d
      '<xf numFmtId="3" fontId="0" fillId="0" borderId="1" applyNumberFormat="1" applyBorder="1"/>' +                                                     // 5 n
      '<xf numFmtId="9" fontId="0" fillId="0" borderId="1" applyNumberFormat="1" applyBorder="1"/>' +                                                     // 6 p
      '<xf numFmtId="0" fontId="4" fillId="3" borderId="1" applyFont="1" applyFill="1" applyBorder="1"/>' +                                               // 7 bad
      '<xf numFmtId="0" fontId="0" fillId="4" borderId="1" applyFill="1" applyBorder="1"/>' +                                                             // 8 warn
      '<xf numFmtId="0" fontId="0" fillId="5" borderId="1" applyFill="1" applyBorder="1"/>' +                                                             // 9 ok
      '<xf numFmtId="0" fontId="5" fillId="0" borderId="0" applyFont="1"/>' +                                                                             // 10 mute
      '<xf numFmtId="3" fontId="3" fillId="6" borderId="1" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1"/>' +                         // 11 sub
      '<xf numFmtId="165" fontId="0" fillId="0" borderId="1" applyNumberFormat="1" applyBorder="1"/>' +                                                   // 12 dn (1 số lẻ)
    '</cellXfs>' +
    '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>' +
    '</styleSheet>';

  // Bỏ ký tự điều khiển XML không hợp lệ
  const BAD_XML = /[\u0000-\u0008\u000B\u000C\u000E-\u001F￾￿]/g;
  function x(s) {
    return String(s).replace(BAD_XML, '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  function colName(i) {
    let s = '';
    i += 1;
    while (i > 0) { const m = (i - 1) % 26; s = String.fromCharCode(65 + m) + s; i = Math.floor((i - 1) / 26); }
    return s;
  }

  function excelDate(d) {
    // Giữ nguyên giờ địa phương (giờ VN) như người dùng thấy
    const ms = d.getTime() + 7 * 3600000; // Explicit Vietnam time, independent of PC timezone
    return ms / 86400000 + 25569;
  }

  const isDate = (v) => Object.prototype.toString.call(v) === '[object Date]';
  function cellXml(ref, cell) {
    let v = cell, s = '';
    if (cell && typeof cell === 'object' && !isDate(cell)) { v = cell.v; s = cell.s || ''; }
    if (isDate(v)) {
      if (isNaN(v)) return '';
      return `<c r="${ref}" s="${STYLE_IDX.d}"><v>${excelDate(v)}</v></c>`;
    }
    const si = STYLE_IDX[s] != null ? STYLE_IDX[s] : 0;
    if (v === null || v === undefined || v === '') return si ? `<c r="${ref}" s="${si}"/>` : '';
    if (typeof v === 'number' && isFinite(v)) return `<c r="${ref}" s="${si}"><v>${v}</v></c>`;
    if (typeof v === 'boolean') return `<c r="${ref}" s="${si}" t="b"><v>${v ? 1 : 0}</v></c>`;
    let str = String(v);
    if (str.length > 32000) str = str.slice(0, 32000);
    return `<c r="${ref}" s="${si}" t="inlineStr"><is><t xml:space="preserve">${x(str)}</t></is></c>`;
  }

  function sheetXml(rows, opt) {
    opt = opt || {};
    const out = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
      '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'];
    let maxCols = 0;
    for (const r of rows) if (r && r.length > maxCols) maxCols = r.length;
    const freeze = opt.freeze || 0;
    out.push('<sheetViews><sheetView workbookViewId="0"' + (opt.zoom ? ` zoomScale="${opt.zoom}"` : '') + '>');
    if (freeze) out.push(`<pane ySplit="${freeze}" topLeftCell="A${freeze + 1}" activePane="bottomLeft" state="frozen"/><selection pane="bottomLeft"/>`);
    out.push('</sheetView></sheetViews>');
    out.push('<sheetFormatPr defaultRowHeight="15"/>');
    if (opt.widths && opt.widths.length) {
      out.push('<cols>');
      opt.widths.forEach((w, i) => { if (w) out.push(`<col min="${i + 1}" max="${i + 1}" width="${w}" customWidth="1"/>`); });
      out.push('</cols>');
    }
    out.push('<sheetData>');
    rows.forEach((r, ri) => {
      if (!r) { out.push(`<row r="${ri + 1}"/>`); return; }
      const cells = [];
      for (let ci = 0; ci < r.length; ci++) {
        const c = cellXml(colName(ci) + (ri + 1), r[ci]);
        if (c) cells.push(c);
      }
      const ht = opt.headerRow && ri + 1 === opt.headerRow ? ' ht="30" customHeight="1"' : '';
      out.push(`<row r="${ri + 1}"${ht}>${cells.join('')}</row>`);
    });
    out.push('</sheetData>');
    if (opt.filter && rows.length > (opt.headerRow || 1) && maxCols) {
      const hr = opt.headerRow || 1;
      out.push(`<autoFilter ref="A${hr}:${colName(maxCols - 1)}${rows.length}"/>`);
    }
    if (opt.merges && opt.merges.length) {
      out.push(`<mergeCells count="${opt.merges.length}">` + opt.merges.map((m) => `<mergeCell ref="${m}"/>`).join('') + '</mergeCells>');
    }
    out.push('<pageMargins left="0.5" right="0.5" top="0.75" bottom="0.75" header="0.3" footer="0.3"/>');
    out.push('</worksheet>');
    return out.join('');
  }

  function safeSheetName(name, used) {
    let n = String(name || 'Sheet').replace(/[\[\]:*?\/\\]/g, ' ').trim().slice(0, 31) || 'Sheet';
    let base = n, i = 2;
    while (used.has(n.toLowerCase())) { const suf = ' (' + i++ + ')'; n = base.slice(0, 31 - suf.length) + suf; }
    used.add(n.toLowerCase());
    return n;
  }

  /* ---------- ZIP ---------- */
  const CRC_TABLE = (() => {
    const t = new Uint32Array(256);
    for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; }
    return t;
  })();
  function crc32(buf) {
    let c = 0xFFFFFFFF;
    for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xFF] ^ (c >>> 8);
    return (c ^ 0xFFFFFFFF) >>> 0;
  }

  async function deflateRaw(data) {
    if (typeof CompressionStream === 'undefined') return null;
    try {
      const cs = new CompressionStream('deflate-raw');
      const stream = new Blob([data]).stream().pipeThrough(cs);
      const ab = await new Response(stream).arrayBuffer();
      return new Uint8Array(ab);
    } catch (e) { return null; }
  }

  function dosTime(d) {
    const time = (d.getHours() << 11) | (d.getMinutes() << 5) | (Math.floor(d.getSeconds() / 2));
    const date = ((d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate();
    return { time, date };
  }

  async function zip(files) {
    const enc = new TextEncoder();
    const parts = [];
    const central = [];
    let offset = 0;
    const { time, date } = dosTime(new Date());
    for (const f of files) {
      const name = enc.encode(f.name);
      const raw = typeof f.data === 'string' ? enc.encode(f.data) : f.data;
      const crc = crc32(raw);
      const comp = await deflateRaw(raw);
      const useDeflate = comp && comp.length < raw.length;
      const body = useDeflate ? comp : raw;
      const method = useDeflate ? 8 : 0;

      const lh = new DataView(new ArrayBuffer(30));
      lh.setUint32(0, 0x04034b50, true); lh.setUint16(4, 20, true); lh.setUint16(6, 0x0800, true);
      lh.setUint16(8, method, true); lh.setUint16(10, time, true); lh.setUint16(12, date, true);
      lh.setUint32(14, crc, true); lh.setUint32(18, body.length, true); lh.setUint32(22, raw.length, true);
      lh.setUint16(26, name.length, true); lh.setUint16(28, 0, true);
      parts.push(new Uint8Array(lh.buffer), name, body);

      const ch = new DataView(new ArrayBuffer(46));
      ch.setUint32(0, 0x02014b50, true); ch.setUint16(4, 20, true); ch.setUint16(6, 20, true);
      ch.setUint16(8, 0x0800, true); ch.setUint16(10, method, true); ch.setUint16(12, time, true); ch.setUint16(14, date, true);
      ch.setUint32(16, crc, true); ch.setUint32(20, body.length, true); ch.setUint32(24, raw.length, true);
      ch.setUint16(28, name.length, true); ch.setUint16(30, 0, true); ch.setUint16(32, 0, true);
      ch.setUint16(34, 0, true); ch.setUint16(36, 0, true); ch.setUint32(38, 0, true); ch.setUint32(42, offset, true);
      central.push(new Uint8Array(ch.buffer), name);

      offset += 30 + name.length + body.length;
    }
    const cdSize = central.reduce((a, b) => a + b.length, 0);
    const end = new DataView(new ArrayBuffer(22));
    end.setUint32(0, 0x06054b50, true); end.setUint16(8, files.length, true); end.setUint16(10, files.length, true);
    end.setUint32(12, cdSize, true); end.setUint32(16, offset, true);
    return new Blob([...parts, ...central, new Uint8Array(end.buffer)], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  }

  function workbook() {
    const sheets = [];
    const used = new Set();
    return {
      sheet(name, rows, opt) { sheets.push({ name: safeSheetName(name, used), rows, opt: opt || {} }); return this; },
      get count() { return sheets.length; },
      async toBlob() {
        if (!sheets.length) this.sheet('Sheet1', [['(trống)']]);
        const files = [];
        files.push({ name: '[Content_Types].xml', data:
          '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
          '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">' +
          '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>' +
          '<Default Extension="xml" ContentType="application/xml"/>' +
          '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>' +
          '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>' +
          sheets.map((s, i) => `<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join('') +
          '</Types>' });
        files.push({ name: '_rels/.rels', data:
          '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
          '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
          '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>' +
          '</Relationships>' });
        files.push({ name: 'xl/workbook.xml', data:
          '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
          '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">' +
          '<sheets>' + sheets.map((s, i) => `<sheet name="${x(s.name)}" sheetId="${i + 1}" r:id="rId${i + 1}"/>`).join('') + '</sheets>' +
          (sheets.some((s) => s.opt.filter) ? '<definedNames>' + sheets.map((s, i) => {
            if (!s.opt.filter || s.rows.length <= (s.opt.headerRow || 1)) return '';
            let mc = 0; for (const r of s.rows) if (r && r.length > mc) mc = r.length;
            const hr = s.opt.headerRow || 1;
            return `<definedName name="_xlnm._FilterDatabase" localSheetId="${i}" hidden="1">'${x(s.name).replace(/'/g, "''")}'!$A$${hr}:$${colName(mc - 1)}$${s.rows.length}</definedName>`;
          }).join('') + '</definedNames>' : '') +
          '</workbook>' });
        files.push({ name: 'xl/_rels/workbook.xml.rels', data:
          '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
          '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
          sheets.map((s, i) => `<Relationship Id="rId${i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i + 1}.xml"/>`).join('') +
          `<Relationship Id="rId${sheets.length + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>` +
          '</Relationships>' });
        files.push({ name: 'xl/styles.xml', data: STYLES_XML });
        sheets.forEach((s, i) => files.push({ name: `xl/worksheets/sheet${i + 1}.xml`, data: sheetXml(s.rows, s.opt) }));
        return zip(files);
      },
    };
  }

  root.XLSXLite = { workbook, colName };
})(typeof self !== 'undefined' ? self : this);
