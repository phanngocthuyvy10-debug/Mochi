/* Hậu mãi Hub — token đăng nhập TikiNOW Center, mỗi seller 1 token (JWT sống ~24h).
 * Nguồn: cookie ACP_AUTH của tikinowcenter.tikinow.vn = {"accessToken","expiresIn","expiresAt"}.
 * Token này gọi được cả FD (api.tikinow.vn/fulfillment) lẫn CR (api.tikinow.vn/tnc-ams) với header Bearer.
 * Dùng chung cho background.js (importScripts) và app.html. Không lưu mật khẩu; không gửi đi đâu ngoài Tiki.
 */
'use strict';
const CENTER = 'https://tikinowcenter.tikinow.vn';
const ACC_KEY = 'accounts';

const jwtExp = (tk) => {
  try { return JSON.parse(atob(tk.split('.')[1].replace(/-/g, '+').replace(/_/g, '/'))).exp * 1000; } catch (e) { return 0; }
};
const tokenAlive = (a) => !!(a && a.tk && !a.dead && a.exp > Date.now() + 60000);

async function getAccounts() { return (await chrome.storage.local.get(ACC_KEY))[ACC_KEY] || {}; }
async function patchAccount(sellerId, patch) {
  const all = await getAccounts();
  if (patch === null) delete all[sellerId];
  else all[sellerId] = Object.assign({}, all[sellerId], patch);
  await chrome.storage.local.set({ [ACC_KEY]: all });
}

const tokenOfCookie = (v) => JSON.parse(decodeURIComponent(v)).accessToken;

// Hỏi /api/user để biết token thuộc seller nào.
async function readAccount(tk) {
  const r = await fetch(CENTER + '/api/user?include=permissions,roles', { headers: { Accept: 'application/json', Authorization: 'Bearer ' + tk } });
  if (!r.ok) throw new Error('TikiNOW không nhận token (HTTP ' + r.status + ') — đăng nhập lại tikinowcenter.tikinow.vn.');
  const j = await r.json(); const d = j.data || j;
  if (!d.seller_id) throw new Error('Token không gắn seller_id.');
  return { sellerId: String(d.seller_id), name: d.name || '', email: d.email || '', tk, exp: jwtExp(tk), savedAt: Date.now(), dead: false };
}

async function saveTokenFromCookie(value) {
  const acc = await readAccount(tokenOfCookie(value));
  const prev = (await getAccounts())[acc.sellerId] || {};
  await patchAccount(acc.sellerId, Object.assign({ firstSeenAt: prev.firstSeenAt || Date.now() }, acc));
  return acc;
}

const acpFromDocCookie = (s) => { const m = String(s || '').match(/(?:^|;\s*)ACP_AUTH=([^;]+)/); return m ? m[1] : null; };

/* Tìm cookie ACP_AUTH theo 3 đường (mới nhất trước), dừng ở đường đầu tiên tìm thấy:
 *  1) chrome.cookies theo URL   2) chrome.cookies theo domain, mọi cookie store
 *  3) đọc document.cookie của các tab TikiNOW Center đang mở (chrome.scripting)
 * Trả về diag để báo đúng lý do khi không tìm thấy. */
async function findAcpValues() {
  const vals = new Map(); const diag = [];
  const add = (v, exp) => { if (v && !vals.has(v)) vals.set(v, exp || 0); };
  if (chrome.cookies) {
    try { for (const c of await chrome.cookies.getAll({ url: CENTER + '/', name: 'ACP_AUTH' })) add(c.value, c.expirationDate); }
    catch (e) { diag.push('cookies(url): ' + e.message); }
    if (!vals.size) {
      try {
        const stores = chrome.cookies.getAllCookieStores ? await chrome.cookies.getAllCookieStores() : [{ id: undefined }];
        for (const st of stores) for (const c of await chrome.cookies.getAll({ domain: 'tikinow.vn', name: 'ACP_AUTH', storeId: st.id })) add(c.value, c.expirationDate);
      } catch (e) { diag.push('cookies(domain): ' + e.message); }
    }
  } else diag.push('extension chưa có quyền cookies (gỡ và cài lại extension)');
  if (!vals.size && chrome.scripting && chrome.tabs) {
    try {
      const tabs = await chrome.tabs.query({ url: CENTER + '/*' });
      if (!tabs.length) diag.push('không có tab tikinowcenter nào đang mở');
      for (const t of tabs) {
        try {
          const [res] = await chrome.scripting.executeScript({ target: { tabId: t.id }, func: () => document.cookie });
          add(acpFromDocCookie(res && res.result), 1);
        } catch (e) { diag.push('tab ' + t.id + ': ' + e.message); }
      }
    } catch (e) { diag.push('tabs: ' + e.message); }
  }
  return { values: [...vals.entries()].sort((a, b) => b[1] - a[1]).map((x) => x[0]), diag };
}

async function captureFromCookies() {
  const { values, diag } = await findAcpValues();
  const out = []; let lastErr = null;
  for (const v of values) {
    try { out.push(await saveTokenFromCookie(v)); } catch (e) { lastErr = e; diag.push(e.message); }
  }
  return { current: out[0] || null, found: values.length, error: out.length ? null : lastErr, diag };
}
