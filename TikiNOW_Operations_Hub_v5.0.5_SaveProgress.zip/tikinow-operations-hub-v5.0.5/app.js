/* TikiNOW Operations Hub v5 — controller.
 * Nguyên tắc: (1) mặc định chỉ kéo việc ĐANG MỞ (đơn chưa giao xong, FD/CR chưa kết thúc) — vài chục request;
 * (2) mọi trang chạy song song qua 1 bộ giới hạn chung; (3) tôn trọng trần 10.000 dòng/truy vấn bằng cách chia
 * khung thời gian; (4) chi tiết đơn hàng chỉ tải khi mở đơn; chi tiết FD/CR đang mở chạy nền, có cache. */
'use strict';
const E = window.HMEngine, K = window.TNKPI, X = window.XLSXLite;
const $ = (s, r) => (r || document).querySelector(s);
const $$ = (s, r) => [...(r || document).querySelectorAll(s)];
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const nf = (n) => (n == null || n === '' ? '' : Number(n).toLocaleString('vi-VN'));
const VN = new Intl.DateTimeFormat('vi-VN', { timeZone: 'Asia/Ho_Chi_Minh', day: '2-digit', month: '2-digit', year: '2-digit', hour: '2-digit', minute: '2-digit' });
const fdt = (d) => { if (d == null || d === '') return ''; const x = d instanceof Date ? d : /^\d{1,2}\/\d{1,2}\/\d{4}/.test(String(d)) ? E.parseDate(d) : K.date(d) || E.parseDate(d); return x && !isNaN(x) ? VN.format(x) : ''; };
const ago = (t) => { const m = Math.round((Date.now() - t) / 60000); return m < 1 ? 'vừa xong' : m < 60 ? m + ' phút trước' : m < 1440 ? Math.round(m / 60) + ' giờ trước' : Math.round(m / 1440) + ' ngày trước'; };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const debounce = (f, ms) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => f(...a), ms); }; };
const fmtDur = (s) => (s < 60 ? Math.max(1, Math.round(s)) + ' giây' : s < 3600 ? Math.round(s / 60) + ' phút' : (s / 3600).toFixed(1) + ' giờ');
const vnSec = (ms) => new Date(ms + 7 * 3600e3).toISOString().slice(0, 19).replace('T', ' ');
const vnDay = (ms) => new Date(ms + 7 * 3600e3).toISOString().slice(0, 10);
const dayStart = (ymd) => Date.parse(ymd + 'T00:00:00+07:00');
const API = 'https://api.tikinow.vn';
const CENTER_URL = 'https://tikinowcenter.tikinow.vn/new#/';

/* ======================= SETTINGS ======================= */
const DEFAULTS = {
  mode: 'open', orderStatus: '', days: 30, from: '', to: '', kinds: { orders: true, fd: true, cr: true },
  aftersalesDetail: true, concurrency: 6, autoSync: true, theme: '', rangeLimit: 0,
  slaFd: 3, slaCr: 7, crUseEta: true, done: { fd: E.DEFAULT_DONE.fd.slice(), cr: E.DEFAULT_DONE.cr.slice() },
  holidays: [], peakDays: [], b2bGroup: '', priorityMode: 'exact', orderOverrides: {}, reverseOverrides: {},
};
let S = {};
async function loadSettings() {
  const o = await chrome.storage.local.get(['settingsV5', 'settings']);
  const old = o.settings || {};
  S = Object.assign({}, DEFAULTS, o.settingsV5 || {
    // giữ quy tắc người dùng đã chỉnh ở bản cũ
    slaFd: old.slaFd ?? DEFAULTS.slaFd, slaCr: old.slaCr ?? DEFAULTS.slaCr, crUseEta: old.crUseEta ?? true,
    done: old.done && old.done.fd ? old.done : DEFAULTS.done, holidays: old.holidays || [], peakDays: old.peakDays || [],
    b2bGroup: old.b2bGroup || '', priorityMode: old.priorityMode || 'exact', orderOverrides: old.orderOverrides || {}, reverseOverrides: old.reverseOverrides || {}, theme: old.theme || '',
  });
  S.kinds = Object.assign({}, DEFAULTS.kinds, S.kinds);
  const migrateLimit = S.rangeLimitPolicy !== 'optional';
  if (migrateLimit) {
    if (+S.rangeLimit === 60000) S.rangeLimit = 0;
    S.rangeLimitPolicy = 'optional';
  }
  if (!Number.isFinite(+S.rangeLimit) || +S.rangeLimit < 0) S.rangeLimit = 0;
  if (!o.settingsV5) await cleanupLegacy();
  if (!o.settingsV5 || migrateLimit) await saveSettings();
  fixRange();
}
const saveSettings = () => chrome.storage.local.set({ settingsV5: S });
function fixRange() {
  const today = vnDay(Date.now());
  if (!S.to || S.days) S.to = today;
  if (!S.from || S.days) S.from = vnDay(dayStart(S.to) - (Math.max(1, S.days || 30) - 1) * 86400e3);
  if (S.from > S.to) S.from = S.to;
}
// Bản 4.x giữ hàng trăm nghìn đơn + kho ghi nhận API trong IndexedDB — dọn để Chrome nhẹ lại.
async function cleanupLegacy() {
  for (const n of ['hmhub_v2', 'tnhub_capture_archive']) try { indexedDB.deleteDatabase(n); } catch (e) {}
  await chrome.storage.local.remove(['dataMeta', 'orderMeta', 'screenScan', 'captureHealth', 'apiCaptureEnabled', 'deferredScreenScan', 'referenceData', 'apiSnapshots', 'endpoints', 'current']);
}
function applyTheme() {
  const t = S.theme || (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
  document.documentElement.setAttribute('data-theme', t);
}

/* ======================= STORAGE ======================= */
let dbP;
function db() {
  if (!dbP) dbP = new Promise((res, rej) => {
    const r = indexedDB.open('tnhub_v5', 1);
    r.onupgradeneeded = () => {
      const d = r.result;
      d.createObjectStore('rows', { keyPath: 'key' }).createIndex('sk', 'sk');
      d.createObjectStore('details', { keyPath: 'key' });
      d.createObjectStore('products', { keyPath: 'k' });
      d.createObjectStore('extids', { keyPath: 'k' });
    };
    r.onblocked = () => rej(new Error('Đang có tab Hub cũ giữ dữ liệu — đóng các tab Hub khác rồi F5.'));
    r.onsuccess = () => { r.result.onversionchange = () => r.result.close(); res(r.result); };
    r.onerror = () => rej(r.error);
  });
  return dbP;
}
const txDone = (t) => new Promise((res, rej) => { t.oncomplete = res; t.onerror = () => rej(t.error); t.onabort = () => rej(t.error); });
async function storeAll(name) { const d = await db(); return new Promise((res, rej) => { const q = d.transaction(name).objectStore(name).getAll(); q.onsuccess = () => res(q.result || []); q.onerror = () => rej(q.error); }); }
async function storePut(name, rows) { if (!rows.length) return; const d = await db(); const t = d.transaction(name, 'readwrite'); const s = t.objectStore(name); rows.forEach((r) => s.put(r)); await txDone(t); }
async function storeClear(name) { const d = await db(); const t = d.transaction(name, 'readwrite'); t.objectStore(name).clear(); await txDone(t); }
// Thay toàn bộ dữ liệu của (seller, loại) bằng lượt mới — cùng 1 transaction, lỗi giữa chừng thì giữ bản cũ.
async function replaceRows(sid, kind, items, onProgress) {
  const d = await db(), t = d.transaction('rows', 'readwrite'), s = t.objectStore('rows');
  const completion = txDone(t); let failure = null, removed = 0, offset = 0;
  const report = (phase, n) => { if (onProgress) onProgress(phase, n, items.length); };
  const abort = (e) => { failure = e; try { t.abort(); } catch (_) {} };
  const checkStop = () => { if (STOP) { abort(stopErr()); return true; } return false; };
  function writeBatch() {
    if (checkStop()) return;
    if (offset >= items.length) { report('writing', offset); return; }
    try {
      const end = Math.min(items.length, offset + 250); let tail;
      for (let i = offset; i < end; i++) tail = s.put(items[i]);
      // Queue the next batch inside the active IndexedDB request handler.
      // Keep one atomic transaction; errors/cancel restore the previous dataset.
      tail.onsuccess = () => {
        try { offset = end; report('writing', offset); writeBatch(); }
        catch (e) { abort(e); }
      };
    } catch (e) { abort(e); }
  }
  report('deleting', 0);
  const c = s.index('sk').openKeyCursor(IDBKeyRange.only(sid + '|' + kind));
  c.onsuccess = () => {
    if (checkStop()) return;
    try {
      const cur = c.result;
      if (cur) { s.delete(cur.primaryKey); removed++; if (removed % 250 === 0) report('deleting', removed); cur.continue(); }
      else { report('writing', 0); writeBatch(); }
    } catch (e) { abort(e); }
  };
  try { await completion; } catch (e) { throw failure || e || new Error('Không lưu được IndexedDB; dữ liệu trước được giữ.'); }
}

/* ======================= STATE ======================= */
const ROWS = { orders: [], fd: [], cr: [] };      // {key, sk, kind, sid, acc, row}
let DET = new Map();                               // key -> {key, detail, upd, st, at, ev, evAt, extra}
let PROD = {}, EXT = {};
let META = {};                                     // sid|kind -> {at, mode, from, to, count, total, error, warn}
let COUNTS = {};                                   // sid -> {at, from, to, statuses}
let ACCOUNTS = {};
let ACCF = '';
let ORDERS = [], AFTER = [], A = null, OV = [], AV = [];
let CURRENT = 'overview';

const okey = (kind, sid, code) => kind + '|' + sid + '|' + code;
const codeOf = (kind, row) => (kind === 'orders' ? row.order_code : kind === 'fd' ? row.code : row.cr_code);
const accLabel = (a) => (a && (a.name || a.email)) || ('seller ' + (a && a.sellerId));
const kcfg = () => ({ now: Date.now(), holidays: S.holidays, peakDays: S.peakDays, priorityMode: S.priorityMode, b2bGroup: S.b2bGroup, overrides: S.orderOverrides, reverseOverrides: S.reverseOverrides });
const ecfg = () => ({ now: Date.now(), slaFd: +S.slaFd, slaCr: +S.slaCr, crUseEta: !!S.crUseEta, done: S.done, products: PROD, ext: EXT });
const truth = (v) => v === true || v === 'true' || v === 1;

function orderModel(it, cfg) {
  const d = DET.get(it.key);
  const r = K.order({ __sid: it.sid, __acc: it.acc, row: it.row, det: d && d.detail, apiExtra: (d && d.extra) || {}, extraErrors: (d && d.errors) || {} }, cfg);
  const raw = r.raw, ex = raw.extra || {}, ad = (raw.delivery && raw.delivery.address) || {};
  return Object.assign(r, {
    key: it.key, warehouseName: (raw.warehouse && raw.warehouse.name) || r.wh, recipient: ad.full_name || '', phone: ad.phone || '',
    address: ad.address_v2 || ad.address || '', office: ad.delivery_address_type === 'company', promised: K.date(raw.delivery && raw.delivery.promised_delivery_date),
    packDeadline: K.date(ex.ecom_pack_deadline), shipPlan: raw.shipping_plan || '', ecomPlan: ex.ecom_shipping_plan || '', isHolding: truth(raw.is_holding),
    hasLabel: !!ex.shipping_label_url, shippingLabel: ex.shipping_label_url || '', partner: ex.delivery_partner || r.carrier || '', store: ex.store_name || '',
    payment: raw.payment_method || '', fulfil: r.kpis.find((k) => k.id === 'fulfillment' || k.id === 'fulfillment_b2b') || null,
    search: [r.code, r.ref, r.tracking, r.external, ad.full_name, ad.phone, (raw.items || []).map((x) => x.sku + ' ' + (x.product_name || '') + ' ' + (x.seller_product_code || '')).join(' ')].join(' ').toLowerCase(),
  });
}
function rebuild() {
  const cfg = kcfg();
  ORDERS = ROWS.orders.map((it) => orderModel(it, cfg));
  const raw = ROWS.fd.concat(ROWS.cr).map((it) => { const d = DET.get(it.key); return { __kind: it.kind, __sid: it.sid, __acc: it.acc, row: it.row, det: d && d.detail, ev: d && d.ev }; });
  AFTER = E.prepare(raw, ecfg());
  AFTER.forEach((r) => { r.key = okey(r.kind, r.sid, r.code); r.search = [r.sid, r.code, r.order, r.extId, r.tracking, r.refCode, r.skus, r.names, r.pkgCodes].join(' ').toLowerCase(); });
  refilter();
}
function refilter() {
  OV = ACCF ? ORDERS.filter((r) => r.sid === ACCF) : ORDERS;
  AV = ACCF ? AFTER.filter((r) => String(r.sid) === ACCF) : AFTER;
  A = E.analyze(AV);
  updateNav();
}
let rebuildT = 0;
const rebuildSoon = () => { if (rebuildT) return; rebuildT = setTimeout(() => { rebuildT = 0; rebuild(); renderSoft(); }, 1500); };

/* ======================= NETWORK ======================= */
class AuthError extends Error { constructor(m, s) { super(m); this.status = s; } }
const stopErr = () => Object.assign(new Error('Đã dừng'), { stopped: true });
let STOP = false;
const NET = { calls: 0, retries: 0, cooldown: 0, reason: '', t0: 0 };
function limiter(n) {
  let active = 0; const q = [];
  const next = () => { while (active < n && q.length) { const t = q.shift(); active++; Promise.resolve().then(t.f).then(t.res, t.rej).finally(() => { active--; next(); }); } };
  const fn = (f, front) => new Promise((res, rej) => { (front ? q.unshift : q.push).call(q, { f, res, rej }); next(); });
  fn.stat = () => ({ active, queued: q.length });
  return fn;
}
let LIM = limiter(6);
async function rawFetch(url, init) {
  const ctl = new AbortController(), timer = setTimeout(() => ctl.abort(), 30000);
  try {
    const res = await fetch(url, Object.assign({}, init, { signal: ctl.signal }));
    const text = (await res.text()).replace(/^﻿/, '').trim();
    let j = null; try { j = JSON.parse(text); } catch (e) {}
    return { status: res.status, j: j && typeof j === 'object' ? j : null, retryAfter: res.headers.get('Retry-After'), html: /^</.test(text) };
  } catch (e) {
    throw Object.assign(new Error(e.name === 'AbortError' ? 'Máy chủ không phản hồi sau 30 giây' : 'Lỗi mạng: ' + e.message), { retry: true });
  } finally { clearTimeout(timer); }
}
const errMsg = (j) => j && ((j.error && (j.error.message || j.error.code)) || j.message || (j.errors && j.errors[0] && j.errors[0].message));
async function api(url, tk, opt) {
  opt = opt || {};
  const init = { method: opt.body ? 'POST' : 'GET', headers: { Accept: 'application/json', Authorization: 'Bearer ' + tk } };
  if (opt.body) { init.headers['Content-Type'] = 'application/json'; init.body = JSON.stringify(opt.body); }
  const path = new URL(url).pathname;
  let last;
  for (let attempt = 0; attempt < 5; attempt++) {
    if (STOP && !opt.ignoreStop) throw stopErr();
    try {
      const r = await LIM(async () => {
        while (NET.cooldown > Date.now()) { if (STOP && !opt.ignoreStop) throw stopErr(); await sleep(Math.min(500, NET.cooldown - Date.now())); }
        if (STOP && !opt.ignoreStop) throw stopErr();
        NET.calls++; return rawFetch(url, init);
      }, opt.front);
      if (r.status === 401 || r.status === 403) throw new AuthError('Phiên đăng nhập hết hạn / không có quyền (HTTP ' + r.status + '). Đăng nhập lại TikiNOW Center.', r.status);
      if (r.status === 429 || r.status >= 500 || (!r.j && r.status < 300)) {
        const ra = Number(r.retryAfter);
        const wait = Number.isFinite(ra) && ra > 0 ? ra * 1000 : Math.min(20000, 1500 * 2 ** attempt);
        if (r.status === 429) NET.cooldown = Math.max(NET.cooldown, Date.now() + wait);
        throw Object.assign(new Error((r.status === 429 ? 'TikiNOW giới hạn tốc độ' : r.j ? 'Máy chủ lỗi' : 'Phản hồi không phải JSON') + ' (HTTP ' + r.status + ') · ' + path), { retry: true, wait });
      }
      if (r.status >= 400) throw new Error((errMsg(r.j) || 'HTTP ' + r.status) + ' · ' + path);
      if (r.j.success === false || r.j.success === 'false') throw new Error((errMsg(r.j) || 'API báo lỗi') + ' · ' + path);
      return r.j;
    } catch (e) {
      if (!e.retry) throw e;
      last = e; NET.retries++; NET.reason = e.message;
      if (attempt < 4) await sleep(e.wait || 1500 * 2 ** attempt);
    }
  }
  throw last;
}

/* ---------- Tải theo trang + chia khung thời gian khi chạm trần ----------
 * spec: { unit (ms), cap, size, fetch(lo, hi, page) -> {rows,total} } — lo/hi là chỉ số đơn vị, bao gồm 2 đầu. */
async function pullWindow(spec, lo, hi, job, depth) {
  depth = depth || 0;
  if (STOP) throw stopErr();
  const first = await spec.fetch(lo, hi, 1);
  const total = first.total;
  if (Number.isFinite(spec.cap) && total >= spec.cap) {
    if (hi <= lo || depth > 14) throw new Error('Khung thời gian nhỏ nhất vẫn đạt trần ' + nf(spec.cap) + ' dòng/truy vấn — chưa thể xác nhận đã lấy đủ. Thu hẹp bộ lọc.');
    const k = Math.min(24, Math.max(2, Math.ceil(total / (spec.cap * 0.6)))), span = hi - lo + 1, parts = [];
    for (let i = 0; i < k; i++) { const a = lo + Math.floor(span * i / k), b = lo + Math.floor(span * (i + 1) / k) - 1; if (b >= a) parts.push([a, b]); }
    job.windows += parts.length - 1;
    await settleAll(parts.map(([a, b]) => () => pullWindow(spec, a, b, job, depth + 1)));
    return;
  }
  const pages = Math.max(1, Math.ceil(total / spec.size));
  job.expected += total; job.pt += pages; job.pd++; job.add(first.rows); tick();
  await settleAll(Array.from({ length: pages - 1 }, (_, i) => async () => { const p = await spec.fetch(lo, hi, i + 2); job.pd++; job.add(p.rows); tick(); }));
}
// Chạy hết, không bỏ dở khi 1 phần lỗi; báo lỗi đầu tiên sau cùng (AuthError/Stop ưu tiên).
async function settleAll(fns) {
  const rs = await Promise.allSettled(fns.map((f) => f()));
  const bad = rs.filter((r) => r.status === 'rejected').map((r) => r.reason);
  if (bad.length) throw bad.find((e) => e instanceof AuthError) || bad.find((e) => e.stopped) || bad[0];
}

const ORDER_OPEN = ['new', 'awaiting_confirmation', 'processing', 'shipping', 'unpaid'];
const orderUrl = (path, p) => { const u = new URL(API + '/fulfillment/1.0/' + path); for (const [k, v] of Object.entries(p)) if (v !== '' && v != null) u.searchParams.set(k, v); return u.href; };
function orderSpec(acc, status) {
  const sid = String(acc.sellerId);
  return {
    unit: 1000, cap: 10000, size: 1000,
    async fetch(lo, hi, page) {
      const j = await api(orderUrl('orders', { 'filters.seller_id': sid, 'filters.extra.is_tnsl_order': 'true', 'filters.created_at.from': vnSec(lo * 1000), 'filters.created_at.to': vnSec(hi * 1000), 'filters.status': status, sort_by: 'created_at|desc', 'page.page_number': page, 'page.per_page': 1000 }), acc.tk);
      if (j.data == null && j.paging && !+j.paging.total) j.data = [];
      if (!Array.isArray(j.data) || !j.paging) throw new Error('API đơn hàng đổi cấu trúc (thiếu data/paging)');
      for (const r of j.data) { const s = r.seller_info && r.seller_info.seller_id; if (s != null && String(s) !== sid) throw new Error('API trả đơn của seller khác — đã chặn lưu'); }
      return { rows: j.data, total: +j.paging.total || 0 };
    },
  };
}
function fdSpec(acc, statuses) {
  const sid = String(acc.sellerId);
  return {
    unit: 86400e3, cap: Infinity, size: 50,
    async fetch(lo, hi, page) {
      const u = new URL(E.PROFILES.fd.url);
      const p = { 'filters.seller_id': sid, seller_id: sid, 'page.page_number': page, 'page.per_page': 50 };
      if (statuses) p['filters.status'] = statuses.join(','); else { p['filters.created_from'] = vnDay(lo * 86400e3); p['filters.created_to'] = vnDay(hi * 86400e3); }
      for (const [k, v] of Object.entries(p)) u.searchParams.set(k, v);
      const j = await api(u.href, acc.tk);
      if (j.data == null && j.paging && !+j.paging.total) j.data = [];
      if (!Array.isArray(j.data) || !j.paging) throw new Error('API FD đổi cấu trúc');
      return { rows: j.data, total: +j.paging.total || 0 };
    },
  };
}
function crSpec(acc, status) {
  const sid = String(acc.sellerId);
  return {
    unit: 86400e3, cap: 10000, size: 100,
    async fetch(lo, hi, page) {
      const u = new URL(E.PROFILES.cr.url);
      const p = { seller_id: sid, page, size: 100, ordering: '-created_at', created_at__gte: vnDay(lo * 86400e3), created_at__lte: vnDay(hi * 86400e3) };
      if (status) p.status__in = status;
      for (const [k, v] of Object.entries(p)) u.searchParams.set(k, v);
      const j = await api(u.href, acc.tk);
      if (j.data == null && (!j.meta_data || !+j.meta_data.total_record)) return { rows: [], total: 0 }; // CR trả data:null khi không có dòng
      if (!Array.isArray(j.data) || !j.meta_data) throw new Error('API CR đổi cấu trúc');
      return { rows: j.data, total: +j.meta_data.total_record || 0 };
    },
  };
}

/* ======================= SYNC ======================= */
let BUSY = false, JOBS = [], PHASE = '', DSTAT = { done: 0, total: 0, t0: 0 };
const HISTORY_FROM = dayStart('2024-01-01');
function newJob(acc, kind) {
  const job = { acc, kind, sid: String(acc.sellerId), name: accLabel(acc), state: 'wait', count: 0, expected: 0, pd: 0, pt: 0, windows: 1, map: new Map(), error: '', warn: '', t0: 0, ms: 0 };
  job.add = (rows) => { for (const row of rows) { const c = codeOf(kind, row); if (c && !job.map.has(c)) job.map.set(c, row); } job.count = job.map.size; };
  return job;
}
async function sync(onlySid, onlyKinds) {
  if (BUSY) return;
  const kinds = ['orders', 'fd', 'cr'].filter((k) => onlyKinds ? onlyKinds.includes(k) : S.kinds[k]);
  if (!kinds.length) return toast('Chọn ít nhất 1 loại dữ liệu (Đơn hàng / FD / CR).', 'bad');
  fixRange();
  if (S.mode === 'range' && S.from > S.to) return toast('Ngày bắt đầu phải trước ngày kết thúc.', 'bad');
  BUSY = true; STOP = false; LIM = limiter(Math.max(1, Math.min(10, +S.concurrency || 6)));
  Object.assign(NET, { calls: 0, retries: 0, cooldown: 0, reason: '', t0: Date.now() });
  DSTAT = { done: 0, total: 0, t0: 0 };
  setBusyUI(true);
  try {
    await captureFromCookies().catch(() => null);
    ACCOUNTS = await getAccounts();
    const accs = Object.values(ACCOUNTS).filter((a) => !onlySid || String(a.sellerId) === String(onlySid));
    if (!accs.length) { toast('Chưa có tài khoản. Đăng nhập tikinowcenter.tikinow.vn trên Chrome này rồi bấm Đồng bộ.', 'bad', 8000); return; }
    PHASE = 'list';
    JOBS = [];
    for (const acc of accs) for (const k of kinds) JOBS.push(newJob(acc, k));
    tick();
    await Promise.all(JOBS.map(runListJob));
    rebuild(); renderSoft();
    if (!STOP && S.aftersalesDetail && JOBS.some((j) => j.kind !== 'orders' && j.state === 'ok')) {
      PHASE = 'detail'; tick();
      await enrichAftersales(JOBS.filter((j) => j.kind !== 'orders' && j.state === 'ok'));
      rebuild();
    }
    const bad = JOBS.filter((j) => j.state === 'err');
    const rows = JOBS.reduce((n, j) => n + (j.state === 'ok' ? j.count : 0), 0);
    toast(STOP ? 'Đã dừng. Các phần tải xong đã được lưu.' : bad.length ? 'Xong ' + nf(rows) + ' dòng · ' + bad.length + ' phần lỗi (xem Chi tiết).' : 'Đã đồng bộ ' + nf(rows) + ' dòng trong ' + fmtDur((Date.now() - NET.t0) / 1000) + '.', bad.length ? 'bad' : 'ok', 6000);
    if (bad.length) $('#pjobs').classList.remove('hidden');
  } catch (e) {
    toast('Lỗi đồng bộ: ' + e.message, 'bad', 9000);
  } finally {
    BUSY = false; PHASE = ''; setBusyUI(false); tick(); refreshAccounts(); renderFresh(); render();
  }
}
async function runListJob(job) {
  const { acc, kind } = job;
  if (!tokenAlive(acc)) { job.state = 'err'; job.error = 'Token hết hạn — đăng nhập lại tài khoản này trên TikiNOW Center.'; tick(); return; }
  job.state = 'run'; job.t0 = Date.now(); tick();
  const open = S.mode === 'open';
  const lo = open ? HISTORY_FROM : dayStart(S.from), hi = open ? Date.now() : Math.min(Date.now(), dayStart(S.to) + 86400e3 - 1000);
  try {
    if (kind === 'orders') {
      // Đếm theo trạng thái cho khoảng ngày (1 request) — dùng cho Tổng quan ở cả 2 chế độ.
      const cFrom = open ? vnDay(Date.now() - (Math.max(1, S.days || 30) - 1) * 86400e3) : S.from, cTo = open ? vnDay(Date.now()) : S.to;
      try {
        const c = await api(orderUrl('orders/counts', { 'filters.seller_id': job.sid, 'filters.extra.is_tnsl_order': 'true', 'filters.created_at.from': cFrom + ' 00:00:00', 'filters.created_at.to': cTo + ' 23:59:59' }), acc.tk);
        COUNTS[job.sid] = { at: Date.now(), from: cFrom, to: cTo, statuses: (c.data && c.data.statuses) || {} };
        await chrome.storage.local.set({ countsV5: COUNTS });
      } catch (e) { if (e instanceof AuthError || e.stopped) throw e; }
      if (!open) {
        const currentCounts = COUNTS[job.sid];
        const statuses = currentCounts && currentCounts.from === cFrom && currentCounts.to === cTo ? currentCounts.statuses : {};
        const selected = S.orderStatus === 'delivered' ? [statuses.delivered || {}] : Object.values(statuses);
        const tot = selected.reduce((n, x) => n + (+x.total_order || 0), 0);
        if (+S.rangeLimit > 0 && tot > +S.rangeLimit) throw Object.assign(new Error('Khoảng ' + S.from + ' → ' + S.to + ' có ' + nf(tot) + ' đơn, vượt giới hạn ' + nf(S.rangeLimit) + ' đơn/tài khoản. Đã lưu số tổng theo trạng thái (xem Tổng quan). Thu hẹp khoảng ngày để tải đủ danh sách.'), { soft: true });
      }
      await pullWindow(orderSpec(acc, open ? ORDER_OPEN.join(',') : (S.orderStatus === 'delivered' ? 'delivered' : '')), Math.floor(lo / 1000), Math.floor(hi / 1000), job);
    } else if (kind === 'fd') {
      const sts = E.PENDING_PULL.fd.filter((s) => !S.done.fd.includes(s));
      const spec = fdSpec(acc, open ? sts : null);
      await pullWindow(spec, Math.floor((lo + 7 * 3600e3) / 86400e3), Math.floor((hi + 7 * 3600e3) / 86400e3), job);
    } else {
      const d0 = Math.floor((lo + 7 * 3600e3) / 86400e3), d1 = Math.floor((hi + 7 * 3600e3) / 86400e3);
      if (open) {
        // API CR chỉ nhận 1 trạng thái mỗi lần lọc → tải song song từng trạng thái đang mở.
        const sts = E.PENDING_PULL.cr.filter((s) => !S.done.cr.includes(s));
        await settleAll(sts.map((s) => () => pullWindow(crSpec(acc, s), d0, d1, job)));
      } else await pullWindow(crSpec(acc, ''), d0, d1, job);
    }
    if (STOP) throw stopErr();
    job.state = 'saving'; job.saveStage = 'prepare'; job.saved = 0; job.saveTotal = job.map.size; tick();
    await sleep(0);
    if (STOP) throw stopErr();
    const items = [...job.map.values()].map((row) => { const code = codeOf(kind, row); return { key: okey(kind, job.sid, code), sk: job.sid + '|' + kind, kind, sid: job.sid, acc: job.name, row }; });
    await replaceRows(job.sid, kind, items, (stage, n, total) => { job.saveStage = stage; job.saved = n; job.saveTotal = total; tick(); });
    ROWS[kind] = ROWS[kind].filter((it) => it.sid !== job.sid).concat(items);
    META[job.sid + '|' + kind] = { at: Date.now(), mode: S.mode, from: open ? '' : S.from, to: open ? '' : S.to, count: items.length, expected: job.expected, name: job.name, orderStatus: kind === 'orders' && !open ? (S.orderStatus || '') : '' };
    await chrome.storage.local.set({ metaV5: META });
    job.state = 'ok';
    if (job.expected > items.length) job.warn = 'API báo ' + nf(job.expected) + ', nhận ' + nf(items.length) + ' mã duy nhất (đơn đổi trạng thái trong lúc tải). Đồng bộ lại nếu cần khớp tuyệt đối.';
    rebuildSoon();
  } catch (e) {
    job.state = 'err'; job.error = e.message;
    if (e instanceof AuthError && e.status === 401) await patchAccount(job.sid, { dead: true });
    META[job.sid + '|' + kind] = Object.assign({}, META[job.sid + '|' + kind], { lastError: e.message, lastAttempt: Date.now(), name: job.name });
    await chrome.storage.local.set({ metaV5: META });
  }
  job.ms = Date.now() - job.t0; tick();
}

/* Chi tiết FD/CR đang mở (lịch sử, SL thiếu, sản phẩm, giải pháp) — cache, chỉ gọi lại khi đơn đổi. */
async function enrichAftersales(jobs) {
  const now = Date.now(), todo = [];
  for (const job of jobs) {
    const done = new Set(S.done[job.kind]);
    for (const row of job.map.values()) {
      const st = job.kind === 'fd' ? row.status : row.cr_status;
      if (done.has(st)) continue;
      const key = okey(job.kind, job.sid, codeOf(job.kind, row)), c = DET.get(key);
      const fresh = c && c.detail && (job.kind === 'fd' ? c.upd === row.updated_at : c.st === st && now - c.at < 6 * 3600e3);
      if (!fresh) todo.push({ job, row, key, st });
    }
  }
  DSTAT = { done: 0, total: todo.length, t0: Date.now() }; tick();
  // Mã đơn sàn cho FD + tên SP theo SKU: rẻ, theo lô.
  lookupExtIds(jobs).catch(() => {});
  const out = []; let flushAt = Date.now();
  await Promise.allSettled(todo.map(async (t) => {
    if (STOP || t.job.authLost) return;
    try {
      const url = t.job.kind === 'fd'
        ? API + '/fulfillment/1.0/inbound-shipments/fds/detail?code=' + encodeURIComponent(t.row.code)
        : API + '/tnc-ams/v1/cr/detail/' + encodeURIComponent(t.row.cr_code) + '?seller_id=' + encodeURIComponent(t.job.sid);
      const j = await api(url, t.job.acc.tk);
      if (j && j.data) { const rec = Object.assign({}, DET.get(t.key), { key: t.key, detail: j.data, upd: t.row.updated_at || null, st: t.st, at: Date.now() }); DET.set(t.key, rec); out.push(rec); }
    } catch (e) { if (e instanceof AuthError) t.job.authLost = true; else if (!e.stopped) t.job.detErr = (t.job.detErr || 0) + 1; }
    DSTAT.done++; tick();
    if (out.length >= 200 && Date.now() - flushAt > 4000) { flushAt = Date.now(); await storePut('details', out.splice(0)); rebuildSoon(); }
  }));
  await storePut('details', out);
  await lookupProducts(jobs.filter((j) => j.kind === 'fd'));
  for (const j of jobs) if (j.authLost) j.warn = 'Token hết hạn giữa chừng — danh sách đã lưu, chi tiết còn lại sẽ tải sau khi đăng nhập lại.'; else if (j.detErr) j.warn = (j.warn ? j.warn + ' · ' : '') + nf(j.detErr) + ' đơn chưa lấy được chi tiết (thử lại ở lần sau).';
}
async function lookupExtIds(jobs) {
  const saved = [];
  for (const j of jobs) if (j.kind === 'cr') for (const r of j.map.values()) { const k = j.sid + '|' + r.order_code; if (r.external_order_id && !EXT[k]) { EXT[k] = r.external_order_id; saved.push({ k, v: EXT[k] }); } }
  await settleAll(jobs.filter((j) => j.kind === 'fd').map((job) => async () => {
    const need = [...new Set([...job.map.values()].map((r) => r.origin).filter((oc) => oc && !EXT[job.sid + '|' + oc]))];
    for (let i = 0; i < need.length && !STOP; i += 150) {
      try {
        const j = await api(orderUrl('orders', { 'filters.seller_id': job.sid, 'filters.order_code': need.slice(i, i + 150).join(','), 'page.page_number': 1, 'page.per_page': 500 }), job.acc.tk);
        for (const o of j.data || []) if (o.order_code && o.ref_code) { const k = job.sid + '|' + o.order_code; EXT[k] = o.ref_code; saved.push({ k, v: o.ref_code }); }
      } catch (e) { if (e instanceof AuthError || e.stopped) return; }
    }
  })).catch(() => {});
  await storePut('extids', saved);
}
async function lookupProducts(jobs) {
  const saved = [];
  await settleAll(jobs.map((job) => async () => {
    const skus = new Set();
    for (const r of job.map.values()) { const d = DET.get(okey('fd', job.sid, r.code)); for (const x of (d && d.detail && d.detail.items) || r.items || []) if (x.sku && !PROD[job.sid + '|' + x.sku]) skus.add(x.sku); }
    const arr = [...skus];
    for (let i = 0; i < arr.length && !STOP; i += 100) {
      try {
        const j = await api(API + '/business/v1/product/base-info', job.acc.tk, { body: { skus: arr.slice(i, i + 100), seller_id: +job.sid } });
        for (const p of j.data || []) { const v = { k: job.sid + '|' + p.sku, name: p.name || '', image: p.image || '', price: +p.price || 0 }; PROD[v.k] = v; saved.push(v); }
      } catch (e) { if (e instanceof AuthError || e.stopped) return; }
    }
  })).catch(() => {});
  await storePut('products', saved);
}

/* ---------- Tiến độ ---------- */
let tickT = 0;
function tick() { if (!tickT) tickT = setTimeout(() => { tickT = 0; renderProgress(); }, 200); }
function renderProgress() {
  const box = $('#progress');
  if (!JOBS.length) { box.classList.add('hidden'); return; }
  box.classList.remove('hidden');
  const el = (Date.now() - NET.t0) / 1000, rate = el > 2 ? NET.calls / el : 0;
  let pct, text;
  if (PHASE === 'detail') {
    pct = DSTAT.total ? DSTAT.done / DSTAT.total : 1;
    const r = (Date.now() - DSTAT.t0) / 1000, sp = r > 3 ? DSTAT.done / r : 0;
    text = `<b>Đang bổ sung chi tiết FD/CR</b> · ${nf(DSTAT.done)}/${nf(DSTAT.total)} đơn${sp && DSTAT.total > DSTAT.done ? ' · còn ~' + fmtDur((DSTAT.total - DSTAT.done) / sp) : ''} · danh sách đã dùng được`;
  } else {
    const pd = JOBS.reduce((n, j) => n + j.pd, 0), pt = JOBS.reduce((n, j) => n + j.pt, 0), done = JOBS.filter((j) => j.state === 'ok' || j.state === 'err').length;
    pct = BUSY ? (pt ? (pd / pt) * 0.9 + (done / JOBS.length) * 0.1 : 0.03) : 1;
    const rows = JOBS.reduce((n, j) => n + j.count, 0), left = pt - pd;
    const saving = JOBS.filter(j => j.state === 'saving');
    text = BUSY && saving.length ? `<b>Đang lưu dữ liệu vào Chrome</b> · đã tải ${nf(rows)} dòng · đang lưu ${saving.length} phần · số đơn trong danh sách sẽ cập nhật sau khi lưu xong`
      : BUSY && done === JOBS.length ? '<b>Đang cập nhật danh sách đã lưu…</b>'
      : BUSY ? `<b>Đang tải danh sách</b> · ${done}/${JOBS.length} phần · ${nf(rows)} dòng · ${rate.toFixed(1)} req/giây${rate && left > 0 ? ' · còn ~' + fmtDur(left / rate) : ''}`
      : `<b>${JOBS.some((j) => j.state === 'err') ? 'Hoàn tất, có phần lỗi' : 'Hoàn tất'}</b> · ${nf(rows)} dòng · ${nf(NET.calls)} request · ${fmtDur(el)}`;
  }
  if (NET.cooldown > Date.now()) text += ` · <span class="warn-t">${esc(NET.reason)} — chờ ${Math.ceil((NET.cooldown - Date.now()) / 1000)}s</span>`;
  else if (BUSY && NET.retries) text += ` · <span class="muted">${NET.retries} lần thử lại</span>`;
  $('.pbar i', box).style.width = Math.max(3, Math.round(pct * 100)) + '%';
  box.classList.toggle('done', !BUSY);
  $('#ptext').innerHTML = text;
  const KN = { orders: 'Đơn hàng', fd: 'FD', cr: 'CR' };
  $('#pjobs').innerHTML = JOBS.map((j) => `<div class="pj ${j.state}"><span class="dot"></span><b>${KN[j.kind]}</b><span class="nm">${esc(j.name)}</span><span class="st">${j.state === 'ok' ? nf(j.count) + ' dòng · ' + (j.ms / 1000).toFixed(1) + 's' : j.state === 'run' ? nf(j.count) + (j.expected ? '/' + nf(j.expected) : '') + ' · trang ' + j.pd + '/' + (j.pt || '?') : j.state === 'saving' ? (j.saveStage === 'prepare' ? 'Đang chuẩn bị lưu ' + nf(j.saveTotal) + ' dòng' : j.saveStage === 'deleting' ? 'Đang thay danh sách cũ · ' + nf(j.saved) + ' dòng' : 'Đang lưu ' + nf(j.saved) + '/' + nf(j.saveTotal) + ' dòng') : j.state === 'err' ? 'lỗi' : 'chờ'}</span>${j.error ? `<div class="pe">${esc(j.error)}</div>` : j.warn ? `<div class="pw">${esc(j.warn)}</div>` : ''}</div>`).join('');
  if (CURRENT === 'accounts') renderAccounts().catch(() => {});
}
function setBusyUI(on) {
  $('#syncBtn').disabled = on; $('#syncBtn').classList.toggle('running', on); $('.lbl', $('#syncBtn')).textContent = on ? 'Đang đồng bộ…' : 'Đồng bộ';
  $('#stopBtn').classList.toggle('hidden', !on); $('#stopBtn').textContent = 'Dừng';
  $$('#modeSeg button, #daysSeg button, #from, #to, #kinds input, #orderScope').forEach((b) => (b.disabled = on));
}

/* ======================= UI SHELL ======================= */
let toastT;
function toast(msg, cls, ms) {
  const t = $('#toast'); t.textContent = msg; t.className = 'toast ' + (cls || ''); clearTimeout(toastT);
  if (ms !== 0) toastT = setTimeout(() => t.classList.add('hidden'), ms || 3500);
}
async function copyText(s) { try { await navigator.clipboard.writeText(s); toast('Đã copy: ' + (s.length > 60 ? s.slice(0, 60) + '…' : s), 'ok', 1500); } catch (e) { toast('Trình duyệt chặn clipboard.', 'bad'); } }
const TITLES = {
  overview: ['Tổng quan vận hành', 'Đơn đang mở, quá hạn đóng gói, FD/CR tồn — một màn hình'],
  orders: ['Danh sách đơn hàng', 'Lọc nhanh theo trạng thái, kho, kênh, SLA · bấm 1 đơn để xem chi tiết, video'],
  kpi: ['KPI dịch vụ 2026', 'Theo PDF TikiNOW · tính trên dữ liệu đã tải'],
  fd: ['Giao thất bại · FD', 'Đơn giao thất bại chờ kho nhận / cất hàng'],
  cr: ['Yêu cầu thu hồi · CR', 'Đang về kho / xử lý giải pháp'],
  late: ['Tồn lâu / trễ', 'FD/CR chưa kết thúc đã quá hạn nội bộ — lâu nhất trước'],
  accounts: ['Tài khoản', 'Token đăng nhập TikiNOW Center của từng seller'],
  settings: ['Cài đặt', 'Quy tắc trễ, trạng thái kết thúc, lịch nghỉ KPI, đồng bộ'],
};
function switchView(v) {
  CURRENT = v; closeDrawer();
  $$('#nav button').forEach((b) => b.classList.toggle('active', b.dataset.view === v));
  $('#crumb').textContent = TITLES[v][0]; $('#sub').textContent = TITLES[v][1];
  $('#view').scrollTop = 0; render();
}
function render() {
  const f = { overview: renderOverview, orders: renderOrders, kpi: renderKPI, fd: () => renderGrid('fd'), cr: () => renderGrid('cr'), late: () => renderGrid('late'), accounts: renderAccounts, settings: renderSettings }[CURRENT];
  f();
}
// Vẽ lại nhẹ khi dữ liệu đổi trong lúc đồng bộ: không phá ô tìm kiếm / cài đặt đang gõ.
function renderSoft() { if (['overview', 'kpi', 'accounts'].includes(CURRENT)) render(); else if (GRID_DRAW[CURRENT]) GRID_DRAW[CURRENT](true); updateNav(); renderFresh(); }
function updateNav() {
  const v = (n) => (n ? nf(n) : '');
  $('#nOrders').textContent = v(OV.filter((r) => !r.done).length || OV.length);
  $('#nKpi').textContent = v(OV.filter((r) => r.kpis.some((k) => k.state === 'overdue')).length);
  $('#nFd').textContent = v(A && A.fd.pending); $('#nCr').textContent = v(A && A.cr.pending); $('#nLate').textContent = v(A && A.late);
}
function renderFresh() {
  const ms = Object.values(META).filter((m) => m.at);
  if (!ms.length) { $('#fresh').innerHTML = '<span class="muted">Chưa đồng bộ</span>'; return; }
  const at = Math.max(...ms.map((m) => m.at)), m = ms.find((x) => x.at === at);
  $('#fresh').innerHTML = `<b>${m.mode === 'open' ? 'Đang mở' : esc(m.from + ' → ' + m.to)}</b><span>cập nhật ${ago(at)}</span>`;
}
function scopeChip(kind) {
  const ms = Object.entries(META).filter(([k, m]) => m.at && (!kind || kind.split(',').some((x) => k.endsWith('|' + x)))).map(([, m]) => m); if (!ms.length) return '';
  const at = Math.max(...ms.map((m) => m.at)), m = ms.find((x) => x.at === at);
  return `<span class="chip-s">${m.mode === 'open' ? '● Đang mở · mọi ngày tạo' : '● ' + esc(m.from + ' → ' + m.to) + (m.orderStatus === 'delivered' ? ' · Đơn hàng đã hoàn tất' : ' · Mọi trạng thái')} · ${ago(at)}</span>`;
}

/* ---------- Empty state ---------- */
function emptyState() {
  const accs = Object.values(ACCOUNTS), alive = accs.filter(tokenAlive);
  return `<div class="empty"><div class="empty-ic">◧</div><h2>${alive.length ? 'Sẵn sàng đồng bộ' : 'Kết nối TikiNOW Center'}</h2>
  <p>${alive.length ? `Đã nhận <b>${alive.length}</b> tài khoản. Chế độ <b>Đang mở</b> chỉ tải đơn chưa giao xong, FD/CR chưa kết thúc — thường dưới 1 phút.` : 'Hub dùng chính phiên đăng nhập TikiNOW Center trên Chrome này. Không cần mật khẩu.'}</p>
  <div class="empty-act">${alive.length ? '<button class="btn primary lg" data-act="sync">Đồng bộ ngay</button>' : '<a class="btn primary lg" target="_blank" href="https://tikinowcenter.tikinow.vn">Mở TikiNOW Center ↗</a><button class="btn ghost lg" data-act="rescan">Tôi đã đăng nhập — quét lại</button>'}</div>
  <ol class="steps"><li><b>Đăng nhập</b> tikinowcenter.tikinow.vn (nhiều seller: đăng nhập lần lượt, Hub giữ token ~24h từng tài khoản).</li><li><b>Đồng bộ</b> — mặc định Đang mở. Cần lịch sử: chọn Theo ngày tạo (${+S.rangeLimit > 0 ? 'giới hạn tự chọn ' + nf(S.rangeLimit) + ' đơn/tài khoản' : 'không giới hạn tổng số đơn'}).</li><li><b>Theo dõi & xuất</b> — bấm số liệu để lọc, xuất Excel theo đúng danh sách đang xem.</li></ol></div>`;
}
const hasData = () => ROWS.orders.length + ROWS.fd.length + ROWS.cr.length > 0;

/* ======================= OVERVIEW ======================= */
const STAGE_COLORS = ['var(--c1)', 'var(--c2)', 'var(--c3)', 'var(--c4)', 'var(--c5)'];
const stageColor = (kind, st) => { const i = E.STAGE_ORDER[kind].indexOf(st); return i < 0 ? 'var(--c5)' : STAGE_COLORS[i]; };
const stack = (kind, stages, total) => !total ? '<span class="stack"></span>' : '<span class="stack">' + E.STAGE_ORDER[kind].filter((s) => stages[s]).map((s) => `<i title="${esc(s)}: ${nf(stages[s])}" style="width:${stages[s] / total * 100}%;background:${stageColor(kind, s)}"></i>`).join('') + '</span>';
const legend = (kind, used) => '<div class="legend">' + E.STAGE_ORDER[kind].filter((s) => !used || used.includes(s)).map((s) => `<span><i style="background:${stageColor(kind, s)}"></i>${esc(s)}</span>`).join('') + '</div>';
const tile = (o) => `<div class="tile ${o.cls || ''} ${o.go ? 'click' : ''}" ${o.go ? `data-go="${o.go}"` : ''}><div class="t-l">${o.tag ? `<span class="tag">${o.tag}</span>` : ''}${o.l}</div><div class="t-v">${o.v}</div>${o.extra || ''}<div class="t-s">${o.s || ''}</div></div>`;
const SUB_VI = { ready_for_pickup: 'Chờ lấy hàng', picking: 'Đang lấy hàng', packing: 'Đang đóng gói', packed: 'Đã đóng gói', seller_confirmed: 'Seller đã xác nhận', waiting_for_packing: 'Chờ đóng gói', delivering: 'Đang giao', picked_up_from_seller: 'Đã lấy hàng', '3pl_picked_up_from_seller': 'ĐVVC đã lấy', delivery_failed: 'Giao thất bại', delivery_failed_1: 'Giao thất bại lần 1', returning: 'Đang hoàn', out_of_stock: 'Hết hàng' };
const subVi = (s) => SUB_VI[s] || (s ? s.replace(/_/g, ' ') : '—');

function renderOverview() {
  const host = $('#view');
  if (!hasData() && !Object.keys(COUNTS).length) { host.innerHTML = emptyState(); return; }
  const open = OV.filter((r) => !r.done), overPack = open.filter((r) => r.fulfil && r.fulfil.state === 'overdue');
  const dueSoon = open.filter((r) => r.fulfil && r.fulfil.state === 'pending' && r.fulfil.due && r.fulfil.due - Date.now() < 2 * 3600e3);
  const hold = open.filter((r) => r.isHolding).length;
  const fd = A.fd, cr = A.cr;
  const pend = AV.filter((r) => !r.done && r.age != null), oldest = pend.reduce((m, r) => (r.age > m.age ? r : m), { age: 0 });
  const fdSt = {}; fd.byWh.forEach((g) => E.STAGE_ORDER.fd.forEach((s) => (fdSt[s] = (fdSt[s] || 0) + (g.stages[s] || 0))));
  const crSt = {}; cr.byCarrier.forEach((g) => E.STAGE_ORDER.cr.forEach((s) => (crSt[s] = (crSt[s] || 0) + (g.stages[s] || 0))));
  let h = `<div class="scope-row">${scopeChip()}<span class="spacer"></span><button class="btn ghost sm" data-act="mail">Copy tóm tắt email</button></div>`;
  h += '<div class="tiles">' +
    tile({ tag: 'ĐƠN', l: 'Đang mở', v: nf(open.length), s: `${nf(open.filter((r) => r.status === 'processing').length)} đang xử lý · ${nf(open.filter((r) => r.status === 'shipping').length)} đang giao${hold ? ' · ' + nf(hold) + ' tạm giữ' : ''}`, go: 'orders:open' }) +
    tile({ tag: 'ĐƠN', l: 'Quá hạn đóng gói', v: nf(overPack.length), cls: overPack.length ? 'bad' : 'ok', s: dueSoon.length ? `<b>${nf(dueSoon.length)}</b> đơn đến hạn trong 2 giờ` : 'Theo cutoff kênh trong PDF KPI', go: 'orders:overdue' }) +
    tile({ tag: 'FD', l: 'Đang chờ kho', v: nf(fd.pending), extra: stack('fd', fdSt, fd.pending), s: `<b class="${fd.late ? 'bad-t' : ''}">${nf(fd.late)}</b> quá ${S.slaFd} ngày`, go: 'fd' }) +
    tile({ tag: 'CR', l: 'Đang thu hồi', v: nf(cr.pending), extra: stack('cr', crSt, cr.pending), s: `<b class="${cr.late ? 'bad-t' : ''}">${nf(cr.late)}</b> ${S.crUseEta ? 'quá ngày dự kiến về' : 'quá ' + S.slaCr + ' ngày'}`, go: 'cr' }) +
    tile({ l: 'FD/CR tồn lâu nhất', v: oldest.age ? oldest.age.toFixed(1) + '<small> ngày</small>' : '—', cls: oldest.age > 14 ? 'warn' : '', s: oldest.code ? `<span class="mono">${esc(oldest.code)}</span>` : '', go: 'late' }) +
    '</div>';

  // Đơn theo trạng thái (counts API, cả khoảng ngày) — số tổng thật từ Center.
  const cs = Object.entries(COUNTS).filter(([sid]) => !ACCF || sid === ACCF);
  if (cs.length) {
    const agg = {}; cs.forEach(([, c]) => Object.entries(c.statuses || {}).forEach(([s, x]) => (agg[s] = (agg[s] || 0) + (+x.total_order || 0))));
    const tot = Object.values(agg).reduce((a, b) => a + b, 0), max = Math.max(1, ...Object.values(agg));
    const c0 = cs[0][1], order = ['awaiting_confirmation', 'processing', 'shipping', 'delivered', 'canceled', 'unpaid', 'new'];
    const keys = Object.keys(agg).sort((a, b) => order.indexOf(a) - order.indexOf(b));
    const colr = { delivered: 'var(--ok)', canceled: 'var(--mute-c)', shipping: 'var(--c2)', processing: 'var(--acc)', awaiting_confirmation: 'var(--warn)' };
    h += `<div class="card"><div class="card-h"><b>Đơn tạo ${esc(c0.from)} → ${esc(c0.to)}</b><span class="muted">Số tổng từ Center · ${nf(tot)} đơn${cs.length > 1 ? ' · ' + cs.length + ' tài khoản' : ''}</span></div><div class="hbars">` +
      keys.map((s) => `<div class="hb"><span class="hb-l">${esc(K.STATUS[s] || s)}</span><span class="hb-b"><i style="width:${agg[s] / max * 100}%;background:${colr[s] || 'var(--c4)'}"></i></span><span class="hb-v">${nf(agg[s])}</span><span class="hb-p">${tot ? (agg[s] / tot * 100).toFixed(1) : 0}%</span></div>`).join('') +
      `</div><div class="card-f">Tỷ lệ hủy <b>${tot ? ((agg.canceled || 0) / tot * 100).toFixed(1) : 0}%</b> · đã giao <b>${tot ? ((agg.delivered || 0) / tot * 100).toFixed(1) : 0}%</b></div></div>`;
  }

  // Đơn đang mở theo kho × trạng thái phụ
  if (open.length) {
    const byWh = {}, subs = {};
    for (const r of open) { const g = byWh[r.wh] || (byWh[r.wh] = { k: r.wh, name: r.warehouseName, n: 0, over: 0, soon: 0, hold: 0, sub: {} }); g.n++; if (r.fulfil && r.fulfil.state === 'overdue') g.over++; if (dueSoon.includes(r)) g.soon++; if (r.isHolding) g.hold++; const s = r.status === 'shipping' ? 'Đang giao' : r.sub ? subVi(r.sub) : r.statusVi; g.sub[s] = (g.sub[s] || 0) + 1; subs[s] = (subs[s] || 0) + 1; }
    const subCols = Object.entries(subs).sort((a, b) => b[1] - a[1]).slice(0, 5).map((x) => x[0]);
    const rows = Object.values(byWh).sort((a, b) => b.over - a.over || b.n - a.n);
    h += `<div class="card"><div class="card-h"><b>Đơn đang mở theo kho</b><span class="muted">bấm 1 kho để xem danh sách</span></div><div class="tw"><table><thead><tr><th>Kho</th><th class="num">Đang mở</th>${subCols.map((s) => `<th class="num">${esc(s)}</th>`).join('')}<th class="num">Quá hạn ĐG</th><th class="num">Đến hạn ≤2h</th><th class="num">Tạm giữ</th></tr></thead><tbody>` +
      rows.map((g) => `<tr class="click" data-wh="${esc(g.k)}"><td><b>${esc(g.k)}</b><div class="muted sm">${esc(g.name !== g.k ? g.name : '')}</div></td><td class="num"><b>${nf(g.n)}</b></td>${subCols.map((s) => `<td class="num">${g.sub[s] ? nf(g.sub[s]) : '<span class="z">0</span>'}</td>`).join('')}<td class="num">${g.over ? `<span class="pill bad">${nf(g.over)}</span>` : '<span class="z">0</span>'}</td><td class="num">${g.soon ? `<span class="pill warn">${nf(g.soon)}</span>` : '<span class="z">0</span>'}</td><td class="num">${g.hold ? nf(g.hold) : '<span class="z">0</span>'}</td></tr>`).join('') + '</tbody></table></div></div>';
  }

  const groupTable = (kind, groups, label) => {
    const used = E.STAGE_ORDER[kind].filter((s) => groups.some((g) => g.stages[s])), rows = groups.filter((g) => g.pending);
    if (!rows.length) return `<div class="muted pad">Không có ${kind.toUpperCase()} đang mở.</div>`;
    return `<div class="tw"><table><thead><tr><th>${label}</th><th>Phân bổ</th><th class="num">Đang mở</th>${used.map((s) => `<th class="num">${esc(s)}</th>`).join('')}<th class="num">Trễ</th><th class="num">Lâu nhất</th></tr></thead><tbody>` +
      rows.map((g) => `<tr class="click" data-goto="${kind}" data-grp="${esc(g.k)}"><td><b>${esc(g.k)}</b></td><td>${stack(kind, g.stages, g.pending)}</td><td class="num"><b>${nf(g.pending)}</b></td>${used.map((s) => `<td class="num">${g.stages[s] ? nf(g.stages[s]) : '<span class="z">0</span>'}</td>`).join('')}<td class="num">${g.late ? `<span class="pill bad">${nf(g.late)}</span>` : '<span class="z">0</span>'}</td><td class="num">${g.maxAge ? g.maxAge.toFixed(1) + 'n' : '—'}</td></tr>`).join('') +
      `</tbody></table></div>${legend(kind, used)}`;
  };
  if (ROWS.fd.length || ROWS.cr.length) {
    h += `<div class="grid2"><div class="card"><div class="card-h"><b>FD theo kho nhập lại</b></div>${groupTable('fd', fd.byWh, 'Kho')}</div><div class="card"><div class="card-h"><b>CR theo đơn vị thu hồi</b></div>${groupTable('cr', cr.byCarrier, 'ĐVVC')}</div></div>`;
    const ageTbl = (kind) => { const s = A[kind]; const max = Math.max(1, ...s.buckets.map((b) => b.n)); return '<div class="hbars">' + s.buckets.map((b) => `<div class="hb"><span class="hb-l">${b.label}</span><span class="hb-b"><i style="width:${b.n / max * 100}%;background:var(--${b.min >= 7 ? 'bad' : b.min >= 3 ? 'warn' : 'acc'})"></i></span><span class="hb-v">${nf(b.n)}</span><span class="hb-p">${s.pending ? Math.round(b.n / s.pending * 100) : 0}%</span></div>`).join('') + '</div>'; };
    h += `<div class="grid2"><div class="card"><div class="card-h"><b>Tuổi tồn FD đang mở</b></div>${ageTbl('fd')}</div><div class="card"><div class="card-h"><b>Tuổi tồn CR đang mở</b></div>${ageTbl('cr')}</div></div>`;
  }
  host.innerHTML = h;
}

/* ======================= ORDERS ======================= */
const SERVICE = { ffo: 'Đóng gói B2C', lmo: 'Chỉ vận chuyển B2C', 'ffo-b2b': 'Đóng gói B2B', 'lmo-b2b': 'Chỉ vận chuyển B2B' };
const KPI_LABEL = { ontime: 'Đúng hạn', late: 'Hoàn tất trễ', overdue: 'Quá hạn', pending: 'Trong hạn', unknown: 'Thiếu mốc', excluded: 'Loại trừ' };
const kcls = (s) => (s === 'ontime' ? 'ok' : s === 'late' || s === 'overdue' ? 'bad' : s === 'pending' ? 'acc' : 'mute');
const kbadge = (s) => `<span class="pill ${kcls(s)}">${KPI_LABEL[s] || esc(s)}</span>`;
const OF = { q: '', status: '', sub: '', wh: '', channel: '', service: '', kpi: '', flag: '', sort: 'created', dir: -1, page: 0 };
const GRID_DRAW = {};
let ORDER_LIST = [];
function orderFilter() {
  const terms = OF.q.toLowerCase().split(/[\s,;\n]+/).filter(Boolean);
  const now = Date.now();
  return OV.filter((r) => (!OF.status || (OF.status === 'open' ? !r.done : r.status === OF.status)) && (!OF.sub || r.sub === OF.sub) && (!OF.wh || r.wh === OF.wh) && (!OF.channel || r.channel === OF.channel) && (!OF.service || r.service === OF.service) &&
    (!OF.kpi || (r.fulfil && r.fulfil.state === OF.kpi)) &&
    (!OF.flag || (OF.flag === 'hold' ? r.isHolding : OF.flag === 'nolabel' ? !r.hasLabel && !r.done : OF.flag === 'soon' ? r.fulfil && r.fulfil.state === 'pending' && r.fulfil.due && r.fulfil.due - now < 2 * 3600e3 : true)) &&
    (!terms.length || terms.some((t) => r.search.includes(t))));
}
function directOrderLookup() {
  return '<div class="tools"><input id="directOrderCode" class="search" placeholder="Nhập mã đơn để tra API trực tiếp, không cần tải lịch sử"><button class="btn primary sm" data-act="lookup-order" ' + (BUSY ? 'disabled' : '') + '>Tra API đơn + video</button><span class="muted sm">Chọn tài khoản ở bộ lọc phía trên.</span></div>';
}
async function lookupOrderByCode() {
  if (BUSY) return;
  const code = ($('#directOrderCode').value || '').trim();
  if (!/^[A-Za-z0-9_-]{1,120}$/.test(code)) return toast('Nhập mã đơn hợp lệ.', 'bad');
  const all = await getAccounts(), accs = Object.values(all);
  const acc = ACCF ? all[ACCF] : accs.length === 1 ? accs[0] : null;
  if (!acc) return toast('Chọn đúng tài khoản ở bộ lọc trước khi tra đơn.', 'bad');
  if (!tokenAlive(acc)) return toast('Phiên tài khoản hết hạn. Đăng nhập lại tài khoản này.', 'bad');
  const button = document.querySelector('[data-act="lookup-order"]');
  if (button && button.disabled) return;
  if (button) button.disabled = true;
  try {
    const j = await api(API + '/fulfillment/1.0/orders/' + encodeURIComponent(code), acc.tk, { front: true, ignoreStop: true });
    const row = j.data, sid = String(acc.sellerId), owner = row && (row.seller_info && row.seller_info.seller_id || row.seller_id);
    if (!row || String(row.order_code) !== code || (owner != null && String(owner) !== sid)) throw new Error('API không trả đúng đơn / seller đã chọn.');
    const key = okey('orders', sid, code), item = { key, sk: sid + '|orders', kind: 'orders', sid, acc: accLabel(acc), row };
    await storePut('rows', [item]);
    const i = ROWS.orders.findIndex(x => x.key === key); if (i >= 0) ROWS.orders[i] = item; else ROWS.orders.push(item);
    rebuild(); const r = ORDERS.find(x => x.key === key); openOrder(r, true);
    await loadOrderDetail(r, row);
  } catch (e) { toast('Tra API thất bại: ' + e.message, 'bad', 9000); }
  finally { if (button) button.disabled = false; }
}
function completedOrdersAction() {
  return `<div class="note">Cần đơn hàng đã hoàn tất? Chọn khoảng <b>ngày tạo đơn</b> ở trên (mặc định 30 ngày), rồi <button class="btn primary sm" data-act="completed-orders" ${BUSY ? 'disabled' : ''}>Tải đơn hàng hoàn tất</button>. Chỉ lấy trạng thái <b>Đã hoàn thành</b>, không gồm đơn huỷ. Lần tải này thay danh sách đơn của tài khoản đang chọn trong bộ lọc; FD/CR được giữ nguyên.</div>`;
}
async function syncCompletedOrders() {
  if (BUSY) return;
  S.mode = 'range'; S.orderStatus = 'delivered'; S.kinds.orders = true;
  fixRange(); await saveSettings(); syncControls();
  Object.assign(OF, { q: '', status: 'delivered', sub: '', wh: '', channel: '', service: '', kpi: '', flag: '', page: 0 });
  switchView('orders');
  await sync(ACCF || undefined, ['orders']);
}
function renderOrders() {
  const host = $('#view');
  if (!ROWS.orders.length) { host.innerHTML = directOrderLookup() + completedOrdersAction() + (hasData() || Object.keys(COUNTS).length ? `<div class="empty sm"><h2>Chưa có đơn hàng trong dữ liệu</h2><p>Bật <b>Đơn hàng</b> trên thanh đồng bộ rồi bấm Đồng bộ. ${S.mode === 'range' ? (+S.rangeLimit > 0 ? 'Giới hạn tự chọn: ' + nf(S.rangeLimit) + ' đơn/tài khoản. Đặt 0 trong Cài đặt để tải không giới hạn tổng.' : 'Không giới hạn tổng số đơn; hệ thống tự chia khoảng và phân trang.') : ''}</p><button class="btn primary" data-act="sync">Đồng bộ</button></div>` : emptyState()); return; }
  const opt = (v, l, sel) => `<option value="${esc(v)}" ${String(v) === String(sel) ? 'selected' : ''}>${esc(l)}</option>`;
  const vals = (k, map) => [...new Set(OV.map((r) => r[k]).filter(Boolean))].sort().map((v) => [v, map ? map(v) : v]);
  const counts = {}; OV.forEach((r) => (counts[r.status] = (counts[r.status] || 0) + 1));
  const tabs = [['', 'Tất cả', OV.length], ['open', 'Đang mở', OV.filter((r) => !r.done).length]].concat(Object.keys(K.STATUS).filter((s) => s === 'delivered' || counts[s]).map((s) => [s, K.STATUS[s], counts[s] || 0]));
  host.innerHTML = `${directOrderLookup()}${completedOrdersAction()}<div class="scope-row">${scopeChip('orders')}</div>
  <div class="tabs">${tabs.map(([v, l, n]) => `<button data-st="${v}" class="${OF.status === v ? 'active' : ''}">${esc(l)} <b>${nf(n)}</b></button>`).join('')}</div>
  <div class="card flush"><div class="tools">
    <div class="search-w"><input id="oq" class="search" value="${esc(OF.q)}" placeholder="Tìm mã đơn, mã sàn, vận đơn, SKU, SĐT… (dán nhiều mã cách nhau dấu phẩy / xuống dòng)"><kbd>/</kbd></div>
    <select data-of="sub" class="sel">${opt('', 'Trạng thái phụ', OF.sub)}${vals('sub', subVi).map(([v, l]) => opt(v, l, OF.sub)).join('')}</select>
    <select data-of="wh" class="sel">${opt('', 'Mọi kho', OF.wh)}${vals('wh').map(([v, l]) => opt(v, l, OF.wh)).join('')}</select>
    <select data-of="channel" class="sel">${opt('', 'Mọi kênh', OF.channel)}${vals('channel').map(([v, l]) => opt(v, l, OF.channel)).join('')}</select>
    <select data-of="service" class="sel">${opt('', 'Mọi loại đơn', OF.service)}${Object.entries(SERVICE).map(([v, l]) => opt(v, l, OF.service)).join('')}</select>
    <select data-of="kpi" class="sel">${opt('', 'SLA đóng gói', OF.kpi)}${Object.entries(KPI_LABEL).map(([v, l]) => opt(v, l, OF.kpi)).join('')}</select>
    <select data-of="flag" class="sel">${opt('', 'Cờ khác', OF.flag)}${opt('soon', 'Đến hạn đóng gói ≤ 2h', OF.flag)}${opt('hold', 'Đang tạm giữ', OF.flag)}${opt('nolabel', 'Chưa có nhãn', OF.flag)}</select>
    <button class="btn ghost sm" data-act="oreset">Xóa lọc</button>
  </div><div class="tw tall"><table class="otable"><thead><tr>
    <th class="sort" data-os="created">Đơn hàng</th><th>Trạng thái</th><th class="sort" data-os="wh">Kho / ĐVVC</th><th class="sort" data-os="due">Hạn đóng gói · SLA</th><th>Người nhận</th><th class="num sort" data-os="qty">SL · COD</th>
  </tr></thead><tbody id="obody"></tbody></table></div><div class="pager" id="opager"></div></div>`;
  const draw = (keep) => {
    if (keep && !$('#obody')) return;
    ORDER_LIST = orderFilter();
    const val = (r) => (OF.sort === 'created' ? +r.created || 0 : OF.sort === 'due' ? (r.fulfil && r.fulfil.due ? +r.fulfil.due : 9e15) : OF.sort === 'qty' ? r.qty : r[OF.sort] || '');
    ORDER_LIST.sort((a, b) => { const x = val(a), y = val(b); return (x > y ? 1 : x < y ? -1 : 0) * OF.dir; });
    const PAGE = 50, pages = Math.max(1, Math.ceil(ORDER_LIST.length / PAGE)); OF.page = Math.min(OF.page, pages - 1);
    const slice = ORDER_LIST.slice(OF.page * PAGE, OF.page * PAGE + PAGE);
    $$('th[data-os]', host).forEach((th) => { th.dataset.dir = th.dataset.os === OF.sort ? (OF.dir > 0 ? 'asc' : 'desc') : ''; });
    $('#obody').innerHTML = slice.map((r, i) => {
      const f = r.fulfil, left = f && f.due ? (f.due - Date.now()) / 3600e3 : null;
      return `<tr class="click" data-oi="${OF.page * PAGE + i}">
      <td><div class="code"><span class="mono copy" data-copy="${esc(r.code)}">${esc(r.code)}</span></div><div class="mono muted sm">${esc(r.ref)}</div><div class="sm"><span class="ch ch-${esc((r.channel || '').toLowerCase().replace(/[^a-z]/g, ''))}">${esc(r.channel || '—')}</span> ${SERVICE[r.service]} · ${fdt(r.created)}</div></td>
      <td><span class="pill ${r.done ? (r.status === 'delivered' ? 'ok' : 'mute') : 'acc'}">${esc(r.statusVi)}</span>${preorderBadge(r)}<div class="sm muted">${esc(subVi(r.sub))}</div>${r.isHolding ? '<span class="pill warn">Tạm giữ</span>' : ''}</td>
      <td><b>${esc(r.wh)}</b><div class="sm muted">${esc(r.partner)}</div><div class="mono sm">${esc(r.tracking || r.external)}</div></td>
      <td>${f ? kbadge(f.state) : '<span class="pill mute">—</span>'}<div class="sm">${f && f.due ? fdt(f.due) : ''}${left != null && !r.done && f.state === 'pending' ? ` <span class="${left < 2 ? 'warn-t' : 'muted'}">· còn ${left < 1 ? Math.max(0, Math.round(left * 60)) + 'p' : left.toFixed(1) + 'h'}</span>` : ''}</div></td>
      <td><div>${esc(r.recipient || '—')}</div><div class="sm muted clip">${esc(r.address)}</div></td>
      <td class="num"><b>${nf(r.qty)}</b><div class="sm muted">${r.cod ? nf(r.cod) + ' ₫' : '—'}</div></td></tr>`;
    }).join('') || '<tr><td colspan="6" class="empty-cell">Không có đơn khớp bộ lọc.</td></tr>';
    $('#opager').innerHTML = `<span><b>${nf(ORDER_LIST.length)}</b> / ${nf(OV.length)} đơn</span><span class="spacer"></span><button class="btn ghost sm" data-act="oexport">Xuất Excel danh sách này</button><button class="pg" data-pg="-1" ${OF.page ? '' : 'disabled'}>‹</button><span>${OF.page + 1} / ${pages}</span><button class="pg" data-pg="1" ${OF.page < pages - 1 ? '' : 'disabled'}>›</button>`;
  };
  GRID_DRAW.orders = draw;
  const dq = debounce(() => { OF.page = 0; draw(); }, 180);
  $('#oq').addEventListener('input', (e) => { OF.q = e.target.value; dq(); });
  host.onchange = (e) => { const k = e.target.dataset.of; if (k) { OF[k] = e.target.value; OF.page = 0; draw(); } };
  host.onclick = (e) => {
    const cp = e.target.closest('[data-copy]'); if (cp) { e.stopPropagation(); return copyText(cp.dataset.copy); }
    const st = e.target.closest('[data-st]'); if (st) { OF.status = st.dataset.st; OF.page = 0; $$('.tabs button', host).forEach((b) => b.classList.toggle('active', b === st)); return draw(); }
    const th = e.target.closest('th[data-os]'); if (th) { const k = th.dataset.os; OF.dir = OF.sort === k ? -OF.dir : k === 'due' ? 1 : -1; OF.sort = k; return draw(); }
    const pg = e.target.closest('[data-pg]'); if (pg) { OF.page += +pg.dataset.pg; draw(); $('#view').scrollTop = 0; return; }
    if (e.target.closest('[data-act="oreset"]')) { Object.assign(OF, { q: '', status: '', sub: '', wh: '', channel: '', service: '', kpi: '', flag: '', page: 0 }); return renderOrders(); }
    if (e.target.closest('[data-act="oexport"]')) return exportOrders(ORDER_LIST);
    const tr = e.target.closest('tr[data-oi]'); if (tr) openOrder(ORDER_LIST[+tr.dataset.oi]);
  };
  draw();
}

/* ---------- Drawer đơn hàng: chi tiết + video tải khi mở ---------- */
let DRAWER = null;
function closeDrawer() { $('#drawer').classList.add('hidden'); DRAWER = null; }
const kv = (k, v) => (v == null || v === '' ? '' : `<div class="kv"><span>${esc(k)}</span><span>${v}</span></div>`);
const sec = (t, body, extra) => (body ? `<div class="sec"><div class="sec-h">${t}${extra ? `<span class="muted">${extra}</span>` : ''}</div>${body}</div>` : '');
const copyable = (v) => (v ? `<span class="mono copy" data-copy="${esc(v)}">${esc(v)}</span>` : '');
const LANE_LABEL = { same_cluster_inner: 'Nội tỉnh / nội cụm / nội thành', same_cluster_outer: 'Nội tỉnh / nội cụm / ngoại thành', cross_cluster_inner: 'Nội tỉnh / liên cụm / nội thành', cross_cluster_outer: 'Nội tỉnh / liên cụm / ngoại thành', same_region_inner: 'Nội vùng / nội thành', same_region_outer: 'Nội vùng / ngoại thành', near_region_inner: 'Cận vùng / nội thành', near_region_outer: 'Cận vùng / ngoại thành', hanoi_hcm_inner: 'Hà Nội ↔ HCM / nội thành', hanoi_hcm_outer: 'Hà Nội ↔ HCM / ngoại thành', far_region_inner: 'Vùng xa / nội thành', far_region_outer: 'Vùng xa / ngoại thành' };
function videoLinks(evRows, code, sid) { return OrderInspect.links(evRows, code, sid); }
function preorderBadge(r) {
  const pre = OrderInspect.preorder(r.raw || {});
  return pre.known && pre.value ? '<span class="pill warn">PRE-ORDER</span>' : '';
}
function orderVideos(d, r) {
  const sources = (d.extra && d.extra.evidenceSources) || [];
  return [...new Map([
    ...videoLinks(d.extra && d.extra.evidence, r.code, r.sid),
    ...sources.filter(x => x.ok).flatMap(x => videoLinks(x.payload, r.code, r.sid)),
    ...OrderInspect.detailMedia(d.detail || {}, r.code, r.sid),
  ].map(x => [x.url, x])).values()];
}
function videoDiagnostics(d, r) {
  const sources = (d.extra && d.extra.evidenceSources) || [];
  if (!sources.length) return '<div class="note">Dữ liệu cache cũ chưa giữ phản hồi từng API. Bấm Tải lại chi tiết + video để kiểm tra lại.</div>';
  return '<details><summary>Kết quả từng API video</summary>' + sources.map(x => `<div class="note ${x.ok ? '' : 'bad'}"><b>${esc(x.id)}</b> · ${x.ok ? videoLinks(x.payload, r.code, r.sid).length + ' link đọc được' : esc(x.error || 'Không đọc được API')}</div>`).join('') + '<p class="muted sm">Không có link đọc được chưa chứng minh không có video. Trạng thái chờ xử lý / quyền truy cập / cấu trúc khác cần xem chẩn đoán. Chỉ đọc các API hiện có; không tạo yêu cầu mới.</p></details>';
}
function exportOrderDiagnostic(r) {
  const d = DET.get(r.key) || {};
  const data = OrderInspect.report(r.code, r.sid, d.extra && d.extra.evidenceSources, d.detail || r.raw);
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const a = document.createElement('a'), url = URL.createObjectURL(blob);
  a.href = url; a.download = 'TikiNOW_API_Diagnostic_' + r.code.replace(/[^A-Za-z0-9_-]/g, '_') + '.json';
  document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 5000);
}
const mediaBlock = (v) => { const vid = /\.(mp4|mov|webm|m3u8)(\?|$)/i.test(v.url) || /video/i.test(v.label), img = /\.(jpe?g|png|gif|webp)(\?|$)/i.test(v.url); return `<div class="media"><div class="media-h"><b>${esc(v.label)}</b><span class="muted sm">${esc(fdt(v.at))}</span><span class="spacer"></span><button class="btn ghost xs" data-copy="${esc(v.url)}">Copy link</button><a class="btn ghost xs" target="_blank" rel="noopener" href="${esc(v.url)}">Mở ↗</a></div>${vid ? `<video controls preload="none" src="${esc(v.url)}"></video>` : img ? `<img src="${esc(v.url)}" alt="">` : ''}</div>`; };

function openOrder(r, noLoad) {
  if (!r) return;
  DRAWER = { type: 'order', key: r.key };
  const d = DET.get(r.key) || {}, o = r.override || {}, raw = r.raw;
  const opt = (v, l, s) => `<option value="${esc(v)}" ${String(s || '') === String(v) ? 'selected' : ''}>${esc(l)}</option>`;
  const vids = orderVideos(d, r);
  const pre = OrderInspect.preorder(raw || {});
  $('#drawerTitle').innerHTML = `<span class="mono">${esc(r.code)}</span><span class="pill ${r.done ? 'mute' : 'acc'}">${esc(r.statusVi)}</span>${preorderBadge(r)}${r.fulfil ? kbadge(r.fulfil.state) : ''}`;
  let h = `<div class="d-act"><button class="btn primary sm" data-act="oload" ${d.loading ? 'disabled' : ''}>${d.loading ? 'Đang tải…' : r.hasDetail ? '⟳ Tải lại chi tiết + video' : 'Tải chi tiết + video'}</button><a class="btn ghost sm" target="_blank" rel="noopener" href="${CENTER_URL}tnsl-order/list?seller_id=${esc(r.sid)}">Mở Center ↗</a>${r.shippingLabel ? `<a class="btn ghost sm" target="_blank" rel="noopener" href="${esc(r.shippingLabel)}">Nhãn vận chuyển ↗</a>` : ''}<button class="btn ghost sm" data-act="ojson">Copy JSON</button><button class="btn ghost sm" data-act="odiagnostic">Xuất chẩn đoán API</button></div>`;
  if (d.loadError) h += `<div class="note bad">${esc(d.loadError)}</div>`;
  h += `<div class="facts">${[['Seller ID', copyable(r.sid)], ['PRE-ORDER', pre.conflict ? 'Các trường API mâu thuẫn' : pre.known ? (pre.value ? 'Có · ' + esc(pre.evidence.map(x => x.path).join(', ')) : 'Không · theo cờ API') : 'Chưa xác định từ dữ liệu API'], ['Mã sàn', copyable(r.ref)], ['Vận đơn', copyable(r.tracking || r.external)], ['Kênh · shop', esc([r.channel, r.store].filter(Boolean).join(' · '))], ['Loại đơn', esc(SERVICE[r.service] + (r.fo ? ' · chỉ đóng gói' : ''))], ['Kho', esc(r.warehouseName)], ['ĐVVC', esc(r.partner)], ['Tạo lúc', fdt(r.created)], ['Hạn Center', fdt(r.promised)], ['Hạn đóng gói sàn', fdt(r.packDeadline)], ['COD', r.cod ? nf(r.cod) + ' ₫' : '—'], ['Thanh toán', esc(r.payment)], ['Tài khoản', esc(r.acc)]].map(([k, v]) => `<div><span>${k}</span><b>${v || '—'}</b></div>`).join('')}</div>`;
  h += sec('Người nhận', kv('Tên', esc(r.recipient)) + kv('Điện thoại', copyable(r.phone)) + kv('Địa chỉ', esc(r.address)) + kv('Loại địa chỉ', r.office ? 'Văn phòng' : 'Nhà riêng'));
  h += sec('Video đóng gói', (vids.length ? vids.map(mediaBlock).join('') : d.evAt ? `<div class="muted">Chưa trích xuất được link video từ các phản hồi đã đọc (kiểm tra ${ago(d.evAt)}). Chưa thể kết luận đơn không có video.</div>` : '<div class="muted">Bấm Tải chi tiết + video để đọc API bằng tài khoản hiện tại.</div>') + videoDiagnostics(d, r));
  h += sec('KPI · các mốc xử lý', `<div class="tw"><table class="mini"><thead><tr><th>Công đoạn</th><th>Bắt đầu</th><th>Hạn</th><th>Thực tế</th><th>Kết quả</th></tr></thead><tbody>${r.kpis.map((k) => `<tr><td>${esc(k.label)}<div class="muted xs">${esc(k.reason || k.source)}</div></td><td>${fdt(k.start)}</td><td>${fdt(k.due)}</td><td>${fdt(k.end)}</td><td>${kbadge(k.state)}</td></tr>`).join('')}</tbody></table></div>
    <details class="rule"><summary>Gán tuyến giao / nhóm B2B / NOW / loại trừ cho đơn này</summary><form id="orderRule"><div class="frow"><label>Tuyến giao<select name="lane">${opt('', 'Chưa xác định', o.lane)}${Object.keys(K.LANE_DAYS).map((v) => opt(v, LANE_LABEL[v] || v, o.lane)).join('')}</select></label><label>Nhóm B2B<select name="b2bGroup">${opt('', 'Theo cài đặt', o.b2bGroup)}${opt('FMCG', 'SLA 1 · FMCG', o.b2bGroup)}${opt('HB_FASHION', 'SLA 2 · HB & Fashion', o.b2bGroup)}</select></label><label>NOW<select name="nowHours">${opt('', 'Không', o.nowHours)}${opt('2', '2H', o.nowHours)}${opt('4', '4H', o.nowHours)}</select></label></div><div class="frow"><label class="ck"><input type="checkbox" name="office" ${(o.office ?? r.office) ? 'checked' : ''}> Văn phòng (nghỉ T7)</label><label class="ck"><input type="checkbox" name="priority" ${r.priority ? 'checked' : ''}> Ưu tiên 90 phút</label><label class="grow">Lý do loại trừ<input name="exclusion" value="${esc(o.exclusion || '')}" placeholder="Để trống nếu không"></label><button type="button" class="btn primary sm" data-act="orule">Lưu</button></div></form></details>`);
  h += sec('Sản phẩm', `<div class="tw"><table class="mini"><thead><tr><th>SKU</th><th>Tên</th><th class="num">SL</th><th class="num">Giá</th></tr></thead><tbody>${(raw.items || []).map((x) => `<tr><td>${copyable(x.sku)}<div class="muted xs">${esc(x.seller_product_code || '')}</div></td><td>${esc(x.product_name || x.name || '')}</td><td class="num">${nf(x.quantity ?? x.qty)}</td><td class="num">${nf(x.price)}</td></tr>`).join('')}</tbody></table></div>`, nf((raw.items || []).length) + ' SKU');
  h += r.histories.length ? sec('Lịch sử', '<ol class="tl">' + r.histories.slice().reverse().map((t, i) => `<li class="${i ? '' : 'now'}"><b>${esc(K.STATUS[t.status] || t.label)}</b> <span class="muted">${esc(subVi(t.sub))}</span><div class="muted xs">${fdt(t.at)}${t.note ? ' · ' + esc(t.note) : ''}</div></li>`).join('') + '</ol>', r.histories.length + ' mốc') : '';
  h += `<details class="raw"><summary>Dữ liệu gốc API</summary><pre>${esc(JSON.stringify(K.sanitize(raw), null, 2))}</pre></details>`;
  $('#drawerBody').innerHTML = h;
  $('#drawer').classList.remove('hidden');
  if (!noLoad && (!r.hasDetail || !(d.extra && d.extra.evidenceSources)) && !d.loading) loadOrderDetail(r);
}
async function loadOrderDetail(r, initialDetail) {
  const acc = (await getAccounts())[r.sid];
  const d = Object.assign({ key: r.key }, DET.get(r.key));
  if (!tokenAlive(acc)) { d.loadError = 'Token tài khoản này hết hạn — đăng nhập lại TikiNOW Center.'; DET.set(r.key, d); return refreshDrawer(); }
  d.loading = true; d.loadError = ''; DET.set(r.key, d); refreshDrawer();
  try {
    const code = encodeURIComponent(r.code);
    const sid = encodeURIComponent(r.sid);
    const calls = [
      { id: 'check-evidence-documents', url: API + '/tnc-ams/v1/check-evidence-documents?seller_id=' + sid + '&order_code=' + code + '&is_video_pack=true' },
      { id: 'evidence-documents-request', url: API + '/tnc-ams/v1/evidence-documents-request?seller_id=' + sid + '&order_code=' + code },
    ];
    // Retain each response, including object payloads and individual failures. GET only.
    const [detail, sources] = await Promise.all([
      (initialDetail ? Promise.resolve({ data: initialDetail }) : api(API + '/fulfillment/1.0/orders/' + code, acc.tk, { front: true, ignoreStop: true })).then(payload => ({ ok: true, payload }), e => ({ ok: false, error: e.message })),
      Promise.all(calls.map(async x => {
        try { return { id: x.id, ok: true, payload: await api(x.url, acc.tk, { front: true, ignoreStop: true }) }; }
        catch (e) { return { id: x.id, ok: false, error: e.message }; }
      })),
    ]);
    d.extra = Object.assign({}, d.extra, { evidenceSources: sources });
    delete d.extra.evidence; // Do not mix a previous successful check with a new failed one.
    d.evAt = Date.now();
    const failures = sources.filter(x => !x.ok).map(x => x.id + ': ' + x.error);
    if (detail.ok) {
      const row = detail.payload.data, rowSid = row && (row.seller_info && row.seller_info.seller_id || row.seller_id);
      if (!row || String(row.order_code) !== String(r.code) || (rowSid != null && String(rowSid) !== String(r.sid))) failures.push('Chi tiết API không khớp mã đơn / seller, không lưu phản hồi chi tiết.');
      else Object.assign(d, { detail: row, at: Date.now() });
    } else failures.push('Chi tiết đơn: ' + detail.error);
    d.loadError = failures.length ? 'Một phần API chưa đọc được: ' + failures.join(' · ') : '';
  } catch (e) { d.loadError = 'Không tải được chi tiết: ' + e.message; }
  d.loading = false; DET.set(r.key, d);
  const { loading, loadError, ...save } = d; if (save.detail) storePut('details', [save]).catch(() => {});
  const it = ROWS.orders.find((x) => x.key === r.key); if (it) { const m = orderModel(it, kcfg()), i = ORDERS.findIndex((x) => x.key === r.key); if (i >= 0) ORDERS[i] = m; refilter(); }
  refreshDrawer();
}
function refreshDrawer() {
  if (!DRAWER) return;
  if (DRAWER.type === 'order') openOrder(ORDERS.find((x) => x.key === DRAWER.key), true);
  else openAfter(AFTER.find((x) => x.key === DRAWER.key), true);
}

/* ======================= FD / CR / LATE GRIDS ======================= */
const COLS = {
  fd: [
    ['sid', 'Seller ID', (r) => copyable(r.sid)],
    ['code', 'Mã FD', (r) => copyable(r.code)], ['order', 'Mã đơn', (r) => copyable(r.order) + (r.extId ? `<div class="mono muted xs">${esc(r.extId)}</div>` : '')],
    ['statusVi', 'Trạng thái', (r) => `<span class="pill ${r.done ? 'mute' : r.late ? 'bad' : 'ok'}">${esc(r.statusVi)}</span>`], ['stage', 'Giai đoạn', (r) => stageCell('fd', r)],
    ['wh', 'Kho', (r) => `<b>${esc(r.wh)}</b>`], ['created', 'Tạo lúc', (r) => fdt(r.created)], ['age', 'Tuổi', (r) => (r.age == null ? '' : r.age.toFixed(1) + 'n'), 'num'],
    ['due', 'Hạn', (r) => (r.late ? `<span class="pill bad">quá ${r.overdue.toFixed(1)}n</span>` : fdt(r.due))], ['qty', 'SL', (r) => nf(r.qty), 'num'],
    ['missing', 'Thiếu', (r) => (r.missing ? `<span class="pill bad">${nf(r.missing)}</span>` : ''), 'num'], ['names', 'Sản phẩm', (r) => `<span class="clip" title="${esc(r.names || r.skus)}">${esc(r.names || r.skus)}</span>`],
    ['lastEventAt', 'Sự kiện cuối', (r) => (r.lastEvent ? `${esc(r.lastEvent)}<div class="muted xs">${fdt(r.lastEventAt)}</div>` : '')],
  ],
  cr: [
    ['sid', 'Seller ID', (r) => copyable(r.sid)],
    ['code', 'Mã CR', (r) => copyable(r.code)], ['order', 'Mã đơn gốc', (r) => copyable(r.order) + (r.extId ? `<div class="mono muted xs">${esc(r.extId)}</div>` : '')],
    ['statusVi', 'Trạng thái', (r) => `<span class="pill ${r.done ? 'mute' : r.late ? 'bad' : 'ok'}">${esc(r.statusVi)}</span>`], ['stage', 'Giai đoạn', (r) => stageCell('cr', r)],
    ['carrier', 'ĐVVC', (r) => esc(r.carrier)], ['created', 'Tạo lúc', (r) => fdt(r.created)], ['age', 'Tuổi', (r) => (r.age == null ? '' : r.age.toFixed(1) + 'n'), 'num'],
    ['eta', 'Dự kiến về', (r) => (r.late ? `<span class="pill bad">quá ${r.overdue.toFixed(1)}n</span>` : fdt(r.eta))], ['tracking', 'Vận đơn', (r) => copyable(r.tracking)],
    ['names', 'Sản phẩm', (r) => `<span class="clip" title="${esc(r.names)}">${esc(r.names)}</span>`], ['value', 'Giá trị', (r) => (r.value ? nf(r.value) : ''), 'num'], ['reasons', 'Lý do', (r) => esc(r.reasons)],
  ],
  late: [
    ['sid', 'Seller ID', (r) => copyable(r.sid)],
    ['kind', 'Loại', (r) => `<span class="pill ${r.kind === 'fd' ? 'acc' : 'mute'}">${r.kind.toUpperCase()}</span>`], ['code', 'Mã', (r) => copyable(r.code)], ['order', 'Mã đơn', (r) => copyable(r.order)],
    ['grp', 'Kho / ĐVVC', (r) => esc(r.kind === 'fd' ? r.wh : r.carrier)], ['statusVi', 'Trạng thái', (r) => esc(r.statusVi)], ['stage', 'Giai đoạn', (r) => stageCell(r.kind, r)],
    ['created', 'Tạo lúc', (r) => fdt(r.created)], ['due', 'Hạn', (r) => fdt(r.due)], ['overdue', 'Quá hạn', (r) => `<span class="pill bad">${r.overdue.toFixed(1)}n</span>`, 'num'],
    ['names', 'Sản phẩm', (r) => `<span class="clip" title="${esc(r.names || r.skus)}">${esc(r.names || r.skus)}</span>`],
  ],
};
const stageCell = (kind, r) => `<span class="stage"><i style="background:${r.done ? 'var(--line)' : stageColor(kind, r.stage)}"></i>${esc(r.stage)}</span>`;
const sortVal = (r, k) => { const v = k === 'grp' ? (r.kind === 'fd' ? r.wh : r.carrier) : r[k]; return v instanceof Date ? v.getTime() : typeof v === 'boolean' ? +v : v == null ? '' : v; };
const GRID = {}, GRID_PRESET = {};
let GRID_OUT = [];
function renderGrid(view) {
  const host = $('#view');
  if (!ROWS.fd.length && !ROWS.cr.length) { host.innerHTML = hasData() ? `<div class="empty sm"><h2>Chưa có dữ liệu hậu mãi</h2><p>Bật FD / CR trên thanh đồng bộ rồi bấm Đồng bộ.</p><button class="btn primary" data-act="sync">Đồng bộ</button></div>` : emptyState(); return; }
  const isLate = view === 'late';
  const st = GRID[view] || (GRID[view] = { q: '', grp: '', stage: '', status: '', kind: '', pend: !isLate, late: false, sort: isLate ? 'overdue' : '', dir: 'desc', page: 0 });
  const pre = GRID_PRESET[view]; GRID_PRESET[view] = null;
  if (pre) Object.assign(st, { q: '', grp: pre.grp || '', status: pre.status || '', stage: '', pend: true, late: !!pre.late, page: 0 });
  const base = () => (isLate ? A.lateList : AV.filter((r) => r.kind === view));
  const b0 = base();
  const groups = [...new Set(b0.map((r) => (r.kind === 'fd' ? r.wh : r.carrier)))].filter(Boolean).sort();
  const stages = isLate ? [...new Set(E.STAGE_ORDER.fd.concat(E.STAGE_ORDER.cr))] : E.STAGE_ORDER[view].concat(['Hoàn tất', 'Huỷ / từ chối']);
  const statuses = [...new Map(b0.map((r) => [r.status, r.statusVi])).entries()].sort((a, b) => a[1].localeCompare(b[1]));
  const opt = (v, l, sel) => `<option value="${esc(v)}" ${sel === v ? 'selected' : ''}>${esc(l)}</option>`;
  host.innerHTML = `<div class="scope-row">${scopeChip(isLate ? 'fd,cr' : view)}</div><div class="card flush"><div class="tools">
    <div class="search-w"><input class="search" data-f="q" value="${esc(st.q)}" placeholder="Tìm Seller ID, mã FD/CR, mã đơn, mã sàn, vận đơn, SKU, tên SP…"><kbd>/</kbd></div>
    ${isLate ? `<select class="sel" data-f="kind">${opt('', 'FD + CR', st.kind)}${opt('fd', 'Chỉ FD', st.kind)}${opt('cr', 'Chỉ CR', st.kind)}</select>` : ''}
    <select class="sel" data-f="grp">${opt('', view === 'fd' ? 'Mọi kho' : view === 'cr' ? 'Mọi ĐVVC' : 'Mọi kho / ĐVVC', st.grp)}${groups.map((g) => opt(g, g, st.grp)).join('')}</select>
    <select class="sel" data-f="stage">${opt('', 'Mọi giai đoạn', st.stage)}${stages.map((g) => opt(g, g, st.stage)).join('')}</select>
    <select class="sel" data-f="status">${opt('', 'Mọi trạng thái', st.status)}${statuses.map(([c, l]) => opt(c, l, st.status)).join('')}</select>
    ${isLate ? '' : `<label class="chip"><input type="checkbox" data-f="pend" ${st.pend ? 'checked' : ''}><span>Chỉ đang mở</span></label><label class="chip"><input type="checkbox" data-f="late" ${st.late ? 'checked' : ''}><span>Chỉ trễ</span></label>`}
  </div><div class="tw tall"><table id="gt"></table></div><div class="pager" id="gp"></div></div>`;
  const draw = (keep) => {
    if (keep && !$('#gt')) return;
    const q = st.q.trim().toLowerCase();
    let out = base().filter((r) => (!st.kind || r.kind === st.kind) && (!st.grp || (r.kind === 'fd' ? r.wh : r.carrier) === st.grp) && (!st.stage || r.stage === st.stage) && (!st.status || r.status === st.status) && (isLate || !st.pend || !r.done) && (isLate || !st.late || r.late));
    if (q) { const ts = q.split(/[\s,;]+/).filter(Boolean); out = out.filter((r) => ts.some((t) => r.search.includes(t))); }
    if (st.sort) { const d = st.dir === 'asc' ? 1 : -1; out.sort((a, b) => { const x = sortVal(a, st.sort), y = sortVal(b, st.sort); return (x > y ? 1 : x < y ? -1 : 0) * d; }); }
    else out.sort((a, b) => (b.late - a.late) || (b.overdue - a.overdue) || (a.done - b.done) || ((b.created || 0) - (a.created || 0)));
    GRID_OUT = out;
    const PAGE = 100, pages = Math.max(1, Math.ceil(out.length / PAGE)); st.page = Math.min(st.page, pages - 1);
    const cols = COLS[view], slice = out.slice(st.page * PAGE, st.page * PAGE + PAGE);
    $('#gt').innerHTML = '<thead><tr>' + cols.map(([k, l, , c]) => `<th class="sort ${c || ''}" data-k="${k}" ${st.sort === k ? `data-dir="${st.dir}"` : ''}>${l}</th>`).join('') + '</tr></thead><tbody>' +
      (slice.map((r, i) => `<tr class="click" data-i="${st.page * PAGE + i}">` + cols.map(([, , f, c]) => `<td${c ? ` class="${c}"` : ''}>${f(r)}</td>`).join('') + '</tr>').join('') || `<tr><td colspan="${cols.length}" class="empty-cell">Không có dòng nào khớp bộ lọc.</td></tr>`) + '</tbody>';
    $('#gp').innerHTML = `<span><b>${nf(out.length)}</b> / ${nf(base().length)}</span><span class="spacer"></span><button class="btn ghost sm" data-act="gexport">Xuất Excel danh sách này</button><button class="pg" data-pg="-1" ${st.page ? '' : 'disabled'}>‹</button><span>${st.page + 1} / ${pages}</span><button class="pg" data-pg="1" ${st.page < pages - 1 ? '' : 'disabled'}>›</button>`;
  };
  GRID_DRAW[view] = draw;
  const dq = debounce(() => { st.page = 0; draw(); }, 180);
  host.oninput = (e) => { const f = e.target.dataset.f; if (!f) return; st[f] = e.target.type === 'checkbox' ? e.target.checked : e.target.value; if (f === 'q') dq(); else { st.page = 0; draw(); } };
  host.onclick = (e) => {
    const cp = e.target.closest('[data-copy]'); if (cp) { e.stopPropagation(); return copyText(cp.dataset.copy); }
    const th = e.target.closest('th[data-k]'); if (th) { const k = th.dataset.k; if (st.sort === k) { if (st.dir === 'desc') st.dir = 'asc'; else { st.sort = ''; st.dir = 'desc'; } } else { st.sort = k; st.dir = 'desc'; } return draw(); }
    const pg = e.target.closest('[data-pg]'); if (pg) { st.page += +pg.dataset.pg; draw(); $('#view').scrollTop = 0; return; }
    if (e.target.closest('[data-act="gexport"]')) return exportAfter(GRID_OUT, view);
    const tr = e.target.closest('tr[data-i]'); if (tr) openAfter(GRID_OUT[+tr.dataset.i]);
  };
  draw();
}

function openAfter(r, noLoad) {
  if (!r) return;
  DRAWER = { type: 'after', key: r.key };
  const d = DET.get(r.key) || {};
  const link = r.kind === 'fd' ? `${CENTER_URL}aftersales/failed-delivery?seller_id=${encodeURIComponent(r.sid)}&page=1&size=20&filters.order_code=${encodeURIComponent(r.order)}` : `${CENTER_URL}aftersales/request-return/list?seller_id=${encodeURIComponent(r.sid)}`;
  $('#drawerTitle').innerHTML = `<span class="pill ${r.kind === 'fd' ? 'acc' : 'mute'}">${r.kind.toUpperCase()}</span><span class="mono">${esc(r.code)}</span><span class="pill ${r.done ? 'mute' : r.late ? 'bad' : 'ok'}">${esc(r.statusVi)}</span>${r.late ? `<span class="pill bad">quá ${r.overdue.toFixed(1)} ngày</span>` : ''}`;
  let h = `<div class="d-act"><button class="btn primary sm" data-act="aload" ${d.loading ? 'disabled' : ''}>${d.loading ? 'Đang tải…' : r.hasDetail ? '⟳ Tải lại chi tiết + video' : 'Tải chi tiết + video'}</button><a class="btn ghost sm" target="_blank" rel="noopener" href="${esc(link)}">Mở Center ↗</a><button class="btn ghost sm" data-act="ajson">Copy JSON</button></div>`;
  if (d.loadError) h += `<div class="note bad">${esc(d.loadError)}</div>`;
  h += `<div class="facts">${[['Seller ID', copyable(r.sid)], ['Mã đối tác (partner_code)', r.kind === 'fd' ? copyable(r.partner) : ''], ['Mã đơn', copyable(r.order)], ['Mã sàn', copyable(r.extId)], ['Giai đoạn', stageCell(r.kind, r)], [r.kind === 'fd' ? 'Kho nhập lại' : 'Kho / điểm nhận', esc(r.wh)], ['Tạo lúc', fdt(r.created)], ['Tuổi', r.age == null ? '' : r.age.toFixed(1) + ' ngày'], ['Hạn nội bộ', fdt(r.due)], ['ĐVVC', esc(r.carrier)], ['Vận đơn', copyable(r.tracking)], ['Dự kiến về', fdt(r.eta)], ['Hoàn tất', fdt(r.completed)], ['Tài khoản', esc(r.acc)]].filter(([, v]) => v).map(([k, v]) => `<div><span>${k}</span><b>${v}</b></div>`).join('')}</div>`;
  if (!r.hasDetail) h += '<div class="note">Chưa có chi tiết (lịch sử, sản phẩm, video). Đang tải…</div>';
  h += sec('Video & bằng chứng', r.videos.length ? r.videos.map(mediaBlock).join('') : d.evAt ? '<div class="muted">Không có video / bằng chứng.</div>' : '');
  const thumb = (src) => (src ? `<img class="thumb" loading="lazy" src="${esc(src)}" alt="">` : '<span class="thumb ph"></span>');
  if (r.kind === 'fd' && r.items.length) h += sec('Sản phẩm', `<div class="tw"><table class="mini"><thead><tr><th></th><th>SKU / tên</th><th class="num">SL</th><th class="num">Khớp</th><th class="num">Xong</th><th class="num">Thiếu</th></tr></thead><tbody>${r.items.map((x) => `<tr><td>${thumb(x.image)}</td><td>${copyable(x.sku)}<div>${esc(x.name)}</div></td><td class="num">${x.qty}</td><td class="num">${x.matched}</td><td class="num">${x.doneQty}</td><td class="num">${x.missing ? `<span class="pill bad">${x.missing}</span>` : 0}</td></tr>`).join('')}</tbody></table></div>`, r.items.length + ' SKU');
  if (r.kind === 'cr' && r.products.length) h += sec('Sản phẩm', r.products.map((p) => `<div class="prod">${thumb(p.image)}<div><b>${esc(p.name)}</b><div class="muted sm">${copyable(p.sku)} · ${nf(p.price)} ₫ × ${p.qty}</div><div class="sm">Lý do: <b>${esc(p.reason || '—')}</b>${p.resType ? ` · Giải pháp: <b>${esc(p.resType)}</b>` : ''}</div>${p.images.length ? `<div class="gal">${p.images.map((u) => `<a href="${esc(u)}" target="_blank" rel="noopener"><img loading="lazy" src="${esc(u)}" alt=""></a>`).join('')}</div>` : ''}</div></div>`).join(''), r.products.length + ' SP');
  if (r.traces.length) h += sec('Lịch sử trạng thái', '<ol class="tl">' + r.traces.map((t, i) => `<li class="${i ? '' : 'now'}"><b>${esc(t.label)}</b><div class="muted xs">${fdt(t.at)}${t.by ? ' · ' + esc(t.by) : ''}${t.note ? ' · ' + esc(t.note) : ''}</div></li>`).join('') + '</ol>', r.traces.length + ' mốc');
  const x = K.reverse(r, kcfg()), o = x.override || {}, opt = (v, l, s) => `<option value="${v}" ${v === (s || '') ? 'selected' : ''}>${l}</option>`;
  h += sec('KPI hậu mãi · PDF 2026', `<div class="tw"><table class="mini"><thead><tr><th>Công đoạn</th><th>Hạn</th><th>Thực tế</th><th>Kết quả</th></tr></thead><tbody>${x.kpis.map((k) => `<tr><td>${esc(k.label)}<div class="muted xs">${esc(k.reason || '')}</div></td><td>${fdt(k.due)}</td><td>${fdt(k.end)}</td><td>${kbadge(k.state)}</td></tr>`).join('')}</tbody></table></div><form id="reverseRule" class="frow"><label>Vùng hoàn<select name="region">${opt('', 'Chưa xác định', o.region)}${opt('same', 'Cùng thành phố', o.region)}${opt('near', 'Vùng gần', o.region)}${opt('far', 'Vùng xa', o.region)}</select></label><label>Kết quả phân loại<select name="goods">${opt('', 'Chưa xác định', o.goods)}${opt('good', 'Hàng mới → kho bán', o.goods)}${opt('bad', 'Hàng lỗi → kho hậu mãi', o.goods)}</select></label><button type="button" class="btn ghost sm" data-act="arule">Lưu</button></form>`);
  h += `<details class="raw"><summary>Dữ liệu gốc API</summary><pre>${esc(JSON.stringify(K.sanitize(r.raw), null, 2))}</pre></details>`;
  $('#drawerBody').innerHTML = h;
  $('#drawer').classList.remove('hidden');
  if (!noLoad && (!r.hasDetail || !d.evAt) && !d.loading && !d.loadError) loadAfterDetail(r);
}
async function loadAfterDetail(r) {
  const acc = (await getAccounts())[String(r.sid)];
  const d = Object.assign({ key: r.key }, DET.get(r.key));
  if (!tokenAlive(acc)) { d.loadError = 'Token tài khoản này hết hạn — đăng nhập lại TikiNOW Center.'; DET.set(r.key, d); return refreshDrawer(); }
  d.loading = true; d.loadError = ''; DET.set(r.key, d); refreshDrawer();
  const it = ROWS[r.kind].find((x) => x.key === r.key);
  try {
    const url = r.kind === 'fd' ? API + '/fulfillment/1.0/inbound-shipments/fds/detail?code=' + encodeURIComponent(r.code) : API + '/tnc-ams/v1/cr/detail/' + encodeURIComponent(r.code) + '?seller_id=' + encodeURIComponent(r.sid);
    const [j, ev] = await Promise.all([
      api(url, acc.tk, { front: true, ignoreStop: true }),
      api(API + '/tnc-ams/v1/evidence-documents-request?seller_id=' + encodeURIComponent(r.sid) + '&order_code=' + encodeURIComponent(r.order), acc.tk, { front: true, ignoreStop: true }).catch((e) => ({ error: e.message })),
    ]);
    if (j && j.data) Object.assign(d, { detail: j.data, upd: it && it.row.updated_at, st: r.status, at: Date.now() });
    if (ev && !ev.error) Object.assign(d, { ev: Array.isArray(ev.data) ? ev.data : [], evAt: Date.now() }); else d.loadError = 'Chưa kiểm tra được bằng chứng: ' + ev.error;
  } catch (e) { d.loadError = 'Không tải được chi tiết: ' + e.message; }
  d.loading = false; DET.set(r.key, d);
  const { loading, loadError, ...save } = d; storePut('details', [save]).catch(() => {});
  if (r.kind === 'fd' && it) { const job = { kind: 'fd', sid: String(r.sid), acc, map: new Map([[r.code, it.row]]) }; await lookupProducts([job]); }
  rebuild(); refreshDrawer();
}

/* ======================= KPI ======================= */
function renderKPI() {
  const host = $('#view');
  if (!hasData()) { host.innerHTML = emptyState(); return; }
  const rev = AV.map((r) => K.reverse(r, kcfg())), records = OV.concat(rev), sum = K.summarize(records);
  const ex = records.flatMap((r) => r.kpis.filter((k) => k.state === 'overdue' || k.state === 'late').map((k) => ({ r, k }))).sort((a, b) => (a.k.due || 0) - (b.k.due || 0));
  host.innerHTML = `<div class="scope-row">${scopeChip()}<span class="spacer"></span><button class="btn ghost sm" data-act="kexport">Xuất Excel KPI</button></div>
  <div class="card"><div class="card-h"><b>KPI theo công đoạn</b><span class="muted">KPI = đúng hạn / đã hoàn tất có đủ mốc · giờ Việt Nam</span></div><div class="tw"><table><thead><tr><th>Công đoạn</th><th class="num">Mục tiêu</th><th class="num">Đúng / hoàn tất</th><th>KPI</th><th class="num">Quá hạn</th><th class="num">Trong hạn</th><th class="num">Thiếu mốc</th><th class="num">Loại trừ</th></tr></thead><tbody>${sum.map((g) => `<tr><td><b>${esc(g.label)}</b></td><td class="num">${g.target == null ? 'Theo thỏa thuận' : g.target * 100 + '%'}</td><td class="num">${nf(g.ontime)} / ${nf(g.denominator)}</td><td>${g.rate == null ? '<span class="pill mute">Chưa đủ mẫu</span>' : `<div class="meter"><i style="width:${g.rate * 100}%" class="${g.target != null && g.rate < g.target ? 'bad' : 'ok'}"></i><span>${(g.rate * 100).toFixed(1)}%</span></div>`}</td><td class="num">${g.overdue ? `<span class="pill bad">${nf(g.overdue)}</span>` : '0'}</td><td class="num">${nf(g.pending)}</td><td class="num muted">${nf(g.unknown)}</td><td class="num muted">${nf(g.excluded)}</td></tr>`).join('') || '<tr><td colspan="8" class="empty-cell">Chưa có dữ liệu.</td></tr>'}</tbody></table></div>
  <div class="card-f">Ở chế độ <b>Đang mở</b>, KPI chủ yếu cho biết đơn <b>quá hạn / trong hạn</b>. Tỷ lệ đúng hạn cần mốc hoàn tất (lịch sử đơn) — có khi mở chi tiết đơn, hoặc đồng bộ Theo ngày tạo.</div></div>
  <div class="card"><div class="card-h"><b>Quá hạn / hoàn tất trễ</b><span class="muted">${nf(ex.length)} công đoạn · hiển thị 300 đầu</span></div><div class="tw tall"><table><thead><tr><th>Loại</th><th>Mã</th><th>Công đoạn</th><th>Hạn</th><th>Kết quả</th><th>Tài khoản</th></tr></thead><tbody>${ex.slice(0, 300).map(({ r, k }) => `<tr class="click" data-kk="${esc(r.kind === 'order' ? r.key : okey(r.kind, r.sid, r.code))}"><td>${r.kind === 'order' ? 'Đơn' : r.kind.toUpperCase()}</td><td>${copyable(r.code)}</td><td>${esc(k.label)}</td><td>${fdt(k.due)}</td><td>${kbadge(k.state)}</td><td class="muted">${esc(r.acc)}</td></tr>`).join('') || '<tr><td colspan="6" class="empty-cell">Không có công đoạn quá hạn.</td></tr>'}</tbody></table></div></div>
  <details class="card rules"><summary>Quy tắc PDF TikiNOW 2026 đang áp dụng</summary><div class="rules-b">
   <p><b>Đóng gói B2C 96%</b> · Ưu tiên: 90 phút làm việc (08–18h). Lazada: trước 14h → 19h N; 14–20h → 13h N+1; từ 20h → 19h N+1. Shopee: trước 16h → 20h N; sau → 11h N+1. TikTok: trước 18h → 20h N; sau → 11h N+1. Kênh khác: trước 13h → 19h N; 13–19h → 13h N+1; sau 19h → 19h N+1.</p>
   <p><b>Pickup 95%</b>: xác nhận trước 13h → 19h N, từ 13h → 19h N+1. <b>Delivery 95%</b>: theo tuyến (gán trong chi tiết đơn). <b>B2B</b>: SLA 1 FMCG / SLA 2 HB & Fashion. <b>NOW 95%</b>: trước 16h tính từ phút 59 + 2/4h.</p>
   <p><b>Hậu mãi 95%/công đoạn</b>: FD hoàn về N+4/5/6 theo vùng; QC N+1; nhập lại N+1. CR lấy hàng N+2; về kho N+3/4/5; QC N+1. Thiếu mốc → “Thiếu mốc”, không tự tính đạt.</p>
   <p>Lịch: Thứ 2–7, loại Chủ nhật, 01/01, 30/04, 01/05, 02/09 và ngày nghỉ khai báo trong Cài đặt.</p></div></details>`;
  host.onclick = (e) => {
    const cp = e.target.closest('[data-copy]'); if (cp) { e.stopPropagation(); return copyText(cp.dataset.copy); }
    if (e.target.closest('[data-act="kexport"]')) return exportOrders(OV, true);
    const tr = e.target.closest('tr[data-kk]'); if (!tr) return;
    const k = tr.dataset.kk; if (k.startsWith('orders|')) openOrder(ORDERS.find((x) => x.key === k)); else openAfter(AFTER.find((x) => x.key === k));
  };
}

/* ======================= ACCOUNTS ======================= */
const AV_COLORS = ['#2563eb', '#7c3aed', '#db2777', '#ea580c', '#059669', '#0891b2', '#4f46e5', '#b91c1c'];
const avColor = (s) => AV_COLORS[[...String(s)].reduce((a, c) => a + c.charCodeAt(0), 0) % AV_COLORS.length];
function accountSyncStatus(sid) {
  const names = { orders: 'Đơn hàng', fd: 'FD', cr: 'CR' };
  const active = BUSY ? JOBS.filter(j => String(j.sid) === String(sid) && ['wait', 'run', 'saving'].includes(j.state)) : [];
  const live = active.map(j => `<div class="note sm"><b>Lượt hiện tại · ${names[j.kind]}</b>: ${j.state === 'saving' ? (j.saveStage === 'writing' ? 'Đang lưu ' + nf(j.saved) + '/' + nf(j.saveTotal) + ' dòng vào Chrome' : 'Đã tải xong, đang chuẩn bị / thay dữ liệu đã lưu') : j.state === 'run' ? 'Đang tải ' + nf(j.count) + ' dòng · trang ' + j.pd + '/' + (j.pt || '?') : 'Đang chờ'}</div>`).join('');
  const previous = ['orders', 'fd', 'cr'].filter(k => !active.some(j => j.kind === k)).map(k => ({ kind: k, meta: META[sid + '|' + k] })).filter(x => x.meta && x.meta.lastError && (!x.meta.at || x.meta.lastAttempt > x.meta.at));
  return live + previous.map(x => `<div class="note bad sm"><b>Lượt trước · ${names[x.kind]}</b> (${fdt(x.meta.lastAttempt)}): ${esc(x.meta.lastError)}</div>`).join('');
}
async function renderAccounts() {
  ACCOUNTS = await getAccounts();
  if (CURRENT !== 'accounts') return;
  const list = Object.values(ACCOUNTS).sort((a, b) => (b.savedAt || 0) - (a.savedAt || 0));
  const cnt = (sid, k) => ROWS[k].filter((r) => r.sid === String(sid)).length;
  $('#view').innerHTML = '<div class="accs">' + list.map((a) => {
    const alive = tokenAlive(a), h = Math.max(0, Math.round((a.exp - Date.now()) / 3600e3));
    const status = accountSyncStatus(a.sellerId);
    return `<div class="acct"><div class="acc-top"><div class="av" style="background:${avColor(a.sellerId)}">${esc((a.name || a.email || '?').trim()[0].toUpperCase())}</div><div class="who"><b>${esc(a.name || a.email || 'seller ' + a.sellerId)}</b><span>${esc(a.email || '')} · seller <span class="mono">${esc(a.sellerId)}</span></span></div><span class="pill ${alive ? 'ok' : 'bad'}">${alive ? '● còn ' + h + 'h' : a.dead ? 'bị thu hồi' : 'hết hạn'}</span></div>
    <div class="acc-stats"><div><b>${nf(cnt(a.sellerId, 'orders'))}</b><span>đơn đã lưu</span></div><div><b>${nf(cnt(a.sellerId, 'fd'))}</b><span>FD</span></div><div><b>${nf(cnt(a.sellerId, 'cr'))}</b><span>CR</span></div></div>
    ${status}
    <div class="acc-act"><button class="btn ghost sm" data-sync="${esc(a.sellerId)}" ${alive ? '' : 'disabled'}>Đồng bộ riêng</button><button class="btn ghost sm" data-only="${esc(a.sellerId)}">Chỉ xem TK này</button><span class="spacer"></span><button class="btn ghost sm danger" data-del="${esc(a.sellerId)}">Gỡ</button></div></div>`;
  }).join('') + `<div class="acct add"><b>+ Thêm tài khoản</b><p class="muted sm">Đăng xuất TikiNOW Center, đăng nhập tài khoản khác — Hub tự lưu token (không lưu mật khẩu). Token sống ~24h.</p><div class="acc-act"><a class="btn primary sm" target="_blank" href="https://tikinowcenter.tikinow.vn">Mở TikiNOW Center ↗</a><button class="btn ghost sm" data-act="rescan">Quét lại đăng nhập</button></div></div></div>`;
  $('#view').onclick = async (e) => {
    const b = e.target.closest('button'); if (!b) return;
    if (b.dataset.sync) return sync(b.dataset.sync);
    if (b.dataset.only) return setAccFilter(b.dataset.only, 'overview');
    if (b.dataset.del) { await patchAccount(b.dataset.del, null); renderAccounts(); refreshAccounts(); }
  };
}
async function rescan() {
  const r = await captureFromCookies().catch((e) => ({ error: e, diag: [e.message] }));
  const why = (r.diag || []).filter(Boolean).slice(0, 2).join(' · ');
  if (r.current) toast('Đã nhận tài khoản: ' + accLabel(r.current), 'ok');
  else if (r.found) toast('Có cookie nhưng TikiNOW từ chối token — đăng nhập lại. ' + ((r.error && r.error.message) || why), 'bad', 9000);
  else toast('Chưa đọc được đăng nhập. Mở / F5 một tab tikinowcenter.tikinow.vn rồi quét lại.' + (why ? ' (' + why + ')' : ''), 'bad', 9000);
  await refreshAccounts(); render();
}
async function refreshAccounts() {
  ACCOUNTS = await getAccounts();
  const accs = Object.values(ACCOUNTS), alive = accs.filter(tokenAlive);
  $('#nAcc').textContent = accs.length ? alive.length + '/' + accs.length : '';
  $('#accReady').textContent = alive.length ? alive.length + ' tài khoản sẵn sàng' : '';
  const sel = $('#accFilter'), seen = new Set(accs.map((a) => String(a.sellerId)));
  const extra = [...new Map(ROWS.orders.concat(ROWS.fd, ROWS.cr).filter((r) => !seen.has(r.sid)).map((r) => [r.sid, r.acc])).entries()];
  sel.innerHTML = '<option value="">Tất cả tài khoản</option>' + accs.map((a) => `<option value="${esc(a.sellerId)}">${esc(accLabel(a))}</option>`).join('') + extra.map(([s, l]) => `<option value="${esc(s)}">${esc(l)}</option>`).join('');
  sel.value = ACCF; if (sel.value !== ACCF) { ACCF = ''; sel.value = ''; }
  const b = $('#banner'), dead = accs.filter((a) => !tokenAlive(a));
  if (!accs.length) { b.className = 'banner warn'; b.innerHTML = '<span>Chưa nhận được tài khoản TikiNOW nào. Đăng nhập <b>tikinowcenter.tikinow.vn</b> trên Chrome này.</span><span class="spacer"></span><a class="btn ghost sm" target="_blank" href="https://tikinowcenter.tikinow.vn">Mở TikiNOW ↗</a><button class="btn ghost sm" data-act="rescan">Quét lại</button>'; }
  else if (dead.length) { b.className = 'banner bad'; b.innerHTML = `<span><b>${dead.length}</b> tài khoản cần đăng nhập lại: ${dead.map((a) => esc(accLabel(a))).join(', ')}</span><span class="spacer"></span><a class="btn ghost sm" target="_blank" href="https://tikinowcenter.tikinow.vn">Mở TikiNOW ↗</a><button class="btn ghost sm" data-act="rescan">Quét lại</button>`; }
  else b.className = 'banner hidden';
}
async function setAccFilter(sid, view) { ACCF = sid || ''; $('#accFilter').value = ACCF; await chrome.storage.local.set({ uiV5: { accf: ACCF } }); refilter(); if (view) switchView(view); else render(); }

/* ======================= SETTINGS ======================= */
function renderSettings() {
  const chk = (kind) => { const dict = kind === 'fd' ? E.FD_STATUS : E.CR_STATUS, counts = {}; AFTER.forEach((r) => { if (r.kind === kind) counts[r.status] = (counts[r.status] || 0) + 1; }); const done = new Set(S.done[kind]); return Object.keys(dict).map((c) => `<label class="chip ${done.has(c) ? 'on' : ''}"><input type="checkbox" data-done="${kind}" value="${esc(c)}" ${done.has(c) ? 'checked' : ''}><span>${esc(dict[c])}${counts[c] ? ` <b>${nf(counts[c])}</b>` : ''}</span></label>`).join(''); };
  $('#view').innerHTML = `<div class="set">
  <div class="card"><div class="card-h"><b>Đồng bộ</b></div><div class="frow">
    <label>Request song song<input type="number" min="1" max="10" data-s="concurrency" value="${S.concurrency}"></label>
    <label>Giới hạn tự chọn (đơn/tài khoản, 0 = không giới hạn tổng)<input type="number" min="0" step="1000" data-s="rangeLimit" value="${S.rangeLimit}"></label>
    <label class="ck"><input type="checkbox" data-s="aftersalesDetail" ${S.aftersalesDetail ? 'checked' : ''}> Tự bổ sung chi tiết FD/CR đang mở (SL thiếu, lịch sử, sản phẩm)</label>
    <label class="ck"><input type="checkbox" data-s="autoSync" ${S.autoSync ? 'checked' : ''}> Tự đồng bộ khi mở Hub nếu dữ liệu cũ hơn 15 phút</label></div>
    <div class="card-f">Đơn hàng: chi tiết + video chỉ tải khi mở từng đơn (≈2 request). Tải chi tiết hàng loạt cho hàng trăm nghìn đơn là nguyên nhân bản cũ chạy không xong.</div></div>
  <div class="card"><div class="card-h"><b>Cảnh báo tồn lâu hậu mãi</b><span class="muted">quy tắc nội bộ, tách khỏi KPI PDF</span></div><div class="frow">
    <label>FD trễ khi chưa xong quá (ngày)<input type="number" min="0" step="0.5" data-s="slaFd" value="${S.slaFd}"></label>
    <label>CR không có ngày dự kiến: quá (ngày)<input type="number" min="0" step="0.5" data-s="slaCr" value="${S.slaCr}"></label>
    <label class="ck"><input type="checkbox" data-s="crUseEta" ${S.crUseEta ? 'checked' : ''}> CR trễ khi quá ngày dự kiến về kho</label></div></div>
  <div class="card"><div class="card-h"><b>Trạng thái coi là KẾT THÚC</b><span class="muted">không tính đang mở / trễ · số = dòng đã tải</span></div><div class="sub-h">FD</div><div class="chips wrap">${chk('fd')}</div><div class="sub-h">CR</div><div class="chips wrap">${chk('cr')}</div></div>
  <div class="card"><div class="card-h"><b>KPI theo PDF 2026</b></div><div class="frow">
    <label>Nhóm SLA đóng gói B2B<select data-s="b2bGroup"><option value="">Chưa xác định</option><option value="FMCG" ${S.b2bGroup === 'FMCG' ? 'selected' : ''}>SLA 1 · FMCG</option><option value="HB_FASHION" ${S.b2bGroup === 'HB_FASHION' ? 'selected' : ''}>SLA 2 · HB & Fashion</option></select></label>
    <label>Ưu tiên 90 phút<select data-s="priorityMode"><option value="exact">Từ đúng phút tạo</option><option value="hour_bucket" ${S.priorityMode === 'hour_bucket' ? 'selected' : ''}>Từ đầu giờ tạo (ví dụ PDF)</option></select></label></div>
    <div class="frow"><label class="grow">Ngày nghỉ bổ sung (YYYY-MM-DD, phẩy)<textarea rows="2" data-dates="holidays" placeholder="2026-02-16, 2026-02-17">${esc(S.holidays.join(', '))}</textarea></label><label class="grow">D-Day / Peak gia hạn B2B 1 ngày<textarea rows="2" data-dates="peakDays">${esc(S.peakDays.join(', '))}</textarea></label></div></div>
  <div class="card"><div class="card-h"><b>Dữ liệu</b></div><div class="frow"><span class="muted">${nf(ROWS.orders.length)} đơn · ${nf(ROWS.fd.length)} FD · ${nf(ROWS.cr.length)} CR · ${nf(DET.size)} chi tiết đã lưu</span><span class="spacer"></span><button class="btn ghost sm" data-act="clear">Xóa dữ liệu đã tải</button><button class="btn ghost sm danger" data-act="clearAll">Xóa sạch (gồm token)</button></div></div></div>`;
  const host = $('#view');
  host.onchange = async (e) => {
    const t = e.target;
    if (t.dataset.s) { const k = t.dataset.s; S[k] = t.type === 'checkbox' ? t.checked : t.type === 'number' ? +t.value : t.value; await saveSettings(); if (['slaFd', 'slaCr', 'crUseEta', 'b2bGroup', 'priorityMode'].includes(k)) rebuild(); toast('Đã lưu.', 'ok', 1200); }
    if (t.dataset.done) { const k = t.dataset.done; S.done[k] = $$(`[data-done="${k}"]:checked`, host).map((x) => x.value); t.closest('.chip').classList.toggle('on', t.checked); await saveSettings(); rebuild(); }
    if (t.dataset.dates) { const a = t.value.split(/[\s,;]+/).filter(Boolean); if (a.some((v) => !/^\d{4}-\d{2}-\d{2}$/.test(v))) { toast('Ngày không hợp lệ — dùng YYYY-MM-DD.', 'bad'); return; } S[t.dataset.dates] = [...new Set(a)]; await saveSettings(); rebuild(); toast('Đã lưu lịch.', 'ok', 1200); }
  };
}

/* ======================= EXPORT ======================= */
function stamp() { const d = new Date(), p = (n) => ('0' + n).slice(-2); return d.getFullYear() + p(d.getMonth() + 1) + p(d.getDate()) + '_' + p(d.getHours()) + p(d.getMinutes()); }
async function download(wb, name) { const blob = await wb.toBlob(); const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 5000); toast('Đã tải ' + name, 'ok', 4000); }
async function exportOrders(rows, withKpi) {
  if (!rows.length) return toast('Không có đơn để xuất.', 'bad');
  toast('Đang tạo Excel…', '', 0); await sleep(30);
  const wb = X.workbook(), h = (a) => a.map((v) => ({ v, s: 'h' })), d = (v) => (v ? { v: v instanceof Date ? v : K.date(v), s: 'd' } : '');
  const head = ['Tài khoản', 'Mã TikiNOW', 'Mã sàn', 'Vận đơn', 'Kênh', 'Shop', 'Loại đơn', 'Trạng thái', 'Trạng thái phụ', 'Tạo lúc', 'Hạn đóng gói (KPI)', 'SLA đóng gói', 'Hạn Center', 'Kho', 'ĐVVC', 'Người nhận', 'Điện thoại', 'Địa chỉ', 'SL', 'COD', 'Tạm giữ', 'Có nhãn', 'SKU'];
  wb.sheet('Đơn hàng', [h(head), ...rows.map((r) => [r.acc, r.code, r.ref, r.tracking || r.external, r.channel, r.store, SERVICE[r.service], r.statusVi, subVi(r.sub), d(r.created), d(r.fulfil && r.fulfil.due), r.fulfil ? { v: KPI_LABEL[r.fulfil.state], s: kcls(r.fulfil.state) === 'bad' ? 'bad' : '' } : '', d(r.promised), r.wh, r.partner, r.recipient, r.phone, r.address, r.qty, r.cod || 0, r.isHolding ? 'Có' : '', r.hasLabel ? 'Có' : 'Chưa', (r.raw.items || []).map((x) => x.sku + ' ×' + (x.quantity ?? x.qty)).join(', ')])], { freeze: 1, filter: true, widths: [22, 14, 26, 18, 10, 18, 18, 16, 18, 15, 15, 12, 15, 10, 12, 20, 13, 40, 6, 11, 8, 8, 40] });
  if (withKpi) {
    const rev = AV.map((r) => K.reverse(r, kcfg())), recs = rows.concat(rev), sum = K.summarize(recs);
    wb.sheet('KPI tổng hợp', [h(['Công đoạn', 'Mục tiêu', 'Đúng hạn', 'Hoàn tất trễ', 'Mẫu số', 'KPI', 'Quá hạn', 'Trong hạn', 'Thiếu mốc', 'Loại trừ']), ...sum.map((g) => [g.label, g.target == null ? 'Theo thỏa thuận' : { v: g.target, s: 'p' }, g.ontime, g.late, g.denominator, g.rate == null ? '—' : { v: g.rate, s: g.target != null && g.rate < g.target ? 'bad' : 'p' }, g.overdue, g.pending, g.unknown, g.excluded])], { widths: [30, 14, 10, 12, 10, 10, 10, 10, 10, 10] });
    wb.sheet('KPI chi tiết', [h(['Loại', 'Mã', 'Công đoạn', 'Bắt đầu', 'Hạn', 'Thực tế', 'Kết quả', 'Ghi chú']), ...recs.flatMap((r) => r.kpis.map((k) => [r.kind === 'order' ? 'Đơn' : r.kind.toUpperCase(), r.code, k.label, d(k.start), d(k.due), d(k.end), KPI_LABEL[k.state], k.reason || k.source]))], { freeze: 1, filter: true, widths: [6, 22, 26, 15, 15, 15, 12, 50] });
  }
  await download(wb, 'TikiNOW_DonHang_' + stamp() + '.xlsx');
}
async function exportAfter(rows, view) {
  if (!rows.length) return toast('Danh sách trống.', 'bad');
  const sheets = view === 'late' ? { late: true, timeline: true, videos: true } : view === 'all' ? { overview: true, late: true, fd: true, cr: true, fdItems: true, crProducts: true, timeline: true, videos: true } : { [view]: true, [view === 'fd' ? 'fdItems' : 'crProducts']: true, timeline: true, videos: true };
  toast('Đang tạo Excel…', '', 0); await sleep(30);
  const wb = E.buildWorkbook({ X, recs: rows, groups: [], sheets, onlyPending: false, split: false, rawFields: false, now: Date.now(), sla: { fd: S.slaFd, cr: S.slaCr }, accLabel: ACCF ? accLabel(ACCOUNTS[ACCF]) : 'tất cả' });
  await download(wb, 'TikiNOW_HauMai_' + (view === 'all' ? 'FD-CR' : view.toUpperCase()) + '_' + stamp() + '.xlsx');
}
function exportCurrent() {
  if (CURRENT === 'orders') return exportOrders(ORDER_LIST.length ? ORDER_LIST : OV);
  if (CURRENT === 'kpi') return exportOrders(OV, true);
  if (['fd', 'cr', 'late'].includes(CURRENT)) return exportAfter(GRID_OUT, CURRENT);
  if (AV.length) return exportAfter(AV, 'all');
  return exportOrders(OV, true);
}

/* ======================= WIRING ======================= */
function syncControls() {
  $$('#modeSeg button').forEach((b) => b.classList.toggle('active', b.dataset.mode === S.mode));
  $('#rangeBox').classList.toggle('dim', S.mode !== 'range');
  $('#orderScope').value = S.orderStatus || '';
  $('#orderScope').disabled = BUSY;
  $$('#daysSeg button').forEach((b) => b.classList.toggle('active', +b.dataset.days === +S.days));
  $('#from').value = S.from; $('#to').value = S.to; $('#to').max = $('#from').max = vnDay(Date.now());
  $$('#kinds input').forEach((c) => { c.checked = !!S.kinds[c.value]; c.closest('.chip').classList.toggle('on', c.checked); });
}
function wire() {
  $('#nav').addEventListener('click', (e) => { const b = e.target.closest('button[data-view]'); if (b) switchView(b.dataset.view); });
  $('#syncBtn').addEventListener('click', () => sync());
  $('#stopBtn').addEventListener('click', () => { STOP = true; $('#stopBtn').textContent = 'Đang dừng…'; });
  $('#pToggle').addEventListener('click', () => $('#pjobs').classList.toggle('hidden'));
  $('#modeSeg').addEventListener('click', async (e) => { const b = e.target.closest('[data-mode]'); if (!b || BUSY) return; S.mode = b.dataset.mode; await saveSettings(); syncControls(); });
  $('#daysSeg').addEventListener('click', async (e) => { const b = e.target.closest('[data-days]'); if (!b || BUSY) return; S.days = +b.dataset.days; S.mode = 'range'; fixRange(); await saveSettings(); syncControls(); });
  for (const id of ['from', 'to']) $('#' + id).addEventListener('change', async (e) => { S[id] = e.target.value; S.days = 0; S.mode = 'range'; fixRange(); await saveSettings(); syncControls(); });
  $('#orderScope').addEventListener('change', async (e) => { if (BUSY) return; S.orderStatus = e.target.value; S.mode = 'range'; fixRange(); await saveSettings(); syncControls(); });
  $('#kinds').addEventListener('change', async (e) => { S.kinds[e.target.value] = e.target.checked; e.target.closest('.chip').classList.toggle('on', e.target.checked); await saveSettings(); });
  $('#accFilter').addEventListener('change', (e) => setAccFilter(e.target.value));
  $('#exportBtn').addEventListener('click', exportCurrent);
  $('#themeBtn').addEventListener('click', async () => { S.theme = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark'; applyTheme(); await saveSettings(); });
  $('#drawerClose').addEventListener('click', closeDrawer);
  $('#drawer').addEventListener('click', async (e) => {
    if (e.target.id === 'drawer') return closeDrawer();
    const cp = e.target.closest('[data-copy]'); if (cp) return copyText(cp.dataset.copy);
    const a = e.target.closest('[data-act]'); if (!a || !DRAWER) return;
    const r = DRAWER.type === 'order' ? ORDERS.find((x) => x.key === DRAWER.key) : AFTER.find((x) => x.key === DRAWER.key);
    if (!r) return;
    if (a.dataset.act === 'odiagnostic') return exportOrderDiagnostic(r);
    if (a.dataset.act === 'oload') { const d = DET.get(r.key); if (d) d.loadError = ''; return loadOrderDetail(r); }
    if (a.dataset.act === 'aload') { const d = DET.get(r.key); if (d) d.loadError = ''; return loadAfterDetail(r); }
    if (a.dataset.act === 'ojson' || a.dataset.act === 'ajson') return copyText(JSON.stringify(K.sanitize(r.raw), null, 2));
    if (a.dataset.act === 'orule') { const f = $('#orderRule').elements; S.orderOverrides[r.sid + '|' + r.code] = { lane: f.lane.value, b2bGroup: f.b2bGroup.value, priority: f.priority.checked, office: f.office.checked, nowHours: f.nowHours.value, exclusion: f.exclusion.value.trim() }; await saveSettings(); rebuild(); refreshDrawer(); toast('Đã lưu quy tắc cho đơn.', 'ok'); }
    if (a.dataset.act === 'arule') { const f = $('#reverseRule').elements; S.reverseOverrides[r.sid + '|' + r.code] = { region: f.region.value, goods: f.goods.value }; await saveSettings(); refreshDrawer(); toast('Đã lưu.', 'ok'); }
  });
  // Hành động chung trong vùng nội dung / banner
  document.addEventListener('click', async (e) => {
    const a = e.target.closest('[data-act]'); if (!a || a.closest('#drawer')) return;
    const act = a.dataset.act;
    if (act === 'lookup-order') return lookupOrderByCode();
    if (act === 'completed-orders') return syncCompletedOrders();
    if (act === 'sync') return sync();
    if (act === 'rescan') return rescan();
    if (act === 'mail') { const txt = E.mailSummary(AV, { now: Date.now(), sla: { fd: S.slaFd, cr: S.slaCr }, accLabel: ACCF ? accLabel(ACCOUNTS[ACCF]) : '' }); const open = OV.filter((r) => !r.done), over = open.filter((r) => r.fulfil && r.fulfil.state === 'overdue'); return copyText((ROWS.orders.length ? `ĐƠN HÀNG: đang mở ${nf(open.length)} · quá hạn đóng gói ${nf(over.length)}\n\n` : '') + txt); }
    if (act === 'clear' && confirm('Xóa toàn bộ dữ liệu đã tải (giữ token)?')) { for (const n of ['rows', 'details', 'products', 'extids']) await storeClear(n); ROWS.orders = []; ROWS.fd = []; ROWS.cr = []; DET = new Map(); PROD = {}; EXT = {}; META = {}; COUNTS = {}; await chrome.storage.local.remove(['metaV5', 'countsV5']); rebuild(); renderFresh(); render(); toast('Đã xóa dữ liệu.', 'ok'); }
    if (act === 'clearAll' && confirm('Xóa sạch tài khoản, token và dữ liệu?')) { for (const n of ['rows', 'details', 'products', 'extids']) await storeClear(n); await chrome.storage.local.clear(); location.reload(); }
  });
  // Bấm số liệu ở Tổng quan → nhảy sang danh sách đã lọc sẵn
  $('#view').addEventListener('click', (e) => {
    if (CURRENT !== 'overview') return;
    const t = e.target.closest('[data-go]');
    if (t) { const g = t.dataset.go; if (g === 'orders:open') { Object.assign(OF, { status: 'open', kpi: '', flag: '', wh: '', page: 0 }); return switchView('orders'); } if (g === 'orders:overdue') { Object.assign(OF, { status: 'open', kpi: 'overdue', flag: '', wh: '', page: 0 }); return switchView('orders'); } if (g !== 'late') GRID_PRESET[g] = {}; return switchView(g); }
    const wh = e.target.closest('tr[data-wh]'); if (wh) { Object.assign(OF, { status: 'open', wh: wh.dataset.wh, kpi: '', flag: '', page: 0 }); return switchView('orders'); }
    const tr = e.target.closest('tr[data-goto]'); if (tr) { GRID_PRESET[tr.dataset.goto] = { grp: tr.dataset.grp || '' }; switchView(tr.dataset.goto); }
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') return closeDrawer();
    if (/INPUT|SELECT|TEXTAREA/.test(document.activeElement.tagName) || e.ctrlKey || e.metaKey || e.altKey) return;
    if (e.key === '/') { const s = $('#view .search'); if (s) { e.preventDefault(); s.focus(); } }
    else if (e.key === 'r' || e.key === 'R') sync();
    else if ('1234567'.includes(e.key)) switchView(['overview', 'orders', 'kpi', 'fd', 'cr', 'late', 'accounts'][+e.key - 1]);
  });
  chrome.storage.onChanged.addListener((ch, area) => { if (area === 'local' && ch.accounts) { refreshAccounts(); if (CURRENT === 'accounts') renderAccounts(); } });
  window.addEventListener('focus', () => captureFromCookies().then(refreshAccounts).catch(() => {}));
  setInterval(() => { renderFresh(); if (!BUSY && hasData()) { rebuild(); renderSoft(); } }, 5 * 60000);
}

async function init() {
  await loadSettings(); applyTheme(); wire(); syncControls();
  const o = await chrome.storage.local.get(['metaV5', 'countsV5', 'uiV5']);
  META = o.metaV5 || {}; COUNTS = o.countsV5 || {}; ACCF = (o.uiV5 && o.uiV5.accf) || '';
  const [rows, det, prod, ext] = await Promise.all([storeAll('rows'), storeAll('details'), storeAll('products'), storeAll('extids')]);
  for (const it of rows) (ROWS[it.kind] || (ROWS[it.kind] = [])).push(it);
  DET = new Map(det.map((d) => [d.key, d])); PROD = Object.fromEntries(prod.map((p) => [p.k, p])); EXT = Object.fromEntries(ext.map((x) => [x.k, x.v]));
  await captureFromCookies().catch(() => null);
  await refreshAccounts(); rebuild(); renderFresh(); switchView('overview');
  const last = Math.max(0, ...Object.values(META).map((m) => m.at || 0));
  if (S.autoSync && S.mode === 'open' && Object.values(ACCOUNTS).some(tokenAlive) && Date.now() - last > 15 * 60000) setTimeout(() => sync(), 400);
}
init().catch((e) => { const b = $('#banner'); b.className = 'banner bad'; b.textContent = 'Không khởi động được: ' + e.message; console.error(e); });
