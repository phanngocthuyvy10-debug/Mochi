# TikiNOW Operations Hub v5.0.0

## Cài / cập nhật
1. Giải nén, chép toàn bộ file đè vào ĐÚNG thư mục extension đang cài (giữ được token tài khoản).
2. chrome://extensions → bấm Reload ở extension. Đóng các tab Hub cũ, mở lại Hub.
3. Lần đầu mở, Hub tự dọn kho dữ liệu cũ của v4.x (hàng trăm nghìn đơn + kho ghi nhận API) để Chrome nhẹ lại.

## Dùng hằng ngày
- **Đang mở** (mặc định): đơn chưa giao xong + FD/CR chưa kết thúc, mọi ngày tạo. Đo trên tài khoản thật: ~13 giây, ~110 request.
- **Theo ngày tạo** (Hôm nay / 7N / 30N / chọn ngày): mọi trạng thái. Đơn hàng giới hạn 60.000 đơn/tài khoản (chỉnh trong Cài đặt); vượt thì chỉ lưu số tổng theo trạng thái.
- Chi tiết + video đơn hàng tải khi mở từng đơn. Chi tiết FD/CR đang mở tự bổ sung nền, có cache.
- Phím tắt: R đồng bộ · / tìm kiếm · Esc đóng · 1–7 chuyển màn.

## Vì sao v4.1.5 không kéo được
- Mặc định 6 tháng mọi trạng thái (~830 nghìn đơn/30 ngày ở seller Operation) + 6–8 API phụ cho mỗi đơn → hàng chục triệu request.
- FD/CR phải chờ phần đơn hàng xong mới chạy; các khung thời gian chạy tuần tự; lệch tổng là báo lỗi cả lượt.
- Bộ ghi nhận API chèn vào mọi trang Center làm chậm cả Center.

## Giới hạn API đã kiểm tra (02/11/2026)
- Đơn hàng: tối đa 1.000 dòng/trang, trần 10.000 dòng/truy vấn (quá trần trả lặp trang cuối, không báo lỗi) → Hub tự chia khung thời gian; lọc nhiều trạng thái được.
- FD: tối đa 50 dòng/trang, không trần, lọc nhiều trạng thái được.
- CR: tối đa 100 dòng/trang, trần 10.000, chỉ lọc 1 trạng thái/lần, trả data:null khi rỗng.
- Video đóng gói: check-evidence-documents + evidence-documents-request (chỉ đọc video đã có, không tạo yêu cầu tính phí).

## Đã bỏ khỏi v4
Bộ ghi nhận/quét toàn bộ màn hình Center và xuất JSONL kho ghi nhận — không phục vụ việc theo dõi đơn và là nguyên nhân chính gây chậm.
