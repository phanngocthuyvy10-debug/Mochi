# Kiểm tra bản 5.0.1

Đã chạy trong môi trường kiểm tra:
- `node --check` cho toàn bộ JavaScript: đạt.
- Chạy engine với FD và CR dữ liệu giả: đạt.
- Thực thi buildWorkbook với bộ ghi sheet trong bộ nhớ: cột Seller ID đúng `r.sid`, giữ số 0 đầu; partner_code được xuất riêng: đạt.
- Thực thi hàm dựng cột của FD / CR / Tồn lâu và hàm openAfter trong Node VM với DOM giả: có mã sao chép và Seller ID trong chi tiết; partner_code riêng: đạt.
- Kiểm tra tìm kiếm hậu mãi chứa r.sid: đạt.
- Kiểm tra đủ tệp gốc trong gói ZIP và 11 endpoint trong inventory: đạt.

Dữ liệu kiểm tra là dữ liệu giả. Chưa kiểm tra trình duyệt thật, hiển thị bằng ảnh chụp, phiên Chrome extension hoặc API TikiNOW thật. Không tuyên bố đây là toàn bộ API của dịch vụ; đây là toàn bộ endpoint tìm thấy trong mã nguồn ZIP.
