# Third-party components

The bundled `extension/xlsx.mini.min.js` identifies itself as SheetJS 0.18.5, copyright SheetJS. Its Apache License 2.0 text is in `docs/LICENSE-SheetJS.txt`, retrieved from the official SheetJS v0.18.5 repository. This inherited copy is unchanged; its update is an explicit production release gate.

Playwright 1.58.2 (Apache-2.0) and linkedom 0.18.12 (ISC), with their locked transitive dependencies, are development-only packages. Their notices are supplied by npm under each installed package. `node_modules` is not included in the extension or source release archives.

No new public open-source license or Chrome Web Store approval is asserted for the OnPoint application. Use and distribution remain subject to the application's existing rights and your organization's authorization.
