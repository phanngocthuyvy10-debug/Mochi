# OnPoint Marketplace Performance 2.2.91 — release candidate

Prepared 2 November 2026. The uploaded ZIP was named v2.2.35, but its actual extension manifest was v2.2.90. This candidate upgrades that manifest to 2.2.91 and retains the extension's public key/ID for existing Chrome storage and native-host compatibility.

## Improvements

- Failed Ticket Master sync records are retained after 12 failures, paused visibly, and recoverable with **Gửi lại**. Restarting a worker does not automatically unpause them.
- Ticket sync requests contain at most 150 rows, including jobs saved by older versions. Acknowledgement removes only snapshots actually sent; concurrent enqueues and newer ticket updates survive.
- Long numeric order IDs remain exact. JSON parsing no longer modifies numeric-looking text inside JSON strings.
- Required follow-up attachments must be confirmed before sending. A saved pre-send message baseline prevents the initial ticket's identical text from being mistaken for a new reply after reload. Unconfirmed sends retain their marker and pause for review. SVG-only search icons now activate their button correctly.
- Performance and ticket CSV exports neutralize spreadsheet formulas, including those preceded by whitespace/control characters.
- No shared Google Sheets write key or default write destination is included. Existing locally saved connections and queues are preserved. Fresh installs begin with automatic collection off.
- First-run guidance opens and focuses connection settings. Workspace tabs support arrow keys, Home/End, visible focus and a single tab stop. Invalid saved workspace names recover to Collect.
- Ticket links and tabs fit narrow side panels; four workspace views are tested at 320, 360, 440 and 800 px. Hidden Performance panels stop periodic redraws.
- A synthetic offline dashboard preview replaces the old report snapshot. No real seller records are needed for the preview.
- Pinned test dependencies, deterministic historical-fixture dates, a test runner, integrity checks, packaging and validation records are included in the source bundle.

## Production release gates

1. **Update the inherited SheetJS 0.18.5 browser library.** The official 0.20.3 distribution is blocked by the current cloud network policy. `cdn.sheetjs.com` has been added to the configuration draft for review; it has not been verified as accessible. The npm dependency audit covers development packages, not this copied browser library. Do not treat this candidate as cleared for untrusted spreadsheet imports.
2. **Rotate the shared connection key exposed in the original uploaded ZIP.** Removing it from this package does not revoke the old key. The Apps Script owner should run the existing `rotateConnectionKey()` in the correct Performance project and distribute the replacement privately. Update affected existing clients in Admin. No live key rotation or deployment was performed here.
3. **Complete `RELEASE_CHECKLIST.md` on an approved Chrome host with real seller sessions and on Windows for the optional native helper.** This cloud Chromium's managed `ExtensionInstallBlocklist=["*"]` prevents full unpacked-extension installation. Browser UI and automation fixture tests use mocked Chrome/platform APIs and do not prove marketplace integration.

The bundled Apps Script backend and Windows native helper are preserved from the upload. Their inclusion is not a claim of new deployment or Windows validation. Keep the existing backend deployment and storage when updating this extension.
