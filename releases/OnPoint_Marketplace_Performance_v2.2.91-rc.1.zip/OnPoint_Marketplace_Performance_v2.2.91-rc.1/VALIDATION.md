# Validation — OnPoint 2.2.91 RC1

Final run: 2026-11-02T23:55:03.338000+07:00 (Vietnam time). Node v24.19.0; system Chromium 154.0.8037.57; Playwright 1.58.2. All results below are current-instance checks, not a production deployment or a fresh-cloud-task restore.

## Results

| Check | Result |
| --- | --- |
| Offline + local Chromium fixture suites | 58 passed, 0 failed, 5 explicitly skipped |
| New release regression groups | 8 passed: IDs/JSON, CSV, retained failed sync, bounded batches, concurrent updates, private setup/upgrade, truthful retry outcome, durable reply baseline |
| Extension JS syntax | All 55 scripts passed |
| Assets / manifest / JSON / MV3 CSP | Passed |
| Public extension ID | Preserved: inalelipnbmnlnpbmefampanmimiiijb |
| Both Apps Script projects | Syntax and in-memory spreadsheet tests passed; source unchanged from upload |
| Browser panel | Four workspaces at 320/360/440/800 px, keyboard navigation, first-run setup, input preservation, iframe initialization, paused queue guidance: passed |
| Browser ticket fixtures | Current DOM selection, exact ticket capture, no duplicate submission, native file-input bytes, attachment failures, send confirmation and reload baseline: passed |
| Browser runtime errors / remote requests in new UI suite | None |
| Original shared key in candidate sources | Absent; the old server key still needs owner rotation |
| npm development dependency audit | 0 reported advisories; excludes inherited browser vendor library |
| Original backend / Windows native files | Byte-for-byte preserved; native Windows execution not tested |
| Package integrity | Per-file SHA-256, archive CRC and repeatable archive build checked during packaging |

The test summary records SHA-256 hashes of the exact extension, backend and test inputs. The packager refuses stale or failing validation. See `test-results/summary.json` in the source archive and `CHANGE_SUMMARY.json` for inspected changes.

## Skipped suites

- `tests/claim-stores-browser.js`: Requires a Chrome host that allows unpacked extension installation.
- `tests/e2e.js`: Legacy unpacked-extension harness; requires a Chrome host that allows extension installation.
- `tests/enabler-quarter.js`: Original Q3/Q4 report workbooks were not supplied.
- `tests/shopee-dom-legacy.js`: Archived pre-current-tab API/UI contract; superseded by shopee-model, shopee-api and current-tab suites.
- `tests/ticket-checks/verify-shopee-form-type-browser.cjs`: Requires a Chrome host that allows unpacked extension installation.

No zero-check suite was counted as passed. Optional branches requiring the original official workbooks were not executed. Historical fixtures are kept inside their intended October reporting window; elapsed-time/ticket timing suites use advancing real clocks. Old version assumptions and DOM harness gaps were corrected without weakening scope, identity, attachment or duplicate-send checks. The archived legacy Shopee suite still exists in source, with its obsolete behavior clearly excluded from the current test selection.

## Limits and production gates

- The copied SheetJS browser parser remains 0.18.5. Downloading the official 0.20.3 distribution returned proxy HTTP 403. `cdn.sheetjs.com` is saved as a requested domain addition, not verified as applied. After settings review/save enables access, run `node tools/update-sheetjs.mjs` and rerun checks. Production release is blocked until the vendor upgrade is verified.
- The original ZIP contained a shared write key. It was removed from this distributable, not revoked on the server. The existing Apps Script `rotateConnectionKey()` must be run by its owner, and clients updated privately.
- Real unpacked extension installation is blocked by this cloud Chromium's managed extension blocklist. UI fixtures use mocked Chrome APIs; Node suites execute real worker/backend code against storage, network and spreadsheet fakes. These do not establish MV3 lifecycle behavior in approved Windows Chrome.
- No signed-in TikTok/Shopee, SharePoint, Power BI or live Google Sheets workflow was validated. No production ticket, server configuration or data was written. Windows PowerShell/registry/native messaging, live acceptance, deployment and publication remain unrun.

Complete `RELEASE_CHECKLIST.md` before production rollout. This is an enhanced, tested release candidate, not production sign-off.
