# Production acceptance — 2.2.91

These checks remain open. Record operator, date, Chrome/Windows versions, expected result and actual result. Use a test shop and a test Sheet for submission checks.

- [ ] Allow the official SheetJS distribution in cloud environment settings, update the vendored parser from that source, verify its version/integrity and rerun `npm run check`, `npm test` and `npm run test:browser`.
- [ ] Rotate the old shared Performance write key and update existing clients privately; confirm the old key is refused.
- [ ] Install/reload in approved Chrome 120+ without changing the existing extension folder or ID. Confirm saved connections, queues, ticket logs and store mappings survive.
- [ ] On a fresh profile, confirm no bundled key/default write destination, no automatic collection, and working Admin setup for Performance and Ticket Master separately.
- [ ] Load the actual MV3 service worker, open all four workspaces, then open Ticket vận hành. Confirm no worker or page errors in Chrome's extension error view.
- [ ] With signed-in TikTok and Shopee test shops, collect and reconcile KPI/order counts, evaluation periods, shop identity, long IDs and missing timestamps. Switch shops and confirm data cannot mix.
- [ ] Disconnect during sync, close/reopen the worker/browser, restore connectivity and confirm the retained records arrive exactly once logically (upsert). Check a batch over 150 rows and the paused/Gửi lại path.
- [ ] In a test ticket workflow, verify attachments, one submission, captured Ticket ID, follow-up and tracker updates. Do not resubmit an existing ticket to test upgrade behavior.
- [ ] On Windows, install the optional native helper, confirm the stable extension ID, export/query/split an approved workbook, then test uninstall. Linux checks do not validate PowerShell, registry or native messaging.
- [ ] Review manifest permissions and the internal distribution audience. The tool can act on seller sessions, downloads, cloud documents and tickets; keep private connection material out of the ZIP.
- [ ] Confirm package SHA-256 checksums and record final sign-off. Publish/distribute only the signed-off build; no store publication was performed during this task.
