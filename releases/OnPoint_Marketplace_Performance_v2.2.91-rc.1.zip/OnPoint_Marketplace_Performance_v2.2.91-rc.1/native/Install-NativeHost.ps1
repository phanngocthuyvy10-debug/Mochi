param(
    [Parameter(Mandatory = $true)]
    [string]$PackageRoot
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version 2.0

$hostName = "com.onpoint.tts_pickup_split"
$extensionId = "inalelipnbmnlnpbmefampanmimiiijb"
$packageRootPath = [IO.Path]::GetFullPath($PackageRoot)
$sourceNative = Join-Path $packageRootPath "native"
$installRoot = Join-Path $env:LOCALAPPDATA "OnPoint\TTSPickupTicketAssistant"
$manifestPath = Join-Path $installRoot "$hostName.json"
$hostExePath = Join-Path $installRoot "OnPointTtsHost.exe"
$hostSourcePath = Join-Path $installRoot "OnPointTtsHost.cs"
$buildScriptPath = Join-Path $installRoot "Build-TTS-Split.ps1"

foreach ($required in @("OnPointTtsHost.cs", "Build-TTS-Split.ps1")) {
    if (-not (Test-Path -LiteralPath (Join-Path $sourceNative $required) -PathType Leaf)) {
        throw "Bo cai thieu file: $required"
    }
}

$null = New-Item -ItemType Directory -Path $installRoot -Force
Copy-Item -LiteralPath (Join-Path $sourceNative "OnPointTtsHost.cs") -Destination $hostSourcePath -Force
Copy-Item -LiteralPath (Join-Path $sourceNative "Build-TTS-Split.ps1") -Destination $buildScriptPath -Force
Get-ChildItem -LiteralPath $installRoot -File | Unblock-File -ErrorAction SilentlyContinue

if (Test-Path -LiteralPath $hostExePath -PathType Leaf) {
    Remove-Item -LiteralPath $hostExePath -Force
}

$hostSource = Get-Content -LiteralPath $hostSourcePath -Raw
Add-Type `
    -TypeDefinition $hostSource `
    -Language CSharp `
    -OutputAssembly $hostExePath `
    -OutputType ConsoleApplication

$manifest = @{
    name = $hostName
    description = "OnPoint TTS Pickup Excel query and split helper"
    path = $hostExePath
    type = "stdio"
    allowed_origins = @("chrome-extension://$extensionId/")
}
[IO.File]::WriteAllText(
    $manifestPath,
    ($manifest | ConvertTo-Json -Depth 4),
    (New-Object Text.UTF8Encoding($false))
)

$registryPath = "HKCU:\Software\Google\Chrome\NativeMessagingHosts\$hostName"
$null = New-Item -Path $registryPath -Force
Set-Item -Path $registryPath -Value $manifestPath

if (-not (Test-Path -LiteralPath $hostExePath -PathType Leaf)) {
    throw "Khong compile duoc helper."
}

Write-Host ""
Write-Host "========================================================" -ForegroundColor DarkMagenta
Write-Host "  DA CAI XONG DOWNLOAD + QUERY + SPLIT" -ForegroundColor Green
Write-Host "========================================================" -ForegroundColor DarkMagenta
Write-Host "Extension ID : $extensionId"
Write-Host "Helper       : $hostExePath"
Write-Host "Fast Query   : readRawChunk v0.10.10 installed"
Write-Host ""
Write-Host "BUOC TIEP THEO:"
Write-Host "1. Mo chrome://extensions"
Write-Host "2. Bat Developer mode"
Write-Host "3. Chon Load unpacked"
Write-Host "4. Chon folder: $packageRootPath\extension"
Write-Host "5. Reload tab Power BI"
