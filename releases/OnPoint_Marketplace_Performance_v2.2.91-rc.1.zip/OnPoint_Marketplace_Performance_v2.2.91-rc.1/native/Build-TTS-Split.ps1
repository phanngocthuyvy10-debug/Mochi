param(
    [Parameter(Mandatory = $true)]
    [string]$RequestBase64
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version 2.0

function Convert-ToCompactJson {
    param($Value)
    return ($Value | ConvertTo-Json -Depth 8 -Compress)
}

function Convert-ToGzipBase64 {
    param([string]$Text)

    $inputBytes = [Text.Encoding]::UTF8.GetBytes($Text)
    $memory = New-Object IO.MemoryStream
    try {
        $gzip = [IO.Compression.GZipStream]::new(
            $memory,
            [IO.Compression.CompressionMode]::Compress,
            $true
        )
        try {
            $gzip.Write($inputBytes, 0, $inputBytes.Length)
        }
        finally {
            $gzip.Dispose()
        }
        return [Convert]::ToBase64String($memory.ToArray())
    }
    finally {
        $memory.Dispose()
    }
}

function Get-Request {
    $bytes = [Convert]::FromBase64String($RequestBase64)
    $json = [Text.Encoding]::UTF8.GetString($bytes)
    return ($json | ConvertFrom-Json)
}

function Read-RawChunk {
    param($Request)

    if (
        -not ($Request.PSObject.Properties.Name -contains "rawPath") -or
        [string]::IsNullOrWhiteSpace([string]$Request.rawPath)
    ) {
        throw "Downloaded Excel path is missing."
    }

    $rawPath = [IO.Path]::GetFullPath([string]$Request.rawPath)
    if (-not (Test-Path -LiteralPath $rawPath -PathType Leaf)) {
        throw "Downloaded Excel file was not found."
    }

    [long]$offset = 0
    if ($Request.PSObject.Properties.Name -contains "offset") {
        $offset = [long]$Request.offset
    }
    if ($offset -lt 0) { $offset = 0 }

    [long]$requestedLength = 512 * 1024
    if ($Request.PSObject.Properties.Name -contains "length") {
        $requestedLength = [long]$Request.length
    }
    if ($requestedLength -lt 1) { $requestedLength = 1 }
    if ($requestedLength -gt 600 * 1024) {
        $requestedLength = 600 * 1024
    }
    [int]$chunkLength = [int]$requestedLength

    $fileInfo = Get-Item -LiteralPath $rawPath
    [long]$fileSize = $fileInfo.Length
    if ($offset -gt $fileSize) { $offset = $fileSize }

    [long]$remaining = $fileSize - $offset
    [int]$wanted = if ($remaining -lt $chunkLength) {
        [int]$remaining
    }
    else {
        $chunkLength
    }
    [byte[]]$buffer = New-Object byte[] $wanted
    [int]$totalRead = 0
    $shareMode = [IO.FileShare](
        [int][IO.FileShare]::ReadWrite -bor
        [int][IO.FileShare]::Delete
    )
    $stream = [IO.File]::Open(
        $rawPath,
        [IO.FileMode]::Open,
        [IO.FileAccess]::Read,
        $shareMode
    )
    try {
        $stream.Position = $offset
        while ($totalRead -lt $wanted) {
            $read = $stream.Read($buffer, $totalRead, $wanted - $totalRead)
            if ($read -le 0) { break }
            $totalRead += $read
        }
    }
    finally {
        $stream.Dispose()
    }

    if ($totalRead -ne $buffer.Length) {
        [byte[]]$trimmed = New-Object byte[] $totalRead
        if ($totalRead -gt 0) {
            [Array]::Copy($buffer, 0, $trimmed, 0, $totalRead)
        }
        $buffer = $trimmed
    }

    [long]$nextOffset = $offset + $totalRead
    return @{
        ok = $true
        fileSize = $fileSize
        offset = $offset
        nextOffset = $nextOffset
        eof = ($nextOffset -ge $fileSize)
        data = [Convert]::ToBase64String($buffer)
        compatibilityPath = "powershell"
    }
}

function Test-StableFile {
    param([string]$Path)
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $false }
    $first = (Get-Item -LiteralPath $Path).Length
    Start-Sleep -Milliseconds 700
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $false }
    $second = (Get-Item -LiteralPath $Path).Length
    return ($first -gt 0 -and $first -eq $second)
}

function Normalize-Text {
    param($Value)
    $text = ([string]$Value).Trim().ToLowerInvariant()
    if (-not $text) { return "" }
    $decomposed = $text.Normalize([Text.NormalizationForm]::FormD)
    $builder = New-Object Text.StringBuilder
    foreach ($char in $decomposed.ToCharArray()) {
        $category = [Globalization.CharUnicodeInfo]::GetUnicodeCategory($char)
        if ($category -ne [Globalization.UnicodeCategory]::NonSpacingMark) {
            $null = $builder.Append($char)
        }
    }
    $text = $builder.ToString().Normalize([Text.NormalizationForm]::FormC)
    $text = $text.Replace("đ", "d")
    $text = [regex]::Replace($text, "[^\p{L}\p{Nd}]+", " ")
    return ([regex]::Replace($text, "\s+", " ")).Trim()
}

function Resolve-Columns {
    param([object[]]$Headers)

    $aliases = [ordered]@{
        PlatformOrderId = @("platform order id", "platform orderid", "platform_order_id")
        OrderNo = @("order no", "order number", "order id", "order code", "order ref code", "ma don hang")
        DeliveryPlatform = @("delivery platform", "delivery partner", "logistics provider", "carrier", "dvvc")
        ChannelName = @("channel name", "opollo channel name", "shop name", "store name", "channel")
        WarehouseBranch = @(
            "warehouse branch",
            "wh branch",
            "ffm group wh branch",
            "ffm group warehouse branch",
            "warehouse name",
            "fulfillment center",
            "fc",
            "warehouse"
        )
        OrderDate = @("order date", "order created", "platform created at", "created at", "order created platform")
        SlaDate = @("sla date", "sla deadline", "firstmile sla deadline", "dispatch sla")
        TrackingNo = @("tracking no", "tracking code", "tracking id", "tracking number", "ship code")
        OrderStatus = @("order status", "warehouse status", "delivery completion status", "status")
        Cnnc = @("cnnc", "ma cnnc", "cnnc code", "channel nickname code", "channel nick name code", "ma dau don", "order prefix", "prefix", "preflix")
    }

    $normalizedHeaders = @()
    foreach ($header in $Headers) { $normalizedHeaders += (Normalize-Text $header) }
    $result = @{}

    foreach ($field in $aliases.Keys) {
        $result[$field] = $null
        $normalizedAliases = @($aliases[$field] | ForEach-Object { Normalize-Text $_ })

        for ($index = 0; $index -lt $normalizedHeaders.Count; $index++) {
            if ($normalizedAliases -contains $normalizedHeaders[$index]) {
                $result[$field] = $index + 1
                break
            }
        }
        if ($result[$field]) { continue }

        for ($index = 0; $index -lt $normalizedHeaders.Count; $index++) {
            $header = $normalizedHeaders[$index]
            if (-not $header) { continue }
            $matched = $false
            foreach ($alias in $normalizedAliases) {
                if ($header.Contains($alias)) {
                    $matched = $true
                    break
                }
            }
            if ($matched) {
                $result[$field] = $index + 1
                break
            }
        }
    }

    return $result
}

function Convert-CellToText {
    param($Value)
    if ($null -eq $Value) { return "" }
    if (
        $Value -is [byte] -or
        $Value -is [int16] -or
        $Value -is [int32] -or
        $Value -is [int64] -or
        $Value -is [single] -or
        $Value -is [double] -or
        $Value -is [decimal]
    ) {
        return ([Convert]::ToDecimal($Value)).ToString(
            "0.############################",
            [Globalization.CultureInfo]::InvariantCulture
        )
    }
    return ([string]$Value).Trim()
}

function Convert-ToExcelDateTimeValue {
    param($Value)

    if ($null -eq $Value) { return "" }
    if ($Value -is [datetime]) { return ([datetime]$Value).ToOADate() }
    if (
        $Value -is [byte] -or
        $Value -is [int16] -or
        $Value -is [int32] -or
        $Value -is [int64] -or
        $Value -is [single] -or
        $Value -is [double] -or
        $Value -is [decimal]
    ) {
        $serial = [double]$Value
        if ($serial -gt 0 -and $serial -lt 2958466) { return $serial }
    }

    $text = ([string]$Value).Trim()
    if (-not $text) { return "" }

    $formats = @(
        "MM/dd/yyyy HH:mm:ss",
        "MM/dd/yyyy HH:mm",
        "M/d/yyyy H:mm:ss",
        "M/d/yyyy H:mm",
        "MM/dd/yyyy hh:mm:ss tt",
        "MM/dd/yyyy hh:mm tt",
        "M/d/yyyy h:mm:ss tt",
        "M/d/yyyy h:mm tt",
        "dd/MM/yyyy HH:mm:ss",
        "dd/MM/yyyy HH:mm",
        "d/M/yyyy H:mm:ss",
        "d/M/yyyy H:mm",
        "dd-MM-yyyy HH:mm:ss",
        "dd-MM-yyyy HH:mm",
        "d-M-yyyy H:mm:ss",
        "d-M-yyyy H:mm",
        "yyyy-MM-dd HH:mm:ss",
        "yyyy-MM-dd HH:mm",
        "yyyy-MM-ddTHH:mm:ss",
        "yyyy-MM-ddTHH:mm:ss.fff",
        "yyyy-MM-ddTHH:mm:ssK",
        "yyyy-MM-ddTHH:mm:ss.fffK"
    )
    $styles = [Globalization.DateTimeStyles]::AllowWhiteSpaces
    foreach ($cultureName in @("en-US", "vi-VN", "en-GB", "")) {
        $culture = if ($cultureName) {
            [Globalization.CultureInfo]::GetCultureInfo($cultureName)
        }
        else {
            [Globalization.CultureInfo]::InvariantCulture
        }

        foreach ($format in $formats) {
            $parsed = [datetime]::MinValue
            if ([datetime]::TryParseExact($text, $format, $culture, $styles, [ref]$parsed)) {
                return $parsed.ToOADate()
            }
        }

        $parsed = [datetime]::MinValue
        if ([datetime]::TryParse($text, $culture, $styles, [ref]$parsed)) {
            return $parsed.ToOADate()
        }
    }

    return $text
}

function Convert-ToQueueDateTimeText {
    param($Value)

    $converted = Convert-ToExcelDateTimeValue $Value
    if (
        $converted -is [byte] -or
        $converted -is [int16] -or
        $converted -is [int32] -or
        $converted -is [int64] -or
        $converted -is [single] -or
        $converted -is [double] -or
        $converted -is [decimal]
    ) {
        try {
            return ([datetime]::FromOADate([double]$converted)).ToString("dd/MM/yyyy HH:mm")
        }
        catch {
            return ([string]$converted).Trim()
        }
    }
    return ([string]$converted).Trim()
}

function Derive-PlatformOrderId {
    param([string]$OrderNo)
    $raw = ([string]$OrderNo).Trim()
    if (-not $raw) { return "" }
    $match = [regex]::Match($raw, "(\d{12,25})$")
    if ($match.Success) { return $match.Groups[1].Value }
    $parts = @($raw -split "-" | Where-Object { $_ })
    if ($parts.Count -gt 1) { return [string]$parts[$parts.Count - 1] }
    return $raw
}

function Derive-CnncCode {
    param(
        [string]$ExplicitCode,
        [string]$OrderNo,
        [string]$PlatformOrderId
    )

    $explicit = ([string]$ExplicitCode).Trim()
    if ($explicit) { return $explicit }

    $rawOrderNo = ([string]$OrderNo).Trim()
    $orderId = ([string]$PlatformOrderId).Trim()
    if (-not $rawOrderNo -or $rawOrderNo -eq $orderId) { return "" }

    if ($orderId) {
        $index = $rawOrderNo.LastIndexOf(
            $orderId,
            [StringComparison]::OrdinalIgnoreCase
        )
        if ($index -gt 0) {
            $prefix = $rawOrderNo.Substring(0, $index)
            $prefix = [regex]::Replace($prefix, "[\s\-_/|:]+$", "").Trim()
            if ($prefix) { return $prefix }
        }
    }

    $match = [regex]::Match(
        $rawOrderNo,
        "^([A-Za-z][A-Za-z0-9]{1,30})(?:[\s\-_/|:]+)"
    )
    if ($match.Success) { return $match.Groups[1].Value }
    return ""
}

function Get-SafeFilePart {
    param([string]$Value)
    $safe = [regex]::Replace(([string]$Value).Trim(), '[<>:"/\\|?*\x00-\x1F]', "_")
    $safe = [regex]::Replace($safe, "\s+", " ").Trim([char[]]@(" ", "."))
    if (-not $safe) { $safe = "Unknown" }
    if ($safe.Length -gt 45) { $safe = $safe.Substring(0, 45).Trim() }
    return $safe
}

function Get-OutputRoot {
    param([string]$RawPath)
    $rawDirectory = [IO.Path]::GetDirectoryName($RawPath)
    $rawLeaf = [IO.Path]::GetFileName($rawDirectory)
    $parent = [IO.Directory]::GetParent($rawDirectory)
    if (
        $rawLeaf -ieq "Raw" -and
        $parent -and
        $parent.Name -ieq "OnPoint_TTS_Pickup_Ticket"
    ) {
        return $parent.FullName
    }
    return (Join-Path $rawDirectory "OnPoint_TTS_Pickup_Ticket")
}

function Open-OutputFolder {
    $statePath = Join-Path $PSScriptRoot "last-result.json"
    if (Test-Path -LiteralPath $statePath -PathType Leaf) {
        $state = Get-Content -LiteralPath $statePath -Raw | ConvertFrom-Json
        if ($state.outputPath -and (Test-Path -LiteralPath ([string]$state.outputPath))) {
            $null = Start-Process -FilePath ([string]$state.outputPath)
            return @{ ok = $true; outputPath = [string]$state.outputPath }
        }
    }

    $fallback = Join-Path ([Environment]::GetFolderPath("UserProfile")) "Downloads\OnPoint_TTS_Pickup_Ticket\Output"
    if (-not (Test-Path -LiteralPath $fallback -PathType Container)) {
        $null = New-Item -ItemType Directory -Path $fallback -Force
    }
    $null = Start-Process -FilePath $fallback
    return @{ ok = $true; outputPath = $fallback }
}

function Get-QueueCacheRoot {
    $root = Join-Path $PSScriptRoot "QueueCache"
    if (-not (Test-Path -LiteralPath $root -PathType Container)) {
        $null = New-Item -ItemType Directory -Path $root -Force
    }
    return $root
}

function Write-QueueCache {
    param(
        [System.Collections.IList]$Rows,
        [string]$SourceFileName
    )

    $cacheRoot = Get-QueueCacheRoot
    foreach ($oldDirectory in @(Get-ChildItem -LiteralPath $cacheRoot -Directory -ErrorAction SilentlyContinue)) {
        if ($oldDirectory.LastWriteTime -lt (Get-Date).AddDays(-7)) {
            Remove-Item -LiteralPath $oldDirectory.FullName -Recurse -Force -ErrorAction SilentlyContinue
        }
    }

    $token = [guid]::NewGuid().ToString("N")
    $cachePath = Join-Path $cacheRoot $token
    $null = New-Item -ItemType Directory -Path $cachePath -Force

    $allRows = [object[]]$Rows.ToArray()
    $pageIndex = 0
    $offset = 0
    $preferredPageSize = 2500
    $maxPageBytes = 760 * 1024
    $utf8 = New-Object Text.UTF8Encoding($false)

    while ($offset -lt $allRows.Count) {
        $take = [Math]::Min($preferredPageSize, $allRows.Count - $offset)
        $pageJson = ""

        while ($true) {
            $lastIndex = [int]$offset + [int]$take - 1
            if ($take -eq 1) {
                $slice = [object[]]@($allRows[$offset])
            }
            else {
                $slice = [object[]]$allRows[$offset..$lastIndex]
            }

            $pageJson = Convert-ToCompactJson -Value ([ordered]@{
                rows = $slice
            })
            $pageBytes = [Text.Encoding]::UTF8.GetByteCount($pageJson)
            if ($pageBytes -le $maxPageBytes -or $take -le 1) { break }
            $take = [Math]::Max(1, [Math]::Floor($take / 2))
        }

        $pageName = "page_{0:D5}.json" -f $pageIndex
        [IO.File]::WriteAllText(
            (Join-Path $cachePath $pageName),
            $pageJson,
            $utf8
        )
        $offset = [int]$offset + [int]$take
        $pageIndex++
    }

    $meta = [ordered]@{
        token = $token
        pageCount = $pageIndex
        rowCount = $allRows.Count
        sourceFileName = $SourceFileName
        createdAt = (Get-Date).ToString("o")
    }
    [IO.File]::WriteAllText(
        (Join-Path $cachePath "meta.json"),
        (Convert-ToCompactJson -Value $meta),
        $utf8
    )

    return $meta
}

function Read-QueuePage {
    param($Request)

    $token = ""
    if ($Request.PSObject.Properties.Name -contains "queueToken") {
        $token = [string]$Request.queueToken
    }
    if ($token -notmatch "^[a-fA-F0-9]{32}$") {
        throw "Queue token khong hop le."
    }

    $pageIndex = -1
    if ($Request.PSObject.Properties.Name -contains "pageIndex") {
        $pageIndex = [int]$Request.pageIndex
    }
    if ($pageIndex -lt 0 -or $pageIndex -gt 99999) {
        throw "Queue page index khong hop le."
    }

    $cachePath = Join-Path (Get-QueueCacheRoot) $token
    $metaPath = Join-Path $cachePath "meta.json"
    if (-not (Test-Path -LiteralPath $metaPath -PathType Leaf)) {
        throw "Khong tim thay queue data. Hay chay lai Download + Query."
    }

    $meta = Get-Content -LiteralPath $metaPath -Raw | ConvertFrom-Json
    if ($pageIndex -ge [int]$meta.pageCount) {
        throw "Queue page index vuot qua so trang."
    }

    $pageName = "page_{0:D5}.json" -f $pageIndex
    $pagePath = Join-Path $cachePath $pageName
    if (-not (Test-Path -LiteralPath $pagePath -PathType Leaf)) {
        throw "Thieu queue page: $pageName"
    }
    $page = Get-Content -LiteralPath $pagePath -Raw | ConvertFrom-Json

    return [ordered]@{
        ok = $true
        queueToken = $token
        pageIndex = $pageIndex
        pageCount = [int]$meta.pageCount
        rowCount = [int]$meta.rowCount
        sourceFileName = [string]$meta.sourceFileName
        rows = @($page.rows)
    }
}

function Invoke-Build {
    param($Request)

    if (-not ($Request.PSObject.Properties.Name -contains "rawPath") -or -not $Request.rawPath) {
        throw "Thieu duong dan file Excel raw tu Chrome."
    }

    $rawPath = [IO.Path]::GetFullPath([string]$Request.rawPath)
    if ([IO.Path]::GetExtension($rawPath) -ine ".xlsx") {
        throw "File raw khong phai Excel .xlsx: $rawPath"
    }
    if (-not (Test-StableFile -Path $rawPath)) {
        throw "File Excel raw chua tai xong hoac khong ton tai: $rawPath"
    }
    Unblock-File -LiteralPath $rawPath -ErrorAction SilentlyContinue

    $timestamp = ""
    if (($Request.PSObject.Properties.Name -contains "timestamp") -and $Request.timestamp) {
        $timestamp = ([string]$Request.timestamp) -replace "[^0-9_]", ""
    }
    if ($timestamp -notmatch "^\d{8}_\d{6}$") {
        $timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
    }

    $outputRoot = Get-OutputRoot -RawPath $rawPath
    $outputBase = Join-Path $outputRoot "Output"
    $null = New-Item -ItemType Directory -Path $outputBase -Force

    $folderName = "TTS_Pickup_Backlog_Split_$timestamp"
    $outputPath = Join-Path $outputBase $folderName
    $suffix = 2
    while (Test-Path -LiteralPath $outputPath) {
        $outputPath = Join-Path $outputBase ($folderName + "_" + $suffix)
        $suffix++
    }
    $workingPath = Join-Path $outputBase (".working_" + [guid]::NewGuid().ToString("N"))
    $null = New-Item -ItemType Directory -Path $workingPath -Force

    $excel = $null
    $sourceWorkbook = $null
    $sourceSheet = $null
    $usedRange = $null
    $fileCount = 0
    $rowCount = 0
    $queueRows = New-Object Collections.ArrayList

    try {
        $excel = New-Object -ComObject Excel.Application
        $excel.Visible = $false
        $excel.DisplayAlerts = $false
        $excel.AskToUpdateLinks = $false
        $excel.EnableEvents = $false
        try { $excel.AutomationSecurity = 3 } catch {}

        $sourceWorkbook = $excel.Workbooks.Open($rawPath, 0, $true)
        try {
            $sourceSheet = $sourceWorkbook.Worksheets.Item("Export")
        }
        catch {
            $sourceSheet = $sourceWorkbook.Worksheets.Item(1)
        }

        $usedRange = $sourceSheet.UsedRange
        $sourceRows = [int]$usedRange.Rows.Count
        $sourceColumns = [int]$usedRange.Columns.Count
        if ($sourceRows -lt 2 -or $sourceColumns -lt 2) {
            throw "Sheet Export khong co du lieu."
        }

        $values = $usedRange.Value2
        if (-not ($values -is [Array]) -or $values.Rank -ne 2) {
            throw "Khong doc duoc bang du lieu 2 chieu trong sheet Export."
        }
        $rowBase = $values.GetLowerBound(0)
        $columnBase = $values.GetLowerBound(1)

        $bestHeaderRow = 0
        $bestScore = -1
        $bestColumns = $null
        $scanRows = [Math]::Min(25, $sourceRows)

        for ($row = 1; $row -le $scanRows; $row++) {
            $headers = @()
            for ($column = 1; $column -le $sourceColumns; $column++) {
                $headerValue = $values.GetValue(
                    $rowBase + $row - 1,
                    $columnBase + $column - 1
                )
                $headers += (Convert-CellToText $headerValue)
            }
            $resolved = Resolve-Columns -Headers $headers
            $score = 0
            foreach ($field in @("PlatformOrderId", "DeliveryPlatform", "ChannelName", "WarehouseBranch", "OrderDate", "SlaDate", "TrackingNo")) {
                if ($resolved[$field]) { $score++ }
            }
            if (-not $resolved["PlatformOrderId"] -and $resolved["OrderNo"]) { $score++ }
            if ($score -gt $bestScore) {
                $bestScore = $score
                $bestHeaderRow = $row
                $bestColumns = $resolved
            }
        }

        $missing = New-Object "System.Collections.Generic.List[string]"
        if (-not $bestColumns["PlatformOrderId"] -and -not $bestColumns["OrderNo"]) {
            $missing.Add("Platform Order ID hoac Order No")
        }
        foreach ($field in @("DeliveryPlatform", "ChannelName", "WarehouseBranch", "OrderDate", "SlaDate", "TrackingNo")) {
            if (-not $bestColumns[$field]) { $missing.Add($field) }
        }
        if ($missing.Count -gt 0) {
            throw ("Thieu cot bat buoc: " + ($missing -join ", "))
        }

        # Preserve every source column for Google Sheets Ticket Master.
        # Duplicate and blank headers are made deterministic, while each
        # raise attachment remains limited to the required 6 columns.
        $sourceHeaderNames = New-Object Collections.ArrayList
        $headerNameCounts = @{}
        for ($column = 1; $column -le $sourceColumns; $column++) {
            $rawHeader = $values.GetValue(
                $rowBase + $bestHeaderRow - 1,
                $columnBase + $column - 1
            )
            $headerName = Convert-CellToText $rawHeader
            if (-not $headerName) { $headerName = "Column $column" }
            $headerKey = $headerName.ToLowerInvariant()
            if ($headerNameCounts.ContainsKey($headerKey)) {
                $headerNameCounts[$headerKey] = [int]$headerNameCounts[$headerKey] + 1
                $headerName = $headerName + "_" + $headerNameCounts[$headerKey]
            }
            else {
                $headerNameCounts[$headerKey] = 1
            }
            $null = $sourceHeaderNames.Add($headerName)
        }

        $groups = @{}
        for ($row = $bestHeaderRow + 1; $row -le $sourceRows; $row++) {
            $getValue = {
                param($ColumnIndex)
                if (-not $ColumnIndex) { return $null }
                return $values.GetValue(
                    $rowBase + $row - 1,
                    $columnBase + [int]$ColumnIndex - 1
                )
            }

            $platformOrderId = ""
            $orderNo = ""
            if ($bestColumns["PlatformOrderId"]) {
                $rawPlatformOrderId = & $getValue $bestColumns["PlatformOrderId"]
                $platformOrderId = Convert-CellToText $rawPlatformOrderId
            }
            if ($bestColumns["OrderNo"]) {
                $rawOrderNo = & $getValue $bestColumns["OrderNo"]
                $orderNo = Convert-CellToText $rawOrderNo
            }
            if (-not $platformOrderId -and $orderNo) {
                $platformOrderId = Derive-PlatformOrderId -OrderNo $orderNo
            }

            $rawDeliveryPlatform = & $getValue $bestColumns["DeliveryPlatform"]
            $rawChannelName = & $getValue $bestColumns["ChannelName"]
            $rawWarehouseBranch = & $getValue $bestColumns["WarehouseBranch"]
            $rawTrackingNo = & $getValue $bestColumns["TrackingNo"]
            $rawOrderStatus = & $getValue $bestColumns["OrderStatus"]
            $rawCnnc = & $getValue $bestColumns["Cnnc"]
            $deliveryPlatform = Convert-CellToText $rawDeliveryPlatform
            $channelName = Convert-CellToText $rawChannelName
            $warehouseBranch = Convert-CellToText $rawWarehouseBranch
            $trackingNo = Convert-CellToText $rawTrackingNo
            $orderStatus = Convert-CellToText $rawOrderStatus
            $explicitCnnc = Convert-CellToText $rawCnnc
            $cnnc = Derive-CnncCode `
                -ExplicitCode $explicitCnnc `
                -OrderNo $orderNo `
                -PlatformOrderId $platformOrderId
            if (
                -not $platformOrderId -or
                -not $deliveryPlatform -or
                -not $channelName -or
                -not $warehouseBranch
            ) {
                continue
            }

            $rawOrderDate = & $getValue $bestColumns["OrderDate"]
            $rawSlaDate = & $getValue $bestColumns["SlaDate"]
            $orderDate = Convert-ToExcelDateTimeValue $rawOrderDate
            $slaDate = Convert-ToExcelDateTimeValue $rawSlaDate
            $queueOrderDate = Convert-ToQueueDateTimeText $rawOrderDate
            $queueSlaDate = Convert-ToQueueDateTimeText $rawSlaDate

            # Windows PowerShell 5.1 can surface a command result as Object[]
            # when it is used directly on the left side of +. Build the key
            # from an explicit string array so a split value can never invoke
            # Object[].op_Addition.
            $groupKeyParts = [string[]]@(
                [string](Normalize-Text $deliveryPlatform)
                [string](Normalize-Text $channelName)
                [string](Normalize-Text $warehouseBranch)
            )
            $groupKey = [string]::Join("|||", $groupKeyParts)

            if (-not $groups.ContainsKey($groupKey)) {
                $groups[$groupKey] = [pscustomobject]@{
                    DeliveryPlatform = $deliveryPlatform
                    ChannelName = $channelName
                    WarehouseBranch = $warehouseBranch
                    Rows = (New-Object Collections.ArrayList)
                }
            }

            $record = [object[]]@(
                $platformOrderId,
                $deliveryPlatform,
                $channelName,
                $orderDate,
                $slaDate,
                $trackingNo
            )
            $null = $groups[$groupKey].Rows.Add($record)

            $originalRow = [ordered]@{}
            for ($column = 1; $column -le $sourceColumns; $column++) {
                $originalValue = $values.GetValue(
                    $rowBase + $row - 1,
                    $columnBase + $column - 1
                )
                $originalRow[[string]$sourceHeaderNames[$column - 1]] = Convert-CellToText $originalValue
            }

            $null = $queueRows.Add([ordered]@{
                _row = [int]$row
                orderId = [string]$platformOrderId
                orderNo = [string]$orderNo
                cnnc = [string]$cnnc
                channel = [string]$channelName
                carrier = [string]$deliveryPlatform
                platform = "TIKTOK"
                status = [string]$orderStatus
                orderDate = [string]$queueOrderDate
                slaAt = [string]$queueSlaDate
                trackingId = [string]$trackingNo
                warehouse = [string]$warehouseBranch
                sourceFile = [IO.Path]::GetFileName($rawPath)
                _original = $originalRow
            })
            $rowCount++
        }

        if ($groups.Count -eq 0) {
            throw "Khong co dong nao de split sau khi query 6 cot."
        }

        $headers = [object[]]@(
            "Platform Order ID",
            "Delivery Platform",
            "Channel Name",
            "Order Date",
            "SLA Date",
            "Tracking No"
        )
        $usedNames = @{}

        foreach ($groupKey in @($groups.Keys | Sort-Object)) {
            $group = $groups[$groupKey]
            $baseNameParts = [string[]]@(
                [string](Get-SafeFilePart $group.DeliveryPlatform)
                [string](Get-SafeFilePart $group.ChannelName)
                [string](Get-SafeFilePart $group.WarehouseBranch)
            )
            $baseName = [string]::Join("__", $baseNameParts)
            $fileName = "{0}.xlsx" -f $baseName
            $nameSuffix = 2
            while ($usedNames.ContainsKey($fileName.ToLowerInvariant())) {
                $fileName = "{0}_{1}.xlsx" -f $baseName, $nameSuffix
                $nameSuffix++
            }
            $usedNames[$fileName.ToLowerInvariant()] = $true
            $filePath = Join-Path $workingPath $fileName

            $outputWorkbook = $null
            $outputSheet = $null
            try {
                $outputWorkbook = $excel.Workbooks.Add()
                while ($outputWorkbook.Worksheets.Count -gt 1) {
                    $outputWorkbook.Worksheets.Item($outputWorkbook.Worksheets.Count).Delete()
                }
                $outputSheet = $outputWorkbook.Worksheets.Item(1)
                $outputSheet.Name = "Pickup Orders"

                $groupRows = $group.Rows
                $dimensions = [int[]]@(([int]$groupRows.Count + 1), 6)
                $matrix = [Array]::CreateInstance([object], $dimensions)
                for ($column = 0; $column -lt 6; $column++) {
                    $matrix.SetValue($headers[$column], 0, [int]$column)
                }
                for ($index = 0; $index -lt $groupRows.Count; $index++) {
                    $record = [object[]]$groupRows[$index]
                    $matrixRowIndex = [int]$index + 1
                    for ($column = 0; $column -lt 6; $column++) {
                        $matrix.SetValue(
                            $record[$column],
                            $matrixRowIndex,
                            [int]$column
                        )
                    }
                }

                $targetLastRow = [int]$groupRows.Count + 1
                $target = $outputSheet.Range(
                    $outputSheet.Cells.Item(1, 1),
                    $outputSheet.Cells.Item($targetLastRow, 6)
                )
                $outputSheet.Columns.Item(1).NumberFormat = "@"
                $outputSheet.Columns.Item(2).NumberFormat = "@"
                $outputSheet.Columns.Item(3).NumberFormat = "@"
                $outputSheet.Columns.Item(4).NumberFormat = "dd/mm/yyyy hh:mm"
                $outputSheet.Columns.Item(5).NumberFormat = "dd/mm/yyyy hh:mm"
                $outputSheet.Columns.Item(6).NumberFormat = "@"
                $target.Value2 = $matrix

                $headerRange = $outputSheet.Range("A1", "F1")
                $headerRange.Font.Bold = $true
                $headerRange.Font.Color = 16777215
                $headerRange.Interior.Color = 192
                $headerRange.HorizontalAlignment = -4108
                $null = $target.AutoFilter()
                $null = $outputSheet.Columns.AutoFit()

                foreach ($column in 1..6) {
                    if ($outputSheet.Columns.Item($column).ColumnWidth -gt 42) {
                        $outputSheet.Columns.Item($column).ColumnWidth = 42
                    }
                }

                # Freeze panes is only cosmetic. Excel COM can return no active
                # window (or reject FreezePanes) while the application is hidden.
                # Never let that optional formatting step abort the whole query.
                $activeWindow = $null
                try {
                    $outputSheet.Activate()
                    $activeWindow = $excel.ActiveWindow
                    if ($null -ne $activeWindow) {
                        $activeWindow.FreezePanes = $false
                        $activeWindow.SplitColumn = 0
                        $activeWindow.SplitRow = 1
                        $activeWindow.FreezePanes = $true
                    }
                }
                catch {
                    Write-Verbose ("Skipped FreezePanes for '{0}': {1}" -f $fileName, $_.Exception.Message)
                }
                finally {
                    if ($null -ne $activeWindow) {
                        try { $null = [Runtime.InteropServices.Marshal]::ReleaseComObject($activeWindow) } catch {}
                        $activeWindow = $null
                    }
                }
                $null = $outputWorkbook.SaveAs($filePath, 51)
                $null = $outputWorkbook.Close($false)
                $fileCount++
            }
            finally {
                if ($outputSheet) {
                    $null = [Runtime.InteropServices.Marshal]::ReleaseComObject($outputSheet)
                }
                if ($outputWorkbook) {
                    try { $null = $outputWorkbook.Close($false) } catch {}
                    $null = [Runtime.InteropServices.Marshal]::ReleaseComObject($outputWorkbook)
                }
            }
        }

        $null = $sourceWorkbook.Close($false)
        $null = [Runtime.InteropServices.Marshal]::ReleaseComObject($usedRange)
        $usedRange = $null
        $null = [Runtime.InteropServices.Marshal]::ReleaseComObject($sourceSheet)
        $sourceSheet = $null
        $null = [Runtime.InteropServices.Marshal]::ReleaseComObject($sourceWorkbook)
        $sourceWorkbook = $null
        $null = $excel.Quit()
        $null = [Runtime.InteropServices.Marshal]::ReleaseComObject($excel)
        $excel = $null

        Move-Item -LiteralPath $workingPath -Destination $outputPath

        # Send the whole queue back with the build response in one compressed
        # payload. The old implementation started PowerShell once per 500 rows,
        # which made 13k rows take roughly 28 separate native-host calls.
        $queueArray = [object[]]$queueRows.ToArray()
        $queueJson = Convert-ToCompactJson -Value ([ordered]@{
            rows = $queueArray
        })
        $queuePayload = Convert-ToGzipBase64 -Text $queueJson
        $queuePayloadEncoding = "gzip-base64"
        $queueToken = ""
        $queuePageCount = 0

        # Chrome limits one native-host response to 1 MB. Real queue data
        # compresses far below this threshold; keep the paged cache only as a
        # safe fallback for unusually large text fields.
        if ($queuePayload.Length -gt (800 * 1024)) {
            $queueCache = Write-QueueCache `
                -Rows $queueRows `
                -SourceFileName ([IO.Path]::GetFileName($rawPath))
            $queuePayload = ""
            $queuePayloadEncoding = ""
            $queueToken = [string]$queueCache.token
            $queuePageCount = [int]$queueCache.pageCount
        }

        $result = @{
            ok = $true
            outputPath = $outputPath
            fileCount = $fileCount
            rowCount = $rowCount
            columns = @(
                "Platform Order ID",
                "Delivery Platform",
                "Channel Name",
                "Order Date",
                "SLA Date",
                "Tracking No"
            )
            splitBy = @("Delivery Platform", "Channel Name", "Warehouse Branch")
            queueToken = $queueToken
            queuePageCount = $queuePageCount
            queueRowCount = [int]$queueArray.Count
            queueSourceFileName = [IO.Path]::GetFileName($rawPath)
            queuePayloadEncoding = $queuePayloadEncoding
            queuePayload = $queuePayload
            slaDateFiltered = $true
            slaDateFilter = "year_to_date"
            completedAt = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
        }

        $lastResult = @{}
        foreach ($key in $result.Keys) {
            if ($key -ne "queuePayload") {
                $lastResult[$key] = $result[$key]
            }
        }
        [IO.File]::WriteAllText(
            (Join-Path $PSScriptRoot "last-result.json"),
            (Convert-ToCompactJson -Value $lastResult),
            (New-Object Text.UTF8Encoding($false))
        )

        $openAfterBuild = $true
        if ($Request.PSObject.Properties.Name -contains "openAfterBuild") {
            $openAfterBuild = ($Request.openAfterBuild -ne $false)
        }
        if ($openAfterBuild) { $null = Start-Process -FilePath $outputPath }
        return $result
    }
    finally {
        if ($usedRange) {
            $null = [Runtime.InteropServices.Marshal]::ReleaseComObject($usedRange)
        }
        if ($sourceSheet) {
            $null = [Runtime.InteropServices.Marshal]::ReleaseComObject($sourceSheet)
        }
        if ($sourceWorkbook) {
            try { $null = $sourceWorkbook.Close($false) } catch {}
            $null = [Runtime.InteropServices.Marshal]::ReleaseComObject($sourceWorkbook)
        }
        if ($excel) {
            try { $null = $excel.Quit() } catch {}
            $null = [Runtime.InteropServices.Marshal]::ReleaseComObject($excel)
        }
        if (Test-Path -LiteralPath $workingPath -PathType Container) {
            Remove-Item -LiteralPath $workingPath -Recurse -Force -ErrorAction SilentlyContinue
        }
        [GC]::Collect()
        [GC]::WaitForPendingFinalizers()
    }
}

try {
    $request = Get-Request
    $action = ""
    if ($request.PSObject.Properties.Name -contains "action") {
        $action = [string]$request.action
    }

    switch ($action) {
        "ping" {
            $result = @{
                ok = $true
                host = "com.onpoint.tts_pickup_split"
                hostVersion = "0.10.10"
                readRawChunkSupported = $true
                excelInstalled = [bool](Get-ItemProperty "Registry::HKEY_CLASSES_ROOT\Excel.Application\CLSID" -ErrorAction SilentlyContinue)
            }
        }
        "openOutput" {
            $result = Open-OutputFolder
        }
        "build" {
            $result = Invoke-Build -Request $request
        }
        "readQueuePage" {
            $result = Read-QueuePage -Request $request
        }
        "readRawChunk" {
            # Compatibility path for an older compiled host. New hosts handle
            # this action directly in C#, while old hosts forward it here.
            $result = Read-RawChunk -Request $request
        }
        default {
            throw "Unsupported action: $action"
        }
    }

    Write-Output (Convert-ToCompactJson -Value $result)
    exit 0
}
catch {
    $errorMessage = [string]$_.Exception.Message
    $lineNumber = [int]$_.InvocationInfo.ScriptLineNumber
    if ($lineNumber -gt 0) {
        $errorMessage = "Query Excel line {0}: {1}" -f $lineNumber, $errorMessage
    }
    Write-Output (Convert-ToCompactJson -Value @{
        ok = $false
        error = $errorMessage
    })
    exit 1
}
