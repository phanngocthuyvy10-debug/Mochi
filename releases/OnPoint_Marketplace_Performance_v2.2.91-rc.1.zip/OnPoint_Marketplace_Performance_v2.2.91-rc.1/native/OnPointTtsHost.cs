using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

internal static class OnPointTtsHost
{
    private const int MaxMessageBytes = 1024 * 1024;
    private const int PowerShellTimeoutMs = 20 * 60 * 1000;

    private static byte[] ReadExact(Stream stream, int count)
    {
        var buffer = new byte[count];
        var offset = 0;
        while (offset < count)
        {
            var read = stream.Read(buffer, offset, count - offset);
            if (read <= 0)
            {
                return offset == 0 ? null : buffer.Take(offset).ToArray();
            }
            offset += read;
        }
        return buffer;
    }

    private static string JsonString(string value)
    {
        if (value == null) return "";
        return value
            .Replace("\\", "\\\\")
            .Replace("\"", "\\\"")
            .Replace("\r", "\\r")
            .Replace("\n", "\\n")
            .Replace("\t", "\\t");
    }

    private static void WriteMessage(string json)
    {
        var output = Console.OpenStandardOutput();
        var payload = Encoding.UTF8.GetBytes(json);
        var length = BitConverter.GetBytes(payload.Length);
        output.Write(length, 0, length.Length);
        output.Write(payload, 0, payload.Length);
        output.Flush();
    }

    private static string RunPowerShell(string requestJson)
    {
        var scriptPath = Path.Combine(
            AppDomain.CurrentDomain.BaseDirectory,
            "Build-TTS-Split.ps1"
        );
        if (!File.Exists(scriptPath))
        {
            return "{\"ok\":false,\"error\":\"Missing Build-TTS-Split.ps1 in the installed helper folder.\"}";
        }

        var requestBase64 = Convert.ToBase64String(Encoding.UTF8.GetBytes(requestJson));
        var startInfo = new ProcessStartInfo
        {
            FileName = "powershell.exe",
            Arguments =
                "-NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File \""
                + scriptPath.Replace("\"", "\"\"")
                + "\" -RequestBase64 \""
                + requestBase64
                + "\"",
            UseShellExecute = false,
            CreateNoWindow = true,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            StandardOutputEncoding = Encoding.UTF8,
            StandardErrorEncoding = Encoding.UTF8
        };

        using (var process = new Process { StartInfo = startInfo })
        {
            process.Start();
            if (!process.WaitForExit(PowerShellTimeoutMs))
            {
                try { process.Kill(); } catch { }
                return "{\"ok\":false,\"error\":\"Excel query exceeded the 20-minute safety timeout.\"}";
            }

            var standardOutput = process.StandardOutput.ReadToEnd();
            var standardError = process.StandardError.ReadToEnd();
            var resultLine = standardOutput
                .Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries)
                .LastOrDefault(line => line.TrimStart().StartsWith("{"));

            if (!string.IsNullOrWhiteSpace(resultLine))
            {
                return resultLine.Trim();
            }

            var error = string.IsNullOrWhiteSpace(standardError)
                ? "The Excel helper returned no result."
                : standardError.Trim();
            return "{\"ok\":false,\"error\":\"" + JsonString(error) + "\"}";
        }
    }

    private static string ReadJsonString(string json, string name)
    {
        var match = Regex.Match(
            json ?? "",
            "\"" + Regex.Escape(name) + "\"\\s*:\\s*\"((?:\\\\.|[^\"])*)\"",
            RegexOptions.IgnoreCase
        );
        if (!match.Success) return "";
        return Regex.Unescape(match.Groups[1].Value);
    }

    private static long ReadJsonLong(string json, string name, long fallback)
    {
        var match = Regex.Match(
            json ?? "",
            "\"" + Regex.Escape(name) + "\"\\s*:\\s*(-?\\d+)",
            RegexOptions.IgnoreCase
        );
        long value;
        return match.Success && long.TryParse(match.Groups[1].Value, out value)
            ? value
            : fallback;
    }

    private static string FindRecentRawFile(string requestJson)
    {
        var sinceMs = ReadJsonLong(requestJson, "since", 0);
        var sinceUtc = sinceMs > 0
            ? new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc).AddMilliseconds(sinceMs - 5000)
            : DateTime.UtcNow.AddMinutes(-3);
        var downloadRoot = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
            "Downloads"
        );
        if (!Directory.Exists(downloadRoot))
        {
            return "{\"ok\":false,\"error\":\"Windows Downloads folder was not found.\"}";
        }

        FileInfo best = null;
        var candidates = Directory
            .EnumerateFiles(downloadRoot, "*.xlsx", SearchOption.AllDirectories)
            .Select(path =>
            {
                try { return new FileInfo(path); }
                catch { return null; }
            })
            .Where(file =>
                file != null
                && file.LastWriteTimeUtc >= sinceUtc
                && !file.Name.StartsWith("~$", StringComparison.OrdinalIgnoreCase)
                && (
                    file.Name.IndexOf("Orders Detailed View", StringComparison.OrdinalIgnoreCase) >= 0
                    || file.Name.IndexOf("Operations FBO Backlog Dashboard", StringComparison.OrdinalIgnoreCase) >= 0
                    || file.Name.IndexOf("TTS_Pickup_Backlog_Raw", StringComparison.OrdinalIgnoreCase) >= 0
                    || file.DirectoryName.IndexOf(
                        Path.Combine("OnPoint_TTS_Pickup_Ticket", "Raw"),
                        StringComparison.OrdinalIgnoreCase
                    ) >= 0
                )
            )
            .OrderByDescending(file =>
                file.Name.IndexOf("Orders Detailed View", StringComparison.OrdinalIgnoreCase) >= 0 ? 2 :
                file.Name.IndexOf("TTS_Pickup_Backlog_Raw", StringComparison.OrdinalIgnoreCase) >= 0 ? 1 : 0
            )
            .ThenByDescending(file => file.LastWriteTimeUtc);

        foreach (var candidate in candidates)
        {
            try
            {
                using (var stream = new FileStream(
                    candidate.FullName,
                    FileMode.Open,
                    FileAccess.Read,
                    FileShare.Read
                ))
                {
                    if (stream.Length > 0)
                    {
                        best = candidate;
                        break;
                    }
                }
            }
            catch
            {
                // Chrome is still writing this candidate; retry on the next poll.
            }
        }

        if (best == null)
        {
            return "{\"ok\":false,\"found\":false}";
        }
        return "{\"ok\":true,\"found\":true,\"path\":\""
            + JsonString(best.FullName)
            + "\",\"fileName\":\""
            + JsonString(best.Name)
            + "\"}";
    }

    private static string ReadRawChunk(string requestJson)
    {
        var rawPath = Path.GetFullPath(ReadJsonString(requestJson, "rawPath"));
        if (!File.Exists(rawPath))
        {
            return "{\"ok\":false,\"error\":\"Downloaded Excel file was not found.\"}";
        }

        var offset = Math.Max(0, ReadJsonLong(requestJson, "offset", 0));
        var requested = ReadJsonLong(requestJson, "length", 512 * 1024);
        var chunkLength = (int)Math.Max(1, Math.Min(600 * 1024, requested));
        var fileInfo = new FileInfo(rawPath);
        if (offset > fileInfo.Length) offset = fileInfo.Length;

        byte[] bytes;
        using (var stream = new FileStream(
            rawPath,
            FileMode.Open,
            FileAccess.Read,
            FileShare.ReadWrite | FileShare.Delete
        ))
        {
            stream.Position = offset;
            var wanted = (int)Math.Min(chunkLength, fileInfo.Length - offset);
            bytes = ReadExact(stream, wanted) ?? new byte[0];
        }

        var nextOffset = offset + bytes.Length;
        return "{\"ok\":true,\"fileSize\":" + fileInfo.Length
            + ",\"offset\":" + offset
            + ",\"nextOffset\":" + nextOffset
            + ",\"eof\":" + (nextOffset >= fileInfo.Length ? "true" : "false")
            + ",\"data\":\"" + Convert.ToBase64String(bytes) + "\"}";
    }

    public static int Main()
    {
        try
        {
            var input = Console.OpenStandardInput();
            var lengthBytes = ReadExact(input, 4);
            if (lengthBytes == null || lengthBytes.Length != 4) return 0;

            var length = BitConverter.ToInt32(lengthBytes, 0);
            if (length <= 0 || length > MaxMessageBytes)
            {
                WriteMessage("{\"ok\":false,\"error\":\"Invalid native message length.\"}");
                return 1;
            }

            var requestBytes = ReadExact(input, length);
            if (requestBytes == null || requestBytes.Length != length)
            {
                WriteMessage("{\"ok\":false,\"error\":\"Incomplete native message.\"}");
                return 1;
            }

            var requestJson = Encoding.UTF8.GetString(requestBytes);
            var action = ReadJsonString(requestJson, "action");
            WriteMessage(
                string.Equals(action, "readRawChunk", StringComparison.OrdinalIgnoreCase)
                    ? ReadRawChunk(requestJson)
                    : string.Equals(action, "findRecentRawFile", StringComparison.OrdinalIgnoreCase)
                        ? FindRecentRawFile(requestJson)
                        : RunPowerShell(requestJson)
            );
            return 0;
        }
        catch (Exception exception)
        {
            WriteMessage(
                "{\"ok\":false,\"error\":\""
                + JsonString(exception.Message)
                + "\"}"
            );
            return 1;
        }
    }
}
