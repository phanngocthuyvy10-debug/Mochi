$ErrorActionPreference = "Stop"

$hostName = "com.onpoint.tts_pickup_split"
$registryPath = "HKCU:\Software\Google\Chrome\NativeMessagingHosts\$hostName"
$installRoot = Join-Path $env:LOCALAPPDATA "OnPoint\TTSPickupTicketAssistant"

if (Test-Path -LiteralPath $registryPath) {
    Remove-Item -LiteralPath $registryPath -Recurse -Force
}
if (Test-Path -LiteralPath $installRoot -PathType Container) {
    Remove-Item -LiteralPath $installRoot -Recurse -Force
}

Write-Host "Da go helper Download + Query cua OnPoint TTS Pickup Ticket Assistant." -ForegroundColor Green
