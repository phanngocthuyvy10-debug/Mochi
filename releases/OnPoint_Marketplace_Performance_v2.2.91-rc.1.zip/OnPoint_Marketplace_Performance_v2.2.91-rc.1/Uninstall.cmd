@echo off
setlocal
echo This removes the local Download + Query helper. It does not delete raw or output Excel files.
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0native\Uninstall-NativeHost.ps1"
pause
