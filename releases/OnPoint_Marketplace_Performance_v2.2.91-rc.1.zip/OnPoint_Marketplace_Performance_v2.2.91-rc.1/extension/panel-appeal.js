/* Panel v2.2.0 — tab "Kháng nghị" (Ticket Assistant nhúng nguyên bản) + cầu nối đơn bị ảnh hưởng → Kháng nghị.
   1) Đưa đơn lỗi của store vừa lấy vào phiên "Kháng nghị — Đã bàn giao, ĐVVC chưa cập nhật" (mỗi đơn 1 form, Auto raise trong tab Kháng nghị).
   2) Shopee FHR / cảnh báo gỡ nhãn Mall: lấy tối đa 20 đơn ở trang "tỷ lệ giao hàng nhanh tính lại" và soạn sẵn tin để dán vào chat CSKH. */
(() => {
  const $a = id => document.getElementById(id);
  const escA = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const FHR_URL = 'https://shopee.vn/m/tylegiaohangnhanhtinhlai';
  const KPI_NAME = { FHR: 'Giao hàng nhanh (FHR)', LSR: 'Giao hàng trễ (LSR)', NFR: 'Đơn không thành công (NFR)', FDR: 'Gửi hàng nhanh (FDR)', LDR: 'Gửi hàng muộn (LDR)', NDDR: 'Giao nhanh 24h', SFCR: 'Hủy do lỗi người bán', INSTANT_LDR: 'Gửi muộn Hỏa tốc', SAME_DAY_LDR: 'Gửi muộn Trong ngày' };
  let data = null, picked = new Set(), loadedRun = '', lastSig = '';
  const pct = v => v == null ? '?' : (v * 100).toLocaleString('vi-VN', { maximumFractionDigits: 2 }) + '%';
  const dmyA = s => /^\d{4}-\d{2}-\d{2}/.test(String(s || '')) ? `${s.slice(8, 10)}/${s.slice(5, 7)}/${s.slice(0, 4)}` : String(s || '');
  const isShopee = run => String(run?.platform || '').toUpperCase() === 'SHOPEE';
  const orderNo = (o, run) => String((isShopee(run) ? (o.order_sn || o.order_id) : (o.order_id || o.platform_order_id)) || '').trim().toUpperCase();
  const cancelled = o => o.metric === 'NFR' || /cancel|hủy|huỷ/i.test(`${o.status || ''} ${o.order_status || ''}`);
  // v2.2.9 — chỉ số khiếu nại bằng file danh sách (panel-claim.js): Shopee FHR/LSR, TikTok FDR/LDR → không đưa vào form từng đơn.
  const claimSet = run => isShopee(run) ? ['FHR', 'LSR'] : ['FDR', 'LDR'];

  async function load() {
    try { data = await chrome.runtime.sendMessage({ type: 'EXPORT' }); if (data?.error) data = null; } catch (_) { data = null; }
    const runId = data?.run?.id || '';
    if (runId !== loadedRun) { loadedRun = runId; picked = new Set(groups().map(g => g.code).filter(c => !claimSet(data?.run).includes(c))); }
  }
  function groups() {
    const run = data?.run; if (!run) return [];
    const by = new Map();
    for (const o of data.orders || []) { const k = o.metric; if (!k) continue; const no = orderNo(o, run); if (!no) continue; const g = by.get(k) || { code: k, orders: new Map() }; g.orders.set(no, o); by.set(k, g); }
    return [...by.values()].map(g => ({ ...g, m: (run.metrics || []).find(m => m.code === g.code) })).sort((a, b) => b.orders.size - a.orders.size);
  }
  async function renderAppeal(force = 0) {
    const box = $a('appealBox'); if (!box) return;
    await load();
    const run = data?.run, gs = groups(), { fhrRecalc } = await chrome.storage.local.get('fhrRecalc');
    const recalc = fhrRecalc && Date.now() - Date.parse(fhrRecalc.at || 0) < 6 * 3600e3 ? fhrRecalc : null;
    // Re-draw only when the data changed, so an open chat draft / checkbox choice is not wiped.
    const sig = JSON.stringify([run?.id, gs.map(g => [g.code, g.orders.size]), [...picked], recalc?.orders?.length, recalc?.at, force]);
    if (sig === lastSig) return; lastSig = sig;
    const title = '<div class="ap-title">Kháng nghị từng đơn <span>Đã bàn giao, ĐVVC chưa cập nhật · cần biên bản</span></div>';
    if (!run) { box.innerHTML = `${title}<p class="cl-empty">Lấy dữ liệu một store trước. Đơn bị ảnh hưởng của các KPI không đạt sẽ hiện ở đây.</p>`; return; }
    const batch = gs.filter(g => claimSet(run).includes(g.code));
    const individual = gs.filter(g => !batch.includes(g));
    const total = new Set(individual.filter(g => picked.has(g.code)).flatMap(g => [...g.orders.keys()])).size;
    const fhr = (run.metrics || []).find(m => m.code === 'FHR');
    box.innerHTML = `${title}<div class="ap-store"><strong>${escA(run.shopName || run.channel_name || '')}</strong><span>${escA(isShopee(run) ? 'Shopee' : 'TikTok Shop')} · Shop ID ${escA(run.shopId || '')}</span></div>
      ${individual.length ? `<div class="appeal-kpis">${individual.map(g => `<label class="check"><input type="checkbox" data-appeal-kpi="${escA(g.code)}" ${picked.has(g.code) ? 'checked' : ''}> ${escA(KPI_NAME[g.code] || g.code)} · <b>${g.orders.size}</b> đơn${g.m?.value != null ? ` · ${escA(g.m.unit === 'rate' || g.m.value <= 1 ? pct(g.m.value) : g.m.value)}` : ''}</label>`).join('')}</div>
        <button id="appealPush" class="primary" ${total ? '' : 'disabled'}>Đưa ${total} đơn vào Kháng nghị</button>
        <p class="hint">Chỉ dùng khi đã có bằng chứng bàn giao thực tế. Tool điền sẵn mã đơn, vận đơn, ĐVVC; mỗi đơn 1 form.</p>`
        : `<p class="cl-empty">${batch.length ? `Đơn lỗi ${batch.map(g => g.code).join('/')} gửi bằng khiếu nại file danh sách ở trên.` : 'Store này không có đơn lỗi ở KPI không đạt.'}</p>`}
      ${isShopee(run) ? `<details class="ap-sub" open><summary>Shopee · chat CSKH giữ nhãn Mall (FHR tính lại)</summary>
        <p class="hint">Trang "tỷ lệ giao hàng nhanh tính lại" hiển thị tối đa 20 đơn. Kết quả do Shopee xét duyệt. FHR mới nhất: <b>${escA(pct(fhr?.value))}</b>${fhr?.period_start ? ` (${escA(dmyA(fhr.period_start))} – ${escA(dmyA(fhr.period_end))})` : ''}.</p>
        <button id="appealOpenFhr">1 · Mở trang đơn FHR tính lại</button>
        <p class="hint">${recalc ? `Đã đọc <b>${recalc.orders.length}</b> đơn từ trang tính lại lúc ${escA(new Date(recalc.at).toLocaleTimeString('vi-VN'))}${recalc.shopId && recalc.shopId !== String(run.shopId) ? ` · <span class="fail">Shop ID trang (${escA(recalc.shopId)}) khác store đang lấy</span>` : ''}.` : 'Chưa đọc trang tính lại: tool dùng 20 đơn FHR gần nhất. Mở trang ở bước 1 (login tài khoản shop) và kéo xuống danh sách đơn để tool tự đọc.'}</p>
        <button id="appealChat">2 · Soạn tin chat CSKH &amp; copy</button><textarea id="appealChatText" rows="9" hidden></textarea>
        </details>` : ''}`;
    box.querySelectorAll('[data-appeal-kpi]').forEach(c => c.onchange = () => { c.checked ? picked.add(c.dataset.appealKpi) : picked.delete(c.dataset.appealKpi); renderAppeal().catch(() => {}); });
    if ($a('appealPush')) $a('appealPush').onclick = () => push(individual.filter(g => picked.has(g.code)).flatMap(g => [...g.orders.values()])).catch(e => message(e.message, true));
    if ($a('appealOpenFhr')) $a('appealOpenFhr').onclick = () => chrome.tabs.create({ url: FHR_URL, active: true });
    if ($a('appealChat')) $a('appealChat').onclick = async () => { const t = chatText(run, fhr, recalc, gs); const ta = $a('appealChatText'); ta.hidden = false; ta.value = t; try { await navigator.clipboard.writeText(t); message('Đã copy tin nhắn. Dán vào chat CSKH Shopee của shop.'); } catch (_) { ta.select(); message('Chọn sẵn nội dung — bấm Ctrl+C để copy.'); } };
  }
  function fhrList(run, recalc, gs) {
    if (recalc?.orders?.length) return recalc.orders.slice(0, 20);
    const g = gs.find(x => x.code === 'FHR'); if (!g) return [];
    return [...g.orders.entries()].filter(([, o]) => !globalThis.OPClaim?.tooOld(o)).sort((a, b) => String(b[1].period_end || '').localeCompare(String(a[1].period_end || '')) || String(b[1].created_at || '').localeCompare(String(a[1].created_at || ''))).slice(0, 20).map(x => x[0]);
  }
  function chatText(run, fhr, recalc, gs) {
    const list = fhrList(run, recalc, gs), g = gs.find(x => x.code === 'FHR');
    const carriers = [...new Set(list.map(no => g?.orders.get(no)?.carrier).filter(Boolean))].join(', ');
    return [`Shop: ${run.shopName || ''} (Shop ID ${run.shopId || ''})`,
      `Nội dung: Khiếu nại Tỷ lệ giao hàng nhanh${fhr?.period_start ? ` kỳ ${dmyA(fhr.period_start)} – ${dmyA(fhr.period_end)}` : ''} (FHR ${pct(fhr?.value)}), shop nhận cảnh báo gỡ nhãn Mall.`,
      `Kho đã bàn giao hàng đúng hạn nhưng ĐVVC${carriers ? ` (${carriers})` : ''} lấy hàng/cập nhật trạng thái trễ nên các đơn bị tính không đạt giao hàng nhanh. Nhờ Shopee hỗ trợ loại các đơn dưới đây khỏi tỷ lệ giao hàng nhanh và giữ nhãn Mall cho shop.`,
      `Danh sách ${list.length} đơn bị ảnh hưởng${recalc ? ' (theo trang tỷ lệ giao hàng nhanh tính lại)' : ''}:`, ...list.map((no, i) => `${i + 1}. ${no}`), 'Cảm ơn Shopee!'].join('\n');
  }
  async function push(rows) {
    const run = data?.run; if (!run) throw Error('Chưa có store vừa lấy.');
    const plat = isShopee(run) ? 'shopee' : 'tiktok';
    const seen = new Set(), orders = [];
    let old = 0; // Sàn không nhận khiếu nại đơn quá 30 ngày (panel-claim.js · OPClaim.tooOld).
    for (const o of rows) { if (claimSet(run).includes(o.metric)) continue; const no = orderNo(o, run); if (!no || seen.has(no) || !OPHandover.validOrder(no, plat)) continue; seen.add(no);
      if (globalThis.OPClaim?.tooOld(o)) { old++; continue; }
      orders.push({ ...OPHandover.newOrder(), orderId: no, trackingId: String(o.tracking_id || '').trim(), status: cancelled(o) ? 'cancelled' : 'pending', note: [KPI_NAME[o.metric] || o.metric, o.period_start ? `kỳ ${dmyA(o.period_start)}–${dmyA(o.period_end)}` : ''].filter(Boolean).join(' · ').slice(0, 200), selected: true }); }
    if (!orders.length && old) throw Error(`Tất cả ${old} đơn đã quá ${OPClaim.MAX_DAYS} ngày — sàn không nhận khiếu nại.`);
    if (!orders.length) throw Error(plat === 'shopee' ? 'Không có mã đơn Shopee hợp lệ (dạng 251009ABCD1234).' : 'Không có mã đơn TikTok hợp lệ.');
    const st = await chrome.storage.local.get(['handoverSessions', 'handoverSelectedByPlatform', 'handoverWorkflows', 'handoverRun', 'tiktokTicketWorkflow']);
    if (st.handoverRun && !st.handoverRun.doneAt && (st.handoverRun.activeKey || (!st.handoverRun.paused && st.handoverRun.pending?.length))) throw Error('Tab Kháng nghị đang Auto raise một phiên khác. Chờ xong hoặc Tạm dừng rồi thử lại.');
    const count = new Map(); for (const o of rows) if (!claimSet(run).includes(o.metric) && o.carrier) count.set(o.carrier, (count.get(o.carrier) || 0) + 1);
    const session = { ...OPHandover.newSession(plat), carrier: String([...count.entries()].sort((a, b) => b[1] - a[1])[0]?.[0] || '').slice(0, 70), orders, source: { tool: 'performance', runId: run.id, shopId: run.shopId, shopName: run.shopName, at: new Date().toISOString() } };
    const sessions = { ...(st.handoverSessions || {}), [session.id]: session };
    await chrome.storage.local.set({ handoverSessions: sessions, handoverSelectedSession: session.id, handoverSelectedByPlatform: { ...(st.handoverSelectedByPlatform || {}), [plat]: session.id }, handoverWorkflows: { ...(st.handoverWorkflows || {}), [plat]: 'handover' }, activePlatform: plat, ...(plat === 'tiktok' ? { tiktokTicketWorkflow: 'handover' } : {}) });
    openTicket(true);
    message(`Đã tạo phiên kháng nghị ${orders.length} đơn (${plat === 'shopee' ? 'Shopee' : 'TikTok'})${old ? ` · bỏ ${old} đơn quá ${OPClaim.MAX_DAYS} ngày` : ''}. Chọn biên bản bàn giao, nhập STT từng đơn rồi bấm Auto raise.`);
  }
  /* v2.2.9 — tab Kháng nghị chia 2 mục con: "Khiếu nại KPI" (panel-claim + kháng nghị từng đơn) và "Ticket vận hành"
     (Ticket Assistant nhúng: pickup backlog, bàn giao, webform Shopee). Iframe chỉ tải khi mở mục Ticket vận hành, theo sàn đang chọn. */
  async function loadFrame(reload) {
    const f = $a('ticketFrame'); if (!f || (f.src && !reload)) return;
    const plat = document.body.dataset.claimPlat; if (plat && !reload) await chrome.storage.local.set({ activePlatform: plat === 'SHOPEE' ? 'shopee' : 'tiktok' }).catch(() => {});
    f.src = 'sidepanel.html' + (reload ? '?t=' + Date.now() : '');
  }
  function setSub(sub) {
    sub = sub === 'assistant' ? 'assistant' : 'claim'; document.body.dataset.tsub = sub;
    document.querySelectorAll('[data-tsub]').forEach(b => { b.setAttribute('aria-selected', String(b.dataset.tsub === sub)); b.tabIndex = b.dataset.tsub === sub ? 0 : -1; });
    try { localStorage.setItem('opTicketSub', sub); } catch (_) {}
    if (sub === 'assistant' && document.body.dataset.role === 'ticket') loadFrame().catch(() => {}); else renderAppeal().catch(() => {});
  }
  function openTicket(reload) {
    document.getElementById('role_ticket')?.click(); setSub('assistant');
    loadFrame(reload).catch(() => {});
  }
  globalThis.OPAppeal = { render: renderAppeal, openTicket, chatText, fhrList, push, load, setSub };
  document.querySelectorAll('[data-tsub]').forEach(b => b.onclick = () => setSub(b.dataset.tsub));
  document.getElementById('role_ticket')?.addEventListener('click', () => setSub(document.body.dataset.tsub));
  if ($a('goClaim')) $a('goClaim').onclick = () => { document.getElementById('role_ticket')?.click(); setSub('claim'); };
  chrome.storage.onChanged.addListener((ch, area) => { if (area === 'local' && ch.fhrRecalc) renderAppeal().catch(() => {}); });

  /* v2.2.9 — "Kết quả thu thập" (Shopee): FHR tính lại (xét nhãn Mall) ngay dưới dòng Tỷ lệ giao hàng nhanh 30 ngày.
     Nguồn: trang shopee.vn/m/tylegiaohangnhanhtinhlai (fhr-recalc.js) — lưu theo Shop ID trong fhrRecalcByShop. */
  /* panel.js vẽ lại danh sách KPI bằng innerHTML vài giây một lần. Khối này vì vậy KHÔNG chèn sau (bị xoá → chèn lại → nháy),
     mà để panel.js tự vẽ cùng lượt ngay sau dòng FHR từ chuỗi HTML chuẩn bị sẵn ở globalThis.OPFhrRecalc. */
  async function renderFhrRecalc() {
    let d = null; try { d = await chrome.runtime.sendMessage({ type: 'EXPORT' }); if (d?.error) d = null; } catch (_) {}
    const run = d?.run;
    if (!isShopee(run)) { globalThis.OPFhrRecalc = null; $a('fhrRecalcBox')?.remove(); return; }
    const { fhrRecalcByShop = {}, fhrRecalc, fhrAuto = {}, fhrUserByShop = {} } = await chrome.storage.local.get(['fhrRecalcByShop', 'fhrRecalc', 'fhrAuto', 'fhrUserByShop']);
    const st = fhrAuto.status?.[String(run.shopId)], reading = st?.state === 'reading' && Date.now() - Date.parse(st.at || 0) < 120000;
    const saved = fhrRecalcByShop[String(run.shopId)];
    const loose = !saved && fhrRecalc?.weeks?.length && !fhrRecalc.shopConfirmed && Date.now() - Date.parse(fhrRecalc.at || 0) < 6 * 3600e3 ? fhrRecalc : null;
    const weeks = (saved || loose)?.weeks || [], fhr = (run.metrics || []).find(m => m.code === 'FHR');
    const target = fhr?.threshold?.target, below = v => Number.isFinite(target) && v < target;
    const [w0, w1] = weeks;
    const html = `<div class="fhrr-head"><div><b>Giao hàng nhanh tính lại</b><span>Xét duyệt nhãn Mall · theo tuần</span></div>${w0 ? `<strong class="${below(w0.value) ? 'fail' : 'good'}">${escA(pct(w0.value))}</strong>` : '<strong class="muted">—</strong>'}</div>
      ${w0 ? `<div class="fhrr-weeks">Cập nhật <b>${escA(dmyA(w0.date))}</b>${w1 ? ` · tuần trước đó <b>${escA(pct(w1.value))}</b> (${escA(dmyA(w1.date))})` : ''}${Number.isFinite(target) ? ` · mục tiêu ${escA(fhr.threshold.direction || '>=')} ${escA(pct(target))}` : ''}</div>` : `<div class="fhrr-weeks">${reading ? 'Đang tự đọc trang tính lại ở tab nền…' : 'Chưa có số. Tool tự mở trang tính lại ở tab nền mỗi lần lấy dữ liệu Shopee (tối đa 1 lần / 6 giờ / shop).'}</div>`}
      ${st && !reading && st.state !== 'done' && st.message ? `<div class="fhrr-warn">${escA(st.message)}</div>` : ''}
      ${saved && (st?.state === 'done' || fhrUserByShop[String(run.shopId)]) ? `<div class="fhrr-note">Tự đọc lúc ${escA(new Date(saved.at || st?.at).toLocaleString('vi-VN', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit' }))}${fhrUserByShop[String(run.shopId)] ? ' · tài khoản ' + escA(fhrUserByShop[String(run.shopId)]) : ''}</div>` : ''}
      ${loose ? '<div class="fhrr-warn">Chưa xác định được shop của số này → chỉ hiển thị, chưa lưu lên Performance. Mở tab Kênh Người Bán của shop rồi F5 trang tính lại.</div>' : ''}
      <div class="fhrr-note">Khác "Tỷ lệ giao hàng nhanh" 30 ngày ở trên: chỉ tính 1 tuần và loại các đơn trễ không do shop (thường do ĐVVC).</div>
      <div class="fhrr-actions"><button type="button" class="link-next fhrr-read" ${reading ? 'disabled' : ''}>${reading ? 'Đang đọc…' : 'Đọc lại ngay (tự mở, tự đóng)'}</button> <button type="button" class="link-next fhrr-open">Xem trang ↗</button></div>`;
    globalThis.OPFhrRecalc = { html };
    const box = $a('fhrRecalcBox');
    if (box) { if (box.innerHTML !== html) box.innerHTML = html; return; } // chỉ đổi khi nội dung đổi
    // Lần đầu (panel.js vẽ trước khi có HTML): chèn một lần ngay dưới dòng FHR; các lượt sau panel.js tự vẽ.
    const row = [...document.querySelectorAll('#metrics .metric')].find(el => /giao hàng nhanh|FHR/i.test(el.querySelector('span')?.textContent || ''));
    if (row) row.insertAdjacentHTML('afterend', `<div id="fhrRecalcBox" class="fhrr">${html}</div>`);
  }
  document.addEventListener('click', (e) => { if (e.target.closest?.('.fhrr-open')) chrome.tabs.create({ url: FHR_URL, active: true }); });
  // v2.2.18 — đọc lại ngay: tool mở trang ở tab nền, đọc xong tự đóng và lưu.
  document.addEventListener('click', async (e) => { const b = e.target.closest?.('.fhrr-read'); if (!b) return; b.disabled = true; b.textContent = 'Đang đọc…';
    try { const r = await chrome.runtime.sendMessage({ type: 'FHR_AUTO_READ' }); if (!r?.ok) throw Error(r?.error || 'Không mở được trang.'); } catch (err) { b.disabled = false; b.textContent = 'Chưa mở được: ' + err.message + ' — bấm để thử lại'; return; }
    renderFhrRecalc().catch(() => {}); });
  let fhrrTimer = null; // state đổi liên tục khi đang lấy dữ liệu → gộp lại, tối đa 1 lần / 1,5 giây
  chrome.storage.onChanged.addListener((ch, area) => { if (area === 'local' && (ch.fhrRecalcByShop || ch.fhrRecalc || ch.state || ch.fhrAuto)) { clearTimeout(fhrrTimer); fhrrTimer = setTimeout(() => renderFhrRecalc().catch(() => {}), 1500); } });
  renderFhrRecalc().catch(() => {});
  let sub0 = 'claim'; try { sub0 = localStorage.getItem('opTicketSub') || 'claim'; } catch (_) {}
  setSub(sub0);
  // Light polling: chỉ khi đang xem mục Khiếu nại KPI (EXPORT reads the local order DB).
  setInterval(() => { if (document.visibilityState === 'visible' && document.body.dataset.role === 'ticket' && document.body.dataset.tsub === 'claim') renderAppeal().catch(() => {}); }, 10000);
})();
