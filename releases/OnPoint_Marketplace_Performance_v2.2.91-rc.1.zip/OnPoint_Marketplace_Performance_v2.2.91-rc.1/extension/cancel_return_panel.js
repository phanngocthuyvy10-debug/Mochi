/* v2.2.20 — Side Panel: Đòi hàng — sàn hủy nhưng đã bàn giao ĐVVC, kiện chưa hoàn về. */
(() => {
  const $c = id => document.getElementById(id);
  const CR = globalThis.OPCancelReturn;
  let shown = false, loading = true, shopName = '', readingShop = null;
  // v2.2.67 — sàn đang chọn trên Side Panel (TikTok / Shopee): panel chỉ hiện channel, shop, phiếu của sàn đó.
  let platform = 'tiktok';
  const isShopee = () => platform === 'shopee';
  const sell = () => CR.sellerLabel(platform);
  const ofPlatform = item => (item?.platform === 'shopee' ? 'shopee' : 'tiktok') === platform;
  const shopHint = () => isShopee() ? 'Mở Kênh Người Bán Shopee (đúng shop) để tự nhận shop.' : 'Mở tab TikTok Shop để tự nhận shop.';
  // v2.2.69 — Shopee: mở thẳng trang chi tiết phiếu seller-service.cs.shopee.vn/detail/<mã phiếu>.
  const ticketUrl = ticket => (ticket?.platform === 'shopee' ? CR.shopeeDetailUrl(ticket.TicketID) : `https://seller-vn.tiktok.com/ticket/detail/${encodeURIComponent(ticket?.TicketID || ticket)}?shop_region=VN`);
  /** Mở Yêu cầu của tôi và tự tìm theo Mã đơn hàng (Tất cả → Mã đơn hàng → gõ mã) — seller-service-bridge.js làm các bước. */
  async function searchOnShopee(orderId) {
    await save({ shopeeCaseSearch: { orderId: String(orderId || '').trim().toUpperCase(), at: Date.now() } });
    await chrome.tabs.create({ url: CR.SHOPEE.followUrl, active: true });
  }
  let settings = {}, tracker = null, groups = {}, shopMap = {}, tickets = {}, run = null, follow = null, openGroups = {}, lookup = null, tikTokScan = null;
  // Form tự điền xong nhưng không tự gửi (thiếu file, chưa chọn được chủ đề, sai shop…) → có nút Thử lại.
  const formFailed = key => { const autofill = openGroups?.[key]?.autofill; return Boolean(autofill && autofill.ok === false && (autofill.reason || autofill.details)); };
  const esc = value => escapeHtml(value);
  const status = (message, kind = '') => { $c('crStatus').textContent = message; $c('crStatus').className = `status-box ${kind}`; };
  const followStatus = (message, kind = '') => { $c('crFollowStatus').textContent = message; $c('crFollowStatus').className = `status-box ${kind}`; };
  const reportError = error => status(error?.message || String(error), 'error');
  // v2.2.34 — phiếu gộp nhiều đơn: TikTok chỉ xử lý đơn đại diện, yêu cầu tạo phiếu riêng cho các đơn còn lại → chỉ tính đơn đại diện là đã raise.
  const raisedOrders = () => new Set(Object.values(tickets).flatMap(ticket => (ticket.orderIds || []).length > 1 ? [ticket.orderIds[0]] : ticket.orderIds || []));
  // v2.2.44 — hàng đợi đang TẠM DỪNG (kể cả chờ phản hồi phiếu) không khóa raise; raise mới sẽ gác hàng đợi cũ lại.
  const running = () => Boolean(run && !run.doneAt && (run.activeKey || (run.awaitingReply && !run.paused) || (!run.paused && run.pending?.length)));
  const channelGroups = channel => Object.values(groups).filter(group => group.channel === channel);
  // v2.2.63 — channel chỉ thật sự 'thuộc' 1 shop khi đã raise thành công ít nhất 1 phiếu ở shop đó.
  // Gắn lúc bấm Raise mà chưa ra phiếu nào (vd đang login nhầm shop) không được tính → không khóa nhầm channel.
  const boundShop = channel => (channel && shopMap[channel] && channelGroups(channel).some(group => group.ticketId)) ? shopMap[channel] : '';
  const save = values => chrome.storage.local.set(values);

  /* ---------------------------------------------------------------- tracker --- */
  function readWorkbook(bytes) {
    const workbook = XLSX.read(bytes, { type: 'array', cellDates: false });
    const name = workbook.SheetNames.find(sheet => CR.fold(sheet) === CR.fold(CR.TRACKER_SHEET));
    if (!name) throw new Error(`File không có sheet ${CR.TRACKER_SHEET}. Sheet đang có: ${workbook.SheetNames.join(', ')}.`);
    const rows = XLSX.utils.sheet_to_json(workbook.Sheets[name], { header: 1, raw: false, defval: '' });
    return CR.parseTracking(rows);
  }
  // Giữ file tự thêm / nội dung đã sửa của nhóm chưa raise khi tải lại tracker.
  async function applyTracker(parsed, source) {
    // v2.2.65 — sheet Tracking (Excel) không có cột Ticket ID → đọc thêm Ticket ID đã ghi trên List "FG Recon Tracking"
    // để đơn đã raise (ở Chrome/máy khác, hoặc ghi tay trên SharePoint) không bị bắt raise lại.
    status('Đang đọc Ticket ID đã ghi trên SharePoint List…', 'running');
    const raised = raisedOrders();
    let remoteNote = '';
    const remote = await chrome.runtime.sendMessage({ type: 'LIST_CANCEL_RETURN_SP_TICKETS' }).catch(error => ({ ok: false, error: error.message }));
    if (remote?.ok) {
      const byOrderNo = new Map(parsed.rows.map(row => [row.orderNo, row.orderId]));
      let added = 0;
      for (const item of remote.items || []) {
        const orderId = byOrderNo.get(item.orderNo) || (/^\d{12,25}$/.test(item.orderId) || CR.validOrderId(String(item.orderId || '').toUpperCase(), 'shopee') ? String(item.orderId).toUpperCase() : '') || (item.orderNo.match(/(\d{12,25})$/) || [])[1] || CR.shopeeOrderId('', item.orderNo);
        // Đơn nằm trong phiếu gộp nhưng không phải đơn đại diện → TikTok không xử lý, vẫn cần phiếu riêng.
        if (item.representative && item.representative !== orderId) continue;
        if (orderId && !raised.has(orderId)) { raised.add(orderId); added++; }
      }
      remoteNote = ` · ${added} đơn bỏ qua vì đã có Ticket ID trên SharePoint`;
    } else remoteNote = ` · ⚠ chưa đọc được Ticket ID trên SharePoint (${remote?.error || 'lỗi'}) — đơn raise ở Chrome khác có thể hiện lại`;
    const fresh = CR.buildGroups(parsed.rows, raised, { groupByCarrier: settings.groupByCarrier === true });
    const kept = Object.fromEntries(Object.entries(groups).filter(([, group]) => group.ticketId || group.reraiseOf));
    for (const group of fresh) {
      const old = groups[group.id];
      if (old && !old.ticketId && old.rows.map(row => row.orderId).join() === group.rows.map(row => row.orderId).join()) {
        group.files = (old.files || []).filter(file => file.kind !== 'excel');
        group.textOverride = old.textOverride || '';
        group.selected = old.selected !== false;
        group.evidenceNote = old.evidenceNote || '';
      }
      kept[group.id] = group;
    }
    groups = kept;
    // v2.2.75 — giữ danh sách đơn kho vẫn ghi "Đã bàn giao ĐVVC" (chưa nhận hàng hoàn) để phản biện khi TikTok báo "đã hoàn thành công".
    // v2.2.78 — mọi channel có đơn "Đã bàn giao ĐVVC" trong tracker (kể cả đã raise hết ở Chrome/máy khác → không có nhóm đơn ở đây).
    const trackerChannels = {};
    for (const row of parsed.rows) { const c = trackerChannels[row.channel] || (trackerChannels[row.channel] = { platform: row.platform, handed: 0 }); c.handed++; }
    // v2.2.79 — phiếu TikTok đã có Ticket ID trong tracker (raise ở Chrome/máy khác) → Quét phiếu TikTok cũng kiểm tra phiếu đó.
    // Ticket ID lấy từ List (chính xác 18 số); không đọc được List thì lấy cột Ticket ID của sheet Tracking.
    const ticketOf = new Map();
    for (const item of remote?.ok ? remote.items || [] : []) { if (/^\d{8,30}$/.test(item.ticketId)) { ticketOf.set(item.orderNo, item.ticketId); if (item.orderId) ticketOf.set(item.orderId, item.ticketId); } }
    const trackerTickets = {};
    for (const row of parsed.rows) {
      if (row.platform !== 'tiktok') continue;
      const ticketId = ticketOf.get(row.orderNo) || ticketOf.get(row.orderId) || (/^\d{8,30}$/.test(row.ticketId || '') ? row.ticketId : '');
      if (!ticketId) continue;
      const t = trackerTickets[ticketId] || (trackerTickets[ticketId] = { channel: row.channel, carrier: row.carrier, warehouse: row.warehouse, orderIds: [], orderNos: [], trackingIds: [], evidence: '', sequence: '', handoverAt: row.handoverAt });
      if (!t.orderIds.includes(row.orderId)) { t.orderIds.push(row.orderId); t.orderNos.push(row.orderNo); t.trackingIds.push(row.trackingId); }
      t.evidence = t.evidence || (row.evidence || [])[0] || ''; t.sequence = t.sequence || row.sequence || '';
    }
    tracker = { loadedAt: new Date().toISOString(), source, stats: parsed.stats, count: parsed.rows.length, channels: trackerChannels, tickets: trackerTickets, pendingOrders: [...new Set(parsed.rows.map(row => row.orderId).filter(Boolean))] };
    await save({ cancelReturnGroups: groups, cancelReturnTracker: tracker });
    const channels = [...new Set(fresh.filter(ofPlatform).map(group => group.channel))];
    if (!channels.includes(settings.channel) && !trackerChannels[settings.channel]) { settings.channel = channels[0] || ''; await save({ cancelReturnSettings: settings }); }
    render();
    const pending = fresh.reduce((sum, group) => sum + group.rows.length, 0);
    const mine = fresh.filter(ofPlatform);
    status(`Đã đọc ${parsed.stats.total} dòng · ${parsed.stats.handedOver} dòng "Đã bàn giao ĐVVC" · ${parsed.stats.tiktok} TikTok · ${parsed.stats.shopee || 0} Shopee · ${sell()}: ${mine.reduce((sum, group) => sum + group.rows.length, 0)} đơn chưa có ticket đòi hàng, chia ${mine.length} ticket (tất cả sàn: ${pending} đơn)${remoteNote}.`, remote?.ok ? 'ok' : 'error');
  }
  async function fetchTracker() {
    const url = settings.trackerUrl || CR.TRACKER_URL;
    status('Đang tải FG_Phan_hoi_tong.xlsx từ SharePoint…', 'running');
    let response;
    try { response = await fetch(url, { credentials: 'include', cache: 'no-store' }); }
    catch (error) { throw new Error(`Không kết nối được SharePoint (${error.message}). Mở SharePoint trên Chrome này, đăng nhập rồi thử lại, hoặc bấm Chọn file đã tải.`); }
    const type = response.headers.get('content-type') || '';
    if (!response.ok || /text\/html/i.test(type)) throw new Error(`SharePoint chưa cho tải file (HTTP ${response.status}). Đăng nhập onpointvn.sharepoint.com trên Chrome này rồi thử lại, hoặc tải file về và bấm Chọn file đã tải.`);
    await applyTracker(readWorkbook(new Uint8Array(await response.arrayBuffer())), 'SharePoint');
  }

  /* ------------------------------------------------------------- file nhóm --- */
  const MIME = { pdf: 'application/pdf', jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', xls: 'application/vnd.ms-excel', csv: 'text/csv', mp4: 'video/mp4', mov: 'video/quicktime' };
  const EXT_BY_MIME = Object.fromEntries(Object.entries(MIME).map(([ext, mime]) => [mime, ext]));
  function excelAttachment(group) {
    const bytes = createXlsx(CR.excelHeaders(group), CR.excelRows(group), 'Don huy da ban giao');
    return { name: CR.excelName(group), type: MIME.xlsx, size: bytes.length, base64: bytesToBase64(bytes), kind: 'excel' };
  }
  // Link chia sẻ SharePoint/OneDrive → link tải trực tiếp. Link ngoài SharePoint được ghi trong Excel, không tải.
  function downloadUrl(link) {
    let url;
    try { url = new URL(link); } catch (_) { return ''; }
    // v2.2.34 — link biên bản trong tracker là file trực tiếp (vd tms.s3-sgn10.fptcloud.com/…pdf) → tải thẳng.
    if (url.protocol !== 'https:') return '';
    if (!/\.sharepoint\.com$/i.test(url.hostname)) return url.toString();
    const doc = url.searchParams.get('sourcedoc');
    if (doc) { const site = url.pathname.split('/_layouts/')[0]; return `${url.origin}${site}/_layouts/15/download.aspx?UniqueId=${encodeURIComponent(doc.replace(/[{}]/g, ''))}`; }
    if (/\/:[a-z]:\//i.test(url.pathname)) { url.searchParams.set('download', '1'); return url.toString(); }
    return url.toString();
  }
  function fileNameFrom(response, link, type) {
    const disposition = response.headers.get('content-disposition') || '';
    const star = disposition.match(/filename\*=UTF-8''([^;]+)/i);
    const plain = disposition.match(/filename="?([^";]+)"?/i);
    let name = star ? decodeURIComponent(star[1]) : plain ? plain[1] : decodeURIComponent(new URL(link).pathname.split('/').pop() || 'bien_ban');
    if (!/\.[a-z0-9]{2,4}$/i.test(name) && EXT_BY_MIME[type]) name += `.${EXT_BY_MIME[type]}`;
    return name.replace(/[\\/:*?"<>|]+/g, '_').slice(0, 120);
  }
  async function fetchEvidence(link) {
    const url = downloadUrl(link);
    if (!url) throw new Error('link không hợp lệ (cần https)');
    let response = await fetch(url, { credentials: 'include', cache: 'no-store' });
    let type = (response.headers.get('content-type') || '').split(';')[0].trim().toLowerCase();
    // v2.2.68 — trang xem ảnh (ibb.co, imgur…) → tải ảnh gốc trong og:image.
    if (response.ok && type === 'text/html') {
      const image = CR.ogImage(await response.text(), response.url || url);
      if (image) { response = await fetch(image, { cache: 'no-store' }); link = image; type = (response.headers.get('content-type') || '').split(';')[0].trim().toLowerCase(); }
    }
    if (!response.ok || type === 'text/html') throw new Error(`HTTP ${response.status}${type === 'text/html' ? ' (cần đăng nhập / link là thư mục)' : ''}`);
    let bytes = new Uint8Array(await response.arrayBuffer());
    let name = CR.safeFileName(fileNameFrom(response, link, type));
    let ext = name.split('.').pop().toLowerCase();
    if (!MIME[ext]) throw new Error(`${name}: định dạng TikTok không nhận`);
    const limit = /^(jpg|jpeg|png)$/.test(ext) ? 5 : /^(mp4|mov)$/.test(ext) ? 80 : 50;
    // v2.2.66 — ảnh biên bản > 5 MB: tự nén xuống dưới 5 MB.
    if (limit === 5 && bytes.length >= limit * 1024 * 1024) {
      const small = await CR.shrinkImage(bytes, MIME[ext]).catch(() => null);
      if (small) { bytes = small; ext = 'jpg'; name = name.replace(/\.[a-z0-9]+$/i, '.jpg'); }
    }
    if (!bytes.length || bytes.length >= limit * 1024 * 1024) throw new Error(`${name}: dung lượng phải dưới ${limit} MB`);
    return { name, type: MIME[ext], size: bytes.length, base64: bytesToBase64(bytes), kind: 'evidence', source: link };
  }
  /** v2.2.34 — 1 đơn/ticket: chỉ đính kèm BIÊN BẢN (PDF tải từ Link bằng chứng, đặt tên theo ĐVVC + mã vận đơn + STT);
      file Excel danh sách đơn chỉ dùng khi gộp nhiều đơn. Tối đa 6 file. */
  async function prepareFiles(group, options = {}) {
    const own = (group.files || []).filter(file => file.kind !== 'excel' && file.kind !== 'evidence');
    // v2.2.67 — Shopee: luôn có Excel danh sách đơn (như raise vận hành pickup), cả khi ticket chỉ 1 đơn.
    const files = [...(group.rows.length > 1 || group.platform === 'shopee' ? [excelAttachment(group)] : []), ...own];
    const limitFiles = CR.maxFiles(group);
    const linkRow = new Map();
    for (const row of group.rows) for (const link of row.evidence || []) if (!linkRow.has(link)) linkRow.set(link, row);
    const links = options.skipEvidence ? [] : [...linkRow.keys()];
    const notes = [];
    for (const link of links) {
      if (files.length >= limitFiles) { notes.push(`${links.length - links.indexOf(link)} link còn lại chưa đính kèm (đủ ${limitFiles} file; link vẫn nằm trong Excel)`); break; }
      try {
        const file = await fetchEvidence(link);
        const row = linkRow.get(link);
        const ext = file.name.split('.').pop();
        file.name = CR.safeFileName(`BienBan_${group.carrier}_${row.trackingId || row.orderId}${row.sequence ? `_STT${row.sequence}` : ''}.${ext}`);
        if (files.some(item => item.name.toLowerCase() === file.name.toLowerCase())) continue;
        files.push(file);
      } catch (error) { notes.push(`Không tải được biên bản (${error.message}): ${link}`); }
    }
    group.files = files;
    group.evidenceNote = notes.join(' · ');
    return group;
  }

  /* ----------------------------------------------------------------- render --- */
  function renderStage() {
    $c('crStage').innerHTML = Object.entries(CR.STAGES).map(([key, item]) => `<option value="${key}">${esc(item.label)}</option>`).join('');
    $c('crStage').value = CR.stage(settings.stage);
    $c('crStagePath').innerHTML = `Chủ đề tự chọn: ${CR.subjectPath(settings.stage).map(step => `<b>${esc(step)}</b>`).join(' → ')}`;
    $c('crWarehouse').value = settings.warehouse || '';
    $c('crReplyAfter').checked = settings.replyAfterRaise !== false;
    $c('crGroupByCarrier').checked = settings.groupByCarrier === true;
    $c('crHideRaised').checked = settings.hideRaised === true;
    $c('crParallelReply').checked = settings.parallelReply !== false;
    $c('crFastMode').checked = settings.fastMode === true; $c('crFastMode').disabled = settings.parallelReply === false;
    $c('crAutoScan').checked = settings.autoScan === true; $c('crAutoReraise').checked = settings.autoReraise === true; $c('crAutoReraise').disabled = !settings.autoScan;
    if (document.activeElement !== $c('crShopeeEmail')) $c('crShopeeEmail').value = settings.shopeeEmail || '';
    document.querySelectorAll('#cancelReturnPanel [data-cr-only]').forEach(el => { el.hidden = el.dataset.crOnly !== platform; });
  }
  function renderSource() {
    $c('crSource').textContent = tracker
      ? `Tracker ${tracker.source} · ${new Date(tracker.loadedAt).toLocaleString('vi-VN')} · ${tracker.stats.handedOver} dòng "Đã bàn giao ĐVVC", ${tracker.stats.tiktok} TikTok, ${tracker.stats.shopee || 0} Shopee${tracker.stats.invalid ? `, ${tracker.stats.invalid} dòng thiếu mã đơn/trùng` : ''}.`
      : 'Chưa tải tracker. Bấm Tải từ SharePoint (cần đăng nhập SharePoint trên Chrome) hoặc chọn file đã tải.';
  }
  // v2.2.35 — đếm cả đơn ĐÃ raise để channel không biến mất và hiện tiến độ "còn / đã raise".
  function renderChannels() {
    const counts = new Map();
    for (const group of Object.values(groups).filter(ofPlatform)) {
      const item = counts.get(group.channel) || { pending: 0, raised: 0 };
      if (group.ticketId) item.raised += group.rows.length; else item.pending += group.rows.length;
      counts.set(group.channel, item);
    }
    // Channel có trong tracker nhưng không còn nhóm đơn nào ở Chrome này (đã raise hết ở nơi khác) → vẫn hiện, ghi số đơn đã bàn giao.
    for (const [channel, info] of Object.entries(tracker?.channels || {})) {
      if (counts.has(channel) || (info.platform === 'shopee') !== isShopee()) continue;
      counts.set(channel, { pending: 0, raised: 0, handed: info.handed });
    }
    // v2.2.54 — channel còn đơn lên trên. v2.2.78 — channel đã raise xong KHÔNG ẩn nữa (người dùng cần biết store nào đã raise
    // để vào kiểm tra lại): hiện ở nhóm "✓ Đã raise xong", chọn được để xem đơn/phiếu đã raise.
    const all = [...counts.keys()];
    const channels = all.filter(channel => counts.get(channel).pending > 0).sort((a, b) => a.localeCompare(b));
    const doneList = all.filter(channel => !counts.get(channel).pending).sort((a, b) => a.localeCompare(b));
    const option = channel => { const c = counts.get(channel); const shop = boundShop(channel) || shopMap[channel] || ''; return `<option value="${esc(channel)}">${c.pending ? `${esc(channel)} · còn ${c.pending} đơn${c.raised ? ` · đã raise ${c.raised}` : ''}` : c.raised ? `✓ ${esc(channel)} · đã raise ${c.raised} đơn` : `✓ ${esc(channel)} · ${c.handed || 0} đơn bàn giao đã có ticket (raise ở nơi khác)`}${shop ? ` · ${esc(shop)}` : ''}</option>`; };
    $c('crChannel').innerHTML = all.length
      ? (channels.length ? `<optgroup label="Còn đơn chưa raise (${channels.length})">${channels.map(option).join('')}</optgroup>` : '')
        + (doneList.length ? `<optgroup label="✓ Đã raise xong (${doneList.length})">${doneList.map(option).join('')}</optgroup>` : '')
      : `<option value="">${tracker ? `Không có đơn ${sell()} cần đòi hàng` : 'Chưa có đơn — tải tracker'}</option>`;
    if (all.includes(settings.channel)) $c('crChannel').value = settings.channel;
    else settings.channel = channels[0] || doneList[0] || '';
  }
  /** v2.2.35 — tự nhận channel theo shop TikTok đang đăng nhập: shop đã gắn (lần raise trước) hoặc tên shop chứa tên brand của channel. */
  function channelForShop(name) {
    if (!name) return '';
    // Chỉ tự chọn channel còn đơn chưa raise (channel đã xong bị ẩn khỏi danh sách).
    const channels = [...new Set(Object.values(groups).filter(group => !group.ticketId && ofPlatform(group)).map(group => group.channel))];
    const bound = channels.filter(channel => boundShop(channel) === name);
    if (bound.length) return bound[0];
    const shop = CR.fold(name);
    const words = new Set(shop.split(/[^a-z0-9]+/).filter(Boolean));
    const hits = channels.filter(channel => {
      const base = CR.fold(channel).replace(/\s*-\s*(tiktok|shopee).*$/, '').trim();
      if (!base) return false;
      if (shop.includes(base)) return true;
      const first = base.split(/[^a-z0-9]+/).filter(Boolean)[0] || '';
      return first.length >= 3 && words.has(first);
    });
    if (hits.length === 1) return hits[0];
    // v2.2.78 — shop đã raise xong mọi channel: chọn channel đã gắn với shop này (để xem lại đơn đã raise).
    const doneBound = [...new Set(Object.values(groups).filter(ofPlatform).map(group => group.channel))].filter(channel => boundShop(channel) === name);
    return !hits.length && doneBound.length === 1 ? doneBound[0] : '';
  }  function renderBinding() {
    const channel = settings.channel;
    const bound = boundShop(channel);
    const box = $c('crBinding');
    if (!channel) { box.textContent = ''; return; }
    if (bound && shopName && bound !== shopName) { box.innerHTML = `⚠ Channel <b>${esc(channel)}</b> thuộc shop <b>${esc(bound)}</b>, đang login <b>${esc(shopName)}</b>${loggedShopDone() ? ' (shop này đã raise xong ✓)' : ''}. Đổi sang shop đó để raise tiếp. <button class="link-btn" data-cr-rebind>Gắn lại channel này với shop đang login</button> <button class="link-btn" data-cr-unbind>Bỏ gắn shop</button>`; return; }
    box.innerHTML = bound ? `Channel <b>${esc(channel)}</b> ↔ shop <b>${esc(bound)}</b>. <button class="link-btn" data-cr-unbind>Bỏ gắn shop</button>` : `Channel <b>${esc(channel)}</b> chưa gắn shop. Lần raise đầu sẽ gắn với shop đang login <b>${esc(shopName || '?')}</b> — kiểm tra đúng shop.`;
  }
  // v2.2.43 — danh sách gọn: mỗi đơn 1 dòng (bấm ▾ mới mở nội dung/file), tìm nhanh, chọn hết/bỏ chọn, xem thêm theo trang.
  const view = { q: '', limit: 30, open: '', raisedLimit: 30, raisedOpen: false, ticketFilter: 'all', ticketLimit: 30, ticketOpen: '', shop: '' };
  const PAGE = 30;
  const groupLabel = group => group.rows.length > 1 ? `${group.rows.length} đơn · đại diện ${group.rows[0].orderId}` : group.rows[0].orderId;
  const matchesSearch = group => {
    const q = CR.fold(view.q || '').trim();
    if (!q) return true;
    return CR.fold([group.carrier, ...group.rows.flatMap(row => [row.orderId, row.orderNo, row.trackingId, row.sequence])].join(' ')).includes(q);
  };
  // Shop đang login có channel đã gắn nhưng không còn đơn nào → đã raise xong.
  function loggedShopDone() {
    if (!shopName) return false;
    const mine = Object.values(groups).filter(group => boundShop(group.channel) === shopName);
    return mine.length > 0 && mine.every(group => group.ticketId);
  }
  function startBlockReason(list, selected) {
    const bound = boundShop(settings.channel);
    if (loading) return 'Đang tải tracker…';
    if (running()) return run?.channel && run.channel !== settings.channel ? `Đang chạy hàng đợi của channel ${run.channel} — chờ xong, bấm Dừng, hoặc Bỏ qua phản hồi phiếu đang kẹt.` : 'Đang raise — chờ phiếu hiện tại xong.';
    if (!shopName) return isShopee() ? 'Chưa nhận được shop Shopee đang đăng nhập — mở Kênh Người Bán Shopee rồi bấm ↻.' : 'Chưa nhận được shop TikTok đang đăng nhập — mở tab TikTok Shop rồi bấm ↻.';
    if (bound && bound !== shopName) return `Đơn của channel ${settings.channel} thuộc shop "${bound}" — đang login "${shopName}"${loggedShopDone() ? ` (shop này đã raise xong hết ✓)` : ''}. Đổi sang shop "${bound}" để raise tiếp, hoặc chọn channel khác.`;
    if (!list.length) return 'Channel này không còn đơn cần raise.';
    if (!selected) return 'Chưa chọn đơn nào — tick đơn cần raise hoặc bấm Chọn hết.';
    return '';
  }
  function raisedRows(raisedList) {
    const shown = raisedList.slice(0, view.raisedLimit);
    const rows = shown.map(group => {
      const ticket = tickets[group.ticketId] || {};
      const state = ticket.lastStatus && ticket.lastStatus !== 'Submitted' ? ticket.lastStatus : 'Đã gửi';
      const tracker = ticket.trackerSyncedAt ? '<span class="cr-chip ok">tracker ✓</span>' : ticket.trackerError ? '<span class="cr-chip warn">tracker ⚠</span>' : '';
      return `<div class="cr-row cr-done"><div class="cr-line"><span class="cr-tick">✓</span>
        <div class="cr-main"><b>${esc(groupLabel(group))}</b><span class="cr-sub">${esc(group.carrier)} · ${esc(state)}${group.ticketRecordedAt ? ` · ${esc(CR.vnTime(group.ticketRecordedAt))}` : ''}</span></div>
        ${tracker}<a class="cr-ticket" href="${esc(ticketUrl({ ...ticket, TicketID: group.ticketId, platform: group.platform }))}" target="_blank" rel="noopener" title="${esc(group.ticketId)}">#${esc(String(group.ticketId).slice(-6))} ↗</a></div></div>`;
    }).join('');
    const more = raisedList.length > shown.length ? `<button class="secondary wide cr-more" data-cr-more-raised>Xem thêm ${Math.min(PAGE, raisedList.length - shown.length)} (còn ${raisedList.length - shown.length})</button>` : '';
    return rows + more;
  }
  function renderGroups() {
    const all = channelGroups(settings.channel).filter(group => !group.ticketId);
    const list = all.filter(matchesSearch);
    const raisedList = channelGroups(settings.channel).filter(group => group.ticketId).filter(matchesSearch).sort((a, b) => String(b.ticketRecordedAt || '').localeCompare(String(a.ticketRecordedAt || '')));
    const lock = running();
    const open = openGroups || {};
    const wrongShop = Boolean(boundShop(settings.channel) && shopName && boundShop(settings.channel) !== shopName);
    const shown = list.slice(0, view.limit);
    // v2.2.61 — lý do đơn bị bỏ qua ở lượt raise trước (hiện ngay trên dòng đơn).
    const skippedWhy = Object.fromEntries((run?.skipped || []).map(item => [item.groupId, item.error]));
    const rows = shown.map(group => {
      const key = CR.groupKey(group.id);
      const active = open[key];
      const expanded = view.open === group.id || Boolean(active) || (Boolean(skippedWhy[group.id]) && view.open !== `closed:${group.id}`);
      const first = group.rows[0];
      const links = [...new Set(group.rows.flatMap(row => row.evidence || []))];
      const why = skippedWhy[group.id] || '';
      const chip = active ? `<span class="cr-chip run">Đang chạy</span>` : why ? `<span class="cr-chip warn" title="${esc(why)}">lỗi lần trước</span>` : !links.length && !(group.files || []).length ? '<span class="cr-chip warn">thiếu biên bản</span>' : '';
      let detail = '';
      if (expanded) {
        const body = CR.text(group, settings);
        const extra = (group.files || []).filter(file => file.kind !== 'excel');
        detail = `<div class="cr-detail">
          ${active ? `<div class="data-note"><b>Đang xử lý</b> · ${esc(active.autofill?.details || 'tự điền, tự gửi và lưu Ticket ID')}</div>` : ''}
          <div class="data-note">${group.rows.slice(0, 6).map(row => `${esc(row.orderId)} · MVĐ ${esc(row.trackingId || '-')} · STT ${esc(row.sequence || '?')}`).join('<br>')}${group.rows.length > 6 ? `<br>… +${group.rows.length - 6} đơn (đủ trong Excel đính kèm)` : ''}</div>
          <div class="data-note">File: ${group.rows.length > 1 || group.platform === 'shopee' ? 'Excel danh sách đơn (tự tạo)' : 'biên bản PDF'}${extra.length ? ` + ${extra.map(file => `${esc(file.name)} · ${formatBytes(file.size)}`).join(', ')}` : ''} · ${links.length} link biên bản tự tải khi raise${group.platform === 'shopee' ? ` (tối đa ${CR.maxFiles(group)} file; link còn lại nằm trong Excel) · webform Shopee Vận chuyển (Mã đơn hàng = đơn đại diện), không re-raise` : ''}.</div>
          ${group.evidenceNote ? `<div class="data-note">⚠ ${esc(group.evidenceNote)}</div>` : ''}
          ${why ? `<div class="data-note cr-why">⚠ Lượt trước bị bỏ qua: ${esc(why)}<br>Bấm Raise để thử lại (tool tải lại biên bản từ đầu). Link hỏng thì thêm biên bản tay ở mục "Thêm biên bản / ảnh riêng".</div>` : ''}
          <details class="handover-extra"><summary>Nội dung ticket (${body.length}/${CR.maxText(group)})</summary><textarea data-cr-text rows="6" maxlength="${CR.maxText(group)}" ${lock ? 'disabled' : ''}>${esc(body)}</textarea>
          <div class="actions"><button class="secondary" data-cr-reset ${lock ? 'disabled' : ''}>Tạo lại</button><button class="secondary" data-cr-copy>Copy</button></div></details>
          <details class="handover-extra"><summary>Thêm biên bản / ảnh riêng</summary><input data-cr-files type="file" multiple accept=".pdf,.jpg,.jpeg,.png,.xlsx,.xls,.csv,.mp4,.mov" ${lock ? 'disabled' : ''} />
          ${extra.map((file, index) => `<div class="handover-file"><span>${esc(file.name)}</span><button class="link-btn" data-cr-remove="${index}" ${lock ? 'disabled' : ''}>Xóa</button></div>`).join('')}</details>
          ${active && formFailed(key) ? '<button class="primary wide" data-cr-retry>Thử lại đính kèm (tải lại form, dùng file đã lưu)</button>' : ''}
          ${group.platform === 'shopee' ? `<div class="actions"><button class="link-btn" data-cr-search-shopee title="Mở Yêu cầu của tôi, tự chọn Tất cả → Mã đơn hàng → tìm ${esc(first.orderId)}">Tìm phiếu trên Shopee ↗</button></div>` : ''}
          <details class="handover-extra"><summary>Đã gửi tay / đóng tab sớm — nhập Ticket ID</summary><div class="handover-manual"><input data-cr-manual placeholder="${group.platform === 'shopee' ? 'Mã phiếu Shopee' : 'Ticket ID TikTok'}" ${group.platform === 'shopee' ? '' : 'inputmode="numeric"'} /><button class="secondary" data-cr-map>Lưu</button></div></details>
        </div>`;
      }
      return `<article class="cr-row${expanded ? ' open' : ''}${active ? ' busy' : ''}" data-cr-group="${esc(group.id)}">
        <div class="cr-line">
          <input type="checkbox" data-cr-select aria-label="Chọn ${esc(first.orderId)}" ${group.selected !== false ? 'checked' : ''} ${lock ? 'disabled' : ''} />
          <div class="cr-main"><b>${group.reraiseOf ? '↻ ' : ''}${esc(groupLabel(group))}</b><span class="cr-sub">${group.reraiseOf ? `Raise lại phiếu #${esc(String(group.reraiseOf.ticketId).slice(-6))} · ` : ''}${esc(group.carrier)} · ${esc(first.trackingId || '-')} · STT ${esc(first.sequence || '?')}</span></div>
          ${chip}
          <button class="cr-mini" data-cr-raise-one title="Raise riêng đơn này" ${lock || active || wrongShop ? 'disabled' : ''}>Raise</button>
          <button class="cr-toggle" data-cr-toggle title="Xem nội dung / file" aria-expanded="${expanded}">${expanded ? '▴' : '▾'}</button>
        </div>${detail}
      </article>`;
    }).join('');
    const more = list.length > shown.length ? `<button class="secondary wide cr-more" data-cr-more>Xem thêm ${Math.min(PAGE, list.length - shown.length)} đơn (còn ${list.length - shown.length})</button>` : '';
    const fromTracker = tracker?.channels?.[settings.channel];
    const empty = all.length ? (list.length ? '' : '<div class="data-note">Không có đơn khớp tìm kiếm.</div>')
      : `<div class="data-note">✓ Channel này không còn đơn nào cần raise${!raisedList.length && fromTracker ? ` — ${fromTracker.handed} đơn "Đã bàn giao ĐVVC" trong tracker đều đã có Ticket ID (raise ở Chrome/máy khác). Xem phiếu ở thẻ Theo dõi › Store cần kiểm tra` : ''}.</div>`;
    // v2.2.78 — channel đã raise xong: mở sẵn danh sách đơn đã raise để kiểm tra.
    const raisedBox = raisedList.length && !$c('crHideRaised').checked
      ? `<details class="cr-raised-box"${view.raisedOpen || !all.length ? ' open' : ''}><summary>✓ Đã raise (${raisedList.reduce((sum, group) => sum + group.rows.length, 0)} đơn)</summary>${raisedRows(raisedList)}</details>` : '';
    $c('crGroups').innerHTML = rows + more + empty + raisedBox;
    $c('crGroups').querySelector('.cr-raised-box')?.addEventListener('toggle', event => { view.raisedOpen = event.target.open; });

    const selected = all.filter(group => group.selected !== false).length;
    $c('crTabRaise').textContent = all.length ? String(all.length) : '';
    const raisedOrders = channelGroups(settings.channel).filter(group => group.ticketId).reduce((sum, group) => sum + group.rows.length, 0);
    const pendingOrders = all.reduce((sum, group) => sum + group.rows.length, 0);
    const pct = pendingOrders + raisedOrders ? Math.round(raisedOrders * 100 / (pendingOrders + raisedOrders)) : 0;
    $c('crKpis').innerHTML = settings.channel ? `<div class="cr-stat idle"><b>${pendingOrders}</b><span>Còn raise</span></div><div class="cr-stat ok"><b>${raisedOrders}</b><span>Đã raise</span></div><div class="cr-stat run"><b>${pct}%</b><span>Tiến độ</span><i class="cr-bar"><i style="width:${pct}%"></i></i></div>` : '';
    $c('crCount').textContent = all.length ? `Đã chọn ${selected}/${all.length} đơn${view.q ? ` · khớp tìm: ${list.length}` : ''}` : '';
    const bound = boundShop(settings.channel);
    const why = startBlockReason(all, selected);
    $c('crStart').disabled = Boolean(why);
    $c('crStartWhy').textContent = why && all.length ? `Chưa raise được: ${why}` : '';
    const unit = all.some(group => group.rows.length > 1) ? 'ticket' : 'đơn';
    // v2.2.86 — nút Raise ngắn, rõ số lượng + ước lượng thời gian (fast mode ~15s, thường ~30s/đơn).
    const fast = !isShopee() && settings.fastMode === true && settings.parallelReply !== false && selected > 1;
    const eta = selected ? Math.max(1, Math.round(selected * (fast ? 15 : 30) / 60)) : 0;
    $c('crStart').textContent = selected ? `${bound ? '🚀 Raise' : '🔗 Gắn shop & Raise'} ${selected} ${unit}${fast ? ' ⚡' : ''} · ~${eta >= 60 ? `${Math.floor(eta / 60)}h${String(eta % 60).padStart(2, '0')}` : `${eta} phút`}` : 'Chọn đơn để raise';
  }
  /* v2.2.87 — ĐO TỪNG BƯỚC: trung bình giây của từng bước (các đơn gần nhất có đủ mốc) + bước chậm nhất. */
  const STEP_DEFS = [
    ['Chuyển đơn', t => t.prevSaved && t.prevSaved < t.open && t.open - t.prevSaved < 600000 ? t.open - t.prevSaved : null, 'lưu ID đơn trước → mở form đơn này (đọc shop, tải biên bản)'],
    ['Mở form', t => t.ctx - t.open, 'tải trang tạo phiếu TikTok → tool nhận việc'],
    ['Đọc shop', t => t.shop - t.ctx, 'chờ tên shop hiện trên trang để chống raise nhầm shop'],
    ['Chủ đề', t => t.subject - t.shop, 'mở menu + chọn 3 tầng chủ đề'],
    ['Điền', t => t.fill - t.subject, 'mô tả + Order ID'],
    ['Tải file', t => t.upload - t.fill, 'đẩy biên bản PDF + chờ TikTok tải xong'],
    ['Kiểm file', t => t.verify - t.upload, 'xác nhận file đã gắn vào phiếu trước Gửi'],
    ['Gửi', t => t.submit - t.verify, 'bấm Gửi → Tiếp theo → TikTok nhận'],
    ['Lưu ID', t => t.saved - t.submit, 'bắt Ticket ID + ghi Ticket Master']
  ];
  function renderSteps() {
    const box = $c('crStepsBox'); if (!box) return;
    const rows = Object.values(run?.timings || {}).filter(t => t.open && t.saved).sort((a, b) => b.open - a.open).slice(0, 10);
    box.hidden = !rows.length;
    if (!rows.length) return;
    const stats = STEP_DEFS.map(([label, fn, hint]) => {
      const values = rows.map(t => { try { const v = fn(t); return Number.isFinite(v) && v >= 0 ? v : null; } catch (_) { return null; } }).filter(v => v != null);
      return { label, hint, avg: values.length ? values.reduce((s, v) => s + v, 0) / values.length / 1000 : null, max: values.length ? Math.max(...values) / 1000 : null };
    }).filter(item => item.avg != null);
    const total = rows.map(t => (t.saved - t.open) / 1000);
    const slow = stats.reduce((top, item) => !top || item.avg > top.avg ? item : top, null);
    const scale = Math.max(...stats.map(item => item.avg), 1);
    $c('crStepsTitle').textContent = `⏱ Thời gian từng bước · TB ${Math.round(total.reduce((s, v) => s + v, 0) / total.length)}s/form (${rows.length} đơn) · chậm nhất: ${slow?.label} ~${slow?.avg.toFixed(1)}s`;
    $c('crSteps').innerHTML = stats.map(item => `<div class="cr-step${item === slow ? ' slow' : ''}" title="${esc(item.hint)} · lâu nhất ${item.max.toFixed(1)}s"><span>${esc(item.label)}</span><i><b style="width:${Math.max(3, Math.round(item.avg * 100 / scale))}%"></b></i><em>${item.avg.toFixed(1)}s</em></div>`).join('');
  }
  // v2.2.50 — tốc độ đo thật: trung bình giây/đơn (mở form → lưu Ticket ID) của các đơn gần nhất + thời gian còn lại.
  function speedNote() {
    const list = (run?.durations || []).slice(-15);
    // v2.2.88 — chưa có đơn xong: vẫn nói lý do bỏ qua gần nhất (chi tiết ở mục "⚠ Đơn bị bỏ qua").
    if (!list.length) return `${run?.skipped?.length ? ` · ⚠ bỏ qua ${run.skipped.length} đơn lỗi (vd ${run.skipped.at(-1).orderId}: ${String(run.skipped.at(-1).error || '').slice(0, 80)})` : ''} · chưa xong đơn nào nên chưa đo được tốc độ`;
    // v2.2.82 — 2 làn song song: tốc độ thật = khoảng cách giữa các lần lưu Ticket ID (không phải thời gian 1 form).
    const times = (run?.recordTimes || []).slice(-12).map(value => Date.parse(value)).filter(Number.isFinite);
    const throughput = run?.laneB && times.length >= 3 ? (times.at(-1) - times[0]) / 1000 / (times.length - 1) : 0;
    const avg = throughput || list.reduce((sum, value) => sum + value, 0) / list.length;
    const left = Math.round(avg * (run.pending?.length || 0) / 60);
    const skipped = run?.skipped?.length ? ` · bỏ qua ${run.skipped.length} đơn lỗi (vd ${run.skipped.at(-1).orderId}: ${run.skipped.at(-1).error.slice(0, 80)})` : '';
    const lane = follow?.lane && !follow.doneAt ? ` · tin bổ sung chạy song song (chờ ${(follow.queue || []).length + (follow.active ? 1 : 0)})` : '';
    const fast = run?.laneB ? (run.laneB.on ? ` · ⚡ 2 tab (làn 2 xong ${run.laneB.done || 0} đơn${throughput ? `, mỗi form ~${Math.round(list.reduce((s, v) => s + v, 0) / list.length)} giây` : ''})` : ` · ⚠ làn 2 đã tắt (${run.laneB.stoppedReason || 'lỗi'}) — chạy 1 tab`) : '';
    return ` · ~${Math.round(avg)} giây/đơn${fast} · còn ≈ ${left >= 60 ? `${Math.floor(left / 60)} giờ ${left % 60} phút` : `${left} phút`}${lane}${skipped}`;
  }
  function renderRun() {
    try { renderSteps(); } catch (_) {}
    try { renderLive(); } catch (_) {}
    if (run && !run.doneAt && run.paused && !run.activeKey && run.channel !== settings.channel) {
      $c('crPause').hidden = true; $c('crResume').hidden = true; $c('crSkipReply').hidden = true;
      status(`Hàng đợi ${run.channel} đang tạm dừng${run.error ? ` (${run.error.slice(0, 120)})` : ''}. Raise channel này sẽ gác hàng đợi đó lại; phiếu đã raise vẫn ở thẻ Theo dõi.`);
      return;
    }
    const mine = run && !run.doneAt;
    $c('crPause').hidden = !mine || run.paused;
    $c('crStopNow').hidden = !(running() || (lookup && !lookup.doneAt));
    const uploadRetry = Boolean(mine && run.activeKey && formFailed(run.activeKey));
    const captureRetry = uploadRetry && openGroups[run.activeKey]?.autofill?.reason === 'ticket-list-not-ready';
    $c('crResume').hidden = !uploadRetry && (!mine || !run.paused || Boolean(run.activeKey));
    // v2.2.40 — kẹt ở bước phản hồi lại phiếu vừa raise → cho bỏ qua (phiếu đã có biên bản ở tin đầu) để raise đơn kế.
    $c('crSkipReply').hidden = !(mine && run.paused && run.awaitingReply && !run.activeKey);
    $c('crResume').textContent = captureRetry ? 'Thử lại tìm phiếu' : uploadRetry ? 'Thử lại đính kèm' : 'Tiếp tục';
    // v2.2.82 — tốc độ cả lượt = (lưu Ticket ID cuối − bắt đầu) / số đơn (đúng cả khi chạy 2 làn).
    const doneSec = run?.doneAt && run.raisedCount ? Math.round((Date.parse(run.recordTimes?.at(-1) || run.doneAt) - Date.parse(run.startedAt)) / 1000 / run.raisedCount) : 0;
    if (!mine) { if (run?.doneAt && shown && !$c('crStatus').classList.contains('error')) status(`✓ Đã raise ${run.raisedCount || ''} đơn cho ${run.channel}${doneSec > 0 ? ` (~${doneSec} giây/đơn${run.laneB ? ' · ⚡ 2 tab' : ''})` : (run.durations || []).length ? ` (~${Math.round(run.durations.reduce((s, v) => s + v, 0) / run.durations.length)} giây/đơn)` : ''}${follow?.lane && !follow.doneAt ? ` · còn ${(follow.queue || []).length + (follow.active ? 1 : 0)} tin bổ sung đang gửi song song` : ' · đã gửi tin bổ sung từng phiếu'}${run.skipped?.length ? ` · ⚠ bỏ qua ${run.skipped.length} đơn lỗi — ${run.skipped.at(-1).orderId}: ${String(run.skipped.at(-1).error || "").slice(0, 160)} (đơn vẫn trong danh sách Raise để thử lại)` : ''}.${run.lastReplyError ? ` ⚠ ${run.lastReplyError}` : ''} Theo dõi phiếu ở mục bên dưới.`, run.lastReplyError ? 'error' : 'ok'); return; }
    if (captureRetry) status('Đã gửi · chưa bấm xong Tất cả để bắt Ticket ID. Tool đang tự thử lại; có thể bấm Thử lại tìm phiếu (không gửi lại ticket).', 'error');
    else if (uploadRetry) status(` → Bấm Thử lại đính kèm (tải lại form, dùng file đã lưu).`, 'error');
    else if (run.error) status(run.error, 'error');
    else if (run.awaitingReply) status(`Đã raise phiếu #${run.awaitingReply.ticketId} · bấm Tất cả → tìm đúng phiếu → điền lại nội dung + đính kèm lại file → Gửi · còn ${run.pending.length} ĐVVC chờ.`, 'running');
    else if (run.paused) status(run.activeKey ? 'Đã chọn dừng — ticket hiện tại vẫn hoàn tất.' : `Tạm dừng · còn ${run.pending.length} ticket.`);
    else status(`Đang raise ${run.channel} · còn ${run.pending.length} đơn${speedNote()}.`, 'running');
  }
  const ago = iso => { if (!iso || !Number.isFinite(Date.parse(iso))) return ''; const days = Math.floor((Date.now() - Date.parse(iso)) / 86400000); return days <= 0 ? 'hôm nay' : `${days} ngày trước`; };
  // v2.2.45 — Theo dõi: mỗi phiếu 1 dòng (chấm màu trạng thái + nhãn), lọc nhanh, bấm ▾ mới hiện chi tiết & thao tác.
  const VERDICT_TONE = { ok: 'ok', bad: 'warn', warn: 'warn', run: 'run', idle: 'idle' };
  // v2.2.72 — "Cần có hành động của bạn": còn bao lâu trước khi TikTok tự đóng (24 giờ sau tin yêu cầu).
  const leftText = ms => { if (!ms) return ''; const left = ms - Date.now(); if (left <= 0) return 'quá hạn 24h'; const h = Math.floor(left / 3600000); return h ? `còn ${h}h${String(Math.floor(left % 3600000 / 60000)).padStart(2, '0')}` : `còn ${Math.max(1, Math.floor(left / 60000))} phút`; };
  // v2.2.74 — phản hồi TikTok đã phân loại (bồi thường / đã hoàn / từ chối / cần bổ sung / đang xử lý…).
  const ttReply = ticket => ticket.platform !== 'shopee' && ticket.tiktok?.reply && ticket.tiktok.reply.verdict !== 'none' ? ticket.tiktok.reply : null;
  const ticketTone = ticket => ticket.finished ? 'ok' : ticket.reraisedTo ? 'idle' : CR.ttActionOpen(ticket) || CR.ttRebutOpen(ticket) || CR.ttNeedsNewTicket(ticket) ? 'warn' : ticket.shopee?.tone ? VERDICT_TONE[ticket.shopee.tone] : ttReply(ticket) && ['ok', 'bad'].includes(ttReply(ticket).tone) ? VERDICT_TONE[ttReply(ticket).tone] : CR.isClosedStatus(ticket.lastStatus) ? 'warn' : /xử lý|processing/i.test(ticket.lastStatus || '') ? 'run' : 'idle';
  // v2.2.83 — phiếu raise lại đã tạo ở thẻ Raise nhưng chưa có Ticket ID (đang chạy / bị bỏ qua) → nói rõ, không báo "cần raise lại" chung chung.
  const reraiseGroupOf = ticket => Object.values(groups).find(group => String(group.reraiseOf?.ticketId || '') === String(ticket.TicketID) && !group.ticketId);
  const reraiseState = ticket => {
    const group = reraiseGroupOf(ticket);
    if (!group) return '';
    const skipped = (run?.skipped || []).filter(item => item.groupId === group.id).at(-1);
    const busy = run && !run.doneAt && (run.activeKey === CR.groupKey(group.id) || run.laneB?.activeKey === CR.groupKey(group.id));
    return skipped ? `✖ Raise lại lỗi: ${skipped.error.slice(0, 60)}` : busy ? '⏳ Đang raise lại…' : run && !run.doneAt && (run.pending || []).includes(group.id) ? '⏳ Raise lại đang chờ lượt' : '⏳ Đã tạo raise lại — chưa gửi (thẻ Raise)';
  };
  const ticketLabel = ticket => ticket.finished ? 'Đã nhận hàng' : ticket.reraisedTo ? (/^\d+$/.test(String(ticket.reraisedTo)) ? `Đã raise lại → #${String(ticket.reraisedTo).slice(-6)}` : 'Đã raise lại (tay)') : CR.ttActionOpen(ticket) ? `⚡ Cần hành động · ${leftText(CR.ttDeadline(ticket))}` : CR.ttRebutOpen(ticket) ? `⚖ Cần phản biện · ${ttReply(ticket)?.label || ticket.lastStatus}` : CR.ttNeedsNewTicket(ticket) ? reraiseState(ticket) || 'Đã đóng — raise lại phiếu mới' : ticket.shopee?.label ? ticket.shopee.label
    : ttReply(ticket) ? `${ttReply(ticket).label}${ttReply(ticket).shopLast ? ' · chờ TikTok' : ''}` : ticket.lastStatus && ticket.lastStatus !== 'Submitted' ? ticket.lastStatus : 'Đã gửi';
  const TICKET_FILTERS = {
    all: { label: 'Tất cả', test: () => true },
    action: { label: '⚡ Cần hành động', test: ticket => CR.ttActionOpen(ticket) },
    rebut: { label: '⚖ Cần phản biện', test: ticket => CR.ttRebutOpen(ticket) },
    // v2.2.85 — dấu "Đã theo dõi" hiệu lực 24 giờ.
    unfollowed: { label: 'Chưa theo dõi (24h)', test: ticket => !ticket.finished && !ticket.reraisedTo && !CR.followedRecently(ticket) },
    followed: { label: '✓ Đã theo dõi (24h)', test: ticket => CR.followedRecently(ticket) },
    ttnew: { label: 'TikTok trả lời mới', test: ticket => Boolean(ttReply(ticket)) && (tikTokScan?.fresh || []).includes(String(ticket.TicketID)) },
    ttlose: { label: 'TikTok từ chối', test: ticket => !ticket.finished && ttReply(ticket)?.verdict === 'lose' },
    ttgood: { label: 'Bồi thường / đã hoàn', test: ticket => !ticket.finished && ['win', 'returned'].includes(ttReply(ticket)?.verdict) },
    closed: { label: 'Cần mở lại', test: ticket => ticket.platform !== 'shopee' && !ticket.finished && CR.isClosedStatus(ticket.lastStatus) },
    reraise: { label: 'Cần raise lại', test: ticket => CR.needsReraise(ticket) },
    need: { label: 'Shopee cần bổ sung', test: ticket => !ticket.finished && ['need', 'returned'].includes(ticket.shopee?.verdict) },
    tracker: { label: 'Lỗi tracker', test: ticket => Boolean(ticket.trackerError) },
    shop: { label: 'Shop đang login', test: ticket => Boolean(shopName) && ticket.shopName === shopName },
    returns: { label: 'Đòi hàng', test: ticket => ticket.kind !== 'general' },
    other: { label: 'Loại khác', test: ticket => ticket.kind === 'general' }
  };
  const ticketType = ticket => ticket.kind === 'general' ? CR.issueLabel(ticket.issueType) : 'Đòi hàng';
  /* v2.2.71 — kết quả đọc từ nội dung phiếu Shopee: Thắng / Thua / Shopee báo đã hoàn / Shopee cần bổ sung / Đang chờ. */
  function shopeeBox(ticket) {
    const s = ticket.shopee;
    if (!s) return '<div class="data-note">Chưa đọc nội dung phiếu — bấm <b>Kiểm tra phản hồi</b> để xem Shopee trả lời gì (thắng / thua / cần bổ sung).</div>';
    const replies = (s.messages || []).filter(m => !m.inbound && m.text).slice(-3);
    return `<div class="data-note${s.tone === 'ok' ? '' : ' cr-why'}"><b>Kết quả: ${esc(s.label)}</b>${s.status ? ` · phiếu ${esc(CR.shopeeCaseStatus(s.status))}` : ''}${Number(s.remainingReply) > 0 ? ` · còn ${s.remainingReply} lượt trả lời trên phiếu (có thể bấm Trả lời ở trang phiếu)` : s.remainingReply === 0 ? ' · hết lượt trả lời — phiếu đóng thì raise lại = phiếu mới' : ''}${s.checkedAt ? ` · đọc ${esc(ago(s.checkedAt))}` : ''}
      ${s.need ? `<br>👉 Cần làm: ${esc(s.need)}` : ''}
      ${(s.links || []).length ? `<br>${s.links.map(link => `<a class="link-btn" href="${esc(link)}" target="_blank" rel="noopener">Hướng dẫn / link Shopee ↗</a>`).join(' ')}` : ''}</div>
      ${replies.length ? `<details class="handover-extra"${CR.needsReraise(ticket) ? ' open' : ''}><summary>Shopee phản hồi (${s.replies || replies.length} tin)</summary>${replies.map(m => `<div class="data-note"><b>${esc(CR.vnTime(m.at))}</b><br>${esc(CR.replyGist(m.text, 700))}</div>`).join('')}</details>` : ''}`;
  }
  /* v2.2.72 — TikTok: điều TikTok vừa yêu cầu (tin cuối) + hạn trả lời + nội dung sẽ gửi khi re-raise. */
  function tiktokBox(ticket) {
    const t = ticket.tiktok;
    if (!t) return '<div class="data-note">Chưa đọc phản hồi TikTok — bấm <b>Quét phiếu TikTok</b>.</div>';
    const r = t.reply;
    const verdict = r && r.verdict !== 'none' ? `<div class="data-note${['bad', 'warn'].includes(r.tone) ? ' cr-why' : ''}"><b>Phản hồi: ${esc(r.label)}</b>${r.at ? ` · ${esc(CR.vnTime(r.at))}` : ''}${r.shopLast ? ' · shop đã trả lời sau, chờ TikTok' : ''} · ${r.replies} tin TikTok
      ${r.gist ? `<br>${esc(r.gist)}` : ''}${r.need ? `<br>👉 ${esc(r.need)}` : ''}</div>` : r ? '<div class="data-note">TikTok chưa phản hồi phiếu này.</div>' : '';
    const thread = (t.messages || []).length ? `<details class="handover-extra"${CR.ttActionOpen(ticket) ? ' open' : ''}><summary>Luồng phiếu (${t.messages.length} tin gần nhất)</summary>${t.messages.map(m => `<div class="data-note"><b>${m.agent ? 'TikTok' : 'Shop'} · ${esc(CR.vnTime(m.at))}</b><br>${esc(CR.replyGist(m.text, 700))}</div>`).join('')}</details>` : '';
    const ask = thread || (t.lastFromAgent && t.lastText ? `<details class="handover-extra"${CR.ttActionOpen(ticket) ? ' open' : ''}><summary>TikTok nhắn ${esc(CR.vnTime(t.lastAt))}</summary><div class="data-note">${esc(CR.replyGist(t.lastText, 700))}</div></details>` : '');
    const head = CR.ttActionOpen(ticket) ? `<b>⚡ Cần có hành động của bạn</b> · hạn ${esc(CR.vnTime(new Date(CR.ttDeadline(ticket)).toISOString()))} (${esc(leftText(CR.ttDeadline(ticket)))})`
      : CR.ttRebutOpen(ticket) ? `<b>⚖ Cần phản biện</b> — phiếu ${esc(t.label || ticket.lastStatus || '')} nhưng TikTok ${r?.verdict === 'deflect' ? 'trả lời lệch vấn đề' : r?.verdict === 'lose' ? 'từ chối' : r?.verdict === 'returned' ? 'báo "đã chuyển hoàn" trong khi tracker kho vẫn ghi Đã bàn giao ĐVVC (chưa nhận) → đòi bằng chứng giao hoàn' : 'chưa xử lý đúng vấn đề'}${ticket.rebutCount ? ` · đã phản biện ${ticket.rebutCount} lần` : ''}.`
      : CR.ttNeedsNewTicket(ticket) ? `<b>✖ Đã đóng sau khi TikTok yêu cầu bằng chứng</b> — không trả lời được nữa, ${ticket.kind === 'general' ? 'raise lại tay trên TikTok' : 'bấm Raise lại (phiếu mới)'}.`
      : `TikTok: ${esc(t.label || ticket.lastStatus || '')}${ticket.evidenceReplyAt ? ` · đã bổ sung bằng chứng ${esc(ago(ticket.evidenceReplyAt))}` : ''}`;
    const plan = CR.ttActionOpen(ticket) ? `<details class="handover-extra"><summary>Nội dung sẽ gửi</summary><div class="data-note" style="white-space:pre-wrap">${esc(ticket.actionPlan?.text || CR.actionReplyText(ticket))}</div></details>`
      // v2.2.75 — phản biện: sửa được nội dung trước khi gửi (lưu theo phiếu; xóa trống = tự soạn lại).
      : CR.ttRebutOpen(ticket) ? `<details class="handover-extra" open><summary>Nội dung phản biện (sửa được, ≤500 ký tự)</summary><textarea data-cr-rebut-text rows="6" maxlength="500">${esc(ticket.rebutDraft || CR.rebuttalText(ticket))}</textarea></details>` : '';
    return `<div class="data-note${CR.ttActionOpen(ticket) || CR.ttNeedsNewTicket(ticket) ? ' cr-why' : ''}">${head}${t.scannedAt ? ` · quét ${esc(ago(t.scannedAt))}` : ''}</div>${verdict}${ask}${plan}`;
  }
  /** Raise lại = phiếu MỚI (Shopee không mở lại phiếu đã giải quyết; v2.2.72 — TikTok đã đóng phiếu "Cần hành động" sau 24 giờ):
      tạo ticket ở thẻ Raise, cùng đơn, nội dung dẫn chiếu phiếu cũ. */
  async function createReraise(ticket) {
    const plat = ticket.platform === 'shopee' ? 'shopee' : 'tiktok';
    if (plat === 'tiktok' && (ticket.kind === 'general' || !ticket.channel)) throw new Error(`Phiếu #${ticket.TicketID} không phải phiếu Đòi hàng của tool (thiếu channel) — raise lại tay trên TikTok.`);
    const src = Object.values(groups).find(group => group.ticketId === ticket.TicketID);
    const links = CR.evidenceLinks(`${ticket.replyText || ''}\n${ticket.tiktok?.context || ''}`).filter(link => !/tiktok\.com/i.test(link)).slice(0, 2);
    // v2.2.81 — STT biên bản lấy lại từ tin bổ sung bằng chứng của phiếu cũ (phiếu lấy từ tracker không có nhóm đơn ở Chrome này).
    const sequence = (String(ticket.replyText || ticket.tiktok?.context || '').match(/STT(?:\s*trong biên bản(?: bàn giao)?)?\s*:?\s*(\d{1,5})/i) || [])[1] || '';
    const rows = src?.rows || (ticket.orderIds || []).map((orderId, index) => ({ orderId, platform: plat, orderNo: ticket.orderNos?.[index] || '', trackingId: ticket.trackingIds?.[index] || '', channel: ticket.channel, carrier: ticket.carrier, warehouse: ticket.warehouse, evidence: links, sequence: index === 0 ? sequence : '' }));
    if (!rows.length) throw new Error('Phiếu không còn danh sách đơn để raise lại.');
    const id = `${src?.id || `${CR.fold(ticket.channel)}|${CR.fold(ticket.carrier)}|${rows[0].orderId}`}|re${ticket.TicketID}`;
    if (groups[id] && !groups[id].ticketId) return groups[id];
    const s = ticket.shopee || {};
    const group = { ...(src || {}), id, platform: plat, channel: src?.channel || ticket.channel, channelCode: src?.channelCode || '', carrier: src?.carrier || ticket.carrier, warehouse: src?.warehouse || ticket.warehouse,
      rows, files: [], filesTried: false, evidenceNote: '', textOverride: '', selected: true, ticketId: '', ticketRecordedAt: '',
      reraiseOf: { ticketId: ticket.TicketID, verdict: s.verdict || '', gist: s.gist || '', need: s.need || '', at: new Date().toISOString() } };
    groups[id] = group;
    return group;
  }
  async function reraiseTickets(list) {
    const made = [];
    for (const ticket of list) made.push(await createReraise(ticket));
    await save({ cancelReturnGroups: groups });
    const channel = made[0]?.channel;
    if (channel) { settings.channel = channel; settings.tab = 'raise'; await save({ cancelReturnSettings: settings }); }
    render();
    status(`Đã tạo ${made.length} ticket raise lại (phiếu mới, dẫn chiếu phiếu cũ${made.some(group => group.platform === 'shopee') ? ' + trả lời đúng điều Shopee nói' : ' + biên bản bàn giao'}) ở thẻ Raise — xem/sửa nội dung rồi bấm Raise.`, 'ok');
    return made;
  }
  // v2.2.49 — kéo mọi phiếu TikTok trong Ticket Master (pickup, kháng nghị, khiếu nại KPI…) vào Theo dõi để mở lại khi bị đóng.
  let syncedAt = 0;
  async function syncAllTikTokTickets(force = false) {
    if (!force && Date.now() - syncedAt < 120000) return null;
    syncedAt = Date.now();
    const result = await sendRuntimeMessage({ type: 'SYNC_TIKTOK_FOLLOW_TICKETS' }).catch(() => null);
    return result;
  }
  /* v2.2.77 — "Store cần kiểm tra": channel raise xong bị ẩn ở thẻ Raise nên không biết vào store nào để kiểm tra phiếu.
     Gom phiếu đang theo dõi theo shop đã raise (tên shop TikTok lúc raise) → việc cần làm + lần quét gần nhất;
     store có việc / lâu chưa quét lên đầu; bấm 1 store → danh sách chỉ còn phiếu của store đó. */
  const shopKey = ticket => String(ticket.shopName || '').trim() || '(chưa rõ shop)';
  /* v2.2.85 — nút "Đã theo dõi" trên dòng phiếu: bấm để đánh dấu / bỏ dấu; hết hiệu lực sau 24 giờ. */
  function followChip(ticket) {
    if (ticket.finished) return '';
    const left = CR.followLeftMs(ticket);
    if (!left) return `<button type="button" class="cr-follow" data-cr-followed="1" title="Đánh dấu đã theo dõi lại phiếu này (hiệu lực 24 giờ)">☐ Theo dõi</button>`;
    const by = ticket.followedBy === 'tool' ? 'tool gửi tin trên phiếu' : 'đánh dấu tay';
    return `<button type="button" class="cr-follow on" data-cr-followed="0" title="Đã theo dõi lúc ${esc(CR.vnTime(ticket.followedAt))} (${by}) · còn ${Math.ceil(left / 3600000)} giờ · bấm để bỏ dấu">✓ ${esc(CR.vnTime(ticket.followedAt).slice(11))} · còn ${Math.ceil(left / 3600000)}h</button>`;
  }
  function renderShopBoard() {
    const box = $c('crShopBoard'); if (!box) return;
    const shops = new Map();
    for (const ticket of Object.values(tickets)) {
      if (!ofPlatform(ticket) || ticket.platform === 'shopee' || ticket.finished) continue;
      const key = shopKey(ticket);
      const s = shops.get(key) || { name: key, total: 0, action: 0, rebut: 0, fresh: 0, unscanned: 0, lastScan: '', channels: new Set(), deadline: 0, followed: 0 };
      s.total++;
      if (CR.followedRecently(ticket)) s.followed++;
      if (ticket.channel) s.channels.add(ticket.channel);
      if (CR.ttActionOpen(ticket)) { s.action++; const d = CR.ttDeadline(ticket); if (d && (!s.deadline || d < s.deadline)) s.deadline = d; }
      if (CR.ttRebutOpen(ticket)) s.rebut++;
      if (CR.ttNeedsNewTicket(ticket) && !reraiseGroupOf(ticket)) s.fresh++;
      if (!ticket.tiktok?.scannedAt) s.unscanned++;
      else if (ticket.tiktok.scannedAt > s.lastScan) s.lastScan = ticket.tiktok.scannedAt;
      shops.set(key, s);
    }
    for (const [channel, name] of Object.entries(shopMap || {})) { const s = shops.get(name); if (s) s.channels.add(channel); }
    const list = [...shops.values()].map(s => ({ ...s, todo: s.action + s.rebut + s.fresh }))
      .sort((a, b) => (b.action - a.action) || (b.todo - a.todo) || (b.unscanned - a.unscanned) || String(a.lastScan).localeCompare(String(b.lastScan)) || a.name.localeCompare(b.name));
    if (view.shop && !shops.has(view.shop)) view.shop = '';
    const todoShops = list.filter(s => s.todo || s.unscanned).length;
    $c('crShopBoardTitle').textContent = `Store cần kiểm tra (${list.length} store${todoShops ? ` · ${todoShops} có việc / chưa quét` : ''})${view.shop ? ` · đang lọc: ${view.shop}` : ''}`;
    // v2.2.80 — đang lọc 1 store: chỉ hiện store đó (14 store kia đẩy danh sách phiếu xuống tận cuối, tưởng không mở được).
    const visible = view.shop ? list.filter(s => s.name === view.shop) : list;
    box.innerHTML = list.length ? visible.map(s => {
      const tags = [s.action ? `<span class="cr-chip warn">⚡ ${s.action}</span>` : '', s.rebut ? `<span class="cr-chip warn">⚖ ${s.rebut}</span>` : '', s.fresh ? `<span class="cr-chip warn">✖ raise lại ${s.fresh}</span>` : '',
        s.unscanned ? `<span class="cr-chip">chưa quét ${s.unscanned}</span>` : ''].join('');
      const here = shopName && s.name === shopName;
      return `<button type="button" class="cr-shop${s.todo ? ' todo' : ''}${here ? ' here' : ''}${view.shop === s.name ? ' active' : ''}" data-cr-shop="${esc(s.name)}" title="Bấm để chỉ xem phiếu của store này; đăng nhập đúng store trên TikTok rồi bấm Quét phiếu TikTok">
        <b>${here ? '● ' : ''}${esc(s.name)}</b><span class="cr-shop-tags">${tags || '<span class="cr-chip ok">✓ không có việc</span>'}</span>
        <small>${s.total} phiếu · đã theo dõi 24h ${s.followed}/${s.total}${s.channels.size ? ` · ${esc([...s.channels].join(', '))}` : ''} · ${s.lastScan ? `quét ${esc(ago(s.lastScan))}` : 'chưa quét lần nào'}${s.deadline ? ` · hạn gần nhất ${esc(leftText(s.deadline))}` : ''}${here ? ' · đang đăng nhập' : ''}</small></button>`;
    }).join('') + (view.shop ? `<button type="button" class="link-btn" data-cr-shop="">← Xem cả ${list.length} store</button>` : '')
      : '<div class="data-note">Chưa có phiếu TikTok nào đang theo dõi.</div>';
  }
  $c('crShopBoard').addEventListener('click', event => {
    const button = event.target.closest('[data-cr-shop]'); if (!button) return;
    const name = button.dataset.crShop;
    view.shop = view.shop === name ? '' : name; view.ticketLimit = PAGE;
    if (view.shop) {
      // v2.2.80 — mở sẵn phiếu cần làm đầu tiên của store (Cần hành động > phản biện > raise lại), bộ lọc về Tất cả nếu lọc cũ trống.
      const mine = Object.values(tickets).filter(ticket => ofPlatform(ticket) && !ticket.finished && shopKey(ticket) === view.shop);
      const first = mine.find(CR.ttActionOpen) || mine.find(CR.ttRebutOpen) || mine.find(CR.ttNeedsNewTicket);
      if (!mine.some(TICKET_FILTERS[view.ticketFilter]?.test || (() => true))) view.ticketFilter = 'all';
      if (first) { view.ticketOpen = String(first.TicketID); if (!TICKET_FILTERS[view.ticketFilter].test(first)) view.ticketFilter = 'all'; }
    }
    renderTickets();
    if (view.shop) setTimeout(() => ($c('crTickets').querySelector('.cr-row.open') || $c('crTicketFilter')).scrollIntoView({ block: 'start', behavior: 'smooth' }), 50);
    if (view.shop && shopName && view.shop !== shopName) followStatus(`Đang xem phiếu của store "${view.shop}". Để quét / re-raise: đổi sang store này trên TikTok Seller Center rồi bấm Quét phiếu TikTok (đang đăng nhập: ${shopName}).`, 'running');
  });
  // v2.2.80 — link trong khung cảnh báo: lọc đúng nhóm, mở phiếu đầu tiên và cuộn tới.
  $c('crActionAlert').addEventListener('click', event => {
    const link = event.target.closest('[data-cr-goto]'); if (!link) return;
    const filter = link.dataset.crGoto;
    view.ticketFilter = filter; view.ticketLimit = PAGE;
    const first = Object.values(tickets).filter(ticket => ofPlatform(ticket) && (!view.shop || shopKey(ticket) === view.shop)).find(TICKET_FILTERS[filter].test);
    if (!first) view.shop = '';
    view.ticketOpen = String((first || Object.values(tickets).find(TICKET_FILTERS[filter].test))?.TicketID || '');
    renderTickets();
    setTimeout(() => ($c('crTickets').querySelector('.cr-row.open') || $c('crTicketFilter')).scrollIntoView({ block: 'start', behavior: 'smooth' }), 50);
  });
  function renderTickets() {
    const showAll = $c('crShowFinished').checked;
    renderShopBoard();
    const base = Object.values(tickets).filter(ticket => ofPlatform(ticket) && (showAll || !ticket.finished) && (!view.shop || shopKey(ticket) === view.shop)).sort((a, b) => String(b.recordedAt).localeCompare(String(a.recordedAt)));
    const filter = TICKET_FILTERS[view.ticketFilter] ? view.ticketFilter : 'all';
    // v2.2.72 — phiếu Cần hành động luôn lên đầu, hạn 24 giờ gần nhất trước.
    const urgency = ticket => CR.ttActionOpen(ticket) ? CR.ttDeadline(ticket) || 1 : CR.ttRebutOpen(ticket) ? Number.MAX_SAFE_INTEGER : Infinity;
    const rebutList = Object.values(tickets).filter(ticket => ofPlatform(ticket) && CR.ttRebutOpen(ticket));
    if ($c('crRebutAll')) { $c('crRebutAll').textContent = `Phản biện phiếu giải quyết sai${rebutList.length ? ` (${rebutList.length})` : ''}`; $c('crRebutAll').disabled = !rebutList.length || Boolean(follow && !follow.doneAt); }
    const list = base.filter(TICKET_FILTERS[filter].test).sort((a, b) => urgency(a) - urgency(b));
    // v2.2.85 — tiến độ theo dõi trong 24 giờ của danh sách đang hiện + đánh dấu hàng loạt.
    const openShown = list.filter(ticket => !ticket.finished && !ticket.reraisedTo);
    const bulkIds = openShown.filter(ticket => !CR.followedRecently(ticket)).map(ticket => String(ticket.TicketID));
    $c('crFollowBulk').innerHTML = openShown.length ? `<span class="data-note">Đã theo dõi (24h): <b>${openShown.length - bulkIds.length}/${openShown.length}</b> phiếu đang hiện</span>${bulkIds.length ? ` <button type="button" class="link-btn" data-cr-follow-bulk="${esc(bulkIds.join(','))}">✓ Đánh dấu ${bulkIds.length} phiếu còn lại</button>` : ' ✓'}` : '';
    const actionList = Object.values(tickets).filter(ticket => ofPlatform(ticket) && CR.ttActionOpen(ticket)).sort((a, b) => urgency(a) - urgency(b));
    // v2.2.83 — phiếu đã tạo raise lại (đang chờ / đang chạy) không tính là "cần raise lại" nữa.
    const newList = Object.values(tickets).filter(ticket => ofPlatform(ticket) && CR.ttNeedsNewTicket(ticket) && !reraiseGroupOf(ticket));
    // v2.2.81 — Raise lại tất cả phiếu đã đóng của shop đang đăng nhập (raise cần đúng shop).
    if ($c('crReraiseAllTT')) {
      const here = newList.filter(ticket => ticket.kind !== 'general' && (!shopName || !ticket.shopName || ticket.shopName === shopName));
      $c('crReraiseAllTT').disabled = !here.length || running();
      $c('crReraiseAllTT').textContent = `Raise lại tất cả phiếu đã đóng${newList.length ? ` (${here.length}${here.length !== newList.length ? `/${newList.length} — shop đang login` : ''})` : ''}`;
    }
    if ($c('crActionReraise')) {
      $c('crActionReraise').textContent = `Re-raise phiếu Cần hành động${actionList.length ? ` (${actionList.length})` : ''}`;
      $c('crActionReraise').disabled = !actionList.length || Boolean(follow && !follow.doneAt);
      const scan = tikTokScan;
      $c('crActionAlert').hidden = !(actionList.length || newList.length || rebutList.length);
      $c('crActionAlert').innerHTML = actionList.length || newList.length || rebutList.length ? `${rebutList.length ? `⚖ <b>${rebutList.length} phiếu giải quyết sai / TikTok trả lời lệch</b> → <button type="button" class="link-btn" data-cr-goto="rebut">mở danh sách Cần phản biện</button>, xem nội dung rồi bấm <b>Phản biện</b>.${actionList.length || newList.length ? '<br>' : ''}` : ''}` : '';
      $c('crActionAlert').innerHTML += actionList.length || newList.length ? `${actionList.length ? `⚡ <b>${actionList.length} phiếu Cần có hành động của bạn</b> — hạn gần nhất #${esc(String(actionList[0].TicketID).slice(-6))} ${esc(leftText(CR.ttDeadline(actionList[0])))} (TikTok tự đóng sau 24 giờ). Bấm <b>Re-raise phiếu Cần hành động</b>.` : ''}${newList.length ? `${actionList.length ? '<br>' : ''}✖ ${newList.length} phiếu đã bị ĐÓNG sau khi TikTok đòi bằng chứng → <button type="button" class="link-btn" data-cr-goto="reraise">mở danh sách Cần raise lại</button> → Raise lại (phiếu mới).` : ''}${scan?.at ? `<br><small>Quét lúc ${esc(CR.vnTime(scan.at))} · ${scan.scanned} phiếu · shop ${esc(scan.shop || '')}</small>` : ''}` : '';
    }
    const trackerErr = Object.values(tickets).find(ticket => ticket.trackerError);
    $c('crTrackerAlert').hidden = !trackerErr;
    // v2.2.31 — kèm link xử lý ngay trên panel: đăng nhập lại SharePoint · trang cấp quyền List · mở List · mở tracker Excel.
    const SP = 'https://onpointvn.sharepoint.com/sites/Operation-LogsTeam';
    const LIST_ID = '%7BA370BB25-B2F8-4EA0-9DC9-5E6B35A3D710%7D';
    const links = [
      [`${SP}/Lists/FG%20Recon%20Tracking/AllItems.aspx`, 'Đăng nhập lại SharePoint / mở List'],
      [`${SP}/_layouts/15/user.aspx?obj=${LIST_ID},list&List=${LIST_ID}`, 'Trang cấp quyền List'],
      [`${SP}/_layouts/15/Doc.aspx?sourcedoc=%7B9B0469AC-99BB-4114-A8AF-024FBC310438%7D&file=FG_Phan_hoi_tong.xlsx&action=default`, 'Mở tracker Excel']
    ];
    $c('crTrackerAlert').innerHTML = trackerErr ? `⚠ Chưa ghi Ticket ID vào tracker: ${esc(trackerErr.trackerError)}<div class="actions">${links.map(([href, text]) => `<a class="link-btn" href="${href}" target="_blank" rel="noopener">${text} ↗</a>`).join('')}</div>` : '';
    $c('crTicketCount').textContent = String(Object.values(tickets).filter(ticket => ofPlatform(ticket) && !ticket.finished).length);
    const reraiseCount = Object.values(tickets).filter(ticket => ticket.platform === 'shopee' && CR.needsReraise(ticket)).length;
    $c('crShopeeReraiseAll').disabled = !reraiseCount; $c('crShopeeReraiseAll').textContent = `Raise lại phiếu chưa thắng${reraiseCount ? ` (${reraiseCount})` : ''}`;
    // v2.2.30 — chưa có phiếu nào được lưu Ticket ID → không có gì để ghi tracker / nhắc phiếu: nói rõ cách xử lý.
    const noTickets = !Object.keys(tickets).length;
    $c('crNoTicketHint').hidden = !noTickets;
    $c('crNoTicketHint').textContent = noTickets ? (isShopee() ? 'Chưa có phiếu Shopee nào được lưu mã. Đã gửi mà tool chưa bắt được mã: xem seller-service.cs.shopee.vn → Yêu cầu của tôi rồi nhập tay mã phiếu ở dòng đơn (thẻ Raise).' : 'Chưa có phiếu nào được lưu Ticket ID. Đơn đã raise mà tool chưa bắt được Ticket ID: mở thẻ Raise → "Dò Ticket ID đã raise trên TikTok" (hoặc nhập tay Ticket ID ở dòng đơn).') : '';
    $c('crTrackerAll').disabled = noTickets; $c('crTrackerExport').disabled = noTickets;
    const busy = Boolean(follow && !follow.doneAt);
    $c('crFollowAll').disabled = busy || !base.some(ticket => !ticket.finished);
    $c('crFollowStop').hidden = !busy;
    const open = Object.values(tickets).filter(ticket => ofPlatform(ticket) && !ticket.finished);
    $c('crTicketStats').innerHTML = [
      isShopee() ? ['idle', 'Lỗi tracker', Object.values(tickets).filter(ticket => ticket.trackerError).length] : ['warn', 'Cần hành động', actionList.length],
      ['run', 'Đang xử lý', open.filter(ticket => ticketTone(ticket) === 'run').length],
      ['warn', 'Cần mở lại / raise lại', open.filter(ticket => ticketTone(ticket) === 'warn' && !CR.ttActionOpen(ticket)).length],
      ['ok', 'Đã nhận hàng', Object.values(tickets).filter(ticket => ticket.finished).length]
    ].map(([tone, label, value]) => `<div class="cr-stat ${tone}"><b>${value}</b><span>${label}</span></div>`).join('');
    $c('crTicketFilter').innerHTML = Object.entries(TICKET_FILTERS).map(([key, item]) => `<button class="cr-pill${key === filter ? ' active' : ''}" data-tf="${key}">${item.label} <span>${base.filter(item.test).length}</span></button>`).join('');
    const shown = list.slice(0, view.ticketLimit);
    // v2.2.80 — 1 phiếu lỗi khi vẽ chi tiết không được làm hỏng cả danh sách (bấm ▾ tưởng không mở được).
    $c('crTickets').innerHTML = shown.map(ticket => { try { return (() => {
      const id = String(ticket.TicketID);
      const tone = ticketTone(ticket);
      const expanded = view.ticketOpen === id;
      const last = (ticket.followUps || []).slice(-1)[0];
      const orders = ticket.orderIds || [];
      const general = ticket.kind === 'general';
      const tracker = general ? '' : ticket.trackerError ? '<span class="cr-chip warn">tracker ⚠</span>' : ticket.trackerSyncedAt ? '' : '<span class="cr-chip">chờ tracker</span>';
      const detail = expanded ? `<div class="cr-detail">
          <div class="cr-meta">
            <span>Raise</span><b>${esc(CR.vnTime(ticket.recordedAt) || ago(ticket.recordedAt))}</b>
            <span>Phản hồi</span><b>${ticket.replyCount ? `${ticket.replyCount} lần · ${esc(ago(ticket.lastReplyAt))}` : 'chưa'}</b>
            <span>Kiểm tra</span><b>${ticket.lastCheckedAt ? esc(ago(ticket.lastCheckedAt)) : 'chưa'}</b>
            <span>Loại</span><b>${esc(ticketType(ticket))}${ticket.shopName ? ` · ${esc(ticket.shopName)}` : ''}</b>
            <span>Tracker</span><b>${general ? 'không áp dụng (chỉ phiếu đòi hàng)' : (ticket.trackerError ? `⚠ ${esc(ticket.trackerError)}` : ticket.trackerSyncedAt ? `✓ ${ticket.trackerWritten || 0} dòng · ${esc(ago(ticket.trackerSyncedAt))}` : 'đang chờ ghi')}</b>
            <span>Đơn</span><b>${orders.map(esc).join(', ') || '-'}</b>
          </div>
          ${last && !last.ok ? `<div class="data-note cr-why">⚠ ${esc(last.error)}</div>` : ''}
          ${last?.fileErrors?.length ? `<div class="data-note cr-why">⚠ Chưa tải được biên bản: ${esc(last.fileErrors.join(' · '))}</div>` : ''}
          ${ticket.platform === 'shopee' ? shopeeBox(ticket) : tiktokBox(ticket)}
          <div class="cr-actions">
            ${CR.ttActionOpen(ticket) ? `<button class="primary" data-cr-action-one ${busy ? 'disabled' : ''} title="Điền nội dung bổ sung bằng chứng + đính kèm lại biên bản → Gửi">Re-raise ngay (bổ sung bằng chứng)</button>` : ''}
            ${CR.ttRebutOpen(ticket) ? `<button class="primary" data-cr-action-one ${busy ? 'disabled' : ''} title="Gửi nội dung phản biện (ô bên trên) + đính kèm lại biên bản → phiếu mở lại">Phản biện ngay</button>` : ''}
            ${CR.ttNeedsNewTicket(ticket) && ticket.kind !== 'general' && !reraiseGroupOf(ticket) ? '<button class="secondary" data-cr-reraise title="Phiếu đã đóng → tạo phiếu mới ở thẻ Raise, dẫn chiếu phiếu cũ, kèm biên bản">Raise lại (phiếu mới)</button>' : ''}
            ${CR.ttNeedsNewTicket(ticket) ? '<button class="link-btn" data-cr-mark-reraised title="Đã raise phiếu mới (tay trên TikTok hoặc tool chưa bắt được Ticket ID) → thôi báo cần raise lại">Đã raise lại rồi</button>' : ''}
            ${ticket.platform === 'shopee' ? '' : `<button class="secondary" data-cr-reply ${busy || ticket.finished ? 'disabled' : ''} title="Chỉ gửi nội dung nhắc, không đính kèm lại file">Nhắc phiếu ngay</button>`}
            <a class="cr-linkbtn" href="${esc(ticketUrl(ticket))}" target="_blank" rel="noopener" ${ticket.platform === 'shopee' ? '' : 'data-cr-view title="Mở phiếu + quét lại trạng thái và nội dung TikTok trả lời"'}>Xem phiếu ↗</a>
            ${ticket.platform === 'shopee' ? '' : '<button class="link-btn" data-cr-rescan title="Đọc lại trạng thái + cả luồng TikTok trả lời của riêng phiếu này">Quét lại phiếu này</button>'}
            ${ticket.platform === 'shopee' ? `<button class="link-btn" data-cr-search-order="${esc(orders[0] || '')}">Tìm theo mã đơn ↗</button>
            <button class="link-btn" data-cr-check-one>Kiểm tra phản hồi</button>
            ${ticket.finished || ticket.reraisedTo ? '' : `<button class="${CR.needsReraise(ticket) ? 'secondary' : 'link-btn'}" data-cr-reraise title="Shopee không mở lại phiếu đã giải quyết → tạo phiếu mới dẫn chiếu phiếu này, nội dung trả lời đúng điều Shopee nói">Raise lại (phiếu mới)</button>`}` : ''}
            ${general ? '' : '<button class="link-btn" data-cr-tracker>Ghi lại tracker</button>'}
            <button class="link-btn" data-cr-finish>${ticket.finished ? 'Theo dõi lại' : 'Đã nhận hàng hoàn'}</button>
          </div>
        </div>` : '';
      return `<article class="cr-row${expanded ? ' open' : ''}" data-cr-ticket="${esc(id)}">
        <div class="cr-line"><span class="cr-dot ${tone}"></span>
          <div class="cr-main"><b>#${esc(id)}</b><span class="cr-sub">${general ? `<i class="cr-type">${esc(ticketType(ticket))}</i> · ` : ''}${esc(orders[0] || '-')}${orders.length > 1 ? ` +${orders.length - 1}` : ''}${ticket.carrier ? ` · ${esc(ticket.carrier)}` : ''} · ${esc(ago(ticket.recordedAt))}</span></div>
          ${tracker}<span class="cr-chip ${tone}">${esc(ticketLabel(ticket))}</span>
          ${followChip(ticket)}
          <button class="cr-toggle" data-cr-tview aria-expanded="${expanded}" title="Chi tiết & thao tác">${expanded ? '▴' : '▾'}</button>
        </div>${detail}
      </article>`;
    })(); } catch (error) {
      return `<article class="cr-row open" data-cr-ticket="${esc(String(ticket.TicketID))}"><div class="cr-line"><div class="cr-main"><b>#${esc(String(ticket.TicketID))}</b><span class="cr-sub">⚠ Lỗi hiển thị chi tiết: ${esc(error?.message || error)}</span></div><a class="cr-linkbtn" href="${esc(ticketUrl(ticket))}" target="_blank" rel="noopener">Xem phiếu ↗</a></div></article>`;
    } }).join('') + (list.length > shown.length ? `<button class="secondary wide cr-more" data-cr-tmore>Xem thêm (còn ${list.length - shown.length})</button>` : '')
      + (!list.length && !noTickets ? '<div class="data-note cr-empty">Không có phiếu nào trong bộ lọc này.</div>' : '');
    if (busy) {
      const done = follow.results.length, total = done + follow.queue.length + (follow.active ? 1 : 0);
      followStatus(`Đang ${follow.mode === 'evidence' ? 're-raise (bổ sung bằng chứng)' : follow.mode === 'reply' ? 'phản hồi' : 'kiểm tra'} phiếu ${follow.active?.ticketId || ''} · ${done}/${total}.`, 'running');
    } else if (follow?.doneAt && follow.results.length) {
      const replied = follow.results.filter(item => item.replied && item.ok).length;
      const failed = follow.results.filter(item => !item.ok).length;
      followStatus(`Xong ${follow.results.length} phiếu · đã phản hồi ${replied}${failed ? ` · ${failed} lỗi (xem từng phiếu)` : ''}.`, failed ? 'error' : 'ok');
    }
  }
  function render() {
    if (!shown || loading) return;
    $c('crShopName').textContent = shopName || shopHint();
    renderStage(); renderSource(); renderChannels(); renderBinding(); renderGroups(); renderRun(); renderTickets(); renderLookup(); renderTabs();
  }
  async function refreshShop(ensureOpen = false) {
    if (readingShop) return readingShop;
    const asked = platform;
    const before = shopName;
    readingShop = sendRuntimeMessage(asked === 'shopee' ? { type: 'GET_LOGGED_IN_SHOPEE_SHOP', ensureOpen } : { type: 'GET_LOGGED_IN_TIKTOK_SHOP' }).then(result => {
      if (asked !== platform) return result;   // đã đổi sàn trong lúc đọc
      shopName = result?.ok ? String(result.name || '') : '';
      // v2.2.84 — đổi store trên TikTok → Theo dõi tự chọn đúng store đó (bảng store + danh sách phiếu).
      if (asked === 'tiktok' && shopName && shopName !== before) onShopChanged(shopName, before);
      if (!shopName) $c('crShopName').textContent = result?.error || shopHint();
      else {
        // v2.2.35 — đổi shop → tự chọn channel tương ứng (khi không đang raise).
        const auto = channelForShop(shopName);
        if (auto && auto !== settings.channel && !running()) {
          settings.channel = auto; save({ cancelReturnSettings: settings }).catch(() => {});
          renderChannels(); status(`Tự chọn channel ${auto} theo shop đang đăng nhập (${shopName}).`, 'ok');
        }
        $c('crShopName').textContent = auto ? `${shopName} → ${auto}${boundShop(auto) === shopName ? '' : ' (tự nhận)'}` : loggedShopDone() ? `${shopName} · ✓ đã raise xong hết đơn của shop này` : `${shopName} · chưa khớp channel nào — chọn tay`;
        renderBinding(); renderGroups();
      }
      return result;
    }).finally(() => { readingShop = null; });
    return readingShop;
  }

  /* v2.2.84 — TỰ NHẬN STORE ĐANG VÀO: đọc lại tên shop khi chuyển tab / tải xong trang TikTok / 30 giây một lần (panel đang mở).
     Store đổi → bảng "Store cần kiểm tra" tự lọc store đó + báo số việc cần làm. */
  function onShopChanged(name, before) {
    const mine = Object.values(tickets).filter(ticket => ofPlatform(ticket) && !ticket.finished && shopKey(ticket) === name);
    if (mine.length) { view.shop = name; view.ticketLimit = PAGE; }
    else if (view.shop === before) view.shop = '';
    if (!shown) return;
    renderTickets();
    const action = mine.filter(CR.ttActionOpen).length, rebut = mine.filter(CR.ttRebutOpen).length, fresh = mine.filter(ticket => CR.ttNeedsNewTicket(ticket) && !reraiseGroupOf(ticket)).length;
    const scanned = mine.map(ticket => ticket.tiktok?.scannedAt).filter(Boolean).sort().pop();
    followStatus(`Đang ở store ${name}${before ? ` (trước: ${before})` : ''} · ${mine.length ? `${mine.length} phiếu theo dõi${action ? ` · ⚡ ${action}` : ''}${rebut ? ` · ⚖ ${rebut}` : ''}${fresh ? ` · ✖ raise lại ${fresh}` : ''} · ${scanned ? `quét ${ago(scanned)}` : 'chưa quét'} — bấm Quét phiếu TikTok để cập nhật` : 'chưa có phiếu nào của store này trong Theo dõi (bấm Quét phiếu TikTok)'}.`, action || rebut || fresh ? 'running' : 'ok');
  }
  let shopTimer = 0;
  const autoShop = () => { clearTimeout(shopTimer); shopTimer = setTimeout(() => { if (shown && !isShopee() && !readingShop) refreshShop().catch(() => {}); }, 900); };
  try {
    chrome.tabs.onActivated.addListener(autoShop);
    chrome.tabs.onUpdated.addListener((tabId, info, tab) => { if (info.status === 'complete' && /^https:\/\/seller-vn\.tiktok\.com\//.test(tab?.url || '')) autoShop(); });
  } catch (_) {}
  setInterval(() => { if (shown && document.visibilityState === 'visible') autoShop(); }, 30000);
  // v2.2.85 — dấu "Đã theo dõi" tự hết sau 24 giờ: vẽ lại 5 phút/lần để "còn Xh" và bộ lọc đúng giờ.
  setInterval(() => { if (shown && !loading && document.visibilityState === 'visible' && !document.activeElement?.matches?.('textarea,input')) renderTickets(); }, 300000);

  /* ---------------------------------------------------------------- actions --- */
  /** onlyIds: Raise riêng 1 ĐVVC; bỏ trống = Raise tất cả ĐVVC đã chọn (lần lượt, xong phiếu này mới sang phiếu kế). */
  async function start(onlyIds = null) {
    const channel = settings.channel;
    const list = channelGroups(channel).filter(group => !group.ticketId && (onlyIds ? onlyIds.includes(group.id) : group.selected !== false));
    if (!list.length) return status('Chọn ít nhất 1 ĐVVC.', 'error');
    const shop = await refreshShop(isShopee());
    if (!shop?.ok) return status(shop?.error || (isShopee() ? 'Mở Kênh Người Bán Shopee đúng shop rồi thử lại.' : 'Mở tab TikTok Shop đúng shop rồi thử lại.'), 'error');
    $c('crStart').disabled = true;
    try {
      // v2.2.47 — 1 đơn/ticket: KHÔNG tải trước biên bản của mọi đơn (chậm, nặng bộ nhớ). Background tải ngay trước khi mở form
      // từng đơn và tải sẵn đơn kế. Chỉ phiếu gộp nhiều đơn mới cần chuẩn bị file Excel ở đây.
      // Shopee: mọi ticket đều cần Excel danh sách đơn + biên bản (tải ở đây, ≤5 file).
      const multi = list.filter(group => group.rows.length > 1 || group.platform === 'shopee');
      // v2.2.69 — Shopee: chỉ tạo Excel ở đây (tức thì); biên bản tải ngay trước khi mở form từng ticket (background, tải sẵn ticket kế).
      for (const [index, group] of multi.entries()) {
        const shopee = group.platform === 'shopee';
        status(`Chuẩn bị file ${index + 1}/${multi.length}: Excel danh sách đơn${shopee ? '' : ` + biên bản ${group.carrier}`}…`, 'running');
        await prepareFiles(group, { skipEvidence: shopee });
        if (shopee) { group.filesTried = false; group.evidenceNote = ''; }
        groups[group.id] = group;
      }
      await save({ cancelReturnGroups: groups, cancelReturnSettings: settings });
      renderGroups();
      status('Đang mở ticket đầu tiên…', 'running');
      status('Đang mở ticket đầu tiên…', 'running');
    const result = await sendRuntimeMessage({ type: 'START_CANCEL_RETURN', channel, groupIds: list.map(group => group.id), bindShop: !boundShop(channel) });
      if (!result?.ok) throw new Error(result?.error || 'Không mở được hàng đợi.');
    } catch (error) {
      reportError(error);
      // v2.2.62 — lỗi khi bấm Raise hiện ngay dưới nút (trước đây chỉ ở khung trạng thái phía dưới, dễ sót).
      setTimeout(() => { $c('crStartWhy').textContent = `Không raise được: ${error?.message || error}`; }, 0);
    }
    finally { renderGroups(); renderRun(); }
  }
  const groupOf = el => groups[el.closest('[data-cr-group]')?.dataset.crGroup];
  $c('crGroups').addEventListener('input', event => {
    const group = groupOf(event.target);
    if (!group || running()) return;
    if (event.target.matches('[data-cr-text]')) {
      group.textOverride = event.target.value;
      event.target.closest('details').querySelector('summary').textContent = `Nội dung ticket (${event.target.value.length}/${CR.maxText(group)})`;
    }
    if (event.target.matches('[data-cr-select]')) { group.selected = event.target.checked; renderGroups(); }
    save({ cancelReturnGroups: groups }).catch(reportError);
  });
  $c('crGroups').addEventListener('change', async event => {
    if (!event.target.matches('[data-cr-files]')) return;
    const group = groupOf(event.target);
    try {
      const selected = [];
      // v2.2.66 — ảnh chụp > 5 MB: tự nén xuống dưới 5 MB thay vì báo lỗi.
      for (const file of event.target.files) {
        if (/\.(jpe?g|png)$/i.test(file.name) && file.size >= 5 * 1024 * 1024) {
          status(`Đang nén ảnh ${file.name}…`, 'running');
          const small = await CR.shrinkImage(new Uint8Array(await file.arrayBuffer()), file.type).catch(() => null);
          selected.push(small ? new File([small], file.name.replace(/\.[a-z0-9]+$/i, '.jpg'), { type: 'image/jpeg' }) : file);
        } else selected.push(file);
      }
      const own = (group.files || []).filter(file => file.kind !== 'excel');
      if (own.length + selected.length + 1 > CR.maxFiles(group)) throw new Error(`Mỗi ticket tối đa ${CR.maxFiles(group)} file (đã gồm Excel danh sách đơn).`);
      for (const file of selected) { const error = OPHandover.fileError(file, group.platform === 'shopee' ? 'shopee' : 'tiktok'); if (error) throw new Error(error); }
      for (const file of selected) { const item = await fileToStoredAttachment(file); item.type = MIME[file.name.split('.').pop().toLowerCase()]; item.name = CR.safeFileName(item.name); item.kind = 'manual'; own.push(item); }
      group.files = own;
      await save({ cancelReturnGroups: groups }); renderGroups();
    } catch (error) { reportError(error); }
    finally { event.target.value = ''; }
  });
  $c('crGroups').addEventListener('click', async event => {
    const button = event.target.closest('button'); if (!button || button.disabled) return;
    if (button.hasAttribute('data-cr-more')) { view.limit += PAGE; renderGroups(); return; }
    if (button.hasAttribute('data-cr-more-raised')) { view.raisedLimit += PAGE; renderGroups(); return; }
    const group = groupOf(button); if (!group) return;
    if (button.hasAttribute('data-cr-toggle')) { const isOpen = button.getAttribute('aria-expanded') === 'true'; view.open = isOpen ? `closed:${group.id}` : group.id; renderGroups(); return; }
    try {
      if (button.hasAttribute('data-cr-raise-one')) { await start([group.id]); return; }
      if (button.hasAttribute('data-cr-search-shopee')) { await searchOnShopee(group.rows[0].orderId); return; }
      if (button.hasAttribute('data-cr-retry')) {
        button.disabled = true;
        status('Đang tải lại form và đính kèm lại file đã lưu…', 'running');
        const result = await sendRuntimeMessage({ type: 'RESUME_CANCEL_RETURN' });
        if (!result?.ok) throw new Error(result?.error || 'Chưa thử lại được.');
        return;
      }
      if (button.hasAttribute('data-cr-reset')) { group.textOverride = ''; await save({ cancelReturnGroups: groups }); renderGroups(); }
      else if (button.hasAttribute('data-cr-copy')) { await navigator.clipboard.writeText(CR.text(group, settings)); status('Đã copy nội dung.'); }
      else if (button.dataset.crRemove != null) { const own = (group.files || []).filter(file => file.kind !== 'excel'); own.splice(Number(button.dataset.crRemove), 1); group.files = own; await save({ cancelReturnGroups: groups }); renderGroups(); }
      else if (button.hasAttribute('data-cr-map')) {
        const ticketId = button.closest('.handover-manual').querySelector('[data-cr-manual]').value.trim();
        const result = await sendRuntimeMessage({ type: 'MAP_CANCEL_RETURN_MANUALLY', groupId: group.id, ticketId });
        if (!result?.ok) throw new Error(result?.error || 'Không lưu được Ticket ID.');
        status(`✓ Đã lưu Ticket ${ticketId} cho ${group.carrier}.`, 'ok');
      }
    } catch (error) { reportError(error); }
  });
  $c('crTicketFilter').addEventListener('click', event => {
    const pill = event.target.closest('[data-tf]'); if (!pill) return;
    view.ticketFilter = pill.dataset.tf; view.ticketLimit = PAGE; renderTickets();
  });
  $c('crTickets').addEventListener('click', async event => {
    const button = event.target.closest('button'); if (!button || button.disabled) return;
    if (button.hasAttribute('data-cr-tmore')) { view.ticketLimit += PAGE; renderTickets(); return; }
    if (button.dataset.crSearchOrder) { searchOnShopee(button.dataset.crSearchOrder).catch(error => followStatus(error.message, 'error')); return; }
    if (button.hasAttribute('data-cr-check-one') || button.hasAttribute('data-cr-reraise')) {
      const id = button.closest('[data-cr-ticket]')?.dataset.crTicket;
      try {
        if (button.hasAttribute('data-cr-check-one')) {
          followStatus(`Đang đọc nội dung phiếu #${id} trên Shopee…`, 'running');
          const result = await sendRuntimeMessage({ type: 'REFRESH_SHOPEE_CANCEL_RETURN', ticketIds: [id] });
          if (!result?.ok) throw new Error(result?.error || 'Chưa đọc được.');
          const ticket = (await chrome.storage.local.get('cancelReturnTickets')).cancelReturnTickets?.[id];
          followStatus(`#${id}: ${ticket?.shopee?.label || 'đã đọc'}${ticket?.shopee?.need ? ` — ${ticket.shopee.need}` : ''}.`, ticket?.shopee?.tone === 'ok' ? 'ok' : 'running');
        } else await reraiseTickets([tickets[id]]);
      } catch (error) { followStatus(error.message || String(error), 'error'); }
      return;
    }
    if (button.hasAttribute('data-cr-tview')) { const id = button.closest('[data-cr-ticket]')?.dataset.crTicket; view.ticketOpen = view.ticketOpen === id ? '' : id; renderTickets(); return; }
    const ticketId = button.closest('[data-cr-ticket]')?.dataset.crTicket;
    try {
      if (button.hasAttribute('data-cr-reply')) {
        const result = await sendRuntimeMessage({ type: 'FOLLOW_UP_CANCEL_RETURN', ticketIds: [ticketId], mode: 'reply', text: $c('crFollowText').value });
        if (!result?.ok) throw new Error(result?.error);
      } else if (button.hasAttribute('data-cr-tracker')) {
        followStatus(`Đang ghi phiếu #${ticketId} vào tracker SharePoint…`, 'running');
        const result = await sendRuntimeMessage({ type: 'WRITE_CANCEL_RETURN_TRACKER', ticketIds: [ticketId] });
        if (!result?.ok) throw new Error(result?.error);
        const item = result.results?.[ticketId];
        followStatus(item?.ok ? `✓ Đã ghi ${item.written} dòng tracker cho phiếu #${ticketId}.${item.warn ? ` ⚠ ${item.warn}` : ''}` : `Chưa ghi được tracker: ${item?.error || '?'}`, item?.ok ? 'ok' : 'error');
      } else if (button.hasAttribute('data-cr-finish')) {
        const result = await sendRuntimeMessage({ type: 'SET_CANCEL_RETURN_FINISHED', ticketId, finished: !tickets[ticketId]?.finished });
        if (!result?.ok) throw new Error(result?.error);
      }
    } catch (error) { followStatus(error.message || String(error), 'error'); }
  });
  $c('crFollowAll').addEventListener('click', async () => {
    const shop = await refreshShop();
    if (!shop?.ok) return followStatus(shop?.error || 'Mở tab TikTok Shop đúng shop.', 'error');
    followStatus('Đang gom mọi phiếu TikTok đã raise (pickup, kháng nghị, khiếu nại, đòi hàng)…', 'running');
    await syncAllTikTokTickets(true);
    const { cancelReturnTickets: fresh } = await chrome.storage.local.get('cancelReturnTickets');
    if (fresh) tickets = fresh;
    const ids = Object.values(tickets).filter(ticket => !ticket.finished && ticket.shopName === shop.name).map(ticket => ticket.TicketID);
    if (!ids.length) return followStatus(`Shop ${shop.name} không có phiếu TikTok nào đang theo dõi. Đổi shop TikTok để kiểm tra phiếu của shop khác.`, 'error');
    followStatus(`Đang kiểm tra trạng thái ${ids.length} phiếu cùng lúc trên Nhật ký phiếu…`, 'running');
    const result = await sendRuntimeMessage({ type: 'FOLLOW_UP_CANCEL_RETURN', ticketIds: ids, mode: 'auto', text: $c('crFollowText').value });
    if (!result?.ok) return followStatus(result?.error || 'Không chạy được.', 'error');
    const sum = result.summary;
    if (sum) followStatus(`✓ Kiểm tra ${sum.checked} phiếu trong ${sum.seconds} giây: ${sum.open} đang xử lý · ${sum.reopen} phiếu cần mở lại${sum.reopen ? ' → đang phản hồi lần lượt trên 1 tab' : ''}.`, sum.reopen ? 'running' : 'ok');
    else if (!result.count) followStatus('Không có phiếu cần mở lại.', 'ok');
  });
  // v2.2.29 — file cập nhật tracker: mỗi đơn 1 dòng, đúng tên 6 cột trên sheet Tracking (dán vào List khi tool chưa có quyền ghi).
  $c('crTrackerExport').addEventListener('click', () => {
    const rows = Object.values(tickets).flatMap(ticket => (ticket.orderIds || []).map((orderId, index) => {
      const f = CR.trackerFields(ticket, orderId);
      return { order_no: ticket.orderNos?.[index] || '', ecom_order_code: orderId, 'Loại ticket': f.TicketType, 'Ticket ID': f.TicketId, 'Status ticket': f.TicketStatus, 'Ngày tạo ticket': CR.vnTime(f.TicketCreated), 'Phản hồi ticket': f.TicketReply, 'Ghi chú ticket': f.TicketNote };
    }));
    if (!rows.length) return followStatus('Chưa có phiếu đòi hàng.');
    triggerDownload(createXlsx(Object.keys(rows[0]), rows, 'Cap nhat tracker'), `FG_Tracking_TicketID_${new Date().toISOString().slice(0, 10)}.xlsx`, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  });
  /* v2.2.30 — Dò Ticket ID đã raise: kết quả từng ĐVVC; nhiều phiếu chưa đóng → nút "Gán #…" để chọn tay. */
  function renderLookup() {
    const box = $c('crLookupBox');
    const pending = Object.values(groups).filter(group => !group.ticketId && group.platform !== 'shopee').length;
    const shopeePending = Object.values(groups).filter(group => !group.ticketId && group.platform === 'shopee').length;
    const shopeeBusy = Boolean(lookup && !lookup.doneAt && lookup.platform === 'shopee');
    if ($c('crLookupShopee')) { $c('crLookupShopee').disabled = Boolean(lookup && !lookup.doneAt) || !shopeePending || running(); $c('crLookupShopee').textContent = shopeeBusy ? `Đang dò theo Mã đơn hàng… (${(lookup.results || []).length}/${(lookup.results || []).length + (lookup.queue || []).length + (lookup.active ? 1 : 0)})` : `Dò mã phiếu đã raise trên Shopee${shopeePending ? ` (${shopeePending} ticket chưa có mã)` : ''}`; }
    const busy = Boolean(lookup && !lookup.doneAt);
    $c('crLookup').disabled = busy || !pending || running();
    $c('crStopNow').hidden = !(running() || busy);
    $c('crLookup').textContent = busy ? `Đang dò Ticket ID… (${(lookup.results || []).length}/${(lookup.results || []).length + (lookup.queue || []).length + (lookup.active ? 1 : 0)})` : `Dò Ticket ID đã raise trên TikTok${pending ? ` (${pending} ${Object.values(groups).some(group => !group.ticketId && group.rows.length > 1) ? 'mục' : 'đơn'} chưa có ID)` : ''}`;
    if (!lookup?.results?.length || (lookup.platform === 'shopee') !== isShopee()) { box.innerHTML = ''; return; }
    box.innerHTML = lookup.results.slice(-20).map(item => {
      const group = groups[item.groupId];
      if (item.ticketId || group?.ticketId) return `<div>✓ ${esc(item.label)}: Ticket <b>${esc(item.ticketId || group.ticketId)}</b></div>`;
      const choices = (item.candidates || []).map(row => `<button class="link-btn" data-cr-assign="${esc(item.groupId)}" data-ticket="${esc(row.ticketId)}">Gán #${esc(row.ticketId)} · ${esc(row.status || '?')} · ${esc(row.created || '')}</button>${lookup.platform === 'shopee' ? ` <a class="link-btn" href="${esc(CR.shopeeDetailUrl(row.ticketId))}" target="_blank" rel="noopener">xem ↗</a>` : ''}`).join(' ');
      return `<div>⚠ ${esc(item.label)}: ${esc(item.reason || 'chưa gán được')}${choices ? `<br>${choices}` : ''}</div>`;
    }).join('');
  }
  $c('crLookup').addEventListener('click', async () => {
    try {
      status('Đang mở Nhật ký phiếu để dò Ticket ID (Tất cả → ID đơn hàng)…', 'running');
      const result = await sendRuntimeMessage({ type: 'LOOKUP_CANCEL_RETURN_TICKETS' });
      if (!result?.ok) throw new Error(result?.error || 'Chưa dò được.');
      status(`Đang dò ${result.count} ĐVVC trên tab TikTok vừa mở${result.skipped ? ` · ${result.skipped} ĐVVC thuộc shop khác (đổi shop rồi dò tiếp)` : ''}.`, 'running');
    } catch (error) { reportError(error); }
  });
  $c('crLookupShopee').addEventListener('click', async () => {
    try {
      status('Đang dò trên tab Yêu cầu của tôi: Tất cả → Mã đơn hàng → gõ mã từng đơn…', 'running');
      const result = await sendRuntimeMessage({ type: 'LOOKUP_SHOPEE_CANCEL_RETURN' });
      if (!result?.ok) throw new Error(result?.error || 'Chưa dò được.');
      status(`Đã dò ${result.count} ticket Shopee theo Mã đơn hàng · tự lưu mã phiếu cho ${result.mapped}.${result.mapped < result.count ? ' Ticket còn lại xem bên dưới (nhiều phiếu → bấm "Gán #…"; chưa có phiếu → raise lại).' : ''}`, result.mapped === result.count ? 'ok' : 'running');
    } catch (error) { reportError(error); }
  });
  $c('crShopeeRefresh').addEventListener('click', async () => {
    followStatus('Đang đọc nội dung từng phiếu trên Cổng hỗ trợ người bán Shopee (thắng / thua / cần bổ sung)…', 'running');
    try {
      const result = await sendRuntimeMessage({ type: 'REFRESH_SHOPEE_CANCEL_RETURN' });
      if (!result?.ok) throw new Error(result?.error || 'Chưa đọc được.');
      const c = result.counts || {};
      const parts = Object.entries(CR.VERDICTS).filter(([key]) => c[key]).map(([key, item]) => `${item.label}: ${c[key]}`).join(' · ');
      followStatus(`✓ Đã đọc ${result.checked}/${result.total} phiếu Shopee${parts ? ` — ${parts}` : ''}${result.changed ? ` · ${result.changed} phiếu có thay đổi (đang ghi tracker)` : ''}${result.reraise?.length ? ` · ${result.reraise.length} phiếu cần raise lại (lọc "Cần raise lại")` : ''}.`, result.reraise?.length ? 'running' : 'ok');
      view.ticketFilter = result.reraise?.length ? 'reraise' : view.ticketFilter; renderTickets();
    } catch (error) { followStatus(error.message || String(error), 'error'); }
  });
  $c('crShopeeReraiseAll').addEventListener('click', async () => {
    const list = Object.values(tickets).filter(ticket => ticket.platform === 'shopee' && CR.needsReraise(ticket));
    if (!list.length) return followStatus('Không có phiếu Shopee nào cần raise lại (bấm Kiểm tra phản hồi trước).', 'error');
    try { await reraiseTickets(list); } catch (error) { followStatus(error.message || String(error), 'error'); }
  });
  $c('crLookupBox').addEventListener('click', async event => {
    const button = event.target.closest('[data-cr-assign]'); if (!button) return;
    try {
      const result = await sendRuntimeMessage({ type: 'MAP_CANCEL_RETURN_MANUALLY', groupId: button.dataset.crAssign, ticketId: button.dataset.ticket });
      if (!result?.ok) throw new Error(result?.error || 'Chưa gán được.');
      status(`✓ Đã gán Ticket ${button.dataset.ticket}.`, 'ok');
    } catch (error) { reportError(error); }
  });
  $c('crTrackerAll').addEventListener('click', async () => {
    if (!Object.keys(tickets).length) return followStatus('Chưa có phiếu đòi hàng.');
    followStatus('Đang ghi tất cả phiếu vào tracker SharePoint…', 'running');
    try {
      const result = await sendRuntimeMessage({ type: 'WRITE_CANCEL_RETURN_TRACKER' });
      if (!result?.ok) throw new Error(result?.error);
      const items = Object.values(result.results || {}).filter(item => !item.drop);
      const failed = items.filter(item => !item.ok);
      followStatus(failed.length ? `Ghi ${items.length - failed.length}/${items.length} phiếu · lỗi: ${failed[0].error}` : `✓ Đã ghi ${items.reduce((sum, item) => sum + (item.written || 0), 0)} dòng tracker cho ${items.length} phiếu.`, failed.length ? 'error' : 'ok');
    } catch (error) { followStatus(error.message || String(error), 'error'); }
  });
  /* v2.2.72 — Quét phiếu TikTok (tab TikTok đang mở) → ưu tiên "Cần có hành động của bạn" trước khi TikTok đóng phiếu sau 24 giờ. */
  async function scanTikTok() {
    followStatus('Đang tải lại Nhật ký phiếu TikTok → bấm Tất cả → quét (phiếu đang mở + phiếu đóng 14 ngày)…', 'running');
    const result = await sendRuntimeMessage({ type: 'SCAN_TIKTOK_TICKETS', days: settings.scanDays || 14 });
    if (!result?.ok) throw new Error(result?.error || 'Chưa quét được.');
    const { cancelReturnTickets: fresh } = await chrome.storage.local.get('cancelReturnTickets');
    if (fresh) tickets = fresh;
    const parts = Object.entries(result.counts || {}).map(([label, count]) => `${label}: ${count}`).join(' · ');
    if (result.need.length) { view.ticketFilter = 'action'; view.ticketLimit = PAGE; }
    else if (result.closedAfterAsk.length) view.ticketFilter = 'reraise';
    else if (result.rebut?.length) view.ticketFilter = 'rebut';
    else if (result.fresh?.length) view.ticketFilter = 'ttnew';
    const said = Object.entries(result.verdicts || {}).map(([label, count]) => `${label}: ${count}`).join(' · ');
    followStatus(`✓ Quét ${result.scanned} phiếu của ${result.shop} · ${result.updated} phiếu của tool (${parts || 'không có'})${result.others ? ` · bỏ qua ${result.others} phiếu Cần hành động do người khác raise (không có trong tracker)` : ''}.${said ? ` Phản hồi TikTok — ${said}${result.fresh?.length ? ` · ${result.fresh.length} phiếu có trả lời mới (lọc "TikTok trả lời mới")` : ''}.` : ''}${result.rebut?.length ? ` ⚖ ${result.rebut.length} phiếu giải quyết sai / trả lời lệch → lọc "Cần phản biện".` : ''}${result.relinked ? ` ↻ ${result.relinked} phiếu đã đóng nhận ra đã có phiếu mới cho cùng đơn → chuyển "Đã raise lại".` : ''} ${result.need.length ? `⚡ ${result.need.length} phiếu Cần hành động — hạn gần nhất ${CR.vnTime(result.nextDeadline)} → bấm Re-raise phiếu Cần hành động.` : 'Không có phiếu Cần hành động.'}${result.closedAfterAsk.length ? ` ✖ ${result.closedAfterAsk.length} phiếu đã đóng sau yêu cầu bằng chứng → Raise lại (phiếu mới).` : ''}${result.added ? ` (+${result.added} phiếu lấy từ Ticket ID trong tracker — raise ở Chrome/máy khác)` : ''}${!tracker?.tickets ? ' ⚠ Bấm Tải lại tracker 1 lần để quét cả phiếu raise ở Chrome/máy khác.' : ''}`, result.need.length ? 'running' : 'ok');
    renderTickets();
    return result;
  }
  async function actionReraise(ids) {
    const shop = await refreshShop();
    if (!shop?.ok) throw new Error(shop?.error || 'Mở tab TikTok Shop đúng shop.');
    const list = ids.filter(id => tickets[id] && (!tickets[id].shopName || tickets[id].shopName === shop.name));
    if (!list.length) throw new Error(`Các phiếu này không thuộc shop ${shop.name} đang đăng nhập — đổi shop rồi re-raise.`);
    const result = await sendRuntimeMessage({ type: 'RERAISE_TIKTOK_ACTION', ticketIds: list });
    if (!result?.ok) throw new Error(result?.error || 'Chưa chạy được.');
    followStatus(`Đang re-raise ${result.count} phiếu Cần hành động (hạn gần nhất trước): mở phiếu → điền nội dung bổ sung bằng chứng → tải lên biên bản → Gửi…${ids.length > list.length ? ` · ${ids.length - list.length} phiếu shop khác để lượt sau` : ''}`, 'running');
  }
  $c('crScanTikTok').addEventListener('click', async () => {
    $c('crScanTikTok').disabled = true;
    try { await scanTikTok(); } catch (error) { followStatus(error.message || String(error), 'error'); }
    finally { $c('crScanTikTok').disabled = false; }
  });
  $c('crActionReraise').addEventListener('click', async () => {
    const ids = Object.values(tickets).filter(CR.ttActionOpen).sort((a, b) => CR.ttDeadline(a) - CR.ttDeadline(b)).map(ticket => ticket.TicketID);
    try { await actionReraise(ids); } catch (error) { followStatus(error.message || String(error), 'error'); }
  });
  $c('crTickets').addEventListener('click', async event => {
    const button = event.target.closest('[data-cr-action-one]'); if (!button || button.disabled) return;
    const row = button.closest('[data-cr-ticket]'); const id = row?.dataset.crTicket;
    try {
      // Phản biện: lưu nội dung đang sửa trong ô trước khi gửi.
      const box = row.querySelector('[data-cr-rebut-text]');
      if (box) { const saved = await sendRuntimeMessage({ type: 'SET_TIKTOK_REBUT_DRAFT', ticketId: id, text: box.value }); if (!saved?.ok) throw new Error(saved?.error || 'Chưa lưu được nội dung phản biện.'); }
      await actionReraise([id]);
    } catch (error) { followStatus(error.message || String(error), 'error'); }
  });
  /* v2.2.76 — Xem phiếu (mở tab) + quét lại chính phiếu đó; nút "Quét lại phiếu này". */
  async function rescanOne(id) {
    followStatus(`Đang quét lại phiếu #${id} (trạng thái + TikTok trả lời gì)…`, 'running');
    const result = await sendRuntimeMessage({ type: 'SCAN_TIKTOK_TICKETS', ticketIds: [id] });
    if (!result?.ok) throw new Error(result?.error || 'Chưa quét được phiếu.');
    const { cancelReturnTickets: fresh } = await chrome.storage.local.get('cancelReturnTickets');
    if (fresh) tickets = fresh;
    const ticket = tickets[id];
    const reply = ticket?.tiktok?.reply;
    view.ticketOpen = String(id); renderTickets();
    followStatus(`#${id}: ${ticket?.tiktok?.label || ticket?.lastStatus || '?'}${reply && reply.verdict !== 'none' ? ` · ${reply.label}${reply.shopLast ? ' (shop đã trả lời sau, chờ TikTok)' : ''}${reply.gist ? ` — ${reply.gist.slice(0, 200)}` : ''}` : ' · TikTok chưa phản hồi'}${CR.ttActionOpen(ticket) ? ' → ⚡ Cần hành động' : CR.ttRebutOpen(ticket) ? ' → ⚖ Cần phản biện' : CR.ttNeedsNewTicket(ticket) ? ' → raise lại phiếu mới' : ''}.`,
      CR.ttActionOpen(ticket) || CR.ttRebutOpen(ticket) || CR.ttNeedsNewTicket(ticket) ? 'error' : 'ok');
  }
  $c('crTickets').addEventListener('click', event => {
    const target = event.target.closest('[data-cr-view],[data-cr-rescan]'); if (!target || target.disabled) return;
    const id = target.closest('[data-cr-ticket]')?.dataset.crTicket; if (!id) return;
    // Link Xem phiếu vẫn mở tab như thường; quét chạy nền song song.
    rescanOne(id).catch(error => followStatus(error.message || String(error), 'error'));
  });
  // Lưu nội dung phản biện khi rời ô (không lưu từng phím: lưu làm vẽ lại danh sách, mất con trỏ).
  $c('crTickets').addEventListener('change', event => {
    const box = event.target.closest('[data-cr-rebut-text]'); if (!box) return;
    sendRuntimeMessage({ type: 'SET_TIKTOK_REBUT_DRAFT', ticketId: box.closest('[data-cr-ticket]')?.dataset.crTicket, text: box.value }).catch(() => {});
  });
  /* v2.2.81 — Raise lại TẤT CẢ phiếu TikTok đã bị đóng (✖ Cần raise lại) của shop đang đăng nhập:
     tạo phiếu mới ở thẻ Raise (dẫn chiếu phiếu cũ, biên bản tải lại từ link) rồi raise lần lượt từng channel như bấm Raise. */
  // v2.2.85 — đánh dấu / bỏ dấu "Đã theo dõi" 1 phiếu, hoặc hàng loạt theo danh sách đang lọc.
  $c('crTickets').addEventListener('click', async event => {
    const button = event.target.closest('[data-cr-followed]'); if (!button) return;
    event.stopPropagation();
    const id = button.closest('[data-cr-ticket]')?.dataset.crTicket;
    const result = await sendRuntimeMessage({ type: 'SET_TICKETS_FOLLOWED', ticketIds: [id], on: button.dataset.crFollowed === '1' }).catch(error => ({ ok: false, error: error.message }));
    if (!result?.ok) followStatus(result?.error || 'Chưa lưu được dấu theo dõi.', 'error');
  });
  $c('crFollowBulk').addEventListener('click', async event => {
    const button = event.target.closest('[data-cr-follow-bulk]'); if (!button) return;
    const ids = (button.dataset.crFollowBulk || '').split(',').filter(Boolean);
    if (!ids.length || !confirm(`Đánh dấu đã theo dõi ${ids.length} phiếu đang hiện (hiệu lực 24 giờ)?`)) return;
    const result = await sendRuntimeMessage({ type: 'SET_TICKETS_FOLLOWED', ticketIds: ids, on: true }).catch(error => ({ ok: false, error: error.message }));
    followStatus(result?.ok ? `✓ Đã đánh dấu theo dõi ${result.count} phiếu (đến ${CR.vnTime(new Date(Date.now() + CR.FOLLOW_WINDOW_MS).toISOString())}).` : result?.error || 'Chưa lưu được.', result?.ok ? 'ok' : 'error');
  });
  // v2.2.83 — "Đã raise lại rồi": nhập số phiếu mới (nếu biết) → phiếu cũ hết báo cần raise lại, bỏ phiếu raise lại còn chờ ở thẻ Raise.
  $c('crTickets').addEventListener('click', async event => {
    const button = event.target.closest('[data-cr-mark-reraised]'); if (!button) return;
    const id = button.closest('[data-cr-ticket]')?.dataset.crTicket;
    const answer = prompt(`Phiếu #${id} đã được raise lại.\nNhập số phiếu MỚI (để trống nếu không nhớ):`, '');
    if (answer === null) return;
    try {
      const result = await sendRuntimeMessage({ type: 'MARK_TIKTOK_RERAISED', ticketId: id, newTicketId: answer.trim() });
      if (!result?.ok) throw new Error(result?.error || 'Chưa lưu được.');
      followStatus(`✓ #${id}: đã đánh dấu raise lại${answer.trim() ? ` → #${answer.trim()}` : ''}${result.removedGroups ? ` · bỏ ${result.removedGroups} phiếu raise lại còn chờ ở thẻ Raise` : ''}.`, 'ok');
    } catch (error) { followStatus(error.message || String(error), 'error'); }
  });
  $c('crReraiseAllTT').addEventListener('click', async () => {
    const button = $c('crReraiseAllTT');
    try {
      button.disabled = true;
      const shop = await refreshShop();
      if (!shop?.ok) throw new Error(shop?.error || 'Mở tab TikTok Shop đúng shop rồi thử lại.');
      const all = Object.values(tickets).filter(ticket => ofPlatform(ticket) && CR.ttNeedsNewTicket(ticket) && ticket.kind !== 'general');
      const mine = all.filter(ticket => !ticket.shopName || ticket.shopName === shop.name);
      if (!mine.length) {
        const others = [...new Set(all.map(ticket => ticket.shopName).filter(Boolean))];
        throw new Error(`Shop ${shop.name} không có phiếu đã đóng cần raise lại.${others.length ? ` Còn ở: ${others.join(', ')} — đổi sang shop đó rồi bấm lại.` : ''}`);
      }
      const byChannel = {};
      for (const ticket of mine) (byChannel[ticket.channel] = byChannel[ticket.channel] || []).push(ticket);
      const channels = Object.keys(byChannel);
      if (!confirm(`Raise lại ${mine.length} phiếu đã đóng của shop ${shop.name} (${channels.map(channel => `${channel}: ${byChannel[channel].length}`).join(', ')})?\nMỗi phiếu = 1 phiếu MỚI trên TikTok, dẫn chiếu phiếu cũ + biên bản bàn giao.`)) return;
      const made = await reraiseTickets(mine);
      // Raise từng channel một (hàng đợi raise chạy theo channel đang chọn): channel đầu tiên chạy ngay.
      const first = channels[0];
      settings.channel = first; settings.tab = 'raise'; await save({ cancelReturnSettings: settings }); render();
      await start(made.filter(group => group.channel === first).map(group => group.id));
      if (channels.length > 1) status(`Đang raise lại ${byChannel[first].length} phiếu ${first}. Còn ${channels.slice(1).map(channel => `${channel} (${byChannel[channel].length})`).join(', ')} đã tạo sẵn ở thẻ Raise — chọn channel đó rồi bấm Raise tất cả.`, 'running');
    } catch (error) { followStatus(error.message || String(error), 'error'); }
    finally { renderTickets(); }
  });
  $c('crRebutAll').addEventListener('click', async () => {
    const ids = Object.values(tickets).filter(CR.ttRebutOpen).map(ticket => ticket.TicketID);
    try { await actionReraise(ids); } catch (error) { followStatus(error.message || String(error), 'error'); }
  });
  const saveAutoScan = async () => {
    settings.autoScan = $c('crAutoScan').checked; settings.autoReraise = settings.autoScan && $c('crAutoReraise').checked;
    await save({ cancelReturnSettings: settings });
    await sendRuntimeMessage({ type: 'SET_TIKTOK_AUTO_SCAN' });
    renderStage();
    followStatus(settings.autoScan ? `Đã bật tự quét mỗi 2 giờ${settings.autoReraise ? ' + tự re-raise phiếu Cần hành động' : ' (báo khi có phiếu Cần hành động)'}. Cần mở tab TikTok Shop trên Chrome.` : 'Đã tắt tự quét.', 'ok');
  };
  $c('crAutoScan').addEventListener('change', () => saveAutoScan().catch(error => followStatus(error.message || String(error), 'error')));
  $c('crAutoReraise').addEventListener('change', () => saveAutoScan().catch(error => followStatus(error.message || String(error), 'error')));
  $c('crFollowStop').addEventListener('click', () => sendRuntimeMessage({ type: 'STOP_CANCEL_RETURN_FOLLOW_UP' }).catch(() => {}));
  $c('crShowFinished').addEventListener('change', renderTickets);
  $c('crFollowText').addEventListener('input', () => { settings.followText = $c('crFollowText').value; save({ cancelReturnSettings: settings }).catch(() => {}); });
  $c('crExport').addEventListener('click', () => {
    const rows = Object.values(tickets).filter(ofPlatform).map(ticket => ({
      TicketID: ticket.TicketID, Sàn: CR.sellerLabel(ticket), Shop: ticket.shopName, Channel: ticket.channel, 'ĐVVC': ticket.carrier, Kho: ticket.warehouse,
      'Giai đoạn': ticket.platform === 'shopee' ? `Shopee webform › ${CR.SHOPEE.issue}` : CR.STAGES[CR.stage(ticket.stage)].path.join(' › '), 'Số đơn': ticket.orderIds?.length || 0, 'Mã đơn': (ticket.orderIds || []).join(', '),
      'Mã vận đơn': (ticket.trackingIds || []).join(', '), 'Raise lúc': ticket.recordedAt, 'Trạng thái gần nhất': ticket.lastStatus,
      'Kiểm tra lúc': ticket.lastCheckedAt, 'Sàn phản hồi': ticket.shopee?.label || ticket.tiktok?.reply?.label || '', 'Nội dung sàn trả lời': ticket.shopee?.gist || ticket.tiktok?.reply?.gist || '', 'Số lần phản hồi': ticket.replyCount || 0, 'Theo dõi lại lúc': ticket.followedAt ? CR.vnTime(ticket.followedAt) : '', 'Theo dõi (24h)': CR.followedRecently(ticket) ? 'Có' : '', 'Phản hồi gần nhất': ticket.lastReplyAt || '', 'Kết thúc': ticket.finished ? 'Có' : ''
    }));
    if (!rows.length) return followStatus('Chưa có phiếu đòi hàng.');
    triggerDownload(createXlsx(Object.keys(rows[0]), rows, 'Doi hang'), `${sell()}_DoiHang_DonHuy_${new Date().toISOString().slice(0, 10)}.xlsx`, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  });
  $c('crFetch').addEventListener('click', () => fetchTracker().catch(reportError));
  $c('crReload').addEventListener('click', () => fetchTracker().catch(reportError));
  $c('crPick').addEventListener('click', () => $c('crFile').click());
  $c('crFile').addEventListener('change', async event => {
    const file = event.target.files?.[0];
    try { if (file) { status('Đang đọc file…', 'running'); await applyTracker(readWorkbook(new Uint8Array(await file.arrayBuffer())), file.name); } }
    catch (error) { reportError(error); } finally { event.target.value = ''; }
  });
  $c('crParallelReply').addEventListener('change', () => { settings.parallelReply = $c('crParallelReply').checked; save({ cancelReturnSettings: settings }).catch(() => {}); renderStage(); });
  // v2.2.82 — fast mode áp dụng từ lượt bấm Raise kế tiếp (lượt đang chạy giữ nguyên số làn).
  $c('crFastMode').addEventListener('change', () => { settings.fastMode = $c('crFastMode').checked; save({ cancelReturnSettings: settings }).catch(() => {}); renderGroups(); status(settings.fastMode ? '⚡ Fast mode bật: lượt Raise kế tiếp chạy 2 tab song song (cần ≥2 đơn). Tab thứ 2 mở nền; đừng đóng nó khi đang chạy.' : 'Fast mode tắt: raise 1 tab như cũ.', 'ok'); });
  $c('crHideRaised').addEventListener('change', () => { settings.hideRaised = $c('crHideRaised').checked; save({ cancelReturnSettings: settings }).catch(() => {}); renderGroups(); });
  $c('crGroupByCarrier').addEventListener('change', () => { settings.groupByCarrier = $c('crGroupByCarrier').checked; save({ cancelReturnSettings: settings }).catch(reportError); status('Đã đổi cách chia ticket — bấm Tải lại tracker để chia lại các đơn chưa raise.'); });
  $c('crReplyAfter').addEventListener('change', () => { settings.replyAfterRaise = $c('crReplyAfter').checked; save({ cancelReturnSettings: settings }).catch(reportError); });
  $c('crStage').addEventListener('change', async () => { settings.stage = $c('crStage').value; await save({ cancelReturnSettings: settings }); render(); });
  $c('crWarehouse').addEventListener('input', () => { settings.warehouse = $c('crWarehouse').value; save({ cancelReturnSettings: settings }).catch(() => {}); renderGroups(); });
  $c('crShopeeEmail').addEventListener('input', () => { settings.shopeeEmail = $c('crShopeeEmail').value.trim(); save({ cancelReturnSettings: settings }).catch(() => {}); });
  // v2.2.44 — 3 thẻ Raise / Theo dõi / Cài đặt (nhớ thẻ đang mở).
  function renderTabs() {
    const tab = ['raise', 'follow', 'settings'].includes(settings.tab) ? settings.tab : (tracker ? 'raise' : 'settings');
    document.querySelectorAll('#cancelReturnPanel [data-cr-tab]').forEach(button => { const on = button.dataset.crTab === tab; button.classList.toggle('active', on); button.setAttribute('aria-selected', String(on)); });
    document.querySelectorAll('#cancelReturnPanel [data-cr-pane]').forEach(pane => { pane.hidden = pane.dataset.crPane !== tab; });
  }
  document.querySelector('#cancelReturnPanel .cr-tabs').addEventListener('click', event => {
    const button = event.target.closest('[data-cr-tab]'); if (!button) return;
    settings.tab = button.dataset.crTab; save({ cancelReturnSettings: settings }).catch(() => {}); renderTabs();
    if (settings.tab === 'follow' && !isShopee()) syncAllTikTokTickets().catch(() => {});
  });
  // v2.2.43 — tìm nhanh, chọn hết / bỏ chọn (theo kết quả tìm), gắn lại channel ↔ shop.
  let searchTimer = 0;
  $c('crSearch').addEventListener('input', () => { clearTimeout(searchTimer); searchTimer = setTimeout(() => { view.q = $c('crSearch').value; view.limit = PAGE; view.raisedLimit = PAGE; renderGroups(); }, 200); });
  const selectVisible = async value => {
    if (running()) return;
    channelGroups(settings.channel).filter(group => !group.ticketId && matchesSearch(group)).forEach(group => { group.selected = value; });
    await save({ cancelReturnGroups: groups }); renderGroups();
  };
  $c('crSelectAll').addEventListener('click', () => selectVisible(true).catch(reportError));
  $c('crSelectNone').addEventListener('click', () => selectVisible(false).catch(reportError));
  $c('crBinding').addEventListener('click', async event => {
    // v2.2.63 — bỏ gắn channel ↔ shop (gắn nhầm). Lần raise kế sẽ gắn với shop đang login lúc đó.
    if (event.target.closest('[data-cr-unbind]')) {
      if (running()) return;
      const map = { ...shopMap }; delete map[settings.channel]; shopMap = map;
      await save({ cancelReturnShopMap: shopMap });
      status(`Đã bỏ gắn shop cho ${settings.channel}. Đăng nhập đúng shop của channel này rồi bấm Raise.`, 'ok'); renderChannels(); renderBinding(); renderGroups();
      return;
    }
    if (!event.target.closest('[data-cr-rebind]') || !shopName || running()) return;
    // Nút này bị vẽ lại mỗi 5 giây → giữ trạng thái chờ xác nhận ở biến riêng.
    if (Date.now() > rebindArmedUntil) { rebindArmedUntil = Date.now() + 5000; event.target.closest('[data-cr-rebind]').textContent = `Bấm lần nữa để gắn ${settings.channel} ↔ ${shopName}`; return; }
    rebindArmedUntil = 0;
    shopMap = { ...shopMap, [settings.channel]: shopName };
    await save({ cancelReturnShopMap: shopMap });
    status(`✓ Đã gắn ${settings.channel} ↔ ${shopName}.`, 'ok'); renderChannels(); renderBinding(); renderGroups();
  });
  $c('crChannel').addEventListener('change', async () => { view.q = ''; $c('crSearch').value = ''; view.limit = PAGE; view.raisedLimit = PAGE; view.open = ''; setTimeout(renderRun, 0); settings.channel = $c('crChannel').value; await save({ cancelReturnSettings: settings }); renderBinding(); renderGroups(); });
  $c('crRefreshShop').addEventListener('click', () => refreshShop().catch(reportError));
  $c('crStart').addEventListener('click', () => start().catch(reportError));
  // v2.2.53 — Side Panel của Chrome chặn hộp thoại confirm() (luôn trả false) → xác nhận bằng bấm lần 2 trong 5 giây.
  let rebindArmedUntil = 0;
  function armed(button, prompt) {
    if (button.dataset.armedUntil && Date.now() < Number(button.dataset.armedUntil)) { delete button.dataset.armedUntil; button.textContent = button.dataset.label || button.textContent; return true; }
    button.dataset.label = button.dataset.label || button.textContent;
    button.dataset.armedUntil = String(Date.now() + 5000);
    button.textContent = prompt;
    setTimeout(() => { if (button.dataset.armedUntil && Date.now() >= Number(button.dataset.armedUntil)) { delete button.dataset.armedUntil; button.textContent = button.dataset.label; } }, 5100);
    return false;
  }
  $c('crStopNow').addEventListener('click', async event => {
    // v2.2.56 — 1 lần bấm là dừng (dừng an toàn, bấm Tiếp tục để chạy lại).
    event.currentTarget.disabled = true; event.currentTarget.textContent = 'Đang dừng…';
    const result = await sendRuntimeMessage({ type: 'STOP_CANCEL_RETURN_NOW' }).catch(error => ({ ok: false, error: error.message }));
    status(result?.ok ? `■ Đã dừng ngay — tab ${run?.platform === 'shopee' ? 'Shopee' : 'TikTok'} đã ngừng điền form.${result.note || ''} Bấm Tiếp tục để raise tiếp.` : (result?.error || 'Chưa dừng được.'), result?.ok ? '' : 'error');
    $c('crStopNow').disabled = false; $c('crStopNow').textContent = '■ Dừng ngay';
  });
  $c('crPause').addEventListener('click', () => sendRuntimeMessage({ type: 'PAUSE_CANCEL_RETURN' }).catch(reportError));
  $c('crSkipReply').addEventListener('click', async () => { const result = await sendRuntimeMessage({ type: 'SKIP_CANCEL_RETURN_REPLY' }); if (!result?.ok && result?.error) status(result.error, 'error'); });
  $c('crResume').addEventListener('click', async () => { const result = await sendRuntimeMessage({ type: 'RESUME_CANCEL_RETURN' }); if (!result?.ok && result?.error) status(result.error, 'error'); });
  chrome.tabs?.onActivated?.addListener(() => { if (shown) refreshShop().catch(() => {}); });
  setInterval(() => { if (shown && !running()) refreshShop().catch(() => {}); }, 5000);
  /* v2.2.88 — DÒNG TRỰC TIẾP: bước đang chạy trên từng tab raise (trước đây bị dòng trạng thái chung ghi đè) + đã chạy bao lâu;
     danh sách đơn bị bỏ qua kèm lý do (trước đây chỉ hiện khi đã có đơn xong). */
  const liveSteps = {};   // làn → { text, at, warn }
  function laneOfSender(sender) {
    const tabId = Number(sender?.tab?.id);
    if (!tabId || !run) return '';
    return Number(run.laneB?.tabId) === tabId ? 'B' : Number(run.activeTabId) === tabId || Number(run.workTabId) === tabId ? 'A' : '';
  }
  const secs = ms => { const s = Math.max(0, Math.round(ms / 1000)); return s >= 60 ? `${Math.floor(s / 60)}p${String(s % 60).padStart(2, '0')}` : `${s}s`; };
  function renderLive() {
    const box = $c('crLive'); if (!box) return;
    const lanes = [];
    if (run && !run.doneAt) {
      const orderOf = key => (String(key || '').match(/\|(\w{12,25})(?:\||$)/) || [])[1] || '';
      if (run.activeKey) lanes.push({ lane: 'A', order: orderOf(run.activeKey), since: Date.parse(run.activeOpenedAt || ''), step: liveSteps.A });
      if (run.laneB?.activeKey) lanes.push({ lane: 'B', order: orderOf(run.laneB.activeKey), since: Date.parse(run.laneB.openedAt || ''), step: liveSteps.B });
    }
    box.hidden = !lanes.length;
    box.innerHTML = lanes.map(item => {
      const age = Number.isFinite(item.since) ? Date.now() - item.since : 0;
      const slow = age > 90000;
      return `<div class="cr-live-row${slow ? ' slow' : ''}${item.step?.warn ? ' warn' : ''}"><b>${run.laneB ? `Tab ${item.lane === 'A' ? 1 : 2}` : 'Đang làm'}</b><span>${esc(item.order || '…')} · ${secs(age)}${slow ? ' ⚠ lâu' : ''}</span><em>${esc(item.step?.text || 'đang mở form TikTok…').slice(0, 160)}</em></div>`;
    }).join('');
    const skipped = (run?.skipped || []).filter(item => !groups[item.groupId]?.ticketId);
    $c('crSkippedBox').hidden = !skipped.length;
    if (skipped.length) {
      $c('crSkippedTitle').textContent = `⚠ ${skipped.length} đơn bị bỏ qua — xem lý do (đơn vẫn trong danh sách, bấm Raise để thử lại)`;
      $c('crSkipped').innerHTML = skipped.slice(-20).reverse().map(item => `<div><b>${esc(item.orderId || '?')}</b> — ${esc(String(item.error || '').slice(0, 220))}</div>`).join('');
    }
  }
  setInterval(() => { if (shown && run && !run.doneAt && document.visibilityState === 'visible') renderLive(); }, 1000);
  chrome.runtime.onMessage.addListener((message, sender) => {
    if (message?.type !== 'TICKET_STEP_TEXT' || message.followUp) return;
    const lane = laneOfSender(sender);
    if (lane) { liveSteps[lane] = { text: String(message.text || ''), at: Date.now(), warn: Boolean(message.warn) }; if (shown) renderLive(); }
  });
  chrome.runtime.onMessage.addListener(message => {
    if (!shown || message?.type !== 'TICKET_STEP_TEXT') return;
    // Bước phản hồi phiếu (tìm Số phiếu → Kiểm tra chi tiết → điền → Tải lên → Gửi) hiện ở cả 2 khung trạng thái.
    if (message.followUp) followStatus(message.text, message.warn ? 'error' : /^Phản hồi phiếu · ✓/.test(message.text) ? 'ok' : 'running');
    if (run && !run.doneAt && !(message.followUp && follow?.lane)) status(message.text, message.warn ? 'error' : 'running');
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    if (changes.cancelReturnGroups) groups = changes.cancelReturnGroups.newValue || {};
    if (changes.cancelReturnTickets) tickets = changes.cancelReturnTickets.newValue || {};
    if (changes.cancelReturnShopMap) shopMap = changes.cancelReturnShopMap.newValue || {};
    if (changes.cancelReturnRun) run = changes.cancelReturnRun.newValue || null;
    if (changes.cancelReturnFollowRun) follow = changes.cancelReturnFollowRun.newValue || null;
    if (changes.ticketOpenGroups) openGroups = changes.ticketOpenGroups.newValue || {};
    if (changes.cancelReturnLookup) { lookup = changes.cancelReturnLookup.newValue || null; if (shown) renderLookup(); }
    if (changes.cancelReturnTikTokScan) { tikTokScan = changes.cancelReturnTikTokScan.newValue || null; if (shown) renderTickets(); }
    if (!shown) return;
    // Không vẽ lại thẻ khi đang gõ nội dung trong chính thẻ đó (mất con trỏ).
    const typing = document.activeElement?.matches?.('#crGroups textarea, #crGroups input[type="text"], #crGroups [data-cr-manual]');
    if ((changes.cancelReturnGroups && !typing) || changes.cancelReturnShopMap) { renderChannels(); renderBinding(); renderGroups(); renderLookup(); }
    if (changes.cancelReturnRun || changes.ticketOpenGroups) { renderGroups(); renderRun(); }
    // Đang sửa nội dung phản biện → không vẽ lại (mất chữ đang gõ); vẽ lại khi rời ô.
    if ((changes.cancelReturnTickets || changes.cancelReturnFollowRun) && !document.activeElement?.matches?.('[data-cr-rebut-text]')) renderTickets();
    if (changes.cancelReturnFollowRun && follow?.lane) renderRun();
  });
  chrome.storage.local.get(['cancelReturnSettings', 'cancelReturnTracker', 'cancelReturnGroups', 'cancelReturnShopMap', 'cancelReturnTickets', 'cancelReturnRun', 'cancelReturnFollowRun', 'ticketOpenGroups', 'cancelReturnLookup', 'cancelReturnTikTokScan'], data => {
    openGroups = data.ticketOpenGroups || {}; lookup = data.cancelReturnLookup || null; tikTokScan = data.cancelReturnTikTokScan || null;
    settings = data.cancelReturnSettings || {}; tracker = data.cancelReturnTracker || null; groups = data.cancelReturnGroups || {};
    shopMap = data.cancelReturnShopMap || {}; tickets = data.cancelReturnTickets || {}; run = data.cancelReturnRun || null; follow = data.cancelReturnFollowRun || null;
    $c('crFollowText').value = settings.followText || '';
    loading = false; render();
  });
  /** Gọi từ handover_panel.applyWorkflow khi đổi Loại ticket. */
  globalThis.OPCancelReturnPanel = {
    show(visible, activePlatform = 'tiktok') {
      const first = visible && !shown;
      const next = activePlatform === 'shopee' ? 'shopee' : 'tiktok';
      if (next !== platform) {
        platform = next; shopName = ''; view.q = ''; view.limit = PAGE; view.raisedLimit = PAGE; view.open = ''; view.ticketFilter = 'all';
        // Chọn lại channel thuộc sàn vừa chuyển (giữ channel đang chọn nếu đúng sàn).
        const own = Object.values(groups).filter(group => ofPlatform(group) && !group.ticketId).map(group => group.channel);
        if (!own.includes(settings.channel)) settings.channel = own.sort((a, b) => a.localeCompare(b))[0] || '';
      }
      shown = Boolean(visible);
      $c('cancelReturnPanel').hidden = !shown;
      if (!shown) return;
      render(); refreshShop().catch(() => {});
      if (first && !loading && !tracker) fetchTracker().catch(reportError);
    }
  };
})();
