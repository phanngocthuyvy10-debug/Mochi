/* Actual captured KPI tickets -> the Performance Sheet, independently of
   Ticket Master's order-level dedupe. Durable enqueue happens before cleanup. */
(() => {
  const ALARM='op-performance-appeals', metrics={TIKTOK:['FDR','LDR'],SHOPEE:['FHR','LSR']};
  let writeChain=Promise.resolve(),flushing=null;
  const write=f=>{const p=writeChain.then(f);writeChain=p.catch(()=>{});return p;};
  async function enqueue(draft,ticketId,recordedAt=new Date().toISOString(),ticketUrl=''){
    const c=draft?.claim,platform=String(draft?.platform||'').toUpperCase(),id=String(ticketId||'').replace(/^#/,'').trim();
    const validTicket=platform==='SHOPEE'?/^[A-Z0-9][A-Z0-9_-]{4,49}$/i.test(id):/^\d{8,30}$/.test(id);
    if(!c||!metrics[platform]?.includes(c.metric)||!/^\d{5,24}$/.test(String(c.shopId||''))||!validTicket)return {ok:true,skipped:true};
    const key=[platform,c.shopId,c.metric,id].join('|');
    await write(async()=>{
      const {performanceAppealOutbox={},performanceAppealHistory={}}=await chrome.storage.local.get(['performanceAppealOutbox','performanceAppealHistory']);
      if(performanceAppealHistory[key]?.syncStatus==='Synced'||performanceAppealOutbox[key])return;
      const ticket={platform,metric:c.metric,ticketId:id,shopId:String(c.shopId),shopName:c.shopName||draft.channel||'',shopCode:c.shopCode||'',channelCode:c.channelCode||'',opolloCode:c.opolloCode||'',channelName:draft.channel||c.shopName||'',warehouse:draft.warehouse||'',createdAt:draft.createdAt||recordedAt,recordedAt,periodStart:c.periodStart||'',periodEnd:c.periodEnd||'',orderCount:Number(c.orders)||draft.rows?.length||0,representativeOrderId:String(draft.representativeOrderId||draft.rows?.[0]?.orderId||''),sourceFile:c.file||'',subject:platform==='TIKTOK'?'Tình trạng cửa hàng / Xếp hạng Cửa hàng / Điều chỉnh Xếp hạng Cửa hàng':draft.shopeeIssue||draft.issueType||'',ticketUrl};
      performanceAppealOutbox[key]={ticket,attempts:0};performanceAppealHistory[key]={...ticket,syncStatus:'Pending'};
      await chrome.storage.local.set({performanceAppealOutbox,performanceAppealHistory});
    });
    chrome.alarms.create(ALARM,{when:Date.now()+1000});flush().catch(()=>{});
    return {ok:true,queued:true,key};
  }
  async function flush(){
    if(flushing)return flushing;
    flushing=(async()=>{
      await writeChain;const {performanceAppealOutbox={}}=await chrome.storage.local.get('performanceAppealOutbox');
      if(!Object.keys(performanceAppealOutbox).length)return {ok:true,empty:true};
      const {settings}=await read();let error='';
      for(const [key,job] of Object.entries(performanceAppealOutbox)){
        try{await post(settings,{action:'appeal_ticket',ticket:job.ticket});
          await write(async()=>{const x=await chrome.storage.local.get(['performanceAppealOutbox','performanceAppealHistory']);const out=x.performanceAppealOutbox||{},history=x.performanceAppealHistory||{};delete out[key];history[key]={...job.ticket,syncStatus:'Synced',syncedAt:new Date().toISOString()};await chrome.storage.local.set({performanceAppealOutbox:out,performanceAppealHistory:history});});
        }catch(e){error=String(e.message||e);
          await write(async()=>{const x=await chrome.storage.local.get(['performanceAppealOutbox','performanceAppealHistory']),out=x.performanceAppealOutbox||{},history=x.performanceAppealHistory||{};if(out[key])out[key]={...out[key],attempts:(out[key].attempts||0)+1,error};history[key]={...job.ticket,syncStatus:'Pending',syncError:error};await chrome.storage.local.set({performanceAppealOutbox:out,performanceAppealHistory:history});});
          chrome.alarms.create(ALARM,{when:Date.now()+60000});break;
        }
      }
      return {ok:!error,error};
    })().finally(()=>{flushing=null;});return flushing;
  }
  globalThis.OPPerformanceAppeals={enqueue,flush};
  chrome.alarms.onAlarm.addListener(a=>{if(a.name===ALARM)flush().catch(()=>{});});
  chrome.runtime.onStartup?.addListener(()=>flush().catch(()=>{}));
  chrome.storage.onChanged?.addListener((c,area)=>{if(area==='local'&&c.settings)flush().catch(()=>{});});
  flush().catch(()=>{});
})();
