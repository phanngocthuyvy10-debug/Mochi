const $ = id => document.getElementById(id);
let initialized = false, userPicked = false, lastShop = '', detecting = false, stores = [], startupRetried = false, startupTested = false, lastDetect=0, lastTick=0, phase='',boundTabId=null,currentPlatform='TIKTOK';
const call = async m => { const r = await chrome.runtime.sendMessage(m); if (r?.error) throw Error(r.error); return r; };
function message(t, error = false) { $('message').textContent = t; $('message').style.display = t ? 'block' : 'none'; $('message').className = error ? 'error' : ''; }
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const dmy = x => /^\d{4}-\d{2}-\d{2}$/.test(String(x || '')) ? x.slice(8, 10) + '/' + x.slice(5, 7) + '/' + x.slice(0, 4) : String(x || '');
const pct = v => v == null ? '--' : (v * 100).toLocaleString('vi-VN', { maximumFractionDigits: 2 }) + '%';
const platformOf=x=>x?.platform==='SHOPEE'?'SHOPEE':'TIKTOK';
const fmt=(v,unit)=>v==null?'--':!unit||unit==='rate'?pct(v):Number(v).toLocaleString('vi-VN',{maximumFractionDigits:2})+(unit==='days'?' ngày':unit==='points'?' điểm':unit==='count'?' bưu kiện':'');
function download(name, content, type) { const url = URL.createObjectURL(new Blob([content], { type })); const a = document.createElement('a'); a.href = url; a.download = name; a.click(); setTimeout(() => URL.revokeObjectURL(url), 30000); }
async function activeTabId() { if(boundTabId!=null)return boundTabId;const [t] = await chrome.tabs.query({ active: true, currentWindow: true }); return t?.id; }

// Suggest the channel: exact Shop ID binding from TTS_Stores first, then the longest brand-name match.
function suggest(list, id) {
  if (!id) return -1;
  const exact = list.map((s,i)=>({s,i})).filter(({s})=>platformOf(s)===platformOf(id)&&String(s.shop_id||'')===id.shopId);
  if(exact.length)return exact.length===1 && exact[0].s.enabled!==false?exact[0].i:-1;
  const shop = ' ' + OPCore.norm(id.shopName).replace(/[^a-z0-9 ]/g, ' ') + ' ';
  let best = -1, score = 0, tied=false;
  list.forEach((s, i) => {
    if (s.enabled === false || s.shop_id || platformOf(s)!==platformOf(id)) return;
    const brand = OPCore.norm(String(s.channel_name).split(/\s+-\s+/)[0]).replace(/[^a-z0-9 ]/g, ' ').trim();
    const words = brand.split(/\s+/).filter(Boolean);
    if(words.length && words.every(w=>shop.includes(' '+w+' '))) {if(brand.length>score){best=i;score=brand.length;tied=false;}else if(brand.length===score)tied=true;}
  });
  return tied?-1:best;
}

async function detectNow(manual) {
  if (detecting) return; detecting = true;
  try {
    const tabId = await activeTabId(); const { identity } = await call({ type: 'DETECT', tabId });
    if (platformOf(identity)+':'+identity.shopId !== lastShop) { lastShop = platformOf(identity)+':'+identity.shopId; userPicked = false;message('');$('storeSearch').value='';$('store').value='';applySearch(false); }
    if (manual || /Tab đang ở trang đăng nhập|Tab đang ở trang đăng nhap/.test($('message').textContent)) message('');
  } catch (e) { lastShop='';userPicked=false;$('store').value='';$('storeHint').textContent='Chưa nhận diện được store đang login.';if (manual) message(e.message, true); }
  finally { detecting = false;lastDetect=Date.now();await render().catch(()=>{}); }
}

async function render() {
  const { state, settings, stores: allStores, version, pending = [], connectionError = '' } = await call({ type: 'GET' }); let list=allStores;boundTabId=state.run && (['collecting','enriching'].includes(state.run.phase)||state.run.workflow?.active)?state.run.tabId:null;const priorStores=stores;const tabId=await activeTabId(),id=state.detected[tabId];currentPlatform=platformOf(id||state.run);const visible=list.filter(x=>platformOf(x)===currentPlatform);
  if(id&&/^\d{5,24}$/.test(id.shopId||'')&&!visible.some(x=>String(x.shop_id||'')===id.shopId))visible.push({platform:currentPlatform,shop_id:id.shopId,shop_name:id.shopName,channel_code:(currentPlatform==='SHOPEE'?'SPE':'TTK')+id.shopId,channel_name:id.shopName+(currentPlatform==='SHOPEE'?' - Shopee':' - TikTok'),warehouse:'',auto_new:true});stores=visible;list=visible;
  $('ver').textContent = 'v' + version;
  const catalog = JSON.stringify(list);
  if ($('store').dataset.stores !== catalog) { const prevCode=priorStores[Number($('store').value)]?.channel_code, prev=$('store').value; $('store').innerHTML = '<option value="">— Chọn channel cho store này —</option>' + list.map((s, i) => `<option value="${i}" ${s.enabled === false ? 'disabled' : ''}>${esc(s.channel_code)} · ${esc(s.channel_name)}${s.warehouse ? ' · ' + esc(s.warehouse) : ''}${s.shop_id ? ' ✓' : ''}${s.enabled === false ? ' (đã tắt)' : ''}</option>`).join('') + '<option value="custom">+ Thêm channel mới</option>'; $('store').dataset.stores = catalog; const previous=list.findIndex(x=>x.channel_code===prevCode);$('store').value=prev==='custom'?'custom':prev!=='' && previous>=0?String(previous):''; applySearch(false); }
  if (!initialized) { $('collector').value = settings.collector || ''; $('dashUrl').value = settings.dashboardUrl || ''; $('endpoint').value = settings.endpoint; $('secret').value = settings.secret; $('autoSync').checked = settings.autoSync; $('autoStart').checked = !!settings.autoStart; if (!settings.endpoint || !settings.secret) $('conn').open = true; initialized = true; }
  $('connState').textContent = connectionError ? (settings.endpoint ? 'thiếu Khóa kết nối' : 'chưa cấu hình') : settings.connectionVerifiedAt ? 'đã kiểm tra kết nối' : 'cần kiểm tra kết nối';
  if ($('setupPrompt')) $('setupPrompt').hidden = !connectionError;
  $('connectionProblem').textContent = connectionError; $('connectionProblem').hidden = !connectionError;
  const serverProblem=currentPlatform==='SHOPEE'&&settings.connectionVerifiedAt&&(settings.serverOrderSchema<3||!settings.serverPlatforms?.includes('SHOPEE'))?'Apps Script chưa nhận Shopee. Cập nhật Code.gs + Dashboard.html v2.0.3 và triển khai Phiên bản mới. Dữ liệu lấy được vẫn giữ ở máy.':settings.serverWarning||'';$('serverProblem').textContent=serverProblem;$('serverProblem').hidden=!serverProblem;
  if(!startupTested&&!connectionError){startupTested=true;call({type:'TEST'}).then(r=>{if(r.warning)message(r.warning,true);}).catch(e=>message(e.message,true));}
  $('pendingInfo').hidden = !pending.length;
  $('pendingInfo').innerHTML = pending.length ? '<b>Dữ liệu đang chờ gửi lên Sheet</b>' + pending.map(p => `<div>${esc(p.code)} · ${esc(p.name)}<br>${p.orders.toLocaleString('vi-VN')} đơn theo KPI · ${p.daily.toLocaleString('vi-VN')} dòng ngày · ${p.uploads} lượt gửi${p.parts ? ` · đã gửi ${p.sent}/${p.parts} phần` : ''}</div>`).join('') : '';
  if (!startupRetried && pending.length && !connectionError) {
    startupRetried = true;
    call({ type: 'RETRY' }).then(r => message(r.ok ? 'Đã gửi dữ liệu đang chờ lên Performance. Mở Dashboard để xem.' : r.continuing ? `Đang gửi ${r.sent}/${r.total} phần, tool tự gửi tiếp nền.` : 'Chưa gửi được: ' + r.error, !r.ok && !r.continuing)).catch(e => message(e.message, true));
  }


  if((id?platformOf(id)+':'+id.shopId:'')!==lastShop){lastShop=id?platformOf(id)+':'+id.shopId:'';userPicked=false;message('');$('storeSearch').value='';$('store').value='';applySearch(false);}
  $('identity').innerHTML = id ? `<strong>${esc(id.shopName)}</strong><span>${esc(platformOf(id))} · Shop ID ${esc(id.shopId)}${id.shopCode ? ' · Shop Code ' + esc(id.shopCode) : ''}</span>` : '<span>Chưa nhận diện. Mở tab Seller Center của store đã login (F5 nếu vừa cài extension).</span>';
  const bound=id?list.filter(s=>platformOf(s)===platformOf(id)&&String(s.shop_id||'')===id.shopId):[];
  $('store').disabled=bound.length===1;
  $('storeSearch').disabled=bound.length===1;
  $('channelPicker').hidden=bound.length===1 && bound[0].enabled!==false;
  if(id && (!userPicked || bound.length)) { const i=suggest(list,id);if(i>=0){$('store').value=String(i);$('storeHint').textContent=list[i].auto_new?'Store mới · sẽ tự thêm vào Sheet khi lưu.':list[i].shop_id?`Tự nhận diện: ${list[i].channel_code} · tiếp tục lưu vào store này.`:'Khớp tên shop — lần lấy đầu sẽ nhớ Seller ID cho channel này.';}else{$('store').value='';$('storeHint').textContent=bound.some(s=>s.enabled===false)?'Channel của store này đã tắt trong TTS_Stores.':bound.length>1?'Seller ID gắn nhiều channel — cần sửa TTS_Stores.':'Chưa có mapping rõ ràng. Chọn channel một lần rồi bấm Lấy dữ liệu để ghi nhớ.';}}
  $('customStore').hidden = $('store').value !== 'custom';

  const r = !id || platformOf(state.run)===platformOf(id) && String(state.run?.shopId||'')===String(id.shopId) ? state.run : null;
  const busy = !!r && (['collecting','enriching'].includes(r.phase) || r.workflow?.active);
  phase=busy?'enriching':r?.phase||'';
  $('begin').disabled = busy || detecting || !id || !$('store').value; $('begin').textContent = busy ? r.workflow?.stage==='upload'?'Đang tự lưu Sheet…':'Đang tự lấy dữ liệu…' : r && platformOf(r)!=='SHOPEE' && platformOf(r)===platformOf(id) && r.shopId === id?.shopId && r.phase==='done' && r.syncStatus!=='ĐÃ LƯU' ? 'Bổ sung dữ liệu & tự lưu' : 'Lấy toàn bộ & tự lưu';
  $('refreshAll').disabled = $('begin').disabled;$('openDash').disabled=busy;
  const upLog=busy&&r?.workflow?.stage==='upload'?[...(state.log||[])].reverse().find(l=>/^(Gửi |Lịch sử ngày )/.test(l.msg||''))?.msg:'';
  $('workflowStatus').textContent = busy&&r?.workflow?.stage==='upload' ? 'Đang lưu lên Sheet'+(upLog?' · '+upLog:'')+'. Mỗi phần mất khoảng 10–20 giây. Chưa đổi store cho tới khi báo ✓ Đã lưu xong.' : r?.workflow?.message || (r?.navigation?'Đang chuyển nguồn Shopee trên tab hiện tại; xong sẽ tự đọc tiếp.':r?.phase==='collecting'?'Đang lấy KPI, toàn bộ danh sách đơn lỗi và lịch sử. Xong sẽ tự bổ sung mốc rồi gửi Sheet.':settings.autoStart?'Đã bật tự động. Login store để tự lấy và lưu; store mới sẽ tự thêm vào Sheet. Giữ Chrome mở đến khi xong.':'Bấm Lấy toàn bộ & tự lưu một lần. Không cần bấm Lưu riêng.');
  $('workflowStatus').className='workflow'+(r?.workflow?.status==='partial'||r?.workflow?.status==='queued'?' warn':'');
  if(r?.workflow?.active && r.workflow.stage==='waiting' && Date.now()-lastTick>5000){lastTick=Date.now();call({type:'AUTO_TICK',tabId:r.workflow.wait?.tabId}).catch(()=>{});}
  $('sync').disabled = !r || busy || r.phase !== 'done' || r.syncStatus === 'ĐÃ LƯU';
  $('enrich').disabled = !r || busy || r.phase !== 'done' || !r.details?.total;
  $('performance').disabled = !r || busy || r.phase !== 'done' || !r.details?.total;
  $('importDetails').disabled = !r || busy || r.phase !== 'done';
  $('exportOrders').disabled = !r || busy;
  $('close').disabled = busy; $('closeLocal').disabled = busy;
  const labels = {created_at:'Placement time',actual_handover_at:'Actual handover time (sàn)',shipping_location:'Shipping location',delivery_type:'Delivery type / Send By',pickup_type:'Pickup type',paid_at:'Paid Time',is_preorder:'Is Preorder',sla_rule:'SLA rule',tracking_id:'Mã vận đơn',status:'Trạng thái',rts_at:'Sẵn sàng giao',pickup_at:'Pickup time',delivered_at:'Đã giao',deadline:'Hạn xử lý',carrier:'Đơn vị vận chuyển'};
  if(platformOf(r)==='SHOPEE')Object.assign(labels,{confirmed_at:'Thời gian xác nhận',first_attempt_at:'Giao lần đầu',estimated_delivery_at:'Giao dự kiến'});
  $('tiktokAdvanced').hidden=currentPlatform==='SHOPEE';$('shopeeReportImport').hidden=false;$('channelCode').placeholder=currentPlatform==='SHOPEE'?'SPE...':'TTK...';$('channelName').placeholder=currentPlatform==='SHOPEE'?'Tên store - Shopee':'Tên store - TikTok';
  $('detailCoverage').innerHTML = r?.details?.total ? `<div class="coverage"><b>Chi tiết ${r.details.total.toLocaleString('vi-VN')} đơn duy nhất</b><p class="hint">${busy?'Đang bổ sung các mốc theo Order ID; sẽ tự lưu sau khi đọc xong.':!r.details.counts.actual_handover_at?'Snapshot chưa có Actual handover time. Đã gửi Sheet chỉ xác nhận phần dữ liệu đang có. Mở bảng hiệu suất đúng shop/KPI rồi chọn Nâng cao → Lấy mốc từ bảng đang mở để bổ sung; cũng có thể dùng file xuất gốc.':'Các ô trống là trường chưa nhận được từ nguồn hoặc mốc chưa xảy ra.'}</p>${Object.entries(labels).map(([k,label])=>`<div><span>${label}</span><strong>${r.details.counts[k] || 0}/${r.details.total}</strong></div>`).join('')}</div>` : '';
  $('detailError').hidden = !r?.detailError; $('detailError').textContent = r?.detailError || '';
  const fieldsPending=!!r?.details?.total && ['created_at','actual_handover_at','shipping_location','delivery_type','pickup_type'].some(k=>(r.details.counts[k]||0)<r.details.total);
  $('runState').textContent = !r ? 'Chưa bắt đầu' : busy ? 'ĐANG LẤY' : r.phase === 'error' ? 'LỖI' : (r.closed ? 'ĐÃ KẾT THÚC · ' : '') + r.syncStatus + (fieldsPending ? ' · CÒN CỘT TRỐNG' : '');
  $('runState').className = 'badge ' + (r?.syncStatus === 'ĐÃ LƯU' && !fieldsPending ? 'ok' : r?.phase === 'error' ? 'bad' : '');
  $('runInfo').textContent = r ? `${r.business_code||r.shopCode||r.shopName} · ${r.shopName} · ${r.week} · ${new Date(r.capturedAt).toLocaleString('vi-VN')}${r.dailyRows ? ' · lịch sử ' + r.dailyRows + ' dòng ngày' : ''}` : '';
  $('openDash').hidden = !(settings.dashboardUrl || settings.endpoint); $('openDash').dataset.url = settings.dashboardUrl || settings.endpoint || '';
  const ms = r?.metrics || (currentPlatform==='SHOPEE'?OPShopee.defs:OPCore.defs).map(d => ({ ...d, value: null, raw: '', count: 0, coverage: 'CHƯA LẤY' }));
  $('metrics').innerHTML = ms.map(m => { const st = OPCore.status(m); const t = m.threshold ? `Mục tiêu ${m.threshold.direction} ${fmt(m.threshold.target,m.unit)}` : '';
    return `<div class="metric"><span>${esc(m.name)}</span><strong class="${st === 'FAIL' ? 'fail' : ''}">${m.source ? fmt(m.value,m.unit) : '—'}</strong>
    <div class="detail">${m.source ? `<b class="${st === 'FAIL' ? 'fail' : st === 'PASS' ? 'good' : ''}">${esc(st)}</b> · ${esc(t)}<br>Thời gian đánh giá: ${esc(dmy(m.period_start))} - ${esc(dmy(m.period_end))}` : ''}</div>
    ${m.source ? `<div class="detail ${m.coverage === 'ĐỦ ĐƠN' || m.coverage === 'N/A' ? 'good' : 'warn'}">${esc(m.coverage)} · ${esc(m.notes)}</div>` : ''}</div>${m.code === 'FHR' && globalThis.OPFhrRecalc?.html ? `<div id="fhrRecalcBox" class="fhrr">${globalThis.OPFhrRecalc.html}</div>` : ''}`; }).join(''); // v2.2.9 — FHR tính lại vẽ cùng lượt (panel-appeal.js chuẩn bị HTML), không chèn sau → hết nháy
  $('log').innerHTML = (state.log || []).slice().reverse().map(x => `<div>${esc(new Date(x.at).toLocaleTimeString('vi-VN'))} ${esc(x.msg)}</div>`).join('');
}
function bind(id, fn) { $(id).onclick = async () => { const b = $(id); b.disabled = true; try { await fn(); } catch (e) { message(e.message, true); } finally { b.disabled = false; render().catch(() => {}); } }; }
function applySearch(pick) {
  const q = OPCore.norm($('storeSearch').value).replace(/[^a-z0-9 ]/g, ' ').trim(), words = q.split(/\s+/).filter(Boolean);
  let first = null, shown = 0;
  for (const o of $('store').options) {
    const hay = OPCore.norm(o.textContent).replace(/[^a-z0-9 ]/g, ' ');
    const hit = o.value === 'custom' || o.value==='' || words.every(w => hay.includes(w));
    o.hidden = !hit; if (hit && o.value !== 'custom' && o.value!=='' && !o.disabled) { shown++; if (!first) first = o; }
  }
  if (pick && words.length && first && !$('store').disabled) { $('store').value = first.value; userPicked = true; $('customStore').hidden = true; }
  $('storeHint').textContent = words.length ? (shown ? `${shown} channel khớp${first ? ' · đang chọn ' + first.textContent.split(' · ')[0] : ''}` : 'Không có channel khớp — chọn "+ Thêm channel mới".') : $('storeHint').textContent;
}
$('storeSearch').oninput = () => applySearch(true);
$('storeSearch').onkeydown = e => { if (e.key === 'Enter') { e.preventDefault(); applySearch(true); $('begin').focus(); } if (e.key === 'Escape') { $('storeSearch').value = ''; applySearch(false); } };
$('store').onchange = () => { userPicked = true; $('storeHint').textContent = ''; $('customStore').hidden = $('store').value !== 'custom'; };
bind('redetect', () => detectNow(true));
async function runAll(refresh=false) {
  if(!$('store').value)throw Error('Chọn channel cho store chưa có mapping.');
  const store = $('store').value === 'custom' ? { channel_name: $('channelName').value.trim(), channel_code: $('channelCode').value.trim().toUpperCase(), warehouse: $('warehouse').value.trim() } : stores[Number($('store').value)];
  message('Đang tự lấy và lưu dữ liệu. Giữ Chrome mở; không cần bấm Lưu riêng.');
  await call({ type: 'RUN_ALL', store, refresh, tabId: await activeTabId(),historyDays:Number($('historyDays').value) || 30 });
}
bind('begin',()=>runAll());
bind('refreshAll',()=>runAll(true));
$('autoStart').onchange=async()=>{try{await call({type:'AUTO_START',enabled:$('autoStart').checked});if($('autoStart').checked)await detectNow(false);message($('autoStart').checked?'Đã bật tự lấy và lưu khi login store.':'Đã tắt tự bắt đầu; vẫn có thể bấm Lấy toàn bộ & tự lưu.');}catch(e){message(e.message,true);}};
bind('enrich',async()=>{message('Đang đọc chi tiết từng đơn lỗi… giữ tab TikTok mở.');await call({type:'ENRICH',tabId:await activeTabId()});});
bind('performance',async()=>{message('Đang lấy mốc xử lý từ API hoặc bảng đang mở, ghép theo Order ID…');await call({type:'ENRICH',mode:'performance',code:$('performanceMetric').value,tabId:await activeTabId()});});
bind('sourceDiagnostic',async()=>{const r=await call({type:'SOURCE_DIAGNOSTIC',tabId:await activeTabId()});download('OP_TTS_API_Source_'+new Date().toISOString().slice(0,10)+'.json',JSON.stringify(r,null,2),'application/json');message('Đã xuất tên trường và trạng thái nguồn API. File không chứa cookie, token hoặc Khóa kết nối.');});
bind('importDetails',async()=>{
  const files = [...($('detailFile').files || [])]; if (!files.length) throw Error('Chọn file xuất đơn hàng của store hiện tại.');
  const {state} = await call({type:'GET'}), run = state.run; if (!run) throw Error('Lấy danh sách lỗi trước.');
  const all = [];
  for (const f of files) {
    if (f.size > 50*1024*1024) throw Error('File quá lớn. Xuất từng tháng rồi chọn các file đó.');
    const book = XLSX.read(await f.arrayBuffer(),{type:'array',raw:true});const model=platformOf(run)==='SHOPEE'?OPShopee:OPDetails;
    for (const name of book.SheetNames) {
      const sheet = book.Sheets[name], raw = XLSX.utils.sheet_to_json(sheet,{header:1,raw:true,defval:''});
      // Refuse numeric IDs that Excel has already rounded before using formatted cell text.
      model.fromTable(raw);
      const table = XLSX.utils.sheet_to_json(sheet,{header:1,raw:false,defval:''});
      all.push(...model.fromTable(table));
    }
  }
  message(`Đang ghép ${all.length.toLocaleString('vi-VN')} dòng theo mã đơn…`);
  const r = await call({type:'DETAILS_IMPORT',runId:run.id,shopId:run.shopId,rows:all});
  message(`Khớp ${r.matched} dòng theo KPI; bổ sung ${r.updated} dòng.${r.sync?.ok ? ' Đã lưu Sheet.' : r.sync ? ' Đang chờ gửi: '+r.sync.error : ''}`,!!r.sync && !r.sync.ok);
});
bind('importReport',async()=>{const files=[...($('reportFile').files||[])];if(!files.length)throw Error('Chọn OnPoint_summary.xlsx (có thể chọn nhiều tuần/quý).');let total=0;const done=[];const periods=new Set();
  // Parse every file before sending anything: a bad file must not leave a partially imported batch.
  const batch=[];for(const f of files.sort((x,y)=>x.name.localeCompare(y.name))){if(f.size>50*1024*1024)throw Error(f.name+': báo cáo quá lớn.');const date=f.name.match(/(20\d{2})[-_.]?(\d{2})[-_.]?(\d{2})/);const b=XLSX.read(await f.arrayBuffer(),{type:'array',cellDates:false});const summary=XLSX.utils.sheet_to_json(b.Sheets.Summary,{header:1,raw:true,defval:''});const data=OPShopee.reportBundle({Summary:summary},date?`${date[1]}-${date[2]}-${date[3]}`:$('reportDate').value);batch.push({file:f,...data});}
  for(const data of batch){message(`Đang lưu ${data.file.name} (${done.length+1}/${files.length})…`);const result=await call({type:'REPORT_IMPORT',rows:data.rows,summary:data.summary,source:data.file.name});total+=result.rows;data.periods.forEach(r=>periods.add(`${r.year}-Q${r.quarter}-W${r.week}`));done.push(data.file.name);}
  message(`Đã lưu ${total} số liệu, ${periods.size} tuần từ ${done.length} file. Dashboard → Shopee Enabler → chọn Quý / Tuần / Tuần hoặc QTD.`);
});
let submitPreview = null;
$('submitFile').onchange=()=>{submitPreview=null;$('submitPreview').textContent='';$('saveSubmit').disabled=true;};
bind('previewSubmit',async()=>{submitPreview=null;$('saveSubmit').disabled=true;const f=$('submitFile').files?.[0];if(!f)throw Error('Chọn file list submit.');if(f.size>50*1024*1024)throw Error('File quá lớn.');const b=XLSX.read(await f.arrayBuffer(),{type:'array',cellDates:false});const tables=Object.fromEntries(b.SheetNames.map(n=>[n,XLSX.utils.sheet_to_json(b.Sheets[n],{header:1,raw:true,defval:''})]));const rows=OPShopee.submitList(tables);submitPreview={source:f.name,rows};$('submitPreview').innerHTML=`<p><b>${rows.length} shop · ${esc(f.name)}</b></p><p>Danh sách này sẽ thay list submit hiện tại khi bấm Cập nhật.</p><div style="max-height:220px;overflow:auto">${rows.map(r=>`<div>${esc(r.shopId)} · ${esc(r.shopName)}</div>`).join('')}</div>`;$('saveSubmit').disabled=false;});
bind('saveSubmit',async()=>{if(!submitPreview)throw Error('Đọc & xem list trước khi cập nhật.');const r=await call({type:'ENABLER_SUBMIT',...submitPreview});message(`Đã cập nhật list submit cố định: ${r.shops} shop. Các report tuần đã lưu vẫn được giữ.`);});
bind('sync', async () => { const r = await call({ type: 'SYNC' }); message(r.ok ? 'Đã lưu Performance.' : r.continuing ? `Đang gửi ${r.sent}/${r.total} phần, tool tự gửi tiếp nền — có thể bấm việc khác.` : 'Chưa gửi được: ' + (r.error || 'đang chờ gửi lại'), !r.ok && !r.continuing); });
bind('close', async () => { await call({ type: 'CLOSE' }); message('Đã kết thúc. Logout và login store tiếp theo.'); });
bind('closeLocal', async () => { await call({ type: 'CLOSE', keepLocal: true }); message('Đã kết thúc, dữ liệu nằm trong hàng đợi gửi Sheet.'); });
function connectedMessage(r) { const text=r.sync?.ok ? (r.sync.empty ? 'Đã kết nối: ' + r.sheet_name + '.' : 'Đã kết nối: ' + r.sheet_name + ' · đã gửi dữ liệu đang chờ.') : 'Đã kết nối: ' + r.sheet_name + '. Chưa gửi xong: ' + (r.sync?.error || 'xem Nhật ký');return text+(r.warning?' '+r.warning:''); }
bind('settings', async () => { message('Đang kiểm tra kết nối và gửi dữ liệu đang chờ…'); const r = await call({ type: 'SETTINGS', settings: { endpoint: $('endpoint').value.trim(), secret: $('secret').value.trim(), autoSync: $('autoSync').checked } }); message(connectedMessage(r), !r.sync?.ok); });
bind('test', async () => { const r = await call({ type: 'TEST' }); message('Đã kết nối: ' + r.sheet_name+(r.warning?' · '+r.warning:''),!!r.warning); });
async function openViewDashboard(){try{if(boundTabId!=null)throw Error('Đang thu thập. Chờ tự lưu xong rồi mở Dashboard.');message('Đang mở Dashboard…');const r=await call({type:'VIEW_URL'});const [t]=await chrome.tabs.query({active:true,currentWindow:true});if(t&&!/^https:\/\/(seller-vn\.tiktok\.com|banhang\.shopee\.vn)\//.test(t.url||''))await chrome.tabs.update(t.id,{url:r.url});else await chrome.tabs.create({url:r.url});message('');}catch(e){message(e.message,true);}}
$('openDash').onclick = openViewDashboard;$('viewDash').onclick = openViewDashboard;
bind('copyView',async()=>{const r=await call({type:'VIEW_URL'});message(await copy(r.url)?'Đã copy link Dashboard của bạn.':'Link: '+r.url);});
bind('renewView',async()=>{const r=await call({type:'VIEW_URL',renew:true});message('Đã tạo link Dashboard mới.'+(await copy(r.url)?' Link đã được copy.':''));});
(function(){
  const tabs=['collect','view','ticket','admin'].map(r=>[r,$('role_'+r)]).filter(x=>x[1]);
  let role='collect';try{role=localStorage.getItem('opRole')||'collect';}catch(e){}
  const set=r=>{
    if(!tabs.some(([k])=>k===r))r='collect';
    if(document.body)document.body.dataset.role=r;
    tabs.forEach(([k,b])=>{b.setAttribute?.('aria-selected',String(k===r));b.tabIndex=k===r?0:-1;});
    try{localStorage.setItem('opRole',r);}catch(e){}
    if(r==='admin'&&$('team')?.open)loadShares();
  };
  tabs.forEach(([k,b])=>b.onclick=()=>set(k));set(role);
  if($('setupConnection'))$('setupConnection').onclick=()=>{set('admin');$('conn').open=true;$('endpoint').focus();};
})();
bind('saveDash', async () => { await call({ type: 'DASHBOARD_URL', url: $('dashUrl').value }); message('Đã lưu link Dashboard.'); });
const copy = async t => { try { await navigator.clipboard.writeText(t); return true; } catch { return false; } };
bind('saveCollector', async () => { await call({ type: 'COLLECTOR', name: $('collector').value }); message('Đã lưu tên người lấy.'); });
bind('invite', async () => { const r = await call({ type: 'INVITE_CODE' }); const ok = await copy(r.code); $('code').value = ''; message(ok ? 'Đã copy mã mời. Gửi cho người lấy dữ liệu: họ cài extension, mở "Nhóm & chia sẻ", dán mã.' : 'Copy mã này: ' + r.code); });
bind('connect', async () => { message('Đang kiểm tra kết nối và gửi dữ liệu đang chờ…'); const r = await call({ type: 'CONNECT_CODE', code: $('code').value }); $('code').value = ''; initialized = false; message(connectedMessage(r), !r.sync?.ok); });
async function loadShares() { try { const r = await call({ type: 'SHARE_LIST' }); $('shareList').innerHTML = r.links.length ? r.links.map(l => `<div class="share"><span><b>${esc(l.label)}</b> · ${l.scope === 'full' ? 'đầy đủ' : 'chỉ KPI'}${l.by ? ' · ' + esc(l.by) : ''}</span><button class="mini subtle" data-copy="${esc(l.url)}">Copy</button><button class="mini subtle" data-revoke="${esc(l.key)}">Thu hồi</button></div>`).join('') : 'Chưa có link chia sẻ.';
  $('shareList').querySelectorAll('[data-copy]').forEach(b => b.onclick = async () => message(await copy(b.dataset.copy) ? 'Đã copy link.' : b.dataset.copy));
  $('shareList').querySelectorAll('[data-revoke]').forEach(b => b.onclick = async () => { try { await call({ type: 'SHARE_REVOKE', key: b.dataset.revoke }); message('Đã thu hồi link. Người đang mở link sẽ không tải được dữ liệu nữa.'); loadShares(); } catch (e) { message(e.message, true); } });
} catch (e) { $('shareList').textContent = e.message; } }
$('team').ontoggle = () => { if ($('team').open) loadShares(); };
bind('shareCreate', async () => { const r = await call({ type: 'SHARE_CREATE', scope: $('shareScope').value, label: $('shareLabel').value }); const ok = await copy(r.url); message(ok ? 'Đã tạo và copy link dashboard. Gửi cho ai cũng mở được.' : 'Link: ' + r.url); $('shareLabel').value = ''; loadShares(); });
bind('retry', async () => { const r = await call({ type: 'RETRY' }); message(r.ok ? 'Đã gửi dữ liệu đang chờ.' : r.continuing ? `Đang gửi ${r.sent}/${r.total} phần, tool tự gửi tiếp nền.` : r.error || 'Chưa kết nối Web App.', !r.ok && !r.continuing); });
bind('backup', async () => { const r = await call({ type: 'EXPORT_BACKUP' }); download('OP_TTS_Backup_' + new Date().toISOString().slice(0, 10) + '.json', JSON.stringify(r), 'application/json'); message('Đã sao lưu toàn bộ hàng đợi, đơn lỗi và lịch sử ngày. File không chứa Khóa kết nối.'); });
bind('exportOrders',async()=>{
  const r=await call({type:'EXPORT'});
  const fields=[['metric','KPI'],['order_id','Order ID'],['created_at','Placement time'],['actual_handover_at','Actual handover time (Platform)'],['shipping_location','Shipping location'],['delivery_type','Delivery type'],['pickup_type','Pickup type'],['paid_at','Paid Time'],['rts_at','RTS time'],['pickup_at','Pickup time'],['delivered_at','Delivered time'],['deadline','Deadline'],['tracking_id','Tracking ID'],['status','Order Status'],['carrier','Carrier'],['is_preorder','Is Preorder'],['sla_rule','SLA rule'],['confirmed_at','Confirmed At'],['first_attempt_at','First Delivery Attempt'],['estimated_delivery_at','Estimated Delivery'],['platform_order_id','Internal Order ID'],['order_sn','Order SN'],['period_start','Evaluation start'],['period_end','Evaluation end']];
  download(`${platformOf(r.run)==='SHOPEE'?'SPE':'TTS'}_don_loi_${r.run.channel_code}_v2.0.3.csv`,OPCore.csv([fields.map(([,name])=>name),...r.orders.map(o=>fields.map(([key])=>o[key]??''))]),'text/csv;charset=utf-8');
  const n=new Set(r.orders.filter(o=>o.actual_handover_at).map(o=>o.order_id)).size,total=new Set(r.orders.map(o=>o.order_id)).size;
  message(`Đã xuất CSV ${r.orders.length} dòng theo KPI, đủ cột. Actual handover time: ${n}/${total} đơn; ô trống cần bổ sung từ nguồn thật.`,n<total);
});
bind('export', async () => {
  const r = await call({ type: 'EXPORT' });
  const k1 = ['code', 'name', 'value', 'target', 'status', 'period_start', 'period_end', 'error_orders', 'coverage', 'notes'];
  const k2 = ['metric','order_id','created_at','actual_handover_at','shipping_location','delivery_type','pickup_type','paid_at','is_preorder','sla_rule','tracking_id','status','rts_at','pickup_at','delivered_at','deadline','carrier','confirmed_at','first_attempt_at','estimated_delivery_at','platform_order_id','order_sn','reason','period_start','period_end','evidence'];
  download(`OP_TTS_${r.run.channel_code}_${r.run.week}.csv`, OPCore.csv([[`${r.run.channel_code} · ${r.run.shopName} · ${r.run.shopId} · ${r.run.capturedAt}`], k1,
    ...r.run.metrics.map(m => [m.code, m.name, m.value, m.threshold ? m.threshold.direction + m.threshold.target : '', OPCore.status(m), m.period_start, m.period_end, m.count, m.coverage, m.notes]), [], k2, ...r.orders.map(o => k2.map(k => o[k] || ''))]), 'text/csv;charset=utf-8');
  message('Đã xuất CSV.');
});
render().then(() => detectNow(false)).catch(e => message(e.message, true));
setInterval(() => { if (document.visibilityState !== 'hidden') render().catch(() => {}); }, 1500);
chrome.tabs.onActivated.addListener(() => detectNow(false));
chrome.tabs.onUpdated.addListener((tabId, info) => { if (info.status === 'complete') setTimeout(() => detectNow(false), 1500); });
setInterval(()=>{if(document.visibilityState !== 'hidden' && !detecting && !['collecting','enriching'].includes(phase) && Date.now()-lastDetect>=8000)detectNow(false);},8000);
