/* Isolated world: chuyển danh sách đơn từ fhr-recalc.js về extension. */
addEventListener('message', e => {
  if (e.source !== window || e.origin !== location.origin || e.data?.type !== 'OP_FHR_RECALC') return;
  chrome.runtime.sendMessage({ type: 'FHR_RECALC', orders: e.data.orders, shopId: e.data.shopId, weeks: e.data.weeks, username: e.data.username || '', info: document.title }).then(r => {
    if (!r?.ok) return; let tag = document.getElementById('op-fhr-tag');
    if (!tag) { tag = document.createElement('div'); tag.id = 'op-fhr-tag'; tag.style.cssText = 'position:fixed;right:16px;bottom:16px;z-index:2147483647;background:#0f7b5f;color:#fff;font:600 13px/1.4 system-ui;padding:10px 14px;border-radius:10px;box-shadow:0 4px 14px #0003;max-width:420px'; document.documentElement.appendChild(tag); }
    const pct = v => (v * 100).toLocaleString('vi-VN', { maximumFractionDigits: 2 }) + '%', dmy = d => d.split('-').reverse().join('/');
    tag.textContent = ['OnPoint:',
      r.weeks?.length ? `FHR tính lại ${r.weeks.map(w => `${pct(w.value)} (cập nhật ${dmy(w.date)})`).join(' · ')}` : '',
      r.count ? `· ${r.count} đơn bị ảnh hưởng` : '',
      r.weeks?.length ? (r.saved ? `· đã lưu cho Shop ID ${r.shopId}, tự đưa lên Performance` : '· chưa xác định được shop — mở tab Kênh Người Bán của shop này rồi F5 trang này') : ''].filter(Boolean).join(' ');
  }).catch(() => {});
});
