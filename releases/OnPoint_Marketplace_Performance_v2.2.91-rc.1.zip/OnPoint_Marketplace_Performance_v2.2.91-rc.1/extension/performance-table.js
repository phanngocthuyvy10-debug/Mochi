/* Read the rendered operational table when its private API is unknown.
   Uses literal column headings, actual pagination controls and the active shop.
   No guessed endpoints, SKU output, buyer data or fabricated timestamps. */
(() => {
  if (window.OPPerformanceTable) return;
  const D = window.OPDetails;
  const ROW = 'tr,[role="row"],[class*="table-tr"]';
  const CELL = 'th,td,[role="columnheader"],[role="cell"],[role="gridcell"],[class*="table-th"],[class*="table-td"]';
  const HEAD = 'thead th,[role="columnheader"],[class*="table-th"]';
  const pause = ms => new Promise(r => setTimeout(r,ms));
  const text = el => String(el?.innerText ?? el?.textContent ?? '').replace(/\u00a0/g,' ').trim();
  function shown(el) {
    if (!el || !el.isConnected || el.closest('[hidden],[aria-hidden="true"]')) return false;
    if(typeof el.getClientRects==='function' && !el.getClientRects().length)return false;
    const s = getComputedStyle(el);
    return s.display !== 'none' && s.visibility !== 'hidden';
  }
  function cells(row) {
    return [...row.querySelectorAll(CELL)].filter(c => c.closest(ROW) === row);
  }
  const handoverHeader=v=>D.fields.actual_handover_at.some(h=>D.norm(h)===D.norm(v));
  function isHeader(values) {
    return values.some(s=>/^order id(?:\s*\/\s*placement time)?$|^ma don hang$/.test(D.norm(s))) &&
      values.some(handoverHeader);
  }
  function snapshot(root) {
    const lines = [...root.querySelectorAll(ROW)].filter(shown).map(row=>cells(row).map(text)).filter(r=>r.length);
    const headerIndex = lines.findIndex(isHeader);
    if (headerIndex < 0) return null;
    const headers = lines[headerIndex];
    // Header/body may live in separate native tables under the same Arco wrapper.
    const linesWithCells = lines.slice(headerIndex+1).filter(r=>r.length===headers.length && !isHeader(r));
    const rows = D.fromTable([headers,...linesWithCells]);
    return {root,headers,rows,rawCount:linesWithCells.length,key:JSON.stringify(rows)};
  }
  function locate() {
    if (!window.document?.querySelectorAll) return null;
    const candidates = new Map();
    for (const h of document.querySelectorAll(HEAD)) {
      if (!shown(h) || !handoverHeader(text(h))) continue;
      let root = h.closest(ROW)?.parentElement;
      for (let depth=0;root && root!==document.body && depth<9;depth++,root=root.parentElement) {
        const snap = snapshot(root);
        if (snap) candidates.set(root,snap);
      }
    }
    // Prefer the smallest wrapper containing the most rows, retaining nearby pagination.
    return [...candidates.values()].sort((a,b)=>b.rows.length-a.rows.length || a.root.querySelectorAll('*').length-b.root.querySelectorAll('*').length)[0] || null;
  }
  function disabled(el) {
    return !!el && (!!el.disabled || el.getAttribute('aria-disabled')==='true' || /(?:^|[-_\s])disabled(?:$|[-_\s])/.test(String(el.className)));
  }
  function controls(snap) {
    let scope = snap.root;
    for (let depth=0;scope && scope!==document.body && depth<5;depth++,scope=scope.parentElement) {
      const pagers = [...scope.querySelectorAll('[class*="pagination"],[aria-label*="pagination"],[aria-label*="Pagination"]')].filter(shown);
      for (const pager of pagers) {
        if (pager.closest('[role="dialog"]') && !snap.root.closest('[role="dialog"]')) continue;
        const buttons = [...pager.querySelectorAll('button,a,[role="button"],li[class*="item-next"],li[class*="item-prev"]')].filter(shown);
        const label = b => D.norm(b.getAttribute('aria-label') || b.title || text(b));
        const next = buttons.find(b=>/^(?:next|next page|go to next page|trang sau|trang tiep|tiep|trang ke tiep)$/.test(label(b)) || /(?:^|\s)[\w-]*pagination-(?:item-)?next(?:\s|$)/.test(String(b.className)));
        const prev = buttons.find(b=>/^(?:previous|previous page|prev|go to previous page|trang truoc)$/.test(label(b)) || /(?:^|\s)[\w-]*pagination-(?:item-)?prev(?:\s|$)/.test(String(b.className)));
        const first = buttons.find(b=>/^(?:first|first page|go to first page|trang dau)$/.test(label(b)) || text(b)==='1');
        const active = pager.querySelector('[aria-current="page"],[class*="item-active"],[class*="item-selected"]');
        const page = Number(text(active)) || null;
        if (next || prev) return {pager,next,prev,first,page};
      }
    }
    return null;
  }
  function viewInfo() {
    const snap=locate(), u=new URL(location.href);
    let metric=u.searchParams.get('metricId')==='020204'?'FDR':'';
    const heading=String(snap?.root.closest('section')?.innerText || '');
    if(!metric){const hits=[['FDR',/\(FDR\)|Tỷ lệ gửi hàng nhanh/i],['NDDR',/\(NDDR\)|Tỷ lệ giao nhanh 24h/i],['LDR',/\(LDR\)|Tỷ lệ gửi hàng muộn/i],['SFCR',/\(SFCR\)|Tỷ lệ hủy do lỗi/i]].filter(([,rx])=>rx.test(heading));if(hits.length===1)metric=hits[0][0];}
    // Do not confuse graph tick labels or a row's Placement time with an evaluation window.
    const dates=[...document.querySelectorAll('input')].filter(shown).map(e=>String(e.value||'')).map(s=>{
      if(/^\d{4}-\d{2}-\d{2}$/.test(s))return s;
      const m=s.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);return m?`${m[3]}-${m[2]}-${m[1]}`:'';
    }).filter(Boolean);
    return {ready:!!snap,headers:snap?.headers||[],visibleRows:snap?.rows.length||0,metric,period:dates.length===2?{start:dates[0],end:dates[1]}:null};
  }
  async function changed(oldKey,guard,progress) {
    const until=Date.now()+20000;
    for(let tick=0;Date.now()<until;tick++) {
      await guard();
      const s=locate();
      const busy=s?.root.closest('[aria-busy="true"]') || s?.root.querySelector('[aria-busy="true"],[class*="spin-loading"]');
      if(s && s.rows.length && s.key!==oldKey && !busy) {
        await pause(180);const stable=locate();
        if(stable?.key===s.key)return stable;
      }
      if(tick%10===0)progress({msg:'Đang chờ TikTok tải trang bảng tiếp theo…'});
      await pause(200);
    }
    throw Error('TikTok chưa đổi dữ liệu sau khi chuyển trang. Các mốc đã đọc vẫn được giữ; bấm đọc tiếp khi bảng tải xong.');
  }
  function scroller(snap) {
    const nodes=[snap.root,...snap.root.querySelectorAll('[class*="scroll"],[class*="table-body"],[class*="virtual"]')];
    for(let el=snap.root.parentElement,n=0;el && el!==document.body && n<5;el=el.parentElement,n++)nodes.push(el);
    return nodes.find(el=>el.scrollHeight>el.clientHeight+8 && el.clientHeight>0 && /auto|scroll/.test(getComputedStyle(el).overflowY));
  }
  async function read({expectedShop,code,ids,period,identity,progress}) {
    const target=new Set(ids), all=new Map(), seen=new Set();
    const guard=async()=>{if(await identity(true)!==expectedShop)throw Error('Store đã đổi. Dừng đọc bảng; không ghép dữ liệu khác store.');};
    await guard();let snap=locate();
    if(!snap)throw Error('Không thấy bảng có cả Order ID/Placement time và Actual handover time. Mở bảng chi tiết hiệu suất dưới biểu đồ của KPI, rồi bấm Lấy mốc từ bảng đang mở.');
    if(!snap.rows.length)snap=await changed(snap.key,guard,progress);
    const info=viewInfo();
    if(info.metric && info.metric!==code)throw Error(`Trang đang là ${info.metric}, panel chọn ${code}. Chọn đúng KPI.`);
    if(info.period && period && (info.period.start!==period.start || info.period.end!==period.end))throw Error(`Bảng đang ở kỳ ${info.period.start} → ${info.period.end}, khác kỳ KPI ${period.start} → ${period.end}. Chọn lại kỳ.`);
    let pager=controls(snap), startVerified=!pager || pager.page===1 || !!pager.prev && disabled(pager.prev);
    const initialScroll=scroller(snap);
    if(initialScroll?.scrollTop>0){initialScroll.scrollTop=0;await pause(250);snap=locate()||snap;}
    if(pager && !startVerified) {
      if(pager.first && !disabled(pager.first)) {await guard();pager.first.click();snap=await changed(snap.key,guard,progress);startVerified=true;}
      else if(pager.prev) {
        for(let n=0;n<10000 && pager.prev && !disabled(pager.prev);n++) {await guard();pager.prev.click();snap=await changed(snap.key,guard,progress);pager=controls(snap);}
        startVerified=!!pager?.prev && disabled(pager.prev);
      }
    }
    let pages=0,sourceRows=0,complete=false,note='';
    for(;;) {
      await guard();
      if(seen.has(snap.key)){note='Bảng lặp dữ liệu; chưa xác minh đã hết trang.';break;}
      seen.add(snap.key);pages++;sourceRows+=snap.rawCount;
      const updates=[];
      for(const row of snap.rows)if(target.has(row.order_id)) {
        const before=all.get(row.order_id), merged=D.merge(before||{order_id:row.order_id},row);
        if(JSON.stringify(before)!==JSON.stringify(merged)){all.set(row.order_id,merged);updates.push(merged);}
      }
      await guard();
      const count=D.summary([...all.values()]).counts.actual_handover_at;
      const msg=`Bảng ${code}: Actual handover ${count}/${target.size} đơn · đã đọc ${pages} lượt bảng`;
      if(!updates.length)progress({msg});
      for(let i=0;i<updates.length;i+=100)progress({msg,shopId:expectedShop,rows:updates.slice(i,i+100),metric:code});
      pager=controls(snap);
      const scroll=scroller(snap);
      if(scroll && scroll.scrollTop+scroll.clientHeight<scroll.scrollHeight-3) {
        const oldKey=snap.key;await guard();scroll.scrollTop=Math.min(scroll.scrollHeight,scroll.scrollTop+Math.max(40,Math.floor(scroll.clientHeight*.8)));
        await pause(250);const next=locate();
        // A normal scroll area already has all rows in DOM. Only walk new virtual rows.
        if(next && next.key!==oldKey){snap=next;continue;}
      }
      if(pager?.next && !disabled(pager.next)) {await guard();pager.next.click();snap=await changed(snap.key,guard,progress);continue;}
      if(pager?.next && disabled(pager.next)) {complete=startVerified;break;}
      // Unknown pagination must never be presented as a complete source.
      complete=false;note=pager?'Không nhận diện được nút trang tiếp theo.':'Bảng không có nút phân trang đã nhận diện; chỉ xác nhận các mã đã ghép.';break;
    }
    await guard();
    const fieldCounts=D.summary([...all.values()]).counts, handoverFound=fieldCounts.actual_handover_at;
    if(handoverFound<target.size)note=[note,`Còn ${target.size-handoverFound} mã đơn chưa có Actual handover time; chưa lấy đủ các mốc yêu cầu.`].filter(Boolean).join(' ');
    return {shopId:expectedShop,total:target.size,found:all.size,missing:target.size-all.size,handoverFound,fieldCounts,failed:0,source:'rendered-performance-table',sourceRows,pages,listComplete:complete,note,metric:code,period:info.period,scopeVerified:!!info.metric && !!info.period};
  }
  function navigation() {
    const out={performance:[],orderList:'',orderSamples:[]};
    if(!document?.querySelectorAll)return out;
    for(const a of document.querySelectorAll('a[href]')) {
      let u;try{u=new URL(a.getAttribute('href'),location.origin);}catch{continue;}
      if(u.origin!==location.origin || /(?:cancel|refund|delete|confirm|create|edit|print|export)/i.test(u.pathname))continue;
      // Retain route identifiers only, never session/auth query values.
      for(const key of [...u.searchParams.keys()])if(!/^(?:metricId|metric_id|order_id|main_order_id|orderId|shop_id|seller_id|oec_seller_id|tab|type|status|section)$/.test(key))u.searchParams.delete(key);
      if(/^\/health-center\/(?:experience-score|performance)/.test(u.pathname)) {
        const label=D.norm([text(a),a.getAttribute('title')].filter(Boolean).join(' '));
        let code=u.searchParams.get('metricId')==='020204'?'FDR':'';
        if(!code) {const hits=[['NDDR',/\bnddr\b|giao nhanh 24h/],['INSTANT_LDR',/hoa toc|instant/],['SAME_DAY_LDR',/trong ngay|same day/],['FDR',/\bfdr\b|gui hang nhanh/],['LDR',/\bldr\b|gui hang muon/],['SFCR',/\bsfcr\b|huy do loi/]].filter(([,rx])=>rx.test(label));const specific=hits.filter(([k])=>k!=='LDR');if(specific.length===1)code=specific[0][0];else if(hits.length===1)code=hits[0][0];}
        if(code && !out.performance.some(x=>x.code===code))out.performance.push({code,url:u.href});
      }
      if(/^\/(?:order|orders)(?:\/|$)/.test(u.pathname)) {
        const oid=D.id(u.searchParams.get('order_id') || u.searchParams.get('main_order_id') || u.searchParams.get('orderId')) || D.id(text(a));
        if(oid){if(out.orderSamples.length<5)out.orderSamples.push({id:oid,url:u.href});}
        else if(!out.orderList && /(?:list|manage|all|order)$/.test(u.pathname))out.orderList=u.href;
      }
    }
    return out;
  }
  function openSample(ids) {
    const wanted=new Set(ids||[]), snap=locate();
    const candidates=snap?[...snap.root.querySelectorAll('a,button,[role="link"]')]:[...document.querySelectorAll('a[href],[role="link"]')];
    const links=candidates.map(el=>({el,id:D.id(text(el))})).filter(x=>x.id && shown(x.el));
    const hit=links.find(x=>wanted.has(x.id)) || links[0];
    if(!hit)return {clicked:false};
    // Return a verified read URL; background persists the step and navigates
    // the original tab. Clicking a site's link/button could open a new tab.
    if(hit.el.tagName!=='A')return {clicked:false};
    let u;try{u=new URL(hit.el.getAttribute('href'),location.origin);}catch{return {clicked:false};}
    if(u.origin!==location.origin || !/^\/(?:order|orders)(?:\/|$)/.test(u.pathname) || /(?:cancel|refund|delete|confirm|create|edit|print|export)/i.test(u.pathname))return {clicked:false};
    return {clicked:false,url:u.href,id:hit.id};
  }
  window.OPPerformanceTable={read,status:viewInfo,samples:()=>locate()?.rows || [],navigation,openSample};
})();
