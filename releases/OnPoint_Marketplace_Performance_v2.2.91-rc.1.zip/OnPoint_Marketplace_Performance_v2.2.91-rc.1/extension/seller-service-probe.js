/* v2.2.4 · MAIN world trên seller-service.cs.shopee.vn ("Yêu cầu của tôi").
   Không gọi API riêng, không đọc cookie: chỉ đọc JSON mà chính trang trả về khi Seller mở danh sách / chi tiết yêu cầu,
   lấy các object có trạng thái (status/state…) và gửi cho seller-service-bridge.js để khớp với mã phiếu tool đã raise. */
(() => {
  if (window.__OP_SSS_PROBE__) return;
  window.__OP_SSS_PROBE__ = true;
  const k = s => String(s || '').replace(/[_\-\s]/g, '').toLowerCase();
  const STATUS = ['status', 'casestatus', 'statusname', 'statustext', 'statusdesc', 'statuslabel', 'displaystatus', 'statusdisplay', 'state', 'ticketstatus', 'casestatusname'];
  const UPDATED = ['updatetime', 'updatedat', 'mtime', 'lastupdatetime', 'modifytime', 'updatedtime', 'lastmodifiedtime', 'solvedtime', 'closetime'];
  const prim = v => (typeof v === 'string' && v.length <= 120) || (typeof v === 'number' && Number.isFinite(v));
  function walk(node, out, depth = 0) {
    if (!node || typeof node !== 'object' || depth > 8 || out.length >= 500) return;
    if (Array.isArray(node)) { for (const x of node) walk(x, out, depth + 1); return; }
    const entries = Object.entries(node), st = [], ids = [];
    let updated = '';
    for (const [name, value] of entries) {
      const key = k(name);
      if (STATUS.includes(key) && prim(value)) st.push(value);
      else if (UPDATED.includes(key) && prim(value) && !updated) updated = value;
      if (prim(value) && /^[A-Z0-9][A-Z0-9_-]{4,79}$/i.test(String(value)) && ids.length < 40) ids.push(String(value));
    }
    if (st.length && ids.length) {
      const text = st.find(v => typeof v === 'string' && !/^\d+$/.test(v));
      const code = st.find(v => typeof v === 'number' || /^\d+$/.test(String(v)));
      out.push({ ids, status: text ? String(text) : '', code: code == null ? '' : String(code), updated: String(updated || '') });
    }
    for (const [, value] of entries) if (value && typeof value === 'object') walk(value, out, depth + 1);
  }
  function inspect(text) {
    if (typeof text !== 'string' || text.length > 3000000 || !/^\s*[[{]/.test(text)) return;
    let json; try { json = JSON.parse(text.replace(/(:\s*)(\d{16,})(\s*[,}\]])/g, '$1"$2"$3')); } catch (_) { return; }
    const records = []; walk(json, records);
    if (!records.length) return;
    buffer.push(records); if (buffer.length > 10) buffer.shift();
    window.postMessage({ source: 'op-sss-probe', json: JSON.stringify({ records }) }, location.origin);
  }
  // Bridge (isolated world) loads at document_idle: replay what the page fetched before it was listening.
  const buffer = [];
  window.addEventListener('message', event => {
    if (event.source === window && event.origin === location.origin && event.data?.source === 'op-sss-ask') buffer.forEach(records => window.postMessage({ source: 'op-sss-probe', json: JSON.stringify({ records }) }, location.origin));
  });
  const originalFetch = window.fetch;
  if (originalFetch) window.fetch = function () {
    const promise = originalFetch.apply(this, arguments);
    promise.then(r => { if (/json|text/i.test(r.headers.get('content-type') || '')) r.clone().text().then(inspect, () => {}); }, () => {});
    return promise;
  };
  const send = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.send = function () {
    this.addEventListener('load', () => { try { inspect(this.responseType === 'json' ? JSON.stringify(this.response) : (this.responseType === '' || this.responseType === 'text') ? this.responseText : ''); } catch (_) {} }, { once: true });
    return send.apply(this, arguments);
  };
})();
