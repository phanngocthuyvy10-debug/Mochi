/* Runs in the Seller Center page (MAIN world) so requests go through the page's own fetch,
   with the session's normal signing. Only fixed, read-only endpoints verified on seller-vn are called. */
(() => {
  if (window.__opTTSApi) return; window.__opTTSApi = true;
  const BASE = { locale: 'vi-VN', language: 'vi-VN', aid: '4068', app_name: 'i18n_ecom_shop' };
  const PAGE = 1000;
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  // Quote long integers before parsing: order/SKU IDs exceed Number.MAX_SAFE_INTEGER.
  const parse = t => JSON.parse(t.replace(/(:\s*|[\[,]\s*)(-?\d{16,})(?=\s*[,}\]])/g, '$1"$2"'));

  async function call(path, params, init) {
    const u = new URL(path, location.origin);
    for (const [k, v] of Object.entries(params || {})) u.searchParams.set(k, v);
    const r = await window.fetch(u.href, { credentials: 'include', ...(init || {}) });
    const text = await r.text();
    let j; try { j = parse(text); } catch { throw Error(`${path}: phản hồi không phải JSON (HTTP ${r.status}). Có thể phiên đăng nhập đã hết.`); }
    if (j.code !== 0) throw Error(`${path}: ${j.message || 'code ' + j.code}`);
    return j.data || {};
  }

  async function identity() {
    const d = await call('/api/v3/seller/common/get', { need_verify_account: 'true', default_region: 'VN', version: '1' });
    const s = d.seller || {};
    if (!/^\d{5,24}$/.test(String(s.seller_id || ''))) throw Error('Không đọc được Seller ID của store đang đăng nhập.');
    return { shopId: String(s.seller_id), shopName: String(s.shop_name || s.global_shop_name || ''), shopCode: String(s.shop_code || '').trim(), region: String(s.region_code || s.shop_region || '') };
  }

  const vnDate = sec => new Date(sec * 1000).toLocaleDateString('sv-SE', { timeZone: 'Asia/Ho_Chi_Minh' }); // YYYY-MM-DD
  const vnTime = sec => sec ? new Date(sec * 1000).toLocaleString('sv-SE', { timeZone: 'Asia/Ho_Chi_Minh' }) : '';
  const OPS = { 1: '=', 2: '>', 3: '>=', 4: '<', 5: '<=' };
  function codeOf(m) {
    const f = String(m.feature_code || ''), t = String(m.title || '').toLowerCase();
    if (/pre_cot_fast_dispatch/.test(f) || /giao nhanh 24h/.test(t)) return 'NDDR';
    if (/late_dispatch_instant/.test(f) || /hỏa tốc/.test(t)) return 'INSTANT_LDR';
    if (/late_dispatch_sameday/.test(f) || /trong ngày/.test(t)) return 'SAME_DAY_LDR';
    if (/late_dispatch/.test(f) || /gửi hàng muộn/.test(t)) return 'LDR';
    if (/liable_cancel/.test(f) || /hủy do lỗi/.test(t)) return 'SFCR';
    if (/fast_dispatch/.test(f) || /gửi hàng nhanh/.test(t)) return 'FDR';
    return null;
  }

  async function kpis(shopId, module) {
    const d = module || await metricsModule(shopId);
    const groups = d.metric_groups || [];
    const g = groups.find(x => /order_fulfillment/.test(x.violation_type || '')) ||
      groups.find(x => (x.metrics || []).some(codeOf));
    if (!g) throw Error('Không thấy nhóm "Vi phạm về hoàn thiện đơn hàng" trong Điểm tình trạng tài khoản.');
    const out = [];
    for (const m of g.metrics || []) {
      const code = codeOf(m); if (!code || out.some(x => x.code === code)) continue;
      const has = typeof m.value === 'number' && Number.isFinite(m.value);
      out.push({
        code, title: m.title || '', value: has ? m.value : null, raw: has ? (m.value * 100).toFixed(2) + '%' : '--',
        threshold: typeof m.target_value === 'number' && OPS[m.operator] ? { direction: OPS[m.operator], target: m.target_value, source: 'SELLER_CENTER' } : null,
        period_start: m.start_time ? vnDate(m.start_time) : '', period_end: m.end_time ? vnDate(m.end_time) : '',
        end_time: m.end_time || 0, indicator: m.feature_code || '', violation_count: m.violation_count ?? null
      });
    }
    return out;
  }

  function metricsModule(shopId) {
    return call('/api/v1/seller/growth_center/shop/metrics_module/query',
      { aid: '4068', locale: 'vi-VN', oec_seller_id: shopId, seller_id: shopId },
      { method: 'POST', headers: { 'content-type': 'application/json' }, body: '{}' });
  }

  async function orderPage(shopId, indicator, date, offset) {
    return call('/api/v1/seller/growth_center/defective_orders/list',
      { ...BASE, oec_seller_id: shopId, indicator_name: indicator, offset: String(offset), limit: String(PAGE), order_channel: '0', date });
  }
  const ymd = s => s.replace(/-/g, '');
  const prevDay = s => { const d = new Date(s + 'T00:00:00Z'); d.setUTCDate(d.getUTCDate() - 1); return d.toISOString().slice(0, 10); };

  async function defective(shopId, k, progress) {
    if (!k.indicator || !k.period_end) return { lines: [], total: 0, note: 'Không có mã chỉ số để lấy danh sách' };
    let day = k.period_end, note = '';
    for (let back = 0; back <= 2; back++) {
      const first = await orderPage(shopId, k.indicator, ymd(day), 0);
      const total = Number(first.total) || 0, lines = [...(first.items || [])];
      if (total > 0 && !lines.length && back < 2) { note = `TikTok báo ${total} dòng nhưng chưa trả danh sách ngày ${day}`; day = prevDay(day); continue; }
      const seenPages = new Set([JSON.stringify(first.items || [])]);
      let incomplete = '';
      while (lines.length < total) {
        await sleep(250);
        const p = await orderPage(shopId, k.indicator, ymd(day), lines.length);
        if (!(p.items || []).length) { incomplete = `API dừng ở ${lines.length}/${total} dòng nguồn`; break; }
        const pageKey = JSON.stringify(p.items);
        if (seenPages.has(pageKey)) { incomplete = `API lặp trang tại ${lines.length}/${total} dòng nguồn`; break; }
        seenPages.add(pageKey);
        lines.push(...p.items); progress?.(`${k.code}: ${lines.length}/${total} dòng nguồn`);
      }
      if (note) note += `; đã lấy theo kỳ kết thúc ${day}`;
      if (incomplete) note = (note ? note + '; ' : '') + incomplete;
      const shift = Math.round((Date.parse(k.period_end) - Date.parse(day)) / 86400000), listStart = k.period_start ? new Date(Date.parse(k.period_start) - shift * 86400000).toISOString().slice(0, 10) : '';
      return { lines, total, listDate: day, listStart, note };
    }
    return { lines: [], total: 0, note };
  }

  // Previous evaluation windows (same length, back to back) so every failed order in the retention range is captured.
  const ORDER_HISTORY_DAYS = 90;
  const shiftDay = (s, n) => { const d = new Date(s + 'T00:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };
  async function windowLines(shopId, indicator, day, progress, label) {
    const first = await orderPage(shopId, indicator, ymd(day), 0);
    const total = Number(first.total) || 0, lines = [...(first.items || [])], seen = new Set([JSON.stringify(first.items || [])]);
    while (lines.length < total) {
      await sleep(250);
      const p = await orderPage(shopId, indicator, ymd(day), lines.length);
      const key = JSON.stringify(p.items || []);
      if (!(p.items || []).length || seen.has(key)) break;
      seen.add(key); lines.push(...p.items); progress?.(`${label}: ${lines.length}/${total} dòng nguồn`);
    }
    return { lines, total };
  }
  async function history(shopId, k, current, progress) {
    const end = current.listDate || k.period_end, start = current.listStart || k.period_start;
    if (!k.indicator || !end || !start) return { orders: [], fetched: 0, total: 0, windows: 0 };
    const len = Math.max(1, Math.round((Date.parse(end) - Date.parse(start)) / 86400000) + 1);
    const seen = new Set(current.orderIds), orders = []; let fetched = 0, total = 0, windows = 0;
    for (let back = len; back < ORDER_HISTORY_DAYS; back += len) {
      const we = shiftDay(end, -back), ws = shiftDay(start, -back);
      const r = await windowLines(shopId, k.indicator, we, progress, `${k.code} kỳ ${ws}→${we}`);
      fetched += r.lines.length; total += r.total; windows++;
      for (const o of toOrders(r.lines, k.code, k)) if (!seen.has(o.order_id)) { seen.add(o.order_id); orders.push({ ...o, period_start: ws, period_end: we }); }
      await sleep(150);
    }
    return { orders, fetched, total, windows };
  }

  // One row per order; SKU lines are folded into the row.
  function toOrders(lines, code, k) {
    const by = new Map();
    for (const l of lines) {
      const id = String(l.main_order_id || '').trim(); if (!/^\d{10,24}$/.test(id)) continue;
      const o = by.get(id) || { order_id: id, skus: [], qty: 0, created: l.created_time, channel: l.order_channel, detail: {} };
      o.detail = window.OPDetails.merge(o.detail,window.OPDetails.flat(l));
      o.skus.push(`${l.sku_id}×${l.quantity ?? 1} ${String(l.variation || l.product_name || '').slice(0, 80)}`.trim());
      o.qty += Number(l.quantity) || 0; by.set(id, o);
    }
    return [...by.values()].map(o => ({
      order_id: o.order_id, metric: code, tracking_id: '', status: '',
      reason: k.title,
      created_at: vnTime(o.created), paid_at: '', rts_at: '', pickup_at: '', delivered_at: '', deadline: '',
      shipping_type: '', carrier: '', warehouse: '', violation_id: '', appeal_status: '',
      evidence: 'API_FAILURE_LIST', sku_lines: o.skus.length, ...o.detail
    }));
  }

  // Read every requested date batch, including gaps. Retention is controlled by TikTok.
  const BATCH = 60;
  async function trend(shopId, k, days) {
    const out = []; let cursor = new Date(vnDate(Date.now()/1000)+'T00:00:00Z');
    for (let left = days; left > 0; left -= BATCH) {
      const dates = []; for (let i = 0; i < Math.min(BATCH, left); i++) { dates.push(cursor.toISOString().slice(0, 10).replace(/-/g, '')); cursor.setUTCDate(cursor.getUTCDate() - 1); }
      const u = new URL('/api/v1/seller/growth_center/indicator_detail/get', location.origin);
      for (const [a, b] of Object.entries({ ...BASE, oec_seller_id: shopId, indicator_name: k.indicator })) u.searchParams.set(a, b);
      for (const d of dates) u.searchParams.append('dates', d);
      const r = await window.fetch(u.href, { credentials: 'include' }); let j; try { j = parse(await r.text()); } catch { throw Error(`Lịch sử ${k.code}: API không trả JSON`); }
      if (j.code !== 0) throw Error(`Lịch sử ${k.code}: ${j.message || j.code}`);
      const rows = (j.data?.indicator_details || []).filter(x => /^\d{8}$/.test(String(x.date)));
      for (const x of rows) out.push({ metric: k.code, name: k.name || undefined, date: `${String(x.date).slice(0, 4)}-${String(x.date).slice(4, 6)}-${String(x.date).slice(6, 8)}`, value: typeof x.value === 'number' && Number.isFinite(x.value) ? x.value : null, errors: Number.isFinite(Number(x.defective_order_count)) ? Number(x.defective_order_count) : null, window_start: x.start_time ? vnDate(x.start_time) : '', window_end: x.end_time ? vnDate(x.end_time) : '' });
      await sleep(150);
    }
    return out;
  }
  async function shopScore(shopId) {
    try {
      const d = await call('/api/v1/seller/experience-score/score-overview', { ...BASE, oec_seller_id: shopId, shop_region: 'VN', shop_id: shopId });
      const o = d.overview || {};
      return (o.dailyScoreList || []).filter(x => x.date && typeof x.score === 'number').map(x => ({ metric: 'SHOP_SCORE', date: vnDate(Number(x.date)), value: x.score, errors: null, window_start: '', window_end: '' }));
    } catch { return []; }
  }

  // Everything else Account Health exposes: service metrics, experience score (numerator/denominator), AHR, violation points.
  const xcode = s => ('X_' + String(s).toUpperCase().replace(/[^A-Z0-9]+/g, '_').replace(/^_+|_+$/g, '')).slice(0, 62);
  const num = v => { if (typeof v === 'number') return Number.isFinite(v) ? v : null; const t = String(v ?? '').trim(); if (!t || t === '--') return null; const n = Number(t.replace(/[^\d,.-]/g, '').replace(',', '.')); return Number.isFinite(n) ? (/%/.test(t) ? Math.round(n * 1e6) / 1e8 : n) : null; };
  async function extras(shopId, module, days, post) {
    const today = vnDate(Date.now() / 1000), rows = [], notes = [], add = (metric, value, date, name, ws = '', we = '', errors = null) => { if (value != null && Number.isFinite(value)) rows.push({ metric, value, date, name: String(name || metric).slice(0, 120), window_start: ws, window_end: we, errors }); };
    const UNIT = { 101: '%', 202: 'giờ' };
    for (const g of module.metric_groups || []) for (const m of g.metrics || []) {
      if (codeOf(m)) continue;
      const code = xcode(String(m.feature_code || m.title).split('.').pop()), ws = m.start_time ? vnDate(m.start_time) : '', we = m.end_time ? vnDate(m.end_time) : '';
      const target = typeof m.target_value === 'number' ? ` (mục tiêu ${OPS[m.operator] || ''}${m.unit === 101 ? +(m.target_value * 100).toFixed(2) + '%' : m.target_value + (UNIT[m.unit] ? ' ' + UNIT[m.unit] : '')})` : '';
      const name = (m.title || code) + target;
      add(code, typeof m.value === 'number' ? m.value : null, we || today, name, ws, we, m.violation_count ?? null);
      if (m.feature_code) try { const h = await trend(shopId, { code, name, indicator: m.feature_code }, days); rows.push(...h.filter(x => x.value != null)); post('PROGRESS', { msg: `Lịch sử ${m.title}: ${h.length} ngày` }); } catch (e) { notes.push(`${m.title}: ${e.message}`); }
    }
    try {
      const d = await call('/api/v1/seller/experience-score/score-overview', { ...BASE, oec_seller_id: shopId, shop_region: 'VN', shop_id: shopId });
      const o = d.overview || {}, day = o.date ? vnDate(Number(o.date)) : today, es = o.evaluationStartTime ? vnDate(o.evaluationStartTime) : '', ee = o.evaluationEndTime ? vnDate(o.evaluationEndTime) : '';
      add('X_ES_SCORE', num(o.score), day, 'Điểm trải nghiệm cửa hàng', es, ee);
      add('X_ES_DELIVERED_ORDERS', num(o.totalDeliveredOrderCnt), day, 'Điểm trải nghiệm: đơn đã giao', es, ee);
      add('X_ES_VALID_ORDERS', num(o.totalValidOrderCnt), day, 'Điểm trải nghiệm: đơn hợp lệ', es, ee);
      for (const g of d.metric?.metricGroups || []) {
        add(xcode('ES_' + g.code + '_SCORE'), num(g.score), day, `${g.name} · điểm nhóm (trọng số ${g.weight || '?'})`, es, ee);
        for (const m of g.metricScores || []) {
          const ws = m.startTime ? vnDate(m.startTime) : es, we = m.endTime ? vnDate(m.endTime) : ee, b = 'ES_' + m.code;
          add(xcode(b + '_VALUE'), num(m.score), day, `${m.name} · giá trị`, ws, we);
          add(xcode(b + '_POINT'), num(m.metricScore), day, `${m.name} · điểm (0-5)`, ws, we);
          add(xcode(b + '_NUM'), num(m.scoreNumerator), day, `${m.name} · tử số${m.scoreNumeratorTitle ? ': ' + m.scoreNumeratorTitle : ''}`, ws, we);
          add(xcode(b + '_DEN'), num(m.scoreDenominator), day, `${m.name} · mẫu số${m.scoreDenominatorTitle ? ': ' + m.scoreDenominatorTitle : ''}`, ws, we);
        }
      }
    } catch (e) { notes.push('Điểm trải nghiệm: ' + e.message); }
    try { const a = await call('/api/v1/account/ahr/score', { aid: '4068', locale: 'vi-VN', oec_seller_id: shopId, seller_id: shopId, account_type: '2', country_code: 'VN', account_level: '1', is_need_display_status: 'true', is_need_violation: 'true' }); add('X_AHR_SCORE', num(a.score), today, 'Điểm tình trạng tài khoản (0-1000)'); } catch (e) { notes.push('Điểm tình trạng tài khoản: ' + e.message); }
    try {
      const v = await call('/api/v1/seller/growth_center/violation/overview/get', { aid: '4068', locale: 'vi-VN', oec_seller_id: shopId, seller_id: shopId });
      const ws = v.start_time ? vnDate(v.start_time) : '', we = v.end_time ? vnDate(v.end_time) : '';
      add('X_VIOLATION_SCORE', num(v.violation_score), today, 'Điểm vi phạm', ws, we);
      for (const p of v.violation_points_v2 || []) { const c = xcode('VIOLATION_' + String(p.violation_type_key || '').replace('performance_overview_violation_type_', '')); add(c + '_COUNT', num(p.count), today, `${p.violation_type_str} · số vi phạm`, ws, we); add(c + '_POINTS', num(p.violation_score), today, `${p.violation_type_str} · điểm`, ws, we); }
    } catch (e) { notes.push('Vi phạm: ' + e.message); }
    try {
      const p = await call('/api/v1/seller/growth_center/overview/policy_violations_module/query', { aid: '4068', locale: 'vi-VN', oec_seller_id: shopId, seller_id: shopId }, { method: 'POST', headers: { 'content-type': 'application/json' }, body: '{}' });
      for (const i of p.items || []) add(xcode('POLICY_' + String(i.title?.key || i.risk_type).replace('shophealth_overview_policyvio_', '') + '_RECORDS'), num(i.record_count), today, `Hồ sơ vi phạm chính sách · ${i.title?.key || i.risk_type}`);
    } catch (e) { notes.push('Hồ sơ vi phạm: ' + e.message); }
    return { rows, notes };
  }

  async function collect(post, opts) {
    const id = await identity(); post('PROGRESS', { msg: `Store: ${id.shopName} · ${id.shopId}` });
    const module = await metricsModule(id.shopId), list = await kpis(id.shopId, module); post('PROGRESS', { msg: `Đã đọc ${list.length}/6 KPI` });
    const metrics = [];
    // Only a KPI that misses its Seller Center target needs its failed-order list; a passing KPI is skipped to keep collection fast.
    const passes = k => { const t = k.threshold, v = k.value; if (v == null || !t || t.target == null) return v == null; const d = t.direction; return d === '>=' ? v >= t.target : d === '>' ? v > t.target : d === '<=' ? v <= t.target : d === '<' ? v < t.target : d === '=' ? v === t.target : false; };
    for (const k of list) {
      if (passes(k)) { metrics.push({ ...k, lineTotal: 0, linesFetched: 0, listDate: k.period_end, listStart: k.period_start, note: k.value == null ? 'Sàn chưa có số liệu kỳ này · không lấy danh sách đơn' : 'Đạt mục tiêu · bỏ qua danh sách đơn để lấy nhanh', orders: [], historyOrders: [], historyComplete: true, skipped: true }); post('PROGRESS', { msg: `${k.code}: đạt mục tiêu, bỏ qua danh sách đơn` }); continue; }
      const r = await defective(id.shopId, k, msg => post('PROGRESS', { msg }));
      const orders = toOrders(r.lines, k.code, k).map(o => ({ ...o, period_start: r.listStart || k.period_start, period_end: r.listDate || k.period_end }));
      const h = await history(id.shopId, k, { listDate: r.listDate, listStart: r.listStart, orderIds: orders.map(o => o.order_id) }, msg => post('PROGRESS', { msg }));
      const hNote = h.windows ? `${h.windows} kỳ trước (${ORDER_HISTORY_DAYS} ngày): +${h.orders.length} đơn lỗi (${h.fetched}/${h.total} dòng)` : '';
      metrics.push({ ...k, lineTotal: r.total, linesFetched: r.lines.length, listDate: r.listDate || k.period_end, listStart: r.listStart || k.period_start, note: [r.note, hNote].filter(Boolean).join('; '), orders, historyOrders: h.orders, historyComplete: h.fetched === h.total });
      post('PROGRESS', { msg: `${k.code}: ${orders.length} Order ID kỳ hiện tại (${r.lines.length}/${r.total} dòng nguồn)${h.windows ? ` · +${h.orders.length} đơn ${h.windows} kỳ trước` : ''}` });
      await sleep(200);
    }
    const days = Math.max(14, Math.min(3650, Number(opts?.historyDays) || 30)), daily = [];
    for (const k of list) { if (!k.indicator) continue; const rows = await trend(id.shopId, k, days); daily.push(...rows); post('PROGRESS', { msg: `Lịch sử ${k.code}: ${rows.length} ngày` }); }
    daily.push(...await shopScore(id.shopId));
    const x = await extras(id.shopId, module, days, post); daily.push(...x.rows);
    post('PROGRESS', { msg: `Chỉ số phụ: ${new Set(x.rows.map(r => r.metric)).size} mã · ${x.rows.length} dòng` });
    const finalId = await identity();
    if (finalId.shopId !== id.shopId) throw Error('Store đã đổi trong lúc lấy dữ liệu. Không lưu lẫn store.');
    return { identity: id, metrics, daily, notes: x.notes, historyDays: days, at: new Date().toISOString() };
  }

  window.OPOrderSource.bind(identity);

  window.addEventListener('message', async e => {
    if (e.source !== window || e.origin !== location.origin || e.data?.type !== 'OP_TTS_REQ') return;
    const { id, action, opts } = e.data;
    const post = (kind, payload) => window.postMessage({ type: 'OP_TTS_RES', id, kind, ...payload }, location.origin);
    try {
      if (action === 'identity') post('DONE', { result: await identity() });
      else if (action === 'collect') post('DONE', { result: await collect(post, opts) });
      else if (action === 'enrich') post('DONE', { result: await window.OPOrderSource.enrich(opts.shopId,opts.orderIds,payload=>post('PROGRESS',payload)) });
      else if (action === 'performance') post('DONE', { result: await window.OPOrderSource.performance(opts.shopId,opts.code,opts.orderIds,opts.period,payload=>post('PROGRESS',payload)) });
      else if (action === 'sourceDiagnostic') post('DONE',{result:window.OPOrderSource.diagnostic()});
      else if (action === 'openOrderSample') {if((await identity()).shopId!==opts.shopId)throw Error('Store đã đổi trước khi mở mẫu đơn.');post('DONE',{result:window.OPPerformanceTable.openSample(opts.orderIds)});}
    } catch (err) { post('ERROR', { error: String(err?.message || err) }); }
  });
})();
