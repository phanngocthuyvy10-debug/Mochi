/* v2.2.4 · seller-service.cs.shopee.vn — khớp trạng thái phiếu (từ seller-service-probe.js) với phiếu tool đã raise
   (shopeeFollowTickets) và lưu vào shopeeCaseStatus để tab Kháng nghị hiển thị. Chỉ lưu phiếu do tool raise. */
(() => {
  if (window.__OP_SSS_BRIDGE__) return;
  window.__OP_SSS_BRIDGE__ = true;
  let banner = null, queue = Promise.resolve();
  function show(text) {
    if (!banner) { banner = document.createElement('div'); banner.style.cssText = 'position:fixed;right:16px;bottom:16px;z-index:2147483647;background:#0f766e;color:#fff;font:13px/1.4 system-ui,sans-serif;padding:8px 12px;border-radius:8px;box-shadow:0 4px 16px rgba(0,0,0,.2);max-width:360px'; document.documentElement.appendChild(banner); }
    banner.textContent = text;
  }
  async function apply(records) {
    const { shopeeFollowTickets = [], shopeeCaseStatus = {} } = await chrome.storage.local.get(['shopeeFollowTickets', 'shopeeCaseStatus']);
    const known = new Set((Array.isArray(shopeeFollowTickets) ? shopeeFollowTickets : []).map(t => String(t.ticketId || '')).filter(Boolean));
    const next = { ...shopeeCaseStatus }, now = new Date().toISOString(); let hit = 0;
    for (const r of records) {
      const id = (r.ids || []).find(x => known.has(String(x))); if (!id) continue;
      const value = { status: String(r.status || '').slice(0, 80), code: String(r.code || '').slice(0, 20), updated: String(r.updated || '').slice(0, 40), seenAt: now };
      const old = next[id]; if (old && old.status === value.status && old.code === value.code && old.updated === value.updated) { next[id] = { ...old, seenAt: now }; hit++; continue; }
      next[id] = { ...value, changedAt: now }; hit++;
    }
    await chrome.storage.local.set({ shopeeCaseStatus: next, shopeeCaseSeen: { at: now, records: records.length, matched: hit } });
    if (hit) show(`OnPoint: đã cập nhật trạng thái ${hit} phiếu tool đã raise.`);
  }
  window.addEventListener('message', event => {
    if (event.source !== window || event.origin !== location.origin || event.data?.source !== 'op-sss-probe') return;
    let records = []; try { records = JSON.parse(event.data.json)?.records || []; } catch (_) { return; }
    if (records.length) queue = queue.catch(() => {}).then(() => apply(records.slice(0, 500)));
  });
  window.postMessage({ source: 'op-sss-ask' }, location.origin);

  /* v2.2.69 — panel bấm "Tìm phiếu trên Shopee": tự làm đúng các bước tay — tab Tất cả → chọn Mã đơn hàng → gõ mã → tìm. */
  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
  const visible = el => Boolean(el && el.getClientRects().length);
  const press = el => { for (const type of ['pointerdown', 'mousedown', 'mouseup', 'click']) el.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, view: window })); };
  async function waitFor(fn, ms = 15000) { const end = Date.now() + ms; while (Date.now() < end) { const v = fn(); if (v) return v; await sleep(200); } return null; }
  async function searchOrder(orderId) {
    show(`OnPoint: đang tìm phiếu theo mã đơn ${orderId}…`);
    const all = await waitFor(() => [...document.querySelectorAll('[role="tab"]')].find(tab => tab.innerText.trim() === 'Tất cả' && visible(tab)));
    if (!all) { show('OnPoint: chưa thấy tab Tất cả — đăng nhập Cổng hỗ trợ người bán rồi bấm lại.'); return; }
    if (all.getAttribute('aria-selected') !== 'true') { all.click(); await sleep(700); }
    const input = await waitFor(() => [...document.querySelectorAll('input.shopee-react-input__input')].find(el => /tìm kiếm/i.test(el.placeholder || '') && visible(el)));
    if (!input) { show('OnPoint: chưa thấy ô tìm kiếm.'); return; }
    if (!/mã đơn hàng/i.test(input.placeholder)) {
      const trigger = input.closest('[class*="search__group"]')?.querySelector('.shopee-react-select__inner') || document.querySelector('.shopee-react-select .shopee-react-select__inner');
      if (trigger) { press(trigger); await sleep(400); }
      const option = await waitFor(() => [...document.querySelectorAll('.shopee-react-select-option')].find(el => visible(el) && el.innerText.trim() === 'Mã đơn hàng'), 4000);
      if (!option) { show('OnPoint: chưa chọn được "Mã đơn hàng" — chọn tay rồi gõ mã.'); return; }
      press(option); await sleep(500);
    }
    const box = [...document.querySelectorAll('input.shopee-react-input__input')].find(el => /mã đơn hàng/i.test(el.placeholder || '')) || input;
    Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(box, orderId);
    box.dispatchEvent(new Event('input', { bubbles: true }));
    await sleep(250);
    for (const type of ['keydown', 'keypress', 'keyup']) box.dispatchEvent(new KeyboardEvent(type, { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true }));
    await sleep(1500);
    if (/không có yêu cầu nào/i.test(document.body.innerText || '')) { const icon = box.closest('.shopee-react-input')?.querySelector('.shopee-react-input__suffix-icon'); if (icon) { press(icon); await sleep(1200); } }
    show(/không có yêu cầu nào/i.test(document.body.innerText || '') ? `OnPoint: chưa có phiếu nào theo mã đơn ${orderId}.` : `OnPoint: đã lọc phiếu theo mã đơn ${orderId} (tab Tất cả).`);
  }
  chrome.storage.local.get('shopeeCaseSearch').then(async ({ shopeeCaseSearch: job }) => {
    if (!job?.orderId || Date.now() - Number(job.at || 0) > 120000 || /\/detail\//.test(location.pathname)) return;
    await chrome.storage.local.remove('shopeeCaseSearch');
    searchOrder(String(job.orderId)).catch(error => show(`OnPoint: tìm phiếu lỗi — ${error.message || error}`));
  }).catch(() => {});
})();
