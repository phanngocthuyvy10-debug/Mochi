const OPDB=(()=>{
  let p;
  function open(){return p||=new Promise((resolve,reject)=>{const r=indexedDB.open('OPPerformance',1);r.onupgradeneeded=()=>{const s=r.result.createObjectStore('orders',{keyPath:'key'});s.createIndex('run','runId');};r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});}
  async function put(runId,code,rows){const db=await open();return new Promise((resolve,reject)=>{const tx=db.transaction('orders','readwrite'),s=tx.objectStore('orders');for(const row of rows){const key=`${runId}|${code}|${row.order_id}`,r=s.get(key);r.onsuccess=()=>s.put({...OPCore.mergeOrder(r.result,row),key,runId,metric:code});}tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);});}
  async function list(runId){const db=await open();return new Promise((resolve,reject)=>{const r=db.transaction('orders').objectStore('orders').index('run').getAll(runId);r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});}
  return {put,list};
})();
