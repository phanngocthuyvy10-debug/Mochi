/* Operational fields only. Shared by the page collector, panel imports and worker.
   Missing timestamps stay missing; never infer an SLA or a pickup from another event. */
(function (root) {
  'use strict';
  const fields = {
    tracking_id: ['tracking_id','tracking_number','tracking_no','waybill_no','Tracking ID','Tracking No','Tracking number','Mã vận đơn'],
    status: ['order_status','order_status_name','status','Order Status','Trạng thái đơn hàng'],
    created_at: ['created_at','created_time','create_time','order_create_time','placement_time','order_placed_time','Placement time','Created At','Created Time','Thời gian tạo đơn hàng','Thời gian tạo đơn','Tạo đơn'],
    paid_at: ['paid_at','paid_time','payment_time','pay_time','Paid At','Paid Time','Payment Time','Thời gian thanh toán'],
    rts_at: ['rts_at','rts_time','ready_to_ship_time','ready_to_ship_at','Ready To Ship At','RTS Time','Thời gian sẵn sàng vận chuyển','Thời gian sẵn sàng giao hàng'],
    pickup_at: ['pickup_at','pickup_time','collection_time','collected_time','handover_time','Pickup At','Collection Time','Thời gian lấy hàng','Thời gian bàn giao cho ĐVVC','Thời gian bàn giao cho đơn vị vận chuyển'],
    delivered_at: ['delivered_at','delivered_time','delivery_time','Delivered At','Delivered Time','Thời gian giao hàng','Thời gian giao hàng thành công'],
    deadline: ['deadline','fulfillment_deadline','dispatch_deadline','sla_deadline','rts_sla_time','tts_sla_time','Deadline','Ship By Date','Dispatch Deadline','Hạn gửi hàng','Hạn bàn giao','Hạn xử lý'],
    shipping_type: ['shipping_type','delivery_type','delivery_option_name','Shipping Type','Loại vận chuyển','Hình thức vận chuyển'],
    carrier: ['carrier','carrier_name','logistics_provider','logistics_provider_name','shipping_provider','shipping_provider_name','Carrier','Shipping Provider Name','Đơn vị vận chuyển'],
    warehouse: ['warehouse','warehouse_name','Warehouse','Tên kho'],
    actual_handover_at: ['actual_handover_at','actual_handover_time','actual_shipped_time','actual_shipped_time_judged_by_platform','platform_handover_time','actualHandoverAt','actualHandoverTime','actualShippedTime','actualShippedTimeJudgedByPlatform','platformHandoverTime','Thời gian bàn giao thực tế','Thời gian bàn giao thực tế (sàn)','Thời gian bàn giao thực tế (nền tảng)','Actual handover time','Actual handover time (Platform)','Actual Shipped Time Judged By Platform'],
    shipping_location: ['shipping_location','shipping_location_name','Shipping location'],
    delivery_type: ['delivery_type','delivery_type_name','send_by','Send By','Delivery type'],
    pickup_type: ['pickup_type','pickup_type_name','Pickup type'],
    is_preorder: ['is_preorder','is_pre_order','Is Preorder'],
    sla_rule: ['sla_rule','sla_description','SLA Time']
  };
  const times = new Set(['created_at','paid_at','rts_at','pickup_at','delivered_at','deadline','actual_handover_at']);
  const required = ['created_at','actual_handover_at','shipping_location','delivery_type','pickup_type','paid_at','is_preorder','sla_rule','tracking_id','status','rts_at','pickup_at','delivered_at','deadline','shipping_type','carrier'];
  const norm = v => String(v ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/gi,'d').toLowerCase().replace(/[_\-]+/g,' ').replace(/\s+/g,' ').trim();
  const keys = Object.fromEntries(Object.entries(fields).map(([k,a]) => [k,new Set(a.map(norm))]));
  const idKeys = new Set(['order_id','main_order_id','orderId','order_no','order_number','Order ID','Order ID/Placement time','Mã đơn hàng','ID đơn hàng'].map(norm));
  function id(v) { return typeof v === 'number' && !Number.isSafeInteger(v) ? '' : /^\d{10,24}$/.test(String(v ?? '').trim().replace(/^'/,'')) ? String(v).trim().replace(/^'/,'') : ''; }
  function time(v) {
    if (v == null || v === '' || v === 0 || v === '0' || v === '-' || v === '--') return '';
    if (typeof v === 'number' || /^\d{10,13}$/.test(String(v))) {
      let n = Number(v); if (n < 1e11) n *= 1000;
      if (!Number.isFinite(n) || n < Date.UTC(2000,0,1) || n > Date.UTC(2100,0,1)) return '';
      return new Date(n).toLocaleString('sv-SE',{timeZone:'Asia/Ho_Chi_Minh'});
    }
    const s = String(v).trim();
    if (/^\d{4}-\d{2}-\d{2}T.*(?:Z|[+-]\d{2}:?\d{2})$/.test(s)) {
      const n = Date.parse(s); return Number.isFinite(n) ? new Date(n).toLocaleString('sv-SE',{timeZone:'Asia/Ho_Chi_Minh'}) : '';
    }
    // Excel exports may contain local day/month/year text. Retain the supplied value.
    return /^(?:\d{4}-\d{2}-\d{2}|\d{1,2}[/\-]\d{1,2}[/\-]\d{4})/.test(s) ? s.slice(0,80) : '';
  }
  function flat(o) {
    const out = {};
    for (const [k,v] of Object.entries(o || {})) {
      if (v == null || typeof v === 'object') continue;
      const n = norm(k);
      for (const [f,aliases] of Object.entries(keys)) if (aliases.has(n)) {
        const val = times.has(f) ? time(v) : String(v).trim().slice(0,800);
        if (val && !/^(?:[-–—]+|N\/A|null|undefined)$/i.test(val) && !out[f]) out[f] = val;
      }
    }
    return out;
  }
  function orderId(o) {
    for (const [k,v] of Object.entries(o || {})) if (idKeys.has(norm(k)) && id(v)) return id(v);
    return '';
  }
  function merge(a,b) { return {...a,...Object.fromEntries(Object.entries(b || {}).filter(([k,v]) => keys[k] && v !== '' && v != null))}; }
  function extract(payload, targetId) {
    const by = new Map(); let nodes = 0;
    function walk(o, scopedId, depth, path) {
      if (!o || typeof o !== 'object' || depth > 14 || ++nodes > 100000) return;
      if (Array.isArray(o)) { for (const x of o) walk(x,scopedId,depth+1,path); return; }
      let own = orderId(o);
      // Official Order Detail uses `id` inside its `orders` array.
      if (!own && /(?:^|\.)orders$/.test(path)) own = id(o.id);
      const current = own || scopedId;
      if (current && (!targetId || current === targetId)) {
        const f = flat(o);
        if (!own) {
          // A package's status/create_time is not the order's status/create_time.
          if (!Object.keys(o).some(k=>norm(k)==='order status'||norm(k)==='order status name')) delete f.status;
          if (!Object.keys(o).some(k=>norm(k)==='order create time')) delete f.created_at;
        }
        if (Object.keys(f).length) by.set(current,merge(by.get(current) || {order_id:current},f));
      }
      for (const [k,v] of Object.entries(o)) {
        if (!v || typeof v !== 'object' || /^(?:line_items|products|skus|buyer|recipient|recipient_address|address|payment|price|refunds?)$/i.test(k) || k==='items' && current) continue;
        walk(v,current,depth+1,path ? path+'.'+k : k);
      }
    }
    walk(payload,'',0,''); return [...by.values()];
  }
  function summary(rows) {
    const unique = new Map();
    for (const r of rows || []) if (id(r.order_id)) unique.set(r.order_id,merge(unique.get(r.order_id) || {order_id:r.order_id},r));
    const values = [...unique.values()], counts = Object.fromEntries(required.map(k=>[k,values.filter(o=>!!o[k]).length]));
    return {total:values.length, withDetails:values.filter(o=>required.some(k=>k!=='created_at' && !!o[k])).length, counts};
  }
  function fromTable(table) {
    let start = table.findIndex(r => r.some(h => idKeys.has(norm(h)) || /^order id\s*\/\s*placement time$/.test(norm(h))));
    if (start < 0) throw Error('Không tìm thấy cột Order ID / Mã đơn hàng. Dùng file xuất gốc từ Seller Center.');
    const headers = table[start], rows = [];
    for (const r of table.slice(start+1)) {
      const o = Object.fromEntries(headers.map((h,i)=>[h,r[i] ?? '']));
      const combined = Object.keys(o).find(h=>/order id\s*\/\s*placement time/.test(norm(h)));
      if (combined) {
        const m = String(o[combined]).trim().match(/^(\d{10,24})\s+([\s\S]+)$/);
        if (m) {o['Order ID']=m[1];o.placement_time=m[2].replace(/\s+/g,' ').trim();}
      }
      const oid = orderId(o);
      for (const [k,v] of Object.entries(o)) if (idKeys.has(norm(k)) && typeof v === 'number' && !Number.isSafeInteger(v)) throw Error('Mã đơn trong file là số đã bị Excel làm tròn. Xuất lại file gốc có mã đơn dạng chữ; không dùng bản đã chuyển cột ID thành Number.');
      if (oid) rows.push({order_id:oid,...flat(o)});
    }
    return rows;
  }
  function objects(payload,visit) {
    let nodes=0;
    function walk(o,depth=0){if(!o||typeof o!=='object'||depth>14||++nodes>100000)return;if(Array.isArray(o)){o.forEach(x=>walk(x,depth+1));return;}visit(o);for(const [k,v]of Object.entries(o))if(v&&typeof v==='object'&&!/^(?:buyer|recipient|recipient_address|address|payment|price|refunds?)$/i.test(k))walk(v,depth+1);}
    walk(payload);
  }
  // Identify unknown JSON keys only from two or more exact Order ID + visible
  // column-value pairs. Ambiguous timestamps (e.g. pickup == handover) stay unknown.
  function learnTableMapping(payload,witnesses) {
    const by=new Map(witnesses.filter(r=>id(r.order_id)&&r.actual_handover_at).map(r=>[r.order_id,r]));
    if(by.size<2)return null;
    const groups=new Map(), cols=['created_at','actual_handover_at','shipping_location','delivery_type','pickup_type'];
    objects(payload,o=>{
      for(const [idKey,value]of Object.entries(o)) {
        const oid=id(value), witness=by.get(oid);if(!witness)continue;
        const scalar=Object.entries(o).filter(([,v])=>v!=null&&typeof v!=='object');
        const signature=idKey+'|'+scalar.map(([k])=>k).sort().join('|');
        const group=groups.get(signature)||{idKey,ids:new Set(),candidates:{},evidence:{}};
        group.ids.add(oid);
        for(const f of cols)if(witness[f]) {
          (group.evidence[f] ||= new Set()).add(oid);
          const matches=new Set(scalar.filter(([k,v])=>k!==idKey&&(times.has(f)?time(v):String(v).trim())===witness[f]).map(([k])=>k));
          group.candidates[f]=group.candidates[f]?new Set([...group.candidates[f]].filter(k=>matches.has(k))):matches;
        }
        groups.set(signature,group);
      }
    });
    const valid=[...groups.values()].filter(g=>g.ids.size>=2 && g.candidates.actual_handover_at?.size===1);
    if(valid.length!==1)return null;
    const g=valid[0];return {idKey:g.idKey,fields:Object.fromEntries(Object.entries(g.candidates).filter(([f,ks])=>ks.size===1 && g.evidence[f].size>=2).map(([f,ks])=>[f,[...ks][0]])),evidenceOrders:g.ids.size};
  }
  function extractMapped(payload,mapping) {
    const rows=new Map();
    objects(payload,o=>{
      const oid=id(o[mapping.idKey]);if(!oid)return;
      const row={order_id:oid};
      for(const [f,key]of Object.entries(mapping.fields)){const v=o[key];if(v!=null&&typeof v!=='object'){const value=times.has(f)?time(v):String(v).trim();if(value && !/^[-–—]+$/.test(value))row[f]=value;}}
      if(Object.keys(row).length>1)rows.set(oid,merge(rows.get(oid)||row,row));
    });return [...rows.values()];
  }
  root.OPDetails = {fields,required,id,time,flat,extract,merge,summary,fromTable,norm,learnTableMapping,extractMapped};
  if (typeof module !== 'undefined' && module.exports) module.exports = root.OPDetails;
})(typeof globalThis === 'undefined' ? this : globalThis);
