importScripts('xlsx.mini.min.js', 'lib/op-store.js', 'lib/op-sync.js', 'lib/op-handover.js', 'lib/op-tiktok-shop.js', 'lib/op-shopee-shop.js', 'lib/op-tiktok-attachments.js', 'lib/op-cancel-return.js', 'handover_background.js', 'cancel_return_background.js');

const NATIVE_HOST = 'com.onpoint.tts_pickup_split';
const POWER_BI_RAW_STEM = 'Operations FBO Backlog Dashboard - Orders Detailed View';
/* -----------------------------------------------------------------------------
 * v0.11.3 — TÊN FILE RAW THEO SÀN.
 * v0.11.2 đặt mọi file raw là TTS_Pickup_Backlog_Raw_<stamp>.xlsx, kể cả khi
 * chạy tab Shopee ("TTS" = TikTok Shop), nên hai sàn nằm lẫn trong cùng thư mục
 * Raw và không phân biệt được.
 *
 * Stem cũ vẫn được NHẬN DIỆN (LEGACY_RAW_STEM) để file đã tải trước đó và bản
 * Native Host cũ — vốn dò tên chứa "TTS_Pickup_Backlog_Raw" — vẫn hoạt động.
 * -------------------------------------------------------------------------- */
const RAW_STEM_BY_PLATFORM = {
  TIKTOK: 'TikTok_Backlog_Raw',
  SHOPEE: 'Shopee_Backlog_Raw'
};
const LEGACY_RAW_STEM = 'TTS_Pickup_Backlog_Raw';
const OUTPUT_RAW_STEM = RAW_STEM_BY_PLATFORM.TIKTOK;

const normalizePlatform = (value) =>
  String(value || '').trim().toUpperCase() === 'SHOPEE' ? 'SHOPEE' : 'TIKTOK';
const rawStemFor = (platform) => RAW_STEM_BY_PLATFORM[normalizePlatform(platform)];
const WAREHOUSE_FFM_OPTIONS = ['TNSL', 'TOLL', 'MCL'];
/* URL Web App mặc định.
 *
 * Bản v0.10.9 nhét sẵn một URL thuộc deployment của người khác. Deployment đó
 * đã bị xoá — mở ra trả về "Không tìm thấy trang". Vì extension vẫn coi nó là
 * cấu hình hợp lệ, mọi lần sync đều thất bại ÂM THẦM và record nằm mãi ở
 * Pending; bấm "Sync pending" bao nhiêu lần cũng vô ích.
 *
 * Nay trỏ vào deployment đang hoạt động của Sheet OnPoint TTS Tracking Master
 * (đã kiểm chứng: doGet trả {"ok":true,"service":"OnPoint Ticket Master",
 * "version":"2.0.0"}).
 */
const DEFAULT_GOOGLE_SYNC_URL = '';
const GOOGLE_SYNC_SOURCE = 'OnPoint Marketplace Ticket Assistant v0.10.23';

let activeRun = null;
const processingDownloadPromises = new Map();
const processedDownloadResults = new Map();
let ticketStateWrite = Promise.resolve();
let trustedBrowserInputQueue = Promise.resolve();

function debuggerAttach(target) {
  return new Promise((resolve, reject) => {
    chrome.debugger.attach(target, '1.3', () => {
      const error = chrome.runtime.lastError;
      if (error) reject(new Error(error.message));
      else resolve();
    });
  });
}

function debuggerCommand(target, method, params = {}) {
  return new Promise((resolve, reject) => {
    chrome.debugger.sendCommand(target, method, params, (result) => {
      const error = chrome.runtime.lastError;
      if (error) reject(new Error(error.message));
      else resolve(result);
    });
  });
}

function debuggerDetach(target) {
  return new Promise((resolve) => {
    chrome.debugger.detach(target, () => {
      // Detach is best effort; reading lastError prevents a console warning.
      void chrome.runtime.lastError;
      resolve();
    });
  });
}

async function dispatchTrustedBrowserClick(tabId, payload = {}) {
  const x = Number(payload.x);
  const y = Number(payload.y);
  const ctrlKey = Boolean(payload.ctrlKey);
  if (!Number.isFinite(x) || !Number.isFinite(y) || x < 0 || y < 0) {
    throw new Error('Tọa độ thao tác Power BI không hợp lệ.');
  }

  const target = { tabId };
  const modifiers = ctrlKey ? 2 : 0;
  let attached = false;
  let controlPressed = false;
  try {
    try {
      await debuggerAttach(target);
      attached = true;
    } catch (error) {
      if (!/already attached|another debugger/i.test(error?.message || '')) throw error;
      // v2.2.26 — keepalive đã gắn debugger vào tab tạo phiếu. Dùng lại phiên CỦA CHÍNH EXTENSION
      // sau khi một lệnh chỉ đọc thành công; không gỡ phiên đang giữ tab thức.
      // DevTools/extension khác giữ tab thì sendCommand thất bại: giữ nguyên lỗi, không chiếm phiên.
      try { await debuggerCommand(target, 'Runtime.evaluate', { expression: '1', returnByValue: true, silent: true }); }
      catch (_) { throw error; }
    }
    if (ctrlKey) {
      await debuggerCommand(target, 'Input.dispatchKeyEvent', {
        type: 'rawKeyDown',
        key: 'Control',
        code: 'ControlLeft',
        windowsVirtualKeyCode: 17,
        nativeVirtualKeyCode: 17,
        location: 1,
        modifiers: 2
      });
      controlPressed = true;
    }
    await debuggerCommand(target, 'Input.dispatchMouseEvent', {
      type: 'mouseMoved',
      x,
      y,
      button: 'none',
      buttons: 0,
      modifiers
    });
    await debuggerCommand(target, 'Input.dispatchMouseEvent', {
      type: 'mousePressed',
      x,
      y,
      button: 'left',
      buttons: 1,
      clickCount: 1,
      modifiers
    });
    await debuggerCommand(target, 'Input.dispatchMouseEvent', {
      type: 'mouseReleased',
      x,
      y,
      button: 'left',
      buttons: 0,
      clickCount: 1,
      modifiers
    });
    return { ok: true, mode: 'chrome-debugger', reusedSession: !attached, ctrlKey, x, y };
  } catch (error) {
    const detail = error?.message || String(error);
    if (/another debugger|already attached|cannot attach/i.test(detail)) {
      throw new Error(
        'Chrome đang có DevTools/debugger khác giữ tab Power BI. Hãy đóng DevTools của tab rồi chạy lại.'
      );
    }
    throw new Error(`Không bấm thật được trên Power BI: ${detail}`);
  } finally {
    if (ctrlKey && controlPressed) {
      await debuggerCommand(target, 'Input.dispatchKeyEvent', {
        type: 'keyUp',
        key: 'Control',
        code: 'ControlLeft',
        windowsVirtualKeyCode: 17,
        nativeVirtualKeyCode: 17,
        location: 1,
        modifiers: 0
      }).catch(() => {});
    }
    const heldByKeepAlive = typeof OP_DBG !== 'undefined' && OP_DBG.get(Number(tabId)) === 'on';
    if (attached && !heldByKeepAlive) await debuggerDetach(target);
  }
}

function queueTrustedBrowserClick(tabId, payload) {
  const task = trustedBrowserInputQueue.then(() =>
    dispatchTrustedBrowserClick(tabId, payload)
  );
  trustedBrowserInputQueue = task.catch(() => {});
  return task;
}

function nowStamp() {
  const date = new Date();
  const pad = (value) => String(value).padStart(2, '0');
  return (
    `${date.getFullYear()}${pad(date.getMonth() + 1)}${pad(date.getDate())}` +
    `_${pad(date.getHours())}${pad(date.getMinutes())}${pad(date.getSeconds())}`
  );
}

function sanitizeStamp(value) {
  const stamp = String(value || '').replace(/[^0-9_]/g, '');
  return /^\d{8}_\d{6}$/.test(stamp) ? stamp : null;
}

function sanitizeWarehouseSelection(values) {
  if (!Array.isArray(values)) return [...WAREHOUSE_FFM_OPTIONS];
  const requested = new Set(
    values.map((value) => String(value || '').trim().toUpperCase())
  );
  return WAREHOUSE_FFM_OPTIONS.filter((value) => requested.has(value));
}

function leafName(path) {
  return String(path || '').split(/[\\/]/).pop() || '';
}

const RAW_STEM_PATTERN = '(?:TikTok_Backlog_Raw|Shopee_Backlog_Raw|TTS_Pickup_Backlog_Raw)';

function isPowerBiRawName(name) {
  const leaf = leafName(name);
  return (
    /\.xlsx$/i.test(leaf) &&
    (
      /Orders Detailed View/i.test(leaf) ||
      /Operations FBO Backlog Dashboard/i.test(leaf) ||
      new RegExp(`${RAW_STEM_PATTERN}_\\d{8}_\\d{6}`, 'i').test(leaf)
    )
  );
}

function isRenamedRawPath(path) {
  // Thư mục con theo sàn (Raw/TikTok, Raw/Shopee) là tuỳ chọn, để file tải bằng
  // các bản trước — nằm thẳng trong Raw/ — vẫn được nhận là file raw hợp lệ.
  return new RegExp(
    `(?:^|[\\\\/])OnPoint_TTS_Pickup_Ticket[\\\\/]Raw[\\\\/](?:TikTok[\\\\/]|Shopee[\\\\/])?` +
    `${RAW_STEM_PATTERN}_\\d{8}_\\d{6}(?: \\(\\d+\\))?\\.xlsx$`,
    'i'
  ).test(String(path || ''));
}

function nativeMessage(payload) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendNativeMessage(NATIVE_HOST, payload, (response) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      resolve(response);
    });
  });
}

function normalizeQueueKey(value) {
  return String(value || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/đ/gi, 'd')
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, ' ')
    .replace(/\s+/g, ' ');
}

function summarizeQueue(rows) {
  const channels = new Set();
  const groups = new Set();
  for (const row of rows) {
    const channel = normalizeQueueKey(row?.channel);
    const carrier = normalizeQueueKey(row?.carrier);
    const warehouse = normalizeQueueKey(row?.warehouse);
    if (channel) channels.add(channel);
    if (channel && carrier && warehouse) {
      groups.add(`${carrier}|||${channel}|||${warehouse}`);
    }
  }
  return {
    channelCount: channels.size,
    groupCount: groups.size
  };
}

const FAST_ALIASES = {
  platformOrderId: ['platform order id', 'platform orderid', 'platform_order_id'],
  orderNo: ['order no', 'order number', 'order id', 'orderid', 'order code', 'ordercode', 'order ref code', 'mã đơn hàng', 'ma don hang'],
  channel: ['channel name', 'channel_name', 'opollo channel name', 'shop name', 'store name', 'store', 'channel'],
  carrier: ['delivery platform', 'delivery partner', 'logistics provider', 'carrier', 'đvvc', 'dvvc'],
  platform: ['platform', 'platform name', 'sales platform', 'marketplace'],
  status: ['order status', 'status', 'warehouse status', 'delivery completion status'],
  orderDate: ['order date', 'order created', 'platform created at', 'created at', 'order created platform'],
  slaAt: ['sla date', 'sla deadline', 'firstmile sla deadline', 'dispatch sla'],
  trackingId: ['tracking no', 'tracking code', 'tracking id', 'tracking number', 'ship code'],
  warehouse: ['warehouse branch', 'wh branch', 'ffm group wh branch', 'warehouse', 'fc', 'fulfillment center'],
  cnnc: ['cnnc', 'mã cnnc', 'ma cnnc', 'cnnc code', 'channel nickname code', 'channel nick name code', 'mã đầu đơn', 'ma dau don', 'order prefix', 'prefix', 'preflix'],
  sourceFile: ['source file']
};

function detectFastColumns(headers) {
  const normalized = new Map(headers.map((header) => [normalizeQueueKey(header), header]));
  const result = {};
  for (const [key, aliases] of Object.entries(FAST_ALIASES)) {
    let match = aliases.map(normalizeQueueKey).find((alias) => normalized.has(alias));
    if (!match) {
      match = [...normalized.keys()].find((header) =>
        aliases.some((alias) => header.includes(normalizeQueueKey(alias)))
      );
    }
    result[key] = match ? normalized.get(match) : null;
  }
  if (result.platform && normalizeQueueKey(result.platform).includes('delivery platform')) {
    result.platform = null;
  }
  return result;
}

function deriveFastOrderId(value) {
  const raw = String(value ?? '').trim();
  const numericTail = raw.match(/(\d{12,25})$/);
  if (numericTail) return numericTail[1];
  const parts = raw.split('-').filter(Boolean);
  return parts.length > 1 ? parts[parts.length - 1] : raw;
}

async function readDownloadedWorkbook(rawPath) {
  const chunks = [];
  let totalLength = 0;
  let offset = 0;
  let fileSize = 0;
  let chunkNumber = 0;

  while (true) {
    const response = await nativeMessage({
      action: 'readRawChunk',
      rawPath,
      offset,
      length: 512 * 1024
    });
    if (!response?.ok || typeof response.data !== 'string') {
      throw new Error(response?.error || 'Không đọc được file Excel raw vừa tải.');
    }
    const bytes = base64ToBytes(response.data);
    chunks.push(bytes);
    totalLength += bytes.length;
    fileSize = Number(response.fileSize || totalLength);
    offset = Number(response.nextOffset || totalLength);
    chunkNumber++;
    if (chunkNumber === 1 || chunkNumber % 10 === 0) {
      await publishProgress(
        'query',
        `Đã download Excel raw. Đang nạp nhanh: ${Math.min(100, Math.round(offset * 100 / Math.max(1, fileSize)))}%…`
      );
    }
    if (response.eof) break;
  }

  const workbookBytes = new Uint8Array(totalLength);
  let writeOffset = 0;
  for (const chunk of chunks) {
    workbookBytes.set(chunk, writeOffset);
    writeOffset += chunk.length;
  }
  return workbookBytes;
}

function parseFastQueue(workbookBytes, sourceName, fallbackPlatform = 'TIKTOK') {
  const workbook = XLSX.read(workbookBytes, { type: 'array', cellDates: false });
  const sheetName = workbook.SheetNames.includes('Export')
    ? 'Export'
    : workbook.SheetNames[0];
  if (!sheetName) throw new Error('File Excel không có sheet dữ liệu.');
  const matrix = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], {
    header: 1,
    defval: '',
    raw: false,
    blankrows: false
  });
  if (matrix.length < 2) throw new Error('Sheet Export không có dữ liệu.');

  let headerIndex = 0;
  let bestScore = -1;
  for (let index = 0; index < Math.min(25, matrix.length); index++) {
    const candidate = matrix[index].map((value, column) =>
      String(value || `Column ${column + 1}`).trim()
    );
    const columns = detectFastColumns(candidate);
    const score = ['channel', 'carrier', 'warehouse', 'orderDate', 'slaAt', 'trackingId']
      .filter((key) => columns[key]).length
      + (columns.platformOrderId || columns.orderNo ? 1 : 0);
    if (score > bestScore) {
      bestScore = score;
      headerIndex = index;
    }
  }

  const rawHeaders = matrix[headerIndex];
  const counts = new Map();
  const headers = rawHeaders.map((value, column) => {
    const base = String(value || `Column ${column + 1}`).trim();
    const key = base.toLowerCase();
    const count = (counts.get(key) || 0) + 1;
    counts.set(key, count);
    return count === 1 ? base : `${base}_${count}`;
  });
  const columns = detectFastColumns(headers);
  const missing = [];
  if (!columns.platformOrderId && !columns.orderNo) missing.push('Platform Order ID hoặc Order No');
  for (const key of ['channel', 'carrier', 'warehouse', 'orderDate', 'slaAt', 'trackingId']) {
    if (!columns[key]) missing.push(key);
  }
  if (missing.length) throw new Error(`Thiếu cột bắt buộc: ${missing.join(', ')}.`);

  const rows = [];
  for (let index = headerIndex + 1; index < matrix.length; index++) {
    const values = matrix[index];
    const original = Object.fromEntries(
      headers.map((header, column) => [header, values[column] ?? ''])
    );
    const orderNo = columns.orderNo ? String(original[columns.orderNo] ?? '').trim() : '';
    const orderId = columns.platformOrderId
      ? String(original[columns.platformOrderId] ?? '').trim()
      : deriveFastOrderId(orderNo);
    const channel = String(original[columns.channel] ?? '').trim();
    const carrier = String(original[columns.carrier] ?? '').trim();
    const warehouse = String(original[columns.warehouse] ?? '').trim();
    if (!orderId || !channel || !carrier || !warehouse) continue;
    rows.push({
      _row: index + 1,
      orderId,
      orderNo,
      cnnc: columns.cnnc ? String(original[columns.cnnc] ?? '').trim() : '',
      channel,
      carrier,
      platform: columns.platform
        ? String(original[columns.platform] ?? '').trim()
        : fallbackPlatform,
      status: columns.status ? String(original[columns.status] ?? '').trim() : '',
      orderDate: String(original[columns.orderDate] ?? '').trim(),
      slaAt: String(original[columns.slaAt] ?? '').trim(),
      trackingId: String(original[columns.trackingId] ?? '').trim(),
      warehouse,
      sourceFile: columns.sourceFile
        ? String(original[columns.sourceFile] ?? '').trim()
        : sourceName,
      _original: original
    });
  }
  if (!rows.length) throw new Error('Không có dòng nào để tạo Ticket queue.');
  return rows;
}

function base64ToBytes(value) {
  const binary = atob(String(value || ''));
  const bytes = new Uint8Array(binary.length);
  for (let index = 0; index < binary.length; index++) {
    bytes[index] = binary.charCodeAt(index);
  }
  return bytes;
}

async function decodeInlineQueue(buildResponse) {
  const encoding = String(buildResponse?.queuePayloadEncoding || '');
  const payload = String(buildResponse?.queuePayload || '');
  if (encoding !== 'gzip-base64' || !payload) return null;
  if (typeof DecompressionStream !== 'function') {
    throw new Error(
      'Chrome hiện tại không hỗ trợ giải nén queue nhanh. Hãy cập nhật Chrome hoặc chọn file Excel thủ công.'
    );
  }

  const compressed = base64ToBytes(payload);
  const decompressedStream = new Blob([compressed])
    .stream()
    .pipeThrough(new DecompressionStream('gzip'));
  const decoded = await new Response(decompressedStream).json();
  return Array.isArray(decoded?.rows) ? decoded.rows : null;
}

async function loadQueuePages(buildResponse) {
  const queueToken = String(buildResponse?.queueToken || '');
  const pageCount = Number(buildResponse?.queuePageCount || 0);
  const expectedRowCount = Number(buildResponse?.queueRowCount || 0);
  if (!queueToken || pageCount < 1 || expectedRowCount < 1) {
    throw new Error(
      'Excel đã split nhưng helper chưa tạo dữ liệu Ticket queue. Hãy chạy lại Install.cmd của bản mới.'
    );
  }

  const rows = [];
  for (let pageIndex = 0; pageIndex < pageCount; pageIndex++) {
    if (pageIndex === 0 || pageIndex % 5 === 0) {
      await publishProgress(
        'queue',
        `Excel đã split xong. Đang nạp Ticket queue: ${Math.min(pageIndex + 1, pageCount)}/${pageCount}…`
      );
    }
    const page = await nativeMessage({
      action: 'readQueuePage',
      queueToken,
      pageIndex
    });
    if (!page?.ok || !Array.isArray(page.rows)) {
      throw new Error(page?.error || `Không đọc được Ticket queue page ${pageIndex + 1}.`);
    }
    rows.push(...page.rows);
  }

  if (rows.length !== expectedRowCount) {
    throw new Error(
      `Ticket queue thiếu dữ liệu: nhận ${rows.length.toLocaleString('en-US')}/${expectedRowCount.toLocaleString('en-US')} dòng.`
    );
  }
  return rows;
}

async function loadQueueData(buildResponse) {
  const expectedRowCount = Number(buildResponse?.queueRowCount || 0);
  const hasInlinePayload =
    buildResponse?.queuePayloadEncoding === 'gzip-base64' &&
    Boolean(buildResponse?.queuePayload);

  if (!hasInlinePayload) {
    return loadQueuePages(buildResponse);
  }

  await publishProgress(
    'queue',
    'Excel đã split xong. Đang nạp Ticket queue một lần…'
  );
  const rows = await decodeInlineQueue(buildResponse);
  if (!Array.isArray(rows)) {
    throw new Error('Không giải nén được dữ liệu Ticket queue.');
  }
  if (rows.length !== expectedRowCount) {
    throw new Error(
      `Ticket queue thiếu dữ liệu: nhận ${rows.length.toLocaleString('en-US')}/${expectedRowCount.toLocaleString('en-US')} dòng.`
    );
  }
  return rows;
}

async function publishProgress(step, message, extra = {}) {
  const payload = {
    type: 'PBI_AUTOMATION_PROGRESS',
    step,
    message,
    at: new Date().toISOString(),
    ...extra
  };
  await chrome.storage.local.set({ pbiLastRun: payload });
  try {
    await chrome.runtime.sendMessage(payload);
  } catch (_) {
    // The side panel may be closed; persisted state remains authoritative.
  }
}

// Các URL đã biết là chết — nếu Chrome còn lưu thì thay ngay khi khởi động.
const DEAD_SYNC_URLS = ['AKfycbyMK3o170Pll5MoPpBFm1UsaELsSaduGXHBzwm4maTq03iBULaB8i87E4eZOMbmTliL'];

async function initializeExtension() {
  // OPStore.init() tự di trú key 'ticketLog' cũ sang các chunk mới ở lần chạy
  // đầu tiên sau khi nâng cấp. Không mất record nào.
  await OPStore.init();
  await recoverHandoverRun();

  const { googleSyncUrl } = await chrome.storage.local.get(['googleSyncUrl']);
  const stored = String(googleSyncUrl || '').trim();
  const isDead = !stored || DEAD_SYNC_URLS.some((id) => stored.includes(id));
  if (isDead && DEFAULT_GOOGLE_SYNC_URL) {
    await chrome.storage.local.set({ googleSyncUrl: DEFAULT_GOOGLE_SYNC_URL });
    console.info('[OnPoint] Đã thay URL Web App chết bằng deployment đang hoạt động.');
  }

  // Có job còn kẹt từ phiên trước (tắt Chrome giữa chừng, mất mạng)? Gửi lại.
  OPSync.flush({ force: true }).catch(() => {});

  if (chrome.sidePanel?.setPanelBehavior) {
    await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
  }
}

function withTicketStateLock(task) {
  const run = ticketStateWrite.then(task, task);
  ticketStateWrite = run.catch(() => {});
  return run;
}

function deriveCnncFromRow(row) {
  const explicit = String(row?.cnnc || '').trim();
  if (explicit) return explicit;
  const orderNo = String(row?.orderNo || '').trim();
  const orderId = String(row?.orderId || '').trim();
  if (!orderNo || orderNo === orderId) return '';
  if (orderId) {
    const index = orderNo.lastIndexOf(orderId);
    if (index > 0) {
      const prefix = orderNo.slice(0, index).replace(/[\s\-_/|:]+$/g, '').trim();
      if (prefix) return prefix;
    }
  }
  return orderNo.match(/^([A-Za-z][A-Za-z0-9]{1,30})(?:[\s\-_/|:]+)/)?.[1] || '';
}

function normalizeTicketOrderId(value) {
  return String(value == null ? '' : value).trim().toUpperCase();
}

function isValidGoogleSyncUrl(value) {
  try {
    const url = new URL(String(value || '').trim());
    return url.protocol === 'https:' &&
      (url.hostname === 'script.google.com' || url.hostname.endsWith('.script.google.com')) &&
      /\/exec\/?$/.test(url.pathname);
  } catch (_) {
    return false;
  }
}

function ticketRecordKey(record) {
  const ticketId = String(record?.TicketID || record?.ticketId || '').trim();
  const orderId = normalizeTicketOrderId(record?.OrderID || record?.orderId);
  return ticketId && orderId ? `${ticketId}|||${orderId}` : '';
}

/* -----------------------------------------------------------------------------
 * v0.11 — ĐỒNG BỘ KHÔNG CHẶN.
 *
 * v0.10.x gọi fetch() tới Apps Script rồi CHỜ ngay trong luồng nghiệp vụ,
 * không timeout, không retry. Apps Script phía kia đọc cả sheet mỗi lần và
 * ghi từng dòng một dưới DocumentLock 30 giây → mỗi ticket chờ 5–30 giây và
 * cả queue raise đứng lại theo.
 *
 * v0.11 chỉ đẩy record vào hàng đợi bền rồi trả về ngay. OPSync lo phần còn
 * lại ở nền: gộp lô, timeout, backoff mũ, và chrome.alarms để hồi phục kể cả
 * sau khi service worker bị Chrome tắt.
 * -------------------------------------------------------------------------- */
async function queueTicketSync(records, meta = {}) {
  if (!records.length) return { ok: true, skipped: true, queued: 0 };
  const result = await OPSync.enqueue(records, meta);
  return { ok: true, queued: result.queued, deferred: true };
}

/** Đẩy lại mọi record còn Pending — nút "Sync pending" trên Side Panel. */
async function retryPendingSync() {
  const pendingRecords = await OPStore.pending();
  if (!pendingRecords.length) {
    const flushed = await OPSync.flush({ force: true });
    return { ok: Boolean(flushed.ok ?? flushed.done ?? false), queued: 0,
      message: flushed.done ? 'Không còn record nào Pending.' : 'Đã thử lại hàng đợi được giữ trên máy.', ...flushed };
  }
  await OPSync.enqueue(pendingRecords, { reason: 'manual-retry' });
  const flushed = await OPSync.flush({ force: true });
  return { ok: Boolean(flushed.ok ?? true), queued: pendingRecords.length, ...flushed };
}

/* Khi lô đồng bộ thành công/thất bại, chỉ vá đúng chunk chứa record đó. */
/* Sau khi vá trạng thái, PHẢI đẩy con trỏ phiên bản.
 *
 * patchByKeys() chỉ ghi đúng chunk chứa record (ví dụ `tl:c0`), còn Side Panel
 * lại nghe `ticketLogVersion` / `tl:meta` để biết khi nào nạp lại. Không đụng
 * tới hai key đó thì màn hình giữ nguyên bản cũ: hàng đợi báo "Đồng bộ xong,
 * không còn dòng chờ" trong khi danh sách vẫn hiện `Pending`. Dữ liệu đúng,
 * chỉ hiển thị sai — nhưng nhìn vào thì tưởng sync hỏng.
 */
async function markSyncResult(rows, patch) {
  return withTicketStateLock(async () => {
    const keys = rows.map(OPStore.keyOf).filter(Boolean);
    if (!keys.length) return;
    const touched = await OPStore.patchByKeys(keys, record => {
      const source = rows.find(row => OPStore.keyOf(row) === OPStore.keyOf(record));
      return source?.HandoverSubmissionRef && source.HandoverAppealTicketID !== record.HandoverAppealTicketID ? {} : patch;
    });
    const data = await chrome.storage.local.get('handoverTicketHistory');
    let changed = false;
    const history = (data.handoverTicketHistory || []).map(item => {
      const match = rows.some(row => OPHandover.matches(item, row.OrderID, String(row.TicketPlatform || 'tiktok').toLowerCase()) && row.HandoverAppealTicketID === item.TicketID);
      if (!match) return item;
      changed = true;
      return { ...item, ...patch };
    });
    if (touched || changed) await chrome.storage.local.set({ ticketLogVersion: new Date().toISOString(), ...(changed ? { handoverTicketHistory: history } : {}) });
  });
}

// Local outbox survives a worker restart between saving the ticket and enqueueing Sheets.
async function drainTicketSyncOutbox() {
  const { ticketSyncOutbox = {} } = await chrome.storage.local.get('ticketSyncOutbox');
  for (const [key, job] of Object.entries(ticketSyncOutbox)) {
    try {
      await queueTicketSync(job.rows, job.meta);
      delete ticketSyncOutbox[key];
      await chrome.storage.local.set({ ticketSyncOutbox });
    } catch (error) {
      chrome.alarms.create('op-ticket-save-sync', { when: Date.now() + 60000 });
      console.warn('[OnPoint] saved ticket sync will retry', error);
      break;
    }
  }
}
chrome.alarms.onAlarm.addListener(alarm => {
  if (alarm.name === 'op-ticket-save-sync') withTicketStateLock(drainTicketSyncOutbox).catch(console.error);
});
chrome.runtime.onStartup.addListener(() => withTicketStateLock(drainTicketSyncOutbox).catch(console.error));
withTicketStateLock(drainTicketSyncOutbox).catch(console.error);

OPSync.setHooks({
  synced: (rows) => {
    const syncedAt = new Date().toISOString();
    markSyncResult(rows, { SyncStatus: 'Synced', SyncedAt: syncedAt, SyncError: '' })
      .catch((error) => console.warn('[OnPoint] patch synced failed', error));
  },
  failed: (rows, error) => {
    /* v2.2.9 — mỗi lần ghi trạng thái là Side Panel phải nạp lại Ticket Master. Lỗi lặp lại cùng nội dung cho cùng lô
       (retry backoff) thì không ghi lại nữa — trước đây mỗi lần retry đều ghi → panel giật liên tục. */
    const sig = `${String(error || '').slice(0, 120)}|${rows.map(OPStore.keyOf).join(',')}`;
    if (sig === lastSyncFailSig) return;
    lastSyncFailSig = sig;
    markSyncResult(rows, { SyncStatus: 'Pending', SyncError: String(error || '') })
      .catch(() => {});
  }
});
let lastSyncFailSig = '';
OPSync.attach();

/* v2.2.9 — Ticket Master cục bộ: tự bỏ các chunk cũ hơn 90 ngày ĐÃ Synced (đã có trên Google Sheet) để Side Panel không
   phải nạp lại hàng chục nghìn dòng mỗi lần cập nhật. Chunk nóng và mọi dòng còn Pending luôn được giữ. Chạy mỗi ngày. */
const LOCAL_RETENTION_DAYS = 90;
async function pruneLocalTicketLog() {
  const removed = await withTicketStateLock(() => OPStore.prune(LOCAL_RETENTION_DAYS));
  if (removed) { await chrome.storage.local.set({ ticketLogVersion: new Date().toISOString() }); console.info(`[OnPoint] Đã dọn ${removed} ticket cục bộ cũ hơn ${LOCAL_RETENTION_DAYS} ngày.`); }
}
chrome.alarms.get('op-ticket-prune').then(a => { if (!a) chrome.alarms.create('op-ticket-prune', { delayInMinutes: 2, periodInMinutes: 24 * 60 }); }).catch(() => {});
chrome.alarms.onAlarm.addListener(alarm => { if (alarm.name === 'op-ticket-prune') pruneLocalTicketLog().catch(console.warn); });

async function getTicketPayloadForTab(tabId, includeFileBytes = false) {
  const data = await chrome.storage.local.get([
    'ticketTabPayloads',
    'ticketBatchEvidence',
    'ticketOpenGroups',
    'ticketTabReceipts',
    'currentDraft',
    'currentAttachments'
  ]);
  const payload = data.ticketTabPayloads?.[String(tabId)];
  if (payload?.draft) {
    const evidence = Array.isArray(data.ticketBatchEvidence?.[payload.batchId])
      ? data.ticketBatchEvidence[payload.batchId]
      : [];
    const directAttachments = Array.isArray(payload.attachments)
      ? payload.attachments
      : [];
    const attachments = OPHandover.pageAppeal(payload.draft)
      ? [...evidence, ...(payload.orderEvidence || [])]
      : directAttachments.length ? directAttachments.slice(0, 6)
      : [payload.excelAttachment, ...evidence].filter(Boolean).slice(0, 6);
    // v2.2.49 — mọi phiếu TikTok đính kèm qua trang (MAIN world, từng file, chờ ô Tải lên nhận xong) — cùng 1 cách, không lỗi ghi đè.
    const pageUpload = OPHandover.pageAppeal(payload.draft) || String(payload.draft.platform || 'tiktok') === 'tiktok';
    return {
      ok: true, tabScoped: true, groupKey: payload.groupKey,
      draft: payload.draft, ticketCapture: payload.ticketCapture || null,
      attachmentTransport: pageUpload ? 'background-page' : 'inline',
      attachments: pageUpload && !includeFileBytes
        ? attachments.map((file, index) => ({ name: file.name, type: file.type, size: file.size, index }))
        : attachments
    };
  }

  if (data.ticketTabReceipts?.[String(tabId)]) {
    const receipt = data.ticketTabReceipts[String(tabId)];
    return receipt.pendingDraft ? { ok: true, tabScoped: true, draft: receipt.pendingDraft, ticketCapture: receipt.ticketCapture, submissionSaved: true, submission: receipt.submission, attachments: [] } : { ok: true, tabScoped: true, savedTicket: receipt };
  }

  if (data.currentDraft) {
    /* v0.11.15 — ticketTabPayloads[tabId] bị XOÁ ngay khi ghi nhận xong phiếu,
     * nên nếu tab đó load lại thì tab của chính tool cũng bị coi là tab lạ và
     * mất auto-submit. ticketOpenGroups giữ tabId lâu hơn → dùng làm bằng
     * chứng thứ hai cho câu hỏi "tab này có phải do tool mở không". */
    const openedByTool = Object.values(data.ticketOpenGroups || {})
      .some((entry) => Number(entry?.tabId) === Number(tabId));
    return {
      ok: true,
      tabScoped: openedByTool,
      groupKey: data.currentDraft.groupKey || '',
      draft: data.currentDraft,
      attachments: Array.isArray(data.currentAttachments)
        ? data.currentAttachments.slice(0, 6)
        : []
    };
  }
  return { ok: false, error: 'Không tìm thấy draft riêng cho tab ticket này.' };
}

const tikTokUploadQueues = new Map();
function queueTikTokAttachmentUpload(tabId, indices) {
  const previous = tikTokUploadQueues.get(tabId) || Promise.resolve();
  const run = previous.catch(() => {}).then(() => uploadTikTokAttachmentsFromStorage(tabId, indices));
  tikTokUploadQueues.set(tabId, run);
  run.finally(() => { if (tikTokUploadQueues.get(tabId) === run) tikTokUploadQueues.delete(tabId); }).catch(() => {});
  return run;
}
async function uploadTikTokAttachmentsFromStorage(tabId, indices) {
  const tab = await chrome.tabs.get(tabId);
  const shopee = /^https:\/\/help\.shopee\.vn\/portal\/webform\//.test(tab.url || '');
  if (!shopee && !/^https:\/\/seller-vn\.tiktok\.com\/ticket\/create(?:[/?]|$)/.test(tab.url || '')) throw new Error('Upload chỉ chạy trên form tạo ticket.');
  const context = await getTicketPayloadForTab(tabId, true);
  if (!context.tabScoped || !context.draft || String(context.draft?.platform || 'tiktok') !== (shopee ? 'shopee' : 'tiktok') || !(OPHandover.pageAppeal(context.draft) || String(context.draft?.platform || 'tiktok') === 'tiktok') || context.ticketCapture?.startedAt) throw new Error('Không còn đơn/phiếu đang chờ đính kèm.');
  const requested = [...new Set(indices || [])];
  if (!requested.length || requested.length > OPHandover.maxFiles(context.draft) || requested.some(index => !Number.isInteger(index) || index < 0 || index >= context.attachments.length)) throw new Error('Danh sách file không hợp lệ.');
  const perform = async (action, payload) => {
    const results = await chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', func: OPTikTokAttachments.pageOperation, args: [action, { platform: context.draft.platform, ...payload }] });
    const result = results[0]?.result;
    if (!result) throw new Error('Trang ticket chưa trả kết quả đính kèm.');
    return result;
  };
  const dispatchedIndices = [], statuses = {};
  for (const index of requested) {
    const file = context.attachments[index];
    if (!file.base64 || !file.size) throw new Error(`${file.name}: chưa có dữ liệu file. Chọn lại biên bản.`);
    const token = `op_upload_${tabId}_${Date.now()}_${index}_${Math.random().toString(36).slice(2)}`;
    try {
      // Transport chunks stay far below Chrome's message limit, even for a large PDF/video.
      const chunkSize = 393216;
      for (let offset = 0, sequence = 0; offset < file.base64.length; offset += chunkSize, sequence++) {
        const result = await perform('chunk', { token, sequence, base64: file.base64.slice(offset, offset + chunkSize) });
        if (!result.ok) throw new Error(result.error || 'Không chuyển được file sang trang ticket.');
      }
      let result;
      for (let attempt = 0; attempt < (shopee ? 25 : 5); attempt++) {
        result = await perform('dispatch', { token, name: file.name, type: file.type, size: file.size });
        if (result.ok || !result.retryable) break;
        await new Promise(resolve => setTimeout(resolve, 200));
      }
      if (!result?.ok) throw new Error(result?.error || `Chưa đính kèm được ${file.name}.`);
      dispatchedIndices.push(index);
      if (result.status) statuses[index] = result.status;
    } finally { await perform('clear', { token }).catch(() => {}); }
  }
  return { ok: true, dispatchedIndices, statuses };
}

async function updateTicketCaptureState(tabId, capture) {
  return withTicketStateLock(async () => {
    const data = await chrome.storage.local.get(['ticketTabPayloads', 'ticketOpenGroups']);
    const payload = data.ticketTabPayloads?.[String(tabId)];
    if (!payload?.draft) return { ok: false, error: 'Không tìm thấy đơn riêng của tab.' };
    const orderId = normalizeTicketOrderId(payload.draft.representativeOrderId || payload.draft.rows?.[0]?.orderId);
    if (normalizeTicketOrderId(capture?.orderId) !== orderId) return { ok: false, error: 'Đơn gửi không khớp tab.' };
    const ticketCapture = Number(capture.startedAt) > 0 ? {
      orderId, startedAt: Number(capture.startedAt), baselineIds: (capture.baselineIds || []).map(String).slice(0, 200)
    } : null;
    const ticketTabPayloads = { ...data.ticketTabPayloads, [String(tabId)]: { ...payload, ticketCapture } };
    const ticketOpenGroups = { ...data.ticketOpenGroups };
    if (ticketOpenGroups[payload.groupKey]) ticketOpenGroups[payload.groupKey] = { ...ticketOpenGroups[payload.groupKey], status: ticketCapture ? 'saving-ticket' : 'opened' };
    await chrome.storage.local.set({ ticketTabPayloads, ticketOpenGroups });
    return { ok: true };
  });
}

// v2.2.26 — Trước khi có Ticket ID, tab vừa gửi phải bấm Tất cả để thấy phiếu mới.
// Luồng này dùng payload tạo phiếu, không phụ thuộc cancelReturnFollowRun (chỉ có sau khi đã bắt ID).
async function clickForTicketCapture(tab, message) {
  if (!/^https:\/\/seller-vn\.tiktok\.com\/ticket\/?(?:[?#]|$)/.test(tab?.url || '')) return { ok: false, error: 'Chỉ bấm Tất cả trên Nhật ký phiếu.' };
  const { ticketTabPayloads: payloads = {} } = await chrome.storage.local.get('ticketTabPayloads');
  const payload = payloads[String(tab.id)];
  const capture = payload?.ticketCapture;
  const orderId = normalizeTicketOrderId(payload?.draft?.representativeOrderId || payload?.draft?.rows?.[0]?.orderId);
  if (payload?.draft?.issueType !== 'cancel_return' || !capture?.startedAt || normalizeTicketOrderId(message.orderId) !== orderId || Number(message.startedAt) !== Number(capture.startedAt)) {
    return { ok: false, error: 'Tab không có phiếu đòi hàng đã gửi đang chờ bắt Ticket ID.' };
  }
  try { return await queueTrustedBrowserClick(tab.id, { x: message.x, y: message.y }); }
  catch (error) { return { ok: false, error: String(error?.message || error).replace(/Power BI/g, 'TikTok') }; }
}

async function updateTicketAutofillState(tabId, autofill) {
  return withTicketStateLock(async () => {
    const data = await chrome.storage.local.get([
      'ticketTabPayloads',
      'ticketOpenGroups'
    ]);
    const payload = data.ticketTabPayloads?.[String(tabId)];
    if (!payload?.groupKey) return { ok: false };
    const openGroups = data.ticketOpenGroups && typeof data.ticketOpenGroups === 'object'
      ? { ...data.ticketOpenGroups }
      : {};
    if (openGroups[payload.groupKey]) {
      openGroups[payload.groupKey] = {
        ...openGroups[payload.groupKey],
        status: autofill?.ok ? 'autofilled' : 'opened',
        autofill: autofill || {},
        autofilledAt: new Date().toISOString()
      };
      const ticketTabPayloads = { ...data.ticketTabPayloads, [String(tabId)]: { ...payload, autofill: autofill || {} } };
      await chrome.storage.local.set({ ticketOpenGroups: openGroups, ticketTabPayloads });
    }
    return { ok: true };
  });
}

async function cleanupTicketTabState(tabId) {
  return withTicketStateLock(async () => {
    const data = await chrome.storage.local.get([
      'ticketTabPayloads',
      'ticketBatchEvidence',
      'ticketOpenGroups'
    ]);
    const tabPayloads = data.ticketTabPayloads && typeof data.ticketTabPayloads === 'object'
      ? { ...data.ticketTabPayloads }
      : {};
    const payload = tabPayloads[String(tabId)];
    if (!payload) return { ok: true };

    delete tabPayloads[String(tabId)];
    const openGroups = data.ticketOpenGroups && typeof data.ticketOpenGroups === 'object'
      ? { ...data.ticketOpenGroups }
      : {};
    if (payload.groupKey && Number(openGroups[payload.groupKey]?.tabId) === Number(tabId)) {
      delete openGroups[payload.groupKey];
    }

    const batchEvidence = data.ticketBatchEvidence && typeof data.ticketBatchEvidence === 'object'
      ? { ...data.ticketBatchEvidence }
      : {};
    const batchStillUsed = Object.values(tabPayloads).some((item) =>
      item?.batchId === payload.batchId
    );
    if (!batchStillUsed && payload.batchId) delete batchEvidence[payload.batchId];

    await chrome.storage.local.set({
      ticketTabPayloads: tabPayloads,
      ticketBatchEvidence: batchEvidence,
      ticketOpenGroups: openGroups
    });
    return { ok: true };
  });
}

/* -----------------------------------------------------------------------------
 * v0.11 — ĐƯỜNG NÓNG "FAST NEXT GROUP".
 *
 * Ba thay đổi so với v0.10.28:
 *
 *  1. Không còn đọc/ghi lại TOÀN BỘ ticketLog cho mỗi ticket. OPStore chỉ ghi
 *     chunk mới nhất → chi phí hằng số thay vì tăng theo lịch sử.
 *  2. Không còn chờ Google Sheet. Record vào hàng đợi bền rồi trả về ngay,
 *     Side Panel mở nhóm kế tiếp trong cùng nhịp.
 *  3. Dedupe Order ID bằng Set trong RAM (O(1)) thay vì quét mảng log.
 * -------------------------------------------------------------------------- */
async function recordTicketFromTab(tabId, ticketIdValue, reportedOrderIdValue = '', submission = null) {
  return withTicketStateLock(async () => {
    const ticketId = String(ticketIdValue || '').trim();
    if (!ticketId && !submission?.submissionId) return { ok: false, error: 'Ticket ID trống.' };

    await OPStore.init();
    const data = await chrome.storage.local.get([
      'ticketTabPayloads',
      'ticketBatchEvidence',
      'ticketOpenGroups',
      'currentDraft',
      'currentAttachments',
      'activeChannelBatchKey',
      'handoverTicketHistory',
      'handoverRun',
      'ticketTabReceipts',
      'ticketSyncOutbox'
    ]);

    const tabPayloads = data.ticketTabPayloads && typeof data.ticketTabPayloads === 'object'
      ? { ...data.ticketTabPayloads }
      : {};
    let payload = tabPayloads[String(tabId)];
    const previousReceipt = data.ticketTabReceipts?.[String(tabId)];
    if (!payload?.draft && previousReceipt?.pendingDraft) {
      if (reportedOrderIdValue && normalizeTicketOrderId(reportedOrderIdValue) !== previousReceipt.orderId) return { ok: false, error: 'Mã đơn không khớp lần gửi đã lưu.' };
      if (!ticketId) return { ok: true, autoMapped: true, ...previousReceipt, alreadySaved: true };
      payload = { draft: previousReceipt.pendingDraft, groupKey: previousReceipt.groupKey, batchId: '', ticketCapture: previousReceipt.ticketCapture };
      submission = previousReceipt.submission || submission;
    } else if (!payload?.draft && previousReceipt) {
      if (previousReceipt.ticketId !== ticketId || reportedOrderIdValue && normalizeTicketOrderId(reportedOrderIdValue) !== previousReceipt.orderId) return { ok: false, error: 'Tab này đã lưu một phiếu khác.' };
      return { ok: true, autoMapped: true, ...previousReceipt, alreadySaved: true };
    }
    let currentDraftFallback = false;
    if (!payload?.draft && data.currentDraft) {
      currentDraftFallback = true;
      payload = {
        batchId: '',
        groupKey: data.currentDraft.groupKey || '',
        draft: data.currentDraft,
        attachments: Array.isArray(data.currentAttachments) ? data.currentAttachments : []
      };
    }
    if (!payload?.draft) {
      await chrome.storage.local.set({ detectedTicketId: ticketId });
      return { ok: true, autoMapped: false, ticketId };
    }

    const draft = payload.draft;
    const isHandover = draft.issueType === OPHandover.ISSUE;
    const isCancelReturn = draft.issueType === OPCancelReturn.ISSUE;
    if (!ticketId && (!isHandover || draft.platform !== 'shopee' || !payload.ticketCapture?.startedAt || !submission?.submissionId)) return { ok: false, error: 'Chưa có xác nhận gửi Shopee cho đơn này.' };
    const expectedOrderId = normalizeTicketOrderId(
      draft.representativeOrderId || draft.rows?.[0]?.orderId
    );
    const reportedOrderId = normalizeTicketOrderId(reportedOrderIdValue);
    if (reportedOrderId && expectedOrderId && reportedOrderId !== expectedOrderId) {
      return {
        ok: false,
        autoMapped: false,
        ticketId,
        error: `ID đơn hàng ${reportedOrderId} không khớp draft ${expectedOrderId}.`
      };
    }

    // KPI tickets are also recorded in Performance even when the order already
    // has an operational ticket in Ticket Master.
    if(ticketId && globalThis.OPPerformanceAppeals)await OPPerformanceAppeals.enqueue(draft,ticketId,new Date().toISOString(),String(submission?.url||''));
    // --- Dựng record ---------------------------------------------------------
    const now = new Date().toISOString();
    const newRecords = [];
    for (const row of draft.rows || []) {
      const orderId = String(row?.orderId || '').trim();
      if (!orderId || (!isHandover && OPStore.hasOrder(orderId))) continue;   // dedupe O(1)
      newRecords.push({
        ...(row?._original && typeof row._original === 'object' ? row._original : {}),
        TicketID: ticketId,
        TicketPlatform: String(draft.platform || 'tiktok').toUpperCase(),
        OrderID: orderId,
        TrackingID: row.trackingId || '',
        CNNC: deriveCnncFromRow(row),
        ChannelName: draft.channel || row.channel || '',
        DeliveryPlatform: draft.carrier || row.carrier || '',
        WarehouseBranch: row.warehouse || draft.warehouse || '',
        IssueType: draft.issueType || '',
        OrderStatus: row.status || '',
        OrderDate: row.orderDate || '',
        SLADate: row.slaAt || '',
        TicketCreatedAt: draft.createdAt || now,
        TicketRecordedAt: now,
        TicketStatus: ticketId ? 'Submitted' : 'SubmittedAwaitingID',
        SyncStatus: 'Pending',
        SyncedAt: '',
        SyncError: '',
        SourceFile: row.sourceFile || ''
      });
    }

    // --- Ghi cục bộ TRƯỚC (chỉ chunk nóng) -----------------------------------
    let mappedCount = 0;
    let handoverHistory;
    let handoverRun;
    let cancelReturnStorage = null;
    let cancelReturnNext = false;
    let cancelReturnReply = false, cancelReturnLane = false;
    if (isHandover) {
      handoverHistory = [...(data.handoverTicketHistory || [])];
      const already = handoverHistory.find(item => OPHandover.matches(item, expectedOrderId, draft));
      if (already?.TicketID && already.TicketID !== ticketId) return { ok: false, error: `Đơn đã có ticket kháng nghị ${already.TicketID}.` };
      if (!already || !already.TicketID && ticketId) {
        const fields = { ...OPHandover.recordFields(draft), HandoverAppealStatus: ticketId ? 'Submitted' : 'SubmittedAwaitingID', HandoverSubmissionRef: submission?.submissionId || already?.HandoverSubmissionRef || '' };
        if (already) handoverHistory = handoverHistory.filter(item => item !== already);
        const appeal = { ...newRecords[0], ...fields, HandoverAppealTicketID: ticketId, HandoverAppealRecordedAt: now };
        handoverHistory.unshift(appeal);
        const oldRecords = await OPStore.findByOrderIds([expectedOrderId]);
        const old = oldRecords[0];
        if (old?.TicketPlatform && String(old.TicketPlatform).toLowerCase() !== draft.platform) return { ok: false, error: 'Mã đơn đang thuộc sàn khác trong Ticket Master.' };
        const master = old
          ? { ...old, ...(!old.TicketID ? { TicketID: ticketId, TicketStatus: ticketId ? 'Submitted' : 'SubmittedAwaitingID' } : {}), ...fields, HandoverAppealTicketID: ticketId, HandoverAppealRecordedAt: now, SyncStatus: 'Pending', SyncedAt: '', SyncError: '' }
          : appeal;
        if (old) mappedCount = await OPStore.patchByOrderIds([expectedOrderId], master);
        else mappedCount = (await OPStore.prepend([master])).inserted;
        newRecords.splice(0, newRecords.length, master);
      } else newRecords.splice(0);
      const run = data.handoverRun;
      if (run?.sessionId === draft.handover?.sessionId) {
        handoverRun = { ...run, pending: (run.pending || []).filter(rowId => rowId !== draft.handover.rowId) };
        if (run.activeKey === draft.groupKey) { handoverRun.activeKey = ''; handoverRun.activeTabId = null; }
      }
    } else if (isCancelReturn) {
      // v2.2.20 — ticket đòi hàng gom nhiều đơn: ghi/patch từng đơn vào Ticket Master, giữ lịch sử theo ticket.
      const applied = await applyCancelReturnRecord(draft, ticketId, now, tabId);
      cancelReturnReply = applied.reply; cancelReturnLane = Boolean(applied.lane);
      if (applied.error) return { ok: false, error: applied.error };
      mappedCount = applied.mapped;
      newRecords.splice(0, newRecords.length, ...applied.records);
      cancelReturnStorage = applied.storage;
      cancelReturnNext = applied.scheduleNext;
    } else {
      mappedCount = (await OPStore.prepend(newRecords)).inserted;
    }

    if (!currentDraftFallback) delete tabPayloads[String(tabId)];
    const openGroups = data.ticketOpenGroups && typeof data.ticketOpenGroups === 'object'
      ? { ...data.ticketOpenGroups }
      : {};
    if (payload.groupKey) delete openGroups[payload.groupKey];

    const batchEvidence = data.ticketBatchEvidence && typeof data.ticketBatchEvidence === 'object'
      ? { ...data.ticketBatchEvidence }
      : {};
    const batchStillUsed = Object.values(tabPayloads).some((item) => item?.batchId === payload.batchId);
    if (!batchStillUsed && payload.batchId) delete batchEvidence[payload.batchId];

    const currentDraftGroupKey = String(data.currentDraft?.groupKey || '');
    const payloadGroupKey = String(payload.groupKey || draft.groupKey || '');
    const clearCurrentDraft = Boolean(
      data.currentDraft &&
      (
        (payloadGroupKey && currentDraftGroupKey === payloadGroupKey) ||
        (!payloadGroupKey && expectedOrderId && normalizeTicketOrderId(
          data.currentDraft.representativeOrderId || data.currentDraft.rows?.[0]?.orderId
        ) === expectedOrderId)
      )
    );
    const batchChannelKey = isHandover || isCancelReturn ? '' : String(draft.batchChannelKey || data.activeChannelBatchKey || '');

    const autoMapResult = {
      ticketId,
      orderId: reportedOrderId || expectedOrderId,
      groupKey: payloadGroupKey,
      batchChannelKey,
      mappedCount,
      syncOk: false,
      syncPending: true,
      syncError: '',
      capturedAt: now,
      ...(submission ? { submission } : {}),
      ...(!ticketId ? { pendingDraft: draft, ticketCapture: payload.ticketCapture, awaitingTicketId: true } : {})
    };

    const ticketTabReceipts = { ...(data.ticketTabReceipts || {}), [String(tabId)]: autoMapResult };
    const receiptKeys = Object.keys(ticketTabReceipts).sort((a, b) => String(ticketTabReceipts[a].capturedAt).localeCompare(String(ticketTabReceipts[b].capturedAt)));
    while (receiptKeys.length > 200) delete ticketTabReceipts[receiptKeys.shift()];
    const ticketSyncOutbox = { ...(data.ticketSyncOutbox || {}) };
    if (newRecords.length) ticketSyncOutbox[`${ticketId}|||${payloadGroupKey}`] = { rows: newRecords, meta: { ticketId, groupKey: payloadGroupKey } };
    const storageUpdate = {
      ticketTabReceipts,
      ticketSyncOutbox,
      ticketTabPayloads: tabPayloads,
      ticketBatchEvidence: batchEvidence,
      ticketOpenGroups: openGroups,
      detectedTicketId: ticketId,
      ticketAutoMapAt: now,
      ticketAutoMapResult: autoMapResult,
      ticketLogVersion: now
    };
    if (handoverHistory) storageUpdate.handoverTicketHistory = handoverHistory;
    if (handoverRun) storageUpdate.handoverRun = handoverRun;
    if (cancelReturnStorage) Object.assign(storageUpdate, cancelReturnStorage);
    if (clearCurrentDraft) {
      storageUpdate.currentDraft = null;
      storageUpdate.currentAttachments = [];
    }
    await chrome.storage.local.set(storageUpdate);
    // Wait only for durable local enqueueing; never wait for the Sheets network.
    await drainTicketSyncOutbox();
    if (handoverRun && !handoverRun.paused) chrome.alarms.create(HANDOVER_NEXT_ALARM, { when: Date.now() + 500 });
    if (cancelReturnNext) crSchedule(CANCEL_RETURN_NEXT_ALARM, 300);
    if (cancelReturnStorage) scheduleTrackerWrite();
    // Để tab tạo phiếu hiện xong "Đã tự lưu Ticket" rồi mới chuyển sang trang chi tiết phiếu đó.
    if (cancelReturnReply) crSchedule(CANCEL_RETURN_REPLY_ALARM, 300);
    if (cancelReturnLane) crSchedule(CANCEL_RETURN_FOLLOW_ALARM, 300);

    return {
      ok: true,
      autoMapped: true,
      ticketId,
      mappedCount,
      groupKey: payloadGroupKey,
      syncOk: false,
      syncPending: true
    };
  });
}

async function recordTicketByGroupKey(groupKeyValue, ticketIdValue) {
  const groupKey = String(groupKeyValue || '').trim();
  if (!groupKey) return { ok: false, error: 'Không xác định được nhóm ticket.' };

  const data = await chrome.storage.local.get([
    'ticketTabPayloads',
    'ticketOpenGroups'
  ]);
  const tabPayloads = data.ticketTabPayloads && typeof data.ticketTabPayloads === 'object'
    ? data.ticketTabPayloads
    : {};
  const openGroups = data.ticketOpenGroups && typeof data.ticketOpenGroups === 'object'
    ? data.ticketOpenGroups
    : {};
  const matchingEntry = Object.entries(tabPayloads).find(([, payload]) =>
    String(payload?.groupKey || '') === groupKey
  );
  const tabId = Number(openGroups[groupKey]?.tabId || matchingEntry?.[0] || 0);
  if (!tabId || !matchingEntry) {
    return {
      ok: false,
      error: 'Không còn dữ liệu của form này. Hãy mở lại form rồi nhập mã phiếu.'
    };
  }
  return recordTicketFromTab(tabId, ticketIdValue);
}

async function probePowerBiFrames(tabId) {
  const frames = await chrome.webNavigation.getAllFrames({ tabId });
  const results = [];

  for (const frame of frames || []) {
    try {
      const response = await chrome.tabs.sendMessage(
        tabId,
        { type: 'PROBE_PBI_AUTOMATION' },
        { frameId: frame.frameId }
      );
      if (response?.ok) {
        results.push({
          frameId: frame.frameId,
          score: Number(response.score || 0),
          url: frame.url
        });
      }
    } catch (_) {
      // Frames without the content script are expected.
    }
  }

  return results.sort((first, second) => second.score - first.score);
}

async function sendToPowerBiFrame(tabId, message) {
  let frames = await probePowerBiFrames(tabId);
  if (!frames.length || frames[0].score <= 0) {
    await chrome.scripting.executeScript({
      target: { tabId, allFrames: true },
      files: ['pbi.js']
    });
    frames = await probePowerBiFrames(tabId);
  }

  const target = frames.find((frame) => frame.score > 0);
  if (!target) {
    throw new Error(
      'Không tìm thấy đúng frame Power BI có Order Status và bảng Orders Detailed View. Hãy reload report rồi chạy lại.'
    );
  }

  return chrome.tabs.sendMessage(tabId, message, { frameId: target.frameId });
}

async function savePendingRun(run) {
  await chrome.storage.local.set({
    pendingTtsExport: {
      since: run.since,
      timestamp: run.timestamp,
      downloadId: run.downloadId || null,
      tabId: run.tabId || null,
      warehouses: sanitizeWarehouseSelection(run.warehouses),
      // v0.11.3 — NGUYÊN NHÂN GỐC của "Shopee gì cũng ra tên TikTok".
      // Trước đây platform KHÔNG được lưu ở đây. Export Power BI mất vài phút,
      // đủ lâu để Chrome tắt service worker MV3; khi nó thức dậy vì
      // downloads.onChanged thì activeRun đã mất, loadPendingRun() dựng lại từ
      // storage — và platform biến mất, rơi về mặc định TIKTOK trong im lặng.
      // Một lượt chạy Shopee hoàn toàn đúng vẫn bị gắn nhãn TIKTOK.
      platform: normalizePlatform(run.platform)
    }
  });
}

async function loadPendingRun() {
  if (activeRun) return activeRun;
  const { pendingTtsExport } = await chrome.storage.local.get('pendingTtsExport');
  if (!pendingTtsExport?.since) return null;
  return {
    since: Number(pendingTtsExport.since),
    timestamp: sanitizeStamp(pendingTtsExport.timestamp) || nowStamp(),
    downloadId: pendingTtsExport.downloadId || null,
    tabId: pendingTtsExport.tabId || null,
    warehouses: sanitizeWarehouseSelection(pendingTtsExport.warehouses),
    platform: normalizePlatform(pendingTtsExport.platform)
  };
}

function isExpectedDownload(item, run) {
  if (!item || !run) return false;
  const startedAt = Date.parse(item.startTime || '') || 0;
  if (startedAt < Number(run.since || 0) - 1500) return false;
  if (run.downloadId && item.id === run.downloadId) return true;
  return isPowerBiRawName(item.filename) || isRenamedRawPath(item.filename);
}

async function processDownloadedFile(item, run) {
  if (!item?.id) {
    return { ok: false, error: 'Chrome không trả về ID của file Power BI.' };
  }
  if (processedDownloadResults.has(item.id)) {
    return processedDownloadResults.get(item.id);
  }
  if (processingDownloadPromises.has(item.id)) {
    return processingDownloadPromises.get(item.id);
  }

  const task = (async () => {
    await publishProgress(
      'query',
      'Đã download Excel raw. Đang Query đúng 6 cột và split theo Delivery Platform + Channel Name + Warehouse Branch…',
      { downloadId: item.id }
    );

    try {
      const workbookBytes = await readDownloadedWorkbook(item.filename);
      await publishProgress(
        'query',
        'Đã nạp Excel raw. Đang split nhanh trong bộ nhớ…'
      );
      const queueRows = parseFastQueue(
        workbookBytes,
        leafName(item.filename),
        run?.platform || 'TIKTOK'
      );
      const rowCount = queueRows.length;
      const queueSummary = summarizeQueue(queueRows);
      const fileCount = queueSummary.groupCount;
      await chrome.storage.local.set({
        queueRows,
        queueSourceFileName: leafName(item.filename),
        queueRawCount: rowCount || queueRows.length,
        queueSelectedChannel: 'all',
        queueSavedAt: new Date().toISOString()
      });
      await chrome.storage.local.remove([
        'currentDraft',
        'currentAttachments',
        'detectedTicketId',
        'activeChannelBatchKey'
      ]);
      await clearBacklogTicketState();

      await publishProgress(
        'done',
        `ĐÃ XONG NHANH: ${rowCount.toLocaleString('en-US')} dòng · ${queueSummary.channelCount} Channel / ${queueSummary.groupCount} nhóm. File Raise 6 cột sẽ được tạo khi tải ZIP hoặc mở ticket.`,
        {
          outputPath: '',
          fileCount,
          rowCount,
          queueReady: true,
          queueRowCount: queueRows.length,
          channelCount: queueSummary.channelCount,
          groupCount: queueSummary.groupCount,
          filters: {
            platform: run?.platform || 'TIKTOK',
            warehouseFfm: sanitizeWarehouseSelection(run?.warehouses),
            orderStatus: [
              'dl_pending',
              'new',
              'pending_warehouse',
              'wh_completed',
              'wh_processing'
            ],
            slaDateFilter: 'year_to_date'
          }
        }
      );

      try {
        await chrome.notifications.create({
          type: 'basic',
          iconUrl: 'icons/icon128.png',
          title: 'TTS Pickup Backlog đã xong',
          message: `Đã nạp nhanh ${rowCount.toLocaleString('en-US')} dòng vào Ticket queue.`
        });
      } catch (_) {
        // Notification support is optional.
      }

      return {
        ok: true,
        outputPath: '',
        fileCount,
        rowCount,
        queueRowCount: queueRows.length,
        channelCount: queueSummary.channelCount,
        groupCount: queueSummary.groupCount
      };
    } catch (error) {
      const rawMessage = error?.message || String(error);
      const missingHost =
        /native messaging host|specified native messaging host|not found/i.test(rawMessage);
      const message = missingHost
        ? 'Chưa cài phần Download + Query. Hãy chạy Install.cmd rồi Reload extension. Nếu Windows chặn file, mở 00_START_HERE_IF_WINDOWS_BLOCKS.txt.'
        : rawMessage;
      await publishProgress('error', message);
      return { ok: false, error: message };
    }
  })();

  processingDownloadPromises.set(item.id, task);
  try {
    const result = await task;
    processedDownloadResults.set(item.id, result);
    return result;
  } finally {
    processingDownloadPromises.delete(item.id);
  }
}

/* -----------------------------------------------------------------------------
 * v0.11.18 — CHỜ FILE EXPORT: 60 GIÂY LÀ QUÁ NGẮN, VÀ IM LẶNG LÀ SAI.
 *
 * "Data with current layout" bắt Power BI dựng file Ở PHÍA MÁY CHỦ trước khi
 * trình duyệt bắt đầu tải. Với bộ lọc Year-to-date và bảng vài chục nghìn
 * dòng, riêng khâu dựng đã vài phút — Chrome chưa thấy download nào cả. Cắt ở
 * giây thứ 60 là bỏ cuộc giữa lúc Power BI vẫn đang làm việc bình thường.
 *
 * Ba thay đổi:
 *  1. Ngân sách 6 phút thay vì 1 phút.
 *  2. Cứ 5 giây báo về Side Panel một lần, kèm số giây đã trôi — để biết tool
 *     đang CHỜ chứ không phải đã treo.
 *  3. Khi Chrome đã bắt đầu tải (state = in_progress), KHÔNG tính hết giờ nữa:
 *     file đang về thì phải chờ cho xong, dù mất bao lâu.
 * -------------------------------------------------------------------------- */
async function waitForExportDownload(run, timeout = 360000) {
  const startedAt = Date.now();
  let deadline = startedAt + timeout;
  let lastNativeProbeAt = 0;
  let lastTickAt = 0;
  let sawDownloadStart = false;

  while (Date.now() < deadline) {
    const waitedSec = Math.round((Date.now() - startedAt) / 1000);
    if (Date.now() - lastTickAt >= 5000) {
      lastTickAt = Date.now();
      await publishProgress(
        'wait',
        sawDownloadStart
          ? `Chrome đang tải file Excel… (đã ${waitedSec}s)`
          : `Power BI đang dựng file Excel phía máy chủ… (đã ${waitedSec}s, bảng lớn có thể mất vài phút)`
      );
    }

    const downloads = await chrome.downloads.search({
      limit: 40,
      orderBy: ['-startTime']
    });
    const match = downloads.find((item) => isExpectedDownload(item, run));

    if (match) {
      if (run.downloadId !== match.id) {
        run.downloadId = match.id;
        if (activeRun) activeRun.downloadId = match.id;
        await savePendingRun(run);
      }

      if (match.state === 'complete') {
        const processed = await processDownloadedFile(match, run);
        return {
          ...processed,
          downloadId: match.id,
          filename: leafName(match.filename)
        };
      }

      // File đã bắt đầu về: gia hạn liên tục, tuyệt đối không bỏ cuộc giữa chừng.
      if (match.state === 'in_progress') {
        sawDownloadStart = true;
        deadline = Math.max(deadline, Date.now() + 120000);
      }
    }

    if (Date.now() - lastNativeProbeAt >= 1000) {
      lastNativeProbeAt = Date.now();
      try {
        const recent = await nativeMessage({
          action: 'findRecentRawFile',
          since: run.since
        });
        if (recent?.ok && recent?.found && recent.path) {
          await publishProgress(
            'query',
            `Đã nhận file Excel vừa Export: ${recent.fileName || leafName(recent.path)}. Đang nạp nhanh…`
          );
          const fallbackItem = {
            id: `native:${recent.path}`,
            filename: recent.path,
            state: 'complete'
          };
          const processed = await processDownloadedFile(fallbackItem, run);
          return {
            ...processed,
            downloadId: fallbackItem.id,
            filename: recent.fileName || leafName(recent.path),
            detectedBy: 'native-host'
          };
        }
      } catch (_) {
        // Chrome download tracking remains the primary path when helper is unavailable.
      }
    }

    await new Promise((resolve) => setTimeout(resolve, 350));
  }

  const waitedSec = Math.round((Date.now() - startedAt) / 1000);
  return {
    ok: false,
    error: sawDownloadStart
      ? `Chrome đã bắt đầu tải file nhưng sau ${waitedSec}s vẫn chưa xong. Kiểm tra mục Downloads của Chrome rồi bấm lại.`
      : `Đã click Export nhưng sau ${waitedSec}s Power BI vẫn chưa trả file nào. Bảng đang lọc có thể quá lớn — thu hẹp khoảng SLA Date hoặc bớt kho rồi chạy lại.`
  };
}

async function startAutomation(options = {}) {
  if (activeRun) {
    throw new Error('Tool đang chạy. Vui lòng chờ lần hiện tại hoàn tất.');
  }

  const warehouses = sanitizeWarehouseSelection(options?.warehouses);
  const platform = String(options?.platform || 'TIKTOK').toUpperCase() === 'SHOPEE'
    ? 'SHOPEE'
    : 'TIKTOK';
  if (!warehouses.length) {
    throw new Error('Hãy chọn ít nhất 1 Warehouse FFM: TNSL, TOLL hoặc MCL.');
  }

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const tabUrl = String(tab?.url || '');
  if (!tab?.id || !/^https:\/\/[^/]*powerbi\.com\//i.test(tabUrl)) {
    throw new Error('Hãy mở đúng report trên app.powerbi.com trước khi chạy.');
  }

  processedDownloadResults.clear();
  const run = {
    since: Date.now(),
    timestamp: nowStamp(),
    downloadId: null,
    tabId: tab.id,
    warehouses,
    platform
  };
  activeRun = run;
  await savePendingRun(run);
  await publishProgress(
    'start',
    `Đang kết nối Power BI · Warehouse FFM: ${warehouses.join(' + ')}…`,
    { warehouses }
  );

  try {
    const response = await sendToPowerBiFrame(tab.id, {
      type: 'RUN_PBI_AUTOMATION',
      config: { warehouses, platform }
    });
    if (!response?.ok) {
      throw new Error(response?.error || 'Không thao tác được trên report Power BI.');
    }

    await publishProgress(
      'wait',
      'Đã bấm Export → Data with current layout. Đang chờ file Excel tải xong…'
    );
    const download = await waitForExportDownload(run);
    if (!download?.ok) {
      throw new Error(download?.error || 'Không xử lý được file Power BI vừa tải.');
    }
    return { ok: true, ...download };
  } catch (error) {
    const message = error?.message || String(error);
    await publishProgress('error', message);
    return { ok: false, error: message };
  } finally {
    if (activeRun === run) activeRun = null;
    await chrome.storage.local.remove('pendingTtsExport');
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === 'PBI_TRUSTED_BROWSER_CLICK') {
    const tabId = Number(sender.tab?.id || 0);
    const sourceUrl = String(sender.url || sender.tab?.url || '');
    if (
      !tabId ||
      !/^https:\/\/[^/]*(?:powerbi\.com|analysis\.windows\.net)\//i.test(sourceUrl)
    ) {
      sendResponse({ ok: false, error: 'Yêu cầu thao tác không đến từ tab Power BI.' });
      return false;
    }
    queueTrustedBrowserClick(tabId, message)
      .then(sendResponse)
      .catch((error) =>
        sendResponse({ ok: false, error: error?.message || String(error) })
      );
    return true;
  }

  if (message?.type === 'GET_TICKET_TAB_PAYLOAD') {
    getTicketPayloadForTab(sender.tab?.id)
      .then(sendResponse)
      .catch((error) =>
        sendResponse({ ok: false, error: error?.message || String(error) })
      );
    return true;
  }

  if (message?.type === 'TICKET_CAPTURE_LIST_CLICK') {
    if (sender.id !== chrome.runtime.id || !sender.tab?.id) { sendResponse({ ok: false, error: 'Chỉ nhận từ tab ticket của tool.' }); return false; }
    clickForTicketCapture(sender.tab, message)
      .then(sendResponse).catch(error => sendResponse({ ok: false, error: error.message || String(error) }));
    return true;
  }

  if (message?.type === 'VERIFY_TIKTOK_ATTACHMENTS') {
    if (sender.id !== chrome.runtime.id || !sender.tab?.id || !/^https:\/\/seller-vn\.tiktok\.com\/ticket\/create/.test(sender.tab.url || '')) { sendResponse({ ok: false, error: 'Chỉ kiểm tra trên form tạo phiếu TikTok.' }); return false; }
    chrome.scripting.executeScript({ target: { tabId: sender.tab.id }, world: 'MAIN', func: OPTikTokAttachments.pageOperation, args: ['verify', { platform: 'tiktok' }] })
      .then(results => sendResponse(results?.[0]?.result || { ok: false, error: 'Trang chưa trả kết quả.' }))
      .catch(error => sendResponse({ ok: false, error: error.message || String(error) }));
    return true;
  }
  if (['UPLOAD_TIKTOK_ATTACHMENT_FILES', 'UPLOAD_SHOPEE_ATTACHMENT_FILES'].includes(message?.type)) {
    if (sender.id !== chrome.runtime.id || !sender.tab?.id) { sendResponse({ ok: false, error: 'Upload phải đến từ tab ticket của tool.' }); return false; }
    queueTikTokAttachmentUpload(sender.tab.id, message.indices)
      .then(sendResponse).catch(error => sendResponse({ ok: false, error: error.message || String(error) }));
    return true;
  }

  if (message?.type === 'CHECK_HANDOVER_SHOP') {
    (async () => {
      const context = await getTicketPayloadForTab(sender.tab?.id);
      if (!context.tabScoped || context.draft?.issueType !== OPHandover.ISSUE) return { ok: false, error: 'Tab không có đơn kháng nghị riêng.' };
      const { handoverRun: run } = await chrome.storage.local.get('handoverRun');
      const shop = await getLoggedInMarketplaceShop(context.draft.platform, run?.shopTabId);
      if (!shop.ok || shop.name !== context.draft.channel) return { ok: false, error: shop.error || `Shop đang đăng nhập là ${shop.name}; đơn thuộc ${context.draft.channel}. Mở đúng shop rồi thử lại.` };
      return { ok: true, name: shop.name };
    })().then(sendResponse).catch(error => sendResponse({ ok: false, error: error.message || String(error) }));
    return true;
  }

  if (message?.type === 'TICKET_SUBMIT_STARTED') {
    updateTicketCaptureState(sender.tab?.id, message.capture)
      .then(sendResponse).catch(error => sendResponse({ ok: false, error: error.message || String(error) }));
    return true;
  }

  if (message?.type === 'TICKET_AUTOFILL_STATUS') {
    updateTicketAutofillState(sender.tab?.id, message.autofill)
      .then(sendResponse)
      .catch((error) =>
        sendResponse({ ok: false, error: error?.message || String(error) })
      );
    return true;
  }

  if (message?.type === 'SHOPEE_SUBMISSION_CONFIRMED') {
    if (sender.id !== chrome.runtime.id || !/^https:\/\/help\.shopee\.vn\/portal\//.test(sender.tab?.url || '') || !message.submission?.submissionId) { sendResponse({ ok: false, error: 'Không có xác nhận Shopee hợp lệ.' }); return false; }
    recordTicketFromTab(sender.tab.id, message.submission.ticketId || '', message.orderId, message.submission)
      .then(sendResponse).catch(error => sendResponse({ ok: false, error: error.message || String(error) }));
    return true;
  }

  if (message?.type === 'TICKET_ID_DETECTED_FROM_TAB') {
    recordTicketFromTab(sender.tab?.id, message.ticketId, message.orderId)
      .then(sendResponse)
      .catch((error) =>
        sendResponse({ ok: false, error: error?.message || String(error) })
      );
    return true;
  }

  if (message?.type === 'MAP_TICKET_GROUP_MANUALLY') {
    recordTicketByGroupKey(message.groupKey, message.ticketId)
      .then(sendResponse)
      .catch((error) =>
        sendResponse({ ok: false, error: error?.message || String(error) })
      );
    return true;
  }

  if (message?.type === 'START_PBI_AUTOMATION') {
    startAutomation(message.options || {})
      .then(sendResponse)
      .catch((error) =>
        sendResponse({ ok: false, error: error?.message || String(error) })
      );
    return true;
  }

  if (message?.type === 'PBI_SET_TIMESTAMP') {
    const timestamp = sanitizeStamp(message.timestamp);
    if (
      timestamp &&
      activeRun &&
      (!sender.tab?.id || sender.tab.id === activeRun.tabId)
    ) {
      activeRun.timestamp = timestamp;
      savePendingRun(activeRun).catch(() => {});
    }
    sendResponse({ ok: true });
    return false;
  }

  if (message?.type === 'OPEN_TTS_OUTPUT') {
    nativeMessage({ action: 'openOutput' })
      .then((response) => sendResponse(response || { ok: false }))
      .catch((error) =>
        sendResponse({ ok: false, error: error?.message || String(error) })
      );
    return true;
  }

  /* --------------------------------------------------------- v0.11 API --- */

  // Trạng thái hàng đợi đồng bộ cho HUD của Side Panel.
  if (message?.type === 'OP_SYNC_STATUS') {
    OPSync.status()
      .then((state) => sendResponse({ ok: true, ...state }))
      .catch((error) => sendResponse({ ok: false, error: error?.message || String(error) }));
    return true;
  }

  // Nút "Sync pending" — đẩy lại mọi record chưa Synced.
  if (message?.type === 'OP_SYNC_RETRY') {
    retryPendingSync()
      .then(sendResponse)
      .catch((error) => sendResponse({ ok: false, error: error?.message || String(error) }));
    return true;
  }

  // Đọc Ticket Master từ store phân mảnh (mặc định chỉ trang đầu).
  if (message?.type === 'OP_READ_LOG') {
    const all = Boolean(message.all);
    (all ? OPStore.readAll() : OPStore.readRecent(Number(message.limit) || 200))
      .then((records) => OPStore.init().then(() => sendResponse({
        ok: true,
        records,
        total: OPStore.total(),
        orderIds: all ? undefined : [...OPStore.orderSet()]
      })))
      .catch((error) => sendResponse({ ok: false, error: error?.message || String(error) }));
    return true;
  }

  // Tập Order ID đã raise — Side Panel dùng để tô màu card mà không cần cả log.
  if (message?.type === 'OP_READ_ORDER_INDEX') {
    OPStore.init()
      .then(() => sendResponse({ ok: true, orderIds: [...OPStore.orderSet()], total: OPStore.total() }))
      .catch((error) => sendResponse({ ok: false, error: error?.message || String(error) }));
    return true;
  }

  // Side panel tự map ticket (Shopee, hoặc nhập tay) → ghi qua store phân mảnh
  // rồi đưa vào hàng đợi đồng bộ, cùng một đường với đường tự động của TikTok.
  if (message?.type === 'OP_APPEND_RECORDS') {
    const records = Array.isArray(message.records) ? message.records : [];
    OPStore.prepend(records)
      .then(async (stored) => {
        await chrome.storage.local.set({ ticketLogVersion: new Date().toISOString() });
        if (records.length) {
          queueTicketSync(records, { reason: 'side-panel' })
            .catch((error) => console.warn('[OnPoint] queue sync failed', error));
        }
        sendResponse({ ok: true, ...stored });
      })
      .catch((error) => sendResponse({ ok: false, error: error?.message || String(error) }));
    return true;
  }


  // Gán lại / sửa ID phiếu cho các đơn ĐÃ nằm trong Ticket Master.
  // Khoá theo OrderID chứ không theo TicketID, vì chính TicketID là thứ đang
  // sai hoặc đang rỗng — card "ĐÃ RAISE" mà không hiện số ticket chính là ca này.
  if (message?.type === 'OP_REASSIGN_TICKET') {
    const ticketId = String(message.ticketId || '').trim();
    const orderIds = Array.isArray(message.orderIds) ? message.orderIds : [];
    if (!ticketId || !orderIds.length) {
      sendResponse({ ok: false, error: 'Thiếu ID phiếu hoặc danh sách Order ID.' });
      return false;
    }
    const now = new Date().toISOString();
    OPStore.patchByOrderIds(orderIds, {
      TicketID: ticketId,
      TicketRecordedAt: now,
      SyncStatus: 'Pending',
      SyncError: ''
    })
      .then(async (updated) => {
        await chrome.storage.local.set({ ticketLogVersion: now });
        const records = await OPStore.findByOrderIds(orderIds);
        if (records.length) {
          queueTicketSync(records, { reason: 'reassign' })
            .catch((error) => console.warn('[OnPoint] queue sync failed', error));
        }
        sendResponse({ ok: true, updated });
      })
      .catch((error) => sendResponse({ ok: false, error: error?.message || String(error) }));
    return true;
  }


  // Chẩn đoán kết nối Google Sheet: ping thật cái URL đang cấu hình rồi trả về
  // đúng HTTP status và đoạn body. Biến "Pending mãi" từ bí ẩn thành sự kiện.
  if (message?.type === 'OP_SYNC_DIAGNOSE') {
    (async () => {
      const data = await chrome.storage.local.get(['googleSyncUrl', 'syncBackend']);
      const url = String(data.googleSyncUrl || DEFAULT_GOOGLE_SYNC_URL).trim();
      const out = { url, backend: data.syncBackend || 'script', isDefaultUrl: url === DEFAULT_GOOGLE_SYNC_URL };
      const probe = async (label, init) => {
        const ctrl = new AbortController();
        const timer = setTimeout(() => ctrl.abort(), 25000);
        const started = Date.now();
        try {
          const res = await fetch(url, { ...init, redirect: 'follow', signal: ctrl.signal });
          const text = await res.text();
          out[label] = {
            status: res.status, ok: res.ok, ms: Date.now() - started,
            looksLikeJson: text.trim().startsWith('{'),
            looksLikeLogin: /accounts\.google\.com|Sign in|Đăng nhập/i.test(text.slice(0, 2000)),
            body: text.slice(0, 300)
          };
        } catch (error) {
          out[label] = { error: error?.name === 'AbortError' ? 'Quá 25s không phản hồi' : String(error?.message || error), ms: Date.now() - started };
        } finally { clearTimeout(timer); }
      };
      await probe('get', { method: 'GET' });
      await probe('post', {
        method: 'POST',
        headers: { 'Content-Type': 'text/plain;charset=utf-8' },
        body: JSON.stringify({ action: 'appendTicketMaster', protocol: 2, source: 'diagnostic', rows: [] })
      });
      sendResponse({ ok: true, ...out });
    })().catch((error) => sendResponse({ ok: false, error: error?.message || String(error) }));
    return true;
  }

  // Cấp quyền Google cho chế độ Sheets API (chỉ chạy khi user bấm nút).
  if (message?.type === 'OP_CONNECT_GOOGLE') {
    OPSync.getAuthToken(true)
      .then(() => {
        OPSync.resetSheetsCache();
        sendResponse({ ok: true });
      })
      .catch((error) => sendResponse({ ok: false, error: error?.message || String(error) }));
    return true;
  }

  return false;
});

chrome.downloads.onDeterminingFilename.addListener((downloadItem, suggest) => {
  const run = activeRun;
  const startedAt = Date.parse(downloadItem.startTime || '') || 0;
  const isCurrentExport =
    run &&
    startedAt >= run.since - 1500 &&
    isPowerBiRawName(downloadItem.filename);

  if (isCurrentExport) {
    run.downloadId = downloadItem.id;
    savePendingRun(run).catch(() => {});
    // Tên file mang đúng sàn của lượt chạy, và tách thư mục con theo sàn để
    // hai bên không nằm lẫn trong cùng một chỗ.
    const platform = normalizePlatform(run.platform);
    suggest({
      filename:
        `OnPoint_TTS_Pickup_Ticket/Raw/${platform === 'SHOPEE' ? 'Shopee' : 'TikTok'}/` +
        `${rawStemFor(platform)}_${sanitizeStamp(run.timestamp) || nowStamp()}.xlsx`,
      conflictAction: 'uniquify'
    });
    return;
  }

  suggest();
});

chrome.downloads.onChanged.addListener(async (delta) => {
  if (delta.state?.current !== 'complete') return;

  const run = await loadPendingRun();
  if (!run) return;
  const [item] = await chrome.downloads.search({ id: delta.id });
  if (!isExpectedDownload(item, run)) return;

  await processDownloadedFile(item, run);
});

chrome.tabs.onRemoved.addListener((tabId) => {
  cleanupTicketTabState(tabId).catch(() => {});
});

chrome.runtime.onInstalled.addListener(() => {
  initializeExtension().catch(console.error);
});

chrome.runtime.onStartup.addListener(() => {
  initializeExtension().catch(console.error);
});

initializeExtension().catch(console.error);
