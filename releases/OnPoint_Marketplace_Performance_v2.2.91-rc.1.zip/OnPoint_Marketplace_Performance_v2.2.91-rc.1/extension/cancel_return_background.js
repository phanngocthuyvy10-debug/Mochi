/* v2.2.20 — Khiếu nại đòi hàng (đơn hủy đã bàn giao ĐVVC).
   1) Hàng đợi tuần tự: mỗi nhóm Channel + ĐVVC một ticket, chỉ sang nhóm kế khi đã lưu Ticket ID.
   2) Theo dõi phiếu: mở đúng /ticket/detail/<id>, đọc trạng thái, phản hồi để TikTok mở lại phiếu đã tự đóng.
   v2.2.67 — channel Shopee: cùng hàng đợi, mở webform Shopee (Câu hỏi chung/ Vấn đề khác), tự Gửi, lưu mã phiếu; KHÔNG có bước
   phản hồi bổ sung / mở lại phiếu (Shopee theo dõi ở seller-service.cs.shopee.vn). */
const CANCEL_RETURN_NEXT_ALARM = 'op-cancel-return-next';
const CANCEL_RETURN_FOLLOW_ALARM = 'op-cancel-return-follow';
const CANCEL_RETURN_FOLLOW_TIMEOUT_MS = 90000;
const CANCEL_RETURN_TRACKER_ALARM = 'op-cancel-return-tracker';
const CANCEL_RETURN_REPLY_ALARM = 'op-cancel-return-reply';
const TIKTOK_TICKET_DETAIL_URL = id => `https://seller-vn.tiktok.com/ticket/detail/${encodeURIComponent(id)}?shop_region=VN`;
// v2.2.25 — Nhật ký phiếu → bấm thật Tất cả → tìm Số phiếu → Kiểm tra chi tiết → Gửi tin nhắn.
const TIKTOK_TICKET_LIST_URL = 'https://seller-vn.tiktok.com/ticket?shop_region=VN';
const CANCEL_RETURN_KEYS = ['cancelReturnGroups', 'cancelReturnSettings', 'cancelReturnShopMap', 'cancelReturnTickets', 'cancelReturnRun', 'cancelReturnFollowRun'];
const crPlatformOfChannel = (groups, channel) => Object.values(groups || {}).find(group => group.channel === channel)?.platform === 'shopee' ? 'shopee' : 'tiktok';
const crSellerLabel = platform => platform === 'shopee' ? 'Shopee' : 'TikTok';
// Tab form đang làm việc của từng sàn (TikTok: trang tạo phiếu; Shopee: webform).
const crFormUrl = platform => platform === 'shopee' ? OPCancelReturn.SHOPEE.url : 'https://seller-vn.tiktok.com/ticket/create?shop_region=VN';
const crSellerTab = (platform, url) => platform === 'shopee' ? /^https:\/\/help\.shopee\.vn\//.test(url || '') : /^https:\/\/seller-vn\.tiktok\.com\//.test(url || '');
/* v2.2.82 — FAST MODE (TikTok): làn 2 raise song song trên 1 tab phụ (run.laneB). Mỗi tab vẫn ~30 giây/đơn nhưng 2 tab cùng chạy
   → ~15 giây/đơn. Làn 2 dùng y nguyên form tự điền / đính kèm / Gửi / bắt Ticket ID của làn chính (theo từng tab).
   Làn 2 kẹt / lỗi form / tab bị đóng → tắt làn 2, đơn đó vẫn ở hàng đợi để làn chính raise (không bao giờ gửi trùng). */
const crKeyOf = id => OPCancelReturn.groupKey(id);
/* v2.2.87 — ĐO TỪNG BƯỚC: run.timings[groupKey] = mốc ms (open = mở form, prevSaved = lưu ID đơn trước cùng làn, các mốc từ trang,
   saved = lưu Ticket ID). Giữ 20 đơn gần nhất; panel tính trung bình từng bước + bước chậm nhất. */
function crTrimTimings(timings) {
  const entries = Object.entries(timings || {}).sort((a, b) => (b[1].open || 0) - (a[1].open || 0)).slice(0, 20);
  return Object.fromEntries(entries);
}
function crMarkOpen(run, key, lane) {
  run.timings = crTrimTimings({ ...(run.timings || {}), [key]: { open: Date.now(), lane, prevSaved: lane === 'B' ? run.lastSavedB || 0 : run.lastSavedA || 0 } });
}
async function recordCancelReturnStepTiming(tabId, marks) {
  return withTicketStateLock(async () => {
    const { cancelReturnRun: run, ticketTabPayloads: payloads = {} } = await chrome.storage.local.get(['cancelReturnRun', 'ticketTabPayloads']);
    const key = payloads[String(tabId)]?.groupKey;
    if (!run || run.doneAt || !key || !run.timings?.[key]) return { ok: false };
    const clean = Object.fromEntries(Object.entries(marks || {}).filter(([name, value]) => /^[a-z]{2,10}$/.test(name) && Number.isFinite(Number(value))).map(([name, value]) => [name, Number(value)]));
    run.timings = { ...run.timings, [key]: { ...run.timings[key], ...clean } };
    await chrome.storage.local.set({ cancelReturnRun: run });
    return { ok: true };
  });
}
chrome.runtime.onMessage.addListener((message, sender, respond) => {
  if (message?.type !== 'CR_STEP_TIMING') return;
  if (sender.id !== chrome.runtime.id || !/^https:\/\/seller-vn\.tiktok\.com\/ticket/.test(sender.tab?.url || '')) { respond({ ok: false }); return false; }
  recordCancelReturnStepTiming(sender.tab.id, message.marks).then(respond, () => respond({ ok: false }));
  return true;
});
function crNextPending(run, groups) {
  const busy = new Set([run?.activeKey, run?.laneB?.activeKey].filter(Boolean));
  return (run?.pending || []).find(id => groups[id] && !groups[id].ticketId && !busy.has(crKeyOf(id))) || '';
}

async function startCancelReturnRun(channel, groupIds, bindShop) {
  const platform = crPlatformOfChannel((await chrome.storage.local.get('cancelReturnGroups')).cancelReturnGroups, channel);
  const shop = await getLoggedInMarketplaceShop(platform, null, platform === 'shopee' ? { ensureOpen: true } : {});
  if (!shop.ok) throw new Error(shop.error);
  const result = await withTicketStateLock(async () => {
    const data = await chrome.storage.local.get([...CANCEL_RETURN_KEYS, 'handoverRun', 'ticketOpenGroups', 'ticketTabPayloads']);
    const groups = data.cancelReturnGroups || {};
    const shopMap = { ...(data.cancelReturnShopMap || {}) };
    // v2.2.63 — chỉ tính đã gắn khi channel đã có phiếu raise thành công (gắn nhầm lúc bấm Raise ở shop khác không khóa channel).
    const bound = shopMap[channel] && Object.values(groups).some(group => group.channel === channel && group.ticketId) ? shopMap[channel] : '';
    if (bound && bound !== shop.name) throw new Error(`Channel ${channel} đã gắn với shop "${bound}" nhưng đang đăng nhập "${shop.name}". Đổi đúng shop rồi chạy lại.`);
    if (!bound && !bindShop) throw new Error(`Channel ${channel} chưa gắn shop ${crSellerLabel(platform)}. Kiểm tra shop đang đăng nhập "${shop.name}" rồi bấm Gắn & Auto raise.`);
    shopMap[channel] = shop.name;
    const run = data.cancelReturnRun;
    // v2.2.44 — hàng đợi cũ đang tạm dừng (vd kẹt phản hồi phiếu shop khác) → gác lại, không chặn raise mới. Phiếu cũ vẫn ở thẻ Theo dõi.
    if (run && !run.doneAt && (run.activeKey || (run.awaitingReply && !run.paused) || (!run.paused && run.pending?.length))) throw new Error('Đang có hàng đợi đòi hàng chạy. Chờ xong hoặc bấm Dừng trước.');
    if (data.handoverRun?.activeKey) throw new Error('Đang có đơn kháng nghị bàn giao xử lý. Chờ lưu Ticket ID trước.');
    // v2.2.62 — dọn form "ma": ghi nhận form còn sót (tab đã đóng / không còn ở trang tạo phiếu / form đòi hàng của hàng đợi cũ) không được chặn raise.
    const openGroups = { ...(data.ticketOpenGroups || {}) };
    const payloads = { ...(data.ticketTabPayloads || {}) };
    for (const [key, open] of Object.entries(openGroups)) {
      const tab = await chrome.tabs.get(Number(open?.tabId)).catch(() => null);
      const live = tab && /^https:\/\/(?:seller-vn\.tiktok\.com\/ticket\/create|help\.shopee\.vn\/portal\/webform)/.test(tab.url || '');
      const staleCancelReturn = Boolean(open?.cancelReturnGroupId) && !(run && !run.doneAt && run.activeKey === key);
      if (!live || staleCancelReturn) { delete openGroups[key]; if (open?.tabId && !payloads[String(open.tabId)]?.ticketCapture?.startedAt) delete payloads[String(open.tabId)]; }
    }
    if (Object.keys(openGroups).length) throw new Error(`Đang có form ticket khác mở dở (${Object.values(openGroups).map(open => open.carrier || open.channel || 'ticket').join(', ')}) — hoàn tất hoặc đóng tab đó trước.`);
    data.ticketOpenGroups = openGroups;
    await chrome.storage.local.set({ ticketOpenGroups: openGroups, ticketTabPayloads: payloads });
    const settings = data.cancelReturnSettings || {};
    const chosen = (groupIds || []).map(id => groups[id]).filter(group => group && group.channel === channel && !group.ticketId);
    if (!chosen.length) throw new Error('Chưa chọn ĐVVC nào chưa raise trong channel này.');
    const errors = chosen.flatMap(group => OPCancelReturn.validate(group, { ...settings, deferFiles: group.platform !== 'shopee' && (group.rows || []).length === 1 && Boolean(group.rows[0].evidence?.length) }));
    if (errors.length) throw new Error(errors.join('\n'));
    // v2.2.61 — bấm Raise lại: tải lại biên bản từ đầu cho các đơn lần trước tải hỏng (bỏ dấu 'đã thử').
    for (const group of chosen) if (group.filesTried && !(group.files || []).some(file => file.kind === 'evidence')) { groups[group.id] = { ...group, filesTried: false, evidenceNote: '' }; }
    // v2.2.82 — fast mode chỉ cho TikTok, cần ≥2 đơn và tin bổ sung chạy làn phụ (không chờ phản hồi tuần tự).
    const fast = settings.fastMode === true && platform !== 'shopee' && chosen.length > 1 && settings.parallelReply !== false;
    const next = { id: `cancel_return_run_${Date.now()}`, channel, platform, shopName: shop.name, shopTabId: shop.tabId, pending: chosen.map(group => group.id), activeKey: '', activeTabId: null, paused: false, startedAt: new Date().toISOString(), error: '',
      ...(fast ? { laneB: { on: true, activeKey: '', groupId: '', tabId: null, openedAt: '' } } : {}) };
    await chrome.storage.local.set({ cancelReturnRun: next, cancelReturnShopMap: shopMap, cancelReturnGroups: groups });
    return { ok: true, count: chosen.length };
  });
  await advanceCancelReturnRun();
  return result;
}

/* v2.2.47 — tải biên bản NGAY TRƯỚC khi mở form của đơn đó (không tải trước hàng trăm file), tải sẵn đơn kế trong lúc raise. */
const CR_MIME = { pdf: 'application/pdf', jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', xls: 'application/vnd.ms-excel', csv: 'text/csv', mp4: 'video/mp4', mov: 'video/quicktime' };
function crDownloadUrl(link) {
  let url;
  try { url = new URL(link); } catch (_) { return ''; }
  if (url.protocol !== 'https:') return '';
  if (!/\.sharepoint\.com$/i.test(url.hostname)) return url.toString();
  const doc = url.searchParams.get('sourcedoc');
  if (doc) { const site = url.pathname.split('/_layouts/')[0]; return `${url.origin}${site}/_layouts/15/download.aspx?UniqueId=${encodeURIComponent(doc.replace(/[{}]/g, ''))}`; }
  if (/\/:[a-z]:\//i.test(url.pathname)) { url.searchParams.set('download', '1'); return url.toString(); }
  return url.toString();
}
function crBase64(bytes) {
  let out = '';
  for (let i = 0; i < bytes.length; i += 32768) out += String.fromCharCode.apply(null, bytes.subarray(i, i + 32768));
  return btoa(out);
}
async function crFetchEvidence(link, row, carrier, platform = 'tiktok') {
  const url = crDownloadUrl(link);
  if (!url) throw new Error('link không hợp lệ (cần https)');
  // v2.2.52 — link biên bản treo không được làm kẹt hàng đợi: tối đa 20 giây/link.
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 20000);
  let response, bytes;
  try {
    response = await fetch(url, { credentials: 'include', cache: 'no-store', signal: controller.signal });
    // v2.2.68 — trang xem ảnh (ibb.co, imgur…) → tải ảnh gốc trong og:image.
    if (response.ok && /^text\/html/i.test(response.headers.get('content-type') || '')) {
      const image = OPCancelReturn.ogImage(await response.text(), response.url || url);
      if (image) { response = await fetch(image, { cache: 'no-store', signal: controller.signal }); link = image; }
    }
    bytes = response.ok ? new Uint8Array(await response.arrayBuffer()) : null;
  } catch (error) { throw new Error(error?.name === 'AbortError' ? 'quá 20 giây không tải được' : (error.message || String(error))); }
  finally { clearTimeout(timer); }
  const type = (response.headers.get('content-type') || '').split(';')[0].trim().toLowerCase();
  if (!response.ok || type === 'text/html') throw new Error(`HTTP ${response.status}${type === 'text/html' ? ' (cần đăng nhập / link là thư mục)' : ''}`);
  const fromUrl = decodeURIComponent(new URL(link).pathname.split('/').pop() || '');
  let ext = (fromUrl.match(/\.([a-z0-9]{2,4})$/i)?.[1] || Object.keys(CR_MIME).find(key => CR_MIME[key] === type) || '').toLowerCase();
  if (ext === 'jpeg') ext = 'jpg';
  if (!CR_MIME[ext]) throw new Error(`định dạng TikTok không nhận (${type || fromUrl})`);
  // Shopee nhận file ≤10 MB (ảnh vẫn nén về <5 MB).
  const limit = /^(jpg|png)$/.test(ext) ? 5 : platform === 'shopee' ? 10 : /^(mp4|mov)$/.test(ext) ? 80 : 50;
  // v2.2.66 — ảnh > 5 MB: tự nén xuống dưới 5 MB thay vì bỏ qua đơn.
  if (bytes.length >= limit * 1024 * 1024 && limit === 5) {
    const small = await OPCancelReturn.shrinkImage(bytes, CR_MIME[ext]).catch(() => null);
    if (small) { bytes = small; ext = 'jpg'; }
  }
  if (!bytes.length || bytes.length >= limit * 1024 * 1024) throw new Error(`dung lượng phải dưới ${limit} MB${limit === 5 ? ' (đã thử nén ảnh nhưng không được)' : ''}`);
  const name = OPCancelReturn.safeFileName(`BienBan_${carrier}_${row.trackingId || row.orderId}${row.sequence ? `_STT${row.sequence}` : ''}.${ext}`);
  return { name, type: CR_MIME[ext], size: bytes.length, base64: crBase64(bytes), kind: 'evidence', source: link };
}
const crPreparing = new Map();
function ensureCancelReturnFiles(groupId) {
  if (!groupId) return Promise.resolve();
  if (crPreparing.has(groupId)) return crPreparing.get(groupId);
  const job = (async () => {
    const { cancelReturnGroups: groups = {} } = await chrome.storage.local.get('cancelReturnGroups');
    const group = groups[groupId];
    // Gộp nhiều đơn (file Excel) do Side Panel chuẩn bị; đã có biên bản / đã thử → bỏ qua.
    const shopee = group?.platform === 'shopee';
    // TikTok: chỉ phiếu 1 đơn (phiếu gộp do Side Panel chuẩn bị). v2.2.69 — Shopee: mọi ticket (Excel đã có, tải biên bản ở đây).
    if (!group || group.ticketId || (!shopee && (group.rows || []).length !== 1) || group.filesTried || (group.files || []).some(file => file.kind === 'evidence')) return;
    const room = OPCancelReturn.maxFiles(group) - (shopee ? (group.files || []).filter(file => file.kind !== 'evidence').length : 0);
    const pairs = [];
    for (const row of group.rows || []) for (const link of row.evidence || []) if (!pairs.some(item => item.link === link)) pairs.push({ link, row });
    const take = pairs.slice(0, Math.max(0, room));
    if (!take.length) { if (shopee && pairs.length) await withTicketStateLock(async () => { const { cancelReturnGroups: latest = {} } = await chrome.storage.local.get('cancelReturnGroups'); if (latest[groupId] && !latest[groupId].ticketId) { latest[groupId] = { ...latest[groupId], filesTried: true }; await chrome.storage.local.set({ cancelReturnGroups: latest }); } }); return; }
    const results = await Promise.all(take.map(({ link, row }) => crFetchEvidence(link, row, group.carrier, group.platform).then(file => ({ file }), error => ({ error: `Không tải được biên bản (${error.message}): ${link}` }))));
    await withTicketStateLock(async () => {
      const { cancelReturnGroups: latest = {} } = await chrome.storage.local.get('cancelReturnGroups');
      const current = latest[groupId];
      if (!current || current.ticketId) return;
      const own = (current.files || []).filter(file => file.kind !== 'evidence' && (shopee || file.kind !== 'excel'));
      const names = new Set(own.map(file => file.name.toLowerCase()));
      const evidence = results.map(item => item.file).filter(file => file && !names.has(file.name.toLowerCase()) && names.add(file.name.toLowerCase()));
      const more = pairs.length - take.length;
      latest[groupId] = { ...current, files: [...own, ...evidence].slice(0, OPCancelReturn.maxFiles(current)), evidenceNote: [...results.filter(item => item.error).map(item => item.error), more > 0 ? `${more} link biên bản còn lại nằm trong Excel (đủ ${OPCancelReturn.maxFiles(current)} file)` : ''].filter(Boolean).join(' · '), filesTried: true };
      await chrome.storage.local.set({ cancelReturnGroups: latest });
    });
  })().finally(() => crPreparing.delete(groupId));
  crPreparing.set(groupId, job);
  return job;
}

async function advanceCancelReturnRun() {
  const { cancelReturnRun: peek, cancelReturnGroups: peekGroups = {} } = await chrome.storage.local.get(['cancelReturnRun', 'cancelReturnGroups']);
  // Tối đa 45 giây chuẩn bị biên bản rồi đi tiếp (đơn thiếu biên bản sẽ được bỏ qua, ghi lý do) — không bao giờ treo hàng đợi.
  if (peek && !peek.paused && !peek.activeKey && !peek.doneAt && !peek.awaitingReply) await Promise.race([ensureCancelReturnFiles(crNextPending(peek, peekGroups)).catch(() => {}), new Promise(resolve => setTimeout(resolve, 45000))]);
  // v2.2.60 — đọc tên shop NGOÀI khóa (tối đa 10 giây) để không chặn bước lưu Ticket ID đang chờ khóa.
  const { cancelReturnRun: ready } = await chrome.storage.local.get('cancelReturnRun');
  const shopNow = ready && !ready.paused && !ready.activeKey && !ready.doneAt && !ready.awaitingReply && ready.pending?.length ? await getLoggedInMarketplaceShop(ready.platform || 'tiktok', ready.shopTabId) : null;
  const result = await advanceCancelReturnRunLocked(shopNow);
  // Tải sẵn biên bản đơn kế trong lúc đơn này đang raise.
  const { cancelReturnRun: after, cancelReturnGroups: afterGroups = {} } = await chrome.storage.local.get(['cancelReturnRun', 'cancelReturnGroups']);
  const upcoming = crNextPending(after, afterGroups);
  if (after?.activeKey && upcoming) ensureCancelReturnFiles(upcoming).catch(() => {});
  // v2.2.82 — fast mode: làn 2 nhận đơn kế ngay sau làn chính.
  if (after?.laneB?.on) await advanceCancelReturnLaneB(shopNow).catch(console.error);
  return result;
}

/** v2.2.82 — làn 2 (fast mode): mở đơn kế chưa có làn nào nhận trên tab phụ riêng, dùng lại tab đó cho mọi đơn. */
async function advanceCancelReturnLaneB(shopKnown = null) {
  const { cancelReturnRun: peek, cancelReturnGroups: peekGroups = {} } = await chrome.storage.local.get(['cancelReturnRun', 'cancelReturnGroups']);
  if (!peek?.laneB?.on || peek.laneB.activeKey || peek.paused || peek.doneAt || peek.awaitingReply || peek.platform === 'shopee') return { ok: true };
  const candidate = crNextPending(peek, peekGroups);
  if (!candidate) return { ok: true, idle: true };
  await Promise.race([ensureCancelReturnFiles(candidate).catch(() => {}), new Promise(resolve => setTimeout(resolve, 45000))]);
  const shop = shopKnown?.ok ? shopKnown : await getLoggedInMarketplaceShop('tiktok', peek.shopTabId);
  return withTicketStateLock(async () => {
    const data = await chrome.storage.local.get([...CANCEL_RETURN_KEYS, 'ticketTabPayloads', 'ticketBatchEvidence', 'ticketOpenGroups']);
    const run = data.cancelReturnRun;
    if (!run?.laneB?.on || run.laneB.activeKey || run.paused || run.doneAt || run.awaitingReply) return { ok: true };
    const groups = data.cancelReturnGroups || {};
    const id = crNextPending(run, groups);
    if (!id) return { ok: true, idle: true };
    // Sai shop → làn 2 đứng yên; làn chính tự tạm dừng và báo khi tới lượt.
    if (!shop?.ok || shop.name !== run.shopName) return { ok: false, error: 'shop' };
    const group = groups[id];
    const settings = data.cancelReturnSettings || {};
    const errors = OPCancelReturn.validate(group, settings);
    if (errors.length) {
      run.skipped = [...(run.skipped || []), { groupId: id, orderId: group?.rows?.[0]?.orderId || '', error: errors.join(' ') }].slice(-200);
      run.pending = (run.pending || []).filter(item => item !== id);
      await chrome.storage.local.set({ cancelReturnRun: run });
      crSchedule(CANCEL_RETURN_NEXT_ALARM, 100);
      return { ok: false, skipped: true };
    }
    const draft = OPCancelReturn.draft(group, run.shopName, { ...settings, runId: run.id });
    let tab = run.laneB.tabId ? await chrome.tabs.get(Number(run.laneB.tabId)).catch(() => null) : null;
    const busyTabs = new Set(Object.values(data.ticketOpenGroups || {}).map(open => Number(open?.tabId)));
    if (!tab?.id || !crSellerTab('tiktok', tab.url) || busyTabs.has(Number(tab.id)) || Number(tab.id) === Number(run.activeTabId)) tab = await chrome.tabs.create({ url: 'about:blank', active: false });
    if (!tab?.id) return { ok: false, error: 'Chrome không tạo được tab làn 2.' };
    const ticketTabPayloads = { ...(data.ticketTabPayloads || {}), [String(tab.id)]: { batchId: run.id, groupKey: draft.groupKey, draft, orderEvidence: group.files || [], createdAt: draft.createdAt } };
    const ticketOpenGroups = { ...(data.ticketOpenGroups || {}), [draft.groupKey]: { batchId: run.id, tabId: tab.id, status: 'opening', channel: run.shopName, carrier: group.carrier, openedAt: draft.createdAt, cancelReturnGroupId: group.id, lane: 2 } };
    run.laneB = { ...run.laneB, activeKey: draft.groupKey, groupId: id, tabId: tab.id, openedAt: new Date().toISOString() };
    crMarkOpen(run, draft.groupKey, 'B');
    await chrome.storage.local.set({ ticketTabPayloads, ticketBatchEvidence: { ...(data.ticketBatchEvidence || {}), [run.id]: data.ticketBatchEvidence?.[run.id] || [] }, ticketOpenGroups, cancelReturnRun: run });
    await chrome.tabs.update(tab.id, { url: crFormUrl('tiktok') });
    return { ok: true, tabId: tab.id };
  });
}
/** Làn 2 hỏng (kẹt / lỗi form / tab đóng): tắt làn 2, trả đơn về hàng đợi (nếu chưa bấm Gửi) để làn chính raise. */
async function disableCancelReturnLaneB(reason, { closeTab = true } = {}) {
  const tabId = await withTicketStateLock(async () => {
    const data = await chrome.storage.local.get(['cancelReturnRun', 'ticketOpenGroups', 'ticketTabPayloads']);
    const run = data.cancelReturnRun;
    if (!run?.laneB) return null;
    const lane = run.laneB;
    const update = {};
    if (lane.activeKey) {
      const payload = data.ticketTabPayloads?.[String(lane.tabId)];
      const sent = Boolean(payload?.ticketCapture?.startedAt);
      const open = { ...(data.ticketOpenGroups || {}) }; delete open[lane.activeKey]; update.ticketOpenGroups = open;
      if (!sent) { const payloads = { ...(data.ticketTabPayloads || {}) }; delete payloads[String(lane.tabId)]; update.ticketTabPayloads = payloads; }
      // Đã bấm Gửi mà chưa có Ticket ID → không để làn chính raise lại (tránh trùng phiếu): bỏ qua, nhắc Dò Ticket ID.
      if (sent) {
        run.pending = (run.pending || []).filter(id => id !== lane.groupId);
        run.skipped = [...(run.skipped || []), { groupId: lane.groupId, orderId: payload?.draft?.rows?.[0]?.orderId || '', error: `Làn 2 đã bấm Gửi nhưng chưa bắt được Ticket ID (${reason}) — dùng "Dò Ticket ID" trước khi raise lại.` }].slice(-200);
      }
    }
    run.laneB = { ...lane, on: false, activeKey: '', groupId: '', openedAt: '', stoppedReason: reason };
    update.cancelReturnRun = run;
    await chrome.storage.local.set(update);
    return closeTab ? lane.tabId : null;
  });
  if (tabId) await chrome.tabs.remove(Number(tabId)).catch(() => {});
  crSchedule(CANCEL_RETURN_NEXT_ALARM, 200);
}
async function advanceCancelReturnRunLocked(shopNow = null) {
  return withTicketStateLock(async () => {
    const data = await chrome.storage.local.get([...CANCEL_RETURN_KEYS, 'ticketTabPayloads', 'ticketBatchEvidence', 'ticketOpenGroups']);
    const run = data.cancelReturnRun;
    if (!run || run.paused || run.activeKey || run.doneAt || run.awaitingReply) return { ok: true };
    const groups = data.cancelReturnGroups || {};
    run.pending = (run.pending || []).filter(id => groups[id] && !groups[id].ticketId);
    if (!run.pending.length) {
      // v2.2.82 — làn 2 còn đang làm đơn cuối → chưa xong.
      if (run.laneB?.activeKey) { await chrome.storage.local.set({ cancelReturnRun: run }); return { ok: true, idle: true }; }
      run.doneAt = new Date().toISOString(); run.error = '';
      await chrome.storage.local.set({ cancelReturnRun: run });
      return { ok: true, done: true };
    }
    const nextId = crNextPending(run, groups);
    if (!nextId) { await chrome.storage.local.set({ cancelReturnRun: run }); return { ok: true, idle: true }; }   // đơn còn lại đang ở làn 2
    const platform = run.platform || 'tiktok';
    const shop = shopNow || await getLoggedInMarketplaceShop(platform, run.shopTabId);
    if (!shop.ok || shop.name !== run.shopName) {
      run.paused = true; run.error = shop.ok ? `Shop đang đăng nhập là ${shop.name}, hàng đợi thuộc ${run.shopName}. Mở đúng shop rồi bấm Tiếp tục.` : shop.error;
      await chrome.storage.local.set({ cancelReturnRun: run });
      return { ok: false, error: run.error };
    }
    run.shopTabId = shop.tabId;
    const group = groups[nextId];
    const settings = data.cancelReturnSettings || {};
    const errors = group ? OPCancelReturn.validate(group, settings) : ['Nhóm trong hàng đợi đã bị xóa. Tải lại tracker rồi chạy lại.'];
    if (errors.length) {
      // v2.2.52 — 1 đơn lỗi (thiếu biên bản, link hỏng…) không làm dừng cả hàng trăm đơn: bỏ qua đơn đó, ghi lý do, chạy đơn kế.
      run.skipped = [...(run.skipped || []), { groupId: nextId, orderId: group?.rows?.[0]?.orderId || '', error: errors.join(' ') }].slice(-200);
      run.pending = run.pending.filter(id => id !== nextId);
      await chrome.storage.local.set({ cancelReturnRun: run });
      crSchedule(CANCEL_RETURN_NEXT_ALARM, 100);
      return { ok: false, skipped: true, error: errors.join('\n') };
    }
    let tab, reused = false;
    const draft = OPCancelReturn.draft(group, run.shopName, { ...settings, runId: run.id });
    try {
      // v2.2.45 — dùng lại tab TikTok đang làm (tab phiếu vừa raise / tab shop đang mở), chỉ tải lại trang tạo phiếu, không mở tab mới.
      // Shopee: chỉ dùng lại tab webform vừa gửi (không dùng tab Kênh Người Bán — tool cần tab đó để đọc tên shop).
      // v2.2.82 — không lấy nhầm tab của làn 2.
      tab = await reusableTicketTab((platform === 'shopee' ? [run.workTabId] : [run.workTabId, run.shopTabId]).filter(id => Number(id) !== Number(run.laneB?.tabId)), data.ticketOpenGroups, platform);
      reused = Boolean(tab);
      if (!tab) tab = await chrome.tabs.create({ url: 'about:blank', active: false });
      if (!tab?.id) throw new Error('Chrome không tạo được tab ticket.');
      const ticketTabPayloads = { ...(data.ticketTabPayloads || {}), [String(tab.id)]: { batchId: run.id, groupKey: draft.groupKey, draft, orderEvidence: group.files || [], createdAt: draft.createdAt } };
      const ticketBatchEvidence = { ...(data.ticketBatchEvidence || {}), [run.id]: [] };
      const ticketOpenGroups = { ...(data.ticketOpenGroups || {}), [draft.groupKey]: { batchId: run.id, tabId: tab.id, status: 'opening', channel: run.shopName, carrier: group.carrier, openedAt: draft.createdAt, cancelReturnGroupId: group.id } };
      run.activeKey = draft.groupKey; run.activeTabId = tab.id; run.workTabId = tab.id; run.activeOpenedAt = new Date().toISOString(); run.error = '';
      crMarkOpen(run, draft.groupKey, 'A');
      await chrome.storage.local.set({ ticketTabPayloads, ticketBatchEvidence, ticketOpenGroups, cancelReturnRun: run });
      await chrome.tabs.update(tab.id, { url: crFormUrl(platform), ...(platform === 'shopee' ? { active: true } : {}) });
      return { ok: true, tabId: tab.id };
    } catch (error) {
      if (tab?.id && !reused) { try { await chrome.tabs.remove(tab.id); } catch (_) {} }
      const ticketTabPayloads = { ...(data.ticketTabPayloads || {}) };
      const ticketOpenGroups = { ...(data.ticketOpenGroups || {}) };
      if (tab?.id) delete ticketTabPayloads[String(tab.id)];
      delete ticketOpenGroups[draft.groupKey];
      run.activeKey = ''; run.activeTabId = null; run.paused = true; run.error = error.message || String(error);
      await chrome.storage.local.set({ cancelReturnRun: run, ticketTabPayloads, ticketOpenGroups });
      return { ok: false, error: run.error };
    }
  });
}

/** Tab còn mở, đúng sàn (TikTok seller-vn / Shopee help) và không đang giữ form ticket khác → dùng lại. */
async function reusableTicketTab(ids, openGroups = {}, platform = 'tiktok') {
  const busy = new Set(Object.values(openGroups || {}).map(group => Number(group?.tabId)));
  for (const id of ids) {
    if (!Number(id) || busy.has(Number(id))) continue;
    const tab = await chrome.tabs.get(Number(id)).catch(() => null);
    if (tab?.id && crSellerTab(platform, tab.url)) return tab;
  }
  return null;
}

/** v2.2.51 — DỪNG NGAY: bỏ phiếu đang kẹt khỏi hàng đợi (không chờ xong), dừng dò Ticket ID và làn phản hồi song song.
    Phiếu đang dở mà đã bấm Gửi vẫn giữ dữ liệu trên tab đó để kịp lưu Ticket ID nếu TikTok trả về. */
async function stopCancelReturnNow() {
  let note = '';
  const halt = []; // tab cần đưa ra khỏi form (chưa bấm Gửi) / tab phụ cần đóng
  await withTicketStateLock(async () => {
    const data = await chrome.storage.local.get(['cancelReturnRun', 'ticketOpenGroups', 'ticketTabPayloads', 'cancelReturnFollowRun', 'cancelReturnLookup']);
    const run = data.cancelReturnRun, follow = data.cancelReturnFollowRun, lookup = data.cancelReturnLookup;
    const now = new Date().toISOString(), update = {};
    if (run && !run.doneAt) {
      if (run.activeKey) {
        const key = String(run.activeTabId);
        const payload = data.ticketTabPayloads?.[key];
        const openGroups = { ...(data.ticketOpenGroups || {}) };
        delete openGroups[run.activeKey];
        update.ticketOpenGroups = openGroups;
        if (payload?.ticketCapture?.startedAt) note = run.platform === 'shopee' ? ' Phiếu đang dở có thể đã gửi lên Shopee — kiểm tra seller-service.cs.shopee.vn → Yêu cầu của tôi, rồi nhập tay mã phiếu trước khi raise lại.' : ' Phiếu đang dở có thể đã gửi lên TikTok — trước khi raise lại đơn đó, dùng Dò Ticket ID hoặc nhập tay Ticket ID.';
        else { const payloads = { ...(data.ticketTabPayloads || {}) }; delete payloads[key]; update.ticketTabPayloads = payloads; halt.push({ tabId: Number(run.activeTabId), close: false, platform: run.platform || 'tiktok' }); }
      }
      // v2.2.82 — làn 2 cũng dừng ngay như làn chính (giữ bật để Tiếp tục chạy lại 2 làn).
      let laneB = run.laneB;
      if (laneB?.activeKey) {
        const laneKey = String(laneB.tabId);
        const lanePayload = data.ticketTabPayloads?.[laneKey];
        const openGroups = { ...(update.ticketOpenGroups || data.ticketOpenGroups || {}) };
        delete openGroups[laneB.activeKey];
        update.ticketOpenGroups = openGroups;
        if (lanePayload?.ticketCapture?.startedAt) note += ' Làn 2 có thể đã gửi 1 phiếu — dùng Dò Ticket ID trước khi raise lại đơn đó.';
        else { const payloads = { ...(update.ticketTabPayloads || data.ticketTabPayloads || {}) }; delete payloads[laneKey]; update.ticketTabPayloads = payloads; halt.push({ tabId: Number(laneB.tabId), close: false, platform: 'tiktok' }); }
        laneB = { ...laneB, activeKey: '', groupId: '', openedAt: '' };
      }
      update.cancelReturnRun = { ...run, ...(laneB ? { laneB } : {}), paused: true, activeKey: '', activeTabId: null, awaitingReply: null, error: `Đã dừng ngay — bấm Tiếp tục để raise tiếp.${note}` };
    }
    if (lookup && !lookup.doneAt) update.cancelReturnLookup = { ...lookup, doneAt: now, stopped: true };
    if (follow && !follow.doneAt) {
      update.cancelReturnFollowRun = { ...follow, queue: [], active: null, doneAt: now, stopped: true };
      if (follow.active?.tabId && !follow.active.sendingAt) halt.push({ tabId: Number(follow.active.tabId), close: Boolean(follow.lane) });
    }
    if (lookup && !lookup.doneAt && lookup.tabId) halt.push({ tabId: Number(lookup.tabId), close: true });
    await chrome.storage.local.set(update);
  });
  // Dừng hẳn trên trang: tab đang điền form (chưa Gửi) chuyển về Nhật ký phiếu → script không điền/đính kèm/Gửi tiếp; tab phụ đóng.
  for (const item of halt) {
    if (!item.tabId) continue;
    if (item.close) await chrome.tabs.remove(item.tabId).catch(() => {});
    else await chrome.tabs.update(item.tabId, { url: item.platform === 'shopee' ? 'about:blank' : 'https://seller-vn.tiktok.com/ticket?shop_region=VN' }).catch(() => {});
  }
  return { ok: true, note, halted: halt.length };
}

async function pauseCancelReturnRun() {
  return withTicketStateLock(async () => {
    const { cancelReturnRun: run } = await chrome.storage.local.get('cancelReturnRun');
    if (run && !run.doneAt) { run.paused = true; await chrome.storage.local.set({ cancelReturnRun: run }); }
    return { ok: true };
  });
}

async function resumeCancelReturnRun() {
  // v2.2.47 — chỉ thiếu file trên form đang mở: nhờ trang đẩy lại đúng file thiếu rồi tự gửi tiếp — không tải lại cả form.
  // Trang không trả lời (đã tải lại / tab cũ) → làm như cũ: tải lại form với file đã lưu.
  const peek = await chrome.storage.local.get(['cancelReturnRun', 'ticketOpenGroups', 'ticketTabPayloads']);
  const peekRun = peek.cancelReturnRun, peekOpen = peekRun?.activeKey ? peek.ticketOpenGroups?.[peekRun.activeKey] : null;
  if (peekRun && !peekRun.doneAt && peekOpen?.autofill?.reason === 'attachments-not-ready' && !peek.ticketTabPayloads?.[String(peekRun.activeTabId)]?.ticketCapture?.startedAt) {
    const pushed = await Promise.resolve(chrome.tabs.sendMessage?.(Number(peekRun.activeTabId), { type: 'OP_RETRY_ATTACH_ONLY' })).catch(() => null);
    if (pushed?.ok) {
      await withTicketStateLock(async () => {
        const data = await chrome.storage.local.get(['cancelReturnRun', 'ticketOpenGroups']);
        const run = data.cancelReturnRun, open = data.ticketOpenGroups?.[run?.activeKey];
        if (!run || !open) return;
        await chrome.storage.local.set({ ticketOpenGroups: { ...data.ticketOpenGroups, [run.activeKey]: { ...open, status: 'opened', autofill: {} } }, cancelReturnRun: { ...run, paused: false, error: '' } });
      });
      return { ok: true, retryingUpload: true, attachOnly: true };
    }
  }
  let retryingCapture = false;
  const retryTabId = await withTicketStateLock(async () => {
    const data = await chrome.storage.local.get(['cancelReturnRun', 'ticketOpenGroups', 'ticketTabPayloads', 'cancelReturnGroups']);
    const run = data.cancelReturnRun;
    if (!run || run.doneAt) throw new Error('Không có hàng đợi đòi hàng đang tạm dừng.');
    let tabId = null;
    // v2.2.23 — form tự điền lỗi (thiếu file, chưa chọn được chủ đề, sai shop…) → tải lại form với file đã lưu.
    if (run.activeKey && cancelReturnFormFailed(data.ticketOpenGroups?.[run.activeKey])) {
      const key = String(run.activeTabId);
      const payload = data.ticketTabPayloads?.[key];
      if (payload?.ticketCapture?.startedAt) {
        if (data.ticketOpenGroups[run.activeKey].autofill?.reason !== 'ticket-list-not-ready') throw new Error('Ticket đã bắt đầu gửi; đang chờ Ticket ID, không gửi lại.');
        retryingCapture = true;
        await chrome.storage.local.set({ ticketOpenGroups: { ...data.ticketOpenGroups, [run.activeKey]: { ...data.ticketOpenGroups[run.activeKey], status: 'saving-ticket', autofill: {} } }, cancelReturnRun: { ...run, paused: false, error: '' } });
        return run.activeTabId;
      }
      tabId = run.activeTabId;
      const update = { ticketOpenGroups: { ...data.ticketOpenGroups, [run.activeKey]: { ...data.ticketOpenGroups[run.activeKey], status: 'opened', autofill: {} } } };
      // Đổi tên file có ký tự đặc biệt (vd "J&T") sang tên an toàn cho lượt đính kèm lại.
      const rename = list => (list || []).map(file => ({ ...file, name: OPCancelReturn.safeFileName(file.name) }));
      if (payload) {
        const draft = { ...payload.draft, cancelReturn: { ...payload.draft.cancelReturn, files: rename((payload.orderEvidence || [])).map(file => file.name) } };
        update.ticketTabPayloads = { ...data.ticketTabPayloads, [key]: { ...payload, draft, orderEvidence: rename(payload.orderEvidence), autofill: {} } };
      }
      const groupId = payload?.draft?.cancelReturn?.groupId;
      if (groupId && data.cancelReturnGroups?.[groupId]) update.cancelReturnGroups = { ...data.cancelReturnGroups, [groupId]: { ...data.cancelReturnGroups[groupId], files: rename(data.cancelReturnGroups[groupId].files) } };
      await chrome.storage.local.set(update);
    }
    run.paused = false; run.error = '';
    await chrome.storage.local.set({ cancelReturnRun: run });
    return tabId;
  });
  if (retryTabId != null) { await chrome.tabs.reload(retryTabId); return { ok: true, ...(retryingCapture ? { retryingCapture: true } : { retryingUpload: true }) }; }
  const { cancelReturnRun: current } = await chrome.storage.local.get('cancelReturnRun');
  if (current?.awaitingReply) return startPostRaiseReply();
  return advanceCancelReturnRun();
}

/** v2.2.40 — bỏ qua bước phản hồi lại phiếu vừa raise (đang kẹt) rồi raise đơn kế. */
async function skipCancelReturnReply() {
  await withTicketStateLock(async () => {
    const { cancelReturnRun: run, cancelReturnFollowRun: follow } = await chrome.storage.local.get(['cancelReturnRun', 'cancelReturnFollowRun']);
    if (!run?.awaitingReply || run.doneAt) throw new Error('Không có phiếu nào đang chờ phản hồi.');
    const update = { cancelReturnRun: { ...run, awaitingReply: null, paused: false, error: '', lastReplyError: '' } };
    if (follow?.raiseRunId === run.id && !follow.doneAt) update.cancelReturnFollowRun = { ...follow, active: null, queue: [], doneAt: new Date().toISOString() };
    await chrome.storage.local.set(update);
  });
  return advanceCancelReturnRun();
}

/** Form tạo phiếu đã tự điền xong nhưng không tự gửi (lý do nằm ở autofill.reason / autofill.ok === false). */
const cancelReturnFormFailed = open => Boolean(open?.autofill && open.autofill.ok === false && (open.autofill.reason || open.autofill.details));

async function cancelReturnTabClosed(tabId) {
  // v2.2.82 — đóng tab làn 2 → tắt làn 2 (đơn đang dở chưa Gửi trả về hàng đợi cho làn chính).
  const { cancelReturnRun: peek } = await chrome.storage.local.get('cancelReturnRun');
  if (peek?.laneB?.on && Number(peek.laneB.tabId) === Number(tabId) && !peek.doneAt) await disableCancelReturnLaneB('tab làn 2 đã đóng', { closeTab: false });
  return withTicketStateLock(async () => {
    const { cancelReturnRun: run } = await chrome.storage.local.get('cancelReturnRun');
    if (!run?.activeKey || Number(run.activeTabId) !== Number(tabId)) return;
    run.activeKey = ''; run.activeTabId = null; run.paused = true;
    run.error = 'Tab ticket đã đóng trước khi lưu Ticket ID. Nếu đã gửi, nhập Ticket ID ở nhóm đó; nếu chưa, bấm Tiếp tục.';
    await chrome.storage.local.set({ cancelReturnRun: run });
  });
}

async function recoverCancelReturnRun() {
  // v2.2.90 — 1 lần: ghi lại tracker cho các phiếu RAISE LẠI trước bản này (trước đây bị bỏ qua vì dòng đơn còn Ticket ID cũ).
  try {
    const { crTrackerReraiseFix90: fixed, cancelReturnTickets: all = {}, cancelReturnTrackerOutbox: box } = await chrome.storage.local.get(['crTrackerReraiseFix90', 'cancelReturnTickets', 'cancelReturnTrackerOutbox']);
    if (!fixed) {
      let next = box;
      const ids = Object.values(all).filter(ticket => ticket.reraiseOf && ticket.platform !== 'shopee' && ticket.kind !== 'general').map(ticket => String(ticket.TicketID));
      for (const id of ids) next = queueTrackerWrite(next, id);
      await chrome.storage.local.set({ crTrackerReraiseFix90: new Date().toISOString(), ...(ids.length ? { cancelReturnTrackerOutbox: next } : {}) });
      if (ids.length) scheduleTrackerWrite(5000);
    }
  } catch (error) { console.warn('[OnPoint] reraise tracker fix', error); }
  // v2.2.64 — dọn 1 lần bản lưu base64 biên bản tích lũy từ các bản cũ (không còn dùng: tin bổ sung không đính kèm lại).
  // Chỉ giữ phiếu đang chờ phản hồi tuần tự (nếu có) để không đổi hành vi của lượt đang dở.
  const { cancelReturnReplyFiles: replyFiles } = await chrome.storage.local.get('cancelReturnReplyFiles');
  if (replyFiles && Object.keys(replyFiles).length) {
    const { cancelReturnRun: current, cancelReturnFollowRun: following } = await chrome.storage.local.get(['cancelReturnRun', 'cancelReturnFollowRun']);
    // v2.2.72 — giữ cả biên bản của phiếu re-raise "Cần hành động" đang mở dở.
    const keepIds = [current?.awaitingReply?.ticketId, following?.mode === 'evidence' && !following.doneAt ? following.active?.ticketId : ''].filter(id => id && replyFiles[id]);
    const keep = keepIds.length ? Object.fromEntries(keepIds.map(id => [id, replyFiles[id]])) : null;
    if (keep) await chrome.storage.local.set({ cancelReturnReplyFiles: keep }); else await chrome.storage.local.remove('cancelReturnReplyFiles');
  }
  const { cancelReturnRun: run, cancelReturnFollowRun: follow } = await chrome.storage.local.get(['cancelReturnRun', 'cancelReturnFollowRun']);
  if (run && !run.doneAt && run.laneB?.activeKey) {
    // v2.2.82 — service worker khởi động lại: tab làn 2 không còn ở trang phiếu → tắt làn 2 (đơn chưa Gửi về hàng đợi).
    const laneTab = await chrome.tabs.get(Number(run.laneB.tabId)).catch(() => null);
    if (!laneTab || !/^https:\/\/seller-vn\.tiktok\.com\/ticket/.test(laneTab.url || '')) await disableCancelReturnLaneB('tab làn 2 không còn ở trang phiếu', { closeTab: false });
  }
  if (run && !run.doneAt) {
    // v2.2.40 — kẹt do bản cũ (đã bấm Gửi nhưng chưa xác nhận) → tự chạy lại; bản mới kiểm tra luồng, không gửi trùng.
    if (run.paused && run.awaitingReply?.sendingAt && /chưa xác nhận tin nhắn|chưa thấy tin nhắn lên luồng/.test(run.error || '')) {
      run.paused = false; run.error = '';
      await chrome.storage.local.set({ cancelReturnRun: run });
    }
    if (run.awaitingReply && (!follow || (follow.doneAt && !follow.active))) crSchedule(CANCEL_RETURN_REPLY_ALARM, 300);
    else if (run.activeKey) {
      let tab;
      try { tab = await chrome.tabs.get(Number(run.activeTabId)); } catch (_) {}
      if (!tab || !/^(about:blank|https:\/\/seller-vn\.tiktok\.com\/ticket|https:\/\/help\.shopee\.vn\/portal)/.test(tab.url || '')) {
        await cleanupTicketTabState(run.activeTabId);
        await cancelReturnTabClosed(run.activeTabId);
      }
    } else if (!run.paused) crSchedule(CANCEL_RETURN_NEXT_ALARM, 300);
  }
  if (follow && !follow.doneAt) crSchedule(CANCEL_RETURN_FOLLOW_ALARM, 300);
  const { cancelReturnTrackerOutbox: outbox } = await chrome.storage.local.get('cancelReturnTrackerOutbox');
  if (Object.keys(outbox || {}).length) scheduleTrackerWrite(5000);
}

/** Gọi từ recordTicketFromTab (trong khóa) — ghi mọi đơn của ticket vào Ticket Master + lịch sử theo ticket. */
async function applyCancelReturnRecord(draft, ticketId, now, tabId = null) {
  const data = await chrome.storage.local.get(['cancelReturnTickets', 'cancelReturnGroups', 'cancelReturnRun', 'cancelReturnTrackerOutbox', 'cancelReturnSettings', 'cancelReturnFollowRun']);
  const tickets = { ...(data.cancelReturnTickets || {}) };
  const groupId = draft.cancelReturn?.groupId || '';
  const existingTicket = Object.values(tickets).find(item => item.groupId && item.groupId === groupId);
  if (existingTicket && existingTicket.TicketID !== ticketId) return { error: `Nhóm này đã có ticket đòi hàng ${existingTicket.TicketID}.` };
  const orderIds = (draft.rows || []).map(row => row.orderId).filter(Boolean);
  const old = await OPStore.findByOrderIds(orderIds);
  const oldIds = new Set(old.map(record => String(record.OrderID || record['Order ID'] || '').trim().toUpperCase()));
  let mapped = 0;
  const records = [];
  for (const row of draft.rows || []) {
    const fields = OPCancelReturn.recordFields(draft, ticketId, row, now);
    if (oldIds.has(row.orderId.toUpperCase())) {
      mapped += await OPStore.patchByOrderIds([row.orderId], record => ({ ...fields, SyncStatus: 'Pending', SyncedAt: '', SyncError: '', ...(!record.TicketID ? { TicketID: ticketId, TicketStatus: 'Submitted' } : {}) }));
      const [patched] = await OPStore.findByOrderIds([row.orderId]);
      if (patched) records.push(patched);
    } else {
      const record = {
        TicketID: ticketId, TicketPlatform: String(draft.platform || 'tiktok').toUpperCase(), OrderID: row.orderId, TrackingID: row.trackingId || '', CNNC: '',
        ChannelName: draft.trackerChannel || row.channel || '', DeliveryPlatform: draft.carrier || row.carrier || '', WarehouseBranch: row.warehouse || draft.warehouse || '',
        IssueType: OPCancelReturn.ISSUE, OrderStatus: 'cancelled', OrderDate: row.orderDate || '', SLADate: '',
        TicketCreatedAt: draft.createdAt || now, TicketRecordedAt: now, TicketStatus: 'Submitted', SyncStatus: 'Pending', SyncedAt: '', SyncError: '',
        SourceFile: row.sourceFile || '', ...fields
      };
      mapped += (await OPStore.prepend([record])).inserted;
      records.push(record);
    }
  }
  tickets[ticketId] = { ...(existingTicket || OPCancelReturn.ticketRecord(draft, ticketId, now)) };
  // v2.2.71 — phiếu raise lại: phiếu cũ chuyển sang "Đã raise lại → #mới", ngừng theo dõi phiếu cũ.
  const reraiseOf = draft.cancelReturn?.reraiseOf;
  let reraiseOutbox = null;
  if (reraiseOf && tickets[reraiseOf] && reraiseOf !== ticketId) { tickets[reraiseOf] = { ...tickets[reraiseOf], reraisedTo: ticketId, reraisedAt: now }; reraiseOutbox = reraiseOf; }
  const groups = { ...(data.cancelReturnGroups || {}) };
  // v2.2.64 — KHÔNG giữ base64 biên bản sau raise nữa: từ v2.2.42 tin bổ sung không đính kèm lại, mà làn song song không bao giờ
  // xóa bản lưu → cancelReturnReplyFiles phình hàng chục MB, mỗi lần raise đọc/ghi lại cả khối → càng raise càng chậm, có lúc đứng.
  if (groups[groupId]) groups[groupId] = { ...groups[groupId], ticketId, ticketRecordedAt: now, files: [] };
  const storage = { cancelReturnTickets: tickets, cancelReturnGroups: groups, cancelReturnTrackerOutbox: queueTrackerWrite(data.cancelReturnTrackerOutbox, ticketId) };
  if (reraiseOutbox) storage.cancelReturnTrackerOutbox = queueTrackerWrite(storage.cancelReturnTrackerOutbox, reraiseOutbox);
  const run = data.cancelReturnRun;
  let reply = false, lane = false;
  if (run && !run.doneAt && run.id === draft.cancelReturn?.runId) {
    storage.cancelReturnRun = { ...run, pending: (run.pending || []).filter(id => id !== groupId) };
    if (run.activeKey === draft.groupKey) { storage.cancelReturnRun.activeKey = ''; storage.cancelReturnRun.activeTabId = null; }
    // v2.2.82 — đơn của làn 2 (fast mode): nhả làn 2, đo thời gian theo giờ mở form của làn 2.
    const laneB = run.laneB?.activeKey === draft.groupKey;
    if (laneB) storage.cancelReturnRun.laneB = { ...run.laneB, activeKey: '', groupId: '', openedAt: '', done: (run.laneB.done || 0) + 1 };
    // Mốc lưu Ticket ID của từng đơn → panel tính tốc độ thật khi 2 làn chạy song song.
    storage.cancelReturnRun.recordTimes = [...(run.recordTimes || []), now].slice(-30);
    // v2.2.87 — mốc "lưu Ticket ID" cho bảng đo từng bước; mốc này thành "prevSaved" của đơn kế cùng làn.
    if (run.timings?.[draft.groupKey]) storage.cancelReturnRun.timings = { ...run.timings, [draft.groupKey]: { ...run.timings[draft.groupKey], saved: Date.parse(now) } };
    if (laneB) storage.cancelReturnRun.lastSavedB = Date.parse(now); else storage.cancelReturnRun.lastSavedA = Date.parse(now);
    // v2.2.50 — đo thời gian thật mỗi đơn (mở form → lưu Ticket ID) để panel hiện tốc độ & thời gian còn lại.
    const openedAt = Date.parse((laneB ? run.laneB.openedAt : run.activeKey === draft.groupKey ? run.activeOpenedAt : '') || '');
    if (openedAt) storage.cancelReturnRun.durations = [...(run.durations || []), Math.max(1, Math.round((Date.parse(now) - openedAt) / 1000))].slice(-40);
    storage.cancelReturnRun.raisedCount = (run.raisedCount || 0) + 1;
    storage.cancelReturnRun.lastStepAt = now;
    // v2.2.67 — Shopee không re-raise: lưu mã phiếu xong là raise ĐVVC kế.
    if (draft.platform !== 'shopee' && data.cancelReturnSettings?.replyAfterRaise !== false) {
      // v2.2.50 — phản hồi bổ sung chạy SONG SONG trên 1 tab phụ (dùng lại), tab chính raise đơn kế ngay.
      // Phần chờ TikTok dựng khung Gửi tin nhắn (~12 giây/phiếu) không còn chặn hàng đợi raise.
      const follow = data.cancelReturnFollowRun;
      const parallel = data.cancelReturnSettings?.parallelReply !== false;
      if (parallel && (!follow || (follow.doneAt && !follow.active) || (follow.lane && !follow.doneAt))) {
        storage.cancelReturnFollowRun = follow?.lane && !follow.doneAt
          ? { ...follow, queue: [...(follow.queue || []), ticketId] }
          : { id: `lane_${Date.now()}`, mode: 'post_raise', lane: true, raiseRunId: run.id, customText: '', queue: [ticketId], active: null, results: [], startedAt: now, doneAt: '', replyTabId: follow?.lane ? follow.replyTabId || null : null };
        lane = true;
      } else { storage.cancelReturnRun.awaitingReply = { ticketId, tabId: Number(tabId) > 0 ? Number(tabId) : null, at: now, attach: 0, sendingAt: '' }; reply = true; }
    }
  }
  return { mapped, records, storage, reply, lane, scheduleNext: Boolean(storage.cancelReturnRun && !storage.cancelReturnRun.paused && !reply) };
}

/** Mở đúng phiếu vừa raise (tái dùng tab tạo phiếu) để điền lại nội dung + đính kèm lại file rồi Gửi. */
async function startPostRaiseReply() {
  return withTicketStateLock(async () => {
    const data = await chrome.storage.local.get(['cancelReturnRun', 'cancelReturnFollowRun', 'cancelReturnTickets', 'cancelReturnReplyFiles']);
    const run = data.cancelReturnRun;
    const pending = run?.awaitingReply;
    if (!pending || run.doneAt || run.paused) return { ok: true };
    const busy = data.cancelReturnFollowRun;
    if (busy && (!busy.doneAt || busy.active)) { if (busy.raiseRunId === run.id && busy.active?.ticketId === pending.ticketId) return { ok: true }; crSchedule(CANCEL_RETURN_REPLY_ALARM, 300); return { ok: true, waiting: true }; }
    const ticket = data.cancelReturnTickets?.[pending.ticketId];
    if (!ticket) { run.paused = true; run.error = `Không còn dữ liệu phiếu #${pending.ticketId} để phản hồi — chưa mở ĐVVC kế.`; await chrome.storage.local.set({ cancelReturnRun: run }); return { ok: false, error: run.error }; }
    // Chạy ở tab trước mặt để thấy từng bước; dùng lại tab vừa tạo phiếu.
    let tab = null;
    if (pending.tabId) { try { tab = await chrome.tabs.get(pending.tabId); } catch (_) {} }
    if (!tab?.id) tab = await chrome.tabs.create({ url: 'about:blank', active: true });
    const files = data.cancelReturnReplyFiles?.[pending.ticketId] || [];
    // v2.2.42 — biên bản PDF đã nằm trong tin đầu của phiếu → tin bổ sung KHÔNG đính kèm lại, điền xong bấm Gửi ngay.
    const settingsNoReattach = true;
    const now = new Date().toISOString();
    const follow = { id: `follow_${Date.now()}`, mode: 'post_raise', raiseRunId: run.id, customText: '', queue: [], results: [], startedAt: now, doneAt: '',
      active: { ticketId: pending.ticketId, tabId: tab.id, listTabId: null, openedAt: now, text: String(ticket.replyText || ticket.text || '').slice(0, OPCancelReturn.MAX_TEXT), attach: settingsNoReattach ? 0 : pending.attach ?? files.length, sendingAt: pending.sendingAt || '' } };
    run.awaitingReply = { ...pending, tabId: tab.id, attach: follow.active.attach };
    // Lưu ngữ cảnh TRƯỚC khi điều hướng: content script ở trang Nhật ký phải nhận được việc ngay khi tải xong.
    await chrome.storage.local.set({ cancelReturnFollowRun: follow, cancelReturnRun: run });
    // v2.2.27 — mở thẳng link chi tiết phiếu (đúng trang "Kiểm tra chi tiết" mở ra, chỉ đổi số phiếu).
    await chrome.tabs.update(tab.id, { url: TIKTOK_TICKET_DETAIL_URL(pending.ticketId), active: true });
    chrome.alarms.create(CANCEL_RETURN_FOLLOW_ALARM, { when: Date.now() + followTimeout(follow) + 1000 });
    return { ok: true, tabId: tab.id };
  });
}
// v2.2.64 — làn phụ sau raise: 150 giây (chờ khung 60s + Gửi + 1 lần tải lại kiểm tra) rồi tự tải lại phiếu 1 lần, thay vì đứng 5 phút.
const followTimeout = follow => follow?.lane ? 150000 : ['post_raise', 'reply'].includes(follow?.mode) || follow?.active?.attach ? 300000 : CANCEL_RETURN_FOLLOW_TIMEOUT_MS;

/** Đẩy lại đúng các file của phiếu vào ô "Tải lên" của khung Gửi tin nhắn (MAIN world, từng file). */
async function uploadFollowUpFiles(tabId) {
  const { cancelReturnFollowRun: follow, cancelReturnReplyFiles: store = {} } = await chrome.storage.local.get(['cancelReturnFollowRun', 'cancelReturnReplyFiles']);
  const active = follow?.active;
  if (!active || Number(active.tabId) !== Number(tabId) || !active.attach || active.sendingAt) throw new Error('Không còn phiếu chờ đính kèm.');
  const files = (store[active.ticketId] || []).slice(0, OPCancelReturn.MAX_FILES);
  const perform = async (action, payload) => {
    const results = await chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', func: OPTikTokAttachments.pageOperation, args: [action, { platform: 'tiktok', ...payload }] });
    return results[0]?.result || { ok: false, error: 'Trang phiếu chưa trả kết quả đính kèm.' };
  };
  const names = [];
  for (const [index, file] of files.entries()) {
    if (!file.base64 || !file.size) throw new Error(`${file.name}: không còn dữ liệu file.`);
    const token = `op_follow_${tabId}_${Date.now()}_${index}`;
    try {
      for (let offset = 0, sequence = 0; offset < file.base64.length; offset += 393216, sequence++) {
        const result = await perform('chunk', { token, sequence, base64: file.base64.slice(offset, offset + 393216) });
        if (!result.ok) throw new Error(result.error || 'Không chuyển được file sang trang phiếu.');
      }
      let result;
      for (let attempt = 0; attempt < 10; attempt++) {
        result = await perform('dispatch', { token, name: file.name, type: file.type, size: file.size });
        if (result.ok || !result.retryable) break;
        await new Promise(resolve => setTimeout(resolve, 300));
      }
      if (!result?.ok) throw new Error(result?.error || `Chưa đính kèm được ${file.name}.`);
      names.push(file.name);
    } finally { await perform('clear', { token }).catch(() => {}); }
    // Cho TikTok nhận xong file trước rồi mới đẩy file kế (ô chỉ nhận 1 file mỗi lần).
    await new Promise(resolve => setTimeout(resolve, 1500));
  }
  return { ok: true, names };
}

async function mapCancelReturnManually(groupId, ticketIdValue) {
  const ticketId = String(ticketIdValue || '').trim();
  const { cancelReturnGroups: known = {} } = await chrome.storage.local.get('cancelReturnGroups');
  if (known[groupId]?.platform === 'shopee') { if (!/^[A-Za-z0-9][A-Za-z0-9_-]{4,79}$/.test(ticketId)) throw new Error('Mã phiếu Shopee gồm 5–80 chữ/số (xem seller-service.cs.shopee.vn → Yêu cầu của tôi).'); }
  else if (!/^\d{8,30}$/.test(ticketId)) throw new Error('Ticket ID TikTok gồm 8–30 chữ số.');
  let tabId = -Date.now();
  await withTicketStateLock(async () => {
    const data = await chrome.storage.local.get(['cancelReturnGroups', 'cancelReturnSettings', 'cancelReturnShopMap', 'ticketTabPayloads']);
    const group = data.cancelReturnGroups?.[groupId];
    if (!group) throw new Error('Không tìm thấy nhóm.');
    if (group.ticketId) throw new Error(`Nhóm đã có Ticket ${group.ticketId}.`);
    const active = Object.entries(data.ticketTabPayloads || {}).find(([, payload]) => payload.draft?.cancelReturn?.groupId === groupId);
    if (active) { tabId = Number(active[0]); return; }
    const draft = OPCancelReturn.draft(group, data.cancelReturnShopMap?.[group.channel] || group.channel, data.cancelReturnSettings || {});
    await chrome.storage.local.set({ ticketTabPayloads: { ...(data.ticketTabPayloads || {}), [String(tabId)]: { groupKey: draft.groupKey, draft, batchId: '' } } });
  });
  return recordTicketFromTab(tabId, ticketId);
}

/* ------------------------------------------------ v2.2.69 — phiếu Shopee (seller-service) --- */
/** MAIN world trên seller-service.cs.shopee.vn: tìm phiếu theo Mã đơn hàng (tab Tất cả) — đúng API trang gọi khi chọn
    "Mã đơn hàng" và gõ mã. Mỗi đơn trả các case { id, status, title, events (Webform ID) }. */
async function pageShopeeCases(orderIds) {
  const out = [];
  for (const sn of orderIds) {
    try {
      const url = `/api/channel/casetracking/service_portal/v2/cases?status=0&size=20&owner_type=1&scene=2&cursor_id=0&cursor_time=0&cursor_key=&query_type=2&keyword=${encodeURIComponent(sn)}`;
      const response = await fetch(url, { credentials: 'include', headers: { region: 'VN' } });
      const text = await response.text();
      if (!response.ok) { out.push({ sn, ok: false, error: `HTTP ${response.status}` }); continue; }
      const json = JSON.parse(text.replace(/(:\s*)(\d{16,})(\s*[,}\]])/g, '$1"$2"$3'));
      const cases = (json.data || []).filter(item => String(item?.order?.sn || '').toUpperCase() === String(sn).toUpperCase()).map(item => ({
        id: String(item.case?.id || ''), status: String(item.case?.status || ''), title: String(item.case?.title || ''),
        modified: Number(item.case?.last_modified_time || 0), events: (item.case?.enquiries || []).map(e => String(e?.event_id || '')).filter(Boolean)
      })).filter(item => item.id);
      out.push({ sn, ok: true, cases });
    } catch (error) { out.push({ sn, ok: false, error: String(error?.message || error) }); }
  }
  return out;
}
const SHOPEE_SERVICE = 'https://seller-service.cs.shopee.vn/';
/** Tab Cổng hỗ trợ người bán đang mở (đã đăng nhập) — không có thì mở 1 tab, chờ tải xong.
    v2.2.70 — dò bằng giao diện: tab hiện ra (active) và luôn ở trang Yêu cầu của tôi (không ở /detail/…). */
async function shopeeServiceTab({ active = false, home = false } = {}) {
  let open = (await chrome.tabs.query({ url: `${SHOPEE_SERVICE}*` })).find(tab => tab.status === 'complete') || null;
  if (open && (active || (home && new URL(open.url).pathname !== '/'))) {
    open = await chrome.tabs.update(open.id, { ...(active ? { active: true } : {}), ...(home && new URL(open.url).pathname !== '/' ? { url: SHOPEE_SERVICE } : {}) });
    for (let i = 0; i < 80 && home; i++) { const current = await chrome.tabs.get(open.id).catch(() => null); if (!current || current.status === 'complete') break; await new Promise(resolve => setTimeout(resolve, 250)); }
  }
  if (open) return { tabId: open.id, created: false };
  const tab = await chrome.tabs.create({ url: SHOPEE_SERVICE, active });
  for (let i = 0; i < 80; i++) {
    const current = await chrome.tabs.get(tab.id).catch(() => null);
    if (!current) throw new Error('Tab seller-service đã đóng.');
    if (current.url && !current.url.startsWith(SHOPEE_SERVICE)) throw new Error('Chưa đăng nhập Cổng hỗ trợ người bán Shopee — mở seller-service.cs.shopee.vn, đăng nhập rồi dò lại.');
    if (current.status === 'complete') break;
    await new Promise(resolve => setTimeout(resolve, 250));
  }
  return { tabId: tab.id, created: true };
}
/** v2.2.70 — MAIN world: làm đúng thao tác tay trên "Yêu cầu của tôi" — tab Tất cả → chọn "Mã đơn hàng" → gõ mã → tìm,
    rồi đọc bảng kết quả theo tên cột (Mã ID yêu cầu · Trạng thái · Webform ID · Mã đơn hàng · Tên yêu cầu). */
async function pageSearchOrderUI(sn) {
  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
  const visible = el => Boolean(el && el.getClientRects().length);
  const press = el => { for (const type of ['pointerdown', 'mousedown', 'mouseup', 'click']) el.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, view: window })); };
  const waitFor = async (fn, ms = 12000) => { const end = Date.now() + ms; while (Date.now() < end) { const v = fn(); if (v) return v; await sleep(200); } return null; };
  const norm = s => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/đ/gi, 'd').replace(/\s+/g, ' ').trim().toLowerCase();
  try {
    const all = await waitFor(() => [...document.querySelectorAll('[role="tab"]')].find(tab => norm(tab.innerText) === 'tat ca' && visible(tab)));
    if (!all) return { sn, ok: false, error: 'chưa thấy tab Tất cả (chưa đăng nhập Cổng hỗ trợ người bán?)' };
    if (all.getAttribute('aria-selected') !== 'true') { all.click(); await sleep(700); }
    let input = await waitFor(() => [...document.querySelectorAll('input.shopee-react-input__input')].find(el => /tim kiem/.test(norm(el.placeholder)) && visible(el)));
    if (!input) return { sn, ok: false, error: 'chưa thấy ô tìm kiếm' };
    if (!/ma don hang/.test(norm(input.placeholder))) {
      const trigger = input.closest('[class*="search__group"]')?.querySelector('.shopee-react-select__inner') || document.querySelector('.shopee-react-select .shopee-react-select__inner');
      if (trigger) { press(trigger); await sleep(400); }
      const option = await waitFor(() => [...document.querySelectorAll('.shopee-react-select-option')].find(el => visible(el) && norm(el.innerText) === 'ma don hang'), 4000);
      if (!option) return { sn, ok: false, error: 'chưa chọn được "Mã đơn hàng"' };
      press(option); await sleep(500);
      input = [...document.querySelectorAll('input.shopee-react-input__input')].find(el => /ma don hang/.test(norm(el.placeholder))) || input;
    }
    const before = [...document.querySelectorAll('tbody tr')].map(tr => tr.innerText).join('|');
    Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(input, sn);
    input.dispatchEvent(new Event('input', { bubbles: true }));
    await sleep(250);
    for (const type of ['keydown', 'keypress', 'keyup']) input.dispatchEvent(new KeyboardEvent(type, { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true }));
    // Cột "Mã đơn hàng" của bảng hiện TÊN SẢN PHẨM (không phải mã đơn) → không lọc theo chữ; bảng đã được lọc theo mã đơn.
    const empty = () => /khong co yeu cau nao/.test(norm(document.body.innerText));
    const rowsText = () => [...document.querySelectorAll('tbody tr')].map(tr => tr.innerText).join('|');
    let changed = await waitFor(() => rowsText() !== before, 5000);
    if (!changed) { const icon = input.closest('.shopee-react-input')?.querySelector('.shopee-react-input__suffix-icon'); if (icon) press(icon); changed = await waitFor(() => rowsText() !== before, 3000); }
    await sleep(500);
    if (!/ma don hang/.test(norm(input.placeholder)) || input.value.trim().toUpperCase() !== sn.toUpperCase()) return { sn, ok: false, error: 'ô tìm kiếm không giữ đúng Mã đơn hàng' };
    if (empty()) return { sn, ok: true, cases: [], via: 'ui' };
    const heads = [...document.querySelectorAll('thead th')].map(th => norm(th.innerText));
    const col = name => heads.findIndex(h => h.includes(name));
    const idCol = col('ma id yeu cau'), stCol = col('trang thai'), wfCol = col('webform id'), titleCol = col('ten yeu cau');
    if (idCol < 0) return { sn, ok: false, error: 'không thấy cột Mã ID yêu cầu' };
    const cases = [];
    for (const tr of document.querySelectorAll('tbody tr')) {
      const cells = [...tr.children].map(td => td.innerText.trim());
      const id = (String(cells[idCol] || '').match(/\d{12,25}/) || [])[0] || '';
      if (!id) continue;
      cases.push({ id, status: cells[stCol] || '', title: String(cells[titleCol] || '').split('\n')[0], events: [(String(cells[wfCol] || '').match(/\d{12,25}/) || [])[0]].filter(Boolean) });
    }
    return { sn, ok: true, cases, via: 'ui' };
  } catch (error) { return { sn, ok: false, error: String(error?.message || error) }; }
}
/** Dò theo đúng các bước tay trên tab seller-service (hiện ra cho người dùng thấy); bước giao diện lỗi → dùng API cùng truy vấn. */
async function lookupShopeeCasesUI(orderIds, onProgress = () => {}) {
  const wanted = [...new Set((orderIds || []).map(id => String(id || '').trim().toUpperCase()).filter(Boolean))];
  const tab = await shopeeServiceTab({ active: true, home: true });
  const found = {};
  for (const [index, sn] of wanted.entries()) {
    const stop = (await chrome.storage.local.get('cancelReturnLookup')).cancelReturnLookup;
    if (stop?.stopped) break;
    await onProgress(index, wanted.length, sn);
    const [ui] = await chrome.scripting.executeScript({ target: { tabId: tab.tabId }, world: 'MAIN', func: pageSearchOrderUI, args: [sn] }).catch(error => [{ result: { sn, ok: false, error: error.message } }]);
    let item = ui?.result;
    if (!item?.ok) {
      const [api] = await chrome.scripting.executeScript({ target: { tabId: tab.tabId }, world: 'MAIN', func: pageShopeeCases, args: [[sn]] }).catch(() => [null]);
      item = api?.result?.[0] ? { ...api.result[0], via: 'api', uiError: item?.error || '' } : item;
    }
    found[sn] = item || { sn, ok: false, error: 'không đọc được' };
  }
  if (wanted.length && Object.values(found).every(item => !item.ok)) throw new Error(`Không đọc được phiếu Shopee (${Object.values(found)[0]?.error || 'lỗi'}). Đăng nhập seller-service.cs.shopee.vn đúng shop rồi dò lại.`);
  return found;
}
async function lookupShopeeCases(orderIds) {
  const wanted = [...new Set((orderIds || []).map(id => String(id || '').trim().toUpperCase()).filter(Boolean))];
  if (!wanted.length) return {};
  const tab = await shopeeServiceTab();
  try {
    const found = {};
    for (let i = 0; i < wanted.length; i += 20) {
      const [result] = await chrome.scripting.executeScript({ target: { tabId: tab.tabId }, world: 'MAIN', func: pageShopeeCases, args: [wanted.slice(i, i + 20)] });
      for (const item of result?.result || []) found[item.sn] = item;
    }
    const failed = Object.values(found).filter(item => !item.ok);
    if (failed.length && failed.length === wanted.length) throw new Error(`Không đọc được phiếu Shopee (${failed[0].error}). Mở seller-service.cs.shopee.vn, đăng nhập đúng shop rồi thử lại.`);
    return found;
  } finally { if (tab.created) chrome.tabs.remove(tab.tabId).catch(() => {}); }
}
/** Dò mã phiếu Shopee cho ticket đòi hàng chưa có mã — v2.2.70: tìm theo Mã đơn hàng đúng thao tác tay trên "Yêu cầu của tôi"
    (đơn đại diện trước, không ra thì các đơn còn lại của ticket). Tự gán khi khớp Webform ID tool bắt lúc Gửi, hoặc đơn chỉ có
    đúng 1 phiếu "Vận chuyển" chưa dùng; nhiều phiếu thì hiện nút "Gán #…" để chọn. */
async function startShopeeCancelReturnLookup(groupIds) {
  const data = await chrome.storage.local.get(['cancelReturnGroups', 'cancelReturnTickets', 'ticketTabReceipts', 'ticketTabPayloads']);
  const wanted = new Set(groupIds || []);
  const groups = Object.values(data.cancelReturnGroups || {}).filter(group => group.platform === 'shopee' && !group.ticketId && (!wanted.size || wanted.has(group.id)));
  if (!groups.length) throw new Error('Không có ticket Shopee nào đang thiếu mã phiếu.');
  // Webform ID (submissionId) tool đã bắt được lúc bấm Gửi, theo nhóm.
  const submissions = {};
  for (const item of [...Object.values(data.ticketTabReceipts || {}), ...Object.values(data.ticketTabPayloads || {})]) {
    const draft = item?.pendingDraft || item?.draft;
    const sub = item?.submission?.submissionId || item?.ticketCapture?.submissionId || '';
    if (draft?.issueType === OPCancelReturn.ISSUE && draft.platform === 'shopee' && sub) submissions[draft.cancelReturn?.groupId] = String(sub);
  }
  const used = new Set(Object.keys(data.cancelReturnTickets || {}));
  const startedAt = new Date().toISOString();
  const lookup = { id: `lookup_shopee_${Date.now()}`, platform: 'shopee', queue: groups.map(group => group.id), active: '', results: [], startedAt, doneAt: '' };
  await chrome.storage.local.set({ cancelReturnLookup: lookup });
  const publish = () => chrome.storage.local.set({ cancelReturnLookup: { ...lookup } });
  let mapped = 0;
  try {
    for (const group of groups) {
      const latest = (await chrome.storage.local.get('cancelReturnLookup')).cancelReturnLookup;
      if (latest?.stopped) break;
      lookup.active = group.id; lookup.queue = lookup.queue.filter(id => id !== group.id); await publish();
      const rep = group.rows[0].orderId.toUpperCase();
      const label = `${group.carrier} · ${group.rows.length > 1 ? `${group.rows.length} đơn, đại diện ` : ''}${rep}`;
      // Đơn đại diện trước; không ra phiếu thì thử các đơn còn lại (phiếu raise tay có thể ghi đơn khác).
      let cases = [], error = '', searched = '';
      for (const row of group.rows.slice(0, 10)) {
        const sn = row.orderId.toUpperCase();
        const found = await lookupShopeeCasesUI([sn]);
        const item = found[sn];
        if (!item?.ok) { error = item?.error || 'chưa đọc được'; continue; }
        cases = item.cases.filter(c => !used.has(c.id)).sort((a, b) => (BigInt(b.id) > BigInt(a.id) ? 1 : -1));
        searched = sn;
        if (cases.length) break;
      }
      const transport = cases.filter(c => /van chuyen|vận chuyển/i.test(c.title));
      const pick = (submissions[group.id] && cases.find(c => c.events.includes(submissions[group.id])))
        || (transport.length === 1 ? transport[0] : null) || (cases.length === 1 ? cases[0] : null);
      if (pick) {
        try { await mapCancelReturnManually(group.id, pick.id); used.add(pick.id); mapped++; lookup.results.push({ groupId: group.id, label, ticketId: pick.id }); }
        catch (mapError) { lookup.results.push({ groupId: group.id, label, reason: `thấy #${pick.id} nhưng chưa gán được: ${mapError.message}`, candidates: [] }); }
      } else lookup.results.push({ groupId: group.id, label, reason: cases.length ? `${cases.length} phiếu theo mã đơn ${searched} — chọn đúng phiếu đòi hàng` : (error && !searched ? error : `chưa thấy phiếu nào theo mã đơn ${group.rows.length > 1 ? `(đã tìm ${Math.min(10, group.rows.length)} đơn)` : rep} trên Shopee`),
        candidates: cases.slice(0, 5).map(c => ({ ticketId: c.id, status: OPCancelReturn.shopeeCaseStatus(c.status), created: c.title })) });
      await publish();
    }
  } finally {
    lookup.active = ''; lookup.doneAt = new Date().toISOString(); await publish();
  }
  return { ok: true, count: groups.length, mapped };
}
/** v2.2.71 — MAIN world: đọc trang chi tiết phiếu như khi mở /detail/<id>: get_case (trạng thái, mở lại được không, còn lượt trả lời)
    + enquirys (toàn bộ hội thoại: tin shop / tin nhân viên Shopee, link hướng dẫn). */
async function pageShopeeCaseDetails(ids) {
  const parse = text => JSON.parse(text.replace(/(:\s*)(\d{16,})(\s*[,}\]])/g, '$1"$2"$3'));
  const get = async path => { const response = await fetch(`/api/channel/casetracking/service_portal/v1/${path}`, { credentials: 'include', headers: { region: 'VN' } }); if (!response.ok) throw new Error(`HTTP ${response.status}`); return parse(await response.text()); };
  const toText = html => { const box = document.createElement('div'); box.innerHTML = String(html || '').replace(/<br\s*\/?>/gi, '\n').replace(/<\/(p|div|li)>/gi, '\n'); return (box.innerText || box.textContent || '').replace(/\n{3,}/g, '\n\n').trim(); };
  const out = [];
  for (const id of ids) {
    try {
      const [caseData, enquiry] = await Promise.all([get(`cases/get_case?case_id=${encodeURIComponent(id)}`), get(`enquirys?case_id=${encodeURIComponent(id)}`)]);
      const c = caseData.case || {};
      const messages = (enquiry.enquiry_messages || []).map(m => {
        const e = m.enquiry_message || {};
        const html = String(e.html_body || '');
        const links = [...html.matchAll(/href=["']([^"']+)["']/gi)].map(x => x[1]).filter(u => /^https:\/\//.test(u));
        const inbound = m.message_type === 'Web' ? true : e.is_inbound === true;
        return { at: m.message_time ? new Date(m.message_time * 1000).toISOString() : '', inbound, type: m.message_type || '', text: toText(e.text_body || html), links };   // text_body của Shopee cũng là HTML
      }).filter(m => m.text || m.type === 'Web').sort((a, b) => String(a.at).localeCompare(String(b.at)));
      out.push({ id: String(id), ok: true, status: String(c.status || ''), canReopen: c.can_reopen_when_case_closed === true, remainingReply: Number(caseData.remaining_reply_count ?? -1),
        followUpCaseId: String(c.follow_up_case_id || ''), orderStatus: String(caseData.order?.status || ''), modified: Number(c.last_modified_time || 0), messages });
    } catch (error) { out.push({ id: String(id), ok: false, error: String(error?.message || error) }); }
  }
  return out;
}
/** Kiểm tra phản hồi phiếu đòi hàng Shopee: đọc nội dung phiếu → Thắng / Thua / Shopee báo đã hoàn / Shopee cần bổ sung / Đang chờ,
    lưu tóm tắt + việc cần làm, ghi lại tracker khi đổi. Trả danh sách phiếu cần raise lại. */
async function refreshShopeeCancelReturnStatuses(ticketIds) {
  const { cancelReturnTickets: tickets = {} } = await chrome.storage.local.get('cancelReturnTickets');
  const wanted = new Set(ticketIds || []);
  const list = Object.values(tickets).filter(ticket => ticket.platform === 'shopee' && !ticket.finished && !ticket.reraisedTo && (!wanted.size || wanted.has(String(ticket.TicketID))));
  if (!list.length) throw new Error('Chưa có phiếu đòi hàng Shopee nào đang theo dõi.');
  const tab = await shopeeServiceTab();
  let details = [];
  try {
    for (let i = 0; i < list.length; i += 15) {
      const [result] = await chrome.scripting.executeScript({ target: { tabId: tab.tabId }, world: 'MAIN', func: pageShopeeCaseDetails, args: [list.slice(i, i + 15).map(ticket => String(ticket.TicketID))] });
      details = details.concat(result?.result || []);
    }
  } finally { if (tab.created) chrome.tabs.remove(tab.tabId).catch(() => {}); }
  if (details.length && details.every(item => !item.ok)) throw new Error(`Không đọc được phiếu Shopee (${details[0].error}). Mở seller-service.cs.shopee.vn, đăng nhập đúng shop rồi thử lại.`);
  return withTicketStateLock(async () => {
    const data = await chrome.storage.local.get(['cancelReturnTickets', 'cancelReturnTrackerOutbox']);
    const next = { ...(data.cancelReturnTickets || {}) };
    let outbox = data.cancelReturnTrackerOutbox || {}, changed = 0, checked = 0;
    const now = new Date().toISOString();
    const counts = {};
    for (const item of details) {
      const ticket = next[item.id];
      if (!item.ok || !ticket) continue;
      checked++;
      const verdict = OPCancelReturn.classifyShopeeReplies(item.messages, item.status);
      const shopee = { ...verdict, status: item.status, canReopen: item.canReopen, remainingReply: item.remainingReply, followUpCaseId: item.followUpCaseId, orderStatus: item.orderStatus,
        messages: item.messages.slice(-8).map(m => ({ at: m.at, inbound: m.inbound, text: String(m.text || '').slice(0, 1500), links: m.links })), checkedAt: now };
      const label = OPCancelReturn.shopeeCaseStatus(item.status);
      const before = `${ticket.lastStatus}|${ticket.shopee?.verdict}|${ticket.shopee?.gist}`;
      next[item.id] = { ...ticket, lastStatus: label, lastCheckedAt: now, shopee };
      if (before !== `${label}|${shopee.verdict}|${shopee.gist}`) { changed++; outbox = queueTrackerWrite(outbox, item.id); }
      counts[shopee.verdict] = (counts[shopee.verdict] || 0) + 1;
    }
    await chrome.storage.local.set({ cancelReturnTickets: next, cancelReturnTrackerOutbox: outbox });
    if (changed) scheduleTrackerWrite();
    const reraise = Object.values(next).filter(OPCancelReturn.needsReraise).map(ticket => ticket.TicketID);
    return { ok: true, total: list.length, checked, changed, counts, reraise, failed: details.filter(item => !item.ok).length };
  });
}

/* ------------------------------------------------------------ theo dõi phiếu --- */

/** v2.2.49 — gom MỌI phiếu TikTok đã raise trong Ticket Master (pickup, kháng nghị bàn giao, khiếu nại KPI…) vào danh sách theo dõi.
    TikTok tự đóng phiếu → phải phản hồi để mở lại. Phiếu đòi hàng đã có sẵn; phiếu loại khác đánh dấu kind 'general'
    (không ghi tracker FG Recon). Chỉ lấy phiếu trong 45 ngày gần nhất. */
async function syncTikTokFollowTickets() {
  const records = await OPStore.readAll();
  const since = Date.now() - 45 * 86400000;
  const found = new Map();
  for (const record of records) {
    const ticketId = String(record.TicketID || '').trim();
    if (!/^\d{8,30}$/.test(ticketId) || String(record.TicketPlatform || '').toUpperCase() !== 'TIKTOK') continue;
    if (record.IssueType === OPCancelReturn.ISSUE) continue;
    const at = Date.parse(record.TicketRecordedAt || record.TicketCreatedAt || '') || 0;
    if (at && at < since) continue;
    const item = found.get(ticketId) || { TicketID: ticketId, kind: 'general', issueType: record.IssueType || '', shopName: record.ChannelName || '', carrier: record.DeliveryPlatform || '', warehouse: record.WarehouseBranch || '', orderIds: [], trackingIds: [], recordedAt: new Date(at || Date.now()).toISOString(), lastStatus: record.TicketStatus || 'Submitted', followUps: [], finished: false };
    const orderId = String(record.OrderID || '').trim();
    if (orderId && !item.orderIds.includes(orderId)) item.orderIds.push(orderId);
    if (record.TrackingID && !item.trackingIds.includes(record.TrackingID)) item.trackingIds.push(record.TrackingID);
    found.set(ticketId, item);
  }
  return withTicketStateLock(async () => {
    const { cancelReturnTickets: tickets = {} } = await chrome.storage.local.get('cancelReturnTickets');
    let added = 0;
    for (const [ticketId, item] of found) {
      if (tickets[ticketId]) { if (tickets[ticketId].kind === 'general') tickets[ticketId] = { ...item, ...tickets[ticketId], orderIds: [...new Set([...(tickets[ticketId].orderIds || []), ...item.orderIds])] }; continue; }
      tickets[ticketId] = item; added++;
    }
    await chrome.storage.local.set({ cancelReturnTickets: tickets });
    return { ok: true, added, total: found.size };
  });
}

/* v2.2.58 — KIỂM TRA HÀNG LOẠT: 1 lần gọi danh sách phiếu của TikTok (10 mã/lượt) lấy trạng thái mọi phiếu,
   chỉ mở trang chi tiết những phiếu ĐÃ ĐÓNG để phản hồi mở lại (trước đây mở từng phiếu ~15 giây chỉ để đọc trạng thái).
   Đo trên trang thật 31/10: ticketStatus 1 = Đang xử lý, 2 = Đã đóng. Chạy trong MAIN world của trang Nhật ký phiếu. */
function pageTicketStatuses(ids) {
  return (async () => {
    const url = performance.getEntriesByType('resource').map(entry => entry.name).filter(name => /\/api\/ticket\/ticket_list/.test(name)).pop();
    if (!url) return { ok: false, error: 'no-list' };
    const post = body => new Promise(resolve => {
      const xhr = new XMLHttpRequest();
      xhr.open('POST', url); xhr.setRequestHeader('content-type', 'application/json'); xhr.withCredentials = true;
      xhr.onload = () => resolve(xhr.status === 200 ? xhr.responseText : ''); xhr.onerror = () => resolve('');
      xhr.send(JSON.stringify(body));
    });
    const findArr = value => { if (!value || typeof value !== 'object') return null; for (const child of Object.values(value)) { if (Array.isArray(child) && child.length && typeof child[0] === 'object') return child; const found = findArr(child); if (found) return found; } return null; };
    const statuses = {};
    for (let i = 0; i < ids.length; i += 10) {
      const text = await post({ clientType: 2, pageNo: 1, pageSize: 50, filterReadStatus: 1, ticketType: '', sellerSearchCondition: { ticketStatus: 10, ticketNumSearchList: ids.slice(i, i + 10), orderIdSearchList: [], filterCreatedBy: false, requestStartTime: '', requestEndTime: '', updateStartTime: '', updateEndTime: '', ticketFilter: { channel: [] } } });
      let json; try { json = JSON.parse(text); } catch (_) { return { ok: false, error: 'bad-response', statuses }; }
      for (const item of findArr(json) || []) statuses[String(item.ticketNum)] = { status: String(item.ticketStatus), request: String(item.ticketRequestStatus), updated: Number(item.updateTime) || 0, shop: String(item.shopName || '') };
    }
    return { ok: true, statuses };
  })();
}
async function fetchTicketStatusesBulk(ticketIds) {
  return runOnTicketListTab(pageTicketStatuses, [ticketIds]);
}
/** Chạy 1 hàm MAIN world trên trang Nhật ký phiếu: dùng tab TikTok đang mở (kế thừa phiên đăng nhập), không có thì mở tab nền. */
async function runOnTicketListTab(func, args, options = {}) {
  const { cancelReturnRun: run, cancelReturnFollowRun: follow } = await chrome.storage.local.get(['cancelReturnRun', 'cancelReturnFollowRun']);
  const busy = new Set([run?.activeTabId, follow?.active?.tabId].filter(Boolean).map(Number));
  const tabs = await chrome.tabs.query({ url: 'https://seller-vn.tiktok.com/*' }).catch(() => []);
  let tab = tabs.find(item => /^\/ticket\/?$/.test(new URL(item.url).pathname) && !busy.has(item.id));
  let created = false;
  // v2.2.73 — Quét phiếu: tải lại đúng link Nhật ký phiếu ở tab trước mặt rồi bấm "Tất cả" (như thao tác tay), giữ tab lại.
  if (options.reload) {
    if (tab) await chrome.tabs.update(tab.id, { url: TIKTOK_TICKET_LIST_URL, active: true });
    else tab = await chrome.tabs.create({ url: TIKTOK_TICKET_LIST_URL, active: true });
    const ready = await reloadTicketListAndClickAll(tab.id);
    if (!ready.ok) return ready;
  } else if (!tab) { tab = await chrome.tabs.create({ url: TIKTOK_TICKET_LIST_URL, active: false }); created = true; }
  try {
    for (let i = 0; i < 40; i++) {
      const [probe] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: 'MAIN', func: () => performance.getEntriesByType('resource').some(entry => /\/api\/ticket\/ticket_list/.test(entry.name)) }).catch(() => [null]);
      if (probe?.result) break;
      await new Promise(resolve => setTimeout(resolve, 500));
    }
    const [result] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: 'MAIN', func, args });
    return result?.result || { ok: false, error: 'no-result' };
  } catch (error) { return { ok: false, error: error.message || String(error) }; }
  finally { if (created) chrome.tabs.remove(tab.id).catch(() => {}); }
}
const BULK_STATUS_LABEL = { 1: 'Đang xử lý', 2: 'Đã đóng' };

/** Chờ trang Nhật ký phiếu tải xong → bấm tab "Tất cả" (click() — đo trên trang thật) → chờ danh sách Tất cả tải về. */
async function reloadTicketListAndClickAll(tabId) {
  const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
  // Cùng link → ngay sau lệnh tải lại tab vẫn báo "complete" của trang cũ: chờ thấy "loading" (tối đa 3 giây) rồi mới chờ "complete".
  let reloaded = false;
  for (let i = 0; i < 80; i++) {
    const tab = await chrome.tabs.get(tabId).catch(() => null);
    if (!tab) return { ok: false, error: 'Tab Nhật ký phiếu đã bị đóng.' };
    if (tab.status === 'loading') reloaded = true;
    if ((reloaded || i >= 6) && tab.status === 'complete' && /^https:\/\/seller-vn\.tiktok\.com\/ticket\/?(\?|$)/.test(tab.url || '')) break;
    if (/\/account\/login|\/login/.test(tab.url || '')) return { ok: false, error: 'TikTok Shop chưa đăng nhập — đăng nhập rồi quét lại.' };
    await wait(500);
  }
  const [clicked] = await chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', func: async () => {
    const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
    const count = () => performance.getEntriesByType('resource').filter(entry => /\/api\/ticket\/ticket_list/.test(entry.name)).length;
    const norm = value => String(value || '').normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[đĐ]/g, 'd').trim().toLowerCase();
    let tab = null;
    for (let i = 0; i < 60 && !tab; i++) { tab = [...document.querySelectorAll('[role="tab"]')].find(el => el.offsetWidth && /^tat ca/.test(norm(el.textContent))); if (!tab) await sleep(500); }
    if (!tab) return { ok: false, error: 'Chưa thấy tab "Tất cả" trên Nhật ký phiếu.' };
    // Chờ danh sách mặc định (Chưa đọc) tải xong để lượt bấm không bị trang ghi đè.
    for (let i = 0; i < 30 && !count(); i++) await sleep(500);
    const before = count();
    for (let attempt = 0; attempt < 4 && tab.getAttribute('aria-selected') !== 'true'; attempt++) {
      tab.click();
      for (let i = 0; i < 15 && tab.getAttribute('aria-selected') !== 'true'; i++) await sleep(200);
    }
    if (tab.getAttribute('aria-selected') !== 'true') return { ok: false, error: 'Chưa chuyển được sang tab "Tất cả".' };
    for (let i = 0; i < 30 && count() <= before; i++) await sleep(500);
    return { ok: count() > 0, error: count() ? '' : 'Danh sách Tất cả chưa tải về.' };
  } }).catch(error => [{ result: { ok: false, error: error.message || String(error) } }]);
  return clicked?.result || { ok: false, error: 'Không bấm được tab Tất cả.' };
}

/* v2.2.72 — QUÉT LẠI PHIẾU TIKTOK: mọi phiếu đang mở + phiếu đóng trong `days` ngày (theo ngày tạo, API trả mới → cũ).
   Mỗi phiếu: trạng thái, tin cuối (TikTok hay shop gửi, nội dung đã bỏ HTML) và tin đầu của phiếu (có link biên bản). */
function pageScanTickets(days, want = {}, onlyIds = []) {
  return (async () => {
    const url = performance.getEntriesByType('resource').map(entry => entry.name).filter(name => /\/api\/ticket\/ticket_list/.test(name)).pop();
    if (!url) return { ok: false, error: 'no-list' };
    const post = (body, target = url) => new Promise(resolve => {
      const xhr = new XMLHttpRequest();
      xhr.open('POST', target); xhr.setRequestHeader('content-type', 'application/json'); xhr.withCredentials = true;
      xhr.onload = () => resolve(xhr.status === 200 ? xhr.responseText : ''); xhr.onerror = () => resolve('');
      xhr.send(JSON.stringify(body));
    });
    const plain = html => {
      const doc = new DOMParser().parseFromString(String(html || '').replace(/<br\s*\/?>/gi, '\n').replace(/<\/(div|p|li)>/gi, '\n'), 'text/html');
      return String(doc.body?.textContent || '').replace(/[ \t ]+/g, ' ').replace(/\n\s*\n+/g, '\n').trim();
    };
    const since = Math.floor(Date.now() / 1000) - Math.max(1, Number(days) || 14) * 86400;
    const items = [];
    // v2.2.76 — quét lại riêng vài phiếu (bấm từ panel): tìm theo Số phiếu (10 mã/lượt, mọi trạng thái), không giới hạn ngày.
    const only = (onlyIds || []).map(String);
    const passes = only.length ? Array.from({ length: Math.ceil(only.length / 10) }, (_, i) => ({ ticketStatus: 10, nums: only.slice(i * 10, i * 10 + 10) })) : [{ ticketStatus: 1, nums: [] }, { ticketStatus: 2, nums: [] }];
    for (const { ticketStatus, nums } of passes) {
      for (let pageNo = 1; pageNo <= 40; pageNo++) {
        const text = await post({ clientType: 2, pageNo, pageSize: 50, filterReadStatus: 0, ticketType: '', sellerSearchCondition: { ticketStatus, ticketNumSearchList: nums, orderIdSearchList: [], filterCreatedBy: false, requestStartTime: '', requestEndTime: '', updateStartTime: '', updateEndTime: '', ticketFilter: { channel: [] } } });
        let json; try { json = JSON.parse(text); } catch (_) { return { ok: false, error: 'bad-response', items }; }
        if (json.code !== 0) return { ok: false, error: `TikTok: ${json.msg || json.code}`, items };
        const list = json.data?.ticketSearchList || [];
        let older = false;
        for (const item of list) {
          if (ticketStatus === 2 && !nums.length && Number(item.requestTime) < since) { older = true; continue; }
          const last = item.lastReply || {};
          items.push({ id: String(item.ticketNum), status: Number(item.ticketStatus), request: Number(item.ticketRequestStatus), created: Number(item.requestTime) || 0, updated: Number(item.updateTime) || 0,
            shop: String(item.shopName || ''), title: String(item.ticketTitle || '').slice(0, 200), context: plain(item.ticketContext).slice(0, 1500),
            last: { agent: Number(last.operationObject) === 1, at: Number(last.operatedAtSec) || 0, text: plain(last.replyContent).slice(0, 1500) } });
        }
        if (older || list.length < 50 || pageNo * 50 >= Number(json.data?.total || 0)) break;
      }
    }
    // v2.2.74 — phiếu của tool có cập nhật mới: đọc cả luồng (reply_list dùng chung tham số ký của ticket_list, body {ticketNum}).
    // Tin cuối của phiếu đã đóng thường là thẻ khảo sát "survey-card://" → bỏ, lấy tin thật cuối cùng.
    const threadUrl = url.replace('/api/ticket/ticket_list', '/api/ticket/reply_list');
    const todo = items.filter(item => Object.prototype.hasOwnProperty.call(want, item.id) && item.updated > Number(want[item.id] || 0));
    let threads = 0;
    for (let i = 0; i < todo.length; i += 6) {
      await Promise.all(todo.slice(i, i + 6).map(async item => {
        let json; try { json = JSON.parse(await post({ ticketNum: item.id }, threadUrl)); } catch (_) { return; }
        if (json?.code !== 0) return;
        const thread = Object.values(json.data || {}).map(m => ({ agent: Number(m.operationObject) === 1, at: Number(m.operatedAtSec) || 0, text: plain(m.replyContent).slice(0, 1500) }))
          .filter(m => m.text && !/^survey-card:/i.test(m.text)).sort((a, b) => a.at - b.at);
        item.thread = thread; threads++;
        if (thread.length) item.last = thread[thread.length - 1];
      }));
    }
    return { ok: true, items, threads };
  })();
}

async function scanTikTokTickets(days = 14, options = {}) {
  const shop = await getLoggedInMarketplaceShop('tiktok');
  if (!shop?.ok) throw new Error(shop?.error || 'Mở tab TikTok Shop (đúng shop) rồi quét lại.');
  // v2.2.76 — quét lại riêng phiếu (Xem phiếu / Quét lại phiếu này): luôn đọc lại cả luồng, chạy nền, không ghi đè tóm tắt lần quét chung.
  const only = (options.ids || []).map(String).filter(id => /^\d{8,30}$/.test(id));
  // v2.2.73 — chỉ xét phiếu do tool raise (Ticket Master / tracker); phiếu người khác raise trên cùng shop bỏ qua.
  if (!only.length) await syncTikTokFollowTickets().catch(() => null);
  // v2.2.74 — phiếu của tool: đọc lại luồng hội thoại khi phiếu có cập nhật mới so với lần đọc trước.
  const { cancelReturnTickets: tracked = {}, cancelReturnTracker: trackerInfo } = await chrome.storage.local.get(['cancelReturnTickets', 'cancelReturnTracker']);
  // v2.2.79 — cả phiếu có Ticket ID trong tracker (raise ở Chrome/máy khác, vd 3CE) — trước đây bị coi là "người khác raise".
  const fromTracker = trackerInfo?.tickets || {};
  const want = only.length ? Object.fromEntries(only.map(id => [id, -1])) : Object.fromEntries([
    ...Object.keys(fromTracker).filter(id => !tracked[id]).map(id => [id, 0]),
    ...Object.values(tracked).filter(ticket => ticket.platform !== 'shopee' && !ticket.finished && ticket.source !== 'scan').map(ticket => [String(ticket.TicketID), options.full ? 0 : Number(ticket.tiktok?.threadUpdated || 0)])]);
  // Bấm tay: tải lại link Nhật ký phiếu + bấm Tất cả rồi mới quét. Tự quét định kỳ: chạy nền, không giành tab của người dùng.
  const scan = await runOnTicketListTab(pageScanTickets, [days, want, only], { reload: !only.length && options.reload !== false });
  if (scan?.ok && only.length && !scan.items.length) throw new Error(`Không thấy phiếu #${only.join(', #')} trên Nhật ký phiếu của shop ${shop.name} — kiểm tra đúng shop đang đăng nhập.`);
  if (!scan?.ok) throw new Error(scan?.error === 'no-list' ? 'Trang Nhật ký phiếu chưa tải danh sách — mở seller-vn.tiktok.com/ticket rồi quét lại.' : `Không đọc được danh sách phiếu (${scan?.error || '?'}).`);
  return withTicketStateLock(async () => {
    const data = await chrome.storage.local.get(['cancelReturnTickets', 'cancelReturnTrackerOutbox', 'cancelReturnTracker']);
    const tickets = { ...(data.cancelReturnTickets || {}) };
    // Đơn kho vẫn ghi "Đã bàn giao ĐVVC" ở lần tải tracker gần nhất = chưa nhận hàng hoàn (chưa tải tracker → không biết).
    const pendingOrders = Array.isArray(data.cancelReturnTracker?.pendingOrders) ? new Set(data.cancelReturnTracker.pendingOrders.map(String)) : null;
    for (const [id, ticket] of Object.entries(tickets)) if (ticket.source === 'scan') delete tickets[id];   // bản 2.2.72 lỡ thêm phiếu ngoài tracker
    let outbox = data.cancelReturnTrackerOutbox || {}, updated = 0, others = 0, added = 0;
    const now = new Date().toISOString();
    const counts = {}, verdicts = {}, need = [], closedAfterAsk = [], fresh = [], rebut = [];
    // v2.2.83 — phiếu MỚI hơn cho cùng mã đơn (raise lại bằng tool, raise tay trên TikTok, hoặc tool lỡ không bắt được Ticket ID)
    // → phiếu cũ đã đóng coi như "Đã raise lại → #mới", không báo cần raise lại nữa.
    const byOrder = new Map();
    for (const item of scan.items) for (const orderId of OPCancelReturn.ttOrderIds(`${item.title}\n${item.context}`)) (byOrder.get(orderId) || byOrder.set(orderId, []).get(orderId)).push(item);
    let relinked = 0;
    for (const item of scan.items) {
      // Phiếu có trong tracker nhưng Chrome này chưa lưu → tạo bản theo dõi từ dòng tracker (đơn, MVĐ, ĐVVC, kho, STT, link biên bản).
      const tt = !tickets[item.id] && fromTracker[item.id];
      if (tt) {
        tickets[item.id] = { TicketID: item.id, platform: 'tiktok', source: 'tracker', shopName: item.shop, channel: tt.channel, carrier: tt.carrier, warehouse: tt.warehouse,
          stage: 'not_returned', groupId: '', orderIds: tt.orderIds, orderNos: tt.orderNos, trackingIds: tt.trackingIds,
          text: '', replyText: [`Bổ sung bằng chứng bàn giao cho đơn ${tt.orderIds[0]}:`, `- Mã vận đơn: ${tt.trackingIds[0] || '-'}`, tt.sequence ? `- STT trong biên bản bàn giao: ${tt.sequence}` : '', tt.evidence ? `- Biên bản bàn giao (có chữ ký ĐVVC): ${tt.evidence}` : ''].filter(Boolean).join('\n'),
          createdAt: new Date((item.created || Date.now() / 1000) * 1000).toISOString(), recordedAt: new Date((item.created || Date.now() / 1000) * 1000).toISOString(),
          lastStatus: 'Submitted', lastCheckedAt: '', followUps: [], finished: false, trackerSyncedAt: now };
        added++;
      }
      let known = tickets[item.id];
      if (!known) { if (OPCancelReturn.ttActionKind(item)) others++; continue; }
      if (Number(item.status) === 2 && !known.reraisedTo) {
        const newer = (known.orderIds || []).flatMap(orderId => byOrder.get(String(orderId)) || [])
          .filter(other => other.id !== item.id && other.created > item.created).sort((a, b) => b.created - a.created)[0];
        if (newer) { known = tickets[item.id] = { ...known, reraisedTo: newer.id, reraisedAt: now, reraisedBy: 'scan' }; relinked++; if (known.kind !== 'general') outbox = queueTrackerWrite(outbox, item.id); }
      }
      const label = OPCancelReturn.ttStatusLabel(item);
      counts[label] = (counts[label] || 0) + 1;
      // Phản hồi TikTok: luồng vừa đọc → phân loại lại; không đọc (không có gì mới) → giữ kết quả lần trước.
      const reply = item.thread ? OPCancelReturn.classifyTikTokReplies(item.thread) : known.tiktok?.reply || null;
      // Ưu tiên: Cần hành động (24 giờ) > phản biện phiếu giải quyết sai / trả lời lệch > raise lại phiếu mới (đã đóng).
      const notReceived = pendingOrders ? (known.orderIds || []).some(id => pendingOrders.has(String(id))) : undefined;
      const action = OPCancelReturn.ttActionKind(item, known) || OPCancelReturn.ttRebutKind(item, known, reply, { notReceived });
      const messages = item.thread ? item.thread.slice(-4).map(m => ({ agent: m.agent, at: m.at ? new Date(m.at * 1000).toISOString() : '', text: m.text.slice(0, 800) })) : known.tiktok?.messages || [];
      const tiktok = { status: item.status, request: item.request, label, title: item.title, context: item.context, updatedAt: item.updated ? new Date(item.updated * 1000).toISOString() : '',
        lastFromAgent: item.last.agent, lastAt: item.last.at ? new Date(item.last.at * 1000).toISOString() : '', lastText: item.last.text, action, needAction: action === 'reply', scannedAt: now,
        reply, messages, ...(notReceived !== undefined ? { notReceived } : {}), threadUpdated: item.thread ? item.updated : Number(known.tiktok?.threadUpdated || 0) };
      if (reply) verdicts[reply.label] = (verdicts[reply.label] || 0) + 1;
      const newReply = Boolean(reply?.at && reply.at !== known.tiktok?.reply?.at);
      if (newReply) fresh.push(item.id);
      if ((known.lastStatus !== label || newReply) && known.kind !== 'general') outbox = queueTrackerWrite(outbox, item.id);
      tickets[item.id] = { ...known, lastStatus: label, lastCheckedAt: now, tiktok };
      updated++;
      if (action === 'reply') need.push(item.id); else if (action === 'rebut') rebut.push(item.id); else if (action === 'new') closedAfterAsk.push(item.id);
    }
    // Hạn gần nhất lên đầu (TikTok đóng phiếu 24 giờ sau tin yêu cầu).
    need.sort((a, b) => OPCancelReturn.ttDeadline(tickets[a]) - OPCancelReturn.ttDeadline(tickets[b]));
    const nextDeadline = need.length ? new Date(OPCancelReturn.ttDeadline(tickets[need[0]])).toISOString() : '';
    const summary = { at: now, shop: shop.name, days, scanned: scan.items.length, counts, verdicts, fresh, threads: scan.threads || 0, need, rebut, closedAfterAsk, nextDeadline, updated, added, others, relinked };
    await chrome.storage.local.set({ cancelReturnTickets: tickets, cancelReturnTrackerOutbox: outbox, ...(only.length ? {} : { cancelReturnTikTokScan: summary }) });
    scheduleTrackerWrite();
    return { ok: true, ...summary };
  });
}

/* Tự quét định kỳ (bật ở Theo dõi): chỉ khi đang mở tab TikTok Shop; có phiếu Cần hành động → báo Chrome notification
   (kèm hạn gần nhất); bật thêm "tự re-raise" thì tự chạy hàng đợi bổ sung bằng chứng luôn. */
const TT_SCAN_ALARM = 'op-tiktok-ticket-scan';
async function scheduleTikTokScan() {
  const { cancelReturnSettings: settings = {} } = await chrome.storage.local.get('cancelReturnSettings');
  if (settings.autoScan) chrome.alarms.create(TT_SCAN_ALARM, { periodInMinutes: Math.max(30, Number(settings.autoScanMinutes) || 120) });
  else chrome.alarms.clear(TT_SCAN_ALARM);
  return { ok: true, on: Boolean(settings.autoScan) };
}
async function autoScanTikTokTickets() {
  const tabs = await chrome.tabs.query({ url: 'https://seller-vn.tiktok.com/*' }).catch(() => []);
  if (!tabs.length) return;
  const { cancelReturnSettings: settings = {}, cancelReturnFollowRun: follow, cancelReturnRun: run } = await chrome.storage.local.get(['cancelReturnSettings', 'cancelReturnFollowRun', 'cancelReturnRun']);
  if ((follow && !follow.doneAt) || (run && !run.doneAt && !run.paused)) return;   // đang raise / phản hồi → để lượt sau
  const result = await scanTikTokTickets(settings.scanDays || 14, { reload: false }).catch(() => null);
  if (!result?.ok) return;
  if (result.need.length && settings.autoReraise) await startTikTokActionReraise(result.need).catch(() => null);
  if (result.need.length || result.closedAfterAsk.length) {
    const when = result.nextDeadline ? OPCancelReturn.vnTime(result.nextDeadline) : '';
    chrome.notifications?.create(`op-tt-scan-${Date.now()}`, { type: 'basic', iconUrl: 'icons/icon128.png', title: `TikTok: ${result.need.length} phiếu Cần có hành động`,
      message: `${result.need.length ? `Hạn gần nhất ${when}${settings.autoReraise ? ' · đang tự bổ sung bằng chứng' : ' — mở Side Panel › Đòi hàng › Theo dõi để re-raise'}` : ''}${result.closedAfterAsk.length ? ` · ${result.closedAfterAsk.length} phiếu đã đóng cần raise lại phiếu mới` : ''}`.replace(/^ · /, '') });
  }
}
chrome.alarms.onAlarm.addListener(alarm => { if (alarm.name === TT_SCAN_ALARM) autoScanTikTokTickets().catch(() => {}); });

/** Dòng tracker (có link biên bản) của đơn trong phiếu: nhóm đã raise trước, không có thì bất kỳ nhóm nào chứa mã đơn. */
function evidenceRowForTicket(ticket, groups) {
  const orders = new Set(ticket.orderIds || []);
  const own = ticket.groupId && groups[ticket.groupId];
  const pick = group => (group?.rows || []).find(row => orders.has(row.orderId));
  return pick(own) || Object.values(groups).map(pick).find(Boolean) || null;
}

/** Re-raise phiếu "Cần có hành động của bạn" / đóng sau yêu cầu bằng chứng: mở từng phiếu (1 tab dùng lại),
    điền nội dung bổ sung bằng chứng + đính kèm lại biên bản bàn giao → Gửi. Biên bản tải ngay trước khi mở từng phiếu. */
async function startTikTokActionReraise(ticketIds, customText = '') {
  return withTicketStateLock(async () => {
    const data = await chrome.storage.local.get(['cancelReturnTickets', 'cancelReturnFollowRun', 'cancelReturnGroups']);
    if (data.cancelReturnFollowRun && !data.cancelReturnFollowRun.doneAt) throw new Error('Đang theo dõi / phản hồi phiếu. Chờ xong hoặc bấm Dừng.');
    const tickets = { ...(data.cancelReturnTickets || {}) };
    const groups = data.cancelReturnGroups || {};
    // Phiếu đã đóng không trả lời được nữa → raise lại phiếu mới ở thẻ Raise. Hạn 24 giờ gần nhất chạy trước.
    const queue = [...new Set(ticketIds || [])].filter(id => tickets[id] && tickets[id].platform !== 'shopee' && !tickets[id].finished && ['reply', 'rebut'].includes(tickets[id].tiktok?.action))
      // Cần hành động (theo hạn 24 giờ) trước, phản biện sau.
      .sort((a, b) => (tickets[a].tiktok?.action === 'reply' ? OPCancelReturn.ttDeadline(tickets[a]) || 1 : Infinity) - (tickets[b].tiktok?.action === 'reply' ? OPCancelReturn.ttDeadline(tickets[b]) || 1 : Infinity));
    if (!queue.length) throw new Error('Không có phiếu "Cần có hành động" / cần phản biện — bấm Quét phiếu TikTok trước. Phiếu đã đóng: dùng Raise lại (phiếu mới).');
    for (const id of queue) {
      const ticket = tickets[id];
      const row = evidenceRowForTicket(ticket, groups);
      const links = [...new Set([...(row?.evidence || []), ...OPCancelReturn.evidenceLinks(ticket.replyText), ...OPCancelReturn.evidenceLinks(ticket.tiktok?.context)])]
        .filter(link => !/tiktok\.com/i.test(link)).slice(0, 3);
      // v2.2.75 — phản biện: nội dung sửa tay trên panel (rebutDraft) nếu có, không thì tự soạn theo câu trả lời của TikTok.
      const text = ticket.tiktok?.action === 'rebut' ? OPCancelReturn.rebuttalText(ticket, row, customText || ticket.rebutDraft) : OPCancelReturn.actionReplyText(ticket, row, customText);
      tickets[id] = { ...ticket, actionPlan: { text, links, row: row ? { orderId: row.orderId, trackingId: row.trackingId, sequence: row.sequence } : null, at: new Date().toISOString() } };
    }
    const follow = { id: `evidence_${Date.now()}`, mode: 'evidence', reuseTab: true, customText: '', queue, active: null, results: [], startedAt: new Date().toISOString(), doneAt: '' };
    await chrome.storage.local.set({ cancelReturnTickets: tickets, cancelReturnFollowRun: follow });
    crSchedule(CANCEL_RETURN_FOLLOW_ALARM, 200);
    return { ok: true, count: queue.length };
  });
}
/** v2.2.85 — đánh dấu / bỏ dấu "Đã theo dõi" (hiệu lực 24 giờ) cho 1 hoặc nhiều phiếu; ghi vào Ghi chú ticket trên tracker. */
async function setTicketsFollowed(ticketIds, on) {
  return withTicketStateLock(async () => {
    const { cancelReturnTickets: tickets = {}, cancelReturnTrackerOutbox: outbox } = await chrome.storage.local.get(['cancelReturnTickets', 'cancelReturnTrackerOutbox']);
    const now = new Date().toISOString();
    let next = outbox, count = 0;
    for (const id of [...new Set((ticketIds || []).map(String))]) {
      if (!tickets[id]) continue;
      tickets[id] = on ? { ...tickets[id], followedAt: now, followedBy: 'manual' } : { ...tickets[id], followedAt: '', followedBy: '' };
      if (tickets[id].kind !== 'general') next = queueTrackerWrite(next, id);
      count++;
    }
    await chrome.storage.local.set({ cancelReturnTickets: tickets, cancelReturnTrackerOutbox: next });
    if (count) scheduleTrackerWrite();
    return { ok: true, count };
  });
}
/** v2.2.83 — "Đã raise lại tay": đánh dấu phiếu cũ đã có phiếu mới (nhập số phiếu mới nếu biết) → hết báo "cần raise lại". */
async function markTikTokReraised(ticketId, newTicketId) {
  return withTicketStateLock(async () => {
    const { cancelReturnTickets: tickets = {}, cancelReturnTrackerOutbox: outbox, cancelReturnGroups: groups = {} } = await chrome.storage.local.get(['cancelReturnTickets', 'cancelReturnTrackerOutbox', 'cancelReturnGroups']);
    const ticket = tickets[ticketId];
    if (!ticket) throw new Error('Không tìm thấy phiếu.');
    const next = String(newTicketId || '').trim();
    if (next && !/^\d{8,30}$/.test(next)) throw new Error('Số phiếu mới phải là dãy số (vd 202611021112201234).');
    tickets[ticketId] = { ...ticket, reraisedTo: next || 'tay', reraisedAt: new Date().toISOString(), reraisedBy: 'manual' };
    // Bỏ phiếu raise lại còn chờ ở thẻ Raise (đã raise tay rồi → không raise thêm lần nữa).
    const cleaned = Object.fromEntries(Object.entries(groups).filter(([, group]) => !(group.reraiseOf?.ticketId === ticketId && !group.ticketId)));
    const update = { cancelReturnTickets: tickets, cancelReturnGroups: cleaned };
    if (ticket.kind !== 'general') update.cancelReturnTrackerOutbox = queueTrackerWrite(outbox, ticketId);
    await chrome.storage.local.set(update);
    if (ticket.kind !== 'general') scheduleTrackerWrite();
    return { ok: true, removedGroups: Object.keys(groups).length - Object.keys(cleaned).length };
  });
}
/** v2.2.75 — nội dung phản biện sửa tay trên panel (trống = tự soạn lại theo câu trả lời của TikTok). */
async function setTikTokRebutDraft(ticketId, text) {
  return withTicketStateLock(async () => {
    const { cancelReturnTickets: tickets = {} } = await chrome.storage.local.get('cancelReturnTickets');
    if (!tickets[ticketId]) throw new Error('Không tìm thấy phiếu.');
    tickets[ticketId] = { ...tickets[ticketId], rebutDraft: text.slice(0, OPCancelReturn.MAX_TEXT) };
    await chrome.storage.local.set({ cancelReturnTickets: tickets });
    return { ok: true };
  });
}
/** Tải biên bản của phiếu sắp re-raise vào bản lưu tạm (xóa ngay khi phiếu xong). */
async function prepareActionFiles(ticketId) {
  const { cancelReturnTickets: tickets = {}, cancelReturnReplyFiles: store = {} } = await chrome.storage.local.get(['cancelReturnTickets', 'cancelReturnReplyFiles']);
  const ticket = tickets[ticketId];
  if (!ticket?.actionPlan || store[ticketId]) return { files: store[ticketId]?.length || 0, errors: [] };
  const row = { orderId: ticket.actionPlan.row?.orderId || ticket.orderIds?.[0] || ticketId, trackingId: ticket.actionPlan.row?.trackingId || ticket.trackingIds?.[0] || '', sequence: ticket.actionPlan.row?.sequence || '' };
  const files = [], errors = [];
  for (const link of ticket.actionPlan.links || []) {
    try { const file = await crFetchEvidence(link, row, ticket.carrier || 'DVVC'); if (!files.some(item => item.name === file.name)) files.push(file); }
    catch (error) { errors.push(`${link.slice(0, 60)}…: ${error.message || error}`); }
  }
  if (files.length) await chrome.storage.local.set({ cancelReturnReplyFiles: { ...store, [ticketId]: files } });
  return { files: files.length, errors };
}

async function startCancelReturnFollowUp(ticketIds, mode, customText) {
  const startedMs = Date.now();
  const wanted = [...new Set(ticketIds || [])];
  // Chỉ chế độ "Kiểm tra & mở lại" mới lọc trước; "Nhắc phiếu ngay" luôn gửi.
  const bulk = mode === 'reply' || !wanted.length ? null : await fetchTicketStatusesBulk(wanted).catch(() => null);
  return withTicketStateLock(async () => {
    const data = await chrome.storage.local.get(['cancelReturnTickets', 'cancelReturnFollowRun', 'cancelReturnTrackerOutbox']);
    if (data.cancelReturnFollowRun && !data.cancelReturnFollowRun.doneAt) throw new Error('Đang theo dõi / phản hồi phiếu. Chờ xong hoặc bấm Dừng.');
    const tickets = { ...(data.cancelReturnTickets || {}) };
    // v2.2.67 — phiếu Shopee không re-raise / không mở lại qua tool.
    // v2.2.72 — phiếu đóng sau yêu cầu bằng chứng: không nhắc mở lại (TikTok không mở lại) → Raise lại phiếu mới.
    let queue = wanted.filter(id => tickets[id] && !tickets[id].finished && tickets[id].platform !== 'shopee' && !(mode !== 'reply' && tickets[id].tiktok?.action === 'new'));
    if (!queue.length) throw new Error(wanted.some(id => tickets[id]?.platform === 'shopee') ? 'Phiếu Shopee không re-raise — theo dõi ở seller-service.cs.shopee.vn → Yêu cầu của tôi.' : 'Không có phiếu cần theo dõi.');
    let checked = 0, open = 0, outbox = data.cancelReturnTrackerOutbox || {};
    if (bulk?.ok && bulk.statuses && typeof bulk.statuses === 'object') {
      const now = new Date().toISOString();
      const closed = [];
      for (const id of queue) {
        const item = bulk.statuses[id];
        if (!item) { closed.push(id); continue; }  // không thấy trong danh sách (khác shop / lỗi) → mở trang để kiểm tra như cũ
        checked++;
        const label = BULK_STATUS_LABEL[item.status] || `Trạng thái ${item.status}`;
        const changed = tickets[id].lastStatus !== label;
        tickets[id] = { ...tickets[id], lastStatus: label, lastCheckedAt: now };
        if (changed && tickets[id].kind !== 'general') outbox = queueTrackerWrite(outbox, id);
        if (item.status === '1') open++; else closed.push(id);
      }
      queue = closed;
      await chrome.storage.local.set({ cancelReturnTickets: tickets, cancelReturnTrackerOutbox: outbox });
      scheduleTrackerWrite();
    }
    const summary = bulk?.ok && bulk.statuses ? { checked, open, reopen: queue.length, seconds: Math.round((Date.now() - startedMs) / 1000) } : null;
    if (!queue.length) return { ok: true, count: 0, summary };
    // Dùng lại đúng 1 tab cho mọi phiếu (không mở/đóng tab từng phiếu).
    const follow = { id: `follow_${Date.now()}`, mode: mode === 'reply' ? 'reply' : 'auto', reuseTab: true, customText: String(customText || '').slice(0, OPCancelReturn.MAX_TEXT), queue, active: null, results: [], startedAt: new Date().toISOString(), doneAt: '', summary };
    await chrome.storage.local.set({ cancelReturnFollowRun: follow });
    crSchedule(CANCEL_RETURN_FOLLOW_ALARM, 200);
    return { ok: true, count: queue.length, summary };
  });
}

async function stopCancelReturnFollowUp() {
  const tabId = await withTicketStateLock(async () => {
    const { cancelReturnFollowRun: follow } = await chrome.storage.local.get('cancelReturnFollowRun');
    if (!follow || follow.doneAt) return null;
    const active = follow.active?.sendingAt ? null : follow.active?.tabId;
    follow.queue = []; follow.doneAt = new Date().toISOString(); follow.stopped = true;
    const update = {};
    if (!follow.active?.sendingAt) {
      // Dừng phản hồi sau raise → tạm dừng cả hàng đợi raise (bấm Tiếp tục để phản hồi lại phiếu đó).
      if (follow.mode === 'post_raise') {
        const { cancelReturnRun: run } = await chrome.storage.local.get('cancelReturnRun');
        if (run?.awaitingReply?.ticketId === follow.active?.ticketId) update.cancelReturnRun = { ...run, paused: true, awaitingReply: { ...run.awaitingReply, tabId: null }, error: `Đã dừng trước khi phản hồi lại phiếu #${follow.active.ticketId}. Bấm Tiếp tục để phản hồi rồi raise ĐVVC kế.` };
      }
      follow.active = null;
    }
    await chrome.storage.local.set({ cancelReturnFollowRun: follow, ...update });
    return active;
  });
  if (tabId) { try { await chrome.tabs.remove(tabId); } catch (_) {} }
  return { ok: true };
}

async function advanceCancelReturnFollowUp() {
  // v2.2.60 — đọc tên shop NGOÀI khóa; làn tin bổ sung sau raise bỏ qua bước này (phiếu vừa raise đúng shop đang mở).
  const { cancelReturnFollowRun: peek } = await chrome.storage.local.get('cancelReturnFollowRun');
  const shopNow = peek && !peek.doneAt && !peek.active && peek.queue?.length && !peek.lane ? await getLoggedInMarketplaceShop('tiktok') : null;
  // v2.2.72 — re-raise "Cần có hành động": tải biên bản của phiếu kế NGOÀI khóa (tối đa 20 giây/link).
  const prepared = peek?.mode === 'evidence' && !peek.doneAt && !peek.active && peek.queue?.[0] ? await prepareActionFiles(peek.queue[0]).catch(error => ({ files: 0, errors: [error.message || String(error)] })) : null;
  let reopen = null;
  const closeTab = await withTicketStateLock(async () => {
    const data = await chrome.storage.local.get(['cancelReturnFollowRun', 'cancelReturnTickets']);
    const follow = data.cancelReturnFollowRun;
    if (!follow || (follow.doneAt && !follow.active)) return null;
    if (follow.active) {
      const limit = followTimeout(follow);
      if (Date.now() - Date.parse(follow.active.openedAt) < limit) {
        chrome.alarms.create(CANCEL_RETURN_FOLLOW_ALARM, { when: Date.now() + 15000 });
        return null;
      }
      const stale = follow.active;
      // v2.2.64 — làn phụ quá hạn lần đầu (script trang chết / trang treo): mở lại đúng phiếu 1 lần.
      // Dấu "đã bấm Gửi" (sendingAt) giữ nguyên → trang mới chỉ kiểm tra luồng, không gửi trùng.
      if (follow.lane && !follow.doneAt && !stale.retried) {
        follow.active = { ...stale, retried: true, openedAt: new Date().toISOString() };
        await chrome.storage.local.set({ cancelReturnFollowRun: follow });
        chrome.alarms.create(CANCEL_RETURN_FOLLOW_ALARM, { when: Date.now() + limit + 1000 });
        reopen = { tabId: stale.tabId, ticketId: stale.ticketId };
        return null;
      }
      await finishFollowUpLocked(follow, data.cancelReturnTickets || {}, { ok: false, error: stale.sendingAt ? `Đã bấm Gửi nhưng quá ${limit / 1000} giây chưa xác nhận — mở phiếu kiểm tra lại.` : `Quá ${limit / 1000} giây chưa phản hồi xong trên trang phiếu.` });
      return stale.tabId;
    }
    const ticketId = follow.queue.shift();
    if (!ticketId) {
      follow.doneAt = follow.doneAt || new Date().toISOString();
      await chrome.storage.local.set({ cancelReturnFollowRun: follow });
      if (follow.reuseTab && follow.replyTabId) return follow.replyTabId;
      // Làn phản hồi song song: hàng đợi raise đã xong và hết phiếu chờ → đóng tab phụ.
      if (follow.lane && follow.replyTabId) {
        const { cancelReturnRun: run } = await chrome.storage.local.get('cancelReturnRun');
        if (!run || run.doneAt) return follow.replyTabId;
      }
      return null;
    }
    const ticket = data.cancelReturnTickets?.[ticketId];
    const shop = follow.lane ? { ok: true, name: ticket?.shopName || '' } : (shopNow || await getLoggedInMarketplaceShop('tiktok'));
    if (!shop.ok || (ticket?.shopName && shop.name !== ticket.shopName)) {
      follow.results.push({ ticketId, ok: false, at: new Date().toISOString(), error: shop.ok ? `Phiếu thuộc shop ${ticket.shopName}, đang đăng nhập ${shop.name}.` : shop.error });
      if (follow.mode === 'evidence') {
        const { cancelReturnReplyFiles: store } = await chrome.storage.local.get('cancelReturnReplyFiles');
        if (store?.[ticketId]) { const keep = { ...store }; delete keep[ticketId]; await chrome.storage.local.set({ cancelReturnReplyFiles: keep }); }
      }
      await chrome.storage.local.set({ cancelReturnFollowRun: follow });
      crSchedule(CANCEL_RETURN_FOLLOW_ALARM, 200);
      return null;
    }
    // Nhắc phiếu (bấm tay hoặc phiếu đã đóng): mở thẳng link phiếu; bấm tay chạy ở tab trước mặt, kiểm tra hàng loạt ở tab nền.
    // v2.2.50 — làn phản hồi song song: dùng lại đúng 1 tab phụ cho mọi phiếu.
    let tab = (follow.lane || follow.reuseTab) && follow.replyTabId ? await chrome.tabs.get(Number(follow.replyTabId)).catch(() => null) : null;
    if (!tab?.id) tab = await chrome.tabs.create({ url: 'about:blank', active: follow.mode === 'reply' });
    if (follow.lane || follow.reuseTab) follow.replyTabId = tab.id;
    // v2.2.28 — nhắc phiếu chỉ gửi nội dung nhắc, KHÔNG đính kèm lại file (file chỉ gửi lại 1 lần ngay sau khi raise).
    const { cancelReturnRun: run, cancelReturnReplyFiles: replyFiles = {} } = await chrome.storage.local.get(['cancelReturnRun', 'cancelReturnReplyFiles']);
    const evidence = follow.mode === 'evidence';
    const text = evidence ? String(ticket?.actionPlan?.text || OPCancelReturn.actionReplyText(ticket)).slice(0, OPCancelReturn.MAX_TEXT)
      : follow.lane ? String(ticket?.replyText || ticket?.text || '').slice(0, OPCancelReturn.MAX_TEXT) : OPCancelReturn.followUpText(ticket, follow.customText);
    follow.active = { ticketId, tabId: tab.id, openedAt: new Date().toISOString(), text, attach: evidence ? (replyFiles[ticketId] || []).length : 0,
      ...(evidence && prepared?.errors?.length ? { fileErrors: prepared.errors.slice(0, 3) } : {}), sendingAt: run?.awaitingReply?.ticketId === ticketId ? run.awaitingReply.sendingAt || '' : '', baselineCount: run?.awaitingReply?.ticketId === ticketId ? run.awaitingReply.baselineCount ?? null : null };
    await chrome.storage.local.set({ cancelReturnFollowRun: follow });
    await chrome.tabs.update(tab.id, { url: TIKTOK_TICKET_DETAIL_URL(ticketId), active: follow.mode === 'reply' });
    chrome.alarms.create(CANCEL_RETURN_FOLLOW_ALARM, { when: Date.now() + followTimeout(follow) + 1000 });
    return null;
  });
  if (reopen) await chrome.tabs.update(Number(reopen.tabId), { url: TIKTOK_TICKET_DETAIL_URL(reopen.ticketId) }).catch(() => {});
  if (closeTab) {
    try { await chrome.tabs.remove(closeTab); } catch (_) {}
    crSchedule(CANCEL_RETURN_FOLLOW_ALARM, 300);
  }
}

async function finishFollowUpLocked(follow, ticketsValue, result) {
  const active = follow.active;
  const extra = await chrome.storage.local.get(['cancelReturnTrackerOutbox', 'cancelReturnReplyFiles', 'cancelReturnRun']);
  const pending = extra.cancelReturnRun?.awaitingReply?.ticketId === active.ticketId ? extra.cancelReturnRun.awaitingReply : null;
  // Bấm Gửi chưa đủ: chỉ mở khóa khi tin đã lên luồng và đủ file của phiếu.
  const expectedFiles = Math.max(Number(active.attach || 0), pending ? Number(pending.attach ?? extra.cancelReturnReplyFiles?.[active.ticketId]?.length ?? 0) : 0);
  // v2.2.36 — tin đã lên luồng là xong; nếu không tải lại được file (biên bản đã có ở tin đầu) vẫn mở khóa đơn kế.
  const replyComplete = Boolean(result.ok && result.replied && (Number(result.attached || 0) >= expectedFiles || result.attachSkipped));
  if ((pending || result.replied) && result.ok && !replyComplete) result = { ...result, ok: false, replied: false, error: 'Chưa xác nhận phản hồi kèm đủ file — chưa mở ĐVVC kế.' };
  const tickets = { ...ticketsValue };
  const now = new Date().toISOString();
  const ticket = tickets[active.ticketId];
  if (ticket) {
    const entry = { at: now, kind: follow.mode, attached: result.attached || 0, status: result.status || '', statusAfter: result.statusAfter || '', replied: Boolean(result.replied), ok: Boolean(result.ok), error: result.error || '', ...(result.replied ? { text: active.text } : {}), ...(active.fileErrors ? { fileErrors: active.fileErrors } : {}) };
    // v2.2.72 — đã bổ sung bằng chứng → hết "Cần hành động" (lần quét sau không đưa lại, trừ khi TikTok nhắn yêu cầu mới).
    const evidenceDone = follow.mode === 'evidence' && result.ok && result.replied;
    // v2.2.85 — tool vừa gửi tin trên phiếu (re-raise, phản biện, nhắc, tin bổ sung) → tự đánh dấu "Đã theo dõi" 24 giờ.
    tickets[active.ticketId] = { ...ticket, lastStatus: result.statusAfter || result.status || ticket.lastStatus, lastCheckedAt: now, ...(result.replied ? { lastReplyAt: now, replyCount: (ticket.replyCount || 0) + 1, ...(result.ok ? { followedAt: now, followedBy: 'tool' } : {}) } : {}),
      ...(evidenceDone ? { evidenceReplyAt: now, ...(ticket.tiktok?.action === 'rebut' ? { rebuttedAt: now, rebutCount: (ticket.rebutCount || 0) + 1 } : {}),
        tiktok: { ...(ticket.tiktok || {}), action: '', needAction: false, ...(ticket.tiktok?.reply ? { reply: { ...ticket.tiktok.reply, shopLast: true } } : {}) } } : {}), followUps: [...(ticket.followUps || []), entry].slice(-30) };
  }
  follow.results.push({ ticketId: active.ticketId, at: now, ...result });
  follow.active = null;
  // v2.2.64 — làn phụ: phiếu vừa tạo đôi khi chưa mở được trang chi tiết ngay → chưa bấm Gửi thì xếp lại cuối hàng 1 lần.
  if (follow.lane && !follow.doneAt && !result.ok && !active.sendingAt && !follow.retries?.[active.ticketId]) {
    follow.retries = { ...(follow.retries || {}), [active.ticketId]: 1 };
    follow.queue.push(active.ticketId);
  }
  if (!follow.queue.length) follow.doneAt = follow.doneAt || now;
  const update = { cancelReturnFollowRun: follow, cancelReturnTickets: tickets, ...(ticket && ticket.kind !== 'general' ? { cancelReturnTrackerOutbox: queueTrackerWrite(extra.cancelReturnTrackerOutbox, active.ticketId) } : {}) };
  // Đã gửi lại kèm đủ file → bỏ bản lưu file (cả làn song song). Lỗi → giữ để "Mở & phản hồi ngay" đính kèm lại.
  // Re-raise "Cần hành động": biên bản tải lại được bất cứ lúc nào → luôn xóa bản lưu tạm (không để storage phình).
  if ((replyComplete || follow.mode === 'evidence') && extra.cancelReturnReplyFiles?.[active.ticketId]) {
    const files = { ...extra.cancelReturnReplyFiles }; delete files[active.ticketId]; update.cancelReturnReplyFiles = files;
  }
  // Lỗi/timeout/đóng tab: giữ đúng phiếu + file, tạm dừng hàng đợi để Tiếp tục thử lại phiếu đó.
  const run = extra.cancelReturnRun;
  let next = false;
  if (run?.awaitingReply?.ticketId === active.ticketId) {
    if (replyComplete) {
      update.cancelReturnRun = { ...run, awaitingReply: null, error: '', lastReplyError: '' };
      next = !run.paused;
    } else {
      const error = `Phiếu #${active.ticketId}: ${result.error || 'chưa xác nhận đã gửi phản hồi kèm đủ file'}`;
      update.cancelReturnRun = { ...run, paused: true, awaitingReply: { ...run.awaitingReply, tabId: active.tabId, sendingAt: active.sendingAt || run.awaitingReply.sendingAt || '', baselineCount: active.baselineCount ?? run.awaitingReply.baselineCount ?? null }, error: `${error}. Chưa mở ĐVVC kế.`, lastReplyError: error };
    }
  }
  await chrome.storage.local.set(update);
  if (ticket && ticket.kind !== 'general') scheduleTrackerWrite();
  if (next) crSchedule(CANCEL_RETURN_NEXT_ALARM, 300);
  return Boolean(result.ok);
}

async function followUpContextForTab(tab) {
  const tabId = tab?.id;
  // Tab phiếu do "Kiểm tra chi tiết" mở ra (opener = tab Nhật ký phiếu) nhận tiếp việc phản hồi.
  const adopted = await withTicketStateLock(async () => {
    const { cancelReturnFollowRun: follow } = await chrome.storage.local.get('cancelReturnFollowRun');
    const active = follow?.active;
    if (!active || Number(active.tabId) === Number(tabId)) return null;
    const detailId = (String(tab?.url || '').match(/\/ticket\/detail\/(\d+)/) || [])[1];
    if (detailId !== active.ticketId || Number(tab?.openerTabId) !== Number(active.tabId) || active.sendingAt) return null;
    active.listTabId = active.tabId; active.tabId = tabId; active.adoptedAt = new Date().toISOString();
    await chrome.storage.local.set({ cancelReturnFollowRun: follow });
    return active.listTabId;
  });
  if (adopted) setTimeout(() => { chrome.tabs.remove(adopted).catch(() => {}); }, 15000);
  const { cancelReturnFollowRun: follow } = await chrome.storage.local.get('cancelReturnFollowRun');
  const active = follow?.active;
  if (!active || Number(active.tabId) !== Number(tabId)) return { ok: false };
  const { cancelReturnReplyFiles: store = {} } = active.attach ? await chrome.storage.local.get('cancelReturnReplyFiles') : {};
  const names = active.attach ? (store[active.ticketId] || []).map(file => file.name) : [];
  return { ok: true, ticketId: active.ticketId, text: active.text, mode: follow.mode, sendingAt: active.sendingAt, baselineCount: active.baselineCount ?? null, attachCount: active.attach || 0, attachNames: names };
}

async function markFollowUpSending(tabId, ticketId, baselineCount) {
  return withTicketStateLock(async () => {
    const { cancelReturnFollowRun: follow } = await chrome.storage.local.get('cancelReturnFollowRun');
    const active = follow?.active;
    if (!active || Number(active.tabId) !== Number(tabId) || active.ticketId !== ticketId) return { ok: false, error: 'Tab không còn trong hàng đợi phản hồi.' };
    if (active.sendingAt) return { ok: false, alreadySent: true, error: 'Đã bấm Gửi trước đó, không gửi lại.' };
    active.sendingAt = new Date().toISOString();
    active.baselineCount = Number.isSafeInteger(baselineCount) && baselineCount >= 0 ? baselineCount : null;
    const { cancelReturnRun: run } = await chrome.storage.local.get('cancelReturnRun');
    await chrome.storage.local.set({ cancelReturnFollowRun: follow, ...(run?.awaitingReply?.ticketId === ticketId ? { cancelReturnRun: { ...run, awaitingReply: { ...run.awaitingReply, sendingAt: active.sendingAt, baselineCount: active.baselineCount } } } : {}) });
    return { ok: true };
  });
}

/** Click thật (debugger) cho tab đang làm phản hồi phiếu — chỉ tab nằm trong hàng đợi. */
async function clickForFollowUp(tabId, message) {
  const { cancelReturnFollowRun: follow } = await chrome.storage.local.get('cancelReturnFollowRun');
  if (!follow?.active || Number(follow.active.tabId) !== Number(tabId)) return { ok: false, error: 'Tab không còn trong hàng đợi phản hồi.' };
  try { return await queueTrustedBrowserClick(tabId, { x: message.x, y: message.y }); }
  catch (error) { return { ok: false, error: error.message || String(error) }; }
}

async function reportFollowUpResult(tabId, result) {
  const done = await withTicketStateLock(async () => {
    const data = await chrome.storage.local.get(['cancelReturnFollowRun', 'cancelReturnTickets']);
    const follow = data.cancelReturnFollowRun;
    if (!follow?.active || Number(follow.active.tabId) !== Number(tabId) || follow.active.ticketId !== result?.ticketId) return false;
    const mode = follow.mode, reuse = Boolean(follow.reuseTab || follow.lane);
    const success = await finishFollowUpLocked(follow, data.cancelReturnTickets || {}, {
      ok: Boolean(result.ok), status: String(result.status || '').slice(0, 60), statusAfter: String(result.statusAfter || '').slice(0, 60),
      replied: Boolean(result.replied), attached: Number(result.attached) || 0, attachSkipped: Boolean(result.attachSkipped), error: String(result.error || '').slice(0, 300)
    });
    return { success, mode, reuse };
  });
  if (done) {
    // Để người dùng thấy tin nhắn vừa gửi rồi mới đóng tab phiếu. v2.2.45 — phản hồi sau raise: giữ tab để raise đơn kế ngay trên tab này.
    if (done.success && done.mode !== 'post_raise' && !done.reuse) setTimeout(() => { chrome.tabs.remove(tabId).catch(() => {}); }, 4000);
    crSchedule(CANCEL_RETURN_FOLLOW_ALARM, 300);
  }
  return { ok: Boolean(done) };
}

async function setCancelReturnTicketFinished(ticketId, finished) {
  return withTicketStateLock(async () => {
    const { cancelReturnTickets: tickets = {}, cancelReturnTrackerOutbox: outbox } = await chrome.storage.local.get(['cancelReturnTickets', 'cancelReturnTrackerOutbox']);
    if (!tickets[ticketId]) throw new Error('Không tìm thấy phiếu.');
    tickets[ticketId] = { ...tickets[ticketId], finished: Boolean(finished), finishedAt: finished ? new Date().toISOString() : '' };
    const general = tickets[ticketId].kind === 'general';
    await chrome.storage.local.set({ cancelReturnTickets: tickets, ...(general ? {} : { cancelReturnTrackerOutbox: queueTrackerWrite(outbox, ticketId) }) });
    if (!general) scheduleTrackerWrite();
    return { ok: true };
  });
}

/* ------------------------------------------- ghi ngược tracker SharePoint (v2.2.21) --- */
// Hàng đợi bền: ticketId → {queuedAt, attempts, error}. Ghi lại toàn bộ 6 cột mỗi lần (idempotent).
function queueTrackerWrite(outbox, ticketId) {
  return { ...(outbox || {}), [ticketId]: { queuedAt: new Date().toISOString(), attempts: 0, error: '' } };
}
// v2.2.64 — gom ghi tracker: chờ 8 giây sau thay đổi cuối (raise liên tục chỉ mở tab SharePoint 1 lần cho cả loạt).
function scheduleTrackerWrite(delayMs = 8000) { chrome.alarms.create(CANCEL_RETURN_TRACKER_ALARM, { when: Date.now() + delayMs }); }

const spListApi = () => `${OPCancelReturn.TRACKER_SITE}/_api/web/lists/getbytitle('${encodeURIComponent(OPCancelReturn.TRACKER_LIST).replace(/'/g, "''")}')`;
let spDigest = null;
async function spFetch(url, init = {}) {
  const response = await fetch(url, { credentials: 'include', cache: 'no-store', ...init, headers: { Accept: 'application/json;odata=nometadata', ...(init.headers || {}) } });
  if (/text\/html/i.test(response.headers.get('content-type') || '')) throw new Error('SharePoint yêu cầu đăng nhập — mở onpointvn.sharepoint.com trên Chrome này rồi bấm Ghi lại tracker.');
  if (response.status === 401 || response.status === 403) {
    // v2.2.31 — SharePoint trả 403 cho MỌI lệnh (kể cả "tôi là ai") khi phiên đăng nhập hết hạn / Microsoft đòi nhập lại mật khẩu.
    const who = await fetch(`${OPCancelReturn.TRACKER_SITE}/_api/web/currentuser?$select=Title`, { credentials: 'include', cache: 'no-store', headers: { Accept: 'application/json;odata=nometadata' } }).then(r => r.ok ? r.json() : null).catch(() => null);
    if (!who?.Title) throw new Error(`Phiên đăng nhập SharePoint trên Chrome đã hết hạn hoặc Microsoft yêu cầu nhập lại mật khẩu (HTTP ${response.status}) → bấm "Đăng nhập lại SharePoint" bên dưới, đăng nhập xong bấm "Ghi lại tracker cho tất cả phiếu".`);
    throw new Error(`Tài khoản SharePoint "${who.Title}" chưa có quyền xem/sửa List "${OPCancelReturn.TRACKER_LIST}" (HTTP ${response.status}) → nhờ chủ site cấp quyền Edit (link "Trang cấp quyền List" bên dưới).`);
  }
  if (!response.ok) { let detail = ''; try { detail = (await response.json())['odata.error']?.message?.value || ''; } catch (_) {} throw new Error(`SharePoint HTTP ${response.status}${detail ? `: ${detail}` : ''}`); }
  return response;
}
async function spRequestDigest() {
  if (spDigest && spDigest.until > Date.now()) return spDigest.value;
  const json = await (await spFetch(`${OPCancelReturn.TRACKER_SITE}/_api/contextinfo`, { method: 'POST' })).json();
  if (!json.FormDigestValue) throw new Error('SharePoint không trả mã xác thực ghi (FormDigest).');
  spDigest = { value: json.FormDigestValue, until: Date.now() + Math.max(60, (Number(json.FormDigestTimeoutSeconds) || 1800) - 120) * 1000 };
  return spDigest.value;
}
const odataText = value => `'${String(value).replace(/'/g, "''")}'`;
/** Tìm item theo order_no (Title); thiếu order_no thì theo ecom_order_code. Trả Map orderId → item. */
async function spFindItems(ticket) {
  const found = new Map();
  const wanted = (ticket.orderIds || []).map((orderId, index) => ({ orderId, orderNo: ticket.orderNos?.[index] || '' }));
  for (let start = 0; start < wanted.length; start += 15) {
    const part = wanted.slice(start, start + 15);
    const filter = part.map(item => item.orderNo ? `(Title eq ${odataText(item.orderNo)})` : `(ecom_order_code eq ${odataText(item.orderId)})`).join(' or ');
    const json = await (await spFetch(`${spListApi()}/items?$select=Id,Title,ecom_order_code,TicketId&$top=100&$filter=${encodeURIComponent(filter)}`)).json();
    for (const item of json.value || []) {
      const match = part.find(entry => (entry.orderNo && entry.orderNo === item.Title) || String(item.ecom_order_code || '') === entry.orderId);
      if (match) found.set(match.orderId, item);
    }
  }
  return found;
}
/* v2.2.29 — Kiểm tra quyền trước khi ghi. Chrome đăng nhập SharePoint bằng tài khoản không có quyền trên List
   thì REST trả 200 + 0 dòng (không lỗi) → trước đây tool báo nhầm "đã ghi (0 dòng)". */
let spAccess = null;
async function spCheckAccess() {
  if (spAccess && spAccess.until > Date.now()) { if (spAccess.error) throw new Error(spAccess.error); return spAccess; }
  const [list, user] = await Promise.all([
    spFetch(`${spListApi()}?$select=ItemCount,EffectiveBasePermissions`).then(r => r.json()),
    spFetch(`${OPCancelReturn.TRACKER_SITE}/_api/web/currentuser?$select=Title,Email`).then(r => r.json()).catch(() => ({}))
  ]);
  const low = Number(list.EffectiveBasePermissions?.Low || 0);
  const who = [user.Title, user.Email].filter(Boolean).join(' · ') || 'không rõ';
  const canView = Boolean(low & 1), canEdit = Boolean(low & 4);
  const error = canView && canEdit ? '' : `Tài khoản SharePoint đang đăng nhập trên Chrome (${who}) ${canView ? 'chỉ được xem, không được sửa' : 'không có quyền xem/sửa'} List "${OPCancelReturn.TRACKER_LIST}" → chưa ghi được Ticket ID vào tracker FG_Phan_hoi_tong.xlsx. Đăng nhập onpointvn.sharepoint.com bằng tài khoản có quyền sửa List (hoặc nhờ chủ List cấp quyền Edit cho tài khoản này), rồi bấm "Ghi lại tracker cho tất cả phiếu".`;
  spAccess = { who, canView, canEdit, error, until: Date.now() + 2 * 60 * 1000 };
  if (error) throw new Error(error);
  return spAccess;
}
/* v2.2.36 — SharePoint trả 403 cho lệnh GHI gửi từ extension (nguồn chrome-extension://) dù tài khoản có quyền Edit
   (đo 30/10: cùng tài khoản, ghi từ trang SharePoint = 200). → Mọi lệnh ghi tracker chạy BÊN TRONG 1 tab SharePoint (MAIN world). */
function pageTrackerWrite(plan) {
  // Chạy trong trang onpointvn.sharepoint.com — tự chứa, không dùng biến ngoài.
  const h = { Accept: 'application/json;odata=nometadata' };
  const api = `${plan.site}/_api/web/lists/getbytitle('${encodeURIComponent(plan.list).replace(/'/g, "''")}')`;
  const get = url => fetch(url, { credentials: 'include', cache: 'no-store', headers: h });
  const q = value => `'${String(value).replace(/'/g, "''")}'`;
  const page = String(globalThis.location?.href || '').slice(0, 120);
  return (async () => {
    const who = await get(`${plan.site}/_api/web/currentuser?$select=Title`).then(r => r.ok ? r.json() : null).catch(() => null);
    if (!who?.Title) return { error: 'session' };
    const listRes = await get(`${api}?$select=ItemCount,EffectiveBasePermissions`);
    if (!listRes.ok) return { error: 'http', status: listRes.status, who: who.Title, step: 'list', page };
    const list = await listRes.json();
    const low = Number(list.EffectiveBasePermissions?.Low || 0);
    if (!(low & 1) || !(low & 4)) return { error: 'permission', who: who.Title, canView: Boolean(low & 1), low, page };
    const found = new Map();
    for (let start = 0; start < plan.wanted.length; start += 15) {
      const part = plan.wanted.slice(start, start + 15);
      const filter = part.map(item => item.orderNo ? `(Title eq ${q(item.orderNo)})` : `(ecom_order_code eq ${q(item.orderId)})`).join(' or ');
      const res = await get(`${api}/items?$select=Id,Title,ecom_order_code,TicketId&$top=100&$filter=${encodeURIComponent(filter)}`);
      if (!res.ok) return { error: 'http', status: res.status, who: who.Title };
      for (const item of (await res.json()).value || []) {
        const match = part.find(entry => (entry.orderNo && entry.orderNo === item.Title) || String(item.ecom_order_code || '') === entry.orderId);
        if (match) found.set(match.orderId, item);
      }
    }
    const missing = plan.wanted.map(item => item.orderId).filter(orderId => !found.has(orderId));
    if (!found.size) return { written: 0, missing, conflicts: [], who: who.Title };
    const ctx = await fetch(`${plan.site}/_api/contextinfo`, { method: 'POST', credentials: 'include', headers: h });
    if (!ctx.ok) return { error: 'http', status: ctx.status, who: who.Title, step: 'contextinfo' };
    const digest = (await ctx.json()).FormDigestValue;
    const conflicts = []; let written = 0;
    for (const [orderId, item] of found) {
      // v2.2.90 — phiếu RAISE LẠI được thay Ticket ID cũ (đúng phiếu nó raise lại từ đó); phiếu lạ khác vẫn không ghi đè.
      if (item.TicketId && String(item.TicketId) !== String(plan.ticketId) && !(plan.replaces || []).includes(String(item.TicketId))) { conflicts.push(`${orderId} đã có Ticket ${item.TicketId}`); continue; }
      const res = await fetch(`${api}/items(${Number(item.Id)})`, { method: 'POST', credentials: 'include',
        headers: { ...h, 'Content-Type': 'application/json;odata=nometadata', 'IF-MATCH': '*', 'X-HTTP-Method': 'MERGE', 'X-RequestDigest': digest },
        body: JSON.stringify(plan.fields[orderId]) });
      if (!res.ok) return { error: 'http', status: res.status, who: who.Title, step: 'merge', written };
      written++;
    }
    return { written, missing, conflicts, who: who.Title };
  })();
}
/** Tab SharePoint để chạy lệnh ghi: dùng tab đang mở của site nếu có, không thì mở ngầm 1 tab (tự đóng sau lượt ghi). */
let spKeptTab = null; // v2.2.64 — tab SharePoint giữ lại giữa các lượt ghi khi hàng đợi raise còn chạy
async function spWorkTab(state) {
  if (state.tabId) return state.tabId;
  if (spKeptTab) {
    const kept = await chrome.tabs.get(spKeptTab).catch(() => null);
    spKeptTab = null;
    if (kept?.id && kept.status === 'complete' && /^https:\/\/onpointvn\.sharepoint\.com\//.test(kept.url || '')) { state.tabId = kept.id; state.created = true; return kept.id; }
  }
  // v2.2.38 — luôn mở tab riêng đúng trang API của site (không dùng lại tab SharePoint bất kỳ: trang lỗi quyền / Excel Online…).
  const tab = await chrome.tabs.create({ url: `${OPCancelReturn.TRACKER_SITE}/_api/web?$select=Title`, active: false });
  state.tabId = tab.id; state.created = true;
  for (let i = 0; i < 60; i++) {
    const current = await chrome.tabs.get(tab.id).catch(() => null);
    if (!current) break;
    if (current.url && !/^https:\/\/onpointvn\.sharepoint\.com\//.test(current.url)) throw new Error('Phiên đăng nhập SharePoint trên Chrome đã hết hạn hoặc Microsoft yêu cầu nhập lại mật khẩu → bấm "Mở List FG Recon Tracking" trên panel, đăng nhập xong bấm "Ghi lại tracker cho tất cả phiếu".');
    if (!current.status || current.status === 'complete') break;
    await new Promise(resolve => setTimeout(resolve, 300));
  }
  return tab.id;
}
async function writeTicketToTracker(ticket, state = {}) {
  const wanted = (ticket.orderIds || []).map((orderId, index) => ({ orderId, orderNo: ticket.orderNos?.[index] || '' }));
  const fields = Object.fromEntries(wanted.map(item => [item.orderId, OPCancelReturn.trackerFields(ticket, item.orderId)]));
  const tabId = await spWorkTab(state);
  const results = await chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', func: pageTrackerWrite,
    args: [{ site: OPCancelReturn.TRACKER_SITE, list: OPCancelReturn.TRACKER_LIST, ticketId: String(ticket.TicketID), wanted, fields, replaces: ticket.reraiseOf ? [String(ticket.reraiseOf)] : [] }] });
  const result = results?.[0]?.result;
  if (!result) throw new Error('Tab SharePoint chưa trả kết quả ghi — thử lại.');
  if (result.error === 'session') throw new Error('Phiên đăng nhập SharePoint trên Chrome đã hết hạn hoặc Microsoft yêu cầu nhập lại mật khẩu (HTTP 403) → bấm "Mở List FG Recon Tracking" trên panel, đăng nhập xong bấm "Ghi lại tracker cho tất cả phiếu".');
  if (result.error === 'permission') throw new Error(`Tài khoản SharePoint "${result.who}" ${result.canView ? 'chỉ được xem, không được sửa' : 'không có quyền xem/sửa'} List "${OPCancelReturn.TRACKER_LIST}" (quyền ${result.low}) → nhờ chủ site cấp quyền Edit (link "Trang cấp quyền List" trên panel), rồi bấm "Ghi lại tracker cho tất cả phiếu".`);
  if (result.error) throw new Error(`SharePoint từ chối ${result.step === 'merge' ? 'lệnh ghi' : result.step === 'contextinfo' ? 'mã xác thực ghi' : result.step === 'list' ? 'lệnh đọc List' : 'lệnh đọc'} (HTTP ${result.status}, tài khoản "${result.who}").`);
  if (!result.written && result.missing.length === wanted.length) throw new Error(`Không tìm thấy dòng nào của phiếu #${ticket.TicketID} trong List "${OPCancelReturn.TRACKER_LIST}" (order_no ${(ticket.orderNos || []).filter(Boolean).join(', ') || '(trống)'}).`);
  return result;
}/* v2.2.65 — đọc Ticket ID đã ghi trên List "FG Recon Tracking" (FG_v2_Mirror KHÔNG chép cột Ticket sang sheet Tracking của Excel,
   nên trước đây tool chỉ biết đơn đã raise qua bộ nhớ Chrome này → đơn raise ở máy/Chrome khác hoặc ghi tay trên SharePoint vẫn bị bắt raise lại).
   Chạy trong tab SharePoint (MAIN world) như lệnh ghi; chỉ đọc. */
function pageTrackerTickets(plan) {
  const h = { Accept: 'application/json;odata=nometadata' };
  const api = `${plan.site}/_api/web/lists/getbytitle('${encodeURIComponent(plan.list).replace(/'/g, "''")}')`;
  return (async () => {
    const items = [];
    let url = `${api}/items?$select=Id,Title,ecom_order_code,TicketId,TicketNote&$top=2000`;
    for (let page = 0; url && page < 50; page++) {
      const res = await fetch(url, { credentials: 'include', cache: 'no-store', headers: h });
      if (res.status === 401 || res.status === 403) return { error: 'session', status: res.status, items };
      if (!res.ok) return { error: 'http', status: res.status, items };
      const json = await res.json();
      // Phiếu gộp nhiều đơn: TicketNote ghi "(đại diện <mã đơn>)" — chỉ đơn đại diện được tính là đã raise (v2.2.34).
      for (const item of json.value || []) if (String(item.TicketId ?? '').trim()) items.push({ orderNo: String(item.Title || ''), orderId: String(item.ecom_order_code || '').replace(/\.0$/, ''), ticketId: String(item.TicketId).trim(), representative: (String(item.TicketNote || '').match(/đại diện (\d{12,25})/) || [])[1] || '' });
      url = json['odata.nextLink'] || json['@odata.nextLink'] || '';
    }
    return { items };
  })();
}
async function listTrackerTickets() {
  const state = {};
  try {
    const tabId = await spWorkTab(state);
    const results = await chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', func: pageTrackerTickets, args: [{ site: OPCancelReturn.TRACKER_SITE, list: OPCancelReturn.TRACKER_LIST }] });
    const result = results?.[0]?.result;
    if (!result) throw new Error('Tab SharePoint chưa trả danh sách Ticket ID.');
    if (result.error === 'session') throw new Error(`Phiên SharePoint hết hạn / thiếu quyền đọc List (HTTP ${result.status}) — đăng nhập onpointvn.sharepoint.com rồi tải lại tracker.`);
    if (result.error) throw new Error(`SharePoint từ chối đọc List (HTTP ${result.status}).`);
    return { ok: true, items: result.items };
  } finally {
    if (state.created && state.tabId) chrome.tabs.remove(state.tabId).catch(() => {});
  }
}

let trackerDraining = null;
async function drainCancelReturnTracker(force = false) {
  if (trackerDraining) return trackerDraining;
  trackerDraining = (async () => {
    const { cancelReturnTrackerOutbox: outbox = {}, cancelReturnTickets: tickets = {} } = await chrome.storage.local.get(['cancelReturnTrackerOutbox', 'cancelReturnTickets']);
    const results = {};
    const spState = {};
    let blocked = '', deferred = false;
    for (const [ticketId, entry] of Object.entries(outbox)) {
      const ticket = tickets[ticketId];
      if (!ticket || ticket.kind === 'general') { results[ticketId] = { drop: true }; continue; }
      // v2.2.90 — phiếu cũ đã raise lại bằng tool (phiếu mới đang theo dõi): dòng đơn thuộc phiếu MỚI (Ticket ID mới,
      // ghi chú "Raise lại từ phiếu #cũ") → không ghi phiếu cũ đè lên nữa.
      if (/^\d{8,30}$/.test(String(ticket.reraisedTo || '')) && tickets[ticket.reraisedTo]?.reraiseOf === ticketId) { results[ticketId] = { drop: true }; continue; }
      // v2.2.64 — phiếu vừa lỗi (<9 phút) chờ lượt thử lại 10 phút; không thử lại hàng trăm phiếu lỗi sau MỖI lần raise.
      if (!force && entry.lastTryAt && Date.now() - Date.parse(entry.lastTryAt) < 9 * 60 * 1000) { deferred = true; continue; }
      // Phiên SharePoint hết hạn / thiếu quyền là lỗi chung → ghi cùng lỗi cho phiếu còn lại, không gọi SharePoint từng phiếu.
      if (blocked) { results[ticketId] = { queuedAt: entry.queuedAt, ok: false, error: blocked }; continue; }
      try {
        const result = await writeTicketToTracker(ticket, spState);
        const warn = [result.missing.length ? `Không thấy ${result.missing.length} đơn trong List: ${result.missing.join(', ')}` : '', ...result.conflicts].filter(Boolean).join(' · ');
        results[ticketId] = { queuedAt: entry.queuedAt, ok: true, written: result.written, warn };
      } catch (error) {
        results[ticketId] = { queuedAt: entry.queuedAt, ok: false, error: error.message || String(error) };
        if (/đăng nhập|quyền|HTTP 401|HTTP 403/.test(results[ticketId].error)) { spDigest = null; blocked = results[ticketId].error; }
      }
    }
    if (spState.created && spState.tabId) {
      // Hàng đợi raise còn chạy → giữ tab SharePoint cho lượt ghi kế (khỏi tải lại trang mỗi phiếu).
      const { cancelReturnRun: active } = await chrome.storage.local.get('cancelReturnRun');
      if (!blocked && active && !active.doneAt && !active.paused) spKeptTab = spState.tabId;
      else chrome.tabs.remove(spState.tabId).catch(() => {});
    }
    let retry = deferred;
    await withTicketStateLock(async () => {
      const data = await chrome.storage.local.get(['cancelReturnTrackerOutbox', 'cancelReturnTickets']);
      const nextOutbox = { ...(data.cancelReturnTrackerOutbox || {}) };
      const nextTickets = { ...(data.cancelReturnTickets || {}) };
      const now = new Date().toISOString();
      for (const [ticketId, result] of Object.entries(results)) {
        const current = nextOutbox[ticketId];
        // Có thay đổi mới trong lúc đang ghi → giữ trong hàng đợi để ghi lại bản mới nhất.
        const superseded = current && current.queuedAt !== result.queuedAt;
        if (result.drop || (result.ok && !superseded)) delete nextOutbox[ticketId];
        else if (!result.ok && current) nextOutbox[ticketId] = { ...current, attempts: (current.attempts || 0) + 1, error: result.error, lastTryAt: now };
        if (superseded || (!result.ok && !result.drop)) retry = true;
        if (nextTickets[ticketId] && !result.drop) nextTickets[ticketId] = { ...nextTickets[ticketId], ...(result.ok ? { trackerSyncedAt: now, trackerError: '', trackerWarn: result.warn, trackerWritten: result.written } : { trackerError: result.error }) };
      }
      await chrome.storage.local.set({ cancelReturnTrackerOutbox: nextOutbox, cancelReturnTickets: nextTickets });
    });
    if (retry) scheduleTrackerWrite(10 * 60 * 1000);
    return { ok: true, results };
  })().finally(() => { trackerDraining = null; });
  return trackerDraining;
}
async function requeueTrackerWrite(ticketIds) {
  spAccess = null; // bấm Ghi lại: kiểm tra quyền lại ngay (vd vừa đăng nhập tài khoản khác)
  await withTicketStateLock(async () => {
    const data = await chrome.storage.local.get(['cancelReturnTrackerOutbox', 'cancelReturnTickets']);
    let outbox = data.cancelReturnTrackerOutbox || {};
    const ids = ticketIds?.length ? ticketIds : Object.keys(data.cancelReturnTickets || {});
    // Tracker FG Recon chỉ dành cho phiếu đòi hàng; phiếu loại khác chỉ theo dõi / mở lại.
    for (const id of ids) if (data.cancelReturnTickets?.[id] && data.cancelReturnTickets[id].kind !== 'general') outbox = queueTrackerWrite(outbox, id);
    await chrome.storage.local.set({ cancelReturnTrackerOutbox: outbox });
  });
  return drainCancelReturnTracker(true);
}

/* ------------------------------------------- dò Ticket ID đã raise (v2.2.30) --- */
/* Phiếu đã gửi lên TikTok nhưng tool không bắt được Ticket ID (vd kẹt ở tab "Chưa đọc") → nhóm vẫn "chưa raise",
   không có gì để ghi tracker. Dò lại: Nhật ký phiếu → Tất cả → tìm theo "ID đơn hàng" (các mã đơn của nhóm) → gán. */
const parseVnDateTime = text => {
  const m = String(text || '').match(/(\d{1,2})\/(\d{1,2})\/(\d{4})\s+(\d{1,2}):(\d{2})(?::(\d{2}))?/);
  return m ? Date.UTC(+m[3], +m[2] - 1, +m[1], +m[4] - 7, +m[5], +(m[6] || 0)) : 0;   // giờ VN → UTC
};
const parseIsoish = text => { const t = Date.parse(String(text || '').replace(' ', 'T') + (/[zZ+]/.test(String(text)) ? '' : '+07:00')); return Number.isFinite(t) ? t : 0; };
/** Chọn phiếu đòi hàng của nhóm: tạo SAU lần bàn giao muộn nhất (loại phiếu pickup cũ), ưu tiên phiếu chưa "Đã đóng"
    (TikTok đóng phiếu trùng), rồi phiếu tạo sớm nhất. Nhiều phiếu chưa đóng → để người dùng chọn. */
function chooseLookupTicket(group, rows) {
  const orders = new Set((group.rows || []).map(row => row.orderId));
  const handedAt = Math.max(0, ...(group.rows || []).map(row => parseIsoish(row.handoverAt)));
  const seen = new Map();
  for (const row of rows || []) if (/^\d{8,30}$/.test(row.ticketId) && orders.has(row.orderId) && !seen.has(row.ticketId)) seen.set(row.ticketId, { ...row, createdAtMs: parseVnDateTime(row.created) });
  const all = [...seen.values()];
  const after = all.filter(row => !handedAt || !row.createdAtMs || row.createdAtMs >= handedAt);
  const open = after.filter(row => !/da dong|closed/.test(OPCancelReturn.fold(row.status)));
  const pool = (open.length ? open : after).sort((a, b) => (a.createdAtMs || 0) - (b.createdAtMs || 0));
  if (!pool.length) return { pick: null, candidates: all, reason: all.length ? 'chỉ thấy phiếu tạo trước khi bàn giao (phiếu pickup)' : 'không thấy phiếu nào của các mã đơn này' };
  if (open.length > 1) return { pick: null, candidates: pool, reason: `có ${open.length} phiếu chưa đóng — chọn tay` };
  return { pick: pool[0], candidates: pool };
}
async function startCancelReturnLookup(groupIds) {
  const shop = await getLoggedInMarketplaceShop('tiktok');
  if (!shop.ok) throw new Error(shop.error);
  return withTicketStateLock(async () => {
    const data = await chrome.storage.local.get(['cancelReturnGroups', 'cancelReturnShopMap', 'cancelReturnLookup']);
    const prev = data.cancelReturnLookup;
    if (prev && !prev.doneAt) throw new Error('Đang dò Ticket ID. Chờ xong lượt hiện tại.');
    const shopMap = data.cancelReturnShopMap || {};
    const wanted = new Set(groupIds?.length ? groupIds : []);
    const groups = Object.values(data.cancelReturnGroups || {}).filter(group => group.platform !== 'shopee' && !group.ticketId && (!wanted.size || wanted.has(group.id)));
    const mine = groups.filter(group => shopMap[group.channel] === shop.name);
    if (!mine.length) throw new Error(groups.length ? `Không có ĐVVC nào thuộc shop đang đăng nhập (${shop.name}). Channel phải được gắn shop (đã raise ít nhất 1 lần) — đổi đúng shop TikTok rồi dò lại.` : 'Không có ĐVVC nào đang thiếu Ticket ID.');
    const tab = await chrome.tabs.create({ url: 'about:blank', active: true });
    const lookup = { id: `lookup_${Date.now()}`, shopName: shop.name, tabId: tab.id, queue: mine.map(group => group.id), active: '', results: [], startedAt: new Date().toISOString(), doneAt: '' };
    await chrome.storage.local.set({ cancelReturnLookup: lookup });
    await chrome.tabs.update(tab.id, { url: TIKTOK_TICKET_LIST_URL, active: true });
    return { ok: true, count: mine.length, skipped: groups.length - mine.length };
  });
}
/** Trang Nhật ký phiếu hỏi nhóm kế tiếp cần dò (mã đơn để gõ vào ô "ID đơn hàng"). */
async function nextLookupForTab(tabId) {
  return withTicketStateLock(async () => {
    const data = await chrome.storage.local.get(['cancelReturnLookup', 'cancelReturnGroups']);
    const lookup = data.cancelReturnLookup;
    if (!lookup || lookup.doneAt || Number(lookup.tabId) !== Number(tabId)) return { ok: false };
    while (lookup.queue.length && !data.cancelReturnGroups?.[lookup.queue[0]]) lookup.queue.shift();
    const groupId = lookup.active || lookup.queue.shift();
    if (!groupId) { lookup.doneAt = new Date().toISOString(); await chrome.storage.local.set({ cancelReturnLookup: lookup }); setTimeout(() => { chrome.tabs.remove(Number(tabId)).catch(() => {}); }, 2500); return { ok: false, done: true }; }
    lookup.active = groupId;
    await chrome.storage.local.set({ cancelReturnLookup: lookup });
    const group = data.cancelReturnGroups[groupId];
    return { ok: true, groupId, label: `${group.channel} · ${group.carrier}`, orderIds: (group.rows || []).map(row => row.orderId).slice(0, 50) };
  });
}
async function reportLookupForTab(tabId, groupId, rows, error) {
  const state = await withTicketStateLock(async () => {
    const data = await chrome.storage.local.get(['cancelReturnLookup', 'cancelReturnGroups']);
    const lookup = data.cancelReturnLookup;
    if (!lookup || lookup.doneAt || Number(lookup.tabId) !== Number(tabId) || lookup.active !== groupId) return null;
    const group = data.cancelReturnGroups?.[groupId];
    lookup.active = '';
    const decision = group && !error ? chooseLookupTicket(group, rows) : { pick: null, candidates: [], reason: error || 'không còn nhóm' };
    const entry = { groupId, label: group ? `${group.channel} · ${group.carrier}` : groupId, at: new Date().toISOString(), ticketId: decision.pick?.ticketId || '', reason: decision.reason || '',
      candidates: (decision.candidates || []).slice(0, 8).map(row => ({ ticketId: row.ticketId, orderId: row.orderId, status: row.status, created: row.created })) };
    lookup.results.push(entry);
    await chrome.storage.local.set({ cancelReturnLookup: lookup });
    return entry;
  });
  if (!state) return { ok: false };
  if (state.ticketId) {
    try { await mapCancelReturnManually(groupId, state.ticketId); }
    catch (mapError) {
      await withTicketStateLock(async () => {
        const { cancelReturnLookup: lookup } = await chrome.storage.local.get('cancelReturnLookup');
        const last = lookup?.results?.find(item => item.groupId === groupId && item.at === state.at);
        if (last) { last.reason = `tìm thấy #${state.ticketId} nhưng chưa gán được: ${mapError.message || mapError}`; last.ticketId = ''; await chrome.storage.local.set({ cancelReturnLookup: lookup }); }
      });
    }
  }
  return { ok: true, mapped: state.ticketId || '' };
}

/* v2.2.57 — BỘ TỰ GỠ KẸT (chạy mỗi 15 giây khi service worker sống + alarm 30 giây dự phòng):
   - Không có phiếu đang mở mà hàng đợi đứng >25 giây → tự chạy đơn kế.
   - Phiếu đang mở đã lưu Ticket ID nhưng hàng đợi chưa nhả → nhả và chạy đơn kế.
   - Form mở >150 giây mà chưa bấm Gửi → tải lại form 1 lần; vẫn kẹt → bỏ qua đơn đó (ghi lý do) và chạy tiếp. */
const CR_WATCHDOG_ALARM = 'op-cancel-return-watchdog';
let crWatchBusy = false;
async function crWatchdog() {
  if (crWatchBusy) return;
  crWatchBusy = true;
  try {
    const data = await chrome.storage.local.get(['cancelReturnRun', 'cancelReturnGroups', 'ticketTabPayloads', 'ticketOpenGroups']);
    const run = data.cancelReturnRun;
    if (!run || run.doneAt || run.paused || run.awaitingReply) return;
    const now = Date.now();
    // v2.2.82 — làn 2 (fast mode): đã lưu Ticket ID mà chưa nhả → nhả; tab mất / form báo lỗi / >150 giây chưa Gửi → tắt làn 2.
    const lane = run.laneB;
    if (lane?.on && lane.activeKey) {
      const lanePayload = data.ticketTabPayloads?.[String(lane.tabId)];
      const laneSaved = lane.groupId && data.cancelReturnGroups?.[lane.groupId]?.ticketId;
      const laneAlive = await chrome.tabs.get(Number(lane.tabId)).then(tab => Boolean(tab?.id), () => false);
      const laneSent = Boolean(lanePayload?.ticketCapture?.startedAt);
      const laneFailed = data.ticketOpenGroups?.[lane.activeKey]?.autofill?.ok === false;
      if (laneSaved) {
        await withTicketStateLock(async () => {
          const { cancelReturnRun: latest } = await chrome.storage.local.get('cancelReturnRun');
          if (latest?.laneB?.activeKey === lane.activeKey) await chrome.storage.local.set({ cancelReturnRun: { ...latest, laneB: { ...latest.laneB, activeKey: '', groupId: '', openedAt: '' } } });
        });
        crSchedule(CANCEL_RETURN_NEXT_ALARM, 200);
      } else if (!laneAlive) await disableCancelReturnLaneB('tab làn 2 đã đóng', { closeTab: false });
      else if (laneFailed && !laneSent) await disableCancelReturnLaneB(`form làn 2 lỗi: ${data.ticketOpenGroups[lane.activeKey].autofill.reason || 'không tự gửi được'}`);
      else if (!laneSent && now - (Date.parse(lane.openedAt || '') || now) > 150000) await disableCancelReturnLaneB('form làn 2 kẹt >150 giây');
      else if (laneSent && now - (Date.parse(lane.openedAt || '') || now) > 300000) await disableCancelReturnLaneB('làn 2 chờ Ticket ID >5 phút', { closeTab: false });
    } else if (lane?.on && !lane.activeKey && crNextPending(run, data.cancelReturnGroups || {}) && now - Math.max(Date.parse(run.lastStepAt || '') || 0, Date.parse(run.startedAt || '') || 0) > 25000) advanceCancelReturnLaneB().catch(console.error);
    const lastStep = Math.max(Date.parse(run.activeOpenedAt || '') || 0, Date.parse(run.lastStepAt || '') || 0, Date.parse(run.startedAt || '') || 0);
    if (!run.activeKey) {
      if (crNextPending(run, data.cancelReturnGroups || {}) && now - lastStep > 25000) advanceCancelReturnRun().catch(console.error);
      // Làn 2 vừa xong đơn cuối → khép hàng đợi.
      else if (!run.laneB?.activeKey && !(run.pending || []).some(id => !data.cancelReturnGroups?.[id]?.ticketId) && now - lastStep > 5000) advanceCancelReturnRun().catch(console.error);
      return;
    }
    const key = String(run.activeTabId);
    const payload = data.ticketTabPayloads?.[key];
    const groupId = payload?.draft?.cancelReturn?.groupId || '';
    const saved = groupId && data.cancelReturnGroups?.[groupId]?.ticketId;
    const tabAlive = await chrome.tabs.get(Number(run.activeTabId)).then(tab => Boolean(tab?.id), () => false);
    if (saved || !tabAlive) {
      await withTicketStateLock(async () => {
        const { cancelReturnRun: latest, ticketOpenGroups: open = {} } = await chrome.storage.local.get(['cancelReturnRun', 'ticketOpenGroups']);
        if (!latest || latest.activeKey !== run.activeKey) return;
        const groups = { ...open }; delete groups[latest.activeKey];
        await chrome.storage.local.set({ cancelReturnRun: { ...latest, activeKey: '', activeTabId: null, lastStepAt: new Date().toISOString(), ...(saved ? {} : { pending: latest.pending }) }, ticketOpenGroups: groups });
      });
      crSchedule(CANCEL_RETURN_NEXT_ALARM, 200);
      return;
    }
    if (payload?.ticketCapture?.startedAt) return;  // đã bấm Gửi: để luồng bắt Ticket ID tự xử lý, không gửi lại
    const opened = Date.parse(run.activeOpenedAt || '') || 0;
    if (!opened || now - opened < 150000) return;
    if (run.retriedKey !== run.activeKey) {
      await withTicketStateLock(async () => {
        const { cancelReturnRun: latest, ticketOpenGroups: open = {} } = await chrome.storage.local.get(['cancelReturnRun', 'ticketOpenGroups']);
        if (!latest || latest.activeKey !== run.activeKey) return;
        const groups = { ...open };
        if (groups[latest.activeKey]) groups[latest.activeKey] = { ...groups[latest.activeKey], status: 'opened', autofill: {} };
        await chrome.storage.local.set({ cancelReturnRun: { ...latest, retriedKey: latest.activeKey, activeOpenedAt: new Date().toISOString(), error: '' }, ticketOpenGroups: groups });
      });
      await chrome.tabs.reload(Number(run.activeTabId)).catch(() => {});
      return;
    }
    await withTicketStateLock(async () => {
      const { cancelReturnRun: latest, ticketOpenGroups: open = {}, ticketTabPayloads: payloads = {} } = await chrome.storage.local.get(['cancelReturnRun', 'ticketOpenGroups', 'ticketTabPayloads']);
      if (!latest || latest.activeKey !== run.activeKey) return;
      const groups = { ...open }; delete groups[latest.activeKey];
      const nextPayloads = { ...payloads }; delete nextPayloads[key];
      const orderId = payload?.draft?.rows?.[0]?.orderId || '';
      await chrome.storage.local.set({
        ticketOpenGroups: groups, ticketTabPayloads: nextPayloads,
        cancelReturnRun: { ...latest, activeKey: '', activeTabId: null, pending: (latest.pending || []).filter(id => id !== groupId), lastStepAt: new Date().toISOString(),
          skipped: [...(latest.skipped || []), { groupId, orderId, error: 'Form kẹt >5 phút (đã tự tải lại 1 lần) — bỏ qua, raise lại sau.' }].slice(-200) }
      });
    });
    crSchedule(CANCEL_RETURN_NEXT_ALARM, 200);
  } catch (error) { console.warn('[OnPoint] watchdog', error); }
  finally { crWatchBusy = false; }
}
if (typeof ServiceWorkerGlobalScope !== 'undefined') {
  setInterval(() => { crWatchdog().catch(() => {}); }, 15000);
  chrome.alarms.create(CR_WATCHDOG_ALARM, { periodInMinutes: 0.5 });
}

/* v2.2.48 — bước kế chạy ngay bằng setTimeout (alarm của Chrome có thể trễ tới ~30 giây); alarm giữ làm dự phòng
   nếu service worker ngủ. Các bước đều tự kiểm tra trạng thái trong khóa nên chạy thừa 1 lần cũng không sao. */
function crSchedule(name, delayMs) {
  const run = { [CANCEL_RETURN_NEXT_ALARM]: advanceCancelReturnRun, [CANCEL_RETURN_FOLLOW_ALARM]: advanceCancelReturnFollowUp, [CANCEL_RETURN_REPLY_ALARM]: startPostRaiseReply }[name];
  if (run && typeof ServiceWorkerGlobalScope !== 'undefined') setTimeout(() => { run().catch(console.error); }, delayMs);
  chrome.alarms.create(name, { when: Date.now() + (run && typeof ServiceWorkerGlobalScope !== 'undefined' ? Math.max(delayMs, 30000) : delayMs) });
}
chrome.alarms.onAlarm.addListener(alarm => {
  if (alarm.name === CANCEL_RETURN_NEXT_ALARM) advanceCancelReturnRun().catch(console.error);
  if (alarm.name === CR_WATCHDOG_ALARM) crWatchdog().catch(console.error);
  if (alarm.name === CANCEL_RETURN_FOLLOW_ALARM) advanceCancelReturnFollowUp().catch(console.error);
  if (alarm.name === CANCEL_RETURN_TRACKER_ALARM) drainCancelReturnTracker().catch(console.error);
  if (alarm.name === CANCEL_RETURN_REPLY_ALARM) startPostRaiseReply().catch(console.error);
});
chrome.tabs.onRemoved.addListener(tabId => {
  // Đóng tab dò Ticket ID giữa chừng → kết thúc lượt dò (cho phép dò lại).
  withTicketStateLock(async () => {
    const { cancelReturnLookup: lookup } = await chrome.storage.local.get('cancelReturnLookup');
    if (lookup && !lookup.doneAt && Number(lookup.tabId) === Number(tabId)) { lookup.doneAt = new Date().toISOString(); lookup.stopped = true; await chrome.storage.local.set({ cancelReturnLookup: lookup }); }
  }).catch(console.error);
  cancelReturnTabClosed(tabId).catch(console.error);
  withTicketStateLock(async () => {
    const data = await chrome.storage.local.get(['cancelReturnFollowRun', 'cancelReturnTickets']);
    const follow = data.cancelReturnFollowRun;
    if (!follow?.active || Number(follow.active.tabId) !== Number(tabId)) return;
    await finishFollowUpLocked(follow, data.cancelReturnTickets || {}, { ok: false, error: follow.active.sendingAt ? 'Tab đóng sau khi bấm Gửi — mở phiếu kiểm tra phản hồi đã lên chưa.' : 'Tab phiếu bị đóng trước khi phản hồi.' });
    crSchedule(CANCEL_RETURN_FOLLOW_ALARM, 300);
  }).catch(console.error);
});
chrome.runtime.onStartup.addListener(() => { recoverCancelReturnRun().catch(console.error); });
recoverCancelReturnRun().catch(console.error);

// v2.2.53 — Reload/cập nhật extension làm script trên tab TikTok đang chạy mất kết nối ("Extension context invalidated").
// Tự tải lại đúng tab đang raise / đang gửi tin bổ sung để script mới tiếp quản (đã có dấu chống gửi trùng).
chrome.runtime.onInstalled?.addListener(details => {
  if (!['update', 'install'].includes(details?.reason) && details?.reason !== 'chrome_update') return;
  (async () => {
    const { cancelReturnRun: run, cancelReturnFollowRun: follow } = await chrome.storage.local.get(['cancelReturnRun', 'cancelReturnFollowRun']);
    const ids = [run && !run.doneAt && run.activeKey ? run.activeTabId : null, follow && !follow.doneAt ? follow.active?.tabId : null].filter(Boolean);
    for (const id of new Set(ids)) {
      const tab = await chrome.tabs.get(Number(id)).catch(() => null);
      if (tab && /^https:\/\/seller-vn\.tiktok\.com\/ticket/.test(tab.url || '')) await chrome.tabs.reload(tab.id).catch(() => {});
    }
  })().catch(() => {});
});

chrome.runtime.onMessage.addListener((message, sender, respond) => {
  const fromPanel = ['START_CANCEL_RETURN', 'PAUSE_CANCEL_RETURN', 'RESUME_CANCEL_RETURN', 'MAP_CANCEL_RETURN_MANUALLY', 'FOLLOW_UP_CANCEL_RETURN', 'STOP_CANCEL_RETURN_FOLLOW_UP', 'SET_CANCEL_RETURN_FINISHED', 'WRITE_CANCEL_RETURN_TRACKER', 'LOOKUP_CANCEL_RETURN_TICKETS', 'SKIP_CANCEL_RETURN_REPLY', 'SYNC_TIKTOK_FOLLOW_TICKETS', 'STOP_CANCEL_RETURN_NOW', 'LIST_CANCEL_RETURN_SP_TICKETS', 'LOOKUP_SHOPEE_CANCEL_RETURN', 'REFRESH_SHOPEE_CANCEL_RETURN', 'SCAN_TIKTOK_TICKETS', 'RERAISE_TIKTOK_ACTION', 'SET_TIKTOK_AUTO_SCAN', 'SET_TIKTOK_REBUT_DRAFT', 'MARK_TIKTOK_RERAISED', 'SET_TICKETS_FOLLOWED'];
  const fromTab = ['GET_TICKET_FOLLOWUP', 'TICKET_FOLLOWUP_SENDING', 'TICKET_FOLLOWUP_RESULT', 'TICKET_FOLLOWUP_UPLOAD', 'TICKET_FOLLOWUP_CLICK', 'GET_TICKET_LOOKUP', 'TICKET_LOOKUP_RESULT'];
  if (![...fromPanel, ...fromTab].includes(message?.type)) return;
  if (sender.id !== chrome.runtime.id) { respond({ ok: false, error: 'Nguồn không hợp lệ.' }); return false; }
  if (fromPanel.includes(message.type) && sender.tab) { respond({ ok: false, error: 'Chỉ chạy từ Side Panel.' }); return false; }
  if (fromTab.includes(message.type) && !/^https:\/\/seller-vn\.tiktok\.com\/ticket(?:\/detail\/|\/?(?:[?#]|$))/.test(sender.tab?.url || '')) { respond({ ok: false, error: 'Chỉ nhận từ Nhật ký phiếu / trang chi tiết phiếu TikTok.' }); return false; }
  const task = message.type === 'START_CANCEL_RETURN' ? startCancelReturnRun(message.channel, message.groupIds, message.bindShop === true)
    : message.type === 'PAUSE_CANCEL_RETURN' ? pauseCancelReturnRun()
    : message.type === 'STOP_CANCEL_RETURN_NOW' ? stopCancelReturnNow()
    : message.type === 'RESUME_CANCEL_RETURN' ? resumeCancelReturnRun()
    : message.type === 'SKIP_CANCEL_RETURN_REPLY' ? skipCancelReturnReply()
    : message.type === 'MAP_CANCEL_RETURN_MANUALLY' ? mapCancelReturnManually(message.groupId, message.ticketId)
    : message.type === 'FOLLOW_UP_CANCEL_RETURN' ? startCancelReturnFollowUp(message.ticketIds, message.mode, message.text)
    : message.type === 'STOP_CANCEL_RETURN_FOLLOW_UP' ? stopCancelReturnFollowUp()
    : message.type === 'SET_CANCEL_RETURN_FINISHED' ? setCancelReturnTicketFinished(message.ticketId, message.finished)
    : message.type === 'WRITE_CANCEL_RETURN_TRACKER' ? requeueTrackerWrite(message.ticketIds)
    : message.type === 'LOOKUP_CANCEL_RETURN_TICKETS' ? startCancelReturnLookup(message.groupIds)
    : message.type === 'SYNC_TIKTOK_FOLLOW_TICKETS' ? syncTikTokFollowTickets()
    : message.type === 'LIST_CANCEL_RETURN_SP_TICKETS' ? listTrackerTickets()
    : message.type === 'LOOKUP_SHOPEE_CANCEL_RETURN' ? startShopeeCancelReturnLookup(message.groupIds)
    : message.type === 'REFRESH_SHOPEE_CANCEL_RETURN' ? refreshShopeeCancelReturnStatuses(message.ticketIds)
    : message.type === 'SCAN_TIKTOK_TICKETS' ? scanTikTokTickets(message.days, { ids: Array.isArray(message.ticketIds) ? message.ticketIds.slice(0, 50) : [] })
    : message.type === 'RERAISE_TIKTOK_ACTION' ? startTikTokActionReraise(message.ticketIds, message.text)
    : message.type === 'SET_TIKTOK_AUTO_SCAN' ? scheduleTikTokScan()
    : message.type === 'SET_TICKETS_FOLLOWED' ? setTicketsFollowed(Array.isArray(message.ticketIds) ? message.ticketIds.slice(0, 2000) : [], message.on !== false)
    : message.type === 'MARK_TIKTOK_RERAISED' ? markTikTokReraised(String(message.ticketId || ''), message.newTicketId)
    : message.type === 'SET_TIKTOK_REBUT_DRAFT' ? setTikTokRebutDraft(String(message.ticketId || ''), String(message.text || ''))
    : message.type === 'GET_TICKET_LOOKUP' ? nextLookupForTab(sender.tab.id)
    : message.type === 'TICKET_LOOKUP_RESULT' ? reportLookupForTab(sender.tab.id, message.groupId, Array.isArray(message.rows) ? message.rows.slice(0, 200) : [], String(message.error || ''))
    : message.type === 'GET_TICKET_FOLLOWUP' ? followUpContextForTab(sender.tab)
    : message.type === 'TICKET_FOLLOWUP_CLICK' ? clickForFollowUp(sender.tab.id, message)
    : message.type === 'TICKET_FOLLOWUP_SENDING' ? markFollowUpSending(sender.tab.id, message.ticketId, message.baselineCount)
    : message.type === 'TICKET_FOLLOWUP_UPLOAD' ? uploadFollowUpFiles(sender.tab.id)
    : reportFollowUpResult(sender.tab.id, message.result);
  task.then(respond).catch(error => respond({ ok: false, error: error.message || String(error) }));
  return true;
});
