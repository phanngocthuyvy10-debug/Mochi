/* MAIN world: observe the page's own successful ticket creation, without API calls. */
(() => {
  if (window.__OP_TICKET_PROBE__) return;
  window.__OP_TICKET_PROBE__ = true;
  let armed = null;
  const records = [];
  function emit() {
    window.postMessage({ source: 'op-ticket-probe', json: JSON.stringify({ records }) }, '*');
  }
  window.addEventListener('message', event => {
    if (event.source !== window || event.origin !== location.origin) return;
    if (event.data?.source === 'op-ticket-probe-arm') {
      try { armed = JSON.parse(event.data.json); } catch (_) { armed = null; }
    } else if (event.data?.source === 'op-ticket-probe-ask') emit();
  });
  function bodyText(body) {
    if (typeof body === 'string') return body;
    if (body instanceof URLSearchParams) return JSON.stringify(Object.fromEntries(body));
    if (body instanceof FormData) return JSON.stringify(Object.fromEntries([...body].filter(([, value]) => typeof value === 'string')));
    return '';
  }
  function finish(meta, response, httpStatus) {
    try {
      if (!armed?.startedAt || meta.startedAt < armed.startedAt) return;
      const result = OPTicketCapture.creationResponse({ ...meta, response, httpStatus });
      if (!result || result.orderId && result.orderId !== armed.orderId) return;
      records.push({ ...result, orderId: result.orderId || armed.orderId, startedAt: meta.startedAt });
      if (records.length > 20) records.shift();
      emit();
    } catch (_) {}
  }
  const xhrOpen = XMLHttpRequest.prototype.open, xhrSend = XMLHttpRequest.prototype.send;
  const metadata = new WeakMap();
  XMLHttpRequest.prototype.open = function(method, url) {
    metadata.set(this, { method: String(method), url: String(url) });
    return xhrOpen.apply(this, arguments);
  };
  XMLHttpRequest.prototype.send = function(body) {
    try {
      const meta = { ...metadata.get(this), body: bodyText(body), startedAt: Date.now() };
      if (armed?.startedAt && /ticket|work.?order/i.test(meta.url || '')) this.addEventListener('load', () => {
        try { finish(meta, this.responseType === 'json' ? this.response : this.responseText, this.status); } catch (_) {}
      }, { once: true });
    } catch (_) {}
    return xhrSend.apply(this, arguments);
  };
  const originalFetch = window.fetch;
  if (originalFetch) window.fetch = function(input, init) {
    const meta = { method: init?.method || input?.method || 'GET', url: typeof input === 'string' ? input : input?.url || String(input), startedAt: Date.now(), body: '' };
    let body = Promise.resolve('');
    try {
      body = init?.body != null ? Promise.resolve(bodyText(init.body))
        : input instanceof Request && /json|urlencoded/i.test(input.headers.get('content-type') || '') ? input.clone().text() : body;
    } catch (_) {}
    const result = originalFetch.apply(this, arguments);
    if (armed?.startedAt && /ticket|work.?order/i.test(meta.url)) result.then(async response => {
      try {
        if (Number(response.headers.get('content-length')) > 1000000) return;
        const [requestBody, responseText] = await Promise.all([body, response.clone().text()]);
        finish({ ...meta, body: requestBody }, responseText, response.status);
      } catch (_) {}
    }, () => {});
    return result;
  };
})();
