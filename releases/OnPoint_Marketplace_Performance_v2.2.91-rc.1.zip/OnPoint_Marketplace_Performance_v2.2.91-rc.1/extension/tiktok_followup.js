/* v2.2.25 — Nhật ký phiếu: bấm thật Tất cả → tìm đúng phiếu → phản hồi đủ nội dung + file.
   Chỉ chạy trên tab do tool mở (service worker trả ngữ cảnh theo đúng tabId), gửi tối đa 1 lần mỗi lượt. */
(() => {
  if (window.__OP_TICKET_FOLLOWUP__) return;
  window.__OP_TICKET_FOLLOWUP__ = true;
  const norm = value => String(value ?? '').normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[đĐ]/g, 'd').trim().toLowerCase().replace(/\s+/g, ' ');
  const STATUSES = ['Cần có hành động của bạn', 'Đang xử lý', 'Đã giải quyết', 'Đã đóng', 'Đã hoàn thành', 'Chờ phản hồi', 'Chờ xử lý', 'Mới', 'Resolved', 'Closed', 'In progress', 'Pending'];
  const CLOSED = /^(da giai quyet|da dong|da hoan thanh|resolved|closed|completed)$/;
  // v2.2.64 — tab nền (làn phản hồi song song): setTimeout bị Chrome dồn về ≥1 giây → OPWake.sleep giữ đúng nhịp.
  const sleep = ms => globalThis.OPWake ? OPWake.sleep(ms) : new Promise(resolve => setTimeout(resolve, ms));
  const visible = el => { if (!el) return false; const r = el.getBoundingClientRect(); const s = getComputedStyle(el); return r.width > 0 && r.height > 0 && s.visibility !== 'hidden' && s.display !== 'none'; };
  const send = message => new Promise(resolve => {
    try { chrome.runtime.sendMessage(message, response => { void chrome.runtime.lastError; resolve(response); }); } catch (_) { resolve(null); }
  });
  let currentTicketId = '';
  // v2.2.64 — DOM đổi (khung Gửi tin nhắn vừa dựng, tin vừa lên luồng) → kiểm tra ngay, không nằm chờ hết nhịp;
  // sàn 80 ms giữa 2 lần kiểm tra để trang TikTok re-render liên tục không kéo CPU.
  async function waitFor(fn, timeout, step = 250) {
    const end = Date.now() + timeout;
    let wake = null;
    let observer = null;
    try { observer = new MutationObserver(() => { const resolve = wake; wake = null; resolve?.(); }); observer.observe(document.documentElement, { childList: true, subtree: true, characterData: true }); } catch (_) { observer = null; }
    try {
      while (Date.now() < end) {
        const value = fn(); if (value) return value;
        const startedAt = Date.now();
        await new Promise(resolve => { wake = resolve; sleep(step).then(resolve); });
        wake = null;
        if (Date.now() - startedAt < 80) await sleep(80 - (Date.now() - startedAt));
      }
      return null;
    } finally { observer?.disconnect(); }
  }
  const pageText = () => String(document.body?.innerText || '').replace(/(LCP_Loading_Skeleton_)+/g, '');
  function readStatus(ticketId) {
    // "Yêu cầu #<id>" rồi tới nhãn trạng thái ở dòng kế.
    const lines = pageText().split('\n').map(line => line.trim()).filter(Boolean);
    const at = lines.findIndex(line => line.includes(`#${ticketId}`));
    const wanted = STATUSES.map(norm);
    if (at >= 0) for (const line of lines.slice(at + 1, at + 4)) if (wanted.includes(norm(line))) return line;
    const chip = [...document.querySelectorAll('span,div')].find(el => el.children.length === 0 && visible(el) && wanted.includes(norm(el.textContent)) && el.getBoundingClientRect().top < 260);
    return chip ? chip.textContent.trim() : '';
  }
  const replyBox = () => [...document.querySelectorAll('textarea')].filter(visible).sort((a, b) => b.getBoundingClientRect().width - a.getBoundingClientRect().width)[0] || null;
  function sendButton(box) {
    // v2.2.27 — trang thật: nút Gửi nằm 9 lớp trên ô nhập (khung p-row chung) → dò tới 14 lớp, ưu tiên nút chính.
    for (let node = box?.parentElement, depth = 0; node && depth < 14; node = node.parentElement, depth++) {
      const buttons = [...node.querySelectorAll('button')].filter(el => visible(el) && ['gui', 'send'].includes(norm(el.innerText)));
      const button = buttons.find(el => /primary/.test(String(el.className))) || buttons[0];
      if (button) return button;
    }
    return null;
  }
  function setNativeValue(el, value) {
    const setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value').set;
    el.focus();
    setter.call(el, value);
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }
  // Khung "Gửi tin nhắn": tổ tiên gần nhất của ô nhập có chứa nút "Tải lên".
  function replySection(box) {
    for (let node = box?.parentElement, depth = 0; node && depth < 10; node = node.parentElement, depth++) {
      if ([...node.querySelectorAll('button,[role="button"]')].some(el => /^tai len|^upload/.test(norm(el.innerText)))) return node;
    }
    return box?.parentElement || null;
  }
  const FILE_CARD = /\.(xlsx?|csv|pdf|jpe?g|png|mp4|mov)$/i;
  // Thẻ file TikTok rút gọn tên ở giữa ("DoiHang_TTKPSC_...ss_2don.xlsx") nên đếm thẻ có đuôi file, không so tên đủ.
  function attachmentState(section) {
    const leaves = [...section.querySelectorAll('div,span,a,p')].filter(el => el.children.length === 0 && visible(el) && FILE_CARD.test(String(el.textContent).trim()) && String(el.textContent).trim().length <= 160);
    const busy = [...section.querySelectorAll('[aria-busy="true"],[role="progressbar"],[class*="uploading" i],[class*="progress" i]')].some(visible)
      || /\d{1,3}\s?%/.test(section.innerText || '') || /dang tai|uploading/.test(norm(section.innerText));
    const failed = /tai len that bai|upload failed|loi tai len/.test(norm(section.innerText));
    // v2.2.27 — 1 thẻ file = 2 đoạn tên (đầu + đuôi có đuôi file) → đếm theo thẻ chứa, không theo đoạn chữ.
    return { count: new Set(leaves.map(el => el.parentElement || el)).size, busy, failed };
  }
  // Tin nhắn đã lên luồng hội thoại: ô nhập trống và đoạn đầu nội dung xuất hiện ngoài ô nhập.
  // Phản hồi sau raise trùng nội dung tin đầu → so số lần xuất hiện trước/sau khi Gửi.
  function messageCount(box, text) {
    const probe = norm(text).slice(0, 60);
    // Không phụ thuộc trang đang được vẽ (tab nền / cửa sổ bị che vẫn xác nhận được).
    // Mỗi tin nhắn = phần tử SÂU NHẤT mở đầu bằng nội dung (khung chứa luồng không bị tính).
    // v2.2.64 — chỉ chuẩn hóa ĐOẠN ĐẦU textContent: trước đây chuẩn hóa NFD cả nội dung của MỌI div (khung ngoài chứa cả trang)
    // → mỗi lần kiểm tra tốn hàng trăm ms–vài giây, làm bước chờ "tin đã lên luồng" rất chậm.
    if (!probe) return 0;
    const head = el => norm(String(el.textContent || '').slice(0, 400));
    const matches = [...document.querySelectorAll('div,p,span')].filter(el => el.tagName !== 'TEXTAREA' && head(el).startsWith(probe) && !el.contains(box));
    return matches.filter(el => !matches.some(other => other !== el && el.contains(other))).length;
  }
  function replyPosted(box, text, baseline) {
    return (!box.isConnected || !box.value) && messageCount(box, text) > baseline;
  }

  // Hiện từng bước trên Side Panel (cùng kênh TICKET_STEP_TEXT với form tạo phiếu).
  const step = (text, warn = false) => send({ type: 'TICKET_STEP_TEXT', text: `Phản hồi phiếu · ${text}`, warn, followUp: true });
  const center = el => { el.scrollIntoView({ block: 'center', inline: 'center' }); const r = el.getBoundingClientRect(); return { x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2) }; };
  // Click thật (qua debugger của extension) — TikTok chỉ mở tab phiếu khi có thao tác chuột thật.
  // v2.2.37 — bấm thẳng vào phần tử (click()), KHÔNG dùng click theo tọa độ qua debugger: trang đang zoom 90% làm tọa độ lệch,
  // click rơi ra ngoài nút Gửi / có thể trúng nút khác. click() trên nút React của TikTok hoạt động (đo trên trang thật).
  async function trustedClick(el) {
    // Search icons may be SVGElements, which do not implement HTMLElement.click().
    const target = el.closest('button,[role="button"],a') || el;
    target.scrollIntoView({ block: 'center', inline: 'center' });
    await sleep(300);
    if (typeof target.click === 'function') target.click();
    else target.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window }));
    return true;
  }  function setInputValue(el, value) {
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
    el.focus(); setter.call(el, value);
    el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true }));
  }
  const pressEnter = el => { for (const type of ['keydown', 'keypress', 'keyup']) el.dispatchEvent(new KeyboardEvent(type, { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true })); };
  const ticketSearchInput = () => [...document.querySelectorAll('input')].find(el => visible(el) && /tach nhieu phieu|so phieu|ticket/.test(norm(el.placeholder)));
  function allTicketsTab() {
    const labels = [...document.querySelectorAll('[role="tab"],button,a,div,span')].filter(el => visible(el) && /^(tat ca|all)(\s*\(?\d+\+?\)?)?$/.test(norm(el.textContent)));
    // Ưu tiên phần tử tab; nếu nhãn nằm trong span thì click vào khung tab nhận sự kiện.
    const label = labels.find(el => el.getAttribute('role') === 'tab') || labels.find(el => el.children.length === 0) || labels[0];
    return label?.closest('[role="tab"],[class*="tabs-tab"],[class*="tabs-header-title"],[class*="tab-item"],button,a') || label || null;
  }
  function tabSelected(tab) {
    for (let node = tab, depth = 0; node && depth < 3; node = node.parentElement, depth++) {
      const selected = node.getAttribute('aria-selected');
      if (selected != null) return selected === 'true';
      if (/(^|[\s_-])(active|selected)($|[\s_-])/.test(String(node.className))) return true;
    }
    return null; // Một số giao diện không gắn aria-selected/class active.
  }
  async function clickAllTickets(ticketId) {
    step(`#${ticketId}: bấm tab Tất cả…`);
    const tab = await waitFor(allTicketsTab, 30000);
    if (!tab) throw new Error('Không tìm thấy tab "Tất cả" trên Nhật ký phiếu — chưa tìm/mở phiếu.');
    // Luôn bấm thật, kể cả tab đang có gạch chân/aria-selected=true: TikTok cần thao tác này để khởi tạo danh sách.
    await trustedClick(tab);
    await sleep(800);
    const ready = await waitFor(() => {
      const current = allTicketsTab();
      const loading = [...document.querySelectorAll('[role="tabpanel"][aria-busy="true"],[class*="table-loading"],[class*="spin-loading"]')].some(visible);
      return current && tabSelected(current) !== false && !loading && ticketSearchInput();
    }, 15000);
    if (!ready) throw new Error('Đã bấm "Tất cả" nhưng danh sách/ô tìm Số phiếu chưa sẵn sàng — chưa mở ĐVVC kế.');
    return ready;
  }

  /** Nhật ký phiếu: luôn bấm Tất cả trước, rồi tìm đúng Số phiếu và bấm Kiểm tra chi tiết. */
  async function searchAndOpen(context) {
    const ticketId = context.ticketId;
    const detailUrl = `${location.origin}/ticket/detail/${ticketId}?shop_region=VN`;
    const input = await clickAllTickets(ticketId);
    const rowOf = () => [...document.querySelectorAll('tr')].find(tr => visible(tr) && (norm(tr.innerText).match(/(?:id phieu|ticket id)\s*[:#]?\s*(\d{8,30})(?!\d)/) || [])[1] === ticketId);
    setInputValue(input, ticketId);
    pressEnter(input);
    step(`#${ticketId}: đã nhập Số phiếu, đang tìm…`);
    let row = await waitFor(() => { const tr = rowOf(); const rows = [...document.querySelectorAll('tr')].filter(el => visible(el) && /id phieu/.test(norm(el.innerText))); return tr && rows.length === 1 ? tr : null; }, 6000);
    if (!row) {
      // Enter chưa lọc → bấm thật vào kính lúp ở cuối ô tìm kiếm.
      const icon = [...(input.closest('[class*="input" i]')?.parentElement || input.parentElement).querySelectorAll('svg,[class*="search" i],[class*="suffix" i]')].filter(visible).pop();
      if (icon) await trustedClick(icon);
      row = await waitFor(rowOf, 12000);
    }
    if (!row) throw new Error(`Không tìm thấy đúng ID phiếu #${ticketId} trong tab Tất cả — chưa phản hồi, chưa mở ĐVVC kế.`);
    const action = [...row.querySelectorAll('div,span,a,button')].find(el => el.children.length === 0 && visible(el) && norm(el.textContent) === 'kiem tra chi tiet');
    if (!action) throw new Error(`Không thấy Kiểm tra chi tiết của phiếu #${ticketId}.`);
    step(`#${ticketId}: bấm Kiểm tra chi tiết…`);
    await trustedClick(action);
    // Tab phiếu mới tự nhận việc; nếu TikTok không mở tab mới thì mở phiếu ngay tại tab này.
    // Tab phiếu mới nhận việc thì tab này hết ngữ cảnh (service worker trả ok:false).
    let adopted = false;
    for (let i = 0; i < 20 && !adopted; i++) { await sleep(500); const ctx = await send({ type: 'GET_TICKET_FOLLOWUP' }); adopted = ctx?.ok === false; }
    if (!adopted) { step(`#${ticketId}: không thấy tab phiếu mới → mở phiếu tại tab này.`); location.href = detailUrl; }
  }

  /* v2.2.30 — Dò Ticket ID đã raise: Tất cả → ô tìm "ID đơn hàng" → gõ mã đơn của nhóm → đọc dòng phiếu (ID phiếu,
     ID đơn hàng, trạng thái, ngày tạo). Service worker chọn phiếu đúng và gán; không gửi gì lên TikTok. */
  const lookupStep = text => send({ type: 'TICKET_STEP_TEXT', text: `Dò Ticket ID · ${text}`, followUp: true });
  const pressClick = el => { for (const type of ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click']) el.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, view: window })); };
  // Trang có nhiều khung tab trượt ngang, mỗi khung 1 ô tìm + 1 bảng → chỉ làm trong khung của tab đang chọn (aria-controls).
  function activePane() {
    const tab = [...document.querySelectorAll('[role="tab"]')].find(el => el.getAttribute('aria-selected') === 'true');
    const byId = tab?.getAttribute('aria-controls') && document.getElementById(tab.getAttribute('aria-controls'));
    if (byId) return byId;
    const left = (tab?.closest('[role="tablist"],[class*="tabs-header" i]') || tab)?.getBoundingClientRect().left || 0;
    return [...document.querySelectorAll('[class*="tabs-pane" i],[role="tabpanel"]')].filter(pane => pane.querySelector('input'))
      .sort((a, b) => Math.abs(a.getBoundingClientRect().left - left) - Math.abs(b.getBoundingClientRect().left - left))[0] || document;
  }
  const searchInput = () => [...activePane().querySelectorAll('input')].find(el => visible(el) && /tach nhieu|dau phay/.test(norm(el.placeholder)));
  function listRows() {
    const out = [];
    for (const tr of activePane().querySelectorAll('tbody tr')) {
      if (!visible(tr)) continue;
      const text = norm(tr.innerText);
      const ticketId = (text.match(/id phieu\s*:?\s*(\d{8,30})/) || [])[1];
      const orderId = (text.match(/id don hang\s*:?\s*(\d{8,30})/) || [])[1];
      if (!ticketId || !orderId) continue;
      const created = (String(tr.innerText).replace(/\s+/g, ' ').match(/\d{1,2}\/\d{1,2}\/\d{4} \d{1,2}:\d{2}(?::\d{2})?/) || [''])[0];
      out.push({ ticketId, orderId, status: String(tr.cells?.[1]?.innerText || '').trim().slice(0, 40), created });
    }
    return out;
  }
  async function lookupOne(job) {
    const allTab = await waitFor(() => [...document.querySelectorAll('[role="tab"]')].find(el => visible(el) && /^tat ca/.test(norm(el.textContent))), 30000);
    if (!allTab) throw new Error('Chưa thấy tab Tất cả trên Nhật ký phiếu.');
    // Đo trên trang thật: click() đổi được tab, chuỗi pointer/mouse thì không → click() + kiểm tra + thử lại.
    for (let attempt = 0; attempt < 4 && allTab.getAttribute('aria-selected') !== 'true'; attempt++) {
      allTab.click();
      await waitFor(() => allTab.getAttribute('aria-selected') === 'true', 3000, 200);
    }
    if (allTab.getAttribute('aria-selected') !== 'true') throw new Error('Chưa chuyển được sang tab Tất cả.');
    await sleep(800);
    let input = await waitFor(searchInput, 15000);
    if (!input) throw new Error('Chưa thấy ô tìm kiếm.');
    if (!/id don hang/.test(norm(input.placeholder))) {
      // Đổi loại tìm "Số phiếu" → "ID đơn hàng".
      const label = [...activePane().querySelectorAll('span,div')].find(el => el.children.length === 0 && visible(el) && norm(el.textContent) === 'so phieu');
      const selector = label?.closest('[class*="select" i]') || label;
      if (!selector) throw new Error('Chưa thấy ô chọn "Số phiếu".');
      pressClick(selector);
      const option = await waitFor(() => [...document.querySelectorAll('[class*="select-option" i]')].find(el => visible(el) && norm(el.textContent) === 'id don hang'), 5000);
      if (!option) throw new Error('Chưa mở được danh sách chọn "ID đơn hàng".');
      pressClick(option.closest('[class*="select-option" i]:not([class*="label" i])') || option);
      input = await waitFor(() => { const el = searchInput(); return el && /id don hang/.test(norm(el.placeholder)) ? el : null; }, 5000);
      if (!input) throw new Error('Chưa chuyển được ô tìm sang "ID đơn hàng".');
    }
    const value = job.orderIds.join(',');
    setInputValue(input, value);
    pressEnter(input);
    const wanted = new Set(job.orderIds);
    // Chờ danh sách lọc xong: mọi dòng thuộc các mã đơn đang tìm (hoặc bảng trống), đứng yên 1,5 giây.
    let stableSince = 0, lastSig = '';
    await waitFor(() => {
      const rows = listRows();
      const ok = rows.every(row => wanted.has(row.orderId));
      const sig = rows.map(row => row.ticketId).join(',');
      if (!ok || sig !== lastSig) { lastSig = sig; stableSince = 0; return false; }
      stableSince = stableSince || Date.now();
      return Date.now() - stableSince >= 1500;
    }, 15000, 300);
    return listRows().filter(row => wanted.has(row.orderId));
  }
  async function runLookup(first) {
    let job = first, found = 0, count = 0;
    while (job?.ok) {
      count++;
      lookupStep(`${job.label}: tìm ${job.orderIds.length} mã đơn trong Nhật ký phiếu (Tất cả)…`);
      let rows = [], error = '';
      try { rows = await lookupOne(job); } catch (e) { error = e.message || String(e); }
      const result = await send({ type: 'TICKET_LOOKUP_RESULT', groupId: job.groupId, rows, error });
      if (result?.mapped) found++;
      lookupStep(result?.mapped ? `✓ ${job.label}: gán Ticket ${result.mapped}.` : `${job.label}: ${error || 'chưa gán được — xem trên Side Panel'}.`);
      job = await send({ type: 'GET_TICKET_LOOKUP' });
    }
    lookupStep(`✓ Xong: gán được ${found}/${count} ĐVVC. Tab này tự đóng.`);
  }

  (async () => {    if (/\/ticket\/create/.test(location.pathname)) return;
    if (/^\/ticket\/?$/.test(location.pathname)) { const job = await send({ type: 'GET_TICKET_LOOKUP' }); if (job?.ok) return runLookup(job); }
    const context = await send({ type: 'GET_TICKET_FOLLOWUP' });
    if (!context?.ok) return;
    currentTicketId = context.ticketId;
    if (/^\/ticket\/?$/.test(location.pathname)) return searchAndOpen(context);
    const ticketId = context.ticketId;
    const report = result => send({ type: 'TICKET_FOLLOWUP_RESULT', result: { ticketId, ...result } });
    const pathId = (location.pathname.match(/\/ticket\/detail\/(\d+)/) || [])[1];
    if (pathId !== ticketId) return report({ ok: false, error: `Trang mở phiếu ${pathId || '?'} khác phiếu ${ticketId}.` });
    // v2.2.27 — TikTok dựng khung "Gửi tin nhắn" chậm (~12 giây, đo trên trang thật) → chờ tới 60 giây, kéo xuống cuối trang trong lúc chờ.
    step(`#${ticketId}: đã mở phiếu, chờ khung Gửi tin nhắn…`);
    const loaded = await waitFor(() => {
      // Ô nhập rẻ hơn innerText cả trang → kiểm tra trước.
      if (replyBox() && pageText().includes(`#${ticketId}`)) return true;
      try { window.scrollTo(0, document.documentElement.scrollHeight); } catch (_) {}
      return false;
    }, 60000, 250);
    if (!loaded) {
      const status = readStatus(ticketId);
      return report({ ok: false, status, error: pageText().includes(`#${ticketId}`) ? 'Phiếu không có ô "Gửi tin nhắn" (có thể đã khóa hẳn).' : 'Không mở được phiếu — kiểm tra đúng shop đang đăng nhập.' });
    }
    await sleep(300);
    const status = readStatus(ticketId);
    const closed = CLOSED.test(norm(status));
    // Confirm a new matching message against the durable pre-send baseline.
    // The initial ticket can already contain identical text; that is not proof of a follow-up.
    if (context.sendingAt) {
      const found = Number.isSafeInteger(context.baselineCount) && context.baselineCount >= 0 &&
        messageCount(replyBox(), String(context.text || '')) > context.baselineCount;
      step(found ? `✓ #${ticketId}: tin bổ sung đã có trên luồng — chạy đơn kế.` : `#${ticketId}: chưa xác nhận tin bổ sung trên luồng — giữ phiếu để kiểm tra, không tự gửi lại.`, !found);
      return report({ ok: found, status, statusAfter: status, replied: found, attached: 0, attachSkipped: true,
        ...(found ? {} : { error: 'Đã có dấu gửi nhưng chưa xác nhận được tin bổ sung trên luồng. Giữ phiếu để kiểm tra tay; không tự gửi lại.' }) });
    }
    if (context.mode === 'auto' && !closed) return report({ ok: true, status, replied: false });
    const box = replyBox();
    box.scrollIntoView({ block: 'center' });
    step(`#${ticketId} (${status || '?'}): kéo xuống Gửi tin nhắn, điền nội dung…`);
    const text = String(context.text || '').slice(0, Number(box.maxLength) > 0 ? box.maxLength : 500);
    setNativeValue(box, text);
    // Đính kèm lại đúng các file của phiếu (Excel danh sách đơn + biên bản), đủ thẻ file mới Gửi.
    let attached = 0, attachSkipped = false;
    if (context.attachCount > 0) {
      const section = replySection(box);
      const before = attachmentState(section).count;
      step(`#${ticketId}: Tải lên ${context.attachCount} file (${(context.attachNames || []).join(', ')})…`);
      const upload = await send({ type: 'TICKET_FOLLOWUP_UPLOAD' }).catch(() => null);
      let stableSince = 0, ready = null;
      if (upload?.ok) {
        const waitCards = limit => waitFor(() => {
          const state = attachmentState(section);
          if (state.failed) return 'failed';
          if (state.count - before >= context.attachCount && !state.busy) { stableSince = stableSince || Date.now(); return Date.now() - stableSince >= 1500 ? 'ok' : null; }
          stableSince = 0; return null;
        }, limit, 300);
        ready = await waitCards(30000);
        // Còn đang tải (thanh tiến trình) → chờ thêm tối đa 30 giây.
        if (!ready && attachmentState(section).busy) ready = await waitCards(30000);
      }
      attached = Math.max(0, attachmentState(section).count - before);
      if (ready !== 'ok') {
        const error = !upload?.ok ? (upload?.error || 'Không đẩy được file') : ready === 'failed' ? 'TikTok báo tải lỗi' : `Mới xác nhận ${attached}/${context.attachCount} file`;
        step(`#${ticketId}: ${error} — giữ phiếu để thử lại, chưa bấm Gửi.`, true);
        return report({ ok: false, status, replied: false, attached, error: 'Chưa xác nhận đủ tệp đính kèm: ' + error });
      }
      if (box.value !== text) setNativeValue(box, text);
    }
    const button = await waitFor(() => { const el = sendButton(box); return el && !el.disabled && el.getAttribute('aria-disabled') !== 'true' && box.value === text ? el : null; }, 8000);
    if (!button) { step(`#${ticketId}: nút Gửi chưa bật.`, true); return report({ ok: false, status, error: 'Đã điền phản hồi nhưng nút Gửi chưa bật.' }); }
    const baseline = messageCount(box, text);
    const armed = await send({ type: 'TICKET_FOLLOWUP_SENDING', ticketId, baselineCount: baseline });
    if (!armed?.ok) return report({ ok: false, status, replied: false, error: armed?.error || 'Không ghi được trạng thái gửi.' });
    step(`#${ticketId}: đủ nội dung${attached ? ` + ${attached} file` : ''} → bấm Gửi…`);
    try { await trustedClick(button); } catch (_) { button.click(); }
    let posted = await waitFor(() => replyPosted(box, text, baseline), 6000, 300);
    // Click thật chưa trúng (nội dung còn nguyên, nút không ở trạng thái đang gửi) → bấm Gửi đúng 1 lần nữa.
    const sending = () => button.disabled || /loading/i.test(String(button.className)) || Boolean(button.querySelector('[class*="loading" i]'));
    if (!posted && box.isConnected && box.value === text && !sending() && messageCount(box, text) === baseline) {
      step(`#${ticketId}: chưa thấy nhận click → bấm Gửi lần nữa…`);
      button.click();
      posted = await waitFor(() => replyPosted(box, text, baseline), 20000, 400);
    } else if (!posted) posted = await waitFor(() => replyPosted(box, text, baseline), 16000, 400);
    await sleep(600);
    const statusAfter = readStatus(ticketId);
    if (!posted) {
      step(`#${ticketId}: đã bấm Gửi nhưng chưa thấy tin nhắn lên luồng — giữ phiếu và dấu gửi để kiểm tra, không tự gửi lại.`, true);
      return report({ ok: false, status, statusAfter, replied: false, attached,
        error: 'Đã bấm Gửi nhưng chưa thấy tin nhắn lên luồng — mở phiếu kiểm tra. Dấu gửi được giữ để tránh gửi trùng.' });
    }
    step(`✓ #${ticketId}: đã gửi lại nội dung${attached ? ` + ${attached} file` : ''}.`);
    return report(posted ? { ok: true, status, statusAfter, replied: true, attached, attachSkipped } : { ok: false, status, statusAfter, replied: false, attached, error: 'Đã bấm Gửi nhưng chưa thấy tin nhắn lên luồng — mở phiếu kiểm tra.' });
  })().catch(error => send({ type: 'TICKET_FOLLOWUP_RESULT', result: { ticketId: currentTicketId, ok: false, error: String(error?.message || error) } }));
})();
