/* =============================================================================
 * v0.11.19 — MÁY ĐO UPLOAD (chạy trong MAIN world của trang TikTok)
 *
 * Vì sao cần: từ v0.11.13 tới v0.11.18, tool coi "TikTok vẽ card tên file" là
 * "file đã lên". Sai: card hiện NGAY khi file BẮT ĐẦU upload, lúc đó file còn
 * đang bay. Tool bấm Gửi → file nào chưa bay xong là rớt khỏi phiếu. Đó là lý do
 * lúc thiếu Excel, lúc thiếu ảnh — ngẫu nhiên theo tốc độ mạng từng lần.
 *
 * Nguồn sự thật duy nhất là MẠNG: file chỉ thật sự lên khi request upload của
 * chính nó trả về thành công. Script này bọc XHR + fetch của trang, ghi lại mọi
 * request có mang file (FormData chứa Blob, hoặc body là Blob/ArrayBuffer) —
 * tên file, dung lượng, lúc bắt đầu, lúc xong, HTTP status, và mã lỗi trong JSON
 * (API TikTok hay trả HTTP 200 kèm code ≠ 0 khi thất bại).
 *
 * Chỉ QUAN SÁT: không sửa, không chặn, không chậm request nào của trang.
 * Mọi thứ bọc trong try/catch — lỗi ở đây không bao giờ làm hỏng TikTok.
 * ========================================================================== */
(function () {
  if (window.__OP_UPLOAD_PROBE__) return;
  window.__OP_UPLOAD_PROBE__ = true;

  const TAG = 'op-upload-probe';
  // Request "liên quan upload" (kể cả bước commit không mang file của ImageX).
  // Chỉ tính là "liên quan" khi xảy ra trong vòng 5s quanh một request mang file,
  // để request telemetry định kỳ của TikTok không làm mạng "không bao giờ im".
  const UPLOAD_URL_HINT = /(upload|imagex|\/tos|tos-|commit|applyimage|apply_upload|attach)/i;
  const RELATED_WINDOW_MS = 5000;
  let lastBlobActivityAt = 0;
  const records = [];
  let seq = 0;
  let relatedInflight = 0;
  let lastRelatedActivityAt = 0;

  function emit(kind, record) {
    try {
      window.postMessage({
        source: TAG,
        kind,
        json: JSON.stringify({
          record: record || null,
          relatedInflight,
          lastRelatedActivityAt
        })
      }, '*');
    } catch (_) {}
  }

  function describeBody(body) {
    const files = [];
    try {
      if (!body) return files;
      if (typeof FormData !== 'undefined' && body instanceof FormData) {
        for (const [, value] of body.entries()) {
          if (value && typeof value === 'object' && typeof value.size === 'number' && typeof value.slice === 'function') {
            files.push({ name: String(value.name || ''), size: value.size });
          }
        }
        return files;
      }
      if (typeof Blob !== 'undefined' && body instanceof Blob) {
        files.push({ name: String(body.name || ''), size: body.size });
        return files;
      }
      if (body instanceof ArrayBuffer && body.byteLength >= 512) {
        files.push({ name: '', size: body.byteLength });
        return files;
      }
      if (ArrayBuffer.isView(body) && body.byteLength >= 512) {
        files.push({ name: '', size: body.byteLength });
      }
    } catch (_) {}
    return files;
  }

  function jsonSaysFailed(text) {
    if (!text || text.length > 200000) return '';
    const trimmed = String(text).trim();
    if (!trimmed.startsWith('{')) return '';
    try {
      const json = JSON.parse(trimmed);
      if (typeof json.code === 'number' && json.code !== 0 && json.code !== 200) return `code ${json.code}${json.message ? ` ${json.message}` : ''}`;
      if (typeof json.status_code === 'number' && json.status_code !== 0) return `status_code ${json.status_code}`;
      if (json.ResponseMetadata && json.ResponseMetadata.Error) {
        const e = json.ResponseMetadata.Error;
        return `imagex ${e.Code || e.CodeN || ''} ${e.Message || ''}`.trim();
      }
      if (json.BaseResp && typeof json.BaseResp.StatusCode === 'number' && json.BaseResp.StatusCode !== 0) {
        return `BaseResp ${json.BaseResp.StatusCode}`;
      }
    } catch (_) {}
    return '';
  }

  function begin(method, url, body) {
    const files = describeBody(body);
    const related = files.length > 0 || (
      UPLOAD_URL_HINT.test(String(url || '')) && Date.now() - lastBlobActivityAt < RELATED_WINDOW_MS
    );
    if (!related) return null;
    const record = {
      id: ++seq,
      method: String(method || 'GET').toUpperCase(),
      url: String(url || '').slice(0, 300),
      files,
      startedAt: Date.now(),
      endedAt: 0,
      status: 0,
      ok: false,
      error: ''
    };
    relatedInflight += 1;
    lastRelatedActivityAt = record.startedAt;
    if (files.length) lastBlobActivityAt = record.startedAt;
    if (files.length) {
      records.push(record);
      if (records.length > 300) records.splice(0, records.length - 300);
    }
    emit('start', files.length ? record : null);
    return record;
  }

  function end(record, status, responseText, networkError) {
    if (!record || record.endedAt) return;
    record.endedAt = Date.now();
    record.status = Number(status) || 0;
    const httpOk = record.status >= 200 && record.status < 300;
    const apiError = httpOk ? jsonSaysFailed(responseText) : '';
    record.ok = httpOk && !apiError && !networkError;
    record.error = networkError || apiError || (httpOk ? '' : `HTTP ${record.status}`);
    relatedInflight = Math.max(0, relatedInflight - 1);
    lastRelatedActivityAt = record.endedAt;
    if (record.files.length) lastBlobActivityAt = record.endedAt;
    emit('end', record.files.length ? record : null);
  }

  /* ---- XHR ---- */
  try {
    const XHR = XMLHttpRequest.prototype;
    const origOpen = XHR.open;
    const origSend = XHR.send;
    XHR.open = function (method, url) {
      try { this.__opProbeReq = { method, url: String(url) }; } catch (_) {}
      return origOpen.apply(this, arguments);
    };
    XHR.send = function (body) {
      let record = null;
      try {
        const req = this.__opProbeReq || {};
        record = begin(req.method, req.url, body);
        if (record) {
          const xhr = this;
          xhr.addEventListener('loadend', () => {
            let text = '';
            try {
              if (xhr.responseType === '' || xhr.responseType === 'text') text = xhr.responseText;
              else if (xhr.responseType === 'json' && xhr.response) text = JSON.stringify(xhr.response);
            } catch (_) {}
            end(record, xhr.status, text, xhr.status === 0 ? 'network/abort' : '');
          });
        }
      } catch (_) {}
      return origSend.apply(this, arguments);
    };
  } catch (_) {}

  /* ---- fetch ---- */
  try {
    const origFetch = window.fetch;
    if (typeof origFetch === 'function') {
      window.fetch = function (input, init) {
        let record = null;
        try {
          const url = typeof input === 'string' ? input : (input && input.url) || String(input);
          const method = (init && init.method) || (input && input.method) || 'GET';
          record = begin(method, url, init && init.body);
        } catch (_) {}
        const promise = origFetch.apply(this, arguments);
        if (record) {
          promise.then((response) => {
            try {
              response.clone().text()
                .then((text) => end(record, response.status, text, ''))
                .catch(() => end(record, response.status, '', ''));
            } catch (_) { end(record, response.status, '', ''); }
          }, (error) => end(record, 0, '', `network ${error && error.message ? error.message : 'error'}`));
        }
        return promise;
      };
    }
  } catch (_) {}

  /* ---- snapshot theo yêu cầu (content script có thể nạp sau) ---- */
  window.addEventListener('message', (event) => {
    try {
      if (event.source !== window || !event.data || event.data.source !== `${TAG}-ask`) return;
      window.postMessage({
        source: TAG,
        kind: 'snapshot',
        json: JSON.stringify({ records, relatedInflight, lastRelatedActivityAt })
      }, '*');
    } catch (_) {}
  });
})();
