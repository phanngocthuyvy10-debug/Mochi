/* v2.2.9 — Chạy nền: xác định tab nào đang là "tab làm việc" của extension và giữ tab đó thức (lib/op-keepalive.js).
   Tab làm việc = tab đang lấy dữ liệu Performance + tab form ticket đang được tool điền/gửi.
   Đặt autoDiscardable:false để Chrome không giải phóng tab khi người dùng ở tab khác; trả lại như cũ khi xong. */
const OP_KEEP = { tabs: new Set() };

/* "Giữ dính" tab làm việc: Chrome NGỪNG VẼ tab bị ẩn (đổi tab / đổi cửa sổ / bị che) → bảng Seller Center, form ticket không
   cập nhật, tool đứng. Gắn DevTools vào ĐÚNG tab đó và bật Emulation.setFocusEmulationEnabled: Chrome coi tab như đang được xem
   (vẫn vẽ, vẫn chạy đúng nhịp) dù bạn đang làm việc ở tab / cửa sổ khác. Xong việc tự gỡ.
   Trong lúc gắn Chrome hiện thanh "… started debugging this browser" — đừng bấm Cancel (Cancel = thả tab, tool tôn trọng và
   không gắn lại tab đó). */
const OP_DBG = new Map(); // tabId → 'on' | 'declined'
const opDbg = (fn, ...args) => new Promise((resolve, reject) => chrome.debugger[fn](...args, (r) => {
  const e = chrome.runtime.lastError; if (e) reject(new Error(e.message)); else resolve(r);
}));
async function opHoldVisible(id) {
  // v2.2.64 — 'gone' (phiên DevTools rớt khi trang tải lại / đổi tiến trình) → gắn lại; chỉ 'declined' (bấm Cancel) mới tôn trọng.
  if (OP_DBG.has(id) && OP_DBG.get(id) !== 'gone') return;
  OP_DBG.set(id, 'on');
  try {
    await opDbg('attach', { tabId: id }, '1.3');
  } catch (e) {
    // "already attached": thường là phiên của chính tool trước khi service worker khởi động lại → dùng tiếp.
    // Lỗi khác (DevTools đang mở, extension khác đang gắn…) → bỏ qua, chỉ dùng cơ chế nhẹ trong lib/op-keepalive.js.
    if (!/already attached/i.test(e.message)) { OP_DBG.delete(id); return; }
  }
  await opDbg('sendCommand', { tabId: id }, 'Emulation.setFocusEmulationEnabled', { enabled: true }).catch(() => {});
  await opDbg('sendCommand', { tabId: id }, 'Page.setWebLifecycleState', { state: 'active' }).catch(() => {});
}
async function opReleaseVisible(id) {
  const st = OP_DBG.get(id);
  OP_DBG.delete(id);
  if (st === 'on') await opDbg('detach', { tabId: id }).catch(() => {});
}
chrome.debugger.onDetach.addListener((source, reason) => {
  if (source.tabId != null && OP_DBG.get(source.tabId) === 'on') OP_DBG.set(source.tabId, reason === 'canceled_by_user' ? 'declined' : 'gone');
});

async function opWorkTabs() {
  const st = await chrome.storage.local.get(['state', 'ticketTabPayloads', 'ticketOpenGroups', 'handoverRun', 'fhrAuto', 'cancelReturnFollowRun']);
  const ids = new Set();
  const run = st.state?.run;
  if (run?.tabId != null && (['collecting', 'enriching'].includes(run.phase) || run.workflow?.active)) ids.add(Number(run.tabId));
  for (const id of Object.keys(st.ticketTabPayloads || {})) if (Number.isInteger(Number(id))) ids.add(Number(id));
  const fresh = Date.now() - 2 * 3600e3;
  for (const g of Object.values(st.ticketOpenGroups || {})) {
    if (g?.tabId != null && !['mapped', 'closed'].includes(g.status) && Date.parse(g.openedAt || 0) > fresh) ids.add(Number(g.tabId));
  }
  // v2.2.18 — tab "FHR tính lại" tool tự mở ở nền: giữ cho trang vẫn vẽ để đọc được số, tự thả khi đóng.
  for (const id of Object.keys(st.fhrAuto?.tabs || {})) if (Number.isInteger(Number(id))) ids.add(Number(id));
  const h = st.handoverRun;
  if (h?.activeTabId != null && !h.doneAt) ids.add(Number(h.activeTabId));
  // v2.2.27 — tab phản hồi phiếu đòi hàng: ô "Gửi tin nhắn" chỉ dựng ra khi tab được vẽ (~12 giây) → phải giữ thức.
  const follow = st.cancelReturnFollowRun?.active;
  if (follow?.tabId != null) ids.add(Number(follow.tabId));
  // v2.2.64 — tab phụ của làn phản hồi song song: giữ thức suốt cả làn. Trước đây giữa 2 phiếu tab bị thả (gỡ DevTools,
  // tắt keepalive) rồi gắn lại ngay khi mở phiếu kế → trang phiếu dựng chậm / đứng vì đúng lúc tải chưa được giữ thức.
  const lane = st.cancelReturnFollowRun;
  if ((lane?.lane || lane?.reuseTab) && !lane.doneAt && lane.replyTabId != null) ids.add(Number(lane.replyTabId));
  return ids;
}

async function opSyncKeepAlive() {
  const next = await opWorkTabs();
  for (const id of next) {
    if (OP_KEEP.tabs.has(id)) continue;
    OP_KEEP.tabs.add(id);
    chrome.tabs.update(id, { autoDiscardable: false }).catch(() => {});
    chrome.tabs.sendMessage(id, { type: 'OP_KEEPALIVE', on: true }).catch(() => {});
  }
  for (const id of next) opHoldVisible(id).catch(() => {});
  for (const id of [...OP_KEEP.tabs]) {
    if (next.has(id)) continue;
    OP_KEEP.tabs.delete(id);
    chrome.tabs.update(id, { autoDiscardable: true }).catch(() => {});
    chrome.tabs.sendMessage(id, { type: 'OP_KEEPALIVE', on: false }).catch(() => {});
  }
  for (const id of [...OP_DBG.keys()]) if (!next.has(id)) opReleaseVisible(id).catch(() => {});
}

let opKeepTimer = null;
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local' || !(changes.state || changes.ticketTabPayloads || changes.ticketOpenGroups || changes.handoverRun || changes.fhrAuto || changes.cancelReturnFollowRun)) return;
  clearTimeout(opKeepTimer);
  opKeepTimer = setTimeout(() => opSyncKeepAlive().catch(() => {}), 300);
});
chrome.tabs.onRemoved.addListener((id) => { OP_KEEP.tabs.delete(id); OP_DBG.delete(id); });
// Lưới an toàn: service worker có thể ngủ giữa chừng → đồng bộ lại mỗi 30 giây theo nhịp alarm sẵn có.
chrome.alarms.onAlarm.addListener((a) => { if (a.name === 'op-auto') opSyncKeepAlive().catch(() => {}); });

chrome.runtime.onMessage.addListener((m, sender, respond) => {
  if (sender.id !== chrome.runtime.id) return false;
  if (m?.type === 'OP_SLEEP') {
    setTimeout(() => respond({ ok: true }), Math.max(0, Math.min(Number(m.ms) || 0, 1000)));
    return true;
  }
  if (m?.type === 'OP_KEEPALIVE_QUERY') {
    const id = sender.tab?.id;
    opWorkTabs().then((ids) => {
      const on = id != null && ids.has(id);
      if (on && !OP_KEEP.tabs.has(id)) { OP_KEEP.tabs.add(id); chrome.tabs.update(id, { autoDiscardable: false }).catch(() => {}); }
      respond({ on });
    }).catch(() => respond({ on: false }));
    return true;
  }
  return false;
});
opSyncKeepAlive().catch(() => {});
