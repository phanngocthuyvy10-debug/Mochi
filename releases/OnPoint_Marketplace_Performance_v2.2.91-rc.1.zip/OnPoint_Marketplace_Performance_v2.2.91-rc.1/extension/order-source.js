/* Learn read-only performance list and Order Detail requests from this signed-in Seller Center tab.
   No invented private endpoints, cookie export or writes to TikTok. Templates live only in this page. */
(() => {
  if (window.OPOrderSource) return;
  const D = window.OPDetails, details = new Map(), detailFetched = new Set();
  let resolver, shop = '', template, checkedAt = 0, checking, listTemplate;
  const schemas = [], observedLists = new Map();
  const idKeys = new Set(['order_id','main_order_id','order_ids','main_order_ids']);
  const forbidden = /(?:^|[\/_.-])(?:create|update|delete|cancel|confirm|ship|dispatch|pack|print|refund|return|upload|export|download|batch_process)(?:$|[\/_.-])/i;
  const readPath = p => /^\/api\//.test(p) && /orders?|experience[-_]score|performance|defect/.test(p) && !forbidden.test(p) && /(?:^|[\/_.-])(?:detail|details|get|query|list|search)(?:$|[\/_.-])/i.test(p);
  function scalarId(v) {
    if (Array.isArray(v)) return v.length === 1 ? D.id(v[0]) : '';
    if (typeof v === 'string' && /^\[/.test(v)) { try { return scalarId(JSON.parse(v)); } catch { return ''; } }
    return D.id(v);
  }
  function request(url, init = {}) {
    let u; try { u = new URL(typeof url === 'string' ? url : url.href || url.url,location.origin); } catch { return null; }
    const method = String(init.method || (typeof url !== 'string' && url.method) || 'GET').toUpperCase();
    if (u.origin !== location.origin || !/^\/api\//.test(u.pathname) || forbidden.test(u.pathname) || !['GET','POST'].includes(method)) return null;
    // A GET response with real operational fields is evidence of a read source.
    // Unknown POST routes remain diagnostic-only; they must not be replayed.
    if(!readPath(u.pathname) && method!=='GET')return {path:u.pathname,method,diagnosticOnly:true};
    let body = null;
    if (method === 'POST') { try { body = JSON.parse(String(init.body).replace(/(:\s*|[\[,]\s*)(-?\d{16,})(?=\s*[,}\]])/g,'$1"$2"')); } catch { return null; } }
    const slots = [];
    for (const [k,v] of u.searchParams) if (idKeys.has(k) && scalarId(v)) slots.push({where:'query',key:k,id:scalarId(v),array:/^\[/.test(v)});
    function scan(o,path = []) {
      if (!o || typeof o !== 'object' || path.length > 6) return;
      for (const [k,v] of Object.entries(o)) {
        if (idKeys.has(k) && scalarId(v)) slots.push({where:'body',path:[...path,k],id:scalarId(v),array:Array.isArray(v)});
        else if (v && typeof v === 'object' && !Array.isArray(v)) scan(v,[...path,k]);
      }
    }
    scan(body);
    const ids = new Set(slots.map(s=>s.id));
    const headers = {};
    const given = init.headers || (typeof url !== 'string' && url.headers);
    const pairs=Array.isArray(given)?given:given?.forEach?(()=>{const p=[];given.forEach((v,k)=>p.push([k,v]));return p;})():Object.entries(given || {});
    for(const [key,value]of pairs)if(!/^(?:cookie|host|origin|referer|content-length|user-agent|sec-)/i.test(key))headers[key]=String(value);
    // Session headers stay only in this tab; diagnostics never export their values.
    return {url:u.href,path:u.pathname,method,body,headers,slots,orderId:ids.size === 1 ? [...ids][0] : ''};
  }
  async function bindShop(force = false) {
    if (!resolver) throw Error('Chưa nhận diện store.');
    if (!force && shop && Date.now()-checkedAt < 3000) return shop;
    if (checking) return checking;
    checking = (async () => {
      const id = await resolver();
      if (shop && shop !== id.shopId) { details.clear(); detailFetched.clear(); template = null; listTemplate = null; schemas.length = 0; observedLists.clear(); }
      shop = id.shopId; checkedAt = Date.now(); return shop;
    })();
    try { return await checking; } finally { checking = null; }
  }
  async function observe(req, text) {
    if (!req || text.length > 20*1024*1024) return;
    let j; try { j = JSON.parse(text.replace(/(:\s*|[\[,]\s*)(-?\d{16,})(?=\s*[,}\]])/g,'$1"$2"')); } catch { return; }
    if (j.code != null && Number(j.code) !== 0) return;
    const mapping=listTemplate?.path===req.path && listTemplate?.method===req.method?listTemplate.mapping:null;
    const rows = req.diagnosticOnly?[]:extractRows(j,mapping,req.orderId || undefined).filter(r=>D.required.some(k=>!!r[k]));
    const shape = shapeOf(j);
    const entry={path:req.path,method:req.method,shape,fields:rows[0] ? Object.keys(rows[0]) : [],replayEligible:!req.diagnosticOnly && rows.length>0};
    const at=schemas.findIndex(x=>x.path===req.path&&x.method===req.method);
    if(at<0){if(schemas.length<60)schemas.push(entry);}else if(entry.shape.length>schemas[at].shape.length||entry.fields.length>schemas[at].fields.length)schemas[at]=entry;
    if(req.diagnosticOnly)return;
    const potentialList=!req.orderId && /experience|performance|health|fulfill|defect/i.test(req.path);
    if(!rows.length && !potentialList)return;
    try { await bindShop(true); } catch { return; }
    const u = new URL(req.url);
    for (const key of ['oec_seller_id','seller_id','shop_id']) {
      const sid = u.searchParams.get(key) || req.body?.[key];
      if (sid && String(sid) !== shop) return;
    }
    // Keep at most four recent read-only list samples in this tab, never in exports.
    // A rendered table can later identify previously unknown JSON field names.
    if(potentialList) {
      const key=req.method+' '+req.path;observedLists.delete(key);
      observedLists.set(key,{req,j,shop,seenAt:Date.now()});
      if(observedLists.size>4)observedLists.delete(observedLists.keys().next().value);
    }
    if (!rows.length) return;
    for (const r of rows) details.set(r.order_id,D.merge(details.get(r.order_id) || r,r));
    // A replay needs an explicit order-id slot, and that exact id in the response.
    if (req.orderId && req.slots.length && rows.some(r=>r.order_id === req.orderId)) {
      template = {...req,shop,seenAt:Date.now()};
      detailFetched.add(req.orderId);
    }
    if (!req.orderId && rows.some(r=>r.actual_handover_at)) {
      listTemplate = {...req,shop,mapping,seenAt:Date.now(),metric:metricHint(),period:periodOf(req)};
    }
  }
  function shapeOf(j) {
    const out=[];
    function walk(o,path,depth){if(!o||typeof o!=='object'||depth>4||out.length>=20)return;if(Array.isArray(o)){if(o[0])walk(o[0],path+'[]',depth+1);return;}out.push({path,keys:Object.keys(o).slice(0,60)});for(const [k,v]of Object.entries(o))if(v&&typeof v==='object')walk(v,path+'.'+k,depth+1);}
    walk(j,'$',0);return out;
  }
  function metricHint() {
    const u=new URL(location.href || location.origin);
    if (u.searchParams.get('metricId')==='020204') return 'FDR'; // id visible in the supplied Seller Center screenshot.
    const text=String(window.document?.body?.innerText || '');
    const hit=[['FDR',/\bFDR\b|Tỷ lệ gửi hàng nhanh/i],['NDDR',/\bNDDR\b|Tỷ lệ giao nhanh 24h/i],['LDR',/\bLDR\b|Tỷ lệ gửi hàng muộn/i],['SFCR',/\bSFCR\b|Tỷ lệ hủy do lỗi/i]].filter(([,rx])=>rx.test(text));
    return hit.length===1?hit[0][0]:'';
  }
  function periodOf(req) {
    const values=Object.fromEntries(new URL(req.url).searchParams);
    function scan(o,depth=0){if(!o||typeof o!=='object'||depth>6)return;for(const [key,v]of Object.entries(o)){if(v&&typeof v==='object'&&!Array.isArray(v))scan(v,depth+1);else if(v!=null)values[key]=v;}}
    scan(req.body);
    const date=v=>{if(v==null)return '';const s=String(v);if(/^\d{8}$/.test(s))return s.slice(0,4)+'-'+s.slice(4,6)+'-'+s.slice(6,8);if(/^\d{4}-\d{2}-\d{2}/.test(s))return s.slice(0,10);return D.time(v).slice(0,10);};
    return {start:date(values.start_date??values.date_start??values.start_time),end:date(values.end_date??values.date_end??values.end_time)};
  }
  function extractRows(j,mapping,targetId) {
    if(!mapping)return D.extract(j,targetId);
    const by=new Map(D.extract(j,targetId).map(r=>[r.order_id,r]));
    for(const r of D.extractMapped(j,mapping))if(!targetId||targetId===r.order_id)by.set(r.order_id,D.merge(by.get(r.order_id)||r,r));
    return [...by.values()];
  }
  function learnRenderedSource(expectedShop) {
    const witnesses=window.OPPerformanceTable?.samples() || [],view=window.OPPerformanceTable?.status();
    for(const sample of [...observedLists.values()].reverse()) {
      if(sample.shop!==expectedShop || Date.now()-sample.seenAt>30*60*1000)continue;
      const mapping=D.learnTableMapping(sample.j,witnesses);if(!mapping)continue;
      listTemplate={...sample.req,shop:expectedShop,seenAt:sample.seenAt,mapping,metric:view?.metric || metricHint(),period:periodOf(sample.req)};
      return listTemplate;
    }
    return null;
  }
  function pageInfo(j,mapping) {
    let raw=[],total=null,more=null,next=null;
    function walk(o,depth){if(!o||typeof o!=='object'||depth>6)return;if(Array.isArray(o)){if(o.length&&o.slice(0,3).some(x=>extractRows(x,mapping).length)&&o.length>raw.length)raw=o;return;}for(const [k,v]of Object.entries(o)){if(/^(?:total|total_count|total_num|total_records)$/.test(k)&&Number.isSafeInteger(Number(v))&&Number(v)>=0)total=Number(v);if(/^(?:has_more|has_next)$/.test(k))more=v===true||v===1||v==='true';if(/^(?:next_cursor|next_page_token|next_offset)$/.test(k))next=v;if(v&&typeof v==='object')walk(v,depth+1);}}
    walk(j,0);return {raw,total,more,next};
  }
  function pagination(req) {
    const slots=[];
    const kinds={offset:'offset',start_index:'offset',page:'page',page_no:'page',page_index:'page',page_number:'page',current_page:'page',cursor:'cursor',page_token:'cursor',limit:'size',page_size:'size',pageSize:'size'};
    for(const [key,value]of new URL(req.url).searchParams)if(kinds[key])slots.push({where:'query',key,kind:kinds[key],value});
    function walk(o,path=[]){if(!o||typeof o!=='object'||path.length>6)return;for(const [key,value]of Object.entries(o)){if(kinds[key])slots.push({where:'body',path:[...path,key],kind:kinds[key],value});else if(value&&typeof value==='object'&&!Array.isArray(value))walk(value,[...path,key]);}}
    walk(req.body);return slots;
  }
  function pageRequest(t, slots, page, offset, cursor) {
    const r=replay({...t,slots:[]},''),u=new URL(r.url),body=t.body?JSON.parse(r.init.body):null;
    for(const s of slots){if(s.kind==='size')continue;const v=s.kind==='offset'?offset:s.kind==='page'?page:cursor;if(v==null)continue;if(s.where==='query')u.searchParams.set(s.key,v);else{let o=body;for(const p of s.path.slice(0,-1))o=o[p];o[s.path.at(-1)]=typeof s.value==='number'?Number(v):v;}}
    if(body)r.init.body=JSON.stringify(body);r.url=u.href;return r;
  }
  async function performance(expectedShop, code, ids, period, progress) {
    if(await bindShop(true)!==expectedShop)throw Error('Login đúng store đã thu thập trước khi đọc bảng hiệu suất.');
    const t=listTemplate || learnRenderedSource(expectedShop);
    if(!t||t.shop!==expectedShop||Date.now()-t.seenAt>30*60*1000) {
      if(window.OPPerformanceTable)return window.OPPerformanceTable.read({expectedShop,code,ids,period,identity:bindShop,progress});
      throw Error('Chưa thấy API có Actual handover time và bộ đọc bảng chưa được nạp. Reload extension rồi tải lại tab Seller Center một lần.');
    }
    if(t.metric&&t.metric!==code)throw Error(`Trang đang là ${t.metric}, nhưng panel chọn ${code}. Mở đúng bảng KPI rồi thử lại.`);
    if(t.period.start&&t.period.end&&(t.period.start!==period.start||t.period.end!==period.end))throw Error(`Bảng đang ở kỳ ${t.period.start} → ${t.period.end}, khác kỳ KPI ${period.start} → ${period.end}. Chọn lại kỳ trên TikTok.`);
    const slots=pagination(t), pager=slots.find(s=>s.kind!=='size'), size=Number(slots.find(s=>s.kind==='size')?.value)||0;
    let page=pager?.kind==='page'&&Number(pager.value)===0?0:1,offset=0,cursor='',fetched=0,complete=false,note='',total=null;
    const seen=new Set(),target=new Set(ids),all=new Map();
    for(let n=0;;n++){
      if(await bindShop(true)!==expectedShop)throw Error('Store đã đổi. Không ghi dữ liệu bảng hiệu suất.');
      const r=pageRequest(t,slots,page,offset,cursor),response=await window.fetch(r.url,r.init);
      if(!response.ok)throw Error(`API bảng hiệu suất: HTTP ${response.status}. Dữ liệu đã đọc được vẫn giữ.`);
      let j;try{j=JSON.parse((await response.text()).replace(/(:\s*|[\[,]\s*)(-?\d{16,})(?=\s*[,}\]])/g,'$1"$2"'));}catch{throw Error('API bảng hiệu suất không trả JSON.');}
      if(j.code!=null&&Number(j.code)!==0)throw Error('API bảng hiệu suất: '+(j.message||j.code));
      const info=pageInfo(j,t.mapping),rows=extractRows(j,t.mapping),key=JSON.stringify(info.raw.length?info.raw:rows);
      if(seen.has(key)){note='API lặp trang; chưa xác minh đủ dữ liệu';break;}seen.add(key);
      if(!rows.length){complete=info.total===0||total!=null&&fetched>=total||info.more===false;note=complete?'':'API dừng trả dòng; chưa xác minh đủ dữ liệu';break;}
      fetched+=info.raw.length||rows.length;total=info.total??total;
      for(const row of rows)if(target.has(row.order_id))all.set(row.order_id,D.merge(all.get(row.order_id)||row,row));
      const matched=rows.filter(r=>target.has(r.order_id));
      const message=`Bảng ${code}: ${all.size}/${target.size} mã đơn khớp · ${fetched}${total!=null?'/'+total:''} dòng nguồn`;
      if(!matched.length)progress({msg:message});
      for(let i=0;i<matched.length;i+=100)progress({msg:message,shopId:expectedShop,rows:matched.slice(i,i+100),metric:code});
      if(info.more===false||total!=null&&fetched>=total){complete=true;break;}
      if(!pager){note='API không có tham số phân trang đã nhận diện; chưa khẳng định đọc hết';break;}
      if(pager.kind==='cursor'){if(info.next==null||info.next===''){note='API chưa trả cursor tiếp theo';break;}cursor=info.next;}
      else if(pager.kind==='offset')offset+=info.raw.length||rows.length;
      else page++;
      if(total==null&&info.more==null&&size&&(info.raw.length||rows.length)<size){complete=true;break;}
      await new Promise(r=>setTimeout(r,250));
    }
    const fieldCounts=D.summary([...all.values()]).counts,handoverFound=fieldCounts.actual_handover_at;
    if(handoverFound<target.size)note=[note,`Còn ${target.size-handoverFound} mã chưa có Actual handover time.`].filter(Boolean).join(' ');
    return {shopId:expectedShop,total:target.size,found:all.size,missing:target.size-all.size,handoverFound,fieldCounts,failed:0,source:t.path,sourceRows:fetched,sourceTotal:total,listComplete:complete,note,metric:code,period:t.period};
  }
  const originalFetch = window.fetch;
  window.fetch = async function (...args) {
    // fetch(new Request(...)) carries the body in the Request stream, not init.body.
    // Clone before calling fetch; never consume or delay the site's request.
    let pending;
    const input=args[0], init=args[1]||{};
    if(typeof input!=='string' && input?.clone && init.body==null && String(init.method||input.method).toUpperCase()==='POST') {
      try {pending=input.clone().text().then(body=>request(input,{...init,body})).catch(()=>null);}catch{}
    }
    const req = pending || request(input,init);
    const response = await originalFetch.apply(this,args);
    if (req && response.ok) {
      try { Promise.all([Promise.resolve(req),response.clone().text()]).then(([r,t])=>observe(r,t)).catch(()=>{}); } catch { /* caller's response is untouched */ }
    }
    return response;
  };
  if (window.XMLHttpRequest) {
    const proto = window.XMLHttpRequest.prototype, open = proto.open, send = proto.send, header = proto.setRequestHeader;
    proto.open = function (method,url,...rest) { this.__opReadRequest = {method,url,headers:{}}; return open.call(this,method,url,...rest); };
    if(header)proto.setRequestHeader=function(key,value){if(this.__opReadRequest)this.__opReadRequest.headers[key]=value;return header.call(this,key,value);};
    proto.send = function (body) {
      const raw = this.__opReadRequest, req = raw && request(raw.url,{method:raw.method,body,headers:raw.headers});
      if (req) this.addEventListener('load',()=>{
        if (this.status < 200 || this.status >= 300) return;
        try { observe(req,this.responseType === 'json' ? JSON.stringify(this.response) : this.responseText).catch(()=>{}); } catch {}
      },{once:true});
      return send.call(this,body);
    };
  }
  function replay(t,id) {
    const u = new URL(t.url), body = t.body ? JSON.parse(JSON.stringify(t.body)) : null;
    for (const k of [...u.searchParams.keys()]) if (/^(?:msToken|X-Bogus|X-Gnarly|signature|sign|timestamp)$/i.test(k)) u.searchParams.delete(k);
    for (const s of t.slots) {
      const value = s.array ? [id] : id;
      if (s.where === 'query') u.searchParams.set(s.key,s.array ? JSON.stringify(value) : value);
      else { let o = body; for (const p of s.path.slice(0,-1)) o = o[p]; o[s.path.at(-1)] = value; }
    }
    return {url:u.href,init:{method:t.method,credentials:'include',headers:{...(body?{'content-type':'application/json'}:{}),...(t.headers || {})},...(body ? {body:JSON.stringify(body)} : {})}};
  }
  async function enrich(expectedShop, ids, progress) {
    if (await bindShop(true) !== expectedShop) throw Error('Store đang login khác store đã thu thập. Không lấy chi tiết.');
    const t = template;
    if (!t || t.shop !== expectedShop || Date.now()-t.seenAt > 30*60*1000) throw Error('Mở chi tiết một đơn hàng của store này trên Seller Center (F5 nếu trang đã mở), rồi bấm Bổ sung chi tiết đơn lỗi. Extension cần đọc yêu cầu thật của TikTok trước.');
    const unique = [...new Set(ids.filter(D.id))]; let found = 0, failed = 0, batch = [];
    for (let i = 0; i < unique.length; i++) {
      if (i % 10 === 0 && await bindShop(true) !== expectedShop) throw Error('Store đã đổi giữa chừng. Chi tiết đã đọc được vẫn giữ cục bộ.');
      const id = unique[i]; let row = details.get(id);
      // A row cached from a failure list may contain only Placement time.
      // It must not skip the actual detail request for this order.
      if (!detailFetched.has(id)) {
        const r = replay(t,id), response = await window.fetch(r.url,r.init);
        if (response.status === 401 || response.status === 403) throw Error('TikTok từ chối quyền đọc chi tiết. Login lại đúng store hoặc dùng file xuất đơn hàng.');
        if (response.status === 429) throw Error('TikTok giới hạn lượt đọc. Dữ liệu đã lấy được vẫn giữ; chờ rồi bấm bổ sung tiếp.');
        let j; try { j = JSON.parse((await response.text()).replace(/(:\s*|[\[,]\s*)(-?\d{16,})(?=\s*[,}\]])/g,'$1"$2"')); } catch { throw Error('API chi tiết trả nội dung không phải JSON. Mở lại một đơn hàng rồi thử tiếp.'); }
        if (!response.ok || j.code != null && Number(j.code) !== 0) { failed++; }
        else {
          const fetched = D.extract(j,id).find(o=>o.order_id === id);
          if (fetched && D.required.some(k=>fetched[k])) {
            row = D.merge(row || {order_id:id},fetched);
            details.set(id,row); detailFetched.add(id);
          }
        }
      }
      if (row && D.required.some(k=>k!=='created_at' && row[k])) { found++; batch.push(row); }
      if (batch.length || i === unique.length-1) {
        if (await bindShop(true) !== expectedShop) throw Error('Store đã đổi. Không ghi batch chi tiết.');
        progress({msg:`Chi tiết: ${i+1}/${unique.length} đơn · có dữ liệu ${found}`,shopId:expectedShop,rows:batch}); batch = [];
      } else progress({msg:`Chi tiết: ${i+1}/${unique.length} đơn · có dữ liệu ${found}`});
      if (i < unique.length-1) await new Promise(r=>setTimeout(r,250));
    }
    if (await bindShop(true) !== expectedShop) throw Error('Store đã đổi. Không xác nhận hoàn tất.');
    return {shopId:expectedShop,total:unique.length,found,missing:unique.length-found,failed,source:t.path};
  }
  window.OPOrderSource = {bind:fn=>{resolver=fn;},enrich,performance,status:()=>{const dom=window.OPPerformanceTable?.status?.();return {ready:!!template,cached:details.size,source:template?.path || '',performanceReady:!!listTemplate || !!dom?.ready,performanceSource:listTemplate?.path || (dom?.ready?'rendered-performance-table':''),metric:listTemplate?.metric || dom?.metric || '',period:listTemplate?.period || dom?.period || null};},diagnostic:()=>({version:4,pagePath:location.pathname,requiredFields:D.required,schemas,table:window.OPPerformanceTable?.status?.() || null,navigation:window.OPPerformanceTable?.navigation?.() || null,status:window.OPOrderSource.status()})};
})();
