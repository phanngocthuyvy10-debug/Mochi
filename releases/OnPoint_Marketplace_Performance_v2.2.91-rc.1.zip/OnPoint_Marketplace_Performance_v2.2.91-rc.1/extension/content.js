/* Isolated-world bridge: panel/background <-> tts-api.js (page world). */
(() => {
  if (window.__opPerfContent || window.top !== window) return; window.__opPerfContent = true;
  const pending = new Map();
  window.addEventListener('message', e => {
    if (e.source !== window || e.origin !== location.origin || e.data?.type !== 'OP_TTS_RES') return;
    const p = pending.get(e.data.id); if (!p) return;
    if (e.data.kind === 'PROGRESS') { p.arm(); p.onProgress?.(String(e.data.msg || '').slice(0, 300),e.data); return; }
    pending.delete(e.data.id); clearTimeout(p.timer);
    e.data.kind === 'DONE' ? p.resolve(e.data.result) : p.reject(Error(e.data.error || 'Lỗi không xác định'));
  });
  function api(action, onProgress, ms = 240000, opts) {
    return new Promise((resolve, reject) => {
      const id = crypto.randomUUID();
      const p = {resolve,reject,onProgress,timer:null,arm:()=>{clearTimeout(p.timer);p.timer=setTimeout(()=>{pending.delete(id);reject(Error('Seller Center không phản hồi trong thời gian chờ. Chi tiết đã đọc được vẫn giữ; F5 rồi thử tiếp.'));},ms);}};
      p.arm(); pending.set(id,p);
      window.postMessage({ type: 'OP_TTS_REQ', id, action, opts }, location.origin);
    });
  }
  const send = m => chrome.runtime.sendMessage(m).catch(() => {});
  const loginPage = () => /login|passport|university|^\/edu\/|account\/register/.test(location.pathname);

  async function identity(retries = 4) {
    for (let i = 0; ; i++) {
      try { return await api('identity', null, 15000); }
      catch (err) { if (i >= retries) throw err; await new Promise(r => setTimeout(r, 1500)); }
    }
  }

  chrome.runtime.onMessage.addListener((m, sender, respond) => {
    if (sender.id !== chrome.runtime.id) return false;
    if (m.type === 'IDENTITY_NOW') {
      if (loginPage()) { respond({ error: 'Tab đang ở trang đăng nhập. Login store trước.' }); return false; }
      identity(2).then(r => respond({ identity: r }), e => respond({ error: e.message }));
      return true;
    }
    if (m.type === 'COLLECT') {
      respond({ ok: true });
      api('collect', (msg,data) => send(data?.snapshotMetrics?{type:'COLLECT_SNAPSHOT',runId:m.runId,taskId:m.taskId,shopId:data.shopId,metrics:data.snapshotMetrics}:data?.rows?{type:'COLLECT_BATCH',runId:m.runId,taskId:m.taskId,msg,metric:data.metric,shopId:data.shopId,rows:data.rows}:{ type: 'PROGRESS', runId: m.runId, taskId:m.taskId, msg }), 300000, { historyDays: m.historyDays })
        .then(data => send({ type: 'COLLECTED', runId: m.runId, taskId:m.taskId, data }))
        .catch(e => send({ type: 'COLLECT_FAILED', runId: m.runId, taskId:m.taskId, error: e.message }));
      return false;
    }
    if (m.type === 'ENRICH_ORDERS') {
      respond({ok:true});
      api(m.mode==='performance'?'performance':'enrich',(msg,data)=>send(data.rows ? {type:'DETAILS_BATCH',runId:m.runId,taskId:m.taskId,shopId:data.shopId,rows:data.rows,msg} : {type:'PROGRESS',runId:m.runId,msg}),300000,{shopId:m.shopId,orderIds:m.orderIds,code:m.code,period:m.period})
        .then(result=>send({type:'DETAILS_DONE',runId:m.runId,taskId:m.taskId,result}))
        .catch(e=>send({type:'DETAILS_FAILED',runId:m.runId,taskId:m.taskId,error:e.message}));
      return false;
    }
    if(m.type==='SOURCE_DIAGNOSTIC'){
      api('sourceDiagnostic',null,15000).then(result=>respond({result}),e=>respond({error:e.message}));return true;
    }
    if(m.type==='OPEN_ORDER_SAMPLE'){
      api('openOrderSample',null,15000,{shopId:m.shopId,orderIds:m.orderIds}).then(result=>respond({result}),e=>respond({error:e.message}));return true;
    }
    return false;
  });

  // Also works when Seller Center changes login without reloading the document.
  let checkingIdentity=false,lastIdentity='';
  async function announceIdentity(){
    if(checkingIdentity)return;
    if(loginPage()){lastIdentity='';return;}
    checkingIdentity=true;
    try{const r=await identity(0);if(r.shopId!==lastIdentity){lastIdentity=r.shopId;await send({type:'IDENTITY',identity:r});}}
    catch{lastIdentity='';}
    finally{checkingIdentity=false;}
  }
  setTimeout(announceIdentity,800);
  setInterval(announceIdentity,10000);
})();
