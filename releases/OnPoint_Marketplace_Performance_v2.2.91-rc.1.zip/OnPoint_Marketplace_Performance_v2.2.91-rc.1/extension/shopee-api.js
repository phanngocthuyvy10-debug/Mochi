/* Shopee Seller Center (banhang.shopee.vn) — direct read of the Account Health APIs the page itself uses,
   inside the logged-in session (page fetch + session cookies). Read-only GETs; no order actions, no buyer PII.
   Verified live 06/10/2026 on an Official/Mall shop:
     /api/selleraccount/shop_info/                                   shop identity
     /api/accounthealth/v1/sc/metric/configs                         every metric the shop has (id, unit, cmp_op, range)
     /api/accounthealth/v1/sc/shops/metric/available_time_range      first/last available data day per metric
     /api/accounthealth/v1/sc/shops/metric/overview?dt=              value, target, evaluation window (item_period)
     /api/accounthealth/v1/sc/shops/metric/trends                    history: 12 weekly or 30 daily windows
     /api/accounthealth/v1/sc/shops/metric/items?dt=&page_num=       impacted orders per window (page_size ≤ 100)
     /api/accounthealth/v1/sc/shops/penalty/point_overview|points    Sao Quả Tạ
     /api/accounthealth/v1/sc/shops/violations, shops/overview       violations, performance rating
     /api/sc/selleroperation/os/v1/metrics/list/                     Mall/Official seller metrics (net orders, FHR, chat…) */
(()=>{
 if(window.__opShopeeAPI)return;window.__opShopeeAPI=true;
 const origin=location.origin,nativeFetch=window.fetch.bind(window),pause=ms=>new Promise(r=>setTimeout(r,ms));
 const AH='/api/accounthealth/v1/sc/';
 // Account Health metric id → tool KPI code (other ids are kept as X_<NAME_KEY> extra metrics).
 const MAP={1:'LSR',3:'NFR',25:'FHR',4:'APT',11:'CRR',12:'PREORDER_RATE'};
 const NAMES={LSR:'Tỷ lệ giao hàng trễ',NFR:'Tỷ lệ đơn hàng không thành công',FHR:'Tỷ lệ giao hàng nhanh',APT:'Thời gian chuẩn bị hàng',CRR:'Tỷ lệ phản hồi chat',PREORDER_RATE:'Tỷ lệ hàng đặt trước',PP:'Điểm phạt Sao Quả Tạ',SPH:'Bàn giao bưu kiện thứ Bảy'};
 const ORDER_METRICS={1:'lsr',3:'nfr',25:'fhr'};
 const DEFAULT_OP={LSR:'<',NFR:'<',FHR:'>=',APT:'<',CRR:'>=',PREORDER_RATE:'<='};
 const OPS={lt:'<',lte:'<=',gt:'>',gte:'>=',eq:'='};
 const cookie=k=>decodeURIComponent((document.cookie.match(new RegExp('(?:^|; )'+k+'=([^;]*)'))||[])[1]||'');
 const iso=d=>/^\d{8}$/.test(String(d||''))?`${String(d).slice(0,4)}-${String(d).slice(4,6)}-${String(d).slice(6,8)}`:'';
 const ymd=s=>String(s).replace(/-/g,'');
 const addDays=(s,n)=>{const d=new Date(iso(s)+'T00:00:00Z');d.setUTCDate(d.getUTCDate()+n);return d.toISOString().slice(0,10).replace(/-/g,'');};
 const unitOf=u=>u==='percent'?'rate':u==='day'?'days':u==='num'?'count':u==='rating'?'rating':u||'';
 const conv=(v,u)=>{if(v==null||v==='')return null;const n=Number(String(v).replace(',','.'));if(!Number.isFinite(n))return null;return u==='rate'?Math.round(n*1e6)/1e8:n;};
 const safeId=x=>{const s=String(x??'').trim();return /^\d{6}[A-Z0-9]{5,20}$/.test(s)||/^\d{10,24}$/.test(s)?s:'';};
 const parse=t=>JSON.parse(t.replace(/(:\s*|[\[,]\s*)(-?\d{16,})(?=\s*[,}\]])/g,'$1"$2"'));

 async function get(path,params){
  const u=new URL(path,origin);const cds=cookie('SPC_CDS');if(cds){u.searchParams.set('SPC_CDS',cds);u.searchParams.set('SPC_CDS_VER','2');}
  for(const [k,v] of Object.entries(params||{}))u.searchParams.set(k,String(v));
  const r=await nativeFetch(u.href,{credentials:'include',signal:AbortSignal.timeout(30000)});
  const t=await r.text();let j;try{j=parse(t);}catch{throw Error(`${path}: Shopee không trả JSON (HTTP ${r.status}). Có thể phiên login đã hết.`);}
  if(r.status>=400||(j.code!=null&&j.code!==0)||(j.status!=null&&j.status!==200&&j.status!==0))throw Error(`${path}: ${j.message||j.msg||'HTTP '+r.status}`);
  return j.data!==undefined?(j.data||{}):j;
 }

 async function identity(){
  if(/login|passport|signup/.test(location.pathname))throw Error('Login Shopee trước.');
  const d=await get('/api/selleraccount/shop_info/');const sid=String(d.shop_id||'');
  if(!/^\d{5,24}$/.test(sid))throw Error('Shopee chưa trả Shop ID của phiên đang login.');
  return {shopId:sid,shopCode:sid,shopName:String(d.name||d.shop_name||''),platform:'SHOPEE',official:!!d.official_shop,region:String(d.shop_region||''),username:String(d.username||d.user_name||d.shop_username||'').slice(0,80)};
 }
 async function guard(shopId){const id=await identity();if(id.shopId!==shopId)throw Error('Store Shopee đã đổi trong lúc lấy. Dừng để tránh lẫn shop.');}

 function orderRow(code,key,it,window){
  const x=it[key]||{},sn=safeId(x.order_sn),oid=safeId(x.order_id);if(!sn&&!oid)return null;
  const reasons=[x.nfr_type,x.reason,x.fail_pick_up_reason,...(Array.isArray(x.diagnosis_scenario)?x.diagnosis_scenario:[])].filter(v=>v&&v!=='null');
  return {order_id:sn||oid,order_sn:sn,platform_order_id:oid,metric:code,
   created_at:x.order_create_time||'',rts_at:x.arrange_shipment_time||'',deadline:x.ship_by_date||x.fast_handover_due_date||'',
   pickup_at:x.arrange_pick_up_time||'',actual_handover_at:x.actual_pick_up_time||'',
   carrier:x.shipping_channel||'',pickup_type:x.fm_type||x.first_mile_type||'',tracking_id:x.fm_tracking_no||x.first_mile_tracking_no||'',
   sla_rule:x.fast_handover_due_date?'Fast handover due '+x.fast_handover_due_date:x.ship_by_date?'Ship by '+x.ship_by_date:'',
   reason:[NAMES[code],...reasons].join(' · ').slice(0,1500),period_start:window.start,period_end:window.end,evidence:'API_FAILURE_LIST'};
 }

 async function items(metricId,dt,progress,label){
  const key=ORDER_METRICS[metricId],code=MAP[metricId],rows=[];let total=null;
  for(let page=1;page<=200;page++){
   const d=await get(AH+'shops/metric/items',{metric_id:metricId,page_num:page,page_size:100,dt});
   total=Number(d.total)||0;const list=d.metric_item_list||[];
   for(const it of list)rows.push(it);
   progress?.(`Shopee ${label}: ${rows.length}/${total} đơn`);
   if(!list.length||rows.length>=total)break;await pause(150);
  }
  return {rows,total:total||0,key,code};
 }

 async function collect(opts,progress){
  const id=await identity(),notes=[],daily=[],metrics=new Map(),extras=[];
  progress(`Shopee: ${id.shopName} · ${id.shopId}`);
  const configs=((await get(AH+'metric/configs')).metric_config_list||[]);
  const ids=[...new Set([...configs.map(c=>c.metric_id),25])];
  const cfg=Object.fromEntries(configs.map(c=>[c.metric_id,c]));
  for(const mid of ids){
   try{
    const range=await get(AH+'shops/metric/available_time_range',{metric_id:mid});
    if(!range.available_end_time_dt){continue;}
    const c=cfg[mid]||{},unit=unitOf(c.metric_unit||(mid===25?'percent':'')),code=MAP[mid]||('X_'+String(c.name_key||('METRIC_'+mid)).replace(/[^A-Z0-9_]/gi,'_').toUpperCase());
    const ov=await get(AH+'shops/metric/overview',{metric_id:mid,dt:range.available_end_time_dt});
    const win={start:iso(ov.item_period?.start_dt),end:iso(ov.item_period?.end_dt)};
    const value=conv(ov.display_value,unit),target=conv(ov.target_value,unit),dir=OPS[c.cmp_op]||DEFAULT_OP[code]||'';
    const trend=((await get(AH+'shops/metric/trends',{metric_id:mid,is_numerator:'false'})).metric_trend_list||[]);
    for(const t of trend){const v=conv(t.value,unit);if(v==null)continue;daily.push({date:iso(t.dt),metric:code,value:v,window_start:iso(t.item_period?.start_dt),window_end:iso(t.item_period?.end_dt),source:'SHOPEE_API_TREND',unit,name:c.name_key||code});}
    // Shopee's own forecast "Dự đoán tuần sau" (overview.predicted_value) — stored as a value; the Dashboard compares it with the Mall target, not the Account Health target.
    const pred=conv(ov.predicted_value,unit);
    if(MAP[mid]&&pred!=null)daily.push({date:new Date().toLocaleDateString('sv-SE',{timeZone:'Asia/Ho_Chi_Minh'}),metric:'X_PRED_'+code,value:pred,window_start:win.start,window_end:win.end,source:'SHOPEE_API_FORECAST',unit,name:`Dự đoán tuần sau · ${NAMES[code]}`});
    if(MAP[mid]){
     metrics.set(code,{code,name:NAMES[code],unit,value,raw:String(ov.display_value??''),threshold:target!=null&&dir?{direction:dir,target,source:'SELLER_CENTER'}:null,
      period_start:win.start,period_end:win.end,source:'SHOPEE_API',expected:null,denominator:null,orders:[],linesFetched:0,lineTotal:null,scopeVerified:false,
      note:[ov.last_period_value!=null?`kỳ trước ${ov.last_period_value}${unit==='rate'?'%':''}`:'',ov.predicted_value!=null?`dự báo ${ov.predicted_value}${unit==='rate'?'%':''}`:''].filter(Boolean).join(' · ')});
    }else if(value!=null){extras.push({code,value,unit,target,dir,window:win});daily.push({date:win.end||iso(range.available_end_time_dt),metric:code,value,window_start:win.start,window_end:win.end,source:'SHOPEE_API_SNAPSHOT',unit,name:c.name_key||code});}
    // Impacted orders for every window Shopee keeps (weekly for LSR/NFR = up to 12 weeks; FHR rolling 30d → 3 windows cover ~90 days).
    const ok=value!=null&&target!=null&&dir&&(dir==='>='?value>=target:dir==='>'?value>target:dir==='<='?value<=target:dir==='<'?value<target:dir==='='?value===target:false);
    if(ORDER_METRICS[mid]&&(ok||value==null)){Object.assign(metrics.get(code),{orders:[],linesFetched:0,lineTotal:0,expected:0,scopeVerified:true,skipped:true,note:[metrics.get(code).note,value==null?'Sàn chưa có số liệu · không lấy danh sách đơn':'Đạt mục tiêu · bỏ qua danh sách đơn để lấy nhanh'].filter(Boolean).join(' · ')});progress(`Shopee ${code}: đạt mục tiêu, bỏ qua danh sách đơn`);}
    else if(ORDER_METRICS[mid]){
     const m=metrics.get(code),dts=mid===25?[range.available_end_time_dt,addDays(range.available_end_time_dt,-30),addDays(range.available_end_time_dt,-60)].filter(d=>d>=range.available_start_time_dt)
      :[...new Set(trend.map(t=>t.dt).concat(range.available_end_time_dt))].filter(d=>d>=range.available_start_time_dt&&d<=range.available_end_time_dt);
     const all=new Map();let total=0,fetched=0;
     for(const dt of dts.sort().reverse()){
      const tr=trend.find(t=>t.dt===dt),w={start:iso(tr?.item_period?.start_dt||(dt===range.available_end_time_dt?ov.item_period?.start_dt:'')||(mid===25?addDays(dt,-29):'')),end:iso(tr?.item_period?.end_dt||(dt===range.available_end_time_dt?ov.item_period?.end_dt:dt))};
      const r=await items(mid,dt,progress,`${code} kỳ ${w.start||'?'}→${w.end||iso(dt)}`);total+=r.total;fetched+=r.rows.length;
      const rows=r.rows.map(it=>orderRow(code,r.key,it,w)).filter(Boolean);
      for(const row of rows){const k=row.order_id;if(!all.has(k)||String(all.get(k).period_end)<String(row.period_end))all.set(k,row);}
      if(rows.length)progress(`Shopee ${code}: ${all.size} đơn lỗi`,{metric:code,rows,shopId:id.shopId});
      await pause(120);
     }
     Object.assign(m,{orders:[...all.values()],linesFetched:fetched,lineTotal:total,expected:total,scopeVerified:fetched===total,
      note:[m.note,`${all.size} đơn lỗi / ${dts.length} kỳ (${fetched}/${total} dòng)`].filter(Boolean).join(' · ')});
    }
    await pause(100);
   }catch(e){notes.push(/HTTP 200$/.test(e.message)?`metric ${cfg[mid]?.name_key||mid}: không áp dụng cho shop này`:`metric ${mid}: ${e.message}`);if(/đã đổi|login/i.test(e.message))throw e;}
  }
  // Sao Quả Tạ / violations / rating
  try{
   const po=await get(AH+'shops/penalty/point_overview'),ov=await get(AH+'shops/overview');
   const pts=Number(po.total_point);metrics.set('PP',{code:'PP',name:NAMES.PP,unit:'points',value:Number.isFinite(pts)?pts:null,raw:String(po.total_point??''),threshold:null,period_start:'',period_end:'',source:'SHOPEE_API',orders:[],linesFetched:0,lineTotal:null,
    note:[`xếp hạng ${ov.performance_rating||'?'}`,`${ov.failed_metric_count??'?'} chỉ số không đạt`,`${ov.appeal_count??0} khiếu nại`].join(' · ')});
   const today=new Date().toLocaleDateString('sv-SE',{timeZone:'Asia/Ho_Chi_Minh'});
   if(Number.isFinite(pts))daily.push({date:today,metric:'PP',value:pts,window_start:'',window_end:'',source:'SHOPEE_API_SNAPSHOT'});
   const q=new Date(),qs=new Date(Date.UTC(q.getUTCFullYear(),Math.floor(q.getUTCMonth()/3)*3,1)).toISOString().slice(0,10).replace(/-/g,''),qe=addDays(new Date(Date.UTC(q.getUTCFullYear(),Math.floor(q.getUTCMonth()/3)*3+3,1)).toISOString().slice(0,10).replace(/-/g,''),-1);
   const pl=await get(AH+'shops/penalty/points',{start_dt:qs,end_dt:qe,page_num:1,page_size:100}),vl=await get(AH+'shops/violations');
   const nP=(pl.shop_point_list||[]).length,nV=(vl.violation_list||[]).length;if(nP||nV)notes.push(`Sao Quả Tạ: ${nP} dòng điểm phạt, ${nV} vi phạm trong quý (xem Seller Center).`);
   for(const x of [['X_PERFORMANCE_FAILED_METRICS',ov.failed_metric_count],['X_PENALTY_APPEALS',ov.appeal_count]])if(Number.isFinite(Number(x[1])))daily.push({date:today,metric:x[0],value:Number(x[1]),window_start:'',window_end:'',source:'SHOPEE_API_SNAPSHOT',unit:'count'});
  }catch(e){notes.push('Sao Quả Tạ: '+e.message);}
  // Shop tier: Shopee Mall tag (shop_info.official_shop) + Shop Yêu Thích program (/portal/accounthealth/preferred-seller).
  try{
   const vnDay=new Date().toLocaleDateString('sv-SE',{timeZone:'Asia/Ho_Chi_Minh'});
   const PS={1:['Yêu Thích','Shopee đề xuất rời Shop Yêu Thích'],2:['Yêu Thích','Cảnh báo sắp rớt Shop Yêu Thích'],3:['Thường','Shop trong danh sách hạn chế'],4:['Thường',''],5:['Thường','Đủ điều kiện đề xuất Shop Yêu Thích'],6:['Yêu Thích',''],7:['Yêu Thích','Đề xuất lên Yêu Thích+'],8:['Yêu Thích','Đề xuất Yêu Thích+ · có cảnh báo'],9:['Yêu Thích+',''],10:['Yêu Thích+','Cảnh báo sắp rớt Yêu Thích+'],11:['Yêu Thích+','Đang rớt từ Yêu Thích+ về Yêu Thích'],12:['Yêu Thích+','Đang rớt từ Yêu Thích+ về shop thường']};
   const lp=await get('/api/sellergrowth/v2/ps/landing_page/');const st=Number(lp.ps_landing_page_status);const ps=PS[st]||['Không rõ',''];
   const tier=ps[0]==='Yêu Thích+'?2:ps[0]==='Yêu Thích'?1:0,warn=[1,2,8,10,11,12].includes(st)?1:0;
   daily.push({date:vnDay,metric:'X_SHOP_MALL',value:id.official?1:0,window_start:'',window_end:'',source:'SHOPEE_SHOP_INFO',unit:'count',name:'Shopee Mall (1 = đang có tag Mall)'});
   if(PS[st]){daily.push({date:vnDay,metric:'X_SHOP_PREFERRED',value:tier,window_start:'',window_end:'',source:'SHOPEE_PREFERRED_SELLER',unit:'count',name:'Shop Yêu Thích (0 thường · 1 Yêu Thích · 2 Yêu Thích+)'});
    daily.push({date:vnDay,metric:'X_PS_STATUS',value:st,window_start:'',window_end:'',source:'SHOPEE_PREFERRED_SELLER',unit:'count',name:('Trạng thái Shop Yêu Thích: '+ps[0]+(ps[1]?' · '+ps[1]:'')).slice(0,120)});
    daily.push({date:vnDay,metric:'X_PS_WARNING',value:warn,window_start:'',window_end:'',source:'SHOPEE_PREFERRED_SELLER',unit:'count',name:'Shop Yêu Thích · cảnh báo rớt hạng (1 = có)'});}
   if(Number.isFinite(Number(lp.not_meet_metric_count)))daily.push({date:vnDay,metric:'X_PS_NOT_MET',value:Number(lp.not_meet_metric_count),window_start:'',window_end:'',source:'SHOPEE_PREFERRED_SELLER',unit:'count',name:'Shop Yêu Thích · số tiêu chí tuần chưa đạt'});
   const failed=[];for(const m of lp.metrics||[]){const n=Number(m.metric_numerical_value),f=Number(m.metric_factor)||1;if(Number(m.status)===5)failed.push(m.metric_name||m.metric_key);if(!Number.isFinite(n)||n<0)continue;const v=Math.round(n/f*1e8)/1e8,key=String(m.metric_key||m.metric_id).toUpperCase().replace(/[^A-Z0-9]+/g,'_');
    daily.push({date:vnDay,metric:('X_PS_'+key).slice(0,62),value:v,window_start:'',window_end:'',source:'SHOPEE_PREFERRED_SELLER',unit:Number(m.metric_data_type)===3?'rate':'count',name:(`Shop Yêu Thích · ${m.metric_name||key} (mục tiêu ${m.target_value||'?'}) · ${Number(m.status)===5?'Không đạt':'Đạt'}`).slice(0,120)});}
   notes.push(`Phân hạng: ${id.official?'Shopee Mall':'không có tag Mall'} · ${ps[0]}${ps[1]?' ('+ps[1]+')':''}${failed.length?' · tiêu chí Yêu Thích chưa đạt: '+failed.join(', '):''}`);
   progress(`Shopee phân hạng: ${id.official?'Mall':'không Mall'} · ${ps[0]}`);
  }catch(e){notes.push('Shop Yêu Thích: '+e.message);}
  // Shopee-Certified Enabler Program — engagement metrics, weekly (Mon–Sun, giờ VN). Endpoints verified live 09/10/2026 (banhang.shopee.vn, shop đang login):
  //   shop flash sale  GET  /api/marketing/v4/shop_flash_sale/get_shop_flash_sale_list/?type=0 (start_time desc; item_count)
  //   shop voucher     GET  /api/marketing/v3/voucher/list/?promotion_type=0 (start_time/end_time)
  //   discount         POST /api/marketing/v3/public/discount/list/ {discount_type:1} → discounts[].seller_discount{start_time,end_time}
  //   ads (Dịch vụ Hiển thị) POST /api/pas/v1/report/get_time_graph/ → report_by_time[].metrics.cost (÷100000 = VND)
  //   decoration       GET  /api/n/decoration/homepage/draft_list/ + draft_get/?draft_id= → decoration_data[] (số component trang shop đang publish)
  //   video            GET  https://creator.shopee.vn/publish/pc/api/video/list?order=ptime (ptime ms)
  // Each metric is written for last full week (dated Sunday) and the current week-to-date (dated today) as X_ENB_* rows; failures are notes, never block KPI collection.
  try{
   const H=3600,D=86400,nowS=Math.floor(Date.now()/1000),vn=new Date((nowS+7*H)*1000),dow=(vn.getUTCDay()+6)%7;
   const curStart=Date.UTC(vn.getUTCFullYear(),vn.getUTCMonth(),vn.getUTCDate())/1000-dow*D-7*H,prevStart=curStart-7*D;
   const dayOf=ts=>new Date((ts+7*H)*1000).toISOString().slice(0,10);
   const weeks=[{start:prevStart,end:curStart,date:dayOf(curStart-D)},{start:curStart,end:Math.min(curStart+7*D,nowS),date:dayOf(nowS)}];
   const days=(ivs,w)=>{let n=0;for(let d=w.start;d<w.end;d+=D){const e=d+D;if(ivs.some(([s,t])=>s<e&&t>d))n++;}return n;};
   const put=(metric,w,value,unit,name)=>{if(value==null||!Number.isFinite(value))return;daily.push({date:w.date,metric,value,window_start:dayOf(w.start),window_end:dayOf(Math.max(w.start,w.end-1)),source:'SHOPEE_ENABLER_API',unit,name});};
   const post=async(path,body)=>{const u=new URL(path,origin);const cds=cookie('SPC_CDS');if(cds){u.searchParams.set('SPC_CDS',cds);u.searchParams.set('SPC_CDS_VER','2');}
    const r=await nativeFetch(u.href,{method:'POST',credentials:'include',headers:{'content-type':'application/json'},body:JSON.stringify(body),signal:AbortSignal.timeout(30000)});const j=parse(await r.text());
    if(r.status>=400||(j.code!=null&&j.code!==0))throw Error(`${path}: ${j.message||j.msg||'HTTP '+r.status}`);return j.data!==undefined?(j.data||{}):j;};
   const got=[],miss=[];const step=async(label,f)=>{try{await f();got.push(label);}catch(e){miss.push(label+' ('+String(e.message||e).slice(0,80)+')');}};
   await step('Flash Sale',async()=>{const slots=[];for(let off=0;off<1000;off+=50){const d=await get('/api/marketing/v4/shop_flash_sale/get_shop_flash_sale_list/',{offset:off,limit:50,type:0});const l=d.flash_sale_list||[];slots.push(...l);if(l.length<50||l.some(x=>Number(x.start_time)<prevStart))break;await pause(120);}
    for(const w of weeks)put('X_ENB_FLASH',w,slots.filter(x=>Number(x.item_count)>0&&Number(x.start_time)>=w.start&&Number(x.start_time)<w.end).length,'count','Enabler · Shopee Flash Sale (số khung giờ trong tuần, mục tiêu ≥ 3)');});
   await step('Voucher',async()=>{const ivs=[];for(let off=0;off<600;off+=50){const d=await get('/api/marketing/v3/voucher/list/',{offset:off,limit:50,promotion_type:0});const l=d.voucher_list||[];for(const v of l)ivs.push([Number(v.start_time),Number(v.end_time)]);if(l.length<50||off+50>=Number(d.total_count||0))break;await pause(120);}
    for(const w of weeks)put('X_ENB_VOUCHER_DAYS',w,days(ivs,w),'days','Enabler · Mã giảm giá của Shop (số ngày có voucher, mục tiêu ≥ 3)');});
   await step('Khuyến mãi',async()=>{const ivs=[];for(let off=0;off<600;off+=50){const d=await post('/api/marketing/v3/public/discount/list/',{discount_type:1,time_status:0,offset:off,limit:50});const l=d.discounts||[];for(const x of l){const s=x.seller_discount||x;ivs.push([Number(s.start_time),Number(s.end_time)]);}if(l.length<50)break;await pause(120);}
    for(const w of weeks)put('X_ENB_PROMO_DAYS',w,days(ivs,w),'days','Enabler · Chương trình khuyến mãi của Shop (số ngày, mục tiêu ≥ 3)');});
   await step('Quảng cáo',async()=>{const d=await post('/api/pas/v1/report/get_time_graph/',{agg_interval:96,campaign_type:'product_homepage_v2',start_time:prevStart,end_time:nowS,need_roi_target_setting:false,filter_params:{campaign_type:'new_cpc_homepage'}});const rows=d.report_by_time||[];
    for(const w of weeks)put('X_ENB_ADS_VND',w,Math.round(rows.filter(x=>Number(x.key)>=w.start&&Number(x.key)<w.end).reduce((a,x)=>a+(Number(x.metrics?.cost)||0),0)/1e5),'vnd','Enabler · Chi phí Quảng cáo Shopee (Dịch vụ Hiển thị, VND; mục tiêu ≥ 75 USD)');});
   await step('Trang trí shop',async()=>{const l=(await get('/api/n/decoration/homepage/draft_list/')).homepage_list||[];const pub=l.filter(x=>x.draft_type==='publish').sort((a,b)=>Number(b.last_publish_time)-Number(a.last_publish_time))[0];
    const n=pub?((await get('/api/n/decoration/homepage/draft_get/',{draft_id:pub.draft_id})).decoration_data||[]).length:0;put('X_ENB_DECO',weeks[1],n,'count','Enabler · Trang trí Shop (số component trang đang publish, mục tiêu ≥ 3)');});
   await step('Video',async()=>{const ts=[];for(let page=1;page<=10;page++){const r=await nativeFetch(`https://creator.shopee.vn/publish/pc/api/video/list?page=${page}&pageSize=50&order=ptime&orderBy=desc`,{credentials:'include',signal:AbortSignal.timeout(30000)});const j=parse(await r.text());if(j.code!==0)throw Error(j.msg||('HTTP '+r.status));const l=j.data?.list||[];ts.push(...l.map(x=>Math.floor(Number(x.ptime)/1000)));if(l.length<50||ts.some(t=>t<prevStart))break;await pause(120);}
    for(const w of weeks)put('X_ENB_VIDEO',w,ts.filter(t=>t>=w.start&&t<w.end).length,'count','Enabler · Shopee Video (số video đăng trong tuần, mục tiêu ≥ 1)');});
   notes.push(`Enabler: lấy được ${got.join(', ')||'không chỉ số nào'}${miss.length?' · chưa lấy được '+miss.join('; '):''}`);progress(`Shopee Enabler: ${got.length}/6 chỉ số tương tác`);
  }catch(e){notes.push('Enabler: '+e.message);}
  // Mall/Official seller dashboard
  try{
   const os=await get('/api/sc/selleroperation/os/v1/metrics/list/',{region:'vn',shop_id:id.shopId});const day=os.refresh_time?new Date(os.refresh_time).toLocaleDateString('sv-SE',{timeZone:'Asia/Ho_Chi_Minh'}):new Date().toLocaleDateString('sv-SE',{timeZone:'Asia/Ho_Chi_Minh'});
   // Mall criteria table (/portal/accounthealth/official-seller): item.status 1 = Đạt (PASS), 2 = Không đạt (NOTPASS) — enum from Seller Center's own bundle, verified live 07/10/2026.
   // data_operator 2 = ≥, 4 = ≤ (verified); target_value is display text ("80.00%", "2").
   const OP={1:'>',2:'>=',3:'<',4:'<=',5:'='},osFailed=[];let osJudged=0;
   for(const it of os.items||[]){const unit=it.data_type===3?'rate':'count',factor=Number(it.factor)||1,v=Math.round(Number(it.numerical_value)/(unit==='rate'?factor:1)*1e8)/1e8;
    const k=String(it.key||'').toUpperCase().replace(/[^A-Z0-9_]/g,'_'),st=Number(it.status),verdict=st===1?true:st===2?false:null,dir=OP[Number(it.data_operator)]||'';
    const tn=it.target_value==null?null:Number(String(it.target_value).replace('%','').replace(',','.')),tv=tn==null||!Number.isFinite(tn)?null:/%/.test(String(it.target_value))||unit==='rate'?Math.round(tn*1e6)/1e8:tn;
    if(verdict!=null){osJudged++;if(!verdict)osFailed.push(it.key);}
    if(Number.isFinite(v))daily.push({date:day,metric:'X_OS_'+k,value:v,window_start:'',window_end:day,source:'SHOPEE_OFFICIAL_SELLER',unit,name:String(`${it.name||it.key}${dir&&it.target_value!=null?` (mục tiêu ${dir} ${it.target_value})`:''}${verdict==null?'':verdict?' · Đạt':' · Không đạt'}`).slice(0,120)});
    if(tv!=null&&dir)daily.push({date:day,metric:'X_OST_'+k,value:tv,window_start:'',window_end:day,source:'SHOPEE_OFFICIAL_SELLER',unit,name:`${dir} ${it.name||it.key}`.slice(0,120)});
    if(verdict!=null)daily.push({date:day,metric:'X_OSF_'+k,value:verdict?0:1,window_start:'',window_end:day,source:'SHOPEE_OFFICIAL_SELLER',unit:'count',name:`${it.name||it.key} · ${verdict?'Đạt':'Không đạt'} tiêu chí Mall`.slice(0,120)});}
   if(osJudged)daily.push({date:day,metric:'X_OS_NOT_MET',value:osFailed.length,window_start:'',window_end:day,source:'SHOPEE_OFFICIAL_SELLER',unit:'count',name:('Tiêu chí Mall không đạt: '+(osFailed.join(', ')||'không')).slice(0,120)});
  }catch(e){if(!/404|403/.test(e.message))notes.push('Official seller: '+e.message);}
  // Mall label status (/api/sc/selleroperation/os/v1/shop/status/): 1 ONBOARD · 2 WARNING (cảnh báo gỡ nhãn) · 3 DEACTIVE · 4 OFFBOARD — Seller Center enum, verified live 07/10/2026.
  let mallStatus=null;
  if(id.official){try{const ms=Number((await get('/api/sc/selleroperation/os/v1/shop/status/')).status);if([1,2,3,4].includes(ms)){mallStatus=ms;
   daily.push({date:new Date().toLocaleDateString('sv-SE',{timeZone:'Asia/Ho_Chi_Minh'}),metric:'X_MALL_STATUS',value:ms,window_start:'',window_end:'',source:'SHOPEE_OFFICIAL_SELLER',unit:'count',name:'Trạng thái nhãn Mall: '+{1:'Đang hoạt động',2:'Cảnh báo gỡ nhãn',3:'Bị tạm ngưng (DEACTIVE)',4:'Đã gỡ (OFFBOARD)'}[ms]});}}
   catch(e){notes.push('Trạng thái nhãn Mall: '+e.message);}}
  // Panel summary (Dashboard applies the same rule): Shopee's label status first, then failed Mall criteria; FHR-only failure is the documented exception.
  if(id.official){const f=daily.filter(d=>/^X_OSF_/.test(d.metric)&&d.value===1).map(d=>d.metric.slice(6)),fhr=metrics.get('FHR')?.value;
   notes.push(mallStatus===2?'Mall: Shopee đang CẢNH BÁO GỠ NHÃN':mallStatus>2?'Mall: nhãn đã bị tạm ngưng/gỡ':
    !f.length?'Mall: đạt mọi tiêu chí Mall':f.length===1&&f[0]==='SD'?`Mall: chỉ không đạt Giao hàng nhanh · FHR mới nhất ${fhr==null?'?':(fhr*100).toFixed(2)+'%'} (ngoại lệ: chưa gỡ nếu FHR tính lại ≥ 80%)`:`Mall: không đạt ${f.join(', ')} · nguy cơ bị cảnh báo gỡ nhãn`);}
  if(!metrics.has('SPH'))metrics.set('SPH',{code:'SPH',name:NAMES.SPH,unit:'count',value:null,raw:'',threshold:null,period_start:'',period_end:'',source:'',orders:[],linesFetched:0,lineTotal:null,note:'Shopee không trả chỉ số này cho shop.'});
  await guard(id.shopId);
  progress('Đã nhận snapshot KPI Shopee.',{snapshotMetrics:[...metrics.values()].map(m=>({...m,orders:[]})),shopId:id.shopId});
  const orderCount=new Set([...metrics.values()].flatMap(m=>(m.orders||[]).map(o=>o.metric+'|'+o.order_id))).size;
  progress(`Shopee xong: ${metrics.size} KPI · ${orderCount} đơn lỗi · ${daily.length} dòng lịch sử · ${extras.length} chỉ số phụ`);
  return {identity:id,metrics:[...metrics.values()],daily,notes,historyDays:90,at:new Date().toISOString(),platform:'SHOPEE',apiComplete:true};
 }
 function diagnostic(){return {version:2,platform:'SHOPEE',mode:'direct-api',pagePath:location.pathname,endpoints:['selleraccount/shop_info','accounthealth metric configs/overview/trends/items','penalty point_overview/points','violations','selleroperation metrics/list']};}
 window.OPShopeeAPI={identity,collect,diagnostic};
 window.addEventListener('message',async e=>{if(e.source!==window||e.origin!==origin||e.data?.type!=='OP_TTS_REQ')return;const {id,action,opts}=e.data,post=(kind,data)=>window.postMessage({type:'OP_TTS_RES',id,kind,...data},origin);
  try{if(action==='identity')post('DONE',{result:await identity()});else if(action==='collect')post('DONE',{result:await collect(opts,(msg,data)=>post('PROGRESS',{msg,...data}))});else if(action==='sourceDiagnostic')post('DONE',{result:diagnostic()});else if(action==='enrich'||action==='performance')post('DONE',{result:{rows:[],note:'Shopee: mốc xử lý đã lấy trực tiếp từ API sức khỏe tài khoản.'}});else post('ERROR',{error:'Shopee dùng luồng Lấy toàn bộ & tự lưu.'});}
  catch(err){post('ERROR',{error:String(err.message||err).slice(0,600)});}});
})();
