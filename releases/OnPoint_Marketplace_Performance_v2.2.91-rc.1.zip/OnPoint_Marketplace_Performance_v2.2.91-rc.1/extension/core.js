(function(root) {
  'use strict';
  const defs = [
    {code:'NDDR',name:'Tỷ lệ giao nhanh 24h',aliases:['ty le giao nhanh 24h','next day delivery rate','nddr','next_day_delivery_rate','next_day_delivery'],direction:'>=',target:.9},
    {code:'FDR',name:'Tỷ lệ gửi hàng nhanh',aliases:['ty le gui hang nhanh','fast dispatch rate','fast handover rate','fdr','fast_dispatch_rate','fast_handover_rate'],direction:'>=',target:.9},
    {code:'LDR',name:'Tỷ lệ gửi hàng muộn',aliases:['ty le gui hang muon','late dispatch rate','late shipment rate','ldr','late_dispatch_rate','late_shipment_rate'],direction:'<=',target:.04},
    {code:'SFCR',name:'Tỷ lệ hủy do lỗi của người bán',aliases:['ty le huy do loi cua nguoi ban','seller fault cancellation rate','sfcr','seller_fault_cancellation_rate'],direction:'<=',target:.025},
    {code:'INSTANT_LDR',name:'Tỷ lệ gửi hàng muộn đơn Hỏa tốc',aliases:['ty le gui hang muon don hoa toc','instant late dispatch rate','instant_ldr','instant_late_dispatch_rate'],direction:'<=',target:.05},
    {code:'SAME_DAY_LDR',name:'Tỷ lệ gửi hàng muộn đơn Trong ngày',aliases:['ty le gui hang muon don trong ngay','same day late dispatch rate','same_day_ldr','same_day_late_dispatch_rate'],direction:'<=',target:.05}
  ];
  function norm(v){return String(v??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/g,'d').replace(/Đ/g,'D').toLowerCase().replace(/[_\-]+/g,' ').replace(/\s+/g,' ').trim();}
  function metric(v){const n=norm(v);return [...defs].sort((a,b)=>b.name.length-a.name.length).find(d=>d.aliases.some(a=>n===norm(a)))||null;}
  function labelMetric(v){const n=norm(v);return [...defs].sort((a,b)=>b.name.length-a.name.length).find(d=>d.aliases.some(a=>n.includes(norm(a))))||null;}
  function rate(v,unit){if(v==null||v===''||/^(--|—|-|n\/a)$/i.test(String(v).trim()))return null;const s=String(v).trim().replace(/\s/g,'').replace(',','.');const n=Number(s.replace('%',''));if(!Number.isFinite(n)||n<0)return null;const x=s.includes('%')||unit==='percent'?n/100:n;return x<=1?x:null;}
  // Quote long JSON integers before parsing; TikTok IDs exceed Number.MAX_SAFE_INTEGER.
  function safeJSON(s){
    // Match complete JSON strings first so numeric-looking text inside them stays untouched.
    const text=String(s).replace(/"(?:[^"\\]|\\[\s\S])*"|-?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?/g, token=>{
      if(token[0]==='"'||! /^-?(?:0|[1-9]\d*)$/.test(token))return token;
      return Number.isSafeInteger(Number(token))?token:JSON.stringify(token);
    });
    return JSON.parse(text);
  }
  function scalar(v){return typeof v==='string'||typeof v==='boolean'||(typeof v==='number'&&Number.isFinite(v));}
  function first(o,keys){for(const k of keys){if(o[k]!==undefined&&o[k]!==null&&scalar(o[k]))return o[k];}return null;}
  const orderKeys=['order_id','orderId','order_no','order_number','order_sn','Order ID','Mã đơn hàng','ID đơn hàng'];
  function order(o){const id=first(o,orderKeys),idText=String(id??'').trim().replace(/^'/,'');if(id==null||!/^\d{10,24}$/.test(idText)||typeof id==='number'&&!Number.isSafeInteger(id))return null;
    const val=(ks)=>String(first(o,ks)??'').slice(0,800);
    return {order_id:idText,tracking_id:val(['tracking_number','tracking_no','tracking_id','waybill_no','Tracking No','Mã vận đơn']),status:val(['order_status','status','shipment_status','Trạng thái đơn hàng']),reason:val(['violation_reason','fail_reason','failure_reason','cancel_reason','reason','Lý do','Lý do vi phạm']),created_at:val(['create_time','created_at','order_create_time','order_date','Thời gian tạo đơn hàng']),paid_at:val(['paid_time','payment_time']),rts_at:val(['rts_time','ready_to_ship_time']),pickup_at:val(['pickup_time','collection_time','shipped_time','dispatch_time']),delivered_at:val(['delivery_time','delivered_time']),deadline:val(['fulfillment_deadline','dispatch_deadline','sla_deadline']),shipping_type:val(['shipping_type','delivery_type']),carrier:val(['logistics_provider','shipping_provider','carrier_name']),warehouse:val(['warehouse_name']),violation_id:val(['violation_id']),appeal_status:val(['appeal_status'])};}
  function failing(o,code){const yes=v=>v===true||v===1||v==='1'||v==='true';
    if(['is_violation','is_failed','failed'].some(k=>yes(o[k])))return true;
    if(['LDR','INSTANT_LDR','SAME_DAY_LDR'].includes(code)&&['is_late','late_dispatch','is_late_dispatch'].some(k=>yes(o[k])))return true;
    if(code==='FDR'&&['is_fast_dispatch','fast_dispatch_success'].some(k=>o[k]===false||o[k]===0))return true;
    if(code==='NDDR'&&['is_next_day_delivery','next_day_delivery_success'].some(k=>o[k]===false||o[k]===0))return true;
    if(code==='SFCR'&&['seller_fault','is_seller_fault'].some(k=>yes(o[k])))return true;
    return !!first(o,['violation_reason','fail_reason','failure_reason']);
  }
  function extract(payload,url,context) {
    const result={identity:null,metrics:[],orders:[],expected:null,schemas:[],periods:[]};
    let visited=0;const seen=new Set(),identities=new Map();
    function walk(o,path,depth,scope,branchCode){if(!o||typeof o!=='object'||depth>12||++visited>30000||seen.has(o))return;seen.add(o);
      if(Array.isArray(o)){for(const x of o)walk(x,path+'[]',depth+1,scope,branchCode);return;}
      const sid=first(o,['shop_id','shopId']);const sname=first(o,['shop_name','shopName']);
      if(sid!=null&&sname!=null&&!(typeof sid==='number'&&!Number.isSafeInteger(sid)))identities.set(String(sid),{shopId:String(sid),shopName:String(sname).slice(0,250)});
      const named=metric(first(o,['metric_name','indicator_name','metric_code','metric','name','code'])??'')||metric(path.split('.').pop().replace(/\[\]/g,''));
      const namedRate=first(o,['rate','value','actual_value','metric_value','percentage','rate_value']);
      if(named&&namedRate!=null){const rv=rate(namedRate,first(o,['unit','value_unit']));if(rv!=null)result.metrics.push({code:named.code,value:rv,raw:String(namedRate),source:'API',period_start:String(first(o,['start_date','period_start','start_time'])??''),period_end:String(first(o,['end_date','period_end','end_time'])??''),expected:count(first(o,['failed_order_count','violation_order_count','late_order_count'])),denominator:count(first(o,['total_order_count','eligible_order_count']))});}
      for(const [k,v] of Object.entries(o)){
        const d=metric(k);if(d){const rv=scalar(v)?rate(v):null;if(rv!=null)result.metrics.push({code:d.code,value:rv,raw:String(v),source:'API',period_start:'',period_end:''});}
      }
      const activeCode=named?.code||branchCode;const codeMatches=!activeCode||activeCode===context?.code;
      const failScope=scope||/(failed|failure|violation_orders|breached|non_compliant|defect|impacted)_?(order|orders|list)?/.test(path)||(['LDR','INSTANT_LDR','SAME_DAY_LDR'].includes(context?.code)&&/late_orders/.test(path));
      const row=order(o);if(row&&context&&context.code&&codeMatches&&(failScope||failing(o,context.code))){row.evidence=failScope?'API_FAILURE_LIST':'API_FAILURE_FLAG';result.orders.push(row);}
      if(context&&context.code&&codeMatches){const keys=['failed_order_count','failure_order_count','violation_order_count','breached_order_count'];if(['LDR','INSTANT_LDR','SAME_DAY_LDR'].includes(context.code))keys.push('late_order_count');const c=first(o,keys);if(c!=null)result.expected=count(c);
        if(failScope){const t=first(o,['total_count','total','total_num','total_records']);if(t!=null)result.expected=count(t);}}
      if(depth<4&&result.schemas.length<25)result.schemas.push({path,keys:Object.keys(o).slice(0,60)});
      for(const [k,v] of Object.entries(o)){if(v&&typeof v==='object')walk(v,path+'.'+k,depth+1,failScope,activeCode);}
    }
    walk(payload,'$',0,false);result.identity=identities.size===1?[...identities.values()][0]:null;result.orders=[...new Map(result.orders.map(o=>[o.order_id,o])).values()];return result;
  }
  function count(v){if(typeof v!=='number'&&typeof v!=='string')return null;const n=Number(v);return v!==''&&Number.isSafeInteger(n)&&n>=0?n:null;}
  function threshold(text){const m=String(text).match(/(>=|<=|≥|≤|>|<)\s*(\d+(?:[.,]\d+)?)\s*%/);return m?{direction:m[1].replace('≥','>=').replace('≤','<='),target:Number(m[2].replace(',','.'))/100,source:'SELLER_CENTER'}:null;}
  function status(m){if(m.value==null)return m.raw==='--'?'N/A':'CHƯA LẤY';if(!m.threshold||m.threshold.source!=='SELLER_CENTER')return 'CHƯA CÓ MỤC TIÊU';const t=m.threshold;const ok=t.direction==='>='?m.value>=t.target:t.direction==='>'?m.value>t.target:t.direction==='<='?m.value<=t.target:m.value<t.target;return ok?'PASS':'FAIL';}
  function completeness(m,n){if(m.value==null)return m.raw==='--'?'N/A':'CHƯA LẤY';if(m.expected===null||m.expected===undefined)return 'CHƯA ĐỐI CHIẾU';if(n!==m.expected)return n<m.expected?'THIẾU ĐƠN':'LỆCH SỐ ĐƠN';return m.scopeVerified?'ĐỦ ĐƠN':'CẦN KIỂM TRA FILTER';}
  function csv(rows){return '\ufeff'+rows.map(r=>r.map(x=>{let s=String(x??'');if(/^[\s\u0000-\u001f]*[=+\-@]/.test(s)||/^[\t\r\n]/.test(s))s="'"+s;return '"'+s.replace(/"/g,'""')+'"';}).join(',')).join('\r\n');}
  function mergeOrder(old,row){return {...(old||{}),...Object.fromEntries(Object.entries(row).filter(([k,v])=>v!==''&&v!==null&&v!==undefined))};}
  function orderChanged(old,row){return !old||Object.entries(mergeOrder(old,row)).some(([k,v])=>old[k]!==v);}
  root.OPCore={defs,norm,metric,labelMetric,rate,safeJSON,extract,order,threshold,status,completeness,csv,count,mergeOrder,orderChanged};
  if(typeof module!=='undefined'&&module.exports)module.exports=root.OPCore;
})(typeof globalThis==='undefined'?this:globalThis);
