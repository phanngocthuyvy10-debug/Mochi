/* MAIN world. Observe one native submit; only read its resulting case ID. */
(() => {
  if (window.__OP_SHOPEE_PROBE__) return;
  window.__OP_SHOPEE_PROBE__ = true;
  let armed = null;
  const records = [], lookups = new Set();
  const originalFetch = window.fetch;
  function emit() { window.postMessage({ source: 'op-shopee-probe', json: JSON.stringify({ records }) }, location.origin); }
  async function lookup(record) {
    const token = record.submissionId;
    if (!token || !record.csUserId || lookups.has(token) || !originalFetch) return;
    let url;
    try {
      url = new URL(record.submitUrl, location.origin);
      if (url.origin !== location.origin || !/\/form\/v1\/forms\/submit$/.test(url.pathname)) return;
      url.pathname = url.pathname.replace(/submit$/, 'get_case_id');
      url.search = new URLSearchParams({ submissionId: token, csUserId: record.csUserId }).toString();
    } catch (_) { return; }
    lookups.add(token);
    try {
      for (let attempt = 0; attempt < 20 && !record.ticketId; attempt++) {
        try {
          const response = await originalFetch.call(window, url.href, { credentials: 'include', headers: { region: 'VN' } });
          const found = OPShopeeCapture.response({ method: 'GET', url: url.href, httpStatus: response.status, response: await response.text() });
          if (found?.ticketId) { record.ticketId = found.ticketId; emit(); return; }
        } catch (_) {}
        await new Promise(resolve => setTimeout(resolve, Math.min(10000, 1500 + attempt * 500)));
      }
    } finally { lookups.delete(token); }
  }
  window.addEventListener('message', event => {
    if (event.source !== window || event.origin !== location.origin) return;
    if (event.data?.source === 'op-shopee-probe-arm') {
      try {
        armed = JSON.parse(event.data.json);
        if (armed?.lookup?.submissionId && armed.startedAt && armed.orderId) {
          let record = records.find(item => item.submissionId === armed.lookup.submissionId);
          if (!record) { record = { ...armed.lookup, orderId: armed.orderId, startedAt: armed.startedAt, confirmed: true }; records.push(record); }
          lookup(record);
        }
      } catch (_) { armed = null; }
    } else if (event.data?.source === 'op-shopee-probe-ask') emit();
  });
  function finish(meta, response, httpStatus) {
    if (!armed?.startedAt || meta.startedAt < armed.startedAt) return;
    const found = OPShopeeCapture.response({ ...meta, response, httpStatus });
    if (!found?.confirmed) return;
    const record = { ...found, orderId: armed.orderId, startedAt: meta.startedAt };
    if (records.some(item => item.submissionId === record.submissionId)) return;
    records.push(record); if (records.length > 20) records.shift();
    emit(); if (!record.ticketId) lookup(record);
  }
  const open = XMLHttpRequest.prototype.open, send = XMLHttpRequest.prototype.send, metadata = new WeakMap();
  XMLHttpRequest.prototype.open = function(method, url) { metadata.set(this, { method: String(method).toUpperCase(), url: String(url) }); return open.apply(this, arguments); };
  XMLHttpRequest.prototype.send = function() {
    const meta = { ...metadata.get(this), startedAt: Date.now() };
    if (armed?.startedAt && /\/form\/v1\/forms\/submit(?:\?|$)/.test(meta.url || '')) this.addEventListener('load', () => {
      try { finish(meta, this.responseType === 'json' ? this.response : this.responseText, this.status); } catch (_) {}
    }, { once: true });
    return send.apply(this, arguments);
  };
  if (originalFetch) window.fetch = function(input, init) {
    const meta = { method: String(init?.method || input?.method || 'GET').toUpperCase(), url: typeof input === 'string' ? input : input?.url || String(input), startedAt: Date.now() };
    const promise = originalFetch.apply(this, arguments);
    if (armed?.startedAt && /\/form\/v1\/forms\/submit(?:\?|$)/.test(meta.url)) promise.then(async response => {
      try { finish(meta, await response.clone().text(), response.status); } catch (_) {}
    }, () => {});
    return promise;
  };
})();
