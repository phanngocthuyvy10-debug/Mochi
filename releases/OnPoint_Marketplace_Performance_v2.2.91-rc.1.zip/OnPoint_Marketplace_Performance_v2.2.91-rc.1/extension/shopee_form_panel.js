/* v2.2.4 — Ticket Assistant · Shopee · Loại ticket riêng cho 2 webform Người bán (lib/op-shopee-pickup.js):
   - "Khiếu nại cập nhật sai trạng thái lấy hàng" (shopee_status)
   - "Yêu cầu hối lấy hàng" (shopee_urge)
   1 ticket = 1 mã đơn đại diện + file Excel "Danh sách đơn hàng" (tất cả đơn). Không biên bản, không STT, không email.
   Tool tự nhận shop, mở form, chọn vấn đề, điền, tải file, tự Gửi 1 lần, lưu mã phiếu vào Ticket Master + danh sách theo dõi. */
(() => {
  const $f = id => document.getElementById(id);
  const esc = value => escapeHtml(value);
  const KEY = 'shopeeFormDrafts';
  let kind = 'status', drafts = {}, shop = '', reading = null, lastFollow = '';
  const draft = () => (drafts[kind] ||= { option: 0, carrier: '', orders: [] });
  const form = () => OPShopeePickup.FORMS[kind];
  const valid = id => /^\d{6}[A-Z0-9]{6,14}$/.test(String(id || '').trim().toUpperCase());
  const plain = s => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/đ/g, 'd').replace(/Đ/g, 'D').toLowerCase();
  const save = () => chrome.storage.local.set({ [KEY]: drafts }).catch(() => {});
  function status(text, kindClass = '') { $f('sfStatus').textContent = text; $f('sfStatus').className = `status-box ${kindClass}`; }

  function addOrders(list) {
    const d = draft(), seen = new Set(d.orders.map(o => o.orderId)); let added = 0;
    for (const o of list) { const id = String(o.orderId || '').trim().toUpperCase(); if (!valid(id) || seen.has(id)) continue; seen.add(id); d.orders.push({ orderId: id, trackingId: String(o.trackingId || '').trim(), carrier: String(o.carrier || '').trim(), status: o.status === 'cancelled' ? 'cancelled' : 'pending', note: String(o.note || '').slice(0, 200) }); added++; }
    return added;
  }
  function parsePaste(text) {
    const out = [];
    for (const line of String(text || '').split(/\r?\n/)) {
      const parts = (line.includes('\t') ? line.split('\t') : line.split(/[|;,]/)).map(x => x.trim()).filter(Boolean);
      const id = parts.map(x => x.toUpperCase()).find(valid); if (!id) continue;
      const rest = parts.filter(x => x.toUpperCase() !== id);
      out.push({ orderId: id, trackingId: rest.find(x => /\d/.test(x) && /^[A-Z0-9]{8,30}$/i.test(x)) || '', status: rest.some(x => /^(huy|da huy|cancel|cancelled|canceled)$/.test(plain(x))) ? 'cancelled' : 'pending' });
    }
    return out;
  }
  function render() {
    if (!globalThis.OPShopeePickup) return;
    const d = draft(), f = form();
    $f('sfTitle').textContent = f.title;
    $f('sfOption').innerHTML = f.options.map((text, index) => `<option value="${index}" ${index === Number(d.option || 0) ? 'selected' : ''}>${esc(text)}</option>`).join('');
    $f('sfCarrier').value = d.carrier || '';
    document.querySelectorAll('#shopeeFormPanel [data-sf-only]').forEach(el => { el.hidden = el.dataset.sfOnly !== kind; });
    const rows = d.orders, cancelled = rows.filter(o => o.status === 'cancelled').length;
    $f('sfOrders').innerHTML = rows.length
      ? `<table><tr><th>#</th><th>Mã đơn</th><th>Mã vận đơn</th><th>Tình trạng</th><th></th></tr>${rows.slice(0, 300).map((o, i) => `<tr><td>${i + 1}${i === 0 ? ' ★' : ''}</td><td>${esc(o.orderId)}</td><td>${esc(o.trackingId || '')}</td><td>${kind === 'status' ? `<select data-sf-status="${i}"><option value="pending" ${o.status !== 'cancelled' ? 'selected' : ''}>Chưa hủy</option><option value="cancelled" ${o.status === 'cancelled' ? 'selected' : ''}>Đã hủy</option></select>` : ''}</td><td><button class="link-btn" data-sf-remove="${i}" title="Xóa đơn">✕</button></td></tr>`).join('')}</table>${rows.length > 300 ? `<div class="empty">… và ${rows.length - 300} đơn nữa (đều vào file).</div>` : ''}`
      : '<div class="empty">Chưa có đơn. Dán mã đơn ở trên.</div>';
    $f('sfNote').innerHTML = rows.length
      ? `★ <b>${esc(rows[0].orderId)}</b> là mã đơn đại diện; file Excel <b>Danh sách đơn hàng</b> gồm ${rows.length} đơn${cancelled ? ` (${cancelled} đơn đã hủy)` : ''}.${f.note ? ' Tool tự điền Mô tả thêm ngắn.' : ''} Shopee bắt đăng nhập thì đăng nhập tài khoản shop, tool tự điền tiếp.`
      : '';
    $f('sfRaise').disabled = !rows.length;
    $f('sfRaise').textContent = `Raise 1 ticket · ${rows.length} đơn`;
    renderFollow().catch(() => {});
  }
  async function renderFollow() {
    if (!$f('sfFollowCard')?.open) return;
    const list = (await OPShopeePickup.followList()).filter(t => Object.values(OPShopeePickup.FORMS).some(f => f.title === t.form)).slice(0, 15);
    const sig = JSON.stringify(list); if (sig === lastFollow) return; lastFollow = sig;
    $f('sfFollow').innerHTML = `<button id="sfFollowOpen" class="secondary wide">Mở Seller Service · Yêu cầu của tôi</button>
      <div class="data-note">Mở trang (đăng nhập shop nếu cần); tool tự đọc trạng thái phiếu từ dữ liệu trang trả về.</div>
      ${list.length ? `<table class="sf-follow"><tr><th>Mã phiếu</th><th>Form · đơn</th><th>Trạng thái</th></tr>${list.map(t => `<tr><td>${esc(t.ticketId || 'chờ mã…')}</td><td>${esc(t.form)}<br>${esc(t.orderId)}${t.orders > 1 ? ` +${t.orders - 1}` : ''} · ${esc(new Date(t.at).toLocaleString('vi-VN'))}</td><td>${t.status ? `<b>${esc(t.status.status || (t.status.code ? '#' + t.status.code : '?'))}</b>` : 'chưa đọc'}</td></tr>`).join('')}</table>` : '<div class="data-note">Chưa có phiếu nào.</div>'}`;
    $f('sfFollowOpen').onclick = () => chrome.tabs.create({ url: OPShopeePickup.FOLLOW_URL, active: true });
  }
  function refreshShop(ensureOpen = false) {
    if (reading) return reading;
    reading = (async () => {
      if (ensureOpen) $f('sfShop').textContent = 'Đang mở Kênh Người Bán Shopee và tự nhận shop…';
      const result = await sendRuntimeMessage({ type: 'GET_LOGGED_IN_SHOPEE_SHOP', ensureOpen });
      shop = result?.ok ? String(result.name || '') : '';
      $f('sfShop').textContent = shop || result?.error || 'Mở Kênh Người Bán Shopee để tự nhận shop.';
      return result;
    })().finally(() => { reading = null; });
    return reading;
  }
  async function raise() {
    const d = draft(), f = form();
    if (!d.orders.length) throw new Error('Chưa có mã đơn.');
    const result = await refreshShop(true);
    if (!result?.ok) throw new Error(result?.error || 'Mở Kênh Người Bán Shopee đúng shop để tool nhận tên shop.');
    const option = Number(d.option || 0), cancelled = d.orders.filter(o => o.status === 'cancelled').length;
    const reason = kind === 'urge' ? '' : option === 1 ? 'Shipper chưa liên hệ lấy hàng nhưng hệ thống cập nhật lấy hàng không thành công'
      : `Kho đã giao hàng cho ĐVVC nhưng Shopee chưa cập nhật trạng thái đã lấy hàng${cancelled ? `, ${cancelled} đơn đã bị hủy` : ''}`;
    $f('sfRaise').disabled = true; status(`Đang mở form "${f.title}"…`, 'running');
    const r = await OPShopeePickup.raise({ choice: `${kind}:${option}`, channel: shop, carrier: d.carrier || '', reason, status: `${f.title} · ${f.options[option]}`,
      rows: d.orders.map(o => ({ orderId: o.orderId, trackingId: o.trackingId, carrier: o.carrier || d.carrier || '', note: [o.status === 'cancelled' ? 'Đơn đã bị hủy' : '', o.note].filter(Boolean).join(' · '), _original: { ShopeeOrderStatus: o.status } })) });
    d.lastRaise = { at: new Date().toISOString(), orders: r.orders, option: r.option, file: r.file }; d.orders = []; await save(); render();
    status(`✓ Đã mở form "${r.form}" · ${r.orders} đơn (file ${r.file}). Tool tự điền, tải file, Gửi và lưu mã phiếu — giữ tab mở tới khi có mã.`);
  }
  // Pickup backlog đang nạp (Power BI) → chỉ đơn Shopee của shop đang đăng nhập (khớp Channel Name).
  async function fromBacklog() {
    const rows = (typeof eligibleRows !== 'undefined' ? eligibleRows : []).filter(r => valid(r.orderId));
    if (!rows.length) throw new Error('Chưa nạp Pickup backlog Shopee (Loại ticket "Pickup backlog" → bước 1–2).');
    const result = await refreshShop(true); const key = plain(shop).replace(/[^a-z0-9]/g, '');
    const mine = key ? rows.filter(r => { const c = plain(r.channel).replace(/[^a-z0-9]/g, ''); return c && (c.includes(key) || key.includes(c)); }) : [];
    if (!mine.length) throw new Error(result?.ok ? `Backlog không có đơn của shop "${shop}". Kiểm tra Channel Name hoặc dán mã đơn.` : (result?.error || 'Chưa nhận được shop.'));
    const added = addOrders(mine.map(r => ({ orderId: r.orderId, trackingId: r.trackingId, carrier: r.carrier, note: [r.status, r.slaAt ? `SLA ${r.slaAt}` : ''].filter(Boolean).join(' · ') })));
    if (!draft().carrier) draft().carrier = [...new Set(mine.map(r => r.carrier).filter(Boolean))].join(', ').slice(0, 70);
    await save(); render(); status(`Đã thêm ${added} đơn backlog của ${shop}.`);
  }
  async function fromHandover() {
    const st = await chrome.storage.local.get(['handoverSessions', 'handoverSelectedByPlatform']);
    const sessions = st.handoverSessions || {}, s = sessions[st.handoverSelectedByPlatform?.shopee] || Object.values(sessions).filter(x => x.platform === 'shopee').sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)))[0];
    if (!s) throw new Error('Chưa có phiên Kháng nghị Shopee.');
    const added = addOrders((s.orders || []).filter(o => o.selected !== false).map(o => ({ orderId: o.orderId, trackingId: o.trackingId, carrier: s.carrier, status: o.status, note: o.sequence ? `STT biên bản ${o.sequence}` : '' })));
    if (!draft().carrier && s.carrier) draft().carrier = s.carrier;
    await save(); render(); status(added ? `Đã thêm ${added} đơn từ phiên Kháng nghị.` : 'Phiên Kháng nghị không có đơn mới hợp lệ.', added ? '' : 'error');
  }
  const run = fn => () => fn().catch(error => { status(error.message || String(error), 'error'); render(); });
  $f('sfAdd').addEventListener('click', run(async () => {
    const list = parsePaste($f('sfPaste').value); if (!list.length) throw new Error('Không thấy mã đơn Shopee hợp lệ (dạng 261008ABC12345).');
    const added = addOrders(list); $f('sfPaste').value = ''; await save(); render(); status(`Đã thêm ${added} đơn · tổng ${draft().orders.length} đơn vào 1 ticket.`);
  }));
  $f('sfFromBacklog').addEventListener('click', run(fromBacklog));
  $f('sfFromHandover').addEventListener('click', run(fromHandover));
  $f('sfRaise').addEventListener('click', run(raise));
  $f('sfRefreshShop').addEventListener('click', run(() => refreshShop(true)));
  $f('sfClear').addEventListener('click', run(async () => { draft().orders = []; await save(); render(); status('Đã xóa danh sách đơn.'); }));
  $f('sfOption').addEventListener('change', () => { draft().option = Number($f('sfOption').value) || 0; save(); });
  $f('sfCarrier').addEventListener('input', () => { draft().carrier = $f('sfCarrier').value; save(); });
  $f('sfOrders').addEventListener('click', event => { const i = event.target.dataset?.sfRemove; if (i == null) return; draft().orders.splice(Number(i), 1); save(); render(); });
  $f('sfOrders').addEventListener('change', event => { const i = event.target.dataset?.sfStatus; if (i == null) return; draft().orders[Number(i)].status = event.target.value; save(); render(); });
  $f('sfFollowCard').addEventListener('toggle', () => { lastFollow = ''; renderFollow().catch(() => {}); });
  chrome.storage.onChanged.addListener((changes, area) => { if (area === 'local' && (changes.shopeeFollowTickets || changes.shopeeCaseStatus)) renderFollow().catch(() => {}); });
  let loaded = chrome.storage.local.get(KEY).then(data => { drafts = data[KEY] || {}; });
  globalThis.OPShopeeFormPanel = {
    show(workflow) {
      const next = workflow === 'shopee_urge' ? 'urge' : 'status';
      loaded.then(() => { const changed = next !== kind; kind = next; render(); if (changed) status('Dán mã đơn rồi bấm Raise.'); if (!shop) refreshShop(false).catch(() => {}); });
    },
    parsePaste, addOrders
  };
})();
