(() => {
  const $h = id => document.getElementById(id);
  let sessions = {}, selectedId = '', history = [], run = null, workflow = 'backlog', loading = true, saving = Promise.resolve();
  let shopName = '', readingShop = null, shopeeOpenRequested = false, visiblePlatform = '', workflows = {}, selections = {};
  const current = () => sessions[selectedId];
  const sameOrder = (a, b) => OPHandover.orderKey(a) === OPHandover.orderKey(b);
  const completed = order => history.find(item => OPHandover.matches(item, order.orderId, current()));
  const frozen = () => run?.sessionId === selectedId && !run.doneAt && Boolean(run.activeKey || (!run.paused && run.pending?.length));
  const esc = value => escapeHtml(value);
  function status(message, kind = '') { $h('handoverStatus').textContent = message; $h('handoverStatus').className = `status-box ${kind}`; }
  function persist() {
    const snapshot = JSON.parse(JSON.stringify(sessions));
    const selection = selectedId;
    selections[OPHandover.platform(current())] = selection;
    saving = saving.catch(() => {}).then(() => chrome.storage.local.set({ handoverSessions: snapshot, handoverSelectedSession: selection, handoverSelectedByPlatform: { ...selections } }));
    return saving;
  }
  function applyWorkflow() {
    if (!loading && visiblePlatform !== activePlatform) {
      visiblePlatform = activePlatform; shopeeOpenRequested = false;
      workflow = workflows[activePlatform] || 'backlog';
      selectedId = selections[activePlatform] || Object.values(sessions).find(item => OPHandover.platform(item) === activePlatform)?.id || '';
      if (!sessions[selectedId] || OPHandover.platform(sessions[selectedId]) !== activePlatform) {
        const session = OPHandover.newSession(activePlatform); sessions[session.id] = session; selectedId = session.id;
      }
      shopName = ''; persist().catch(reportError); render(); return;
    }
    $h('ticketWorkflowPanel').hidden = false;
    // v2.2.4 — Loại ticket riêng của Shopee: 2 webform Người bán về lấy hàng (shopee_form_panel.js).
    [...($h('ticketWorkflow').options || [])].forEach(option => { if (option.dataset.platform) option.hidden = option.disabled = option.dataset.platform !== activePlatform; });
    if (/^shopee_/.test(workflow) && activePlatform !== 'shopee') workflow = 'backlog';
    // v2.2.67 — Đòi hàng có cả TikTok và Shopee (panel tự lọc channel theo sàn đang chọn).
    const isForm = /^shopee_(status|urge)$/.test(workflow);
    const isHandover = workflow === 'handover';
    const isCancelReturn = workflow === 'cancel_return';
    $h('handoverPanel').hidden = !isHandover;
    if ($h('shopeeFormPanel')) $h('shopeeFormPanel').hidden = !isForm;
    document.querySelectorAll('[data-backlog-panel]').forEach(panel => { panel.hidden = isHandover || isForm || isCancelReturn; });
    $h('ticketWorkflow').value = workflow;
    if (isForm) globalThis.OPShopeeFormPanel?.show(workflow);
    globalThis.OPCancelReturnPanel?.show(isCancelReturn, activePlatform);
    if (isHandover && !loading) {
      const ensureOpen = activePlatform === 'shopee' && !shopeeOpenRequested;
      if (ensureOpen) shopeeOpenRequested = true;
      refreshShop(ensureOpen).catch(reportError);
    }
  }
  globalThis.OPHandoverPanel = { renderPlatform: applyWorkflow };
  function renderSessions() {
    $h('handoverSessionSelect').innerHTML = Object.values(sessions).filter(session => OPHandover.platform(session) === activePlatform).map(session =>
      `<option value="${esc(session.id)}">${esc(session.files?.[0]?.name || 'Biên bản mới')} · ${(session.orders || []).length} đơn</option>`).join('');
    $h('handoverSessionSelect').value = selectedId;
  }
  function fileList(files, scope, rowId = '') {
    return files.length ? files.map((file, index) => `<div class="handover-file"><span>${esc(file.name)} · ${formatBytes(file.size)}</span><button class="link-btn" data-file-remove="${index}" data-scope="${scope}" data-row="${esc(rowId)}" ${frozen() ? 'disabled' : ''}>Xóa</button></div>`).join('') : '<div class="data-note">Chưa có file.</div>';
  }
  function updatePreviews() {
    const session = current();
    if (!session) return;
    session.orders.forEach(order => {
      const card = $h('handoverOrders').querySelector(`[data-order-card="${order.id}"]`);
      if (!card) return;
      const text = OPHandover.text(session, order);
      const area = card.querySelector('[data-field="textOverride"]');
      if (document.activeElement !== area) area.value = text;
      const count = card.querySelector('.handover-count');
      count.textContent = `${text.length}/${OPHandover.maxText(session)} ký tự${order.textOverride ? ' · Đã sửa riêng' : ' · Tự tạo'}`;
      count.classList.toggle('over', text.length > OPHandover.maxText(session));
    });
  }
  function renderCards() {
    const session = current();
    if (!session) return;
    const lock = frozen();
    const input = (order, field, label, max, placeholder = '', inputmode = '') => `<div class="field-row"><label>${label}</label><input data-field="${field}" value="${esc(order[field])}" maxlength="${max}" placeholder="${esc(placeholder)}" ${inputmode ? `inputmode="${inputmode}"` : ''} ${lock || completed(order) ? 'disabled' : ''} /></div>`;
    $h('handoverOrders').innerHTML = session.orders.map((order, index) => {
      const done = completed(order);
      const open = ticketOpenGroups?.[OPHandover.groupKey(order.orderId, session)];
      const cardStatus = done ? `${done.TicketID ? `✓ Đã tự lưu Ticket ${done.TicketID}` : '✓ Đã gửi · chờ Shopee cấp mã phiếu'} · ${done.SyncStatus === 'Synced' ? 'tracker đã đồng bộ' : 'đang đồng bộ tracker'}`
        : open ? `Đang xử lý đơn ${order.orderId} · ${open.autofill?.details || 'tự gửi và lưu Ticket ID'}` : 'Chưa gửi';
      return `<article class="handover-card" data-order-card="${esc(order.id)}">
        <div class="handover-card-head"><label><input type="checkbox" data-field="selected" ${order.selected && !done ? 'checked' : ''} ${lock || done ? 'disabled' : ''} />Đơn ${index + 1}</label><button class="link-btn" data-remove-order="${esc(order.id)}" ${lock ? 'disabled' : ''}>Xóa dòng</button></div>
        ${input(order, 'orderId', `Mã đơn ${OPHandover.label(session)} *`, 25, 'Mã đơn hàng trên sàn', OPHandover.platform(session) === 'shopee' ? 'text' : 'numeric')}
        ${input(order, 'trackingId', 'Mã vận đơn *', 64, 'VTPVN9058431802')}
        <div class="handover-two">${input(order, 'sequence', 'STT biên bản *', 32, '68')}
        <div class="field-row"><label>Tình trạng</label><select data-field="status" ${lock || done ? 'disabled' : ''}><option value="pending" ${order.status !== 'cancelled' ? 'selected' : ''}>Chưa bị hủy</option><option value="cancelled" ${order.status === 'cancelled' ? 'selected' : ''}>Đã bị hủy</option></select></div></div>
        <details class="handover-extra"><summary>Thêm trang / ghi chú / bằng chứng riêng</summary>${input(order, 'page', 'Trang biên bản', 16, '2')}${input(order, 'note', 'Ghi chú riêng', 120, 'Thông tin bổ sung')}
        <input data-order-files="${esc(order.id)}" type="file" multiple accept=".pdf,.jpg,.jpeg,.png,.xlsx,.xls,.csv,.mp4,.mov" ${lock || done ? 'disabled' : ''} />${fileList(order.files || [], 'order', order.id)}</details>
        <details class="handover-extra"><summary>Nội dung tự tạo</summary><textarea data-field="textOverride" rows="6" maxlength="${OPHandover.maxText(session)}" ${lock || done ? 'disabled' : ''}></textarea><div class="handover-count"></div>
        <div class="actions"><button class="secondary" data-reset-text="${esc(order.id)}" ${lock || done ? 'disabled' : ''}>Tạo lại</button><button class="secondary" data-copy-text="${esc(order.id)}">Copy</button></div></details>
        <div class="handover-card-status">${esc(cardStatus)}</div>
        ${done ? '' : `<button class="link-btn" data-send-order="${esc(order.id)}" ${lock ? 'disabled' : ''}>Gửi riêng đơn này</button><details class="handover-extra"><summary>Khôi phục phiếu khi đã đóng tab sớm</summary><div class="handover-manual"><input data-manual-id="${esc(order.id)}" placeholder="Ticket ID đã gửi" /><button class="secondary" data-manual-map="${esc(order.id)}">Lưu</button></div></details>`}
      </article>`;
    }).join('');
    updatePreviews();
  }
  function renderRun() {
    const ownRun = run?.sessionId === selectedId && !run.doneAt;
    const lock = frozen();
    const uploadRetry = ownRun && run.activeKey && ticketOpenGroups?.[run.activeKey]?.autofill?.reason === 'attachments-not-ready';
    ['handoverCarrier', 'handoverEmail', 'handoverFiles', 'handoverAddOrder', 'handoverImport'].forEach(id => { $h(id).disabled = lock || loading; });
    $h('handoverStart').disabled = loading || Boolean(run?.activeKey) || lock;
    $h('handoverPause').hidden = !ownRun || run.paused;
    $h('handoverResume').hidden = !uploadRetry && (!ownRun || !run.paused || Boolean(run.activeKey));
    $h('handoverResume').textContent = uploadRetry ? 'Thử lại đính kèm' : 'Tiếp tục';
    if (ownRun) {
      if (uploadRetry) status(ticketOpenGroups[run.activeKey].autofill.details, 'error');
      else if (run.error) status(run.error, 'error');
      else if (run.paused) status(run.activeKey ? 'Đã chọn dừng. Đơn hiện tại vẫn hoàn tất; các đơn sau chờ bấm Tiếp tục.' : `Tạm dừng · còn ${run.pending.length} đơn chưa lưu ticket.`, '');
      else status(`Đang auto theo từng đơn · còn ${run.pending.length} đơn chưa lưu ticket. ${OPHandover.platform(current()) === 'shopee' ? 'Tự lưu xác nhận gửi rồi chạy đơn tiếp theo; bổ sung mã phiếu khi Shopee trả về.' : 'Tự lưu Ticket ID rồi chạy đơn tiếp theo.'}`, 'running');
    } else if (run?.doneAt && run.sessionId === selectedId) {
      const waiting = current()?.orders.filter(order => completed(order)?.TicketStatus === 'SubmittedAwaitingID').length || 0;
      status(waiting ? `✓ Đã tự gửi và lưu các đơn · ${waiting} đơn chờ Shopee cấp mã phiếu. Giữ các tab xác nhận mở để tool bổ sung mã.` : '✓ Đã tự gửi và lưu ticket cho toàn bộ đơn đã chọn. Có thể export lịch sử bên dưới.');
    }
    else if (run?.activeKey) status('Đang xử lý đơn trong phiên khác. Chọn lại phiên đó để xem tiến trình.', 'running');
  }
  function render() {
    renderSessions();
    const session = current();
    if (!session) return;
    $h('handoverCarrier').value = session.carrier || '';
    $h('handoverEmail').value = session.shopeeEmail || 'operation@onpoint.vn';
    $h('handoverShopeeEmail').hidden = OPHandover.platform(session) !== 'shopee';
    $h('handoverFileLimit').textContent = `Dùng chung cho các đơn. Tối đa ${OPHandover.maxFiles(session)} file/ticket.`;
    $h('handoverTopicNote').textContent = OPHandover.platform(session) === 'shopee' ? 'Người bán → Vận chuyển. Mỗi file dưới 10 MB theo giới hạn của tool; định dạng phải được ô tải lên Shopee chấp nhận.' : 'Thực hiện đơn hàng & Hậu cần (3PL/4PL) → Đón và trả hàng (4PL) → Đã nhận hàng nhưng tình trạng hậu cần chưa được cập nhật. Ảnh <5 MB; PDF/Excel/CSV <50 MB; video <80 MB.';
    $h('handoverFileList').innerHTML = fileList(session.files || [], 'session');
    renderCards(); renderRun(); applyWorkflow();
  }
  async function storedFiles(list) {
    const files = [...list];
    for (const file of files) { const error = OPHandover.fileError(file, current()); if (error) throw new Error(error); }
    const attachments = [];
    for (const file of files) {
      const item = await fileToStoredAttachment(file);
      item.type = OPHandover.MIME[file.name.split('.').pop().toLowerCase()];
      attachments.push(item);
    }
    return attachments;
  }
  async function start(rowIds) {
    if (loading) return;
    const session = current();
    const orders = session.orders.filter(order => rowIds.includes(order.id) && !completed(order));
    const shop = await refreshShop(true);
    if (!shop?.ok) { status(shop?.error || `Mở đúng tab ${OPHandover.label(session)} để tự nhận tên shop.`, 'error'); return; }
    const errors = OPHandover.validate(session, orders);
    if (errors.length) { status(errors.join('\n'), 'error'); return; }
    $h('handoverStart').disabled = true;
    status('Đang mở ticket đầu tiên…', 'running');
    try {
      await persist();
      const result = await sendRuntimeMessage({ type: 'START_HANDOVER_TICKETS', sessionId: selectedId, rowIds: orders.map(order => order.id) });
      if (!result?.ok) throw new Error(result?.error || 'Không mở được hàng đợi.');
    } catch (error) { status(error.message || String(error), 'error'); }
    finally { renderRun(); }
  }
  function reportError(error) { status(error.message || String(error), 'error'); }
  function refreshShop(ensureOpen = false) {
    if (readingShop) return readingShop.then(() => { readingShop = null; return refreshShop(ensureOpen); });
    readingShop = (async () => {
      const session = current(); const source = OPHandover.platform(session);
      if (source === 'shopee' && ensureOpen) $h('handoverShopName').textContent = 'Đang mở Kênh Người Bán Shopee và tự nhận shop…';
      const result = await sendRuntimeMessage({ type: source === 'shopee' ? 'GET_LOGGED_IN_SHOPEE_SHOP' : 'GET_LOGGED_IN_TIKTOK_SHOP', ...(source === 'shopee' ? { ensureOpen } : {}) });
      if (current()?.id !== session?.id || activePlatform !== source) return result;
      shopName = result?.ok ? String(result.name || '') : '';
      $h('handoverShopName').textContent = shopName || result?.error || `Mở tab ${OPHandover.label(current())} để tự nhận shop.`;
      if (current() && !frozen() && current().channel !== shopName) { current().channel = shopName; await persist(); }
      return result;
    })().finally(() => { readingShop = null; });
    return readingShop;
  }
  $h('handoverRefreshShop').addEventListener('click', () => refreshShop(true).catch(reportError));
  chrome.tabs?.onActivated?.addListener(() => { if (workflow === 'handover') refreshShop().catch(reportError); });
  chrome.tabs?.onUpdated?.addListener((tabId, changeInfo) => { if (changeInfo.status === 'complete' && workflow === 'handover') refreshShop().catch(reportError); });
  setInterval(() => { if (!loading && workflow === 'handover' && !frozen()) refreshShop().catch(reportError); }, 5000);
  $h('ticketWorkflow').addEventListener('change', async event => {
    workflow = ['handover', 'cancel_return', 'shopee_status', 'shopee_urge'].includes(event.target.value) ? event.target.value : 'backlog';
    if (activePlatform === 'shopee' && workflow === 'handover') shopeeOpenRequested = false;
    workflows[activePlatform] = workflow;
    await chrome.storage.local.set({ handoverWorkflows: { ...workflows }, ...(activePlatform === 'tiktok' ? { tiktokTicketWorkflow: workflow } : {}) });
    applyWorkflow();
  });
  $h('handoverNewSession').addEventListener('click', async () => {
    const session = OPHandover.newSession(activePlatform); sessions[session.id] = session; selectedId = session.id;
    session.channel = shopName;
    await persist(); status('Chọn biên bản và nhập đơn cần kháng nghị.'); render();
  });
  $h('handoverSessionSelect').addEventListener('change', async event => { selectedId = event.target.value; await persist(); status('Đã mở biên bản đã lưu.'); render(); });
  for (const [id, key] of Object.entries({ handoverCarrier: 'carrier', handoverEmail: 'shopeeEmail' })) {
    $h(id).addEventListener('input', () => {
      if (!current() || frozen()) return;
      current()[key] = $h(id).value;
      current().orders.forEach(order => { if (!completed(order)) order.textOverride = ''; });
      renderSessions(); updatePreviews(); persist().catch(reportError);
    });
  }
  $h('handoverFiles').addEventListener('change', async event => {
    const session = current();
    if (!session || frozen()) return;
    try {
      const selected = [...event.target.files];
      if ((session.files || []).length + selected.length > OPHandover.maxFiles(session)) throw new Error(`Tối đa ${OPHandover.maxFiles(session)} file chung/ticket. Xóa file cũ nếu muốn thay.`);
      status('Đang đọc biên bản…');
      const files = await storedFiles(selected);
      if (current()?.id !== session.id) return;
      session.files.push(...files); await persist(); render(); status(`Đã lưu ${session.files.length} file chung cho phiên.`);
    } catch (error) { reportError(error); }
    finally { event.target.value = ''; }
  });
  $h('handoverAddOrder').addEventListener('click', async () => { if (frozen()) return; current().orders.push(OPHandover.newOrder()); await persist(); renderCards(); });
  $h('handoverImport').addEventListener('click', async () => {
    if (frozen()) return;
    try {
      const added = OPHandover.parsePaste($h('handoverPaste').value, current());
      if (!added.length) throw new Error('Chưa có đơn để thêm.');
      const existing = new Set(current().orders.map(order => OPHandover.orderKey(order.orderId)).filter(Boolean));
      for (const order of added) { const key = OPHandover.orderKey(order.orderId); if (existing.has(key)) throw new Error(`Trùng mã đơn ${key}.`); existing.add(key); }
      current().orders = current().orders.filter(order => order.orderId || order.trackingId || order.sequence || order.files?.length);
      current().orders.push(...added); await persist(); $h('handoverPaste').value = ''; renderCards(); status(`Đã thêm ${added.length} đơn.`);
    } catch (error) { reportError(error); }
  });
  $h('handoverOrders').addEventListener('input', event => {
    const field = event.target.dataset.field;
    const card = event.target.closest('[data-order-card]');
    if (!field || !card || frozen()) return;
    const order = current().orders.find(item => item.id === card.dataset.orderCard);
    if (!order || completed(order)) return;
    order[field] = field === 'selected' ? event.target.checked : event.target.value;
    if (!['selected', 'textOverride'].includes(field)) order.textOverride = '';
    updatePreviews(); persist().catch(reportError);
  });
  $h('handoverOrders').addEventListener('change', async event => {
    const rowId = event.target.dataset.orderFiles;
    if (!rowId || frozen()) return;
    const session = current(); const order = session.orders.find(item => item.id === rowId);
    try {
      const selected = [...event.target.files];
      if (OPHandover.filesFor(session, order).length + selected.length > OPHandover.maxFiles(session)) throw new Error(`Mỗi ticket tối đa ${OPHandover.maxFiles(session)} file chung + riêng.`);
      order.files.push(...await storedFiles(selected)); await persist(); renderCards();
    } catch (error) { reportError(error); }
    finally { event.target.value = ''; }
  });
  async function removeFile(button) {
    if (frozen()) return;
    const files = button.dataset.scope === 'session' ? current().files : current().orders.find(order => order.id === button.dataset.row)?.files;
    if (!files) return;
    files.splice(Number(button.dataset.fileRemove), 1); await persist(); render();
  }
  $h('handoverFileList').addEventListener('click', event => { const button = event.target.closest('[data-file-remove]'); if (button) removeFile(button).catch(reportError); });
  $h('handoverOrders').addEventListener('click', async event => {
    const button = event.target.closest('button'); if (!button || button.disabled) return;
    try {
      if (button.hasAttribute('data-file-remove')) return await removeFile(button);
      if (button.dataset.removeOrder) {
        if (frozen()) return;
        current().orders = current().orders.filter(order => order.id !== button.dataset.removeOrder);
        if (!current().orders.length) current().orders.push(OPHandover.newOrder());
        await persist(); renderCards();
      } else if (button.dataset.resetText) {
        current().orders.find(order => order.id === button.dataset.resetText).textOverride = ''; updatePreviews(); await persist();
      } else if (button.dataset.copyText) {
        const order = current().orders.find(item => item.id === button.dataset.copyText);
        await navigator.clipboard.writeText(OPHandover.text(current(), order));
      } else if (button.dataset.sendOrder) await start([button.dataset.sendOrder]);
      else if (button.dataset.manualMap) {
        const rowId = button.dataset.manualMap;
        const ticketId = button.closest('[data-order-card]').querySelector('[data-manual-id]').value.trim();
        await persist();
        const result = await sendRuntimeMessage({ type: 'MAP_HANDOVER_MANUALLY', sessionId: selectedId, rowId, ticketId });
        if (!result?.ok) throw new Error(result?.error || 'Không map được Ticket ID.');
        status(`✓ Đã lưu Ticket ${ticketId}.`);
      }
    } catch (error) { reportError(error); }
  });
  $h('handoverStart').addEventListener('click', () => start(current().orders.filter(order => order.selected && !completed(order)).map(order => order.id)));
  $h('handoverPause').addEventListener('click', async () => { const result = await sendRuntimeMessage({ type: 'PAUSE_HANDOVER_TICKETS' }); if (!result?.ok) status(result?.error, 'error'); });
  $h('handoverResume').addEventListener('click', async () => { const result = await sendRuntimeMessage({ type: 'RESUME_HANDOVER_TICKETS' }); if (!result?.ok) status(result?.error, 'error'); });
  $h('handoverExport').addEventListener('click', () => {
    const platformHistory = history.filter(item => OPHandover.platform(String(item.TicketPlatform || 'tiktok').toLowerCase()) === activePlatform);
    if (!platformHistory.length) return status('Chưa có lịch sử kháng nghị.');
    const headers = [...new Set(platformHistory.flatMap(record => Object.keys(record)))];
    triggerDownload(createXlsx(headers, platformHistory, 'Handover Appeals'), `${OPHandover.label(current())}_Handover_Appeals_${new Date().toISOString().slice(0,10)}.xlsx`, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  });
  chrome.runtime.onMessage.addListener(message => {
    if (workflow === 'handover' && message?.type === 'TICKET_STEP_TEXT') { if (run?.doneAt && run.sessionId === selectedId) renderRun(); else status(message.text, message.warn ? 'error' : 'running'); }
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    if (changes.handoverTicketHistory) history = changes.handoverTicketHistory.newValue || [];
    if (changes.handoverRun) run = changes.handoverRun.newValue || null;
    if (changes.handoverRun || changes.handoverTicketHistory || changes.ticketOpenGroups) { renderCards(); renderRun(); }
  });
  chrome.storage.local.get(['handoverSessions', 'handoverSelectedSession', 'handoverTicketHistory', 'handoverRun', 'tiktokTicketWorkflow', 'handoverWorkflows', 'handoverSelectedByPlatform'], async data => {
    sessions = data.handoverSessions || {}; selectedId = data.handoverSelectedSession || '';
    for (const session of Object.values(sessions)) { delete session.name; delete session.warehouse; delete session.handedAt; }
    history = data.handoverTicketHistory || []; run = data.handoverRun || null;
    const savedTikTok = ['handover', 'cancel_return'].includes(data.tiktokTicketWorkflow) ? data.tiktokTicketWorkflow : 'backlog';
    workflows = data.handoverWorkflows || { tiktok: savedTikTok };
    selections = data.handoverSelectedByPlatform || { tiktok: selectedId };
    workflow = savedTikTok;
    if (!sessions[selectedId]) { const session = OPHandover.newSession(activePlatform); sessions[session.id] = session; selectedId = session.id; await persist(); }
    loading = false; render();
  });
})();
