/* Cầu nối Performance → Kháng nghị.
   FHR_RECALC: danh sách đơn bị ảnh hưởng đọc từ trang Shopee "tỷ lệ giao hàng nhanh tính lại" (shopee.vn/m/tylegiaohangnhanhtinhlai),
   lưu chrome.storage.local.fhrRecalc để side panel soạn tin chat CSKH / đưa vào Kháng nghị. Không gửi gì ra ngoài. */
/* v2.2.9 — "FHR tính lại (xét nhãn Mall)": % theo tuần đọc từ cùng trang (Chỉ số tuần trước / 2 tuần trước + Ngày cập nhật).
   Lưu theo Shop ID (fhrRecalcByShop). Chỉ đưa lên Sheet khi Shop ID lấy được từ chính trang (không đoán):
   ghi thành dòng lịch sử X_FHR_RECALC vào SPE_Daily qua luồng upload sẵn có (cột tên / đơn vị / nguồn của Daily). */
const FHR_RECALC_METRIC = 'X_FHR_RECALC', FHR_RECALC_NAME = 'Tỷ lệ giao hàng nhanh tính lại (xét nhãn Mall)';
function fhrRecalcRows(entry) {
  return (entry?.weeks || []).filter(w => /^\d{4}-\d{2}-\d{2}$/.test(w.date) && Number.isFinite(w.value) && w.value >= 0 && w.value <= 1)
    .map(w => ({ metric: FHR_RECALC_METRIC, date: w.date, value: w.value, name: FHR_RECALC_NAME, unit: 'rate', source: 'SHOPEE_FHR_RECALC_PAGE', window_start: '', window_end: '' }));
}
/* Gọi từ enqueueAndSync (perf-background.js) trước khi gửi một run Shopee: ghép các tuần FHR tính lại của đúng Shop ID. Trả về số dòng mới. */
async function mergeFhrRecalc_(s) {
  const r = s?.run; if (!r || String(r.platform || '').toUpperCase() !== 'SHOPEE' || !r.shopId) return 0;
  const { fhrRecalcByShop = {} } = await chrome.storage.local.get('fhrRecalcByShop');
  const rows = fhrRecalcRows(fhrRecalcByShop[String(r.shopId)]); if (!rows.length) return 0;
  s.daily ||= {}; const cur = s.daily[r.id] || [], key = d => `${d.metric}|${d.date}|${d.window_start || ''}|${d.window_end || ''}`;
  const seen = new Map(cur.map(d => [key(d), d])); let added = 0;
  for (const d of rows) { const old = seen.get(key(d)); if (!old || old.value !== d.value) { seen.set(key(d), d); added++; } }
  if (added) { s.daily[r.id] = [...seen.values()]; r.dailyRows = s.daily[r.id].length; }
  return added;
}
chrome.runtime.onMessage.addListener((m, sender, respond) => {
  if (sender.id !== chrome.runtime.id || m?.type !== 'FHR_RECALC') return false;
  if (!sender.tab || !/^https:\/\/shopee\.vn\/m\/tylegiaohangnhanhtinhlai/i.test(String(sender.url || sender.tab.url || ''))) { respond({ ok: false }); return false; }
  const orders = [...new Set((Array.isArray(m.orders) ? m.orders : []).map(x => String(x || '').trim().toUpperCase()).filter(x => /^\d{6}[A-Z0-9]{6,14}$/.test(x) || /^\d{12,22}$/.test(x)))].slice(0, 200);
  const weeks = (Array.isArray(m.weeks) ? m.weeks : []).filter(w => /^\d{4}-\d{2}-\d{2}$/.test(String(w?.date)) && Number.isFinite(w?.value) && w.value >= 0 && w.value <= 1).slice(0, 4)
    .map(w => ({ date: String(w.date), value: Number(w.value), label: String(w.label || '').slice(0, 40) }));
  if (!orders.length && !weeks.length) { respond({ ok: false }); return false; }
  const fromPage = String(m.shopId || '').replace(/\D/g, '').slice(0, 24);
  chrome.storage.local.get(['fhrRecalc', 'fhrRecalcByShop', 'state', 'fhrAuto', 'fhrUserByShop']).then(async ({ fhrRecalc, fhrRecalcByShop = {}, state, fhrAuto = {}, fhrUserByShop = {} }) => {
    /* Trang "tính lại" thường không tự trả Shop ID. shopee.vn và Kênh Người Bán dùng chung phiên đăng nhập Shopee của trình duyệt
       → lấy Shop ID đã nhận diện ở các tab Kênh Người Bán đang mở, CHỈ khi tất cả cùng một shop (nhiều shop khác nhau → không đoán). */
    /* v2.2.18 — tab do tool tự mở cho đúng Shop ID vừa lấy dữ liệu (cùng phiên đăng nhập Shopee của trình duyệt) → biết chắc shop.
       Vẫn chặn khi trang tự báo Shop ID khác, hoặc tài khoản đang đăng nhập shopee.vn khác tài khoản đã gắn với shop. */
    const auto = fhrAuto.tabs?.[sender.tab.id], user = String(m.username || '').slice(0, 80);
    const userConflict = sid => !!(user && sid && ((fhrUserByShop[sid] && fhrUserByShop[sid] !== user) || Object.entries(fhrUserByShop).some(([k, u]) => u === user && k !== sid)));
    if (auto) {
      const why = fromPage && fromPage !== auto.shopId ? `trang báo Shop ID ${fromPage}` : (auto.username && user && auto.username !== user) || userConflict(auto.shopId) ? `shopee.vn đang đăng nhập tài khoản ${user}` : '';
      if (why) { if (weeks.length) await fhrAutoDone_(sender.tab.id, 'mismatch', `Không lưu: ${why}, không phải shop ${auto.shopId}.`); respond({ ok: false, mismatch: true }); return; }
    }
    let pageShop = fromPage || auto?.shopId || '';
    if (pageShop && userConflict(pageShop)) pageShop = '';
    if (!pageShop) {
      const tabs = await chrome.tabs.query({ url: ['https://banhang.shopee.vn/*', 'https://seller.shopee.vn/*'] }).catch(() => []);
      const ids = new Set(tabs.map(t => state?.detected?.[t.id]).filter(d => d && String(d.platform || '').toUpperCase() === 'SHOPEE' && /^\d{5,24}$/.test(String(d.shopId || ''))).map(d => String(d.shopId)));
      if (ids.size === 1 && !userConflict([...ids][0])) pageShop = [...ids][0];
    }
    const now = new Date().toISOString(), shopId = pageShop || fhrRecalc?.shopId || '';
    const prev = fhrRecalc && Date.now() - Date.parse(fhrRecalc.at || 0) < 6 * 3600e3 ? fhrRecalc.orders || [] : [];
    const merged = [...new Set([...prev, ...orders])].slice(0, 200);
    const patch = { fhrRecalc: { orders: merged, at: now, shopId, info: String(m.info || '').slice(0, 300), weeks: weeks.length ? weeks : fhrRecalc?.weeks || [], shopConfirmed: weeks.length ? !!pageShop : !!fhrRecalc?.shopConfirmed } };
    let saved = false;
    if (weeks.length && pageShop) {
      const old = fhrRecalcByShop[pageShop]?.weeks || [], byDate = new Map([...old, ...weeks].map(w => [w.date, w]));
      fhrRecalcByShop[pageShop] = { shopId: pageShop, weeks: [...byDate.values()].sort((a, b) => b.date.localeCompare(a.date)).slice(0, 26), at: now };
      patch.fhrRecalcByShop = fhrRecalcByShop; saved = true;
      if (user) patch.fhrUserByShop = { ...fhrUserByShop, [pageShop]: user };
    }
    await chrome.storage.local.set(patch);
    if (weeks.length && auto) await fhrAutoDone_(sender.tab.id, saved ? 'done' : 'unknown', saved ? '' : 'Đọc được số nhưng không xác định được shop.', saved ? { weeks, username: user } : {});
    if (saved) fhrQueueUpload_(pageShop).catch(() => {});
    respond({ ok: true, count: merged.length, weeks, saved, shopId: pageShop, shopSource: fromPage ? 'page' : pageShop ? 'seller-tab' : '' });
  }).catch(e => respond({ ok: false, error: e.message }));
  return true;
});

/* v2.2.7 — Khiếu nại theo TỪNG store (không chỉ store lấy sau cùng). v2.2.9 — thêm store TikTok (FDR / LDR) bên cạnh Shopee (FHR / LSR).
   Mỗi lần state.run là Shopee/TikTok, lưu metadata run vào chrome.storage.local.claimRuns (mới nhất theo sàn + Shop ID, tối đa 60 shop);
   đơn lỗi vẫn nằm sẵn trong IndexedDB (OPDB) theo runId nên panel đọc lại được qua CLAIM_RUNS / CLAIM_EXPORT. */
const CLAIM_METRICS = { SHOPEE: ['FHR', 'LSR'], TIKTOK: ['FDR', 'LDR'] };
let claimRunsSaving = Promise.resolve();
function rememberClaimRun(run) {
  const platform = String(run?.platform || '').toUpperCase();
  if (!run?.id || !CLAIM_METRICS[platform] || !run.shopId) return claimRunsSaving;
  claimRunsSaving = claimRunsSaving.catch(() => {}).then(async () => {
    const { claimRuns = {} } = await chrome.storage.local.get('claimRuns');
    const meta = { id: run.id, platform, shopId: String(run.shopId), shopName: run.shopName || '', shopCode: run.shopCode || '', channel_code: run.channel_code || '', business_code: run.business_code || '', channel_name: run.channel_name || '', warehouse: run.warehouse || '', metrics: (run.metrics || []).filter(m => CLAIM_METRICS[platform].includes(m.code)).map(m => ({ code: m.code, value: m.value, period_start: m.period_start || '', period_end: m.period_end || '' })), at: new Date().toISOString() };
    const next = { ...claimRuns, [platform === 'SHOPEE' ? meta.shopId : `${platform}:${meta.shopId}`]: meta }; // khóa Shopee giữ như cũ (Shop ID)
    const keys = Object.keys(next).sort((a, b) => String(next[b].at).localeCompare(String(next[a].at)));
    for (const k of keys.slice(60)) delete next[k];
    await chrome.storage.local.set({ claimRuns: next });
  });
  return claimRunsSaving;
}
chrome.storage.onChanged.addListener((changes, area) => { if (area === 'local' && changes.state?.newValue?.run) rememberClaimRun(changes.state.newValue.run).catch(() => {}); });
chrome.storage.local.get('state').then(({ state }) => rememberClaimRun(state?.run)).catch(() => {});
chrome.runtime.onMessage.addListener((m, sender, respond) => {
  if (!['CLAIM_RUNS', 'CLAIM_EXPORT'].includes(m?.type)) return false;
  if (sender.id !== chrome.runtime.id || !String(sender.url || '').startsWith(chrome.runtime.getURL(''))) { respond({ ok: false, error: 'Chỉ chạy từ panel.' }); return false; } // trang extension, không nhận từ content script
  (async () => {
    await claimRunsSaving.catch(() => {});
    const { claimRuns = {} } = await chrome.storage.local.get('claimRuns');
    if (m.type === 'CLAIM_EXPORT') {
      const run = Object.values(claimRuns).find(r => r.id === m.runId); if (!run) return { ok: false, error: 'Không còn dữ liệu store này. Lấy dữ liệu lại.' };
      return { ok: true, run, orders: await OPDB.list(run.id) };
    }
    const runs = [];
    for (const r of Object.values(claimRuns)) {
      const orders = await OPDB.list(r.id).catch(() => []);
      const n = k => orders.filter(o => o.metric === k).length;
      runs.push({ id: r.id, platform: r.platform || 'SHOPEE', shopId: r.shopId, shopName: r.shopName || r.channel_name, at: r.at, fhr: n('FHR'), lsr: n('LSR'), fdr: n('FDR'), ldr: n('LDR') });
    }
    const total = r => r.fhr + r.lsr + r.fdr + r.ldr;
    return { ok: true, runs: runs.sort((a, b) => (total(b) > 0) - (total(a) > 0) || String(b.at).localeCompare(String(a.at))) };
  })().then(respond).catch(e => respond({ ok: false, error: e.message }));
  return true;
});


/* =====================================================================================================
   v2.2.18 — FHR tính lại TỰ ĐỘNG: mở trang shopee.vn/m/tylegiaohangnhanhtinhlai ở TAB NỀN (không giành màn hình)
   ngay khi bắt đầu lấy dữ liệu một shop Shopee → fhr-recalc.js đọc % + ngày → lưu theo Shop ID → tự đóng tab.
   - Chỉ MỞ TRANG như người dùng xem, không gọi API riêng của shopee.vn (gọi API lạ dễ bị Shopee chặn "verify/traffic").
   - Mỗi shop tối đa 1 lần / 6 giờ khi đã đọc được (lỗi: thử lại sau 30 phút). Nút "Đọc lại ngay" trên panel bỏ qua giới hạn.
   - Lưu lên Performance: nếu lượt lấy chưa gửi → đi cùng lượt đó; nếu đã gửi → gửi riêng vài dòng X_FHR_RECALC (không gửi lại đơn).
   ===================================================================================================== */
const FHR_PAGE_URL = 'https://shopee.vn/m/tylegiaohangnhanhtinhlai', FHR_TAB_TTL = 90000, FHR_GAP_OK = 6 * 3600e3, FHR_GAP_FAIL = 30 * 60e3;
let fhrLock = Promise.resolve();
const fhrSerial = f => { const p = fhrLock.then(f); fhrLock = p.catch(() => {}); return p; };
async function fhrSetStatus_(fhrAuto, shopId, state, message = '', extra = {}) {
  fhrAuto.status = { ...(fhrAuto.status || {}), [shopId]: { state, message, at: new Date().toISOString(), ...extra } };
}
async function fhrAutoOpen(shopId, opt = {}) {
  shopId = String(shopId || ''); if (!/^\d{5,24}$/.test(shopId)) return { ok: false, error: 'Chưa có Shop ID Shopee của store.' };
  return fhrSerial(async () => {
    const { fhrAuto = {} } = await chrome.storage.local.get('fhrAuto'); const now = Date.now(); fhrAuto.tabs ||= {};
    for (const [t, v] of Object.entries(fhrAuto.tabs)) if (now - v.at > FHR_TAB_TTL * 2) { delete fhrAuto.tabs[t]; chrome.tabs.remove(Number(t)).catch(() => {}); }
    if (Object.values(fhrAuto.tabs).some(v => v.shopId === shopId)) return { ok: true, already: true };
    const st = fhrAuto.status?.[shopId], last = Date.parse(st?.at || 0) || 0;
    if (!opt.force && st && now - last < (st.state === 'done' ? FHR_GAP_OK : FHR_GAP_FAIL)) return { ok: true, skipped: true, status: st };
    const tab = await chrome.tabs.create({ url: FHR_PAGE_URL, active: false });
    fhrAuto.tabs[tab.id] = { shopId, at: now, username: String(opt.username || ''), reason: opt.reason || 'manual' };
    await fhrSetStatus_(fhrAuto, shopId, 'reading', 'Đang tự đọc trang FHR tính lại ở tab nền…');
    await chrome.storage.local.set({ fhrAuto });
    setTimeout(() => fhrAutoDone_(tab.id, 'timeout', 'Trang tính lại không hiện số trong 90 giây (chưa đăng nhập shopee.vn hoặc Shopee chưa cập nhật).').catch(() => {}), FHR_TAB_TTL);
    return { ok: true, opened: true };
  });
}
/* Kết thúc 1 tab tự mở: ghi trạng thái theo shop, đóng tab. Gọi nhiều lần an toàn (lần đầu thắng). */
function fhrAutoDone_(tabId, state, message = '', extra = {}) {
  return fhrSerial(async () => {
    const { fhrAuto = {} } = await chrome.storage.local.get('fhrAuto'); const e = fhrAuto.tabs?.[tabId]; if (!e) return false;
    delete fhrAuto.tabs[tabId]; await fhrSetStatus_(fhrAuto, e.shopId, state, message, extra);
    await chrome.storage.local.set({ fhrAuto }); chrome.tabs.remove(Number(tabId)).catch(() => {}); return true;
  });
}
/* Lưu lên Performance phần FHR tính lại của shop đang có trong phiên (state.run). */
function fhrQueueUpload_(shopId) {
  if (typeof mutate !== 'function') return Promise.resolve();
  return mutate(async () => {
    const { state: s } = await read(); const r = s.run;
    if (!r || String(r.platform || '').toUpperCase() !== 'SHOPEE' || String(r.shopId) !== String(shopId) || r.phase !== 'done' || !r.capturedAt) return;
    const mainPending = (s.outbox || []).some(j => j.run.id === r.id && !j.fhrOnly);
    if (r.syncStatus !== 'ĐÃ LƯU' && !mainPending) { if (await mergeFhrRecalc_(s)) await save(s); return; } // đi cùng lượt gửi sắp tới
    const before = new Set((s.daily?.[r.id] || []).filter(d => d.metric === FHR_RECALC_METRIC).map(d => `${d.date}|${d.value}`));
    if (!(await mergeFhrRecalc_(s))) return;
    const rows = (s.daily[r.id] || []).filter(d => d.metric === FHR_RECALC_METRIC && !before.has(`${d.date}|${d.value}`)); if (!rows.length) return;
    s.outbox.push({ id: `${r.id}-r${r.revision || 1}-fhr${Date.now().toString(36)}`, run: JSON.parse(JSON.stringify(r)), chunks: [[]], next: 1, finalized: true, dailyChunks: [rows], dailyNext: 0, fhrOnly: true, createdAt: new Date().toISOString() });
    note(s, `FHR tính lại ${r.channel_code}: ${rows.length} tuần mới, đang lưu lên Performance.`); await save(s);
    if (!mainPending) await flushOutbox(s);
  });
}
chrome.tabs.onUpdated.addListener((tabId, ch) => {
  if (!ch.url) return;
  if (/shopee\.vn\/verify\//i.test(ch.url)) fhrAutoDone_(tabId, 'blocked', 'Shopee đang yêu cầu xác minh truy cập (chống bot). Tool sẽ tự thử lại sau 30 phút; hoặc mở trang tay một lần.').catch(() => {});
  else if (/shopee\.vn\/(buyer\/)?login|accounts\.shopee/i.test(ch.url)) fhrAutoDone_(tabId, 'login', 'shopee.vn chưa đăng nhập. Đăng nhập shopee.vn bằng tài khoản shop rồi bấm Đọc lại ngay.').catch(() => {});
});
chrome.tabs.onRemoved.addListener(tabId => { fhrAutoDone_(tabId, 'closed', 'Tab tính lại bị đóng trước khi đọc xong.').catch(() => {}); });
chrome.alarms.onAlarm.addListener(a => { if (a.name !== 'op-retry') return; fhrSerial(async () => {
  const { fhrAuto = {} } = await chrome.storage.local.get('fhrAuto'); const now = Date.now();
  return Object.entries(fhrAuto.tabs || {}).filter(([, v]) => now - v.at > FHR_TAB_TTL).map(([t]) => Number(t));
}).then(ids => ids.forEach(t => fhrAutoDone_(t, 'timeout', 'Trang tính lại không hiện số kịp (tab đã đóng).').catch(() => {}))).catch(() => {}); });
chrome.runtime.onMessage.addListener((m, sender, respond) => {
  if (sender.id !== chrome.runtime.id || m?.type !== 'FHR_AUTO_READ' || String(sender.url || '').indexOf(chrome.runtime.getURL('')) !== 0) return false;
  (async () => { const { state } = await chrome.storage.local.get('state'); const r = state?.run; const shopId = String(m.shopId || (String(r?.platform || '').toUpperCase() === 'SHOPEE' ? r.shopId : '') || '');
    return fhrAutoOpen(shopId, { force: true, reason: 'manual' }); })().then(respond, e => respond({ ok: false, error: e.message }));
  return true;
});
