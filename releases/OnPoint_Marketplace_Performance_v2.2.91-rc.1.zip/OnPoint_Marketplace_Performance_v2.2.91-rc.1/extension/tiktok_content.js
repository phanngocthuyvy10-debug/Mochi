(function () {
  if (window.__OP_TTS_TICKET_AUTOFILL__) return;
  window.__OP_TTS_TICKET_AUTOFILL__ = true;

  let SUBJECT_PATH = [
    'Thực hiện đơn hàng & Hậu cần (3PL/4PL)',
    'Đón và trả hàng (4PL)',
    'Nhà cung cấp dịch vụ hậu cần chậm trễ nhận hàng'
  ];
  let SUBJECT_PATH_ALIASES = [
    [SUBJECT_PATH[0]],
    [SUBJECT_PATH[1]],
    [
      SUBJECT_PATH[2],
      'Nhà cung cấp dịch vụ hậu cần chậm trễ việc lấy hàng'
    ]
  ];
  let SUBJECT_FULL_TEXT = SUBJECT_PATH.join(' / ');
  function configureSubject(draft) {
    SUBJECT_PATH = draft?.mode === 'claim' && ['FDR','LDR'].includes(draft.claim?.metric)
      ? ['Tình trạng cửa hàng','Xếp hạng Cửa hàng','Điều chỉnh Xếp hạng Cửa hàng']
      : draft?.issueType === globalThis.OPHandover?.ISSUE ? [...OPHandover.SUBJECT]
      : ['Thực hiện đơn hàng & Hậu cần (3PL/4PL)','Đón và trả hàng (4PL)','Nhà cung cấp dịch vụ hậu cần chậm trễ nhận hàng'];
    SUBJECT_PATH_ALIASES = SUBJECT_PATH.map(step => [step]);
    // v2.2.20 — ticket đòi hàng mang sẵn chủ đề theo giai đoạn (Cấp 1 › Cấp 2 › Cấp 3).
    if (draft?.issueType === 'cancel_return' && Array.isArray(draft.subjectPath) && draft.subjectPath.length === 3) {
      SUBJECT_PATH = [...draft.subjectPath];
      SUBJECT_PATH_ALIASES = SUBJECT_PATH.map((step, index) => Array.isArray(draft.subjectAliases?.[index]) ? [...draft.subjectAliases[index]] : [step]);
    }
    SUBJECT_FULL_TEXT = SUBJECT_PATH.join(' / ');
  }
  const SUBJECT_TRIGGER_TEXTS = [
    'Vui lòng chọn một chủ đề',
    'Chọn một chủ đề'
  ];
  const MAIN_SUBMIT_TEXTS = ['Gửi', 'Send'];
  const CONFIRM_ACTION_TEXTS = ['Tiếp theo', 'Next'];
  const SUBMIT_RETRY_LIMIT = 5;
  const EXTENSION_BUILD = 'v0.11.99 (v2.2.90)';
  const TIKTOK_POLL_MS = 100;
  const STRICT_UPLOAD_STABLE_MS = 800;
  /* v0.11.13 — 2800ms là nguyên nhân "chỉ up được 1 hình".
   * Ô "Đính kèm tệp" là KHÔNG BẮT BUỘC nên nút Gửi bật ngay từ giây 0 →
   * submitReady = true từ đầu → nhánh thoát hiểm bên dưới bắn đúng mốc 2.8s,
   * kệ TikTok mới upload xong mấy file. Nâng lên 12s và siết thêm điều kiện. */
  const REVERSE_READY_FALLBACK_MS = 12000;   // trần chờ tuyệt đối
  /* Số card đính kèm đứng yên bấy lâu ⇒ coi như TikTok nhận xong, bấm Gửi. */
  const UPLOAD_SETTLE_MS = 3000;
  /* Trần tổng cho CẢ khâu đính kèm (đẩy theo đợt + chờ nút Gửi). */
  const UPLOAD_TOTAL_BUDGET_MS = 30000;
  /* Chẩn đoán vòng cuối, để báo đúng "chỉ nhận X/Y file" thay vì nói chung chung. */
  let lastUploadDiagnostics = null;
  const FINAL_SUBMIT_GUARD_MS = 1500;
  const FINAL_SUBMIT_FALLBACK_MS = 2500;
  const FREQUENT_TOAST_PATTERNS = [
    'ban dang thu qua thuong xuyen',
    'qua thuong xuyen',
    'thu lai sau',
    'too frequent',
    'too many requests',
    'please try again later',
    '操作太频繁',
    '请稍后再试'
  ];
  const UPLOAD_FAILURE_PATTERNS = [
    'tai len khong thanh cong',
    'tai khong thanh cong',
    'khong tai duoc',
    'tep khong hop le',
    'file khong hop le',
    'upload failed',
    'failed to upload',
    'could not upload'
  ];
  let subjectSelectionFailure = '';
  let subjectTimings = '';

  // v2.2.9 — tab ở nền: OPWake.sleep (lib/op-keepalive.js) giữ đúng nhịp thay vì bị Chrome dồn về 1 giây.
  const sleep = (ms) => globalThis.OPWake ? OPWake.sleep(ms) : new Promise((resolve) => setTimeout(resolve, ms));
  const norm = (value) => String(value ?? '')
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[đĐ]/g, 'd')
    .trim().toLowerCase().replace(/\s+/g, ' ');

  function runtimeMessage(message) {
    return new Promise((resolve, reject) => {
      if (!chrome?.runtime?.sendMessage) {
        reject(new Error('Runtime messaging chưa sẵn sàng.'));
        return;
      }
      chrome.runtime.sendMessage(message, (response) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        resolve(response);
      });
    });
  }

  let activeTicketCapture = null;

  async function loadTicketContext() {
    try {
      const context = await runtimeMessage({ type: 'GET_TICKET_TAB_PAYLOAD' });
      // Background trả lời được ⇒ cờ tabScoped là ĐÁNG TIN.
      if (context?.ok && (context.draft || context.savedTicket)) return { ...context, tabScopeKnown: true };
    } catch (_) {
      // A v0.10.20 tab can still be open while the extension reloads. Fall
      // back to the single TikTok draft stored by the side panel.
    }
    return new Promise((resolve) => {
      chrome.storage.local.get(
        ['currentDraft', 'currentAttachments'],
        ({ currentDraft, currentAttachments }) => resolve({
          ok: Boolean(currentDraft),
          tabScoped: false,
          // Không hỏi được background ⇒ KHÔNG biết tab này của ai ⇒ đừng chặn.
          tabScopeKnown: false,
          draft: currentDraft || null,
          attachments: Array.isArray(currentAttachments) ? currentAttachments : []
        })
      );
    });
  }

  function subjectStepVariants(step) {
    const index = SUBJECT_PATH.findIndex((item) => norm(item) === norm(step));
    return index >= 0 ? SUBJECT_PATH_ALIASES[index] : [step];
  }

  /* ---------------------------------------------------------------------------
   * v0.11.14 — TĂNG TỐC CHỌN CHỦ ĐỀ. Không đổi một vị từ nào.
   *
   * Đo trên DOM 21k node: mỗi lượt quét tốn 187–325 ms, vì các hàm quét đều
   * chạy `querySelectorAll('…,div,span')` rồi `.filter(visible)` — tức là
   * getComputedStyle + getBoundingClientRect trên HÀNG CHỤC NGÀN node, ép
   * trình duyệt tính lại layout mỗi node một lần. Chờ nhanh cỡ nào cũng vô
   * nghĩa khi một lần "nhìn" đã mất 1/4 giây.
   *
   * Hai đòn bẩy, cả hai đều GIỮ NGUYÊN tập kết quả:
   *
   *  1. Nhớ tạm `visible()` trong đúng MỘT lượt quét đồng bộ. JS đơn luồng nên
   *     DOM không thể đổi giữa chừng → kết quả nhớ tạm luôn đúng.
   *  2. Loại thô bằng chữ TRƯỚC, đo hình học SAU. `textContent` không ép
   *     layout; sau khi bỏ hết khoảng trắng nó là tập cha của `innerText`, nên
   *     "không chứa" ⇒ chắc chắn vị từ gốc cũng trượt ⇒ loại sớm là an toàn.
   * ------------------------------------------------------------------------ */
  let visibleCache = null;

  const visible = (el) => {
    if (!el || !(el instanceof Element)) return false;
    if (visibleCache) {
      const cached = visibleCache.get(el);
      if (cached !== undefined) return cached;
    }
    const style = getComputedStyle(el);
    const rect = el.getBoundingClientRect();
    const result = style.display !== 'none' && style.visibility !== 'hidden' && Number(style.opacity || 1) > 0 && rect.width > 1 && rect.height > 1;
    if (visibleCache) visibleCache.set(el, result);
    return result;
  };

  /** Gom một lượt quét ĐỒNG BỘ vào chung một cache visible(). */
  function scanScope(fn) {
    if (visibleCache) return fn();
    visibleCache = new WeakMap();
    try {
      return fn();
    } finally {
      visibleCache = null;
    }
  }

  /** norm() rồi bỏ sạch khoảng trắng — để textContent và innerText so được nhau. */
  const squash = (value) => norm(value).replace(/\s+/g, '');

  /** Node CÓ THỂ mang một trong các chuỗi cần tìm hay không — chỉ đọc chữ, không đo. */
  function mayCarryText(el, needles) {
    if (!needles.length) return true;
    const text = el.textContent;
    if (text) {
      const hay = squash(text);
      for (const needle of needles) if (needle && hay.includes(needle)) return true;
    }
    const read = el.getAttribute;
    if (!read) return false;
    let extra = '';
    for (const name of ['aria-label', 'title', 'placeholder', 'aria-valuetext']) {
      const value = read.call(el, name);
      if (value) extra += ` ${value}`;
    }
    if (typeof el.value === 'string' && el.value) extra += ` ${el.value}`;
    if (!extra) return false;
    const hayAttr = squash(extra);
    for (const needle of needles) if (needle && hayAttr.includes(needle)) return true;
    return false;
  }

  /** querySelectorAll + loại thô bằng chữ. Trả về mảng đã hẹp lại rất nhiều. */
  function coarseCandidates(selector, needles) {
    const out = [];
    const nodes = document.querySelectorAll(selector);
    for (const el of nodes) if (mayCarryText(el, needles)) out.push(el);
    return out;
  }

  const setNativeValue = (el, value) => {
    const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
    const previousValue = el.value;
    setter ? setter.call(el, value) : (el.value = value);
    if (el._valueTracker) el._valueTracker.setValue(previousValue);
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.blur();
  };

  function textOf(el) {
    return `${el.getAttribute?.('placeholder') || ''} ${el.getAttribute?.('aria-label') || ''} ${el.closest?.('label')?.innerText || ''} ${el.parentElement?.innerText || ''}`.toLowerCase();
  }

  function elementText(el) {
    return el?.innerText ||
      el?.textContent ||
      el?.getAttribute?.('aria-label') ||
      el?.getAttribute?.('title') ||
      el?.value ||
      el?.getAttribute?.('placeholder') ||
      '';
  }

  function isTooltip(el) {
    if (!el) return false;
    return Boolean(
      el.closest?.('[role="tooltip"]') ||
      el.getAttribute?.('role') === 'tooltip' ||
      norm(typeof el.className === 'string' ? el.className : '').includes('tooltip')
    );
  }

  function classText(el) {
    return norm(typeof el?.className === 'string' ? el.className : el?.getAttribute?.('class') || '');
  }

  function elementValues(el) {
    return [
      elementText(el),
      el?.getAttribute?.('placeholder'),
      el?.getAttribute?.('aria-label'),
      el?.getAttribute?.('title'),
      el?.value
    ].map(norm).filter(Boolean);
  }

  function popupLike(el) {
    if (!el) return false;
    const role = norm(el.getAttribute?.('role'));
    return ['listbox', 'menu', 'tree'].includes(role) ||
      /(cascader[^ ]*(menu|popup|panel|dropdown)|(dropdown|popover|popup|menu|option-list|select-panel))/.test(classText(el));
  }

  function insideVisiblePopup(el) {
    for (let current = el?.parentElement, depth = 0; current && depth < 12; current = current.parentElement, depth++) {
      if (visible(current) && popupLike(current)) return true;
    }
    return false;
  }

  function nearestClickable(el) {
    let fallback = el;
    for (let current = el, depth = 0; current && depth < 7 && current !== document.body; current = current.parentElement, depth++) {
      if (!visible(current)) continue;
      const semantic = current.matches?.(
        'button,[role="button"],[role="option"],[role="menuitem"],[role="treeitem"],li,[tabindex],[aria-haspopup]'
      );
      const styled = /(option|item|row|node|category|select|cascader|trigger)/.test(classText(current)) ||
        getComputedStyle(current).cursor === 'pointer';
      if (semantic || styled) return current;
      fallback = current;
    }
    return fallback || el;
  }

  function fireHover(el) {
    if (!el) return false;
    const pointerEvent = typeof PointerEvent === 'function' ? PointerEvent : MouseEvent;
    el.dispatchEvent(new pointerEvent('pointerover', { bubbles: true, cancelable: true, view: window }));
    el.dispatchEvent(new pointerEvent('pointerenter', { bubbles: false, cancelable: true, view: window }));
    el.dispatchEvent(new MouseEvent('mouseover', { bubbles: true, cancelable: true, view: window }));
    el.dispatchEvent(new MouseEvent('mouseenter', { bubbles: false, cancelable: true, view: window }));
    el.dispatchEvent(new pointerEvent('pointermove', { bubbles: true, cancelable: true, view: window }));
    el.dispatchEvent(new MouseEvent('mousemove', { bubbles: true, cancelable: true, view: window }));
    return true;
  }

  function fireClick(el, useExactElement = false) {
    if (!el) return false;
    const target = useExactElement ? el : nearestClickable(el);
    try { target.scrollIntoView({ block: 'center', inline: 'nearest' }); } catch (_) {}
    fireHover(target);
    const pointerEvent = typeof PointerEvent === 'function' ? PointerEvent : MouseEvent;
    target.dispatchEvent(new pointerEvent('pointerdown', {
      bubbles: true, cancelable: true, view: window, button: 0
    }));
    target.dispatchEvent(new MouseEvent('mousedown', {
      bubbles: true, cancelable: true, view: window, button: 0
    }));
    try { target.focus?.({ preventScroll: true }); } catch (_) { target.focus?.(); }
    target.dispatchEvent(new pointerEvent('pointerup', {
      bubbles: true, cancelable: true, view: window, button: 0
    }));
    target.dispatchEvent(new MouseEvent('mouseup', {
      bubbles: true, cancelable: true, view: window, button: 0
    }));
    if (typeof target.click === 'function') target.click();
    else target.dispatchEvent(new MouseEvent('click', {
      bubbles: true, cancelable: true, view: window, button: 0
    }));
    return true;
  }

  /* v0.11.14 — CHỜ THEO PHẢN ỨNG, không chờ theo đồng hồ.
   *
   * Bản cũ: kiểm tra → ngủ nguyên `interval` (120–160 ms) → kiểm tra lại. React
   * dựng xong tầng cascader ở mili-giây thứ 5 của giấc ngủ thì vẫn phải nằm chờ
   * hết. Nhân với 5 bước của luồng chọn chủ đề là mất trắng vài trăm ms.
   *
   * Bản mới: vẫn ĐÚNG vị từ đó, ĐÚNG timeout đó, chỉ khác ở chỗ MutationObserver
   * đánh thức ngay khi DOM đổi. Có sàn 50 ms giữa hai lần kiểm tra để trang
   * TikTok (vốn re-render liên tục) không kéo CPU lên, và vẫn giữ nhịp `interval`
   * làm lưới an toàn cho những thay đổi observer không nhìn thấy.
   */
  const WAIT_MIN_GAP_MS = 50;
  /* Lượt 1 lướt nhanh mọi ứng viên, lượt 2 mới trả đủ ngân sách gốc. */
  const SUBJECT_TRY_PASSES = [0.15, 1];

  function waitFor(fn, timeout = 10000, interval = TIKTOK_POLL_MS) {
    const started = Date.now();
    let result = null;
    try { result = fn(); } catch (_) { result = null; }
    if (result) return Promise.resolve(result);

    return new Promise((resolve) => {
      let done = false;
      let scheduled = false;
      let lastCheckAt = Date.now();
      let timer = null;
      let observer = null;

      const finish = (value) => {
        if (done) return;
        done = true;
        if (timer) clearTimeout(timer);
        if (observer) { try { observer.disconnect(); } catch (_) {} }
        resolve(value);
      };

      const check = () => {
        if (done) return;
        lastCheckAt = Date.now();
        let value = null;
        try { value = fn(); } catch (_) { value = null; }
        if (value) { finish(value); return; }
        if (Date.now() - started >= timeout) finish(null);
      };

      const schedule = () => {
        if (done || scheduled) return;
        scheduled = true;
        const wait = Math.max(0, WAIT_MIN_GAP_MS - (Date.now() - lastCheckAt));
        setTimeout(() => { scheduled = false; check(); }, wait);
      };

      try {
        observer = new MutationObserver(schedule);
        observer.observe(document.documentElement, {
          childList: true, subtree: true, attributes: true, characterData: true
        });
      } catch (_) { observer = null; }

      const tick = () => {
        if (done) return;
        check();
        if (!done) timer = setTimeout(tick, interval);
      };
      timer = setTimeout(tick, interval);
    });
  }

  function subjectAlreadySelected() {
    const path = SUBJECT_PATH.map(norm);
    const finalSteps = subjectStepVariants(SUBJECT_PATH[SUBJECT_PATH.length - 1]).map(norm);
    const wantedPaths = subjectStepVariants(SUBJECT_PATH[SUBJECT_PATH.length - 1])
      .map((lastStep) => norm([...SUBJECT_PATH.slice(0, -1), lastStep].join(' / ')));
    // Cả 3 nhánh của .some() bên dưới đều đòi value CHỨA một finalStep, nên lọc
    // thô theo finalSteps không thể làm mất bất kỳ node nào từng khớp.
    return scanScope(() => coarseCandidates(
      'input,[role="combobox"],button,[role="button"],[aria-haspopup],[tabindex],div,span',
      finalSteps.map(squash)
    )
      .filter(visible)
      .filter((el) => !isTooltip(el) && !insideVisiblePopup(el))
      .filter((el) => {
        const rect = el.getBoundingClientRect();
        return rect.width >= 90 && rect.height >= 20 && rect.height <= 110;
      })
      .some((el) => {
        const value = norm([
          elementText(el),
          el.getAttribute?.('aria-valuetext'),
          el.getAttribute?.('aria-label'),
          el.getAttribute?.('title'),
          el.value
        ].filter(Boolean).join(' '));
        const stillPlaceholder = SUBJECT_TRIGGER_TEXTS.some((text) => value.includes(norm(text)));
        return !stillPlaceholder && (
          finalSteps.some((finalStep) => value === finalStep || value.includes(finalStep)) ||
          wantedPaths.includes(value) ||
          (path.slice(0, -1).every((part) => value.includes(part)) &&
            finalSteps.some((finalStep) => value.includes(finalStep)))
        );
      }));
  }

  function subjectLabels() {
    return coarseCandidates('label,div,span,p', ['chude'])
      .filter(visible)
      .filter((el) => norm(el.innerText || el.textContent || '').replace(/^\*\s*/, '') === 'chu de');
  }

  function subjectTriggerCandidates() {
    return scanScope(subjectTriggerCandidatesInner);
  }

  function subjectTriggerCandidatesInner() {
    const triggerTexts = SUBJECT_TRIGGER_TEXTS.map(norm);
    const scored = new Map();
    const add = (el, baseScore = 0) => {
      if (!el || !visible(el) || isTooltip(el) || el === document.body || el === document.documentElement) return;
      const rect = el.getBoundingClientRect();
      if (rect.width < 90 || rect.height < 20 || rect.height > 110) return;

      const ownValues = elementValues(el);
      let score = baseScore;
      if (el.matches?.('[role="combobox"]')) score += 420;
      if (el.matches?.('[aria-haspopup]')) score += 360;
      if (el.matches?.('input')) score += 330;
      if (el.matches?.('button,[role="button"]')) score += 300;
      if (el.hasAttribute?.('tabindex')) score += 160;
      if (/(select|cascader|picker|trigger|selector)/.test(classText(el))) score += 280;
      if (getComputedStyle(el).cursor === 'pointer') score += 120;
      if (ownValues.some((value) => triggerTexts.includes(value))) score += 260;
      else if (ownValues.some((value) => triggerTexts.some((text) => value.includes(text)))) score += 120;
      if (rect.height >= 30 && rect.height <= 68) score += 70;
      if (rect.width >= 250) score += 40;
      if (el.matches?.('span,p')) score -= 180;
      const previous = scored.get(el);
      if (previous === undefined || score > previous) scored.set(el, score);
    };

    const seeds = coarseCandidates(
      'input,button,[role="button"],[role="combobox"],[aria-haspopup],[tabindex],span,div,p',
      triggerTexts.map(squash)
    )
      .filter(visible)
      .filter((el) => !isTooltip(el))
      .filter((el) => elementValues(el).some((value) => triggerTexts.includes(value)));

    for (const seed of seeds) {
      for (let current = seed, depth = 0; current && depth < 7 && current !== document.body; current = current.parentElement, depth++) {
        add(current, Math.max(0, 190 - depth * 20));
      }
    }

    for (const label of subjectLabels()) {
      for (let scope = label.parentElement, depth = 0; scope && depth < 5 && scope !== document.body; scope = scope.parentElement, depth++) {
        const controls = scope.querySelectorAll(
          'input,button,[role="button"],[role="combobox"],[aria-haspopup],[tabindex],div[class*="select"],div[class*="Select"],div[class*="cascader"],div[class*="Cascader"],div[class*="picker"],div[class*="Picker"]'
        );
        for (const control of controls) {
          if (control === label || control.contains(label)) continue;
          add(control, Math.max(0, 130 - depth * 18));
        }
      }
    }

    return [...scored.entries()]
      .sort((a, b) => b[1] - a[1])
      .map(([el]) => el);
  }

  function subjectOptionText(value) {
    return norm(value)
      .replace(/[›»>⌄⌃→←]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function subjectOptionTargets(step) {
    return scanScope(() => subjectOptionTargetsInner(step));
  }

  function subjectOptionTargetsInner(step) {
    const wanted = norm(step);
    const wantedValues = subjectStepVariants(step).map(norm);
    const seeds = coarseCandidates(
      '[role="option"],[role="menuitem"],[role="treeitem"],li,button,[tabindex],span,div,p',
      wantedValues.map(squash)
    )
      .filter(visible)
      .filter((el) => !isTooltip(el))
      .filter((el) => wantedValues.includes(subjectOptionText(elementText(el))));
    const scored = new Map();

    const add = (node, seed, depth) => {
      if (!node || !visible(node) || isTooltip(node) || node === document.body || node === document.documentElement) return;
      const rect = node.getBoundingClientRect();
      if (rect.width < 55 || rect.height < 20 || rect.height > 100) return;
      if (getComputedStyle(node).pointerEvents === 'none') return;
      const semanticOption = node.matches?.('[role="option"],[role="menuitem"],[role="treeitem"],li');
      const optionStyled = /(cascader|menu|option|item|category|row|node)/.test(classText(node));
      if (!insideVisiblePopup(node) && !semanticOption && !optionStyled) return;
      const value = subjectOptionText(elementText(node));
      const matchedWanted = wantedValues.find((candidate) =>
        value === candidate || (value.includes(candidate) && value.length <= candidate.length + 8)
      );
      if (!matchedWanted) return;

      let score = 0;
      if (value === wanted) score += 120;
      if (node.matches?.('button,[role="option"],[role="menuitem"],[role="treeitem"],li,[tabindex]')) score += 330;
      if (optionStyled) score += 260;
      if (getComputedStyle(node).cursor === 'pointer') score += 190;
      if (insideVisiblePopup(node)) score += 180;
      if (node.querySelector?.('svg,[class*="arrow"],[class*="Arrow"],[class*="chevron"],[class*="Chevron"]')) score += 80;
      if (rect.height >= 28 && rect.height <= 62) score += 60;
      if (node.children.length > 0) score += 35;
      if (node === seed) score += 20;
      if (node.matches?.('span,p')) score -= 220;
      score += Math.min(depth, 5) * 8;
      const previous = scored.get(node);
      if (previous === undefined || score > previous) scored.set(node, score);
    };

    for (const seed of seeds) {
      for (let current = seed, depth = 0; current && depth < 9 && current !== document.body; current = current.parentElement, depth++) {
        add(current, seed, depth);
      }
    }

    return [...scored.entries()]
      .sort((a, b) => b[1] - a[1])
      .map(([node]) => node);
  }

  function findSubjectOption(step) {
    return subjectOptionTargets(step)[0] || null;
  }

  function subjectPopupVisible() {
    return scanScope(() => {
      const firstSteps = subjectStepVariants(SUBJECT_PATH[0]).map(norm);
      // popupLike/isTooltip chỉ đọc role + class (rẻ), nên đẩy lên trước
      // visible(). Cả ba đều là vị từ thuần AND nên đảo thứ tự không đổi kết quả.
      const needles = firstSteps.map(squash);
      const popupFound = [...document.querySelectorAll('[role="listbox"],[role="menu"],[role="tree"],div')]
        .filter((el) => !isTooltip(el) && popupLike(el))
        .filter((el) => mayCarryText(el, needles))
        .filter(visible)
        .some((el) => firstSteps.some((firstStep) => norm(elementText(el)).includes(firstStep)));
      if (popupFound) return true;
      return subjectOptionTargets(SUBJECT_PATH[0]).some((el) =>
        el.matches?.('[role="option"],[role="menuitem"],[role="treeitem"]') || insideVisiblePopup(el)
      );
    });
  }

  function pressOpenKey(el, key) {
    if (!el) return;
    try { el.focus?.({ preventScroll: true }); } catch (_) { el.focus?.(); }
    const code = key === ' ' ? 'Space' : key;
    el.dispatchEvent(new KeyboardEvent('keydown', { key, code, bubbles: true, cancelable: true }));
    el.dispatchEvent(new KeyboardEvent('keyup', { key, code, bubbles: true, cancelable: true }));
  }

  async function openSubjectMenu() {
    if (subjectPopupVisible()) return true;
    const candidates = await waitFor(() => {
      const items = subjectTriggerCandidates();
      return items.length ? items : null;
    }, 12000, 100);
    if (!candidates) return false;

    /* v0.11.15 — THANG HAI LƯỢT.
     *
     * Bản gốc: mỗi ứng viên trượt tốn 2200+250+1800+1400+1400 ≈ 7 GIÂY. Ứng
     * viên đúng thường không phải cái đầu bảng (điểm cao nhất hay là div bọc
     * ngoài, chỉ input bên trong mới ăn click), nên thực tế phải trả 7–21 giây
     * chỉ để MỞ được menu. Đó mới là chỗ chậm, không phải nhịp chờ.
     *
     * Bản mới: lượt 1 lướt nhanh qua TẤT CẢ ứng viên (ngân sách ×0.15) để tìm
     * cái nào phản hồi; ai cũng im thì lượt 2 chạy lại NGUYÊN ngân sách gốc.
     * Cùng danh sách, cùng thứ tự, cùng thao tác — chỉ khác lịch chờ. Trường
     * hợp xấu nhất chậm hơn bản gốc đúng 15%, trường hợp thường nhanh hơn ~6×.
     */
    for (const scale of SUBJECT_TRY_PASSES) {
      const budget = (ms) => Math.max(220, Math.round(ms * scale));
      for (const candidate of candidates.slice(0, 8)) {
        fireClick(candidate, true);
        if (await waitFor(subjectPopupVisible, budget(2200), 120)) return true;

        fireHover(candidate);
        await sleep(Math.max(60, Math.round(250 * scale)));
        try { HTMLElement.prototype.click.call(candidate); } catch (_) {}
        if (await waitFor(subjectPopupVisible, budget(1800), 120)) return true;

        pressOpenKey(candidate, 'ArrowDown');
        if (await waitFor(subjectPopupVisible, budget(1400), 120)) return true;
        pressOpenKey(candidate, ' ');
        if (await waitFor(subjectPopupVisible, budget(1400), 120)) return true;
      }
    }
    return false;
  }

  function subjectScrollContainers() {
    return [...document.querySelectorAll('[role="menu"],[role="listbox"],[role="tree"],ul,div')]
      .filter(visible)
      .filter((el) => !isTooltip(el))
      .filter((el) => {
        const rect = el.getBoundingClientRect();
        const style = getComputedStyle(el);
        return el.scrollHeight > el.clientHeight + 6 &&
          rect.width >= 100 && rect.width <= 900 &&
          rect.height >= 70 && rect.height <= 620 &&
          (/(auto|scroll)/.test(style.overflowY) || popupLike(el));
      });
  }

  async function findSubjectOptionWithScroll(step, timeout = 10000) {
    const started = Date.now();
    let pass = 0;
    while (Date.now() - started < timeout) {
      const option = findSubjectOption(step);
      if (option) return option;
      for (const container of subjectScrollContainers()) {
        const max = Math.max(0, container.scrollHeight - container.clientHeight);
        if (!max) continue;
        const next = Math.min(max, container.scrollTop + Math.max(90, Math.floor(container.clientHeight * 0.72)));
        container.scrollTop = next === container.scrollTop && pass > 0 ? 0 : next;
        container.dispatchEvent(new Event('scroll', { bubbles: true }));
      }
      pass += 1;
      await sleep(120);
    }
    return null;
  }

  async function activateSubjectBranch(step, nextStep) {
    const targets = await waitFor(() => {
      const items = subjectOptionTargets(step);
      return items.length ? items : null;
    }, 10000, 160);
    if (!targets) {
      subjectSelectionFailure = `không thấy tầng "${step}"`;
      return false;
    }

    for (const scale of SUBJECT_TRY_PASSES) {
      const budget = (ms) => Math.max(220, Math.round(ms * scale));
      for (const target of targets.slice(0, 8)) {
        try { target.scrollIntoView({ block: 'center', inline: 'nearest' }); } catch (_) {}
        fireHover(target);
        if (await waitFor(() => findSubjectOption(nextStep), 420, 70)) return true;

        fireClick(target, true);
        if (await waitFor(() => findSubjectOption(nextStep), budget(2600), 100)) return true;

        const wrapper = nearestClickable(target);
        if (wrapper !== target) {
          fireHover(wrapper);
          fireClick(wrapper, true);
          if (await waitFor(() => findSubjectOption(nextStep), budget(2200), 100)) return true;
        }
      }
    }
    subjectSelectionFailure = `đã thấy "${step}" nhưng tầng "${nextStep}" chưa mở`;
    return false;
  }

  async function chooseSubjectLeaf(step) {
    const targets = await waitFor(() => {
      const items = subjectOptionTargets(step);
      return items.length ? items : null;
    }, 10000, 160);
    if (!targets) {
      subjectSelectionFailure = `không thấy tầng cuối "${step}"`;
      return false;
    }

    for (const scale of SUBJECT_TRY_PASSES) {
      const budget = (ms) => Math.max(260, Math.round(ms * scale));
      for (const target of targets.slice(0, 8)) {
        try { target.scrollIntoView({ block: 'center', inline: 'nearest' }); } catch (_) {}
        fireHover(target);
        fireClick(target, true);
        if (await waitFor(subjectAlreadySelected, budget(3200), 120)) return true;

        const wrapper = nearestClickable(target);
        if (wrapper !== target) {
          fireClick(wrapper, true);
          if (await waitFor(subjectAlreadySelected, budget(2600), 120)) return true;
        }
      }
    }
    subjectSelectionFailure = `đã click "${step}" nhưng form chưa ghi nhận`;
    return false;
  }

  function closeSubjectMenu() {
    document.dispatchEvent(new KeyboardEvent('keydown', {
      key: 'Escape', code: 'Escape', bubbles: true, cancelable: true
    }));
    document.dispatchEvent(new KeyboardEvent('keyup', {
      key: 'Escape', code: 'Escape', bubbles: true, cancelable: true
    }));
  }

  /* v0.11.15 — ĐO NGAY TRÊN MÁY CHỊ.
   * Mọi con số tốc độ trước giờ đều đo trên DOM giả lập của em. Từ bản này,
   * mỗi lần raise sẽ tự in ra thời gian TỪNG CHẶNG lên Side Panel, để lần sau
   * nhìn là biết chặng nào ăn thời gian — không phải đoán nữa. */
  /* v2.2.89 — ĐƯỜNG NHANH CHỌN CHỦ ĐỀ (đo trên trang thật 02/11: 0,8 giây cho cả 3 tầng, cách dò cũ mất nhiều giây).
     Ô Chủ đề là Cascader ".p-cascader[role=combobox]"; sự kiện click/hover nằm ở nhãn ".p-cascader-list-item-label"
     (không ở dòng ngoài) → bấm thẳng nhãn đúng chữ của từng tầng, chờ cột kế hiện bằng MutationObserver.
     Không khớp cấu trúc (TikTok đổi giao diện) → trả false để chạy cách dò cũ, không mất gì. */
  async function fastCascaderSelect() {
    const box = await waitFor(() => [...document.querySelectorAll('.p-cascader[role="combobox"]')].find(visible) || null, 12000, 60);
    if (!box) return false;
    const lists = () => [...document.querySelectorAll('.p-cascader-popup .p-cascader-list')].filter(visible);
    const labelOf = (col, variants) => [...(lists()[col]?.querySelectorAll('.p-cascader-list-item-label') || [])]
      .find(el => variants.includes(norm(el.textContent || '')));
    if (!lists().length) {
      (box.querySelector('.p-cascader-view') || box).click();
      if (!await waitFor(() => lists().length > 0, 2500, 40)) return false;
    }
    for (let level = 0; level < SUBJECT_PATH.length; level++) {
      const variants = subjectStepVariants(SUBJECT_PATH[level]).map(norm);
      const label = await waitFor(() => labelOf(level, variants) || null, 3000, 40);
      if (!label) return false;
      try { label.scrollIntoView({ block: 'nearest' }); } catch (_) {}
      label.click();
    }
    return Boolean(await waitFor(subjectAlreadySelected, 2500, 60));
  }

  async function selectSubjectPath() {
    if (subjectAlreadySelected()) return true;
    subjectSelectionFailure = '';

    const t0 = Date.now();
    const marks = [];
    const lap = async (name, run) => {
      const at = Date.now();
      const result = await run();
      marks.push(`${name} ${((Date.now() - at) / 1000).toFixed(1)}s`);
      return result;
    };
    const report = (verdict) => {
      subjectTimings = `Chủ đề ${verdict} sau ${((Date.now() - t0) / 1000).toFixed(1)}s · ${marks.join(' · ')}`;
      showBanner(subjectTimings, verdict !== 'xong');
    };

    // v2.2.89 — thử đường nhanh trước; hụt thì đóng menu và chạy cách dò cũ.
    let fast = false;
    try { fast = await lap('đường nhanh', fastCascaderSelect); } catch (_) { fast = false; }
    if (fast) { report('xong'); return true; }
    closeSubjectMenu();
    await sleep(150);

    for (let attempt = 0; attempt < 3; attempt++) {
      if (attempt > 0) marks.push(`— thử lại lần ${attempt + 1} —`);

      if (!await lap('mở menu', openSubjectMenu)) {
        subjectSelectionFailure = 'không mở được ô Chủ đề';
        continue;
      }

      if (!await lap('thấy tầng 1', () => findSubjectOptionWithScroll(SUBJECT_PATH[0], 10000))) {
        subjectSelectionFailure = `không thấy tầng "${SUBJECT_PATH[0]}"`;
        closeSubjectMenu();
        await sleep(250);
        continue;
      }
      if (!await lap('mở tầng 2', () => activateSubjectBranch(SUBJECT_PATH[0], SUBJECT_PATH[1]))) {
        closeSubjectMenu();
        await sleep(250);
        continue;
      }

      if (!await lap('mở tầng 3', () => activateSubjectBranch(SUBJECT_PATH[1], SUBJECT_PATH[2]))) {
        closeSubjectMenu();
        await sleep(250);
        continue;
      }

      if (await lap('chốt', () => chooseSubjectLeaf(SUBJECT_PATH[2]))) {
        report('xong');
        return true;
      }
      closeSubjectMenu();
      await sleep(250);
    }
    report('THẤT BẠI');
    return false;
  }

  function base64ToBytes(base64) {
    const binary = atob(base64 || '');
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    return bytes;
  }

  function storedToFile(item) {
    return new File([base64ToBytes(item.base64)], item.name, {
      type: item.type || 'application/octet-stream',
      lastModified: Date.now()
    });
  }

  async function findFileInput() {
    let input = document.querySelector('input[type="file"]');
    if (input) return input;

    const uploadButton = [...document.querySelectorAll('button,[role="button"],span,div')]
      .filter(visible)
      .find((el) => /^(tai len|upload)$/.test(norm(el.innerText || el.textContent || '')));
    if (uploadButton) {
      fireClick(uploadButton);
    }
    input = await waitFor(() => document.querySelector('input[type="file"]'), 5000);
    return input;
  }

  /* ---------------------------------------------------------------------------
   * v0.11.17 — ĐẨY FILE THEO ĐỢT, KHÔNG DỘI CẢ 6 FILE MỘT LÚC.
   *
   * Bản cũ nhét cả 6 file vào MỘT DataTransfer rồi bắn một phát. TikTok upload
   * song song cả 6 → băng thông chia 6 → KHÔNG file nào xong sớm. Tới hạn phải
   * bấm Gửi thì cả 6 đang dở dang, cái nào chưa xong là mất trắng.
   *
   * Đẩy theo đợt thì tổng thời gian y hệt (cùng bấy nhiêu byte), nhưng file
   * XONG HẲN theo thứ tự. Cùng một cái deadline, số file *hoàn tất* cao hơn hẳn.
   * Đây chính là "upload vừa phải để up được nhiều file nhất".
   *
   * Thứ tự cũng là thứ tự ưu tiên: file Excel (dữ liệu thật của phiếu) đi
   * trước, ảnh bằng chứng theo sau — thiếu ảnh còn cứu được, thiếu Excel thì
   * phiếu vô nghĩa.
   *
   * Nhịp tự điều chỉnh: đợt đầu 1 file để đo tốc độ mạng thật, mạng nhanh thì
   * đợt sau to dần (2 → 3), mạng chậm thì giữ nhỏ.
   * ------------------------------------------------------------------------- */
  function nextWaveSize(lastWaveMs, lastWaveCount, remaining) {
    // Đợt đầu luôn 1 file: vừa để đo tốc độ mạng thật, vừa để file Excel —
    // thứ quan trọng nhất của phiếu — chắc chắn về đích trước.
    if (!lastWaveCount) return 1;
    const perFile = lastWaveMs / lastWaveCount;
    // Mạng nhanh thì chia đợt chỉ tổ chậm: bắn hết phần còn lại một phát.
    if (perFile <= 1500) return remaining;
    if (perFile <= 3500) return 2;
    return 1;
  }

  /** Chờ tới khi TikTok hiện đủ card cho số file đã đẩy, hoặc hết hạn.
   *
   * LƯU Ý về "card ngừng tăng": trong lúc một đợt đang bay, card KHÔNG tăng là
   * chuyện bình thường — file chưa xong thì lấy đâu ra card. Nên ở đây phải
   * kiên nhẫn hơn hẳn UPLOAD_SETTLE_MS, và hạn của đợt lấy theo tốc độ ĐO ĐƯỢC
   * chứ không phải một con số cứng. Bản nháp đầu dùng 3s: đợt nào cũng bỏ cuộc
   * sau 3s rồi đẩy tiếp đợt sau — hoá ra vẫn dội cả 6 file, chỉ chậm hơn.
   */
  async function waitForWaveLanded(input, items, target, deadlineAt, waveDeadlineAt) {
    let best = renderedAttachmentEvidence(input, items).renderedCount;
    const limit = Math.min(deadlineAt, waveDeadlineAt);
    while (Date.now() < limit) {
      const evidence = renderedAttachmentEvidence(input, items);
      if (evidence.renderedCount > best) best = evidence.renderedCount;
      if (best >= target) return { landed: best, reason: 'đủ' };
      if (detectUploadFailure(input)) return { landed: best, reason: 'lỗi upload' };
      await sleep(TIKTOK_POLL_MS);
    }
    return {
      landed: best,
      reason: Date.now() >= deadlineAt ? 'hết giờ' : 'đợt này quá lâu'
    };
  }

  /* v0.11.19 — bản đẩy theo đợt v0.11.17 giữ lại để đối chiếu, KHÔNG còn được gọi.
   * Luồng thật nằm ở uploadAttachments() mới ngay bên dưới. */
  async function uploadAttachmentsWavesV01117(storedAttachments) {
    const items = Array.isArray(storedAttachments) ? storedAttachments.slice(0, 6) : [];
    if (!items.length) return { ok: false, count: 0 };
    let input = await findFileInput();
    if (!input) return { ok: false, count: 0 };

    lastUploadDiagnostics = null;
    const startedAt = Date.now();
    const hardDeadline = startedAt + UPLOAD_TOTAL_BUDGET_MS;
    let dispatchedCount = 0;
    let landedCount = 0;
    let waveMs = 0;
    let waveCount = 0;

    while (dispatchedCount < items.length && Date.now() < hardDeadline) {
      const remaining = items.length - dispatchedCount;
      const size = Math.min(nextWaveSize(waveMs, waveCount, remaining), remaining);
      const wave = items.slice(dispatchedCount, dispatchedCount + size);

      // TikTok thay mới <input type=file> sau mỗi lần nhận — phải tìm lại.
      input = (await findFileInput()) || input;
      const dt = new DataTransfer();
      for (const item of wave) dt.items.add(storedToFile(item));
      input.files = dt.files;
      dispatchedCount += dt.files.length;
      input.dispatchEvent(new Event('input', { bubbles: true }));
      input.dispatchEvent(new Event('change', { bubbles: true }));
      showBanner(`Đính kèm ${landedCount}/${items.length} file · đang đẩy đợt ${wave.length} file…`);

      // Hạn cho riêng đợt này: gấp đôi thời gian dự kiến theo tốc độ đo được ở
      // đợt trước (đợt đầu chưa có số liệu thì cho 10s), kẹp trong [6s, 15s].
      const perFileGuess = waveCount ? waveMs / waveCount : 10000;
      const waveDeadline = Date.now() + Math.min(15000, Math.max(6000, perFileGuess * wave.length * 2));

      const waveStart = Date.now();
      const result = await waitForWaveLanded(input, items, dispatchedCount, hardDeadline, waveDeadline);
      waveMs = Date.now() - waveStart;
      waveCount = wave.length;
      landedCount = result.landed;

      if (result.reason === 'lỗi upload' || result.reason === 'hết giờ') break;
      // "đợt này quá lâu" ⇒ vẫn đẩy tiếp đợt sau, biết đâu cái sau nhẹ hơn.
    }

    showBanner(`Đã đính kèm ${landedCount}/${items.length} file · đang chờ nút Gửi…`);
    const remaining = Math.max(3000, hardDeadline - Date.now());
    const ready = await waitForUploadAndSubmitReady(input, items, dispatchedCount, remaining);
    /* v0.11.15 — CỔNG UPLOAD KHÔNG ĐƯỢC LÀM NGHẼN HÀNG.
     *
     * v0.11.13 chặn gửi khi thiếu file. Đúng về nguyên tắc nhưng sai về vận
     * hành: chờ đủ 45 giây rồi vẫn đứng im thì cả queue raise tắc, mà đây là
     * thứ chị ghét nhất. Ranh giới đúng:
     *   - đủ file            → gửi, im lặng (đường thường)
     *   - thiếu nhưng CÓ file → gửi, banner cảnh báo rõ thiếu mấy file
     *   - KHÔNG file nào lên  → mới dừng, giao lại cho người
     * Việc chờ cho đủ (v0.11.13) mới là thứ thật sự sửa lỗi "chỉ 1 hình";
     * cấm gửi chỉ là phần thừa, bỏ đi. */
    const landed = Math.max(
      landedCount,
      ready?.renderedCount || 0,
      lastUploadDiagnostics?.bestRendered || 0
    );
    /* v0.11.16 — ok LUÔN true: khâu upload không còn quyền chặn nút Gửi.
     * Nó chỉ còn báo cáo đã đính kèm được mấy file để banner nói thật. */
    const complete = Boolean(ready) && landed >= dispatchedCount;
    return {
      ok: true,
      partial: !complete,
      count: complete ? dispatchedCount : landed,
      dispatchedCount,
      // Khi thất bại vẫn trả về số card TikTok thực sự nhận, để banner nói rõ
      // "chỉ nhận 3/6 file" thay vì "chưa xác nhận được trạng thái upload".
      renderedCount: ready?.renderedCount || lastUploadDiagnostics?.bestRendered || 0,
      readyMode: ready?.mode || '',
      diagnostics: ready?.diagnostics || lastUploadDiagnostics || null
    };
  }

  /* ===========================================================================
   * v0.11.19 — ĐỦ EXCEL + ĐỦ ẢNH MỌI LẦN, KHÔNG THÊM THỜI GIAN CHỜ CỐ ĐỊNH.
   *
   * Gốc lỗi thiếu file (v0.11.13 → v0.11.18): tool coi "card tên file đã hiện"
   * là "file đã lên". TikTok vẽ card NGAY khi file BẮT ĐẦU upload. Nên:
   *   - đợt Excel "về đích" ngay lập tức dù Excel còn đang bay;
   *   - lối thoát "card ngừng tăng 3s" / "trần 12s" / "ngân sách 30s" bấm Gửi
   *     khi file còn dở → file đó rớt khỏi phiếu;
   *   - file TikTok bỏ qua (change event rơi, request lỗi, API trả code ≠ 0)
   *     KHÔNG BAO GIỜ được đẩy lại.
   * Thiếu Excel hay thiếu ảnh chỉ là chuyện file nào chậm nhất lần đó.
   *
   * Cách mới:
   *   1. Đẩy CẢ 6 file trong MỘT lần (như v0.10.28). Chia đợt không làm tổng
   *      byte ít đi, chỉ thêm một vòng chờ đợt đầu — bỏ đi là NHANH hơn.
   *   2. Đọc kết quả từ MẠNG (tiktok_upload_probe.js): từng file phải có request
   *      upload của chính nó trả về thành công. Không đoán qua card nữa.
   *   3. File lỗi → đẩy lại NGAY file đó. File bị bỏ qua (mạng đã im mà file
   *      chưa từng đi) → đẩy lại file đó. Chỉ file thiếu, không đẩy trùng file đã lên.
   *   4. Đủ hết → trả về ngay trong ~0,25s sau request cuối. Không có
   *      "chờ ổn định 800ms", không "card đứng yên 3s".
   *   5. Đẩy lại 2 lần vẫn thiếu → KHÔNG tự gửi, báo đúng tên file thiếu, và
   *      để nút "Đẩy lại file thiếu & Gửi" góc phải dưới trang.
   *
   * Máy đo không cài được (Chrome quá cũ / TikTok upload trong worker) → tự
   * chuyển sang đọc DOM như cũ, nhưng vẫn giữ quy tắc đủ file mới gửi.
   * ========================================================================= */
  const PROBE_TAG = 'op-upload-probe';
  const UPLOAD_QUIET_MS = 250;          // sau request liên quan upload cuối cùng
  const UPLOAD_STALL_MS = 2500;         // mạng im bấy lâu mà file chưa từng đi → đẩy lại
  const UPLOAD_MAX_ROUNDS = 3;          // mỗi file: 1 lần đầu + tối đa 2 lần đẩy lại
  const UPLOAD_HARD_CAP_MS = 120000;    // chỉ chạm khi mạng hỏng thật
  const UPLOAD_INFLIGHT_STALE_MS = 20000; // request "liên quan" treo quá lâu thì không đợi nó
  const DOM_STABLE_MS = 1000;           // chỉ dùng ở chế độ dự phòng DOM
  const DOM_STALL_MS = 4000;
  // Mạng đã xác nhận đủ mà form vẫn "có vẻ bận" quá lâu → tin mạng (selector
  // spinner của TikTok có thể bắt nhầm phần tử ẩn/còn sót).
  const BUSY_OVERRIDE_MS = 3000;

  const uploadProbe = {
    alive: false,
    records: new Map(),
    relatedInflight: 0,
    lastRelatedActivityAt: 0,
    wakers: new Set()
  };

  window.addEventListener('message', (event) => {
    if (event.source !== window || !event.data || event.data.source !== PROBE_TAG) return;
    let payload = null;
    try { payload = JSON.parse(event.data.json); } catch (_) { return; }
    uploadProbe.alive = true;
    const incoming = Array.isArray(payload.records) ? payload.records : (payload.record ? [payload.record] : []);
    for (const record of incoming) {
      if (record && record.id) uploadProbe.records.set(record.id, record);
    }
    uploadProbe.relatedInflight = Number(payload.relatedInflight) || 0;
    uploadProbe.lastRelatedActivityAt = Number(payload.lastRelatedActivityAt) || uploadProbe.lastRelatedActivityAt;
    for (const wake of [...uploadProbe.wakers]) wake();
  });
  try { window.postMessage({ source: `${PROBE_TAG}-ask` }, '*'); } catch (_) {}

  /** Ngủ tối đa `ms`, nhưng thức dậy NGAY khi mạng báo có request upload bắt đầu/xong. */
  function waitUploadSignal(ms) {
    return new Promise((resolve) => {
      let timer = null;
      const wake = () => {
        uploadProbe.wakers.delete(wake);
        if (timer) clearTimeout(timer);
        resolve();
      };
      uploadProbe.wakers.add(wake);
      timer = setTimeout(wake, ms);
    });
  }

  async function ensureProbeAlive(timeout = 400) {
    if (uploadProbe.alive) return true;
    try { window.postMessage({ source: `${PROBE_TAG}-ask` }, '*'); } catch (_) {}
    const started = Date.now();
    while (!uploadProbe.alive && Date.now() - started < timeout) await waitUploadSignal(50);
    return uploadProbe.alive;
  }

  /** Ô file đúng của khu "Đính kèm tệp" (trang có thể có input file khác). */
  async function findAttachmentFileInput() {
    if (globalThis.OPTikTokAttachments) {
      let scoped = OPTikTokAttachments.pageOperation('locate');
      if (scoped.input) return scoped.input;
      if (scoped.button) {
        scoped.button.click();
        return waitFor(() => OPTikTokAttachments.pageOperation('locate').input, 5000);
      }
      return null;
    }
    const pick = () => {
      const inputs = [...document.querySelectorAll('input[type="file"]')];
      if (!inputs.length) return null;
      const inSection = inputs.find((el) => {
        for (let cur = el.parentElement, depth = 0; cur && depth < 8 && cur !== document.body; cur = cur.parentElement, depth++) {
          const text = norm(cur.textContent || '');
          if (text.length > 4000) break;
          if (/(dinh kem tep|dinh kem|attachment)/.test(text)) return true;
        }
        return false;
      });
      return inSection || inputs.find((el) => el.multiple) || inputs[0];
    };
    return pick() || (await findFileInput()) || pick();
  }

  /**
   * Trạng thái từng file theo MẠNG: 'done' | 'pending' | 'failed' | 'unseen'.
   * Khớp theo tên (FormData), rồi theo dung lượng (upload Blob kiểu ImageX),
   * cuối cùng mới gán theo thứ tự cho request không mang tên/không khớp size
   * (trường hợp TikTok nén ảnh trước khi up).
   */
  function networkFileStates(items, sinceTs, itemSince = [], itemDispatches = []) {
    const entries = [];
    for (const record of uploadProbe.records.values()) {
      if (!record.startedAt || record.startedAt < sinceTs - 50) continue;
      for (const file of record.files || []) entries.push({ record, file, used: false });
    }
    entries.sort((a, b) => a.record.startedAt - b.record.startedAt);

    // 'done' tính từ BẤT KỲ lần đẩy nào. Còn pending/failed/unseen chỉ xét các
    // request từ lần đẩy GẦN NHẤT của file đó — nếu không, vừa đẩy lại xong mà
    // request mới chưa kịp bắt đầu thì lỗi cũ vẫn làm file bị đẩy lại lần nữa
    // (ra 2 bản trùng).
    const verdict = (list, since = 0) => {
      if (list.some((e) => e.record.ok)) return { state: 'done', error: '' };
      const recent = list.filter((e) => e.record.startedAt >= since - 50);
      if (!recent.length) return { state: 'unseen', error: list.length ? (list[list.length - 1].record.error || '') : '' };
      if (recent.some((e) => !e.record.endedAt)) return { state: 'pending', error: '' };
      return { state: 'failed', error: recent[recent.length - 1].record.error || 'lỗi' };
    };

    const itemNames = new Set(items.map((item) => String(item?.name || '')));
    const itemSizes = new Set(items.map((item) => Number(item?.size) || 0));
    const lists = items.map(() => []);
    const anonymousItem = items.map(() => false);
    items.forEach((item, i) => {
      const byName = entries.filter((e) => !e.used && e.file.name && e.file.name === item.name);
      if (byName.length) { byName.forEach((e) => { e.used = true; }); lists[i] = byName; return; }
      const size = Number(item?.size) || 0;
      const bySize = entries.filter((e) => !e.used && !e.file.name && size && e.file.size === size);
      if (bySize.length) { bySize.forEach((e) => { e.used = true; }); lists[i] = bySize; return; }
      anonymousItem[i] = true;
    });

    // Request không nhận diện được (tên/size lạ — TikTok nén ảnh) → gán theo thứ
    // tự đẩy. Mỗi LẦN ĐẨY của một file ăn đúng một request bắt đầu sau lần đẩy đó.
    const leftovers = entries.filter((e) =>
      !e.used && !itemNames.has(e.file.name) && !itemSizes.has(e.file.size)
    );
    const slotUsed = items.map((_, i) => (itemDispatches[i] || []).map(() => false));
    for (const entry of leftovers) {
      let target = -1;
      let slot = -1;
      for (let i = 0; i < items.length && target < 0; i++) {
        if (!anonymousItem[i]) continue;
        const times = itemDispatches[i] || [];
        for (let r = 0; r < times.length; r++) {
          if (slotUsed[i][r] || times[r] > entry.record.startedAt + 50) continue;
          // lần đẩy sau cũng đã bắt đầu trước request này → request thuộc lần sau
          if (r + 1 < times.length && times[r + 1] <= entry.record.startedAt + 50 && !slotUsed[i][r + 1]) continue;
          target = i;
          slot = r;
          break;
        }
      }
      if (target >= 0) {
        slotUsed[target][slot] = true;
        lists[target].push(entry);
      }
    }
    const states = lists.map((list, i) => verdict(list, itemSince[i] || 0));
    return states;
  }

  function networkQuietFor() {
    const since = Date.now() - (uploadProbe.lastRelatedActivityAt || 0);
    if (uploadProbe.relatedInflight > 0 && since < UPLOAD_INFLIGHT_STALE_MS) return 0;
    return since;
  }

  /** File nào đang có card mang đúng tên nó trên form (dùng ở chế độ dự phòng DOM). */
  function domMatchedFlags(input, items) {
    const candidates = attachmentCandidateTexts(input);
    const used = new Set();
    const flags = items.map((item) => {
      const index = candidates.findIndex((candidate, i) => !used.has(i) && attachmentNameMatches(candidate, item?.name || ''));
      if (index < 0) return false;
      used.add(index);
      return true;
    });
    return { flags, cardCount: Math.min(items.length, candidates.length), matched: flags.filter(Boolean).length };
  }

  /* v0.11.20 — bản chỉ-đọc-mạng v0.11.19 giữ lại để đối chiếu, KHÔNG còn được gọi. */
  async function uploadAttachmentsNetOnlyV01119(storedAttachments) {
    const items = Array.isArray(storedAttachments) ? storedAttachments.slice(0, 6) : [];
    const names = items.map((item) => item?.name || '(không tên)');
    if (!items.length) {
      return { ok: false, complete: false, count: 0, dispatchedCount: 0, missing: [], reason: 'không có file nào để đính kèm' };
    }
    const startedAt = Date.now();
    let input = await findAttachmentFileInput();
    if (!input) {
      return { ok: false, complete: false, count: 0, dispatchedCount: items.length, missing: names, missingItems: items, reason: 'không thấy ô Đính kèm tệp' };
    }

    let mode = (await ensureProbeAlive()) ? 'network' : 'dom';
    const rounds = items.map(() => 0);
    const itemSince = items.map(() => 0);
    const itemDispatches = items.map(() => []);
    let retries = 0;
    let firstDispatchAt = 0;
    let lastDispatchAt = 0;
    let sinceTs = 0;
    let lastBanner = '';

    const dispatch = async (indices) => {
      input = (await findAttachmentFileInput()) || input;
      const dt = new DataTransfer();
      for (const i of indices) {
        dt.items.add(storedToFile(items[i]));
        rounds[i] += 1;
        itemSince[i] = Date.now();
        itemDispatches[i].push(itemSince[i]);
      }
      input.files = dt.files;
      input.dispatchEvent(new Event('input', { bubbles: true }));
      input.dispatchEvent(new Event('change', { bubbles: true }));
      lastDispatchAt = Date.now();
      if (!firstDispatchAt) firstDispatchAt = lastDispatchAt;
    };

    sinceTs = Date.now();
    await dispatch(items.map((_, i) => i));

    let domLastCount = -1;
    let domChangedAt = Date.now();
    let domStableSince = 0;
    let lastDomLookAt = 0;
    let states = items.map(() => ({ state: 'unseen', error: '' }));
    let busySince = 0;
    const liveInput = async () => {
      if (!input || !input.isConnected) input = (await findAttachmentFileInput()) || input;
      return input;
    };

    while (Date.now() - startedAt < UPLOAD_HARD_CAP_MS) {
      const now = Date.now();

      if (mode === 'network') {
        states = networkFileStates(items, sinceTs, itemSince, itemDispatches);
        const doneCount = states.filter((s) => s.state === 'done').length;
        const quiet = networkQuietFor();
        const anyBlobSeen = [...uploadProbe.records.values()].some((r) => r.startedAt >= sinceTs - 50);

        const banner = `Đính kèm ${doneCount}/${items.length} file đã lên${retries ? ` · đẩy lại ${retries} lần` : ''}…`;
        if (banner !== lastBanner) { showBanner(banner); lastBanner = banner; }

        let formBusy = false;
        if (doneCount === items.length && quiet >= UPLOAD_QUIET_MS) {
          formBusy = uploadStillBusy(await liveInput());
          if (formBusy && !busySince) busySince = Date.now();
          if (!formBusy) busySince = 0;
        }
        if (doneCount === items.length && quiet >= UPLOAD_QUIET_MS &&
            (!formBusy || Date.now() - busySince >= BUSY_OVERRIDE_MS)) {
          return {
            ok: true, complete: true, partial: false,
            count: items.length, dispatchedCount: items.length, missing: [],
            retries, mode, elapsedMs: Date.now() - startedAt
          };
        }

        // Máy đo có chạy nhưng không thấy request mang file nào, trong khi form
        // đã có card → TikTok upload ở chỗ máy đo không nhìn thấy. Chuyển sang DOM,
        // TUYỆT ĐỐI không đẩy lại (đẩy lại lúc này = nhân đôi file).
        if (!anyBlobSeen && now - lastDispatchAt >= UPLOAD_STALL_MS && quiet >= UPLOAD_STALL_MS) {
          const dom = domMatchedFlags(await liveInput(), items);
          if (dom.cardCount > 0) {
            mode = 'dom';
            domLastCount = -1;
            continue;
          }
        }

        // File lỗi: đẩy lại ngay. File chưa từng đi: chỉ đẩy lại khi mạng đã im
        // đủ lâu (tức TikTok không còn xếp hàng upload nào nữa).
        const failed = [];
        const unseen = [];
        states.forEach((s, i) => {
          if (rounds[i] >= UPLOAD_MAX_ROUNDS) return;
          if (s.state === 'failed') failed.push(i);
          else if (s.state === 'unseen' && quiet >= UPLOAD_STALL_MS && now - itemSince[i] >= UPLOAD_STALL_MS) unseen.push(i);
        });
        const redo = [...failed, ...unseen].sort((a, b) => a - b);
        if (redo.length) {
          retries += 1;
          console.warn(`[${EXTENSION_BUILD}] Đẩy lại ${redo.length} file`, redo.map((i) => `${names[i]} (${states[i].state}${states[i].error ? `: ${states[i].error}` : ''})`));
          showBanner(`Đẩy lại ${redo.length} file TikTok chưa nhận: ${redo.map((i) => names[i]).join(', ')}`);
          // Record cũ của file đẩy lại vẫn tính (lần sau ok là đủ) — sinceTs giữ nguyên.
          await dispatch(redo);
          continue;
        }

        const stuck = states.every((s, i) =>
          s.state === 'done' || (rounds[i] >= UPLOAD_MAX_ROUNDS && s.state !== 'pending')
        );
        if (stuck && quiet >= UPLOAD_STALL_MS && now - lastDispatchAt >= UPLOAD_STALL_MS) break;

        await waitUploadSignal(TIKTOK_POLL_MS);
        continue;
      }

      /* ---- Chế độ dự phòng DOM: không có máy đo mạng ---- */
      if (now - lastDomLookAt < 300) { await sleep(300 - (now - lastDomLookAt)); continue; }
      lastDomLookAt = Date.now();
      const dom = domMatchedFlags(await liveInput(), items);
      const rawBusy = uploadStillBusy(input);
      if (rawBusy && !busySince) busySince = Date.now();
      if (!rawBusy) busySince = 0;
      const busy = rawBusy && Date.now() - busySince < BUSY_OVERRIDE_MS + 2000;
      if (dom.cardCount !== domLastCount) { domLastCount = dom.cardCount; domChangedAt = Date.now(); }
      if (dom.cardCount >= items.length && !busy) {
        if (!domStableSince) domStableSince = Date.now();
        if (Date.now() - domStableSince >= DOM_STABLE_MS) {
          return {
            ok: true, complete: true, partial: false,
            count: items.length, dispatchedCount: items.length, missing: [],
            retries, mode, elapsedMs: Date.now() - startedAt
          };
        }
      } else {
        domStableSince = 0;
      }
      const banner = `Đính kèm ${dom.cardCount}/${items.length} file (đọc form)${retries ? ` · đẩy lại ${retries} lần` : ''}…`;
      if (banner !== lastBanner) { showBanner(banner); lastBanner = banner; }

      if (dom.cardCount < items.length && !busy && Date.now() - domChangedAt >= DOM_STALL_MS && Date.now() - lastDispatchAt >= DOM_STALL_MS) {
        const need = items.length - dom.cardCount;
        const redo = dom.flags
          .map((ok, i) => (!ok && rounds[i] < UPLOAD_MAX_ROUNDS ? i : -1))
          .filter((i) => i >= 0)
          .slice(0, need);
        if (!redo.length) break;
        retries += 1;
        showBanner(`Đẩy lại ${redo.length} file chưa thấy trên form: ${redo.map((i) => names[i]).join(', ')}`);
        await dispatch(redo);
        domChangedAt = Date.now();
      }
    }

    // Hết cách: báo đúng file nào thiếu.
    let missing;
    let missingIndices;
    if (mode === 'network') {
      states = networkFileStates(items, sinceTs, itemSince, itemDispatches);
      missingIndices = states.map((s, i) => (s.state === 'done' ? -1 : i)).filter((i) => i >= 0);
      missing = missingIndices.map((i) => `${names[i]}${states[i].error ? ` (${states[i].error})` : ''}`);
    } else {
      const dom = domMatchedFlags(await liveInput(), items);
      missingIndices = dom.flags.map((ok, i) => (ok ? -1 : i)).filter((i) => i >= 0)
        .slice(0, Math.max(0, items.length - dom.cardCount));
      missing = missingIndices.map((i) => names[i]);
      if (!missing.length && dom.cardCount < items.length) missing = [`${items.length - dom.cardCount} file`];
    }
    console.warn(`[${EXTENSION_BUILD}] Đính kèm KHÔNG đủ`, { missing, rounds, retries, mode, records: [...uploadProbe.records.values()] });
    return {
      ok: false, complete: false, partial: true,
      count: items.length - missing.length, dispatchedCount: items.length,
      missing, missingItems: missingIndices.map((i) => items[i]),
      retries, mode, elapsedMs: Date.now() - startedAt
    };
  }

  /* ===========================================================================
   * v0.11.20 — THẺ FILE TRÊN FORM LÀ SỰ THẬT, MẠNG CHỈ ĐỂ BIẾT "CÒN ĐANG BAY".
   *
   * Lỗi thật của v0.11.19 (ảnh chụp 30/09): Excel lên 2 lần, 1 ảnh mất, không
   * tự gửi. Chuỗi sự kiện:
   *   1. Excel đã lên form, nhưng request upload của Excel máy đo không nhận ra
   *      (TikTok up Excel đường khác ảnh) → máy đo tưởng Excel "chưa đi".
   *   2. Tool đẩy lại Excel → form có 2 Excel.
   *   3. TikTok giới hạn TỐI ĐA 6 TỆP → bản Excel thừa chiếm chỗ, ảnh thứ 5 không
   *      còn chỗ → thiếu ảnh → tool (đúng luật) không tự gửi.
   *
   * Luật mới:
   *   - "File đã đính kèm" = trên form có THẺ mang đúng tên file đó (khớp cả tên
   *     bị TikTok cắt giữa kiểu "TikTok__GHN__Bea... SL TBN3.xlsx").
   *   - File ĐÃ có thẻ thì KHÔNG BAO GIỜ đẩy lại, dù mạng nói gì.
   *   - Thẻ trùng / thẻ lỗi → tool bấm thùng rác xoá, giải phóng chỗ (giới hạn 6).
   *   - Chỉ đẩy lại file KHÔNG có thẻ, và chỉ khi còn chỗ.
   *   - Mạng chỉ dùng để chờ file còn đang bay xong rồi mới gửi.
   *   - Gửi khi: mỗi file đúng 1 thẻ, không thẻ trùng, không file nào đang bay.
   * Đường thường vẫn: đẩy 6 file 1 lần → xong là gửi, không có chờ cố định.
   * ========================================================================= */
  const ATTACH_FILE_TAIL = /\.(?:jpe?g|png|mp4|mov|pdf|xlsx?|csv)$/i;
  const ATTACH_CARD_STABLE_MS = 1200;   // file máy đo không thấy request: thẻ đứng yên bấy lâu mới tin
  const ATTACH_DOM_EVERY_MS = 250;

  /** Khối "Đính kèm tệp" — tìm từ nhãn, KHÔNG phụ thuộc input (đủ 6 tệp TikTok ẩn nút Tải lên). */
  function attachmentSection() {
    if (globalThis.OPTikTokAttachments) return OPTikTokAttachments.pageOperation('locate').section;
    const labels = [...document.querySelectorAll('label,div,span,p')]
      .filter((el) => el.childElementCount <= 3 && /^\*?\s*dinh kem tep/.test(norm(el.textContent || '')) &&
        norm(el.textContent || '').length <= 40);
    const label = labels.find(visible) || labels[0];
    const input = document.querySelector('input[type="file"]');
    const start = label || input;
    if (!start) return null;
    let fallback = start.parentElement;
    for (let cur = start.parentElement, depth = 0; cur && cur !== document.body && depth < 8; cur = cur.parentElement, depth++) {
      if (depth === 2) fallback = cur;
      const hasFileLeaf = [...cur.querySelectorAll('*')].some((el) =>
        el.childElementCount === 0 && ATTACH_FILE_TAIL.test((el.textContent || '').trim()));
      if (hasFileLeaf || (input && cur.contains(input) && label && cur.contains(label))) return cur;
    }
    return fallback;
  }

  function attachmentFileLimit(section) {
    const match = norm(section?.textContent || '').match(/toi da (\d{1,2}) tap tin|up to (\d{1,2}) files?/);
    return Number(match?.[1] || match?.[2]) || 6;
  }

  /** Tên trên thẻ có thể bị cắt giữa ("abc... xyz.png") hoặc cắt cuối ("abc..."). */
  function cardNameMatches(cardText, fullName) {
    // v2.2.23 — TikTok có thể hiện "&" thành "&amp;"/"%26"/"_" trên thẻ: so thêm bản chỉ giữ chữ-số.
    const decode = (value) => String(value || '').replace(/&amp;/gi, '&').replace(/%26/gi, '&');
    const c = norm(decode(cardText));
    const f = norm(decode(fullName));
    if (!c || !f) return false;
    const alnum = (value) => value.replace(/[^a-z0-9.…]/g, '');
    if (/[^a-z0-9._\- …]/.test(f) && cardNameMatches(alnum(c), alnum(f))) return true;
    if (c === f || c.includes(f)) return true;
    const parts = c.split(/\.{3}|…/).map((p) => p.trim()).filter(Boolean);
    if (parts.length === 2) return f.startsWith(parts[0]) && f.endsWith(parts[1]) && parts[0].length + parts[1].length >= 6;
    if (parts.length === 1 && /(\.{3}|…)\s*$/.test(c)) return parts[0].length >= 6 && f.startsWith(parts[0]);
    // Cắt giữa bằng 2 thẻ span: phần đuôi (có đuôi file) nằm riêng một node.
    if (parts.length === 1 && ATTACH_FILE_TAIL.test(c) && c.length >= 8 && f.endsWith(c)) return true;
    return false;
  }

  function cardMatchesItem(cardInfo, fullName) {
    return cardInfo.texts.some((t) => cardNameMatches(t, fullName));
  }

  /** Đọc toàn bộ thẻ file trên form và gán vào từng file cần đính kèm. */
  function readAttachmentCards(items) {
    const section = attachmentSection();
    const empty = { section, cards: [], perItem: items.map(() => []), extras: [], foreign: [], limit: 6, usable: false };
    if (!section) return empty;
    const leaves = [...section.querySelectorAll('*')].filter((el) => {
      if (el.childElementCount > 0) return false;
      const text = (el.getAttribute('title') || el.textContent || '').trim();
      return text.length <= 200 && ATTACH_FILE_TAIL.test(text);
    });
    const leafSet = new Set(leaves);
    const cards = [];
    for (const leaf of leaves) {
      if (!visible(leaf)) continue;
      // Thẻ = tổ tiên lớn nhất vẫn chỉ chứa ĐÚNG MỘT tên file.
      let card = leaf;
      for (let cur = leaf.parentElement; cur && cur !== section; cur = cur.parentElement) {
        let count = 0;
        for (const other of leafSet) if (cur.contains(other)) count += 1;
        if (count > 1) break;
        card = cur;
      }
      const titled = [...(card.querySelectorAll?.('[title]') || [])].map((el) => el.getAttribute('title') || '')
        .filter((t) => ATTACH_FILE_TAIL.test(t.trim()));
      const parentText = leaf.parentElement && leaf.parentElement !== card.parentElement && card.contains(leaf.parentElement)
        ? leaf.parentElement.textContent || '' : '';
      const texts = [...titled, leaf.getAttribute('title') || '', leaf.textContent || '', parentText, card.textContent || '']
        .map((t) => t.trim()).filter(Boolean);
      const text = texts[0] || '';
      const cardText = norm(card.textContent || '');
      const error = UPLOAD_FAILURE_PATTERNS.some((p) => cardText.includes(p)) ||
        /(^|[\s_-])(error|fail|failed)([\s_-]|$)/.test(classText(card));
      cards.push({ leaf, card, text: text.trim(), texts, error });
    }

    const perItem = items.map(() => []);
    const claimed = new Set();
    // Lượt 1: mỗi file giữ 1 thẻ (ưu tiên thẻ không lỗi). Lượt 2: thẻ khớp còn lại = thẻ thừa.
    items.forEach((item, i) => {
      const matches = cards.filter((c) => !claimed.has(c) && cardMatchesItem(c, item?.name || ''));
      const keep = matches.find((c) => !c.error) || matches[0];
      if (keep) { perItem[i].push(keep); claimed.add(keep); }
    });
    const extras = [];
    items.forEach((item, i) => {
      for (const c of cards) {
        if (claimed.has(c) || !cardMatchesItem(c, item?.name || '')) continue;
        claimed.add(c);
        perItem[i].push(c);
        extras.push(c);
      }
    });
    const foreign = cards.filter((c) => !claimed.has(c));
    const matchedItems = perItem.filter((list) => list.length).length;
    return {
      section,
      cards,
      perItem,
      extras,
      foreign,
      limit: attachmentFileLimit(section),
      // Có thẻ nhưng không khớp được file nào → bộ khớp tên không dùng được trên layout này.
      usable: matchedItems > 0 || cards.length === 0
    };
  }

  function cardDeleteButton(cardInfo) {
    const { card, leaf } = cardInfo;
    const nameRect = leaf.getBoundingClientRect();
    const semantic = [...card.querySelectorAll(
      '[class*="delete" i],[class*="remove" i],[class*="trash" i],[class*="close" i],[aria-label*="xóa" i],[aria-label*="xoá" i],[aria-label*="delete" i],[aria-label*="remove" i]'
    )].filter(visible);
    if (semantic.length) return semantic[semantic.length - 1];
    // Không có tên class dễ đoán → icon nhỏ nằm BÊN PHẢI tên file (thùng rác).
    const icons = [...card.querySelectorAll('button,[role="button"],svg,i,span')]
      .filter((el) => el !== leaf && !el.contains(leaf) && visible(el))
      .filter((el) => {
        const r = el.getBoundingClientRect();
        return r.width >= 8 && r.width <= 44 && r.height >= 8 && r.height <= 44 && r.left >= nameRect.right - 4;
      })
      .sort((a, b) => b.getBoundingClientRect().right - a.getBoundingClientRect().right);
    const icon = icons[0];
    if (!icon) return null;
    if (icon.tagName.toLowerCase() === 'svg' || icon.closest?.('svg')) {
      const svg = icon.closest?.('svg') || icon;
      return svg.parentElement && svg.parentElement !== card ? svg.parentElement : svg;
    }
    return icon;
  }

  async function deleteAttachmentCard(cardInfo) {
    const button = cardDeleteButton(cardInfo);
    if (!button) return false;
    fireClick(button, true);
    // Một số bản TikTok hỏi xác nhận xoá.
    const confirm = await waitFor(() => {
      if (!cardInfo.card.isConnected) return { gone: true };
      for (const root of visibleDialogRoots().concat(
        [...document.querySelectorAll('[class*="popconfirm" i],[class*="popover" i]')].filter(visible)
      )) {
        const action = referenceAction(root, ['Xóa', 'Xoá', 'Xác nhận', 'OK', 'Đồng ý', 'Delete', 'Confirm']);
        if (action) return { action };
      }
      return null;
    }, 900, 60);
    if (confirm?.action) fireClick(confirm.action, true);
    const gone = await waitFor(() => !cardInfo.card.isConnected || !visible(cardInfo.leaf), 2000, 60);
    return Boolean(gone);
  }

  /**
   * Đẩy + đối soát file đính kèm. Gọi lại bao nhiêu lần cũng an toàn: file đã có
   * thẻ không bị đẩy lại, thẻ trùng bị xoá. Nút cứu hộ dùng lại đúng hàm này.
   */
  async function uploadAttachments(storedAttachments, opts = {}) {
    // v0.11.21 — lượt vét cuối trước khi tự gửi dùng ít vòng hơn để không chờ lâu.
    const maxRounds = Number(opts.maxRounds) || UPLOAD_MAX_ROUNDS;
    const items = Array.isArray(storedAttachments) ? storedAttachments.slice(0, 6) : [];
    const pageTransport = opts.attachmentTransport === 'background-page' || items.some(item => !item.base64);
    const dispatchErrors = new Map();
    const pageDone = new Set();
    const names = items.map((item) => item?.name || '(không tên)');
    if (!items.length) {
      return { ok: false, complete: false, count: 0, dispatchedCount: 0, missing: [], reason: 'không có file nào để đính kèm' };
    }
    const startedAt = Date.now();
    const probeAlive = await ensureProbeAlive();
    const rounds = items.map(() => 0);
    const itemSince = items.map(() => 0);
    const itemDispatches = items.map(() => []);
    const sinceTs = startedAt;
    let retries = 0;
    let deleted = 0;
    let lastDispatchAt = 0;
    let lastBanner = '';
    let busySince = 0;
    let stableSig = '';
    let stableSince = Date.now();
    let lastDomAt = 0;
    let view = readAttachmentCards(items);
    const deleteTries = new Map();   // mỗi thẻ thử xoá tối đa 2 lần, tránh kẹt vòng lặp
    const tryDelete = async (cardInfo) => {
      const key = cardInfo.card;
      const n = deleteTries.get(key) || 0;
      if (n >= 2) return false;
      deleteTries.set(key, n + 1);
      const ok = await deleteAttachmentCard(cardInfo);
      if (ok) deleted += 1;
      return ok;
    };

    const dispatch = async (indices) => {
      for (const i of indices) {
        rounds[i] += 1;
        itemSince[i] = Date.now();
        itemDispatches[i].push(itemSince[i]);
      }
      try {
        if (pageTransport) {
          const result = await runtimeMessage({ type: 'UPLOAD_TIKTOK_ATTACHMENT_FILES', indices });
          if (!result?.ok || !indices.every(index => result.dispatchedIndices?.includes(index))) throw new Error(result?.error || 'Trang chưa nhận file.');
          // v2.2.55 — trang đã xác nhận file tải xong ('done' trong form TikTok) → không cần chờ thẻ đứng yên.
          for (const index of indices) if (result.statuses?.[index] === 'done') pageDone.add(index);
        } else {
          const input = await findAttachmentFileInput();
          if (!input) throw new Error('Không thấy ô Tải lên của ticket.');
          const dt = new DataTransfer();
          for (const i of indices) dt.items.add(storedToFile(items[i]));
          const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'files')?.set;
          if (setter) setter.call(input, dt.files); else input.files = dt.files;
          input.dispatchEvent(new Event('change', { bubbles: true }));
        }
        for (const i of indices) dispatchErrors.delete(i);
        lastDispatchAt = Date.now();
        return true;
      } catch (error) {
        for (const i of indices) dispatchErrors.set(i, error.message || String(error));
        lastDispatchAt = Date.now();
        return false;
      }
    };

    // Lần đẩy đầu nằm TRONG vòng đối soát: file đã có thẻ (tab load lại / bấm cứu
    // hộ) không bị đẩy lại, thẻ trùng được xoá TRƯỚC để có chỗ cho file thiếu.
    let lastFailNoInput = false;

    while (Date.now() - startedAt < UPLOAD_HARD_CAP_MS) {
      if (pageTransport && pageDone.size === items.length) {
        return { ok: true, complete: true, partial: false, count: items.length, dispatchedCount: items.length, missing: [], retries, deleted, mode: 'page-confirmed', elapsedMs: Date.now() - startedAt };
      }
      const now = Date.now();
      const net = probeAlive ? networkFileStates(items, sinceTs, itemSince, itemDispatches) : items.map(() => ({ state: 'unseen', error: '' }));
      const quiet = networkQuietFor();

      if (now - lastDomAt >= ATTACH_DOM_EVERY_MS) {
        lastDomAt = now;
        view = readAttachmentCards(items);
        const sig = view.cards.map((c) => `${c.text}|${c.error ? 1 : 0}`).join('/');
        if (sig !== stableSig) { stableSig = sig; stableSince = now; }
      }

      // A missing/unfamiliar attachment section still needs an initial dispatch.
      // Never enter a wait-only branch before any file has been pushed.
      if (view.usable) net.forEach((state, i) => {
        if (state.state === 'failed') view.perItem[i].forEach(card => { card.error = true; });
      });
      const onForm = view.usable
        ? view.perItem.map((list, i) => list.some((c) => !c.error) && net[i].state !== 'pending' && net[i].state !== 'failed')
        : net.map(state => state.state === 'done');
      const doneCount = onForm.filter(Boolean).length;
      const banner = `Đính kèm ${doneCount}/${items.length} file trên form${retries ? ` · đẩy lại ${retries}` : ''}${deleted ? ` · đã dọn ${deleted} thẻ trùng/lỗi` : ''}…`;
      if (banner !== lastBanner) { showBanner(banner); lastBanner = banner; }

      // 1) Xoá thẻ trùng / thẻ lỗi của file đã có bản tốt. Chỉ xoá khi mạng đã im
      //    để không đụng vào thẻ TikTok đang dựng dở.
      const toDelete = view.extras.filter((c) => (c.error || quiet >= UPLOAD_QUIET_MS) && (deleteTries.get(c.card) || 0) < 2);
      if (toDelete.length) {
        const target = toDelete[toDelete.length - 1];
        console.warn(`[${EXTENSION_BUILD}] Xoá thẻ file thừa`, target.text);
        showBanner(`Xoá file trùng trên form: ${target.text}`);
        await tryDelete(target);
        lastDomAt = 0;
        continue;
      }

      // 2) Đẩy (lần đầu) / đẩy lại CHỈ file không có thẻ nào. Giới hạn 6 tệp của
      //    TikTok tính cả thẻ lỗi → chỗ trống = giới hạn − mọi thẻ đang có.
      const free = view.limit - view.cards.length;
      const redo = [];
      items.forEach((_, i) => {
        if (onForm[i] || net[i].state === 'pending' || rounds[i] >= maxRounds) return;
        if (rounds[i] === 0) { redo.push(i); return; }
        const s = net[i].state;
        const waited = now - itemSince[i] >= UPLOAD_STALL_MS && quiet >= UPLOAD_STALL_MS;
        if (s === 'pending') return;
        if (s === 'failed' || waited) redo.push(i);
      });
      if (redo.length) {
        // Thẻ lỗi của chính file cần đẩy lại chiếm chỗ → xoá trước.
        const errorCards = view.perItem.flatMap((list, i) => (redo.includes(i) ? list.filter((c) => c.error) : []))
          .filter((c) => (deleteTries.get(c.card) || 0) < 2);
        if (errorCards.length) {
          await tryDelete(errorCards[0]);
          lastDomAt = 0;
          continue;
        }
        const batch = net.some(state => state.state === 'pending') ? [] : redo.slice(0, Math.min(1, Math.max(0, free)));
        if (batch.length) {
          const firstPush = batch.every((i) => rounds[i] === 0);
          if (!firstPush) retries += 1;
          if (!firstPush) console.warn(`[${EXTENSION_BUILD}] Đẩy lại ${batch.length} file không có trên form`, batch.map((i) => `${names[i]} (${net[i].state}${net[i].error ? `: ${net[i].error}` : ''})`));
          if (!firstPush) showBanner(`Đẩy lại ${batch.length} file chưa có trên form: ${batch.map((i) => names[i]).join(', ')}`);
          lastFailNoInput = !(await dispatch(batch));
          lastDomAt = 0;
          continue;
        }
        // Hết chỗ và không còn thẻ lỗi/trùng nào xoá được → không chờ vô ích.
        if (free <= 0 && !errorCards.length && !view.extras.length && quiet >= UPLOAD_STALL_MS) break;
      }

      // 3) Đủ: mỗi file đúng 1 thẻ tốt, không thẻ thừa, không file nào còn đang bay.
      /* v2.2.9 — opts.strict (khiếu nại FDR/LDR kèm Excel + ảnh): thẻ phải đứng yên lâu hơn, không còn % / "đang tải",
         và KHÔNG bỏ qua vòng tải sau 3 giây — trước đây file lớn còn đang tải vẫn bị coi là xong rồi bấm Gửi. */
      const stableNeed = opts.strict ? ATTACH_CARD_STABLE_MS * 3 : ATTACH_CARD_STABLE_MS;
      if (doneCount === items.length && !view.extras.length) {
        const anyPending = net.some((s) => s.state === 'pending');
        const unconfirmed = net.some((s) => s.state !== 'done');
        const netOk = !anyPending && quiet >= UPLOAD_QUIET_MS &&
          (!unconfirmed || (now - stableSince >= stableNeed && quiet >= stableNeed));
        let busy = false;
        if (netOk) {
          busy = [...(view.section?.querySelectorAll(
            '[aria-busy="true"],[role="progressbar"],[class*="uploading" i],[class*="upload-loading" i],[class*="upload-progress" i]' +
            (opts.strict ? ',[class*="loading" i],[class*="spin" i]' : '')
          ) || [])].some(visible) ||
            (opts.strict && view.cards.some((c) => /\b\d{1,2}(?:[.,]\d+)?\s?%|đang tải|uploading|loading/i.test(String(c.text || ''))));
          if (busy && !busySince) busySince = now;
          if (!busy) busySince = 0;
        }
        if (netOk && (!busy || (!opts.strict && now - busySince >= BUSY_OVERRIDE_MS))) {
          return {
            ok: true, complete: true, partial: false,
            count: items.length, dispatchedCount: items.length, missing: [],
            retries, deleted, mode: probeAlive ? 'form+network' : 'form', elapsedMs: Date.now() - startedAt
          };
        }
      }

      // Thẻ trùng xoá 2 lần không được → không chờ vô ích.
      if (view.extras.length && view.extras.every((c) => (deleteTries.get(c.card) || 0) >= 2) && doneCount === items.length) break;

      // 4) Hết đường: file thiếu đã hết lượt đẩy lại, mạng đã im.
      const hopeless = items.every((_, i) => onForm[i] || (rounds[i] >= maxRounds && net[i].state !== 'pending'));
      if (hopeless && doneCount < items.length && quiet >= UPLOAD_STALL_MS && now - lastDispatchAt >= UPLOAD_STALL_MS) break;

      await waitUploadSignal(TIKTOK_POLL_MS);
    }

    view = readAttachmentCards(items);
    const net = probeAlive ? networkFileStates(items, sinceTs, itemSince, itemDispatches) : items.map(() => ({ state: 'unseen' }));
    const missingIdx = items.map((_, i) => {
      const ready = view.usable ? view.perItem[i].some(c => !c.error) && !['failed', 'pending'].includes(net[i].state) : net[i].state === 'done';
      return ready ? -1 : i;
    }).filter(i => i >= 0);
    const missing = missingIdx.map((i) => `${names[i]}${net[i]?.error ? ` (${net[i].error})` : (dispatchErrors.has(i) ? ` (${dispatchErrors.get(i)})` : lastFailNoInput ? ' (không thấy ô Tải lên)' : '')}`);
    if (!missing.length && view.extras.length) missing.push(`còn ${view.extras.length} file trùng chưa xoá được`);
    console.warn(`[${EXTENSION_BUILD}] Đính kèm KHÔNG đủ`, {
      missing, rounds, retries, deleted,
      cards: view.cards.map((c) => c.text), records: [...uploadProbe.records.values()]
    });
    return {
      ok: false, complete: false, partial: true,
      count: items.length - missingIdx.length, dispatchedCount: items.length,
      missing, retries, deleted, mode: 'form+network', elapsedMs: Date.now() - startedAt
    };

  }

  /** v0.11.21 — trước khi tự gửi khi thiếu file: xoá thẻ lỗi + thẻ trùng để
   *  TikTok không chặn nút Gửi và không nhận bản trùng. */
  async function cleanupBrokenAttachmentCards(items) {
    let removed = 0;
    for (let pass = 0; pass < 6; pass++) {
      const view = readAttachmentCards(items);
      const target = view.extras[0] || view.cards.find((c) => c.error);
      if (!target) break;
      if (await deleteAttachmentCard(target)) removed += 1;
      else break;
    }
    return removed;
  }

  /** Nút cứu hộ góc phải dưới — chỉ hiện khi đẩy lại 2 lần vẫn thiếu file. */
  function showAttachmentRescueButton(onClick) {
    try {
      document.getElementById('op-attach-rescue')?.remove();
      const btn = document.createElement('button');
      btn.id = 'op-attach-rescue';
      btn.type = 'button';
      btn.textContent = 'OnPoint: Đẩy lại file thiếu & Gửi';
      btn.style.cssText = 'position:fixed;right:16px;bottom:16px;z-index:2147483647;padding:10px 14px;' +
        'background:#d92d20;color:#fff;border:0;border-radius:8px;font:600 13px/1.2 system-ui,sans-serif;' +
        'box-shadow:0 4px 14px rgba(0,0,0,.25);cursor:pointer';
      btn.addEventListener('click', () => {
        btn.disabled = true;
        btn.textContent = 'Đang đẩy lại…';
        Promise.resolve(onClick()).finally(() => btn.remove());
      }, { once: true });
      document.body.appendChild(btn);
    } catch (_) {}
  }

  // TikTok sometimes concatenates the filename and the icon/accessible label
  // without a whitespace node. Requiring a boundary after the extension made
  // visible cards such as "...xlsx" / "...jpg" disappear from detection.
  const ATTACHMENT_FILE_PATTERN = /\.(?:jpe?g|png|mp4|mov|pdf|xlsx?|csv)/i;

  function attachmentSearchRoot(input) {
    const form = input?.closest?.('form');
    let best = input?.parentElement || form || document.body;
    for (let current = input?.parentElement, depth = 0; current && depth < 8; current = current.parentElement, depth++) {
      if (current === document.body) break;
      const text = norm(current.innerText || current.textContent || '');
      // Return the nearest upload section rather than the outer form/dialog.
      // This keeps upload errors, progress indicators and filename cards scoped
      // to the real attachment area on TikTok's current layout.
      if (/(dinh kem tep|attachment)/.test(text) && /(tai len|upload)/.test(text)) return current;
    }
    return form || best || document;
  }

  function attachmentCandidateTexts(input) {
    const roots = [attachmentSearchRoot(input), document].filter(Boolean);
    const seenElements = new Set();
    const seenTexts = new Set();
    const texts = [];

    for (const root of roots) {
      const elements = [...root.querySelectorAll(
        '[data-file-name],[data-filename],[title],[aria-label],a,button,span,p,div'
      )];
      for (const el of elements) {
        if (seenElements.has(el) || !visible(el)) continue;
        seenElements.add(el);

        const values = [
          el.getAttribute?.('data-file-name'),
          el.getAttribute?.('data-filename'),
          el.getAttribute?.('title'),
          el.getAttribute?.('aria-label'),
          elementText(el)
        ].filter(Boolean);
        const raw = values.join(' ');
        if (!ATTACHMENT_FILE_PATTERN.test(raw)) continue;

        // Prefer the smallest node that owns the filename. This prevents a
        // section wrapper from being counted again for every attachment card.
        const childOwnsFilename = [...el.children].some((child) =>
          visible(child) && ATTACHMENT_FILE_PATTERN.test([
            child.getAttribute?.('data-file-name'),
            child.getAttribute?.('data-filename'),
            child.getAttribute?.('title'),
            child.getAttribute?.('aria-label'),
            elementText(child)
          ].filter(Boolean).join(' '))
        );
        if (childOwnsFilename) continue;

        const normalized = norm(raw);
        if (!normalized || seenTexts.has(normalized)) continue;
        seenTexts.add(normalized);
        texts.push(normalized);
      }
      if (texts.length) break;
    }
    return texts;
  }

  function attachmentNameMatches(candidateText, filename) {
    const fullName = norm(filename);
    if (!fullName) return false;
    if (candidateText.includes(fullName)) return true;

    const extensionMatch = fullName.match(/\.([a-z0-9]{2,5})$/);
    const extension = extensionMatch?.[1] || '';
    if (extension && !candidateText.includes(`.${extension}`)) return false;

    const baseName = extensionMatch ? fullName.slice(0, -(extension.length + 1)) : fullName;
    const distinctiveTokens = baseName
      .split(/[^a-z0-9]+/)
      .filter((token) => token.length >= 5)
      .sort((a, b) => b.length - a.length);
    return distinctiveTokens.some((token) => candidateText.includes(token));
  }

  function renderedAttachmentEvidence(input, items) {
    const candidates = attachmentCandidateTexts(input);
    const used = new Set();
    let matchedCount = 0;

    for (const item of items) {
      const index = candidates.findIndex((candidate, candidateIndex) =>
        !used.has(candidateIndex) && attachmentNameMatches(candidate, item?.name || '')
      );
      if (index >= 0) {
        used.add(index);
        matchedCount += 1;
      }
    }

    return {
      matchedCount,
      // Some TikTok builds shorten the DOM text itself. In that case each
      // unique, visible filename node still represents one rendered card.
      renderedCount: Math.max(matchedCount, Math.min(items.length, candidates.length)),
      expectedCount: items.length
    };
  }

  function visibleTextsMatching(root, patterns) {
    const scope = root || document;
    return [...scope.querySelectorAll(
      '[role="alert"],[role="status"],[class*="toast" i],[class*="message" i],[class*="error" i],p,span,div'
    )]
      .filter(visible)
      .map((el) => norm(elementText(el)))
      .filter((text) => text && text.length <= 360)
      .find((text) => patterns.some((pattern) => text.includes(pattern))) || '';
  }

  function detectUploadFailure(input) {
    return visibleTextsMatching(attachmentSearchRoot(input), UPLOAD_FAILURE_PATTERNS) ||
      visibleTextsMatching(document, UPLOAD_FAILURE_PATTERNS);
  }

  function uploadStillBusy(input) {
    const root = attachmentSearchRoot(input);
    return [...root.querySelectorAll(
      '[aria-busy="true"],[role="progressbar"],[class*="uploading" i],[class*="upload-loading" i],[class*="upload-progress" i]'
    )].some(visible);
  }

  function isDisabledAction(el) {
    if (!el) return true;
    return Boolean(
      el.disabled ||
      el.hasAttribute?.('disabled') ||
      norm(el.getAttribute?.('aria-disabled')) === 'true' ||
      /(^|\s)(disabled|is-disabled)(\s|$)/.test(classText(el))
    );
  }

  function exactActionButton(root, labels) {
    const wanted = labels.map(norm);
    const scope = root || document;
    return [...scope.querySelectorAll('button,[role="button"]')]
      .filter(visible)
      .filter((el) => !isDisabledAction(el))
      .filter((el) => wanted.includes(norm(elementText(el))))
      .sort((a, b) => {
        const aSemantic = a.tagName === 'BUTTON' ? 1 : 0;
        const bSemantic = b.tagName === 'BUTTON' ? 1 : 0;
        if (aSemantic !== bSemantic) return bSemantic - aSemantic;
        return b.getBoundingClientRect().bottom - a.getBoundingClientRect().bottom;
      })[0] || null;
  }

  function exactTextAction(root, labels, predicate = () => true) {
    const wanted = labels.map(norm);
    const scope = root || document;
    const seen = new Set();
    return [...scope.querySelectorAll('button,[role="button"],a,span,div')]
      .filter(visible)
      .filter((source) => wanted.includes(norm(elementText(source))))
      .map((source, index) => {
        const target = source.matches?.('button,[role="button"],a') ? source : nearestClickable(source);
        return { source, target, index };
      })
      .filter(({ source, target }) => {
        if (!target || seen.has(target) || !visible(target) || isDisabledAction(target)) return false;
        if (!predicate(source) || !predicate(target)) return false;
        seen.add(target);
        return true;
      })
      .sort((a, b) => {
        const aSemantic = a.target.matches?.('button,[role="button"]') ? 1 : 0;
        const bSemantic = b.target.matches?.('button,[role="button"]') ? 1 : 0;
        if (aSemantic !== bSemantic) return bSemantic - aSemantic;
        const ar = a.source.getBoundingClientRect();
        const br = b.source.getBoundingClientRect();
        const areaDiff = (ar.width * ar.height) - (br.width * br.height);
        return areaDiff || a.index - b.index;
      })[0]?.target || null;
  }

  function referenceAction(root, labels, predicate = () => true) {
    const semantic = exactActionButton(root, labels);
    if (semantic && predicate(semantic)) return semantic;
    return exactTextAction(root, labels, predicate);
  }

  function visibleDialogRoots() {
    return [...document.querySelectorAll(
      '[role="dialog"],[aria-modal="true"],[class*="modal" i],[class*="dialog" i]'
    )].filter(visible);
  }

  function findMainSubmitButton() {
    const semantic = [...document.querySelectorAll('button,[role="button"]')]
      .filter(visible)
      .filter((el) => !isDisabledAction(el))
      .filter((el) => MAIN_SUBMIT_TEXTS.map(norm).includes(norm(elementText(el))))
      .sort((a, b) => b.getBoundingClientRect().bottom - a.getBoundingClientRect().bottom)[0] || null;
    // TikTok may wrap the complete ticket form in a container whose generated
    // class contains "dialog". Excluding all dialog descendants made the real
    // enabled Gửi button invisible to v0.10.18. Exact action text is enough to
    // distinguish it from the confirmation action (Tiếp theo).
    return semantic || exactTextAction(document, MAIN_SUBMIT_TEXTS);
  }

  function findConfirmActionButton() {
    for (const dialog of visibleDialogRoots()) {
      const action = referenceAction(dialog, CONFIRM_ACTION_TEXTS);
      if (action) return action;
    }
    return referenceAction(document, CONFIRM_ACTION_TEXTS);
  }

  function detectFrequentToast() {
    return [...document.querySelectorAll(
      '[role="alert"],[role="status"],[class*="toast" i],[class*="message" i],[class*="notification" i],p,span,div'
    )]
      .filter(visible)
      .map((el) => norm(elementText(el)))
      .filter((text) => text && text.length <= 320)
      .some((text) => FREQUENT_TOAST_PATTERNS.some((pattern) => text.includes(pattern)));
  }

  async function referenceClick(el) {
    if (!el || !visible(el) || isDisabledAction(el)) return false;
    try { el.scrollIntoView({ block: 'center', inline: 'nearest' }); } catch (_) {}
    try { el.focus?.({ preventScroll: true }); } catch (_) { try { el.focus?.(); } catch (_) {} }
    try {
      // Use the same complete mouse sequence that already works for TikTok's
      // cascader. A bare HTMLElement.click() is sometimes ignored by the
      // Seller Center action footer even though it does not throw.
      return fireClick(el, true);
    } catch (_) {
      try {
        HTMLElement.prototype.click.call(el);
        return true;
      } catch (_) {
        return false;
      }
    }
  }

  async function waitForUploadAndSubmitReady(input, items, dispatchedCount, timeout = 45000) {
    const started = Date.now();
    let submitReadySince = 0;
    let lastDiagnostics = null;
    // Số card cao nhất từng thấy + lúc nó tăng lần cuối. Đây là tín hiệu
    // "TikTok còn đang upload" đáng tin duy nhất: không phụ thuộc class name
    // của spinner, thứ mà TikTok đổi bất cứ lúc nào.
    let bestRendered = 0;
    let lastRenderGrowthAt = started;

    while (Date.now() - started < timeout) {
      const submitButton = findMainSubmitButton();
      const evidence = renderedAttachmentEvidence(input, items);
      const selectedCount = Number(input?.files?.length || 0);
      const uploadFailure = detectUploadFailure(input);
      const busy = uploadStillBusy(input);
      const elapsed = Date.now() - started;
      // TikTok consumes the FileList and often clears input.files back to 0 as
      // soon as React accepts the upload. Confirm readiness from the rendered
      // attachment cards (or a still-populated FileList on older builds) plus
      // the enabled Gửi action. This matches the state visible to the operator.
      const attachmentsReady = evidence.renderedCount >= dispatchedCount || selectedCount >= dispatchedCount;
      const submitReady = Boolean(submitButton && !busy && !uploadFailure);
      if (submitReady) {
        if (!submitReadySince) submitReadySince = Date.now();
      } else {
        submitReadySince = 0;
      }

      if (evidence.renderedCount > bestRendered) {
        bestRendered = evidence.renderedCount;
        lastRenderGrowthAt = Date.now();
      }
      const renderStalledFor = Date.now() - lastRenderGrowthAt;

      lastDiagnostics = {
        expectedCount: items.length,
        dispatchedCount,
        renderedCount: evidence.renderedCount,
        bestRendered,
        renderStalledFor,
        matchedCount: evidence.matchedCount,
        selectedCount,
        submitFound: Boolean(submitButton),
        busy,
        uploadFailure: uploadFailure || ''
      };
      lastUploadDiagnostics = lastDiagnostics;

      if (uploadFailure) {
        console.warn(`[${EXTENSION_BUILD}] TikTok reported an upload failure`, lastDiagnostics);
        return null;
      }

      const submitStableFor = submitReadySince ? Date.now() - submitReadySince : 0;
      if (submitReady && attachmentsReady && submitStableFor >= STRICT_UPLOAD_STABLE_MS) {
        console.info(`[${EXTENSION_BUILD}] Upload ready from attachment evidence`, lastDiagnostics);
        return {
          submitButton,
          renderedCount: evidence.renderedCount,
          mode: 'attachment-evidence',
          diagnostics: lastDiagnostics
        };
      }

      // Reverse Assistant does not block submit on a brittle DOM card count.
      // If all files were dispatched, TikTok shows no upload error/progress and
      // the exact Gửi action stays enabled, continue even when a new TikTok DOM
      // build hides the cards from content-script selectors.
      //
      // v0.11.16 — "up xong bấm gửi liền, khỏi check file".
      // Việc đếm card KHÔNG còn quyền CHẶN, chỉ còn quyền quyết định gửi SỚM
      // hay muộn. Ba lối ra, lối nào tới trước thì đi:
      //   a) đủ card                          → gửi ngay (nhánh phía trên)
      //   b) card ngừng tăng ≥ UPLOAD_SETTLE_MS và đã có ≥1 → TikTok nhận tới
      //      đó là hết, gửi luôn, không nằm chờ cho hết giờ
      //   c) chạm trần REVERSE_READY_FALLBACK_MS → gửi, thôi không chờ nữa
      const settled = bestRendered > 0 && renderStalledFor >= UPLOAD_SETTLE_MS;
      if (
        submitReady &&
        dispatchedCount > 0 &&
        dispatchedCount === items.length &&
        submitStableFor >= STRICT_UPLOAD_STABLE_MS &&
        (settled || elapsed >= REVERSE_READY_FALLBACK_MS)
      ) {
        console.info(`[${EXTENSION_BUILD}] Upload accepted from stable Gửi state`, lastDiagnostics);
        return {
          submitButton,
          renderedCount: evidence.renderedCount,
          mode: 'reverse-submit-ready',
          diagnostics: lastDiagnostics
        };
      }
      await sleep(TIKTOK_POLL_MS);
    }
    console.warn(`[${EXTENSION_BUILD}] Upload readiness timed out`, lastDiagnostics);
    return null;
  }

  function draftSubmitGuardKey(draft) {
    const identity = draft?.groupKey || draft?.representativeOrderId || draft?.rows?.[0]?.orderId || 'current';
    return `op-tts-auto-submit:${String(identity).slice(0, 180)}`;
  }

  async function autoSubmitTicket(draft) {
    const guardKey = draftSubmitGuardKey(draft);
    if (sessionStorage.getItem(guardKey)) {
      return { ok: false, message: 'đã chặn submit trùng trong tab này' };
    }

    for (let attempt = 1; attempt <= SUBMIT_RETRY_LIMIT; attempt++) {
      if (activeTicketCapture?.createdTicket()) return { ok: true, message: 'Phiếu đã tạo · đang tự lưu Ticket ID' };
      showBanner(`Upload đã hoàn tất · đang bấm Gửi (${attempt}/${SUBMIT_RETRY_LIMIT})…`);
      const submitButton = await waitFor(findMainSubmitButton, 5000, 100);
      if (submitButton) await activeTicketCapture?.arm();
      if (!submitButton || !(await referenceClick(submitButton))) {
        await activeTicketCapture?.disarm();
        if (attempt < SUBMIT_RETRY_LIMIT) await sleep(3000);
        continue;
      }

      // Move as soon as TikTok renders a real outcome. This keeps the Reverse
      // Assistant safeguards without a fixed three-second pause on every run.
      const promptOutcome = await waitFor(() => {
        if (activeTicketCapture?.createdTicket()) return { kind: 'captured' };
        if (detectFrequentToast()) return { kind: 'rate-limit' };
        const button = findConfirmActionButton();
        return button ? { kind: 'next', button } : null;
      }, 42000, 100);

      if (promptOutcome?.kind === 'captured') {
        sessionStorage.setItem(guardKey, new Date().toISOString());
        return { ok: true, message: 'Phiếu đã tạo · tự bắt và lưu Ticket ID' };
      }
      if (promptOutcome?.kind === 'rate-limit') {
        await activeTicketCapture?.disarm();
        showBanner('TikTok báo thao tác quá thường xuyên · chờ 30 giây rồi thử lại…', true);
        await sleep(30000);
        continue;
      }

      // Do not depend on the dialog title. TikTok changes that text/layout,
      // while Reverse Assistant succeeds by waiting for the exact action.
      const nextButton = promptOutcome?.button || null;
      if (!nextButton) {
        if (attempt < SUBMIT_RETRY_LIMIT) await sleep(3000);
        continue;
      }

      showBanner(`Đã bấm Gửi · đang bấm Tiếp theo (${attempt}/${SUBMIT_RETRY_LIMIT})…`);
      sessionStorage.setItem(guardKey, 'in-progress');
      if (!(await referenceClick(nextButton))) {
        sessionStorage.removeItem(guardKey);
        if (attempt < SUBMIT_RETRY_LIMIT) await sleep(3000);
        continue;
      }

      const nextClickedAt = Date.now();
      const finalOutcome = await waitFor(() => {
        if (detectFrequentToast()) return { kind: 'rate-limit' };
        const elapsed = Date.now() - nextClickedAt;
        const routeChanged = !/\/ticket\/create(?:\/|$)/i.test(location.pathname);
        if (routeChanged) return { kind: 'accepted-route' };
        const confirmationClosed =
          !nextButton.isConnected ||
          !visible(nextButton) ||
          isDisabledAction(nextButton);
        if (confirmationClosed && elapsed >= FINAL_SUBMIT_GUARD_MS) {
          return { kind: 'accepted-dialog-closed' };
        }
        if (elapsed >= FINAL_SUBMIT_FALLBACK_MS) {
          return { kind: 'accepted-stable' };
        }
        return null;
      }, FINAL_SUBMIT_FALLBACK_MS + 1200, 100);

      if (finalOutcome?.kind === 'rate-limit') {
        await activeTicketCapture?.disarm();
        sessionStorage.removeItem(guardKey);
        showBanner('TikTok báo thao tác quá thường xuyên · chờ 30 giây rồi thử lại…', true);
        await sleep(30000);
        continue;
      }

      sessionStorage.setItem(guardKey, new Date().toISOString());
      return { ok: true, message: 'Đã tự gửi · đang tự bắt và lưu Ticket ID, sau đó chạy đơn tiếp theo' };
    }

    return { ok: false, message: `không hoàn tất Gửi → Tiếp theo sau ${SUBMIT_RETRY_LIMIT} lần thử` };
  }

  function fillDescription(draft) {
    const textareas = [...document.querySelectorAll('textarea')].filter((el) => !el.disabled && visible(el));
    if (textareas.length) {
      setNativeValue(textareas.sort((a, b) => b.clientHeight - a.clientHeight)[0], String(draft.text || '').slice(0, 500));
      return true;
    }

    const editables = [...document.querySelectorAll('[contenteditable="true"]')].filter(visible);
    if (editables.length) {
      editables[0].focus();
      document.execCommand('selectAll', false, null);
      document.execCommand('insertText', false, String(draft.text || '').slice(0, 500));
      editables[0].dispatchEvent(new Event('input', { bubbles: true }));
      return true;
    }
    return false;
  }

  async function fillRepresentativeOrderId(draft, optional = false) {
    const value = draft.representativeOrderId || draft.rows?.[0]?.orderId || '';
    if (!value) return false;

    const findInput = () => {
      const inputs = [...document.querySelectorAll('input')].filter((el) => !el.disabled && el.type !== 'file' && visible(el));
      return inputs.find((el) => /order|don hang|ma don|id don/.test(norm(textOf(el)))) || null;
    };
    const input = optional ? findInput() : await waitFor(findInput, 7000);
    if (!input) return false;
    setNativeValue(input, value);
    return true;
  }

  async function verifyAttachmentsBeforeSubmit(attachments, options = {}) {
    const expected = (attachments || []).map(item => String(item?.name || '').toLowerCase()).filter(Boolean);
    if (!expected.length) return { ok: true, missing: [] };
    const check = async () => {
      const result = await runtimeMessage({ type: 'VERIFY_TIKTOK_ATTACHMENTS' }).catch(() => null);
      if (!result?.ok || !Array.isArray(result.items)) return null;  // không đọc được form → không chặn (giữ hành vi cũ)
      const ready = new Set(result.items.filter(item => item.status === 'done' && item.hasUrl).map(item => item.name.toLowerCase()));
      const busy = result.items.some(item => item.status === 'init' || item.status === 'uploading');
      return { missing: expected.filter(name => !ready.has(name)), busy };
    };
    let state = await check();
    if (!state) return { ok: true, missing: [], unknown: true };
    const started = Date.now();
    let repushed = false;
    while (state.missing.length && Date.now() - started < 60000) {
      if (!state.busy && !repushed && options.attachmentTransport === 'background-page') {
        const indices = (attachments || []).map((item, index) => state.missing.includes(String(item?.name || '').toLowerCase()) ? index : -1).filter(index => index >= 0);
        if (indices.length) { showBanner(`Đẩy lại ${indices.length} file chưa gắn vào phiếu…`, true); await runtimeMessage({ type: 'UPLOAD_TIKTOK_ATTACHMENT_FILES', indices }).catch(() => null); }
        repushed = true;
      }
      await sleep(500);
      state = (await check()) || state;
    }
    return { ok: !state.missing.length, missing: state.missing };
  }

  /* v2.2.87 — ĐO TỪNG BƯỚC (đòi hàng): mốc thời gian thật của từng bước gửi về Side Panel để thấy chỗ đứng lâu.
     nav = bắt đầu tải trang tạo phiếu · ctx = script nhận việc · shop = đọc xong tên shop · subject = chọn xong chủ đề ·
     fill = điền mô tả + Order ID · upload = tải file xong · verify = kiểm file trước Gửi · submit = TikTok nhận Gửi → Tiếp theo. */
  const stepMarks = {};
  const markStep = (name, draft) => {
    if (draft?.issueType !== 'cancel_return') return;
    stepMarks[name] = Date.now();
    if (!stepMarks.nav) stepMarks.nav = Math.round(performance.timeOrigin || Date.now());
    if (['upload', 'submit', 'fail'].includes(name)) runtimeMessage({ type: 'CR_STEP_TIMING', marks: { ...stepMarks } }).catch(() => {});
  };
  async function fillDraft(draft, attachments, options = {}) {
    if (!draft) return;
    const claim = draft.mode === 'claim';
    configureSubject(draft);
    markStep('ctx', draft);
    if (globalThis.OPHandover?.pageAppeal?.(draft)) {
      const shop = await waitFor(() => {
        const value = globalThis.OPTikTokShop?.readFromPage();
        return value?.ok ? value : null;
      }, 6000, 200);
      if (!shop || shop.name !== draft.channel) {
        const details = shop ? `Shop đang đăng nhập ${shop.name} khác shop ${draft.channel}.` : 'Chưa đọc được shop đang đăng nhập.';
        showBanner(`${details} Mở đúng shop rồi chạy lại đơn này.`, true);
        return { ok: false, details, reason: 'shop-mismatch' };
      }
    }
    if (globalThis.OPHandover?.pageAppeal?.(draft) && (!draft.text || draft.text.length > 500)) {
      showBanner('Nội dung kháng nghị cần từ 1 đến 500 ký tự. Sửa nội dung trong Side Panel rồi chạy lại.', true);
      return { ok: false, reason: 'description-length' };
    }
    markStep('shop', draft);
    // v2.2.47 — Thử lại đính kèm: form đã điền (chủ đề, mô tả, Order ID) → chỉ đẩy lại file, không tải lại cả form.
    const subjectOk = options.onlyAttach ? true : await selectSubjectPath();
    markStep('subject', draft);
    const descriptionOk = options.onlyAttach ? true : fillDescription(draft);
    const orderOk = options.onlyAttach ? true : await fillRepresentativeOrderId(draft, claim);
    markStep('fill', draft);
    // v2.2.9 — khiếu nại FDR/LDR: file Excel danh sách đơn là bằng chứng chính → chờ upload xong thật, thiếu file thì KHÔNG gửi.
    const uploadResult = await uploadAttachments(attachments, { attachmentTransport: options.attachmentTransport, strict: claim });
    markStep('upload', draft);

    const details = [
      subjectOk
        ? (subjectTimings || 'đã chọn đúng chủ đề')
        : `chưa chọn được chủ đề${subjectSelectionFailure ? ` (${subjectSelectionFailure})` : ''}`,
      descriptionOk ? 'đã điền mô tả' : 'chưa thấy ô mô tả',
      orderOk ? 'đã điền Order ID đại diện' : claim ? 'Order ID đại diện có trong mô tả và file danh sách' : 'chưa thấy ô Order ID',
      uploadResult.complete
        ? `đã đính kèm đủ ${uploadResult.count}/${uploadResult.dispatchedCount} file (${((uploadResult.elapsedMs || 0) / 1000).toFixed(1)}s${uploadResult.retries ? ` · đẩy lại ${uploadResult.retries} lần` : ''}${uploadResult.deleted ? ` · dọn ${uploadResult.deleted} thẻ trùng/lỗi` : ''})`
        : `✖ THIẾU ${uploadResult.missing?.length || 0}/${uploadResult.dispatchedCount || 0} file: ${(uploadResult.missing || []).join(', ') || uploadResult.reason || '?'}`
    ].join(' · ');
    /* v0.11.16 — chỉ những thứ làm phiếu VÔ GIÁ TRỊ mới được quyền chặn:
     * sai chủ đề, thiếu mô tả, thiếu Order ID. File đính kèm thì không. */
    const formReady = subjectOk && descriptionOk && (claim || orderOk);
    if (!formReady) {
      showBanner(`${details}. KHÔNG tự gửi — form chưa đủ. Chị kiểm tra rồi bấm Gửi tay.`, true);
      return { ok: false, details, reason: 'form-not-ready' };
    }

    /* v0.11.21 — KHÔNG BAO GIỜ DỪNG VÌ THIẾU FILE. Chị chốt: không muốn bấm tay.
     * Thiếu file sau các lượt đẩy lại → vét thêm 1 lượt (dọn trùng + đẩy file
     * thiếu), xoá thẻ lỗi để TikTok không chặn nút Gửi, rồi TỰ GỬI với những gì
     * đã có. Side Panel ghi rõ phiếu nào gửi thiếu file gì để soi lại sau. */
    let finalUpload = uploadResult;
    if (!uploadResult.complete) {
      showBanner(`Thiếu file: ${(uploadResult.missing || []).join(', ') || '?'} · vét thêm 1 lượt rồi tự gửi…`, true);
      try {
        finalUpload = await uploadAttachments(attachments, { maxRounds: 1, attachmentTransport: options.attachmentTransport, strict: claim });
      } catch (error) {
        console.warn(`[${EXTENSION_BUILD}] Lượt vét lỗi`, error);
      }
      if (!claim) { try { await cleanupBrokenAttachmentCards(attachments); } catch (_) {} }
    }
    if (claim && !finalUpload.complete) {
      const missing = (finalUpload.missing || []).join(', ') || finalUpload.reason || 'chưa xác nhận file tải xong';
      const details = `File khiếu nại chưa tải xong: ${missing}. Tool KHÔNG tự gửi — kiểm tra file trên form (tải lại nếu thiếu) rồi bấm Gửi tay.`;
      showBanner(details, true);
      return { ok: false, reason: 'attachments-not-ready', details, uploadResult: finalUpload };
    }
    if (claim) {
      // Chốt cuối: form vừa báo đủ file → chờ thêm cho TikTok cập nhật nút Gửi, và không còn vòng tải nào trên trang.
      showBanner(`Đã tải đủ ${finalUpload.count}/${finalUpload.dispatchedCount} file · kiểm tra lần cuối trước khi Gửi…`);
      const settled = await waitFor(() => {
        const busy = [...document.querySelectorAll('[aria-busy="true"],[role="progressbar"],[class*="uploading" i],[class*="upload-progress" i]')].some(visible);
        return busy ? null : true;
      }, 60000, 300);
      await sleep(1500);
      if (!settled) {
        const details = 'TikTok vẫn đang tải file sau 60 giây. Tool KHÔNG tự gửi — chờ tải xong rồi bấm Gửi tay.';
        showBanner(details, true);
        return { ok: false, reason: 'attachments-not-ready', details, uploadResult: finalUpload };
      }
    }
    if (globalThis.OPHandover?.pageAppeal?.(draft) && !finalUpload.complete) {
      const missing = (finalUpload.missing || []).join(', ') || finalUpload.reason || 'chưa xác nhận file hoàn tất';
      const details = `Biên bản/bằng chứng chưa đính kèm đủ: ${missing}. Tool đã tự thử lại; bấm Thử lại đính kèm để chạy tiếp với file đã lưu.`;
      showBanner(details, true);
      return { ok: false, reason: 'attachments-not-ready', details, uploadResult: finalUpload };
    }
    const attachNote = finalUpload.complete
      ? (uploadResult.complete ? '' : ` · ✓ lượt vét đã đủ ${finalUpload.count}/${finalUpload.dispatchedCount} file`)
      : ` · ⚠ GỬI THIẾU ${finalUpload.missing?.length || 0} file: ${(finalUpload.missing || []).join(', ') || '?'}`;

    /* v0.11.13 — chốt an toàn: chỉ tự bấm Gửi trên tab do chính tool mở.
     * v0.11.15 — nhưng phải FAIL-SAFE. Chỉ chặn khi CHẮC CHẮN tab không phải
     * của tool (allowAutoSubmit === false). Nếu không xác định được (service
     * worker vừa ngủ dậy, message lỗi, context thiếu cờ) thì vẫn gửi như cũ —
     * thà chấp nhận rủi ro cũ còn hơn làm nghẽn queue vì một cờ đọc hụt. */
    if (options.allowAutoSubmit === false && options.tabScopeKnown === true) {
      showBanner(`${details}${attachNote}. Tab này không do tool mở nên KHÔNG tự gửi — chị xem lại rồi bấm Gửi.`, true);
      return { ok: false, details, reason: 'manual-tab' };
    }

    // v2.2.49 — CHỐT trước khi Gửi: đọc dữ liệu form TikTok sẽ gửi. File chỉ đi kèm phiếu khi 'done' + có FileUrl;
    // thẻ file hiện ngay lúc bắt đầu tải nên không đủ tin. Chờ tới 60 giây cho đủ, thiếu thì đẩy lại 1 lượt.
    const gate = await verifyAttachmentsBeforeSubmit(attachments, options);
    markStep('verify', draft);
    if (!gate.ok && (globalThis.OPHandover?.pageAppeal?.(draft) || claim)) {
      const detailsGate = `File chưa thật sự gắn vào phiếu: ${gate.missing.join(', ')}. Tool KHÔNG gửi — bấm Thử lại đính kèm.`;
      showBanner(detailsGate, true);
      markStep('fail', draft);
      return { ok: false, reason: 'attachments-not-ready', details: detailsGate, uploadResult: finalUpload };
    }
    const submitResult = await autoSubmitTicket(draft);
    markStep('submit', draft);
    showBanner(`${details}${attachNote} · ${submitResult.message}.`, !submitResult.ok || !finalUpload.complete);
    return { ok: Boolean(submitResult.ok), details, submitResult };
  }

  /* ---------------------------------------------------------------------------
   * v0.11.9 — THAY ĐỔI DUY NHẤT so với v0.10.28: bỏ popup nổi trên trang.
   *
   * showBanner() gốc vẽ một thanh nổi giữa màn hình TikTok, che mất form. Hàm
   * này giữ NGUYÊN tên và NGUYÊN chữ ký, chỉ đổi đích đến: gửi về Side Panel.
   * Toàn bộ phần còn lại của file là bản sao nguyên văn v0.10.28.
   * ------------------------------------------------------------------------- */
  function showBanner(message, isWarning = false) {
    try {
      chrome.runtime.sendMessage(
        { type: 'TICKET_STEP_TEXT', text: String(message || ''), warn: Boolean(isWarning) },
        () => void chrome.runtime.lastError
      );
    } catch (_) {}
    console.info(`[OnPoint ${EXTENSION_BUILD}] ${message}`);
  }

  // Chẩn đoán trong Console tab TikTok.
  window.__opSubject = () => ({
    build: EXTENSION_BUILD,
    ungVienTrigger: subjectTriggerCandidates().slice(0, 6)
      .map((el) => `${el.tagName}.${String(el.className || '').split(' ')[0]}`),
    menuDangMo: subjectPopupVisible(),
    daChon: subjectAlreadySelected(),
    loiGanNhat: subjectSelectionFailure || '(không có)',
    tang: SUBJECT_PATH.map((step, i) => ({
      tang: i + 1,
      soTarget: subjectOptionTargets(step).length
    })),
    htmlTrigger: subjectTriggerCandidates()[0]?.outerHTML?.slice(0, 800) || '(không có)',
    htmlOptionTang1: findSubjectOption(SUBJECT_PATH[0])?.outerHTML?.slice(0, 800) || '(không có)'
  });

  function parseTicketRowText(value) {
    const text = norm(value);
    const ticket = text.match(/\b(?:id phieu|ma phieu|ticket id|ticket no\.?|case id)\s*[:#]?\s*(\d{8,30})\b/i);
    const order = text.match(/\b(?:id don hang|ma don hang|order id)\s*[:#]?\s*([a-z0-9_-]{6,40})\b/i);
    if (!ticket || !order) return null;
    const created = text.match(/\b(\d{1,2})\/(\d{1,2})\/(\d{4})\s+(\d{1,2}):(\d{2})(?::(\d{2}))?\b/);
    const createdAtMs = created
      ? new Date(
        Number(created[3]),
        Number(created[2]) - 1,
        Number(created[1]),
        Number(created[4]),
        Number(created[5]),
        Number(created[6] || 0)
      ).getTime()
      : 0;
    return {
      ticketId: ticket[1],
      orderId: order[1].toUpperCase(),
      createdAtMs: Number.isFinite(createdAtMs) ? createdAtMs : 0
    };
  }

  function ticketRowCandidates() {
    const ticketLabelPattern = /\b(?:id phieu|ma phieu|ticket id|ticket no\.?|case id)\s*[:#]?\s*\d{8,30}\b/i;
    // v2.2.64 — lọc rẻ bằng textContent trước (có ≥8 chữ số, không quá dài) rồi mới đo visible + innerText:
    // trước đây đo layout + innerText của MỌI div/span trên trang ở mỗi lần DOM đổi → tab Nhật ký phiếu ì, bắt Ticket ID chậm.
    const leaves = [...document.querySelectorAll('div,span,p,td,li')]
      .filter((el) => { const raw = el.textContent || ''; return raw.length <= 1500 && /\d{8}/.test(raw); })
      .filter(visible)
      .filter((el) => {
        const text = norm(elementText(el));
        return text.length <= 240 && ticketLabelPattern.test(text);
      });
    const candidates = new Map();

    leaves.forEach((leaf, domIndex) => {
      let fallbackCandidate = null;
      for (
        let current = leaf, depth = 0;
        current && current !== document.body && depth < 9;
        current = current.parentElement, depth++
      ) {
        if (!visible(current)) continue;
        const text = norm(elementText(current));
        if (!text || text.length > 1400) continue;
        const ticketCount = (text.match(/\b(?:id phieu|ma phieu|ticket id|ticket no\.?|case id)\s*[:#]?\s*\d{8,30}\b/ig) || []).length;
        const orderCount = (text.match(/\b(?:id don hang|ma don hang|order id)\s*[:#]?\s*[a-z0-9_-]{6,40}\b/ig) || []).length;
        if (ticketCount !== 1 || orderCount !== 1) continue;
        const parsed = parseTicketRowText(text);
        if (!parsed) continue;
        const rect = current.getBoundingClientRect();
        const key = `${parsed.ticketId}|||${parsed.orderId}`;
        const candidate = {
          ...parsed,
          element: current,
          top: rect.top + (window.scrollY || 0),
          left: rect.left + (window.scrollX || 0),
          area: rect.width * rect.height,
          domIndex
        };
        if (!fallbackCandidate) fallbackCandidate = candidate;
        if (!candidate.createdAtMs) continue;
        fallbackCandidate = candidate;
        break;
      }
      if (!fallbackCandidate) return;
      const key = `${fallbackCandidate.ticketId}|||${fallbackCandidate.orderId}`;
      const previous = candidates.get(key);
      if (
        !previous ||
        (fallbackCandidate.createdAtMs && !previous.createdAtMs) ||
        (Boolean(fallbackCandidate.createdAtMs) === Boolean(previous.createdAtMs) &&
          fallbackCandidate.area < previous.area)
      ) {
        candidates.set(key, fallbackCandidate);
      }
    });

    return [...candidates.values()].sort((a, b) =>
      a.top - b.top || a.left - b.left || a.domIndex - b.domIndex
    );
  }

  // v2.2.31 — chỉ nhận đúng thẻ tab (role="tab") "Tất cả" và đọc trực tiếp aria-selected của nó.
  function captureAllTab() {
    return [...document.querySelectorAll('[role="tab"]')].find(el => visible(el) && /^(tat ca|all)\b/.test(norm(el.textContent))) || null;
  }
  const captureAllSelected = () => captureAllTab()?.getAttribute('aria-selected') === 'true';
  function captureActivePane() {
    const tab = [...document.querySelectorAll('[role="tab"]')].find(el => el.getAttribute('aria-selected') === 'true');
    return (tab?.getAttribute('aria-controls') && document.getElementById(tab.getAttribute('aria-controls'))) || document;
  }

  async function activateAllBeforeTicketCapture(capture, orderId) {
    showBanner('Đã về Nhật ký phiếu · đang chuyển sang tab Tất cả để tìm Ticket ID…');
    const tab = await waitFor(captureAllTab, 30000, 200);
    if (!tab) throw new Error('Chưa thấy tab Tất cả trên Nhật ký phiếu.');
    // Đo trên trang thật 29/10: click() trực tiếp vào thẻ tab đổi được tab, không phụ thuộc tọa độ / mức zoom của trang.
    for (let attempt = 0; attempt < 6 && !captureAllSelected(); attempt++) {
      const target = captureAllTab() || tab;
      target.scrollIntoView({ block: 'center' });
      if (attempt % 2) {
        // Lần chẵn/lẻ xen kẽ: chuỗi pointer/mouse đầy đủ cho trường hợp tab chỉ nghe mousedown/pointerdown.
        const init = { bubbles: true, cancelable: true, view: window, button: 0, buttons: 1 };
        for (const type of ['pointerdown', 'mousedown', 'pointerup', 'mouseup']) target.dispatchEvent(new (type.startsWith('pointer') ? PointerEvent : MouseEvent)(type, init));
      }
      target.click();
      await waitFor(captureAllSelected, 3000, 200);
    }
    // v2.2.37 — bỏ click theo tọa độ (lệch khi trang zoom khác 100%); click() đã thử 4 lần ở trên.
    if (!captureAllSelected()) throw new Error('Chưa chuyển được sang tab Tất cả (trang vẫn ở tab khác).');
    const ready = await waitFor(() => captureAllSelected() &&
      [...captureActivePane().querySelectorAll('input')].some(el => /tach nhieu|dau phay|so phieu|ticket/.test(norm(el.placeholder)) && visible(el)), 10000, 200);
    if (!ready) throw new Error('Đã chuyển sang Tất cả nhưng danh sách chưa sẵn sàng.');
    // v2.2.87 — 700 → 300 ms: danh sách đã sẵn sàng (ô tìm hiện); chỉ chờ ngắn để bắt trường hợp TikTok bật về tab khác.
    await sleep(300);
    // v2.2.39 — TikTok có thể tải lại danh sách và bật về "Chưa đọc" ngay sau khi bấm → kiểm tra lại.
    if (!captureAllSelected()) throw new Error('TikTok vừa tải lại danh sách và quay về tab khác — bấm lại Tất cả.');
    showBanner('Đã ở tab Tất cả · đang tìm đúng phiếu theo ID đơn hàng để lưu Ticket ID…');
  }
  // Script đã kết nối extension lúc khởi động mà nay mất runtime.id = extension vừa Reload/cập nhật.
  const hadRuntimeId = (() => { try { return Boolean(chrome.runtime?.id); } catch (_) { return false; } })();
  const contextLost = () => { try { return hadRuntimeId && !chrome.runtime?.id; } catch (_) { return true; } };
  function watchTicketId(draft, context = {}) {
    const expectedOrderId = normalizeTicketOrderId(draft?.representativeOrderId || draft?.rows?.[0]?.orderId);
    const isCreate = () => /\/ticket\/create(?:\/|$)/i.test(location.pathname);
    let capture = context.ticketCapture || (!isCreate() && context.tabScoped ? { startedAt: Date.parse(draft.createdAt) || Date.now(), baselineIds: [] } : null);
    let capturePersisted = Boolean(context.ticketCapture?.startedAt);
    let handled = false, processing = false, detected = null, retryAt = 0, allTabReady = false, listHadError = false;
    const network = new Map();
    const publishArm = () => window.postMessage({ source: 'op-ticket-probe-arm', json: JSON.stringify(capture ? { ...capture, orderId: expectedOrderId } : null) }, '*');
    const stop = () => { clearInterval(poll); observer.disconnect(); window.removeEventListener('message', receive); };
    const scan = async () => {
      if (!capture && !isCreate()) capture = { startedAt: Date.parse(draft.createdAt) || Date.now(), baselineIds: [] };
      if (handled || processing || !capture?.startedAt || Date.now() < retryAt) return;
      // Phải chạy TRƯỚC khi chọn Ticket ID. TikTok thường trả về tab Chưa đọc sau Gửi → Tiếp theo,
      // phiếu người bán vừa tạo chỉ hiện khi đã bấm Tất cả. Bao gồm cả SPA và tải lại trang đầy đủ.
      // v2.2.48 — đã bắt được đúng 1 Ticket ID từ phản hồi Gửi của TikTok (mạng) → lưu luôn, không cần sang Tất cả dò danh sách.
      const netOne = [...network.values()].filter(row => row.orderId === expectedOrderId && row.startedAt >= capture.startedAt && !(capture.baselineIds || []).includes(row.ticketId)).length === 1;
      if (netOne && !capturePersisted && context.tabScoped && !isCreate()) {
        const armed = await runtimeMessage({ type: 'TICKET_SUBMIT_STARTED', capture: { ...capture, orderId: expectedOrderId } }).catch(() => null);
        if (armed?.ok) capturePersisted = true;
      }
      if (!netOne && context.tabScoped && draft.issueType === 'cancel_return' && /^\/ticket\/?$/.test(location.pathname) && (!allTabReady || !captureAllSelected())) {
        // v2.2.39 — không "chốt" allTabReady: nếu trang bật về Chưa đọc/Đang xử lý thì bấm Tất cả lại.
        allTabReady = false;
        processing = true;
        try {
          if (!capturePersisted) {
            const armed = await runtimeMessage({ type: 'TICKET_SUBMIT_STARTED', capture: { ...capture, orderId: expectedOrderId } });
            if (!armed?.ok) throw new Error(armed?.error || 'Chưa khôi phục được trạng thái chờ Ticket ID.');
            capturePersisted = true;
          }
          await activateAllBeforeTicketCapture(capture, expectedOrderId);
          allTabReady = true;
          if (listHadError) await runtimeMessage({ type: 'TICKET_AUTOFILL_STATUS', autofill: { ok: true, stage: 'capturing-ticket', details: 'Đã bấm Tất cả · đang tìm Ticket ID.' } });
        } catch (error) {
          listHadError = true;
          retryAt = Date.now() + 2500;
          const details = `${error.message || error} Tool sẽ tự thử lại Tất cả; chưa tạo phiếu khác.`;
          showBanner(details, true);
          runtimeMessage({ type: 'TICKET_AUTOFILL_STATUS', autofill: { ok: false, reason: 'ticket-list-not-ready', details } }).catch(() => {});
        } finally { processing = false; }
        if (!allTabReady) return;
      }
      const candidates = [...network.values()].filter(row => row.orderId === expectedOrderId && row.startedAt >= capture.startedAt && !(capture.baselineIds || []).includes(row.ticketId));
      const candidate = detected || (candidates.length === 1 ? candidates[0] : null) ||
        (!isCreate() ? OPTicketCapture.choose(ticketRowCandidates(), expectedOrderId, capture) : null);
      if (!candidate) return;
      detected = candidate;
      processing = true;
      try {
        let timer;
        const result = await Promise.race([
          runtimeMessage({ type: 'TICKET_ID_DETECTED_FROM_TAB', ticketId: candidate.ticketId, orderId: expectedOrderId }),
          new Promise((_, reject) => { timer = setTimeout(() => reject(new Error('Lưu phiếu quá thời gian, sẽ tự thử lại.')), 30000); })
        ]).finally(() => clearTimeout(timer));
        if (!result?.ok || !result.autoMapped) throw new Error(result?.error || 'Chưa lưu được phiếu.');
        handled = true;
        stop();
        showBanner(`✓ Đã tự lưu Ticket ${candidate.ticketId} cho đơn ${expectedOrderId} · ${result.syncOk ? 'tracker đã đồng bộ' : 'đang đồng bộ tracker'}.`);
      } catch (error) {
        retryAt = Date.now() + 1500;
        if (/context invalidated/i.test(String(error?.message || error)) || contextLost()) { stop(); showBanner('Extension vừa được tải lại/cập nhật — bấm F5 tải lại tab này để tool chạy tiếp.', true); return; }
        // Thử lại là chuyện bình thường (chờ khóa hàng đợi) → ghi info, không đẩy lên trang Errors của Chrome.
        (/quá thời gian/.test(String(error?.message || error)) ? console.info : console.warn)(`[${EXTENSION_BUILD}] Automatic save will retry`, error);
        showBanner(`Đã bắt Ticket ${candidate.ticketId} · đang thử lưu lại tự động. Giữ tab này mở.`, true);
      } finally { processing = false; }
    };
    const receive = event => {
      if (event.source !== window || event.origin !== location.origin || event.data?.source !== 'op-ticket-probe') return;
      try {
        for (const record of JSON.parse(event.data.json).records || []) {
          if (/^\d{8,30}$/.test(record.ticketId) && record.orderId === expectedOrderId && Number.isFinite(record.startedAt)) network.set(record.ticketId, record);
        }
        scan().catch(() => {});
      } catch (_) {}
    };
    window.addEventListener('message', receive);
    // v2.2.64 — gộp các đợt DOM đổi liên tiếp thành 1 lần quét (tối đa ~8 lần/giây); phản hồi mạng & nhịp 500 ms vẫn quét ngay.
    let scanQueued = false;
    const scanSoon = () => {
      if (scanQueued || handled) return;
      scanQueued = true;
      setTimeout(() => { scanQueued = false; scan().catch(() => {}); }, 120);
    };
    const observer = new MutationObserver(scanSoon);
    observer.observe(document.documentElement, { childList: true, subtree: true, characterData: true });
    // Always poll, including a watcher started on /create before an SPA transition.
    const poll = setInterval(() => {
      if (handled) return stop();
      // v2.2.53 — extension vừa Reload/cập nhật: script cũ trên tab này mất kết nối ("Extension context invalidated") → dừng hẳn, nhắc F5.
      if (contextLost()) { stop(); showBanner('Extension vừa được tải lại/cập nhật — bấm F5 tải lại tab này để tool chạy tiếp (nếu phiếu đã Gửi, panel dùng Dò Ticket ID để lấy lại).', true); return; }
      window.postMessage({ source: 'op-ticket-probe-ask' }, '*');
      scan().catch(() => {});
    }, 500);
    if (capture) publishArm();
    window.postMessage({ source: 'op-ticket-probe-ask' }, '*');
    scan().catch(() => {});
    return {
      scan,
      createdTicket: () => Boolean(detected),
      alreadyStarted: () => Boolean(capture?.startedAt),
      async arm() {
        if (capture?.startedAt) return;
        const next = { orderId: expectedOrderId, startedAt: Date.now(), baselineIds: ticketRowCandidates().map(row => row.ticketId) };
        const result = await runtimeMessage({ type: 'TICKET_SUBMIT_STARTED', capture: next });
        if (!result?.ok) throw new Error(result?.error || 'Chưa lưu được trạng thái gửi để tự bắt phiếu.');
        capture = next;
        capturePersisted = true;
        publishArm();
        await sleep(0);
      },
      async disarm() {
        if (detected || handled) return;
        const result = await runtimeMessage({ type: 'TICKET_SUBMIT_STARTED', capture: { orderId: expectedOrderId, startedAt: 0 } });
        if (!result?.ok) throw new Error(result?.error || 'Chưa cập nhật được trạng thái gửi.');
        capture = null;
        capturePersisted = false;
        network.clear();
        publishArm();
      }
    };
  }

  function normalizeTicketOrderId(value) {
    return String(value == null ? '' : value).trim().toUpperCase();
  }

  (async () => {
    const context = await loadTicketContext();
    if (context?.savedTicket) {
      showBanner(`✓ Đã tự lưu Ticket ${context.savedTicket.ticketId} cho đơn ${context.savedTicket.orderId}.`);
      return;
    }
    if (!context?.draft) return;
    const capture = watchTicketId(context.draft, context);
    if (context.tabScoped) activeTicketCapture = capture;

    const isCreatePage = /\/ticket\/create(?:\/|$)/i.test(location.pathname);
    if (!isCreatePage) return;
    if (activeTicketCapture?.alreadyStarted()) {
      showBanner('Đơn đã bắt đầu gửi · đang tự bắt và lưu Ticket ID. Giữ tab này mở để tránh gửi trùng.');
      return;
    }
    const fillOptions = {
      allowAutoSubmit: context.tabScoped === true,
      tabScopeKnown: context.tabScopeKnown === true,
      attachmentTransport: context.attachmentTransport
    };
    // v2.2.47 — Side Panel bấm "Thử lại đính kèm": chỉ đẩy lại file thiếu trên form hiện tại rồi tự gửi tiếp.
    let retrying = false;
    chrome.runtime.onMessage.addListener((message, _sender, reply) => {
      if (message?.type !== 'OP_RETRY_ATTACH_ONLY') return;
      if (retrying || activeTicketCapture?.alreadyStarted?.() || !/\/ticket\/create(?:\/|$)/i.test(location.pathname)) { reply({ ok: false }); return; }
      retrying = true;
      reply({ ok: true });
      showBanner('Đang đẩy lại file đính kèm (không tải lại form)…');
      fillDraft(context.draft, context.attachments || [], { ...fillOptions, onlyAttach: true })
        .then(autofill => runtimeMessage({ type: 'TICKET_AUTOFILL_STATUS', autofill }).catch(() => {}))
        .catch(error => showBanner(`Đẩy lại file lỗi: ${error.message || error}`, true))
        .finally(() => { retrying = false; });
    });
    try {
      const autofill = await fillDraft(context.draft, context.attachments || [], fillOptions);
      runtimeMessage({ type: 'TICKET_AUTOFILL_STATUS', autofill }).catch(() => {});
    } catch (error) {
      console.error('[OnPoint TTS autofill]', error);
      showBanner(`Auto-fill lỗi: ${error.message || error}`, true);
    }
  })();
})();
