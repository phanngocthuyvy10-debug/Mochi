/* Panel v2.2.9 — Khiếu nại chỉ số theo đúng sàn đang mở ("ĐVVC không tới / lấy hàng trễ"):
   - TikTok Shop: FDR / LDR → 1 ticket TikTok (Thực hiện đơn hàng & Hậu cần → Đón và trả hàng (4PL) → Nhà cung cấp dịch vụ hậu cần
     chậm trễ nhận hàng), mô tả ≤500 ký tự, Order ID đại diện, đính kèm Excel toàn bộ đơn; tiktok_content.js tự điền, tự Gửi, tự lưu mã phiếu.
   - Shopee: FHR / LSR → file "<Brand>_Khiếu nại FHR_dd.mm.yyyy.xlsx" (14 cột, cột cuối =IF(RTS>Deadline,"Fail","OnTime")),
     1 ticket Người bán → Câu hỏi chung/ Vấn đề khác (≤999 ký tự) hoặc webform "Cập nhật sai trạng thái lấy hàng".
   Sàn = tab đang mở (seller-vn.tiktok.com / *.shopee.vn) → store vừa lấy; người dùng đổi được bằng nút TikTok | Shopee. */
(() => {
  const $c = id => document.getElementById(id);
  const escC = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const SHOPEE_TICKET_URL = 'https://help.shopee.vn/portal/webform/9e0e87184cf14246aabe6af0d78b2aa9?previousPage=other%20articles';
  const TIKTOK_TICKET_URL = 'https://seller-vn.tiktok.com/ticket/create?shop_region=VN';
  const XLSX_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
  const FHR_RECALC_URL = 'https://shopee.vn/m/tylegiaohangnhanhtinhlai';
  const SELLER_SERVICE_URL = 'https://seller-service.cs.shopee.vn/';
  /* Danh sách phiếu Shopee tool đã gửi + trạng thái đọc từ Seller Service (seller-service-probe.js → shopeeCaseStatus). */
  async function renderFollow() {
    const el = $c('claimFollow'); if (!el) return;
    const list = await globalThis.OPShopeePickup?.followList?.().catch(() => []) || [];
    const { shopeeCaseSeen } = await chrome.storage.local.get('shopeeCaseSeen');
    const stampF = v => { const d = new Date(v); return Number.isNaN(d.getTime()) ? '' : d.toLocaleString('vi-VN', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit' }); };
    el.innerHTML = `<p class="hint">Mở "Theo dõi phiếu" và đăng nhập tài khoản shop; tool tự đọc trạng thái phiếu.${shopeeCaseSeen?.at ? ` Lần đọc gần nhất ${escC(stampF(shopeeCaseSeen.at))}: ${shopeeCaseSeen.records} phiếu, khớp ${shopeeCaseSeen.matched}.` : ''}</p>
      ${list.length ? `<table class="pickup-follow"><tr><th>Mã phiếu</th><th>Form</th><th>Đơn</th><th>Trạng thái</th></tr>${list.slice(0, 15).map(t => `<tr><td>${escC(t.ticketId || 'chờ mã…')}</td><td>${escC(t.form)}</td><td>${escC(t.orderId)}${t.orders > 1 ? ` +${t.orders - 1}` : ''}<br><span class="muted">${escC(stampF(t.at))}</span></td><td>${t.status ? `<b>${escC(t.status.status || (t.status.code ? '#' + t.status.code : '?'))}</b>` : '<span class="muted">chưa đọc</span>'}</td></tr>`).join('')}</table>` : '<p class="muted">Chưa có phiếu Shopee nào do tool gửi.</p>'}`;
  }
  try { chrome.storage.onChanged.addListener((ch, area) => { if (area === 'local' && (ch.shopeeFollowTickets || ch.shopeeCaseStatus) && $c('claimFollowCard')?.open) renderFollow().catch(() => {}); }); } catch (_) {}
  async function renderPerformanceFollow(){
    const box=$c('claimPerformanceTickets');if(!box)return;
    const {performanceAppealHistory={}}=await chrome.storage.local.get('performanceAppealHistory');
    const rows=Object.values(performanceAppealHistory).sort((a,b)=>String(b.recordedAt).localeCompare(String(a.recordedAt))).slice(0,20);
    box.innerHTML='<summary>Ticket kháng nghị KPI · tự lưu vào Ticket Raise</summary>'+(rows.length?`<div class="cl-ticket-scroll"><table><thead><tr><th>Ticket</th><th>Sàn / KPI</th><th>Shop</th><th>Lưu Sheet</th></tr></thead><tbody>${rows.map(t=>`<tr><td>${escC(t.ticketId)}</td><td>${escC(t.platform==='TIKTOK'?'TikTok':'Shopee')} · ${escC(t.metric)}</td><td>${escC(t.opolloCode||t.shopName)}${t.shopCode?'<br><small>Shop Code '+escC(t.shopCode)+'</small>':''}</td><td>${t.syncStatus==='Synced'?'Đã lưu':'Đang chờ gửi'}</td></tr>`).join('')}</tbody></table></div>`:'<p class="hint">Khi gửi thành công và bắt được mã ticket, tool tự ghi vào tab Ticket Raise. Mất kết nối thì giữ lại và tự gửi tiếp.</p>');
  }
  try{chrome.storage.onChanged.addListener((c,area)=>{if(area==='local'&&c.performanceAppealHistory)renderPerformanceFollow().catch(()=>{});});}catch(_){}
  const CLAIM = {
    FHR: { name: 'giao hàng nhanh FHR', label: 'Khiếu nại FHR', title: 'Giao hàng nhanh' },
    LSR: { name: 'giao hàng trễ LSR', label: 'Khiếu nại LSR', title: 'Giao hàng trễ' },
    FDR: { name: 'Tỷ lệ gửi hàng nhanh (FDR)', label: 'Khiếu nại FDR', title: 'Gửi hàng nhanh' },
    LDR: { name: 'Tỷ lệ gửi hàng muộn (LDR)', label: 'Khiếu nại LDR', title: 'Gửi hàng muộn' }
  };
  const PLAT = {
    SHOPEE: { name: 'Shopee', metrics: ['FHR', 'LSR'], max: 999 },
    TIKTOK: { name: 'TikTok Shop', metrics: ['FDR', 'LDR'], max: 500 }
  };
  const HEAD = ['Shop ID', 'Channel Name', 'Metric', 'Order ID', 'Tracking ID', 'Violation Reason', 'Ready To Ship At', 'Deadline', 'Carrier', 'Period Start', 'Period End', 'Actual Handover Time (Platform)', 'SLA Rule'];
  const WIDTH = [11, 30, 8, 18, 19, 90, 18, 18, 12, 13, 13, 31, 34, 14];
  const HEAD_TT = ['Shop ID', 'Channel Name', 'Metric', 'Order ID', 'Tracking ID', 'Carrier', 'Order Created At', 'Deadline', 'Actual Handover Time (Platform)', 'Period Start', 'Period End', 'SLA Rule', 'Violation Reason'];
  const WIDTH_TT = [16, 30, 8, 22, 20, 16, 18, 18, 31, 13, 13, 34, 60];
  let onlyOnTime = true, lastSig = '', pickedRun = '', platPick = '';
  /* v2.2.9 — TikTok: folder ảnh bằng chứng (biên bản, ảnh kho chờ ĐVVC, tin nhắn shipper…). Tool chọn ngẫu nhiên tối đa 5 ảnh
     JPG/PNG < 5 MB, đính kèm cùng file Excel (TikTok nhận tối đa 6 file / ticket). Giữ trong bộ nhớ panel, không lưu ra ngoài. */
  const EVI_MAX = 5, EVI_BYTES = 5 * 1024 * 1024;
  let eviAll = [], eviPick = [], eviUrls = [];
  const shuffle = a => { a = [...a]; for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
  function pickEvidence() { eviUrls.forEach(u => URL.revokeObjectURL(u)); eviPick = shuffle(eviAll).slice(0, EVI_MAX); eviUrls = eviPick.map(f => URL.createObjectURL(f)); }
  const fileB64 = f => new Promise((ok, no) => { const r = new FileReader(); r.onload = () => ok(String(r.result).replace(/^data:[^,]*,/, '')); r.onerror = () => no(Error(`Không đọc được ảnh ${f.name}`)); r.readAsDataURL(f); });
  const platOf = run => { const p = String(run?.platform || '').toUpperCase(); return p === 'SHOPEE' || p === 'TIKTOK' ? p : ''; };
  const isTT = k => PLAT.TIKTOK.metrics.includes(k);
  const clip = (s, n) => { const t = String(s ?? '').replace(/\s+/g, ' ').trim(); return t.length <= n ? t : t.slice(0, Math.max(1, n - 1)).trimEnd() + '…'; };
  // Seller Center times are VN wall-clock strings ("2026-08-09 23:32:14") or epoch seconds; keep them as wall-clock for Excel.
  function wall(v) {
    if (v == null || v === '') return null;
    if (typeof v === 'number' || /^\d{9,13}$/.test(String(v))) { const n = Number(v); const d = new Date((n > 1e11 ? n : n * 1000) + 7 * 3600e3); return [d.getUTCFullYear(), d.getUTCMonth() + 1, d.getUTCDate(), d.getUTCHours(), d.getUTCMinutes(), d.getUTCSeconds()]; }
    const m = String(v).match(/^(\d{4})-(\d{2})-(\d{2})(?:[ T](\d{2}):(\d{2})(?::(\d{2}))?)?/); return m ? m.slice(1).map(x => Number(x || 0)) : null;
  }
  const serial = p => p ? (Date.UTC(p[0], p[1] - 1, p[2], p[3], p[4], p[5]) - Date.UTC(1899, 11, 30)) / 864e5 : null;
  const two = n => String(n).padStart(2, '0');
  // TikTok FDR: đơn tạo trước 18h → hạn 23:59:59 cùng ngày; từ 18h → 11:59:59 hôm sau (cùng luật với lib/op-sla.js).
  const fdrDue = created => { const p = wall(created); if (!p) return ''; const d = new Date(Date.UTC(p[0], p[1] - 1, p[2] + (p[3] >= 18 ? 1 : 0), p[3] >= 18 ? 11 : 23, 59, 59)); return `${d.getUTCFullYear()}-${two(d.getUTCMonth() + 1)}-${two(d.getUTCDate())} ${two(d.getUTCHours())}:59:59`; };
  // FHR: hạn = Fast handover due (sla_rule) — LSR: hạn = Ship by — FDR: luật 18h nếu sàn không trả hạn.
  const due = o => o.metric === 'FHR' && /^Fast handover due /.test(String(o.sla_rule || '')) ? String(o.sla_rule).replace(/^Fast handover due /, '') : o.deadline || (o.metric === 'FDR' ? fdrDue(o.created_at) : '');
  const verdict = o => { const a = serial(wall(o.rts_at)), b = serial(wall(due(o))); return a == null || b == null ? '' : a > b ? 'Fail' : 'OnTime'; };
  /* Sàn không xử lý đơn quá 30 ngày ("Đơn hàng hiện tại đã quá thời gian 30 ngày xử lý theo chính sách") → không đưa vào file / ticket.
     Ngày đơn = created_at; thiếu thì lấy 6 số đầu mã đơn Shopee (YYMMDD + có chữ). Mã TikTok toàn số nên không suy ngày từ mã. */
  const MAX_DAYS = 30;
  const placed = o => serial(wall(o.created_at)) ?? (m => m ? serial([2000 + +m[1], +m[2], +m[3], 0, 0, 0]) : null)(String(o.order_sn || o.order_id || '').toUpperCase().match(/^(\d{2})(\d{2})(\d{2})(?=[A-Z0-9]*[A-Z])[A-Z0-9]{6,14}$/));
  const tooOld = o => { const p = placed(o); return p != null && Math.floor(serial(wall(Date.now() / 1000))) - Math.floor(p) > MAX_DAYS; }; // theo ngày lịch giờ VN
  const sn = o => String((isTT(o.metric) ? (o.order_id || o.platform_order_id) : (o.order_sn || o.order_id)) || '').trim().toUpperCase();
  const validNo = (no, k) => isTT(k) ? /^\d{10,24}$/.test(no) : /^\d{6}[A-Z0-9]{6,14}$/.test(no);
  const brand = run => String(run.shopName || run.channel_name || 'Shop').replace(/\s*-\s*(shopee|tiktok( shop)?)\s*$/i, '').replace(/\b(official\s*store|official\s*shop|official|store)\b/gi, '').replace(/\s+/g, ' ').trim().replace(/[\\/:*?"<>|]/g, '') || 'Shop';
  const today = () => { const d = new Date(Date.now() + 7 * 3600e3); return `${two(d.getUTCDate())}.${two(d.getUTCMonth() + 1)}.${d.getUTCFullYear()}`; };
  const pctC = v => v == null ? '?' : (v * 100).toLocaleString('vi-VN', { maximumFractionDigits: 2 }) + '%';
  const dmyC = s => /^\d{4}-\d{2}-\d{2}/.test(String(s || '')) ? `${s.slice(8, 10)}/${s.slice(5, 7)}/${s.slice(0, 4)}` : String(s || '');

  function claimRows(data, k) {
    const seen = new Set(), all = [], old = [];
    for (const o of data?.orders || []) { if (o.metric !== k) continue; const no = sn(o); if (!validNo(no, k) || seen.has(no)) continue; seen.add(no); if (tooOld(o)) { old.push(o); continue; } all.push({ ...o, deadline: due(o), _no: no, _v: verdict(o) }); }
    all.sort((a, b) => (a._v === 'OnTime' ? 0 : 1) - (b._v === 'OnTime' ? 0 : 1) || String(a.deadline || '').localeCompare(String(b.deadline || '')));
    return { all, old, onTime: all.filter(o => o._v === 'OnTime') };
  }
  function fileName(run, k) { return `${brand(run)}_${CLAIM[k].label}_${today()}.xlsx`; }
  // Shop ID TikTok dài (> 15 số) → giữ dạng text để Excel không làm tròn.
  const shopCell = run => { const shop = Number(run.shopId); return Number.isFinite(shop) && String(run.shopId).length < 16 ? { t: 'n', v: shop } : { t: 's', v: String(run.shopId || '') }; };
  function workbook(run, k, rows) {
    const ws = {}, put = (r, c, cell) => { ws[XLSX.utils.encode_cell({ r, c })] = cell; };
    const tt = isTT(k), head = tt ? HEAD_TT : [...HEAD, CLAIM[k].label];
    head.forEach((h, c) => put(0, c, { t: 's', v: h }));
    rows.forEach((o, i) => {
      const r = i + 1, S = v => ({ t: 's', v: String(v || '') });
      const vals = tt
        ? [shopCell(run), S(run.channel_name || run.shopName), S(k), S(o._no), S(o.tracking_id), S(o.carrier), o.created_at, o.deadline, o.actual_handover_at, o.period_start, o.period_end, S(o.sla_rule), S(o.reason)]
        : [shopCell(run), S(run.channel_name || run.shopName), S(k), S(o._no), S(o.tracking_id), S(o.reason), o.rts_at, o.deadline, S(o.carrier), o.period_start, o.period_end, o.actual_handover_at, S(o.sla_rule)];
      vals.forEach((v, c) => { if (v && typeof v === 'object') return put(r, c, v); const n = serial(wall(v)); put(r, c, n == null ? { t: 's', v: String(v || '') } : { t: 'n', v: n, z: c === 9 || c === 10 ? 'mm-dd-yy' : 'm/d/yy h:mm' }); });
      if (!tt) put(r, 13, { t: 's', v: o._v, f: `IF(G${r + 1}>H${r + 1},"Fail","OnTime")` });
    });
    ws['!ref'] = XLSX.utils.encode_range({ s: { r: 0, c: 0 }, e: { r: Math.max(1, rows.length), c: head.length - 1 } });
    ws['!cols'] = (tt ? WIDTH_TT : WIDTH).map(w => ({ wch: w }));
    const wb = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb, ws, 'Sheet1'); return wb;
  }
  function claimTextTikTok(run, k, rows) {
    const m = (run.metrics || []).find(x => x.code === k), carriers = clip([...new Set(rows.map(o => o.carrier).filter(Boolean))].join(', '), 60);
    const build = shopLen => [
      `Shop đã sẵn sàng bàn giao đúng hạn nhưng ĐVVC tới lấy hàng trễ/không tới lấy, dẫn đến fail chỉ số ${CLAIM[k].name}. Lỗi phát sinh từ ĐVVC, không thuộc vận hành shop. TTS vui lòng xem xét và loại các đơn trong file đính kèm khỏi ${k} cho shop.`,
      `Shop: ${clip(run.shopName || run.channel_name || '', shopLen)}${run.shopId ? ` (Shop ID ${clip(run.shopId, 24)})` : ''}${run.shopCode ? ` · Shop Code ${clip(run.shopCode, 40)}` : ''}`,
      `${k} ${pctC(m?.value)}${m?.period_start ? ` · kỳ ${dmyC(m.period_start)} – ${dmyC(m.period_end)}` : ''}${carriers ? ` · ĐVVC: ${carriers}` : ''}`,
      `Số đơn: ${rows.length} (chi tiết trong file đính kèm)${eviPick.length ? ` · kèm ${eviPick.length} ảnh bằng chứng` : ''}`,
      `Order ID đại diện: ${rows[0]?._no || '-'}`
    ].join('\n');
    let t = build(80); if (t.length > PLAT.TIKTOK.max) t = build(30);
    if(t.length<=PLAT.TIKTOK.max)return t;
    const tail=t.split('\n').pop();return t.slice(0,t.lastIndexOf('\n')).slice(0,PLAT.TIKTOK.max-tail.length-1)+'\n'+tail;
  }
  function claimText(run, k, rows) {
    if (isTT(k)) return claimTextTikTok(run, k, rows);
    const m = (run.metrics || []).find(x => x.code === k), carriers = OPShopeeForm.clip([...new Set(rows.map(o => o.carrier).filter(Boolean))].join(', '), 120);
    const head = [`List đơn bên dưới seller đã bấm sẵn sàng bàn giao đúng hạn nhưng ĐVVC không lấy hết hàng dẫn đến fail chỉ số ${CLAIM[k].name}. Team xem xét và gỡ chỉ số ${k} cho seller nhé.`,
      `Shop: ${OPShopeeForm.clip(run.shopName || '', 140)} (Shop ID ${OPShopeeForm.clip(run.shopId || '', 24)})`,
      `${k} ${pctC(m?.value)}${m?.period_start ? ` · kỳ ${dmyC(m.period_start)} – ${dmyC(m.period_end)}` : ''}${carriers ? ` · ĐVVC: ${carriers}` : ''}`,
      `${rows.length} đơn (RTS trước hạn, chi tiết giờ sẵn sàng / hạn / giờ ĐVVC lấy trong file đính kèm):`];
    const lines = [...head]; let i = 0;
    const footer = n => [n ? `… và ${n} đơn khác trong file đính kèm.` : '', 'Cảm ơn Shopee!'].filter(Boolean).join('\n');
    for (; i < rows.length; i++) {
      const l = `${i + 1}. ${rows[i]._no}`;
      if ([...lines, l, footer(rows.length - i - 1)].join('\n').length > OPShopeeForm.MAX_TEXT) break;
      lines.push(l);
    }
    lines.push(footer(rows.length - i));
    return OPShopeeForm.description(lines.join('\n'), rows[0]?._no);
  }
  function download(run, k, rows) {
    const out = XLSX.write(workbook(run, k, rows), { bookType: 'xlsx', type: 'array' });
    const url = URL.createObjectURL(new Blob([out], { type: XLSX_TYPE }));
    const a = document.createElement('a'); a.href = url; a.download = fileName(run, k); document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 5000);
  }
  const norm = v => String(v || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]/g, '');
  // Chặn raise nhầm shop: chỉ chặn khi đọc được tên shop TikTok đang login và khác hẳn store của đơn.
  async function checkTikTokShop(run) {
    const shop = await chrome.runtime.sendMessage({ type: 'GET_LOGGED_IN_TIKTOK_SHOP' }).catch(() => null);
    const a = norm(shop?.name), b = norm(run.shopName || run.channel_name);
    if (shop?.ok && a && b && !a.includes(b) && !b.includes(a)) throw Error(`Shop TikTok đang đăng nhập là "${shop.name}", đơn thuộc "${run.shopName || run.channel_name}". Chuyển đúng shop rồi raise.`);
  }
  /* Same storage contract as the Ticket Assistant's "Mở form" (ticketTabPayloads / ticketOpenGroups): ticket_content.js (Shopee) /
     tiktok_content.js (TikTok) điền form + đính kèm file, background map mã phiếu vào Ticket Master. */
  async function raise(run, k, rows) {
    if (!rows.length) throw Error('Không có đơn để khiếu nại.');
    const tt = isTT(k), plat = tt ? 'tiktok' : 'shopee';
    const st = await chrome.storage.local.get(['handoverRun', 'ticketTabPayloads', 'ticketOpenGroups', 'handoverSessions', 'handoverSelectedSession']);
    if (st.handoverRun && !st.handoverRun.doneAt && (st.handoverRun.activeKey || (!st.handoverRun.paused && st.handoverRun.pending?.length))) throw Error('Tab Kháng nghị đang Auto raise. Chờ xong hoặc Tạm dừng rồi thử lại.');
    const groupKey = `claim|||${k}|||${run.shopId}|||${today()}`;
    const open = st.ticketOpenGroups?.[groupKey]; if (open && !['mapped', 'closed'].includes(open.status) && Date.now() - Date.parse(open.openedAt || 0) < 3600e3) throw Error(`Ticket khiếu nại này vừa được mở. Kiểm tra tab form ${tt ? 'TikTok' : 'Shopee'}.`);
    if (tt) await checkTikTokShop(run);
    const name = fileName(run, k), b64 = XLSX.write(workbook(run, k, rows), { bookType: 'xlsx', type: 'base64' });
    const size = Math.floor(b64.length * 3 / 4); if (size > 9.5 * 1024 * 1024) throw Error('File khiếu nại quá 10 MB — lọc bớt đơn.');
    const photos = tt ? await Promise.all(eviPick.map(async f => ({ name: f.name, type: f.type || 'image/jpeg', size: f.size, base64: await fileB64(f) }))) : [];
    const carriers = [...new Set(rows.map(o => o.carrier).filter(Boolean))].join(', ');
    const channel = run.channel_name || run.shopName || '';
    const metric = (run.metrics || []).find(m => m.code === k);
    const claimMeta = { metric: k, shopId: String(run.shopId || ''), shopName: run.shopName || channel, shopCode: run.shopCode || '', channelCode: run.channel_code || '', opolloCode: run.business_code || '', periodStart: metric?.period_start || '', periodEnd: metric?.period_end || '', file: name, orders: rows.length };
    const draft = { createdAt: new Date().toISOString(), issueType: `claim_${k.toLowerCase()}_pickup`, mode: 'claim', groupKey, batchChannelKey: '', channel, carrier: carriers, warehouse: run.warehouse || '', cnncCodes: [],
      representativeOrderId: rows[0]._no, platform: plat, text: claimText(run, k, rows), claim: claimMeta,
      ...(tt ? {} : { shopeeEmail: String(Object.values(st.handoverSessions || {}).find(s => s.platform === 'shopee')?.shopeeEmail || 'operation@onpoint.vn'), shopeeIssue: OPShopeeForm.ISSUE }),
      rows: rows.map(o => ({ orderId: o._no, orderNo: o._no, cnnc: '', channel, carrier: o.carrier || '', platform: tt ? 'TIKTOK' : 'SHOPEE', status: `${CLAIM[k].label}${o._v ? ` · ${o._v}` : ''}`, orderDate: o.created_at || '', slaAt: o.deadline || '', trackingId: o.tracking_id || '', warehouse: run.warehouse || '', sourceFile: name, _original: { ClaimMetric: k, ReadyToShipAt: o.rts_at || '', Deadline: o.deadline || '', ActualHandover: o.actual_handover_at || '', ViolationReason: String(o.reason || '').slice(0, 300) } })) };
    const tab = await chrome.tabs.create({ url: 'about:blank', active: false });
    const batchId = crypto.randomUUID();
    await chrome.storage.local.set({ ticketTabPayloads: { ...(st.ticketTabPayloads || {}), [String(tab.id)]: { batchId, groupKey, draft, attachments: [{ name, type: XLSX_TYPE, size, base64: b64 }, ...photos], createdAt: new Date().toISOString() } },
      ticketOpenGroups: { ...(st.ticketOpenGroups || {}), [groupKey]: { batchId, tabId: tab.id, status: 'opening', channel, carrier: carriers, warehouse: draft.warehouse, cnncCodes: [], openedAt: new Date().toISOString() } } });
    // v2.2.9 — TikTok chạy ở tab nền (tự điền, tự Gửi); Shopee cần tick "Tôi đồng ý" nên mở lên trước.
    await chrome.tabs.update(tab.id, { url: tt ? TIKTOK_TICKET_URL : SHOPEE_TICKET_URL, active: !tt });
    message(`Đã mở form ${tt ? 'TikTok' : 'Shopee'} "${CLAIM[k].label}" (${rows.length} đơn, file ${name}${photos.length ? ` + ${photos.length} ảnh bằng chứng` : ''}). ${tt ? 'Đang chạy ở tab nền — tool tự điền, đính kèm và gửi; bạn cứ làm việc ở tab khác, đừng đóng tab form.' : 'Tool tự điền, đính kèm và gửi; giữ tab mở tới khi có mã phiếu.'}`);
  }
  /* v2.2.4 — Shopee: cùng file Excel khiếu nại nhưng gửi qua webform "[Người bán] Khiếu nại cập nhật sai trạng thái lấy hàng"
     (lib/op-shopee-pickup.js): mã đơn đại diện + Danh sách đơn hàng + Mô tả thêm ngắn; tự Gửi, tự lưu mã phiếu. */
  async function raiseStatus(run, k, rows) {
    if (!rows.length) throw Error('Không có đơn để khiếu nại.');
    const name = fileName(run, k), base64 = XLSX.write(workbook(run, k, rows), { bookType: 'xlsx', type: 'base64' });
    const metric = (run.metrics || []).find(m => m.code === k);
    return OPShopeePickup.raise({ choice: 'status:0', channel: run.channel_name || run.shopName || '', shopId: String(run.shopId || ''), warehouse: run.warehouse || '',
      claim: { metric: k, shopId: String(run.shopId || ''), shopName: run.shopName || run.channel_name || '', shopCode: run.shopCode || '', channelCode: run.channel_code || '', opolloCode: run.business_code || '', periodStart: metric?.period_start || '', periodEnd: metric?.period_end || '', file: name, orders: rows.length },
      groupKey: `claim|||${k}-status|||${run.shopId}|||${today()}`, status: `${CLAIM[k].label} · form trạng thái lấy hàng`,
      reason: `Seller đã sẵn sàng bàn giao đúng hạn nhưng ĐVVC cập nhật lấy hàng trễ/sai, làm fail chỉ số ${k}`,
      file: { name, type: XLSX_TYPE, size: Math.floor(base64.length * 3 / 4), base64 },
      rows: rows.map(o => ({ orderId: o._no, trackingId: o.tracking_id || '', carrier: o.carrier || '', orderDate: o.created_at || '', slaAt: o.deadline || '', warehouse: run.warehouse || '',
        _original: { ClaimMetric: k, ReadyToShipAt: o.rts_at || '', Deadline: o.deadline || '', ActualHandover: o.actual_handover_at || '', ViolationReason: String(o.reason || '').slice(0, 300) } })) });
  }
  // Sàn của tab đang mở: TikTok Seller Center / Shopee (Kênh Người bán, help, shopee.vn). '' khi tab khác.
  async function tabPlatform() {
    try {
      const [t] = await chrome.tabs.query({ active: true, lastFocusedWindow: true }); const u = String(t?.url || t?.pendingUrl || '');
      if (/^https:\/\/seller-vn\.tiktok\.com\//.test(u)) return 'TIKTOK';
      if (/^https:\/\/([^/]+\.)?shopee\.vn\//.test(u)) return 'SHOPEE';
    } catch (_) {}
    return '';
  }
  const INFO = {
    TIKTOK: ['1 ticket / chỉ số. Chủ đề: Thực hiện đơn hàng &amp; Hậu cần → Đón và trả hàng (4PL) → Nhà cung cấp dịch vụ hậu cần chậm trễ nhận hàng.',
      'Đính kèm Excel toàn bộ đơn, mô tả ≤500 ký tự kèm Order ID đại diện. Tool tự điền, tự Gửi và lưu mã phiếu vào Ticket Master.',
      `Ảnh bằng chứng (không bắt buộc): chọn 1 folder, tool lấy ngẫu nhiên tối đa ${EVI_MAX} ảnh JPG/PNG &lt; 5 MB và đính kèm cùng Excel (tối đa 6 file / ticket).`,
      'Đối chiếu nguyên nhân ĐVVC trước khi gửi; TikTok có thể yêu cầu bổ sung bằng chứng.', `Đơn quá ${MAX_DAYS} ngày được bỏ khỏi danh sách.`],
    SHOPEE: ['1 ticket / chỉ số: Người bán → Câu hỏi chung/ Vấn đề khác. Đính kèm Excel toàn bộ đơn, nội dung ≤999 ký tự.',
      '"OnTime" = Ready To Ship ≤ Deadline. Đối chiếu nguyên nhân ĐVVC trước khi gửi; Shopee có thể yêu cầu bổ sung bằng chứng.',
      'Có thể gửi cùng file qua webform "Cập nhật sai trạng thái lấy hàng".', `Đơn quá ${MAX_DAYS} ngày được bỏ khỏi danh sách.`]
  };
  async function render() {
    const box = $c('claimBox'); if (!box) return;
    let data = null; try { data = await chrome.runtime.sendMessage({ type: 'EXPORT' }); if (data?.error) data = null; } catch (_) {}
    let runs = []; try { runs = (await chrome.runtime.sendMessage({ type: 'CLAIM_RUNS' }))?.runs || []; } catch (_) {}
    runs = runs.map(r => ({ ...r, platform: platOf(r) || 'SHOPEE' }));
    const auto = await tabPlatform() || platOf(data?.run) || runs[0]?.platform || 'SHOPEE';
    const plat = platPick || auto, P = PLAT[plat];
    document.body.dataset.claimPlat = plat;
    const count = r => P.metrics.reduce((n, k) => n + (Number(r[k.toLowerCase()]) || 0), 0);
    const mine = runs.filter(r => r.platform === plat);
    if (platOf(data?.run) !== plat) data = null;
    const hasClaim = d => (d?.orders || []).some(o => P.metrics.includes(o.metric));
    // v2.2.7 — chọn store bất kỳ đã lấy (không chỉ store lấy sau cùng); mặc định store sau cùng nếu có đơn lỗi.
    const pickId = pickedRun && mine.some(r => r.id === pickedRun) ? pickedRun : (!hasClaim(data) ? (mine.find(r => count(r) > 0) || (!data ? mine[0] : null))?.id : '');
    if (pickId && pickId !== data?.run?.id) { try { const other = await chrome.runtime.sendMessage({ type: 'CLAIM_EXPORT', runId: pickId }); if (other?.ok) data = other; } catch (_) {} }
    const run = data?.run;
    const parts = run ? P.metrics.map(k => ({ k, ...claimRows(data, k) })).filter(p => p.all.length || p.old.length) : [];
    const sig = JSON.stringify([plat, platPick, run?.id, parts.map(p => [p.k, p.all.length, p.onTime.length, p.old.length]), onlyOnTime, mine.map(r => [r.id, count(r)]), eviAll.length, eviUrls]); if (sig === lastSig) return; lastSig = sig;
    const seg = `<div class="seg" role="group" aria-label="Sàn">${['TIKTOK', 'SHOPEE'].map(p => `<button type="button" data-claim-plat="${p}" aria-pressed="${p === plat}">${p === 'TIKTOK' ? 'TikTok' : 'Shopee'}</button>`).join('')}</div>`;
    const head = `<div class="cl-head"><div><h3>Khiếu nại ${P.metrics.join(' / ')}</h3><p class="cl-sub">${escC(P.name)} · ĐVVC lấy hàng trễ / không tới lấy</p></div>${seg}</div>`;
    const stamp = at => new Date(at).toLocaleString('vi-VN', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
    const picker = mine.length ? `<label class="cl-field">Store<select id="claimRun">${mine.map(r => `<option value="${escC(r.id)}" ${r.id === run?.id ? 'selected' : ''}>${escC(r.shopName || r.shopId)} · ${count(r)} đơn lỗi · ${escC(stamp(r.at))}</option>`).join('')}${run && !mine.some(r => r.id === run.id) ? `<option value="" selected>${escC(run.shopName || run.shopId || 'Store vừa lấy')}</option>` : ''}</select></label>` : '';
    // Lối tắt Shopee luôn hiện: trang FHR tính lại (tool tự đọc đơn) + Seller Service (tool tự đọc trạng thái phiếu).
    const links = plat === 'SHOPEE' ? `<div class="cl-links"><button type="button" data-claim-open="${FHR_RECALC_URL}">FHR tính lại ↗<small>shopee.vn/m/tylegiaohangnhanhtinhlai</small></button><button type="button" data-claim-open="${SELLER_SERVICE_URL}">Theo dõi phiếu ↗<small>seller-service.cs.shopee.vn</small></button></div>
      <details class="cl-info" id="claimFollowCard"><summary>Phiếu Shopee đã raise</summary><div id="claimFollow"><p class="muted">Đang tải…</p></div></details>` : '';
    const info = `${links}<details class="cl-info"><summary>Cách hoạt động</summary><ul>${INFO[plat].map(x => `<li>${x}</li>`).join('')}</ul></details>`;
    const bind = () => {
      box.querySelectorAll('[data-claim-plat]').forEach(b => b.onclick = () => { platPick = b.dataset.claimPlat === auto ? '' : b.dataset.claimPlat; pickedRun = ''; lastSig = ''; render().catch(() => {}); });
      const sel = $c('claimRun'); if (sel) sel.onchange = e => { pickedRun = e.target.value; lastSig = ''; render().catch(() => {}); };
      box.querySelectorAll('[data-claim-open]').forEach(b => b.onclick = () => chrome.tabs.create({ url: b.dataset.claimOpen, active: true }));
      if ($c('claimFollowCard')) $c('claimFollowCard').ontoggle = e => { if (e.target.open) renderFollow().catch(() => {}); };
    };
    box.hidden = false;
    if (!parts.length) {
      const empty = !mine.length && !run ? `Chưa lấy dữ liệu store ${escC(P.name)} nào. Vào tab Lấy dữ liệu → lấy store; đơn lỗi ${P.metrics.join('/')} sẽ hiện ở đây.` : `${escC(run?.shopName || 'Store đang chọn')} không có đơn lỗi ${P.metrics.join('/')} (KPI đạt hoặc chưa lấy đơn lỗi).${mine.length > 1 ? ' Chọn store khác ở trên.' : ''}`;
      box.innerHTML = `${head}${picker}<p class="cl-empty">${empty}</p>${info}`;
      bind(); return;
    }
    const shopee = plat === 'SHOPEE', pick = p => shopee && onlyOnTime ? p.onTime : p.all;
    const evidence = shopee ? '' : `<div class="cl-evi">
        <div class="cl-evi-head"><b>Ảnh bằng chứng</b><span class="muted">${eviPick.length ? `${eviPick.length}/${EVI_MAX} ảnh · từ ${eviAll.length} ảnh hợp lệ` : 'Không bắt buộc · tăng sức thuyết phục'}</span>${eviAll.length > EVI_MAX ? '<button type="button" class="cl-link" id="claimEviShuffle">Random lại</button>' : ''}${eviAll.length ? '<button type="button" class="cl-link" id="claimEviClear">Bỏ</button>' : ''}</div>
        ${eviPick.length ? `<div class="cl-thumbs">${eviPick.map((f, i) => `<figure title="${escC(f.name)}"><img src="${eviUrls[i]}" alt=""><button type="button" data-evi-rm="${i}" aria-label="Bỏ ảnh">×</button></figure>`).join('')}</div>` : ''}
        <label class="cl-upload"><input type="file" id="claimEvidence" webkitdirectory directory multiple accept=".jpg,.jpeg,.png,image/jpeg,image/png"><b>${eviAll.length ? 'Chọn folder khác' : 'Chọn folder ảnh bằng chứng'}</b><small>Biên bản, ảnh hàng chờ lấy, tin nhắn shipper… Tool lấy ngẫu nhiên tối đa ${EVI_MAX} ảnh JPG/PNG &lt; 5 MB, đính kèm cùng file Excel.</small></label>
      </div>`;
    box.innerHTML = `${head}${picker}
      ${shopee ? `<label class="check cl-check"><input type="checkbox" id="claimOnlyOnTime" ${onlyOnTime ? 'checked' : ''}> Chỉ đơn OnTime (RTS ≤ hạn)</label>` : ''}${evidence}
      ${parts.map(p => { const rows = pick(p), m = (run.metrics || []).find(x => x.code === p.k), text = rows.length ? claimText(run, p.k, rows) : '';
        return `<div class="cl-metric">
        <div class="cl-mhead"><b>${escC(p.k)}</b><span>${escC(CLAIM[p.k].title)}</span>${m?.value != null ? `<span class="pill">${escC(pctC(m.value))}</span>` : ''}</div>
        <div class="cl-stats"><span><b>${rows.length}</b> đơn sẽ gửi</span>${shopee ? `<span>${p.onTime.length} OnTime · ${p.all.length - p.onTime.length} Fail</span>` : ''}${p.old.length ? `<span class="muted" title="Sàn không xử lý đơn quá ${MAX_DAYS} ngày">bỏ ${p.old.length} đơn quá ${MAX_DAYS} ngày</span>` : ''}</div>
        <div class="cl-actions"><button class="primary" data-claim-raise="${p.k}" ${rows.length ? '' : 'disabled'}>Raise ticket ${shopee ? 'Shopee' : 'TikTok'}</button><button data-claim-dl="${p.k}" ${rows.length ? '' : 'disabled'}>Tải Excel</button></div>
        ${shopee ? `<button class="cl-link" data-claim-status="${p.k}" ${rows.length ? '' : 'disabled'} title="Webform [Người bán] Khiếu nại cập nhật sai trạng thái lấy hàng · đơn đại diện + file danh sách">Hoặc gửi qua form "Cập nhật sai trạng thái lấy hàng" →</button>` : ''}
        ${rows.length ? `<details class="cl-preview"><summary>Xem nội dung ticket <span class="muted">${text.length}/${P.max} ký tự</span></summary><textarea rows="7" readonly>${escC(text)}</textarea></details>` : ''}</div>`; }).join('')}
      ${info}<details id="claimPerformanceTickets" class="cl-preview"></details>`;
    bind();
    await renderPerformanceFollow();
    if ($c('claimOnlyOnTime')) $c('claimOnlyOnTime').onchange = e => { onlyOnTime = e.target.checked; render().catch(() => {}); };
    const redraw = () => { lastSig = ''; render().catch(() => {}); };
    if ($c('claimEvidence')) $c('claimEvidence').onchange = e => {
      const files = [...(e.target.files || [])].filter(f => /\.(jpe?g|png)$/i.test(f.name) && /^image\/(jpeg|png)$|^$/.test(f.type || ''));
      const ok = files.filter(f => f.size > 0 && f.size < EVI_BYTES);
      if (!ok.length) return message(files.length ? 'Ảnh trong folder đều ≥ 5 MB — TikTok không nhận.' : 'Folder không có ảnh JPG/PNG.', true);
      eviAll = ok; pickEvidence(); if (files.length > ok.length) message(`Bỏ ${files.length - ok.length} ảnh ≥ 5 MB.`); redraw();
    };
    if ($c('claimEviShuffle')) $c('claimEviShuffle').onclick = () => { pickEvidence(); redraw(); };
    if ($c('claimEviClear')) $c('claimEviClear').onclick = () => { eviAll = []; pickEvidence(); redraw(); };
    box.querySelectorAll('[data-evi-rm]').forEach(b => b.onclick = () => { const f = eviPick[+b.dataset.eviRm]; eviAll = eviAll.filter(x => x !== f); URL.revokeObjectURL(eviUrls[+b.dataset.eviRm]); eviUrls = eviUrls.filter((_, i) => i !== +b.dataset.eviRm); eviPick = eviPick.filter(x => x !== f); redraw(); });
    const rowsOf = k => pick(parts.find(x => x.k === k));
    box.querySelectorAll('[data-claim-dl]').forEach(b => b.onclick = () => { try { download(run, b.dataset.claimDl, rowsOf(b.dataset.claimDl)); } catch (e) { message(e.message, true); } });
    box.querySelectorAll('[data-claim-status]').forEach(b => b.onclick = async () => { b.disabled = true; try { const r = await raiseStatus(run, b.dataset.claimStatus, rowsOf(b.dataset.claimStatus)); message(`Đã mở form "${r.form}" (${r.orders} đơn, file ${r.file}). Tool tự điền, tải file và Gửi; giữ tab mở tới khi có mã phiếu.`); } catch (e) { message(e.message, true); } finally { b.disabled = false; } });
    box.querySelectorAll('[data-claim-raise]').forEach(b => b.onclick = async () => { b.disabled = true; try { await raise(run, b.dataset.claimRaise, rowsOf(b.dataset.claimRaise)); } catch (e) { message(e.message, true); } finally { b.disabled = false; } });
  }
  globalThis.OPClaim = { render, workbook, claimText, claimRows, fileName, verdict, raise, raiseStatus, tooOld, fdrDue, MAX_DAYS, METRICS: { SHOPEE: PLAT.SHOPEE.metrics, TIKTOK: PLAT.TIKTOK.metrics } };
  render().catch(() => {});
  // Đổi tab TikTok ↔ Shopee thì khối khiếu nại đổi theo (trừ khi người dùng đã chọn tay).
  const rerender = () => { if (!platPick) render().catch(() => {}); };
  try { chrome.tabs.onActivated.addListener(rerender); chrome.tabs.onUpdated.addListener((_, ch, t) => { if (t?.active && ch.url) rerender(); }); chrome.windows?.onFocusChanged?.addListener(rerender); } catch (_) {}
  setInterval(() => { if (document.visibilityState === 'visible' && document.body.dataset.role === 'ticket' && document.body.dataset.tsub === 'claim') render().catch(() => {}); }, 10000);
})();
