// v2.2.9 — nhúng trong tab Kháng nghị của panel chính: ẩn header riêng (styles.css · html.embedded).
if (window.top !== window) document.documentElement.classList.add('embedded');
const TIKTOK_TICKET_URL = 'https://seller-vn.tiktok.com/ticket/create?shop_region=VN';
const SHOPEE_TICKET_URL = 'https://help.shopee.vn/portal/webform/9e0e87184cf14246aabe6af0d78b2aa9?previousPage=other%20articles';
const DEFAULT_SHOPEE_EMAIL = 'operation@onpoint.vn';
const DEFAULT_SHOPEE_ISSUE = OPShopeeForm.ISSUE;
const DEFAULT_GOOGLE_SYNC_URL = '';
const GOOGLE_TICKET_MASTER_URL = 'https://docs.google.com/spreadsheets/d/17z0CJVVsAAxxYyUDYSEgqI2Clo5w2jO6P-s6SHSFlZg/edit?usp=sharing';
let activePlatform = 'tiktok';
const OUTPUT_HEADERS = [
  'Platform Order ID',
  'Delivery Platform',
  'Channel Name',
  'Order Date',
  'SLA Date',
  'Tracking No'
];

const ALIASES = {
  platformOrderId: ['platform order id', 'platform orderid', 'platform_order_id'],
  orderNo: ['order no', 'order number', 'order id', 'orderid', 'order code', 'ordercode', 'order ref code', 'mã đơn hàng', 'ma don hang'],
  channel: ['channel name', 'channel_name', 'opollo channel name', 'shop name', 'store name', 'store', 'channel'],
  carrier: ['delivery platform', 'delivery partner', 'logistics provider', 'carrier', 'đvvc', 'dvvc'],
  platform: ['platform', 'platform name', 'sales platform', 'marketplace'],
  status: ['order status', 'status', 'warehouse status', 'delivery completion status'],
  orderDate: ['order date', 'order created', 'platform created at', 'created at', 'order created platform'],
  slaAt: ['sla date', 'sla deadline', 'firstmile sla deadline', 'dispatch sla'],
  trackingId: ['tracking no', 'tracking code', 'tracking id', 'tracking number', 'ship code'],
  warehouse: ['warehouse branch', 'wh branch', 'ffm group wh branch', 'warehouse', 'fc', 'fulfillment center'],
  cnnc: ['cnnc', 'mã cnnc', 'ma cnnc', 'cnnc code', 'channel nickname code', 'channel nick name code', 'mã đầu đơn', 'ma dau don', 'order prefix', 'prefix', 'preflix'],
  sourceFile: ['source file']
};

let sourceHeaders = [];
let sourceFileName = '';
let rawRows = [];
let importedRawCount = 0;
let eligibleRows = [];
let queue = [];
let currentDraft = null;
let ticketLog = [];
let evidenceFiles = [];
let evidenceCandidates = [];
let selectedChannelKey = 'all';
let activeChannelBatchKey = '';
let ticketOpenGroups = {};
let googleSyncUrl = DEFAULT_GOOGLE_SYNC_URL;
let lastAutoMapHandledKey = '';

function platformLabel() {
  return activePlatform === 'shopee' ? 'SHOPEE' : 'TIKTOK';
}

function ticketUrl() {
  return activePlatform === 'shopee' ? (OPShopeePickup.parse(shopeeFormChoice())?.form.url || SHOPEE_TICKET_URL) : TIKTOK_TICKET_URL; // v2.2.4: form lấy hàng theo lựa chọn
}

function renderPlatformView() {
  document.documentElement.dataset.plat = activePlatform; // v2.2.9 — màu theo sàn (styles.css)
  document.querySelectorAll('.platform-tab').forEach((button) => {
    button.classList.toggle('active', button.dataset.platform === activePlatform);
  });
  $('platformRule').textContent = platformLabel();
  $('shopeeFields').hidden = activePlatform !== 'shopee';
  $('tiktokStep4Guide').hidden = activePlatform !== 'tiktok';
  if (activePlatform === 'shopee') {
    if (!$('shopeeEmail').value.trim()) $('shopeeEmail').value = DEFAULT_SHOPEE_EMAIL;
    $('shopeeIssue').value = DEFAULT_SHOPEE_ISSUE;
    syncShopeeFormView(); // v2.2.4
  }
  const mode = $('ticketMode');
  mode.innerHTML = activePlatform === 'shopee'
    ? '<option value="shopee_all" selected>1 ticket cho toàn bộ Channel</option><option value="shopee_channel">1 ticket / từng Channel Name</option>'
    : '<option value="group" selected>1 Channel + ĐVVC + WH / ticket — 1 Order ID đại diện</option><option value="single">1 đơn / ticket</option>';
  globalThis.OPHandoverPanel?.renderPlatform();
}

async function switchPlatform(platform) {
  activePlatform = platform === 'shopee' ? 'shopee' : 'tiktok';
  rawRows = [];
  importedRawCount = 0;
  eligibleRows = [];
  queue = [];
  currentDraft = null;
  selectedChannelKey = 'all';
  activeChannelBatchKey = '';
  ticketOpenGroups = {};
  await chrome.storage.local.set({ activePlatform });
  await removeBacklogStorage([
    'queueRows', 'queueSourceFileName', 'queueRawCount', 'currentDraft',
    'currentAttachments', 'ticketTabPayloads', 'ticketBatchEvidence',
    'ticketOpenGroups', 'detectedTicketId'
  ]);
  renderPlatformView();
  renderDraft();
  renderDataset();
}

async function removeBacklogStorage(keys) {
  const protectedKeys = ['ticketTabPayloads', 'ticketBatchEvidence', 'ticketOpenGroups'];
  const list = Array.isArray(keys) ? keys : [keys];
  await chrome.storage.local.remove(list.filter(key => !protectedKeys.includes(key)));
  if (list.some(key => protectedKeys.includes(key))) {
    const response = await sendRuntimeMessage({ type: 'CLEAR_BACKLOG_TICKET_STATE' });
    if (!response?.ok) throw new Error(response?.error || 'Không xóa được trạng thái backlog.');
  }
}

const $ = (id) => document.getElementById(id);
const encoder = new TextEncoder();
const WAREHOUSE_FFM_OPTIONS = [
  { id: 'warehouseTNSL', value: 'TNSL' },
  { id: 'warehouseTOLL', value: 'TOLL' },
  { id: 'warehouseMCL', value: 'MCL' }
];

function collectWarehouseSelection() {
  return WAREHOUSE_FFM_OPTIONS
    .filter((option) => $(option.id)?.checked)
    .map((option) => option.value);
}

function renderWarehouseSelectionSummary() {
  const selected = collectWarehouseSelection();
  const summary = $('warehouseSelectionSummary');
  if (!summary) return;
  summary.classList.remove('error');
  if (!selected.length) {
    summary.textContent = 'Chưa chọn kho — phải chọn ít nhất 1 kho.';
    summary.classList.add('error');
  } else if (selected.length === WAREHOUSE_FFM_OPTIONS.length) {
    summary.textContent = 'Đang chọn cả 3 kho.';
  } else {
    summary.textContent = `Sẽ Export: ${selected.join(' + ')}.`;
  }
}

function applyWarehouseSelection(values) {
  const selected = new Set(
    (Array.isArray(values)
      ? values
      : WAREHOUSE_FFM_OPTIONS.map((option) => option.value)
    ).map((value) => String(value || '').trim().toUpperCase())
  );
  for (const option of WAREHOUSE_FFM_OPTIONS) {
    const input = $(option.id);
    if (input) input.checked = selected.has(option.value);
  }
  renderWarehouseSelectionSummary();
}

async function persistWarehouseSelection() {
  const warehouses = collectWarehouseSelection();
  await chrome.storage.local.set({ pbiWarehouseSelection: warehouses });
  return warehouses;
}

function normalize(value) {
  return String(value ?? '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/đ/gi, 'd')
    .trim().toLowerCase()
    .replace(/[^a-z0-9]+/g, ' ')
    .replace(/\s+/g, ' ');
}

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>'"]/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;'
  }[c]));
}

function sanitizeMarketplaceMessage(value) {
  return String(value ?? '')
    .split(/\r?\n/)
    .filter((line) => {
      const normalizedLine = normalize(line);
      return !/(^| )(cnnc|ma cnnc|ma dau don|order prefix|prefix|preflix)( |$)/.test(normalizedLine);
    })
    .join('\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

function csvCell(value) {
  let s = String(value ?? '');
  if (/^[\s\u0000-\u001f]*[=+\-@]/.test(s) || /^[\t\r\n]/.test(s)) s = "'" + s;
  return /[",\n\r;]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

function detectDelimiter(firstLine) {
  const counts = [',', ';', '\t'].map((delimiter) => {
    let quoted = false;
    let count = 0;
    for (let i = 0; i < firstLine.length; i++) {
      if (firstLine[i] === '"') quoted = !quoted;
      else if (!quoted && firstLine[i] === delimiter) count++;
    }
    return [delimiter, count];
  });
  counts.sort((a, b) => b[1] - a[1]);
  return counts[0][1] ? counts[0][0] : ',';
}

function parseCSV(text) {
  const clean = String(text || '').replace(/^\uFEFF/, '');
  const firstLine = clean.split(/\r?\n/, 1)[0] || '';
  const delimiter = detectDelimiter(firstLine);
  const rows = [];
  let row = [];
  let cell = '';
  let quoted = false;

  for (let i = 0; i < clean.length; i++) {
    const c = clean[i];
    const next = clean[i + 1];
    if (c === '"' && quoted && next === '"') {
      cell += '"';
      i++;
    } else if (c === '"') {
      quoted = !quoted;
    } else if (c === delimiter && !quoted) {
      row.push(cell);
      cell = '';
    } else if ((c === '\n' || c === '\r') && !quoted) {
      if (c === '\r' && next === '\n') i++;
      row.push(cell);
      cell = '';
      if (row.some((v) => String(v).trim() !== '')) rows.push(row);
      row = [];
    } else {
      cell += c;
    }
  }
  if (cell.length || row.length) {
    row.push(cell);
    if (row.some((v) => String(v).trim() !== '')) rows.push(row);
  }
  if (!rows.length) return { headers: [], rows: [] };

  const headers = rows[0].map((header, index) => String(header || `Column ${index + 1}`).trim());
  const objects = rows.slice(1).map((values) => Object.fromEntries(headers.map((header, index) => [header, values[index] ?? ''])));
  return { headers, rows: objects };
}

async function parseInputFile(file) {
  if (/\.csv$/i.test(file.name)) return parseCSV(await file.text());
  if (!/\.(xlsx|xls)$/i.test(file.name)) {
    throw new Error('Chỉ hỗ trợ file Power BI dạng .xlsx, .xls hoặc .csv.');
  }
  if (typeof XLSX === 'undefined') {
    throw new Error('Không tải được bộ đọc Excel của extension.');
  }

  const workbook = XLSX.read(await file.arrayBuffer(), {
    type: 'array',
    cellDates: false
  });
  const sheetName = workbook.SheetNames[0];
  if (!sheetName) throw new Error('File Excel không có sheet dữ liệu.');
  const matrix = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], {
    header: 1,
    defval: '',
    raw: false,
    blankrows: false
  });
  if (!matrix.length) return { headers: [], rows: [] };

  const headers = matrix[0].map((header, index) =>
    String(header || `Column ${index + 1}`).trim()
  );
  const rows = matrix.slice(1).map((values) =>
    Object.fromEntries(headers.map((header, index) => [header, values[index] ?? '']))
  );
  return { headers, rows };
}

function detectColumns(headers) {
  const normalized = new Map(headers.map((header) => [normalize(header), header]));
  const result = {};
  for (const [key, aliases] of Object.entries(ALIASES)) {
    let found = aliases.map(normalize).find((alias) => normalized.has(alias));
    if (!found) {
      found = [...normalized.keys()].find((header) => aliases.some((alias) => {
        const a = normalize(alias);
        return header.includes(a);
      }));
    }
    result[key] = found ? normalized.get(found) : null;
  }
  if (result.platform && normalize(result.platform).includes('delivery platform')) {
    result.platform = null;
  }
  return result;
}

function parseDate(value) {
  if (value instanceof Date && !Number.isNaN(value.getTime())) return value;
  const raw = String(value ?? '').trim();
  if (!raw) return null;

  if (/^\d+(\.\d+)?$/.test(raw)) {
    const serial = Number(raw);
    if (serial > 25000 && serial < 100000) {
      const excelEpoch = Date.UTC(1899, 11, 30);
      return new Date(excelEpoch + serial * 86400000);
    }
  }

  const match = raw.match(/^(\d{1,2})[\/-](\d{1,2})[\/-](\d{4})(?:\s+(\d{1,2}):(\d{2})(?::(\d{2}))?\s*(AM|PM)?)?/i);
  if (match) {
    let first = Number(match[1]);
    let second = Number(match[2]);
    const year = Number(match[3]);
    const month = first > 12 ? second : first;
    const day = first > 12 ? first : second;
    let hour = Number(match[4] || 0);
    const minute = Number(match[5] || 0);
    const secondValue = Number(match[6] || 0);
    const ampm = String(match[7] || '').toUpperCase();
    if (ampm === 'PM' && hour < 12) hour += 12;
    if (ampm === 'AM' && hour === 12) hour = 0;
    const parsed = new Date(year, month - 1, day, hour, minute, secondValue);
    if (!Number.isNaN(parsed.getTime())) return parsed;
  }

  const parsed = new Date(raw);
  return Number.isNaN(parsed.getTime()) ? null : parsed;
}

function derivePlatformOrderId(value) {
  const raw = String(value ?? '').trim();
  if (!raw) return '';
  const numericTail = raw.match(/(\d{12,25})$/);
  if (numericTail) return numericTail[1];
  const parts = raw.split('-').filter(Boolean);
  return parts.length > 1 ? parts[parts.length - 1] : raw;
}

function deriveCnncCode(explicitValue, orderNo, platformOrderId) {
  const explicit = String(explicitValue ?? '').trim();
  if (explicit) return explicit;

  const rawOrderNo = String(orderNo ?? '').trim();
  const orderId = String(platformOrderId ?? '').trim();
  if (!rawOrderNo || rawOrderNo === orderId) return '';

  if (orderId) {
    const index = rawOrderNo.lastIndexOf(orderId);
    if (index > 0) {
      const prefix = rawOrderNo
        .slice(0, index)
        .replace(/[\s\-_/|:]+$/g, '')
        .trim();
      if (prefix) return prefix;
    }
  }

  const separated = rawOrderNo.match(/^([A-Za-z][A-Za-z0-9]{1,30})(?:[\s\-_/|:]+)/);
  return separated ? separated[1] : '';
}

function standardize(rows, headers, fileName) {
  const columns = detectColumns(headers);
  const missing = [];
  if (!columns.platformOrderId && !columns.orderNo) missing.push('Platform Order ID hoặc Order No');
  for (const key of ['channel', 'carrier', 'warehouse', 'status', 'orderDate', 'slaAt', 'trackingId']) {
    if (!columns[key]) missing.push(key);
  }
  if (missing.length) {
    throw new Error(`Thiếu cột bắt buộc: ${missing.join(', ')}. Header hiện có: ${headers.slice(0, 30).join(' | ')}`);
  }

  return rows.map((row, index) => {
    const orderNo = columns.orderNo ? String(row[columns.orderNo] ?? '').trim() : '';
    const platformOrderId = columns.platformOrderId
      ? String(row[columns.platformOrderId] ?? '').trim()
      : derivePlatformOrderId(orderNo);
    return {
      _row: index + 2,
      _original: row,
      orderId: platformOrderId,
      orderNo,
      cnnc: deriveCnncCode(
        columns.cnnc ? row[columns.cnnc] : '',
        orderNo,
        platformOrderId
      ),
      channel: String(row[columns.channel] ?? '').trim(),
      carrier: String(row[columns.carrier] ?? '').trim(),
      platform: columns.platform ? String(row[columns.platform] ?? '').trim() : '',
      status: String(row[columns.status] ?? '').trim(),
      orderDate: String(row[columns.orderDate] ?? '').trim(),
      slaAt: String(row[columns.slaAt] ?? '').trim(),
      trackingId: String(row[columns.trackingId] ?? '').trim(),
      warehouse: columns.warehouse ? String(row[columns.warehouse] ?? '').trim() : '',
      sourceFile: columns.sourceFile ? String(row[columns.sourceFile] ?? '').trim() : fileName
    };
  }).filter((row) => row.orderId);
}

function toOutputRow(row) {
  return {
    'Platform Order ID': row.orderId,
    'Delivery Platform': row.carrier,
    'Channel Name': row.channel,
    'Order Date': row.orderDate,
    'SLA Date': row.slaAt,
    'Tracking No': row.trackingId
  };
}

function preparePowerBiExportRows(rows) {
  // The workbook selected here is the Power BI export produced after the
  // report automation has already applied Platform, Order Status, Warehouse
  // and SLA filters. Filtering Status/SLA a second time is unsafe: Power BI can
  // export a display label, another Status column, or a locale-specific date
  // format. That previously excluded hundreds of valid rows (for example
  // 551 raw -> 9 queue rows). Preserve every exported order and only reject a
  // row when the fields required for grouping/ticket creation are actually
  // blank.
  const filtered = rows.filter((row) =>
    row.orderId && row.channel && row.carrier && row.warehouse
  );
  return {
    filtered,
    excludedMissingKeys: Math.max(0, rows.length - filtered.length)
  };
}

function unique(values) {
  return [...new Set(values.filter(Boolean))];
}

function groupRows(rows) {
  const groups = new Map();
  for (const row of rows) {
    const shopeeMode = activePlatform === 'shopee' ? $('ticketMode')?.value : '';
    const key = shopeeMode === 'shopee_all'
      ? 'shopee|||all_channels'
      : shopeeMode === 'shopee_channel'
        ? `shopee|||${normalize(row.channel || 'Unknown channel')}`
        : [
            normalize(row.carrier || 'Unknown carrier'),
            normalize(row.channel || 'Unknown channel'),
            normalize(row.warehouse || 'Unknown warehouse')
          ].join('|||');
    if (!groups.has(key)) {
      groups.set(key, {
        key,
        channel: shopeeMode === 'shopee_all' ? 'Tất cả Channel Shopee' : (row.channel || 'Unknown channel'),
        carrier: row.carrier || 'Unknown carrier',
        warehouse: row.warehouse || 'Unknown warehouse',
        rows: []
      });
    }
    groups.get(key).rows.push(row);
  }
  if (activePlatform === 'shopee') {
    for (const group of groups.values()) {
      group.carrier = unique(group.rows.map((row) => row.carrier)).join(', ');
      group.warehouse = unique(group.rows.map((row) => row.warehouse)).join(', ');
    }
  }
  return [...groups.values()].sort((a, b) =>
    a.carrier.localeCompare(b.carrier) ||
    a.channel.localeCompare(b.channel) ||
    a.warehouse.localeCompare(b.warehouse)
  );
}

function getGroupCnncCodes(group, rows = null) {
  const sourceRows = Array.isArray(rows) ? rows : (group?.rows || []);
  return unique(sourceRows.map((row) =>
    String(row.cnnc || deriveCnncCode('', row.orderNo, row.orderId)).trim()
  ));
}

function formatCnncCodes(group, rows = null) {
  const codes = getGroupCnncCodes(group, rows);
  return codes.length ? codes.join(', ') : 'Không xác định';
}

function toPersistedQueueRow(row) {
  return {
    _row: row._row,
    orderId: row.orderId,
    orderNo: row.orderNo,
    cnnc: row.cnnc,
    channel: row.channel,
    carrier: row.carrier,
    platform: row.platform,
    status: row.status,
    orderDate: row.orderDate,
    slaAt: row.slaAt,
    trackingId: row.trackingId,
    warehouse: row.warehouse,
    sourceFile: row.sourceFile,
    // Ticket Master keeps the complete Power BI row. Raise attachments are
    // still generated separately with only the required 6 columns.
    _original: row._original && typeof row._original === 'object'
      ? { ...row._original }
      : {}
  };
}

async function persistQueueState() {
  await chrome.storage.local.set({
    queueRows: eligibleRows.map(toPersistedQueueRow),
    queueSourceFileName: sourceFileName,
    queueRawCount: importedRawCount || rawRows.length,
    queueSelectedChannel: selectedChannelKey,
    queueSavedAt: new Date().toISOString()
  });
}

function formatDateOnly(date) {
  return `${String(date.getDate()).padStart(2, '0')}/${String(date.getMonth() + 1).padStart(2, '0')}/${date.getFullYear()}`;
}

function renderDataset() {
  const totalRawRows = importedRawCount || rawRows.length;
  $('rowCount').textContent = totalRawRows;
  $('eligibleCount').textContent = eligibleRows.length;
  $('groupCount').textContent = queue.length;
  $('excludedCount').textContent = Math.max(0, totalRawRows - eligibleRows.length);
  $('downloadSplit').disabled = !eligibleRows.length;

  if (!totalRawRows && !eligibleRows.length) {
    $('dataNote').textContent = 'Chưa nạp file.';
  } else {
    $('dataNote').textContent = `Giữ nguyên rows trong file Power BI đã export · không lọc lại Status/SLA · Platform = ${platformLabel()} · split theo ĐVVC + Channel + WH · output chỉ giữ 6 cột.`;
  }
  renderSplitPreview();
  renderGroups();
}

function renderSplitPreview() {
  const box = $('splitPreview');
  if (!queue.length) {
    box.className = 'split-preview empty';
    box.textContent = 'Chưa có nhóm Delivery Platform + Channel Name + Warehouse Branch để split.';
    return;
  }
  box.className = 'split-preview';
  box.innerHTML = '';
  queue.forEach((group) => {
    const row = document.createElement('div');
    row.className = 'split-row';
    row.innerHTML = `<div><b>${escapeHtml(group.channel)}</b><br><span>CNNC: ${escapeHtml(formatCnncCodes(group))} · ${escapeHtml(group.carrier)} · ${escapeHtml(group.warehouse)}</span></div><span>${group.rows.length.toLocaleString('en-US')} rows</span>`;
    box.appendChild(row);
  });
}

function formatBytes(size) {
  const bytes = Number(size || 0);
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
}

function bytesToBase64(bytes) {
  const input = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  let binary = '';
  const chunk = 0x8000;
  for (let i = 0; i < input.length; i += chunk) {
    binary += String.fromCharCode(...input.subarray(i, i + chunk));
  }
  return btoa(binary);
}

async function fileToStoredAttachment(file) {
  const bytes = new Uint8Array(await file.arrayBuffer());
  return {
    name: file.name,
    type: file.type || (/\.png$/i.test(file.name) ? 'image/png' : 'image/jpeg'),
    size: file.size,
    base64: bytesToBase64(bytes)
  };
}

function shuffle(values) {
  const result = [...values];
  for (let i = result.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [result[i], result[j]] = [result[j], result[i]];
  }
  return result;
}

function renderEvidence() {
  $('evidenceCount').textContent = `${evidenceFiles.length}/5`;
  const box = $('evidenceList');
  if (!evidenceFiles.length) {
    box.className = 'evidence-list empty';
    box.textContent = 'Chưa chọn folder bằng chứng.';
    return;
  }
  box.className = 'evidence-list';
  box.innerHTML = evidenceFiles.map((file) =>
    `<div class="evidence-item"><span>${escapeHtml(file.name)}</span><span>${formatBytes(file.size)}</span></div>`
  ).join('');
}

async function selectRandomEvidence() {
  if (!evidenceCandidates.length) {
    opNotify('Chọn lại folder bằng chứng để random ảnh.');
    return;
  }
  const picked = shuffle(evidenceCandidates).slice(0, 5);
  $('evidenceList').className = 'evidence-list empty';
  $('evidenceList').textContent = 'Đang đọc 5 ảnh…';
  evidenceFiles = [];
  for (const file of picked) evidenceFiles.push(await fileToStoredAttachment(file));
  await chrome.storage.local.set({ evidenceFiles });
  renderEvidence();
  if (picked.length < 5) opNotify(`Folder chỉ có ${picked.length} ảnh hợp lệ dưới 5 MB nên tool dùng toàn bộ.`);
}

async function handleEvidenceFolder(event) {
  const files = [...(event.target.files || [])];
  evidenceCandidates = files.filter((file) => /\.(jpe?g|png)$/i.test(file.name) && file.size > 0 && file.size < 5 * 1024 * 1024);
  if (!evidenceCandidates.length) {
    evidenceFiles = [];
    await removeBacklogStorage('evidenceFiles');
    renderEvidence();
    opNotify('Folder không có ảnh JPG/JPEG/PNG hợp lệ dưới 5 MB.');
    return;
  }
  await selectRandomEvidence();
}


/* -----------------------------------------------------------------------------
 * v0.11.3 — TÊN FILE VÀ TÊN SHEET THEO ĐÚNG SÀN.
 * v0.11.2 đặt cứng sheet 'Pickup Orders' và tiền tố 'TTS_' ("TTS" = TikTok Shop)
 * cho mọi output, kể cả khi đang ở tab Shopee. File hai sàn nhìn giống hệt nhau
 * nên rất dễ đính nhầm file của sàn này vào ticket của sàn kia.
 * -------------------------------------------------------------------------- */
const PLATFORM_FILE_LABEL = { tiktok: 'TikTok', shopee: 'Shopee' };
/** Nhãn dùng trong TÊN FILE. platformLabel() sẵn có trả chữ hoa cho phần
 *  hiển thị quy tắc, còn tên file nên đọc được: "Shopee__GHN__...". */
const platformFileLabel = () => PLATFORM_FILE_LABEL[activePlatform] || 'TikTok';
/** Tên sheet trong workbook đính kèm / split. Excel giới hạn 31 ký tự. */
const pickupSheetName = () => `${platformFileLabel()} Pickup`;

function buildGroupExcelAttachment(group, rows) {
  const outputRows = rows.map(toOutputRow);
  const bytes = createXlsx(OUTPUT_HEADERS, outputRows, pickupSheetName());
  const name = `${platformFileLabel()}__${safeFilePart(group.carrier)}__${safeFilePart(group.channel)}__${safeFilePart(group.warehouse)}.xlsx`;
  return {
    name,
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    size: bytes.length,
    base64: bytesToBase64(bytes)
  };
}


/* -----------------------------------------------------------------------------
 * v0.11 — BỎ alert().
 *
 * alert() là modal ĐỒNG BỘ: nó dừng toàn bộ JavaScript của side panel cho tới
 * khi user bấm OK. Trong lúc đứng đó, kết quả sync không được xử lý, nhóm kế
 * tiếp không mở, storage.onChanged không chạy. v0.10.x gọi alert() 24 lần trên
 * đúng những nhánh hay xảy ra nhất — đây là một trong các nguồn "nghẽn" chính,
 * nhất là khi user đã chuyển sang tab khác và không thấy hộp thoại.
 * -------------------------------------------------------------------------- */
function opNotify(message) {
  if (globalThis.OPPanel) return OPPanel.notify(message);
  console.warn('[OnPoint]', message);
  return null;
}

function orderIdKey(value) {
  return String(value ?? '').trim();
}

function channelKey(value) {
  return normalize(value || 'Unknown channel');
}

/* -----------------------------------------------------------------------------
 * v0.11 — CHỈ MỤC THAY CHO QUÉT MẢNG.
 *
 * v0.10.x có một lỗi độ phức tạp thật sự: updateBadge() gọi isOrderLogged()
 * KHÔNG truyền Set, nên mỗi dòng queue phải quét toàn bộ ticketLog. Với 5.000
 * dòng queue và 20.000 record log là 100 TRIỆU phép chuẩn hoá chuỗi cho MỖI
 * lần render — và renderGroups() được gọi ở 17 chỗ. Đó là lúc side panel đơ.
 *
 * v0.11 dựng chỉ mục MỘT LẦN mỗi khi ticketLog đổi, rồi tra cứu O(1).
 * -------------------------------------------------------------------------- */
let loggedOrderIndex = new Set();
let ticketIdByOrder = new Map();
let ticketIndexStamp = -1;

function rebuildTicketIndex(force = false) {
  if (!force && ticketIndexStamp === ticketLog.length) return;
  loggedOrderIndex = new Set();
  ticketIdByOrder = new Map();
  for (const record of ticketLog) {
    const key = orderIdKey(record.OrderID || record.orderId);
    if (!key) continue;
    loggedOrderIndex.add(key);
    const ticketId = String(record.TicketID || record.ticketId || '').trim();
    if (ticketId && !ticketIdByOrder.has(key)) ticketIdByOrder.set(key, ticketId);
  }
  ticketIndexStamp = ticketLog.length;
}


/* -----------------------------------------------------------------------------
 * v0.11 — ĐỌC/GHI TICKET MASTER QUA SERVICE WORKER.
 * Log không còn là một mảng khổng lồ trong storage; nền giữ nó theo chunk và
 * side panel chỉ xin bản sao để render.
 * -------------------------------------------------------------------------- */
async function loadTicketLog({ all = true, limit = 500 } = {}) {
  try {
    const response = await sendRuntimeMessage({ type: 'OP_READ_LOG', all, limit });
    if (response?.ok && Array.isArray(response.records)) return response.records;
  } catch (_) { /* nền đang khởi động lại */ }
  const legacy = await chrome.storage.local.get('ticketLog');
  return Array.isArray(legacy.ticketLog) ? legacy.ticketLog : [];
}

/* v2.2.9 — mỗi lần sync, nền ghi chunk + ticketLogVersion (≥2 sự kiện storage) và trước đây MỖI sự kiện nạp lại toàn bộ
   Ticket Master + vẽ lại → giật máy khi lịch sử lớn. Giờ gộp các sự kiện trong 1,2s thành 1 lần nạp, chỉ một lượt chạy
   cùng lúc, và hoãn khi panel đang ẩn (nạp lại khi hiện lên). */
let ticketLogReloadTimer = null, ticketLogReloading = false, ticketLogReloadAgain = false, ticketLogDirtyHidden = false;
function scheduleTicketLogReload(delay = 1200) {
  if (document.hidden) { ticketLogDirtyHidden = true; return; }
  clearTimeout(ticketLogReloadTimer);
  ticketLogReloadTimer = setTimeout(reloadTicketLogNow, delay);
}
async function reloadTicketLogNow() {
  if (ticketLogReloading) { ticketLogReloadAgain = true; return; }
  ticketLogReloading = true;
  try {
    ticketLog = await loadTicketLog();
    rebuildTicketIndex(true);
    renderLog();
    renderGroups();
  } catch (_) {
  } finally {
    ticketLogReloading = false;
    if (ticketLogReloadAgain) { ticketLogReloadAgain = false; scheduleTicketLogReload(); }
  }
}
document.addEventListener('visibilitychange', () => { if (!document.hidden && ticketLogDirtyHidden) { ticketLogDirtyHidden = false; scheduleTicketLogReload(100); } });

function buildLoggedOrderSet() {
  rebuildTicketIndex();
  return loggedOrderIndex;
}

function isOrderLogged(orderId, loggedOrderSet = null) {
  const key = orderIdKey(orderId);
  if (!key) return false;
  if (loggedOrderSet) return loggedOrderSet.has(key);
  rebuildTicketIndex();
  return loggedOrderIndex.has(key);
}

function getGroupTicketIds(group) {
  rebuildTicketIndex();
  const found = [];
  for (const row of group.rows) {
    const ticketId = ticketIdByOrder.get(orderIdKey(row.orderId));
    if (ticketId) found.push(ticketId);
  }
  return unique(found);
}

function getOpenGroupState(groupKey) {
  const state = ticketOpenGroups?.[groupKey];
  return state && state.status !== 'mapped' ? state : null;
}

function getChannelSummaries(loggedOrderSet) {
  const summaries = new Map();
  for (const group of queue) {
    const key = channelKey(group.channel);
    if (!summaries.has(key)) {
      summaries.set(key, {
        key,
        name: group.channel,
        totalGroups: 0,
        doneGroups: 0,
        pendingGroups: 0,
        openGroups: 0,
        unopenedGroups: 0,
        pendingOrders: 0
      });
    }
    const summary = summaries.get(key);
    const pendingOrders = group.rows.filter((row) => !isOrderLogged(row.orderId, loggedOrderSet)).length;
    summary.totalGroups++;
    summary.pendingOrders += pendingOrders;
    if (pendingOrders) {
      summary.pendingGroups++;
      if (getOpenGroupState(group.key)) summary.openGroups++;
      else summary.unopenedGroups++;
    } else {
      summary.doneGroups++;
    }
  }
  return [...summaries.values()].sort((a, b) => a.name.localeCompare(b.name));
}

function renderChannelControls(loggedOrderSet = buildLoggedOrderSet()) {
  const select = $('channelFilter');
  const button = $('raiseChannel');
  const progress = $('channelProgress');
  const summaries = getChannelSummaries(loggedOrderSet);
  const validKeys = new Set(summaries.map((summary) => summary.key));

  if (selectedChannelKey !== 'all' && !validKeys.has(selectedChannelKey)) {
    selectedChannelKey = 'all';
  }

  select.innerHTML = '';
  const allOption = document.createElement('option');
  allOption.value = 'all';
  allOption.textContent = `Tất cả Channel (${summaries.length})`;
  select.appendChild(allOption);

  for (const summary of summaries) {
    const option = document.createElement('option');
    option.value = summary.key;
    option.textContent = `${summary.name} · ${summary.pendingGroups}/${summary.totalGroups} nhóm chưa raise`;
    select.appendChild(option);
  }
  select.value = selectedChannelKey;

  const selectedSummary = summaries.find((summary) => summary.key === selectedChannelKey);
  if (activePlatform === 'tiktok') {
    button.disabled = !selectedSummary || selectedSummary.pendingGroups === 0 || Boolean(currentDraft);
    button.textContent = selectedSummary
      ? `Raise hết Channel này · ${selectedSummary.pendingGroups} nhóm còn lại`
      : 'Chọn Channel để raise lần lượt cho hết';

    progress.className = 'channel-progress';
    if (activeChannelBatchKey) {
      const batchSummary = summaries.find((summary) => summary.key === activeChannelBatchKey);
      if (batchSummary) {
        progress.classList.add(batchSummary.pendingGroups ? 'running' : 'done');
        progress.textContent = batchSummary.pendingGroups
          ? `Đang chạy ${batchSummary.name}: ${batchSummary.doneGroups}/${batchSummary.totalGroups} nhóm đã raise. Bắt được Ticket ID là mở nhóm kế tiếp ngay; Google Sheet đồng bộ nền.`
          : `✓ ${batchSummary.name}: đã raise đủ ${batchSummary.totalGroups}/${batchSummary.totalGroups} nhóm.`;
        return;
      }
    }
    if (!selectedSummary) {
      progress.textContent = 'Chọn Channel hoặc bấm trực tiếp tên Channel bên dưới.';
    } else if (!selectedSummary.pendingGroups) {
      progress.classList.add('done');
      progress.textContent = `✓ ${selectedSummary.name}: tất cả ${selectedSummary.totalGroups} nhóm đã raise.`;
    } else {
      progress.textContent = `${selectedSummary.name}: còn ${selectedSummary.pendingGroups} nhóm / ${selectedSummary.pendingOrders} đơn chưa raise.`;
    }
    return;
  }

  button.disabled = !selectedSummary || selectedSummary.unopenedGroups === 0;
  button.textContent = selectedSummary
    ? selectedSummary.unopenedGroups
      ? `Mở ${selectedSummary.unopenedGroups} form ticket · đúng ${selectedSummary.unopenedGroups} nhóm`
      : selectedSummary.pendingGroups
        ? `Đã mở đủ ${selectedSummary.openGroups} form · chờ submit`
        : '✓ Channel này đã raise xong'
    : 'Chọn Channel để mở tất cả form ticket';

  progress.className = 'channel-progress';

  if (!selectedSummary) {
    progress.textContent = 'Chọn Channel hoặc bấm trực tiếp tên Channel bên dưới.';
  } else if (!selectedSummary.pendingGroups) {
    progress.classList.add('done');
    progress.textContent = `✓ ${selectedSummary.name}: tất cả ${selectedSummary.totalGroups} nhóm đã raise.`;
  } else if (selectedSummary.openGroups) {
    progress.classList.add('running');
    progress.textContent = activePlatform === 'shopee'
      ? `${selectedSummary.name}: đã mở ${selectedSummary.openGroups} form riêng. Submit xong, nhập mã phiếu Shopee ngay trên card rồi bấm Lưu & map.`
      : `${selectedSummary.name}: đã mở ${selectedSummary.openGroups} form riêng, mỗi form có đúng nội dung + Excel của nhóm. Submit xong sẽ tự chuyển xanh.`;
  } else {
    progress.textContent = `${selectedSummary.name}: còn ${selectedSummary.pendingGroups} nhóm / ${selectedSummary.pendingOrders} đơn chưa raise.`;
  }
}

function findNextPendingGroupIndex(targetChannelKey) {
  const loggedOrderSet = buildLoggedOrderSet();
  // Sắp xếp lại TRƯỚC khi tìm, để "Fast Next Group" mở đúng nhóm gấp nhất
  // chứ không phải nhóm kế tiếp theo thứ tự alphabet như v0.10.
  refreshSlaOrder(loggedOrderSet);
  const hasPending = (group) =>
    group.rows.some((row) => !isOrderLogged(row.orderId, loggedOrderSet));
  const inChannel = (group) => channelKey(group.channel) === targetChannelKey;

  // Ưu tiên nhóm nằm trong mốc SLA đang chọn; nếu mốc đó đã hết nhóm thì
  // vẫn chạy tiếp phần còn lại của Channel thay vì dừng giữa chừng.
  const preferred = queue.findIndex((g) => inChannel(g) && hasPending(g) && groupPassesSla(g));
  if (preferred >= 0) return preferred;
  return queue.findIndex((g) => inChannel(g) && hasPending(g));
}

async function startChannelBatch(targetChannel = null) {
  const targetKey = targetChannel ? channelKey(targetChannel) : $('channelFilter').value;
  if (!targetKey || targetKey === 'all') {
    opNotify('Chọn một Channel Name trước khi chạy.');
    return;
  }

  if (activePlatform === 'tiktok') {
    if (currentDraft) {
      opNotify('Đang có một ticket chưa lưu. Lưu & map ticket hiện tại trước để không ghi đè hoặc raise trùng.');
      return;
    }
    const nextGroupIndex = findNextPendingGroupIndex(targetKey);
    selectedChannelKey = targetKey;
    if (nextGroupIndex < 0) {
      activeChannelBatchKey = '';
      await chrome.storage.local.set({ queueSelectedChannel: selectedChannelKey });
      await removeBacklogStorage('activeChannelBatchKey');
      renderGroups();
      opNotify('Channel này đã map ticket hết rồi.');
      return;
    }
    activeChannelBatchKey = targetKey;
    await chrome.storage.local.set({
      queueSelectedChannel: selectedChannelKey,
      activeChannelBatchKey
    });
    await createDraft(nextGroupIndex, { batch: true });
    return;
  }

  selectedChannelKey = targetKey;
  const loggedOrderSet = buildLoggedOrderSet();
  const groupIndices = [];
  queue.forEach((group, index) => {
    if (channelKey(group.channel) !== targetKey) return;
    if (getOpenGroupState(group.key)) return;
    if (group.rows.some((row) => !isOrderLogged(row.orderId, loggedOrderSet))) {
      groupIndices.push(index);
    }
  });

  if (!groupIndices.length) {
    await chrome.storage.local.set({ queueSelectedChannel: selectedChannelKey });
    renderGroups();
    opNotify('Các nhóm của Channel này đã mở form hoặc đã map ticket hết rồi.');
    return;
  }

  await openTicketForms(groupIndices, { targetChannelKey: targetKey });
}

async function selectAndStartChannel(channel) {
  selectedChannelKey = channelKey(channel);
  $('channelFilter').value = selectedChannelKey;
  await startChannelBatch(channel);
}


/* =============================================================================
 * v0.11.1 — ƯU TIÊN RAISE THEO SLA
 * -----------------------------------------------------------------------------
 * Luật (đã bỏ LDR): Shopee FHR và TikTokShop FDR dùng chung một hình dạng —
 *   order created <18h  →  hạn cùng ngày 23:59
 *   order created ≥18h  →  hạn hôm sau  11:59
 * Không áp lịch T2–T7, không trừ ngày lễ: chỉ dùng Order Date và SLA Date
 * có sẵn trong file raw.
 *
 * Nhóm được xếp theo hạn SỚM NHẤT của các đơn CHƯA raise. Đơn đã raise không
 * còn kéo nhóm lên đầu — nếu tính cả chúng, một nhóm đã xong 95% vẫn chiếm
 * chỗ ưu tiên chỉ vì một đơn cũ quá hạn từ lâu.
 * ========================================================================== */
let slaWindowId = 'all';
let slaCustomUntil = null;
let slaBuckets = { D0: true, D1: true };
let slaSource = 'auto';
/* v0.11.5 — mặc định KHÔNG ẩn nhóm ngoài mốc.
   Mốc SLA là công cụ ƯU TIÊN, không phải công cụ chặn. Ẩn nhóm khiến chọn một
   mốc hẹp là mất luôn nút raise — vẫn còn 20 đơn chưa raise mà màn hình báo
   "không có nhóm nào", không có lối đi tiếp. Giờ nhóm ngoài mốc bị đẩy xuống
   dưới và làm nhạt, vẫn bấm raise được. Muốn ẩn hẳn thì tick ô riêng. */
let slaHideOutside = false;

/** Mốc chặn hiện tại, hoặc null nếu đang xem tất cả. */
function currentSlaUntil() {
  if (slaWindowId === 'custom') return slaCustomUntil;
  const preset = OPSla.presetWindows().find((w) => w.id === slaWindowId);
  return preset ? preset.until : null;
}

const slaBucketAllowed = (buckets) =>
  !buckets || !buckets.length || buckets.some((b) => slaBuckets[b]);

/** Nhóm có lọt qua bộ lọc SLA hiện tại không. */
function groupPassesSla(group) {
  if (!group?.sla) return true;
  if (!slaBucketAllowed(group.sla.buckets)) return false;
  return OPSla.withinWindow(group.sla, currentSlaUntil());
}

/**
 * Gắn group.sla và SẮP XẾP LẠI `queue` tại chỗ.
 * Sắp xếp tại chỗ là có chủ ý: findNextPendingGroupIndex() trả về chỉ số vào
 * chính mảng này và createDraft() dùng lại chỉ số đó, nên hai bên phải nhìn
 * cùng một thứ tự. Dùng mảng view riêng sẽ lệch chỉ số và mở nhầm nhóm.
 */
function refreshSlaOrder(loggedOrderSet = buildLoggedOrderSet()) {
  if (!globalThis.OPSla || !queue.length) return;
  const now = Date.now();
  const isPending = (row) => !isOrderLogged(row.orderId, loggedOrderSet);
  for (const group of queue) {
    group.sla = OPSla.evaluateGroup(group, activePlatform, isPending, now, slaSource);
  }
  queue.sort((a, b) => {
    const ap = a.rows.some(isPending) ? 0 : 1;
    const bp = b.rows.some(isPending) ? 0 : 1;
    if (ap !== bp) return ap - bp;                    // nhóm còn việc lên trước
    const aw = groupPassesSla(a) ? 0 : 1;
    const bw = groupPassesSla(b) ? 0 : 1;
    if (aw !== bw) return aw - bw;                    // trong mốc lên trước
    const d = OPSla.sortKey(a.sla) - OPSla.sortKey(b.sla);
    if (d) return d;                                  // rồi tới hạn sớm nhất
    return a.carrier.localeCompare(b.carrier) ||
      a.channel.localeCompare(b.channel) ||
      a.warehouse.localeCompare(b.warehouse);
  });
}

function renderSlaSummary(loggedOrderSet) {
  const box = $('slaSummary');
  if (!box) return;
  if (!queue.length) { box.textContent = 'Chưa có queue.'; return; }
  const isPending = (row) => !isOrderLogged(row.orderId, loggedOrderSet);
  const total = { overdue: 0, critical: 0, warning: 0, ok: 0, unknown: 0 };
  let mismatches = 0;
  let shown = 0;
  let mixed = 0;
  const bucketFilterOn = !slaBuckets.D0 || !slaBuckets.D1;
  for (const group of queue) {
    if (!group.sla) continue;
    if (groupPassesSla(group) && group.rows.some(isPending)) {
      shown += 1;
      if (bucketFilterOn && (group.sla.buckets || []).length > 1) mixed += 1;
    }
    for (const key of Object.keys(total)) total[key] += group.sla.counts[key] || 0;
    mismatches += group.sla.mismatches || 0;
  }
  const metric = OPSla.metricOf(activePlatform) || 'SLA';
  const pendingGroups = queue.filter((g) => g.rows.some(isPending)).length;
  const outside = Math.max(0, pendingGroups - shown);
  const parts = [
    `<b>${metric}</b> · ${shown}/${pendingGroups} nhóm trong mốc đang chọn`,
    total.overdue ? `<span class="od">${total.overdue} đơn quá hạn</span>` : '',
    total.critical ? `<span class="cr">${total.critical} dưới 2h</span>` : '',
    total.warning ? `<span class="wr">${total.warning} dưới 6h</span>` : '',
    total.unknown ? `${total.unknown} thiếu ngày` : ''
  ].filter(Boolean);
  let html = parts.join(' · ');
  // Khi mốc đang chọn không còn nhóm nào, phải nói rõ chuyện gì xảy ra và lối
  // đi tiếp là gì — thay vì để màn hình trống với "không có nhóm nào".
  if (outside) {
    html += slaHideOutside
      ? `<br>${outside} nhóm nằm ngoài mốc đang bị <b>ẩn</b>. Bỏ tick "Ẩn hẳn nhóm ngoài mốc" để raise chúng.`
      : `<br>${outside} nhóm ngoài mốc vẫn hiện ở dưới vạch ngăn — <b>vẫn raise được</b>.`;
  }
  // Bộ lọc bucket lọc theo NHÓM, không tách đơn trong nhóm — vì quy tắc
  // 1 Channel + ĐVVC + WH / ticket vẫn giữ nguyên. Một nhóm trộn D0 và D1 vẫn
  // hiện khi chỉ tick một bucket, và raise nó sẽ gửi cả đơn thuộc bucket kia.
  // Nói thẳng ra đây để không bị bất ngờ lúc đối soát.
  if (mixed) {
    html += `<br>${mixed} nhóm trộn cả D0 &lt;18h và D0 &ge;18h — raise nhóm sẽ gửi cả hai loại.`;
  }
  if (mismatches) {
    html += `<br>⚠ ${mismatches} đơn có SLA Date trong file lệch quá 90 phút so với luật ${metric}.`;
    html += slaSource === 'rule'
      // Đã chuyển sang luật rồi thì đừng bảo người dùng làm lại việc đã làm.
      ? ` Đang tính theo <b>luật ${metric}</b> nên cột đó không ảnh hưởng hạn chót.`
      : ` Cột đó có thể đang là một mốc khác. Đổi <b>Hạn tính theo → Luôn tính theo luật ${metric}</b> để dùng đúng 23:59 / 11:59.`;
  }
  box.innerHTML = html;
}

function renderSlaControls() {
  const select = $('slaWindow');
  if (!select || !globalThis.OPSla) return;
  const presets = OPSla.presetWindows();
  if (select.options.length !== presets.length) {
    select.innerHTML = '';
    for (const w of presets) {
      const option = document.createElement('option');
      option.value = w.id;
      option.textContent = w.label;
      select.appendChild(option);
    }
  }
  select.value = slaWindowId;
  $('slaCustomRow').hidden = slaWindowId !== 'custom';
}

function renderGroups() {
  const box = $('groups');
  const loggedOrderSet = buildLoggedOrderSet();
  refreshSlaOrder(loggedOrderSet);
  renderSlaControls();
  renderSlaSummary(loggedOrderSet);
  renderChannelControls(loggedOrderSet);

  if (!queue.length) {
    box.className = 'groups empty';
    box.textContent = 'Chưa có queue.';
    updateBadge();
    return;
  }

  box.className = 'groups';
  box.innerHTML = '';
  let rendered = 0;
  let outsideDividerShown = false;

  queue.forEach((group, index) => {
    if (selectedChannelKey !== 'all' && channelKey(group.channel) !== selectedChannelKey) return;
    // v0.11.5: nhóm ngoài mốc KHÔNG bị bỏ qua nữa — chỉ làm nhạt và đẩy xuống
    // dưới một vạch ngăn, để luôn còn đường raise.
    const inWindow = groupPassesSla(group);
    if (!inWindow && slaHideOutside) return;
    if (!inWindow && !outsideDividerShown) {
      outsideDividerShown = true;
      const divider = document.createElement('div');
      divider.className = 'sla-divider';
      divider.textContent = 'Ngoài mốc SLA đang chọn — vẫn raise được';
      box.appendChild(divider);
    }

    const pending = group.rows.filter((row) => !isOrderLogged(row.orderId, loggedOrderSet)).length;
    const completed = group.rows.length - pending;
    const openState = activePlatform === 'shopee' ? getOpenGroupState(group.key) : null;
    const isActive = currentDraft?.groupKey === group.key || Boolean(openState);
    const ticketIds = getGroupTicketIds(group);
    const item = document.createElement('div');
    const slaState = pending > 0 && group.sla ? group.sla.state : '';
    const slaClass = slaState && slaState !== 'ok' && slaState !== 'unknown' ? ` sla-${slaState}` : '';
    item.className = `group${pending === 0 ? ' done' : completed ? ' partial' : ''}${isActive ? ' active' : ''}${slaClass}${inWindow ? '' : ' out-of-window'}`;

    const statusText = pending === 0
      ? (ticketIds.length
          ? `✓ ĐÃ RAISE · Ticket ${ticketIds.join(', ')}`
          // Trước đây chỗ này im lặng in ra mỗi "ĐÃ RAISE", nên không thể biết
          // là nhóm thiếu ID phiếu hay chỉ là hiển thị chưa kịp cập nhật.
          : '⚠ ĐÃ RAISE NHƯNG CHƯA CÓ ID PHIẾU')
      : openState
        ? `${openState.status === 'autofilled' ? '✓ ĐÃ AUTO-FILL' : 'ĐÃ MỞ FORM'} · ${pending} đơn`
        : isActive
          ? `ĐANG XỬ LÝ · ${pending} đơn`
        : completed
          ? `ĐÃ MAP ${completed}/${group.rows.length} · CÒN ${pending}`
          : `CHƯA RAISE · ${pending} đơn`;
    const actionText = pending === 0
      ? '✓ Đã raise'
      : activePlatform === 'tiktok'
        ? $('ticketMode').value === 'single'
          ? 'Raise 1 đơn'
          : 'Raise cả nhóm'
      : openState
        ? 'Form đã mở'
        : isActive
        ? 'Đang xử lý'
        : $('ticketMode').value === 'single'
          ? 'Mở form 1 đơn'
          : 'Mở form cả nhóm';
    const cnncText = formatCnncCodes(group);

    // v0.11.2: ô nhập ID phiếu hiện trên MỌI nhóm còn đơn chưa raise, cả TikTok
    // lẫn Shopee, và không phụ thuộc tab còn mở hay không. Đây là lối thoát khi
    // auto-map hỏng — trước đây TikTok không có ô nào, còn Shopee thì mất ô ngay
    // khi đóng tab.
    // v0.11.4 — ô nhập KHÔNG BAO GIỜ biến mất.
    //
    // v0.11.2 gate bằng `pending > 0`, nhưng "pending" chỉ nghĩa là chưa nằm
    // trong Ticket Master — không phải là "đã có ID phiếu". Một nhóm có thể ở
    // trạng thái ĐÃ RAISE mà TicketID rỗng hoặc sai; đúng lúc cần sửa nhất thì
    // ô nhập lại bị ẩn. Giờ nhóm đã xong vẫn có ô, nhưng đổi thành "gán lại".
    const isReassign = pending === 0;
    const manualHint = isReassign
      ? (ticketIds.length
          ? `Gán lại ID phiếu (đang là ${ticketIds.join(', ')})`
          : 'Nhóm này chưa có ID phiếu — nhập vào đây')
      : activePlatform === 'shopee'
        ? 'Nhập mã phiếu Shopee rồi Enter'
        : 'Nhập ID phiếu TikTok nếu tool không tự bắt được';
    const manualLabel = isReassign
      ? `Gán lại ${group.rows.length} đơn`
      : `Lưu &amp; map ${pending} đơn`;
    const manualMap = `
        <div class="group-ticket-map${openState || isActive || (isReassign && !ticketIds.length) ? '' : ' idle'}${isReassign ? ' reassign' : ''}">
          <input type="text" class="group-ticket-input" placeholder="${escapeHtml(manualHint)}" autocomplete="off" />
          <button type="button" class="group-ticket-save">${manualLabel}</button>
        </div>
      `;

    // Huy hiệu SLA: metric · bucket order-created · hạn chót · đếm ngược.
    // Chỉ hiện khi nhóm còn đơn chưa raise — nhóm đã xong thì SLA hết ý nghĩa.
    const slaBadge = pending > 0 && group.sla && group.sla.deadline
      ? `<span class="group-sla ${group.sla.state}">${escapeHtml(OPSla.badgeText(group.sla))}` +
        `${group.sla.mismatches ? ' <span class="mm" title="SLA Date trong file lệch so với luật">⚠</span>' : ''}</span>`
      : '';

    item.innerHTML = `
      <div class="group-main">
        <button type="button" class="channel-link" title="Bấm một lần để mở toàn bộ form của Channel này">${escapeHtml(group.channel)}</button>
        <p><b>CNNC: ${escapeHtml(cnncText)}</b> · ${escapeHtml(group.carrier)} · ${escapeHtml(group.warehouse)} · ${pending}/${group.rows.length} chưa map ticket</p>
        <span class="group-status">${escapeHtml(statusText)}</span>
        ${slaBadge}
      </div>
      <button type="button" class="group-action">${escapeHtml(actionText)}</button>
      ${manualMap}
    `;

    const channelButton = item.querySelector('.channel-link');
    const actionButton = item.querySelector('.group-action');
    channelButton.addEventListener('click', () => selectAndStartChannel(group.channel));
    actionButton.disabled = pending === 0 ||
      (activePlatform === 'tiktok'
        ? Boolean(currentDraft)
        : Boolean(openState) || Boolean(currentDraft?.groupKey === group.key));
    actionButton.addEventListener('click', () => {
      if (activePlatform === 'tiktok') {
        createDraft(index);
        return;
      }
      openTicketForms([index], {
        targetChannelKey: channelKey(group.channel)
      });
    });
    const ticketInput = item.querySelector('.group-ticket-input');
    const ticketSave = item.querySelector('.group-ticket-save');
    if (ticketInput && ticketSave) {
      const opts = { reassign: isReassign };
      ticketSave.addEventListener('click', () =>
        saveGroupTicket(group, ticketInput, ticketSave, opts)
      );
      ticketInput.addEventListener('keydown', (event) => {
        if (event.key !== 'Enter') return;
        event.preventDefault();
        saveGroupTicket(group, ticketInput, ticketSave, opts);
      });
    }
    box.appendChild(item);
    rendered++;
  });

  if (!rendered) {
    box.className = 'groups empty';
    const hiddenByWindow = slaHideOutside &&
      queue.some((g) => g.rows.some((row) => !isOrderLogged(row.orderId, loggedOrderSet)) && !groupPassesSla(g));
    box.textContent = hiddenByWindow
      ? 'Không có nhóm nào trong mốc SLA đang chọn. Bỏ tick "Ẩn hẳn nhóm ngoài mốc" (hoặc chọn "Tất cả SLA") để thấy và raise các nhóm còn lại.'
      : 'Channel đang chọn không có nhóm nào.';
  }
  updateBadge();
}


/* =============================================================================
 * v0.11.2 — NHẬP MÃ TICKET THỦ CÔNG, LUÔN CÓ SẴN
 * -----------------------------------------------------------------------------
 * Lỗ hổng của v0.11.1:
 *
 *   • Ô #ticketId nằm trong #draftContent, mà khối đó bị hidden khi không còn
 *     currentDraft. Auto-map TikTok hỏng ⇒ draft đã bị xoá ⇒ KHÔNG CÒN Ô NÀO
 *     để gõ ID phiếu. HUD trên trang TikTok bảo "dán ID phiếu vào card" nhưng
 *     với TikTok cái card đó chưa từng có ô nhập.
 *   • Ô trên card Shopee chỉ hiện khi activePlatform==='shopee' VÀ openState
 *     còn sống. Đóng tab là ticketOpenGroups[groupKey] bị dọn ⇒ ô biến mất.
 *   • Đường map qua nền (MAP_TICKET_GROUP_MANUALLY) đòi ticketTabPayloads còn
 *     entry; mất tab là trả "Không còn dữ liệu của form này" — ngõ cụt.
 *
 * v0.11.2: mọi nhóm còn đơn chưa raise đều có ô nhập, cả hai sàn, không phụ
 * thuộc tab còn sống hay không. Khi đường qua nền hết dữ liệu, side panel tự
 * dựng record từ chính `queue` mà nó đang giữ — nên không bao giờ kẹt.
 * ========================================================================== */

/** Một chỗ duy nhất dựng record Ticket Master, để ba lối vào không lệch nhau. */
function buildTicketRecords(ticketId, rows, meta = {}) {
  const now = new Date().toISOString();
  const loggedOrderSet = buildLoggedOrderSet();
  const records = [];
  for (const row of rows || []) {
    const key = orderIdKey(row.orderId);
    if (!key || loggedOrderSet.has(key)) continue;
    loggedOrderSet.add(key);
    records.push({
      ...(row._original && typeof row._original === 'object' ? row._original : {}),
      TicketID: ticketId,
      TicketPlatform: String(meta.platform || activePlatform).toUpperCase(),
      OrderID: row.orderId,
      TrackingID: row.trackingId || '',
      CNNC: row.cnnc || deriveCnncCode('', row.orderNo, row.orderId),
      ChannelName: meta.channel || row.channel || '',
      DeliveryPlatform: meta.carrier || row.carrier || '',
      WarehouseBranch: row.warehouse || meta.warehouse || '',
      IssueType: meta.issueType || $('issueType')?.value || '',
      OrderStatus: row.status || '',
      OrderDate: row.orderDate || '',
      SLADate: row.slaAt || '',
      TicketCreatedAt: meta.createdAt || now,
      TicketRecordedAt: now,
      TicketStatus: 'Submitted',
      SyncStatus: 'Pending',
      SyncedAt: '',
      SyncError: '',
      SourceFile: row.sourceFile || sourceFileName
    });
  }
  return records;
}

/**
 * Map thủ công một nhóm — đường không bao giờ kẹt.
 * Dựng record từ `queue` trong side panel, không cần tab payload còn sống.
 */
async function mapGroupTicketLocally(group, ticketId) {
  const records = buildTicketRecords(ticketId, group.rows, {
    platform: activePlatform,
    channel: group.channel,
    carrier: group.carrier,
    warehouse: group.warehouse
  });
  if (!records.length) {
    return { ok: false, error: 'Tất cả đơn trong nhóm này đã có Ticket ID rồi.' };
  }
  const response = await sendRuntimeMessage({ type: 'OP_APPEND_RECORDS', records });
  if (!response?.ok) {
    return { ok: false, error: response?.error || 'Không ghi được vào Ticket Master.' };
  }
  return { ok: true, mappedCount: response.inserted ?? records.length, records };
}

/**
 * Lưu mã ticket nhập tay cho một nhóm.
 * Thử đường qua nền trước (nó còn dọn cả trạng thái tab đang mở), rồi mới
 * rơi xuống đường cục bộ khi tab payload đã mất.
 */
async function saveGroupTicket(group, input, button, { reassign = false } = {}) {
  const ticketId = String(input?.value || '').trim();
  if (!ticketId) {
    input?.focus();
    opNotify('Nhập mã phiếu / ID phiếu trước khi lưu.');
    return;
  }

  const originalText = button.textContent;
  button.disabled = true;
  button.textContent = 'Đang lưu…';

  // Nhóm đã nằm hết trong Ticket Master → không thêm record mới nữa mà SỬA
  // TicketID của các record sẵn có, rồi đẩy lại lên Sheet.
  if (reassign) {
    try {
      const orderIds = group.rows.map((row) => row.orderId).filter(Boolean);
      const response = await sendRuntimeMessage({
        type: 'OP_REASSIGN_TICKET', ticketId, orderIds
      });
      if (!response?.ok) throw new Error(response?.error || 'Không gán lại được ID phiếu.');
      ticketLog = await loadTicketLog();
      rebuildTicketIndex(true);
      input.value = '';
      button.textContent = `✓ Đã gán ${response.updated} đơn`;
      renderGroups();
      renderLog();
      opNotify(
        `Đã gán ID phiếu ${ticketId} cho ${response.updated} đơn.` +
        '\nGoogle Sheet sẽ được cập nhật lại theo OrderID.'
      );
    } catch (error) {
      button.disabled = false;
      button.textContent = originalText;
      opNotify(`Không gán lại được: ${error.message || error}`);
    }
    return;
  }

  try {
    let mappedCount = 0;
    let via = 'nền';
    const viaBackground = await sendRuntimeMessage({
      type: 'MAP_TICKET_GROUP_MANUALLY',
      groupKey: group.key,
      ticketId
    }).catch(() => null);

    if (viaBackground?.ok) {
      mappedCount = viaBackground.mappedCount || 0;
    } else {
      // Tab đã đóng hoặc extension vừa reload — dựng record ngay tại đây.
      via = 'side panel';
      const local = await mapGroupTicketLocally(group, ticketId);
      if (!local.ok) throw new Error(local.error);
      mappedCount = local.mappedCount;
    }

    ticketLog = await loadTicketLog();
    rebuildTicketIndex(true);
    input.value = '';
    button.textContent = `✓ Đã map ${mappedCount} đơn`;
    renderGroups();
    renderLog();
    opNotify(
      `Đã lưu ID phiếu ${ticketId} cho ${mappedCount} đơn (qua ${via}).` +
      '\nĐồng bộ Google Sheet chạy nền, không cần chờ.'
    );
  } catch (error) {
    button.disabled = false;
    button.textContent = originalText;
    opNotify(`Không lưu được mã phiếu: ${error.message || error}`);
  }
}

function makeTicketDraft(group, selectedRows, options = {}) {
  const rows = Array.isArray(selectedRows) ? selectedRows : [];
  const issueType = options.issueType || $('issueType').value;
  const mode = options.mode || $('ticketMode').value;
  const cnncCodes = getGroupCnncCodes(group, rows);
  const draft = {
    createdAt: new Date().toISOString(),
    issueType,
    mode,
    groupKey: group.key,
    batchChannelKey: options.batchChannelKey || '',
    channel: group.channel,
    carrier: group.carrier,
    warehouse: group.warehouse,
    cnncCodes,
    representativeOrderId: rows[0]?.orderId || '',
    rows,
    platform: activePlatform,
    shopeeEmail: activePlatform === 'shopee'
      ? ($('shopeeEmail').value.trim() || DEFAULT_SHOPEE_EMAIL)
      : '',
    shopeeIssue: activePlatform === 'shopee' ? DEFAULT_SHOPEE_ISSUE : '',
    text: ''
  };
  draft.text = sanitizeMarketplaceMessage(options.text || buildMessage(issueType, group, rows));
  if (activePlatform === 'shopee') draft.text = OPShopeeForm.description(draft.text, draft.representativeOrderId);
  if (activePlatform === 'shopee') applyShopeeFormChoice(draft, group, rows, issueType); // v2.2.4
  return draft;
}

function createBatchId() {
  if (globalThis.crypto?.randomUUID) return globalThis.crypto.randomUUID();
  return `batch_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;
}

function prepareGroupTabPayload(groupIndex, batchId, loggedOrderSet) {
  const group = queue[groupIndex];
  if (!group || getOpenGroupState(group.key)) return null;

  const seenInGroup = new Set();
  const remaining = group.rows.filter((row) => {
    const key = orderIdKey(row.orderId);
    if (!key || isOrderLogged(key, loggedOrderSet) || seenInGroup.has(key)) return false;
    seenInGroup.add(key);
    return true;
  });
  if (!remaining.length) return null;

  const mode = $('ticketMode').value;
  let selected = mode === 'single' ? [remaining[0]] : remaining;
  let draft;

  if (currentDraft?.groupKey === group.key) {
    const remainingIds = new Set(remaining.map((row) => orderIdKey(row.orderId)));
    const keptIds = new Set();
    const keptRows = (currentDraft.rows || []).filter((row) => {
      const key = orderIdKey(row.orderId);
      if (!remainingIds.has(key) || keptIds.has(key)) return false;
      keptIds.add(key);
      return true;
    });
    if (keptRows.length) selected = keptRows;
    draft = makeTicketDraft(group, selected, {
      issueType: currentDraft.issueType,
      mode: currentDraft.mode,
      batchChannelKey: channelKey(group.channel),
      text: Array.isArray(currentDraft.cnncCodes) ? currentDraft.text : ''
    });
  } else {
    draft = makeTicketDraft(group, selected, {
      batchChannelKey: channelKey(group.channel)
    });
  }

  return {
    groupIndex,
    group,
    batchId,
    draft,
    excelAttachment: buildGroupExcelAttachment(group, selected)
  };
}

async function openTicketForms(groupIndices, options = {}) {
  const { handoverRun } = await chrome.storage.local.get('handoverRun');
  if (handoverRun && !handoverRun.doneAt && (handoverRun.activeKey || (!handoverRun.paused && handoverRun.pending?.length))) {
    opNotify('Đang xử lý ticket kháng nghị bàn giao. Chờ đơn hiện tại hoàn tất trước khi mở pickup backlog.');
    return false;
  }
  if (activePlatform === 'shopee' && !$('shopeeEmail').value.trim()) {
    opNotify('Nhập Email đã xác minh trên tài khoản Shopee trước khi mở form.');
    $('shopeeEmail').focus();
    return false;
  }
  const loggedOrderSet = buildLoggedOrderSet();
  const batchId = createBatchId();
  const prepared = [];
  for (const groupIndex of [...new Set(groupIndices)]) {
    const payload = prepareGroupTabPayload(groupIndex, batchId, loggedOrderSet);
    if (!payload) continue;
    prepared.push(payload);
    for (const row of payload.draft.rows) {
      loggedOrderSet.add(orderIdKey(row.orderId));
    }
  }

  if (!prepared.length) {
    renderGroups();
    opNotify('Nhóm này đã mở form hoặc đã map ticket rồi.');
    return false;
  }

  const openedTabs = [];
  try {
    for (let index = 0; index < prepared.length; index++) {
      const tab = await chrome.tabs.create({
        url: 'about:blank',
        active: false
      });
      if (!tab?.id) throw new Error('Chrome không tạo được tab ticket mới.');
      openedTabs.push(tab);
    }

    const stored = await chrome.storage.local.get([
      'ticketTabPayloads',
      'ticketBatchEvidence',
      'ticketOpenGroups'
    ]);
    const tabPayloads = stored.ticketTabPayloads && typeof stored.ticketTabPayloads === 'object'
      ? { ...stored.ticketTabPayloads }
      : {};
    const batchEvidence = stored.ticketBatchEvidence && typeof stored.ticketBatchEvidence === 'object'
      ? { ...stored.ticketBatchEvidence }
      : {};
    ticketOpenGroups = stored.ticketOpenGroups && typeof stored.ticketOpenGroups === 'object'
      ? { ...stored.ticketOpenGroups }
      : { ...ticketOpenGroups };

    batchEvidence[batchId] = evidenceFiles.slice(0, activePlatform === 'shopee' ? 4 : 5);
    prepared.forEach((item, index) => {
      const tabId = String(openedTabs[index].id);
      tabPayloads[tabId] = {
        batchId,
        groupKey: item.group.key,
        draft: item.draft,
        excelAttachment: item.excelAttachment,
        createdAt: new Date().toISOString()
      };
      ticketOpenGroups[item.group.key] = {
        batchId,
        tabId: Number(tabId),
        status: 'opening',
        channel: item.group.channel,
        carrier: item.group.carrier,
        warehouse: item.group.warehouse,
        cnncCodes: item.draft.cnncCodes,
        openedAt: new Date().toISOString()
      };
    });

    const consumedCurrentDraft = prepared.some((item) =>
      currentDraft?.groupKey === item.group.key
    );
    if (consumedCurrentDraft) currentDraft = null;
    activeChannelBatchKey = '';
    selectedChannelKey = options.targetChannelKey || selectedChannelKey;

    await chrome.storage.local.set({
      ticketTabPayloads: tabPayloads,
      ticketBatchEvidence: batchEvidence,
      ticketOpenGroups,
      queueSelectedChannel: selectedChannelKey
    });
    await removeBacklogStorage([
      'activeChannelBatchKey',
      'detectedTicketId',
      ...(consumedCurrentDraft ? ['currentDraft', 'currentAttachments'] : [])
    ]);

    await Promise.all(openedTabs.map((tab) =>
      chrome.tabs.update(tab.id, { url: ticketUrl() })
    ));
    renderDraft();
    renderGroups();
    // v2.2.9 — TikTok tự điền + tự Gửi nên chạy ở tab nền (lib/op-keepalive.js); Shopee cần bạn tick "Tôi đồng ý" nên vẫn mở lên trước.
    if (activePlatform === 'shopee') await chrome.tabs.update(openedTabs[0].id, { active: true });
    else opNotify(`Đã mở ${openedTabs.length} form TikTok ở tab nền — tool tự điền và gửi, bạn cứ làm việc ở tab khác.`);
    return true;
  } catch (error) {
    for (const tab of openedTabs) {
      try {
        await chrome.tabs.remove(tab.id);
      } catch (_) {
        // Roll back only tabs created by this action.
      }
    }
    opNotify(`Không mở được đủ form ticket: ${error.message || error}`);
    return false;
  }
}

async function createDraft(groupIndex, options = {}) {
  const group = queue[groupIndex];
  if (!group) return false;
  if (currentDraft) {
    opNotify('Đang có một ticket chưa lưu. Lưu & map ticket hiện tại trước để không ghi đè hoặc raise trùng.');
    return false;
  }

  const loggedOrderSet = buildLoggedOrderSet();
  const remaining = group.rows.filter((row) => !isOrderLogged(row.orderId, loggedOrderSet));
  if (!remaining.length) {
    renderGroups();
    opNotify('Nhóm này đã map ticket hết rồi.');
    return false;
  }

  const mode = $('ticketMode').value;
  const selected = mode === 'single' ? [remaining[0]] : remaining;
  const issueType = $('issueType').value;
  const warehouses = unique(selected.map((row) => row.warehouse));
  const representativeOrderId = selected[0].orderId;
  const batchChannelKey = options.batch
    ? (activeChannelBatchKey || channelKey(group.channel))
    : '';

  currentDraft = makeTicketDraft(group, selected, {
    issueType,
    mode,
    batchChannelKey
  });
  currentDraft.warehouse = group.warehouse || warehouses.join(', ');
  currentDraft.representativeOrderId = representativeOrderId;

  const excelAttachment = buildGroupExcelAttachment(group, selected);
  const currentAttachments = [
    excelAttachment,
    ...evidenceFiles.slice(0, activePlatform === 'shopee' ? 4 : 5)
  ];
  await chrome.storage.local.set({ currentDraft, currentAttachments });
  renderDraft();
  renderGroups();

  if (!evidenceFiles.length && !options.suppressEvidenceAlert) {
    opNotify('Draft đã tạo nhưng chưa có ảnh bằng chứng. Chọn folder để tool random 5 ảnh trước khi mở form.');
  }
  if (activePlatform === 'tiktok') await openCurrentTicket();
  return true;
}

async function openCurrentTicket() {
  if (!currentDraft) return;
  const { handoverRun } = await chrome.storage.local.get('handoverRun');
  if (handoverRun && !handoverRun.doneAt && (handoverRun.activeKey || (!handoverRun.paused && handoverRun.pending?.length))) {
    opNotify('Đang xử lý ticket kháng nghị bàn giao. Chờ đơn hiện tại hoàn tất trước khi mở pickup backlog.');
    return;
  }
  const draftText = $('draftText');
  if (draftText) currentDraft.text = sanitizeMarketplaceMessage(draftText.value);
  const draft = currentDraft;
  const foreground = activePlatform === 'shopee'; // v2.2.9 — TikTok chạy ở tab nền
  const tab = await chrome.tabs.create({ url: 'about:blank', active: foreground });
  if (!tab?.id) throw new Error('Chrome không tạo được tab ticket TikTok.');

  try {
    const stored = await chrome.storage.local.get([
      'currentAttachments',
      'ticketTabPayloads',
      'ticketOpenGroups'
    ]);
    const tabPayloads = stored.ticketTabPayloads && typeof stored.ticketTabPayloads === 'object'
      ? { ...stored.ticketTabPayloads }
      : {};
    ticketOpenGroups = stored.ticketOpenGroups && typeof stored.ticketOpenGroups === 'object'
      ? { ...stored.ticketOpenGroups }
      : { ...ticketOpenGroups };
    const tabId = String(tab.id);
    const now = new Date().toISOString();
    tabPayloads[tabId] = {
      batchId: `tiktok_${tabId}_${Date.now()}`,
      groupKey: draft.groupKey || '',
      draft,
      attachments: Array.isArray(stored.currentAttachments)
        ? stored.currentAttachments.slice(0, 6)
        : [],
      createdAt: now
    };
    if (draft.groupKey) {
      ticketOpenGroups[draft.groupKey] = {
        batchId: tabPayloads[tabId].batchId,
        tabId: Number(tabId),
        status: 'opening',
        channel: draft.channel || '',
        carrier: draft.carrier || '',
        warehouse: draft.warehouse || '',
        cnncCodes: draft.cnncCodes || [],
        openedAt: now
      };
    }
    await chrome.storage.local.set({
      currentDraft: draft,
      ticketTabPayloads: tabPayloads,
      ticketOpenGroups
    });
    await chrome.tabs.update(tab.id, { url: ticketUrl(), active: foreground });
    if (!foreground) opNotify('Đã mở form TikTok ở tab nền — tool tự điền và gửi, bạn cứ làm việc ở tab khác.');
  } catch (error) {
    try { await chrome.tabs.remove(tab.id); } catch (_) {}
    throw error;
  }
}

function compactMessageValue(value, maxLength = 64) {
  const clean = String(value ?? '-').replace(/\s+/g, ' ').trim() || '-';
  if (clean.length <= maxLength) return clean;
  return `${clean.slice(0, Math.max(1, maxLength - 1)).trimEnd()}…`;
}

function buildShopeeMessage(issueType, group, rows) {
  const representative = rows[0];
  const count = rows.length;
  const orderId = compactMessageValue(representative?.orderId || '-', 28);
  const tracking = compactMessageValue(representative?.trackingId || '-', 48);
  const carrier = compactMessageValue(group.carrier || '-', 64);
  const incident = issueType === 'no_show'
    ? 'ĐVVC chưa đến lấy hàng dù shop đã chuẩn bị đúng hạn.'
    : 'ĐVVC chưa lấy hết hàng dù shop đã chuẩn bị đúng hạn.';

  return [
    `${incident} Lỗi thuộc ĐVVC.`,
    'Nhờ Shopee thúc đẩy lấy hàng và loại các đơn trong file đính kèm khỏi tỷ lệ giao trễ/vi phạm SLA.',
    '',
    `ĐVVC: ${carrier}`,
    `Số đơn: ${count}`,
    `Mã đơn đại diện: ${orderId}`,
    `Mã vận đơn: ${tracking}`
  ].join('\n');
}

function buildMessage(issueType, group, rows) {
  if (activePlatform === 'shopee') {
    return buildShopeeMessage(issueType, group, rows);
  }
  const representative = rows[0];
  const store = group.channel || '-';
  const carrier = group.carrier || '-';
  const warehouse = group.warehouse || '-';
  const count = rows.length;
  const orderId = representative?.orderId || '-';
  // Dòng đại diện có thể trống Tracking No trong file raw (rất hay gặp với đơn
  // chưa được ĐVVC quét). Trước đây in thẳng "-" khiến nội dung ticket thiếu
  // thông tin dù trong nhóm vẫn có mã vận đơn. Giờ lấy mã đầu tiên tìm được.
  const trackedRow = rows.find((row) => String(row?.trackingId || '').trim());
  const tracking = String(trackedRow?.trackingId || '').trim() ||
    (rows.some((row) => row?.trackingId === '') ? 'chưa có mã vận đơn' : '-');

  const incident = issueType === 'no_show'
    ? 'ĐVVC không đến lấy hàng dù shop đã chuẩn bị hàng đúng hạn.'
    : 'ĐVVC đến nhưng không lấy hết hàng dù shop đã chuẩn bị hàng đúng hạn.';

  const request = 'Lỗi phát sinh từ ĐVVC, không thuộc vận hành shop. TTS vui lòng push ĐVVC đến pickup và loại các đơn trong file đính kèm khỏi Late Dispatch Rate/vi phạm trễ SLA.';
  const details = `Store: ${store}\nĐVVC: ${carrier}\nKho: ${warehouse}\nSố đơn: ${count}\nOrder ID đại diện: ${orderId}\nTracking: ${tracking}`;
  return `${incident}\n\n${request}\n\n${details}`.slice(0, 500);
}

function renderDraft() {
  const empty = $('draftEmpty');
  const content = $('draftContent');
  if (!currentDraft) {
    empty.hidden = false;
    content.hidden = true;
    return;
  }
  empty.hidden = true;
  content.hidden = false;
  currentDraft.text = sanitizeMarketplaceMessage(currentDraft.text);
  const batchText = currentDraft.batchChannelKey ? ' · Channel batch' : '';
  const cnncText = Array.isArray(currentDraft.cnncCodes) && currentDraft.cnncCodes.length
    ? currentDraft.cnncCodes.join(', ')
    : formatCnncCodes(null, currentDraft.rows || []);
  $('draftMeta').textContent = `${currentDraft.channel} · CNNC ${cnncText} · ${currentDraft.carrier} · ${currentDraft.warehouse} · ${currentDraft.rows.length} order(s)${batchText}`;
  $('draftText').value = currentDraft.text;
  $('ticketId').value = '';
}

function setSyncStatus(message, state = '') {
  const box = $('syncStatus');
  if (!box) return;
  box.className = `sync-status${state ? ` ${state}` : ''}`;
  box.textContent = message;
}

function renderPausedSync(state) {
  if (state?.status === 'paused') {
    setSyncStatus(`Đã tạm dừng đồng bộ sau nhiều lần lỗi. ${state.pendingRows || 0} record vẫn được giữ trên máy. Kiểm tra kết nối rồi bấm Gửi lại.`, 'error');
  }
}

function isValidGoogleSyncUrl(value) {
  try {
    const url = new URL(String(value || '').trim());
    return url.protocol === 'https:' &&
      (url.hostname === 'script.google.com' || url.hostname.endsWith('.script.google.com')) &&
      /\/exec\/?$/.test(url.pathname);
  } catch {
    return false;
  }
}

function pendingSyncRecords() {
  return ticketLog.filter((record) =>
    String(record.SyncStatus || '').toLowerCase() !== 'synced'
  );
}

async function postRowsToGoogleSheets(records) {
  if (!isValidGoogleSyncUrl(googleSyncUrl)) {
    throw new Error('Chưa có Web App URL hợp lệ. Dán URL /exec tại Ticket master.');
  }
  if (!records.length) return { inserted: 0, duplicates: 0 };
  const response = await fetch(googleSyncUrl, {
    method: 'POST',
    redirect: 'follow',
    headers: { 'Content-Type': 'text/plain;charset=utf-8' },
    body: JSON.stringify({
      action: 'appendTicketMaster',
      source: 'OnPoint Marketplace Ticket Assistant v0.10.23',
      rows: records
    })
  });
  if (!response.ok) throw new Error(`Google Sheets trả lỗi HTTP ${response.status}.`);
  const text = await response.text();
  let result;
  try {
    result = JSON.parse(text);
  } catch {
    throw new Error('Web App chưa trả JSON. Kiểm tra quyền deploy “Anyone”.');
  }
  if (!result?.ok) throw new Error(result?.error || 'Google Sheets không nhận dữ liệu.');
  return result;
}

/* -----------------------------------------------------------------------------
 * v0.11 — ĐẨY VÀO HÀNG ĐỢI, KHÔNG CHỜ MẠNG.
 *
 * v0.10.x: fetch() thẳng tới Apps Script ngay trong side panel, chờ kết quả,
 * rồi ghi lại TOÀN BỘ mảng ticketLog vào storage — hai lần (thành công và
 * thất bại đều ghi). Với sheet lớn, mỗi lần "Lưu & map" đứng 5–30 giây.
 *
 * v0.11: chuyển record cho service worker; OPSync gộp lô, backoff và retry
 * ở nền. Hàm trả về ngay để nhóm kế tiếp mở được liền.
 * -------------------------------------------------------------------------- */
async function syncRecords(records, { quiet = false } = {}) {
  if (!records.length) {
    if (!quiet) setSyncStatus('Không có record chờ đồng bộ.', 'ok');
    return true;
  }
  try {
    const response = await sendRuntimeMessage({ type: 'OP_SYNC_RETRY' });
    if (!quiet) {
      setSyncStatus(
        `Đã đưa ${records.length} dòng vào hàng đợi đồng bộ · chạy nền, không chặn thao tác.`,
        'running'
      );
    }
    return Boolean(response?.ok ?? true);
  } catch (error) {
    setSyncStatus(`Không gọi được tiến trình nền: ${error.message || error}`, 'error');
    return false;
  }
}

async function saveTicket() {
  if (!currentDraft) return;
  const ticketId = $('ticketId').value.trim();
  if (!ticketId) return opNotify('Nhập mã ticket trước khi lưu.');
  const now = new Date().toISOString();
  const draft = currentDraft;
  const loggedOrderSet = buildLoggedOrderSet();
  const rowsToMap = [];
  for (const row of draft.rows) {
    const key = orderIdKey(row.orderId);
    if (!key || loggedOrderSet.has(key)) continue;
    loggedOrderSet.add(key);
    rowsToMap.push(row);
  }
  if (!rowsToMap.length) {
    opNotify('Các đơn trong draft này đã có Ticket ID, tool không lưu trùng.');
    currentDraft = null;
    await removeBacklogStorage(['currentDraft', 'currentAttachments', 'detectedTicketId']);
    renderDraft();
    renderGroups();
    return;
  }

  const newRecords = [];
  for (const row of rowsToMap) {
    const record = {
      ...(row._original && typeof row._original === 'object' ? row._original : {}),
      TicketID: ticketId,
      TicketPlatform: String(currentDraft.platform || activePlatform).toUpperCase(),
      OrderID: row.orderId,
      TrackingID: row.trackingId,
      CNNC: row.cnnc || deriveCnncCode('', row.orderNo, row.orderId),
      ChannelName: draft.channel,
      DeliveryPlatform: draft.carrier,
      WarehouseBranch: row.warehouse,
      IssueType: draft.issueType,
      OrderStatus: row.status,
      OrderDate: row.orderDate,
      SLADate: row.slaAt,
      TicketCreatedAt: draft.createdAt,
      TicketRecordedAt: now,
      TicketStatus: 'Submitted',
      SyncStatus: 'Pending',
      SyncedAt: '',
      SyncError: '',
      SourceFile: row.sourceFile || sourceFileName
    };
    newRecords.push(record);
    ticketLog.unshift(record);
  }

  // v0.11: nền sở hữu Ticket Master (store phân mảnh). Side panel chỉ giữ bản
  // sao trong RAM để render; ghi bền và đồng bộ Sheet đều chạy ở service worker.
  await sendRuntimeMessage({ type: 'OP_APPEND_RECORDS', records: newRecords });
  rebuildTicketIndex(true);
  const synced = await syncRecords(newRecords, { quiet: true });
  const batchChannelKey = draft.batchChannelKey || activeChannelBatchKey;
  currentDraft = null;
  await removeBacklogStorage(['currentDraft', 'currentAttachments', 'detectedTicketId']);
  renderDraft();
  renderGroups();
  renderLog();

  if (batchChannelKey) {
    activeChannelBatchKey = batchChannelKey;
    selectedChannelKey = batchChannelKey;
    const nextGroupIndex = findNextPendingGroupIndex(batchChannelKey);
    if (nextGroupIndex >= 0) {
      await chrome.storage.local.set({
        activeChannelBatchKey,
        queueSelectedChannel: selectedChannelKey
      });
      await createDraft(nextGroupIndex, {
        batch: true,
        suppressEvidenceAlert: true
      });
    } else {
      const completedChannel = queue.find((group) => channelKey(group.channel) === batchChannelKey)?.channel || draft.channel;
      activeChannelBatchKey = '';
      await chrome.storage.local.set({ queueSelectedChannel: selectedChannelKey });
      await removeBacklogStorage('activeChannelBatchKey');
      renderGroups();
      opNotify(
        `Đã raise và map hết Channel ${completedChannel}.` +
        (synced ? '\nGoogle Sheet đã đồng bộ.' : '\nDữ liệu đang Pending, bấm Sync pending để gửi lại.')
      );
    }
  }
}

function getRecordValue(record, aliases) {
  for (const alias of aliases) {
    if (Object.hasOwn(record, alias)) return record[alias];
  }
  return '';
}

function renderLog() {
  const query = normalize($('searchLog').value);
  const list = $('logList');
  const filtered = ticketLog.filter((record) => !query || normalize(Object.values(record).join(' ')).includes(query));
  if (!filtered.length) {
    list.className = 'log-list empty';
    list.textContent = 'Chưa có ticket đã lưu.';
    return;
  }

  list.className = 'log-list';
  list.innerHTML = '';
  filtered.slice(0, 100).forEach((record) => {
    const ticketId = getRecordValue(record, ['TicketID', 'ticketId']);
    const orderId = getRecordValue(record, ['OrderID', 'orderId']);
    const channel = getRecordValue(record, ['ChannelName', 'channel']);
    const carrier = getRecordValue(record, ['DeliveryPlatform', 'carrier']);
    const cnnc = getRecordValue(record, ['CNNC', 'cnnc']);
    const recorded = getRecordValue(record, ['TicketRecordedAt', 'ticketRecordedAt']);
    const syncStatus = getRecordValue(record, ['SyncStatus']) || 'Pending';
    const item = document.createElement('div');
    item.className = 'log-item';
    item.innerHTML = `<b>${escapeHtml(ticketId)} · ${escapeHtml(orderId)}</b><div>${escapeHtml(channel)} · CNNC ${escapeHtml(cnnc || '-')} · ${escapeHtml(carrier)} · ${formatTimestamp(recorded)} · ${escapeHtml(syncStatus)}</div>`;
    list.appendChild(item);
  });
}

function formatTimestamp(value) {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? String(value || '') : date.toLocaleString('vi-VN');
}

function updateBadge() {
  // v0.11: dùng chỉ mục, không quét lại ticketLog cho từng dòng queue.
  const index = buildLoggedOrderSet();
  const pending = queue.reduce(
    (sum, group) => sum + group.rows.filter((row) => !isOrderLogged(row.orderId, index)).length,
    0
  );
  $('queueBadge').textContent = `${pending} pending`;
}

// ----------------------- Minimal XLSX / ZIP writer -----------------------

let CRC_TABLE;
function getCrcTable() {
  if (CRC_TABLE) return CRC_TABLE;
  CRC_TABLE = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
    CRC_TABLE[n] = c >>> 0;
  }
  return CRC_TABLE;
}

function crc32(bytes) {
  const table = getCrcTable();
  let crc = 0xFFFFFFFF;
  for (const byte of bytes) crc = table[(crc ^ byte) & 0xFF] ^ (crc >>> 8);
  return (crc ^ 0xFFFFFFFF) >>> 0;
}

function u16(value) {
  return new Uint8Array([value & 0xFF, (value >>> 8) & 0xFF]);
}

function u32(value) {
  return new Uint8Array([value & 0xFF, (value >>> 8) & 0xFF, (value >>> 16) & 0xFF, (value >>> 24) & 0xFF]);
}

function concatBytes(parts) {
  const total = parts.reduce((sum, part) => sum + part.length, 0);
  const out = new Uint8Array(total);
  let offset = 0;
  for (const part of parts) {
    out.set(part, offset);
    offset += part.length;
  }
  return out;
}

function dosTimeDate(date = new Date()) {
  const year = Math.max(1980, date.getFullYear());
  const time = (date.getHours() << 11) | (date.getMinutes() << 5) | Math.floor(date.getSeconds() / 2);
  const day = ((year - 1980) << 9) | ((date.getMonth() + 1) << 5) | date.getDate();
  return { time, day };
}

function asBytes(data) {
  if (data instanceof Uint8Array) return data;
  if (data instanceof ArrayBuffer) return new Uint8Array(data);
  return encoder.encode(String(data));
}

function createZip(entries) {
  const localParts = [];
  const centralParts = [];
  let localOffset = 0;
  const stamp = dosTimeDate();

  for (const entry of entries) {
    const nameBytes = encoder.encode(entry.name.replace(/\\/g, '/'));
    const dataBytes = asBytes(entry.data);
    const crc = crc32(dataBytes);
    const localHeader = concatBytes([
      u32(0x04034B50), u16(20), u16(0), u16(0), u16(stamp.time), u16(stamp.day),
      u32(crc), u32(dataBytes.length), u32(dataBytes.length), u16(nameBytes.length), u16(0), nameBytes
    ]);
    localParts.push(localHeader, dataBytes);

    const centralHeader = concatBytes([
      u32(0x02014B50), u16(20), u16(20), u16(0), u16(0), u16(stamp.time), u16(stamp.day),
      u32(crc), u32(dataBytes.length), u32(dataBytes.length), u16(nameBytes.length), u16(0), u16(0),
      u16(0), u16(0), u32(0), u32(localOffset), nameBytes
    ]);
    centralParts.push(centralHeader);
    localOffset += localHeader.length + dataBytes.length;
  }

  const central = concatBytes(centralParts);
  const local = concatBytes(localParts);
  const eocd = concatBytes([
    u32(0x06054B50), u16(0), u16(0), u16(entries.length), u16(entries.length),
    u32(central.length), u32(local.length), u16(0)
  ]);
  return concatBytes([local, central, eocd]);
}

function xmlEscape(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;')
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '');
}

function columnName(index) {
  let n = index + 1;
  let name = '';
  while (n > 0) {
    const remainder = (n - 1) % 26;
    name = String.fromCharCode(65 + remainder) + name;
    n = Math.floor((n - 1) / 26);
  }
  return name;
}

function safeSheetName(value) {
  const clean = String(value || 'Data').replace(/[\\/*?:\[\]]/g, ' ').trim();
  return (clean || 'Data').slice(0, 31);
}

function safeFilePart(value) {
  return String(value || 'Unknown')
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[<>:"/\\|?*\x00-\x1F]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 45) || 'Unknown';
}

function cellXml(ref, value, style = 0) {
  const safe = xmlEscape(value);
  return `<c r="${ref}" t="inlineStr" s="${style}"><is><t xml:space="preserve">${safe}</t></is></c>`;
}

function excelDateSerial(date) {
  const localAsUtc = Date.UTC(
    date.getFullYear(),
    date.getMonth(),
    date.getDate(),
    date.getHours(),
    date.getMinutes(),
    date.getSeconds(),
    date.getMilliseconds()
  );
  return (localAsUtc - Date.UTC(1899, 11, 30)) / 86400000;
}

function outputCellXml(ref, value, header, isHeader) {
  if (!isHeader && (header === 'Order Date' || header === 'SLA Date')) {
    const date = parseDate(value);
    if (date) {
      return `<c r="${ref}" s="2"><v>${excelDateSerial(date)}</v></c>`;
    }
  }
  return cellXml(ref, value, isHeader ? 1 : 0);
}

function createXlsx(headers, objectRows, sheetName = 'Data') {
  const cleanHeaders = headers.length ? headers : ['Data'];
  const rows = [cleanHeaders, ...objectRows.map((row) => cleanHeaders.map((header) => row[header] ?? ''))];
  const lastCol = columnName(cleanHeaders.length - 1);
  const lastRow = rows.length;

  const widths = cleanHeaders.map((header, columnIndex) => {
    let max = Math.min(40, Math.max(10, String(header).length + 2));
    for (let i = 1; i < Math.min(rows.length, 201); i++) {
      max = Math.max(max, Math.min(40, String(rows[i][columnIndex] ?? '').length + 2));
    }
    return max;
  });

  const colsXml = widths.map((width, index) => `<col min="${index + 1}" max="${index + 1}" width="${width}" customWidth="1"/>`).join('');
  const rowXml = rows.map((values, rowIndex) => {
    const cells = values.map((value, columnIndex) =>
      outputCellXml(
        `${columnName(columnIndex)}${rowIndex + 1}`,
        value,
        cleanHeaders[columnIndex],
        rowIndex === 0
      )
    ).join('');
    return `<row r="${rowIndex + 1}"${rowIndex === 0 ? ' ht="24" customHeight="1"' : ''}>${cells}</row>`;
  }).join('');

  const sheetXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <dimension ref="A1:${lastCol}${lastRow}"/>
  <sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>
  <sheetFormatPr defaultRowHeight="15"/>
  <cols>${colsXml}</cols>
  <sheetData>${rowXml}</sheetData>
  <autoFilter ref="A1:${lastCol}${lastRow}"/>
</worksheet>`;

  const stylesXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <numFmts count="1"><numFmt numFmtId="164" formatCode="dd/mm/yyyy hh:mm"/></numFmts>
  <fonts count="2">
    <font><sz val="10"/><name val="Aptos"/></font>
    <font><b/><color rgb="FFFFFFFF"/><sz val="10"/><name val="Aptos"/></font>
  </fonts>
  <fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FFC81920"/><bgColor indexed="64"/></patternFill></fill></fills>
  <borders count="2">
    <border><left/><right/><top/><bottom/><diagonal/></border>
    <border><left style="thin"><color rgb="FFE5E7EB"/></left><right style="thin"><color rgb="FFE5E7EB"/></right><top style="thin"><color rgb="FFE5E7EB"/></top><bottom style="thin"><color rgb="FFE5E7EB"/></bottom><diagonal/></border>
  </borders>
  <cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
  <cellXfs count="3">
    <xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1"><alignment vertical="center"/></xf>
    <xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1"><alignment vertical="center" wrapText="1"/></xf>
    <xf numFmtId="164" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1"><alignment vertical="center"/></xf>
  </cellXfs>
  <cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
</styleSheet>`;

  const workbookXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <sheets><sheet name="${xmlEscape(safeSheetName(sheetName))}" sheetId="1" r:id="rId1"/></sheets>
</workbook>`;

  const workbookRels = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>`;

  const rootRels = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>
  <Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>
</Relationships>`;

  const contentTypes = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
  <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
  <Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
  <Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>
  <Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>
</Types>`;

  const created = new Date().toISOString();
  const coreXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <dc:creator>OnPoint TTS Pickup Ticket Assistant</dc:creator>
  <cp:lastModifiedBy>OnPoint TTS Pickup Ticket Assistant</cp:lastModifiedBy>
  <dcterms:created xsi:type="dcterms:W3CDTF">${created}</dcterms:created>
  <dcterms:modified xsi:type="dcterms:W3CDTF">${created}</dcterms:modified>
</cp:coreProperties>`;

  const appXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes">
  <Application>OnPoint TTS Pickup Ticket Assistant</Application>
</Properties>`;

  return createZip([
    { name: '[Content_Types].xml', data: contentTypes },
    { name: '_rels/.rels', data: rootRels },
    { name: 'docProps/app.xml', data: appXml },
    { name: 'docProps/core.xml', data: coreXml },
    { name: 'xl/workbook.xml', data: workbookXml },
    { name: 'xl/_rels/workbook.xml.rels', data: workbookRels },
    { name: 'xl/styles.xml', data: stylesXml },
    { name: 'xl/worksheets/sheet1.xml', data: sheetXml }
  ]);
}

function triggerDownload(bytes, filename, mime) {
  const blob = new Blob([bytes], { type: mime });
  const url = URL.createObjectURL(blob);
  chrome.downloads.download({ url, filename, saveAs: true }, () => {
    setTimeout(() => URL.revokeObjectURL(url), 30000);
  });
}

function downloadSplitZip() {
  if (!eligibleRows.length || !queue.length) return opNotify('Chưa có dữ liệu backlog để split.');

  const usedNames = new Set();
  const entries = [];
  const indexRows = [];
  const today = new Date();

  queue.forEach((group, index) => {
    const base = `${platformFileLabel()}__${safeFilePart(group.carrier)}__${safeFilePart(group.channel)}__${safeFilePart(group.warehouse)}`;
    let fileName = `${base}.xlsx`;
    let suffix = 2;
    while (usedNames.has(fileName.toLowerCase())) fileName = `${base}_${suffix++}.xlsx`;
    usedNames.add(fileName.toLowerCase());

    const outputRows = group.rows.map(toOutputRow);
    const xlsx = createXlsx(OUTPUT_HEADERS, outputRows, pickupSheetName());
    entries.push({ name: fileName, data: xlsx });
    indexRows.push({
      No: index + 1,
      DeliveryPlatform: group.carrier,
      ChannelName: group.channel,
      WarehouseBranch: group.warehouse,
      OrderCount: group.rows.length,
      OutputFile: fileName
    });
  });

  const indexHeaders = ['No', 'DeliveryPlatform', 'ChannelName', 'WarehouseBranch', 'OrderCount', 'OutputFile'];
  entries.unshift({ name: '00_SPLIT_INDEX.xlsx', data: createXlsx(indexHeaders, indexRows, 'Split Index') });
  entries.push({
    name: 'README.txt',
    data: `OnPoint ${platformFileLabel()} Pickup Backlog Split\r\n\r\nFixed filters:\r\n- Order Status = dl_pending, new, pending_warehouse, wh_completed, wh_processing\r\n- Platform, Store = ${platformLabel()}\r\n- SLA Date = YEAR TO DATE (01/01 through today)\r\n\r\nSplit key: Delivery Platform + Channel Name + Warehouse Branch\r\nWarehouse Branch is used only for grouping and filenames; each output workbook keeps exactly 6 columns.\r\n\r\nOutput columns only:\r\n- Platform Order ID\r\n- Delivery Platform\r\n- Channel Name\r\n- Order Date (dd/mm/yyyy hh:mm)\r\n- SLA Date (dd/mm/yyyy hh:mm)\r\n- Tracking No\r\n\r\nSource: ${sourceFileName}\r\n`
  });

  const zip = createZip(entries);
  const dateTag = today.toISOString().slice(0, 10).replace(/-/g, '');
  triggerDownload(zip, `${platformFileLabel()}_Backlog_Split_${dateTag}.zip`, 'application/zip');
}

function exportTicketLog() {
  if (!ticketLog.length) return opNotify('Chưa có ticket record để export.');
  const headers = [...new Set(ticketLog.flatMap((row) => Object.keys(row)))];
  const normalizedRows = ticketLog.map((row) => Object.fromEntries(headers.map((header) => [header, row[header] ?? ''])));
  const bytes = createXlsx(headers, normalizedRows, 'Ticket Master');
  const dateTag = new Date().toISOString().slice(0, 10).replace(/-/g, '');
  // Ticket Master gộp cả hai sàn nên KHÔNG gắn tên sàn vào đây.
  triggerDownload(bytes, `OnPoint_Ticket_Master_${dateTag}.xlsx`, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
}

// ----------------------- Power BI automation -----------------------

function renderPbiStatus(payload) {
  if (!payload) return;
  const box = $('pbiStatus');
  const openOutput = $('openOutput');
  box.className = 'status-box';
  if (payload.step === 'error') box.classList.add('error');
  else if (payload.step === 'done') box.classList.add('ok');
  else box.classList.add('running');
  box.textContent = payload.message || '';
  openOutput.hidden = !(payload.step === 'done' && payload.outputPath);
}

function sendRuntimeMessage(message) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(message, (response) => {
      if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
      else resolve(response);
    });
  });
}

async function runPbiAutomation() {
  const warehouses = collectWarehouseSelection();
  if (!warehouses.length) {
    renderWarehouseSelectionSummary();
    renderPbiStatus({
      step: 'error',
      message: 'Chưa chọn Warehouse FFM. Hãy tick ít nhất 1 kho: TNSL, TOLL hoặc MCL.'
    });
    return;
  }
  await persistWarehouseSelection();
  renderPbiStatus({
    step: 'start',
    message: `Đang kết nối Power BI · Warehouse FFM: ${warehouses.join(' + ')}…`
  });
  try {
    const response = await sendRuntimeMessage({
      type: 'START_PBI_AUTOMATION',
      options: { warehouses, platform: platformLabel() }
    });
    if (response && !response.ok) throw new Error(response.error || 'Power BI automation failed.');
  } catch (error) {
    renderPbiStatus({ step: 'error', message: `Không chạy được: ${error.message}` });
  }
}

async function openOutputFolder() {
  const response = await chrome.runtime.sendMessage({ type: 'OPEN_TTS_OUTPUT' });
  if (!response?.ok) {
    renderPbiStatus({
      step: 'error',
      message: response?.error || 'Không mở được folder Excel đã split.'
    });
  }
}

async function reloadAutomaticQueue() {
  const data = await chrome.storage.local.get([
    'queueRows',
    'queueSourceFileName',
    'queueRawCount',
    'queueSelectedChannel',
    'activeChannelBatchKey',
    'currentDraft',
    'ticketOpenGroups'
  ]);
  eligibleRows = Array.isArray(data.queueRows) ? data.queueRows : [];
  sourceFileName = String(data.queueSourceFileName || '');
  importedRawCount = Number(data.queueRawCount || eligibleRows.length);
  selectedChannelKey = String(data.queueSelectedChannel || 'all');
  activeChannelBatchKey = String(data.activeChannelBatchKey || '');
  currentDraft = data.currentDraft || null;
  ticketOpenGroups = data.ticketOpenGroups && typeof data.ticketOpenGroups === 'object'
    ? data.ticketOpenGroups
    : {};
  queue = groupRows(eligibleRows);
  renderDraft();
  renderDataset();
  updateBadge();
}

// ----------------------- Events / initialization -----------------------

$('runPbi').addEventListener('click', runPbiAutomation);
$('openOutput').addEventListener('click', openOutputFolder);
document.querySelectorAll('.platform-tab').forEach((button) => {
  button.addEventListener('click', () => {
    switchPlatform(button.dataset.platform).catch((error) => opNotify(error.message || String(error)));
  });
});
$('shopeeEmail').addEventListener('change', () => {
  chrome.storage.local.set({ shopeeEmail: $('shopeeEmail').value.trim() }).catch(() => {});
});
$('shopeeIssue').addEventListener('change', () => {
  chrome.storage.local.set({ shopeeIssue: $('shopeeIssue').value.trim() }).catch(() => {});
});
for (const option of WAREHOUSE_FFM_OPTIONS) {
  $(option.id)?.addEventListener('change', () => {
    renderWarehouseSelectionSummary();
    persistWarehouseSelection().catch(() => {});
  });
}

$('dataFile').addEventListener('change', async (event) => {
  const file = event.target.files[0];
  if (!file) return;
  try {
    const parsed = await parseInputFile(file);
    sourceHeaders = parsed.headers;
    sourceFileName = file.name;
    rawRows = standardize(parsed.rows, parsed.headers, file.name);
    importedRawCount = rawRows.length;
    const result = preparePowerBiExportRows(rawRows);
    eligibleRows = result.filtered;
    queue = groupRows(eligibleRows);
    selectedChannelKey = 'all';
    activeChannelBatchKey = '';
    ticketOpenGroups = {};
    currentDraft = null;
    await removeBacklogStorage([
      'currentDraft',
      'currentAttachments',
      'detectedTicketId',
      'activeChannelBatchKey',
      'ticketOpenGroups',
      'ticketTabPayloads',
      'ticketBatchEvidence'
    ]);
    await persistQueueState();
    renderDraft();
    renderDataset();
    if (!eligibleRows.length) {
      opNotify('Không có dòng hợp lệ: cần đủ Order ID, Channel Name, Delivery Platform và Warehouse Branch.');
    } else {
      downloadSplitZip();
    }
  } catch (error) {
    sourceHeaders = [];
    sourceFileName = '';
    rawRows = [];
    importedRawCount = 0;
    eligibleRows = [];
    queue = [];
    selectedChannelKey = 'all';
    activeChannelBatchKey = '';
    ticketOpenGroups = {};
    await removeBacklogStorage([
      'queueRows',
      'queueSourceFileName',
      'queueRawCount',
      'queueSelectedChannel',
      'queueSavedAt',
      'activeChannelBatchKey',
      'ticketOpenGroups',
      'ticketTabPayloads',
      'ticketBatchEvidence'
    ]);
    renderDataset();
    opNotify(error.message || String(error));
  }
});

$('evidenceFolder').addEventListener('change', handleEvidenceFolder);
$('rerollEvidence').addEventListener('click', selectRandomEvidence);
$('downloadSplit').addEventListener('click', downloadSplitZip);
$('channelFilter').addEventListener('change', async (event) => {
  selectedChannelKey = event.target.value || 'all';
  await chrome.storage.local.set({ queueSelectedChannel: selectedChannelKey });
  renderGroups();
});
$('raiseChannel').addEventListener('click', () => startChannelBatch());
$('ticketMode').addEventListener('change', () => {
  queue = groupRows(eligibleRows);
  selectedChannelKey = 'all';
  renderDataset();
});
$('clearQueue').addEventListener('click', async () => {
  rawRows = [];
  importedRawCount = 0;
  eligibleRows = [];
  queue = [];
  sourceHeaders = [];
  sourceFileName = '';
  currentDraft = null;
  selectedChannelKey = 'all';
  activeChannelBatchKey = '';
  ticketOpenGroups = {};
  $('dataFile').value = '';
  await removeBacklogStorage([
    'currentDraft',
    'currentAttachments',
    'detectedTicketId',
    'queueRows',
    'queueSourceFileName',
    'queueRawCount',
    'queueSelectedChannel',
    'queueSavedAt',
    'activeChannelBatchKey',
    'ticketOpenGroups',
    'ticketTabPayloads',
    'ticketBatchEvidence'
  ]);
  renderDraft();
  renderDataset();
});
$('copyDraft').addEventListener('click', async () => navigator.clipboard.writeText($('draftText').value));
$('openTicket').addEventListener('click', openCurrentTicket);
$('saveTicket').addEventListener('click', saveTicket);
$('openTicketMaster').addEventListener('click', () => {
  chrome.tabs.create({ url: GOOGLE_TICKET_MASTER_URL });
});
$('exportLog').addEventListener('click', exportTicketLog);
$('searchLog').addEventListener('input', renderLog);
$('saveSyncUrl').addEventListener('click', async () => {
  const value = $('googleSyncUrl').value.trim();
  if (!isValidGoogleSyncUrl(value)) {
    setSyncStatus('URL không hợp lệ. Phải là URL Web App kết thúc bằng /exec.', 'error');
    return;
  }
  googleSyncUrl = value;
  await chrome.storage.local.set({ googleSyncUrl });
  setSyncStatus(`Đã lưu URL · ${pendingSyncRecords().length} record chờ đồng bộ.`, 'ok');
});
$('syncPending').addEventListener('click', async () => {
  setSyncStatus('Đang đẩy lại toàn bộ record Pending…', 'running');
  const response = await sendRuntimeMessage({ type: 'OP_SYNC_RETRY' }).catch((error) => ({
    ok: false, error: error.message || String(error)
  }));
  if (response?.ok) {
    setSyncStatus(`Đã đưa ${response.queued || 0} record vào hàng đợi · đang gửi nền.`, 'running');
  } else {
    setSyncStatus(`Không gửi lại được: ${response?.error || 'lỗi không xác định'}`, 'error');
  }
});

/* -----------------------------------------------------------------------------
 * v0.11 — CHỌN BACKEND ĐỒNG BỘ.
 * Apps Script (mặc định) chạy ngay không cần setup. Google Sheets API cần một
 * OAuth client nhưng nhanh hơn 20–50 lần vì chỉ đọc đúng một cột chỉ mục và
 * ghi cả lô trong 1–2 lời gọi thay vì đọc cả sheet + ghi từng dòng.
 * -------------------------------------------------------------------------- */
function oauthReady() {
  try {
    const id = chrome.runtime.getManifest()?.oauth2?.client_id || '';
    return Boolean(id) && id.includes('.apps.googleusercontent.com') && !/REPLACE_WITH/i.test(id);
  } catch (_) { return false; }
}

function renderBackendControls(backend) {
  // Chưa có OAuth client thì khoá hẳn lựa chọn Sheets API — chọn vào chỉ để
  // nhận lỗi "bad client id" rồi hàng đợi đứng, không giúp được gì.
  const sheetsOption = $('syncBackend')?.querySelector('option[value="sheets"]');
  if (sheetsOption) {
    const ready = oauthReady();
    sheetsOption.disabled = !ready;
    sheetsOption.textContent = ready
      ? 'Backend: Google Sheets API (nhanh nhất)'
      : 'Backend: Google Sheets API — cần tạo OAuth client trước (xem README mục 3)';
  }
  const isSheets = backend === 'sheets';
  $('sheetsApiConfig').hidden = !isSheets;
  $('connectGoogle').hidden = !isSheets;
  $('googleSyncUrl').disabled = isSheets;
}

$('syncBackend').addEventListener('change', async (event) => {
  const backend = event.target.value === 'sheets' ? 'sheets' : 'script';
  await chrome.storage.local.set({ syncBackend: backend });
  renderBackendControls(backend);
  setSyncStatus(
    backend === 'sheets'
      ? 'Đã chuyển sang Google Sheets API. Điền Spreadsheet ID rồi bấm "Kết nối Google".'
      : 'Đã chuyển về Apps Script Web App.',
    'ok'
  );
});

$('diagnoseSync').addEventListener('click', async () => {
  setSyncStatus('Đang kiểm tra kết nối tới Google Sheet…', 'running');
  const r = await sendRuntimeMessage({ type: 'OP_SYNC_DIAGNOSE' }).catch((e) => ({ ok: false, error: String(e) }));
  if (!r?.ok) { setSyncStatus(`Không chạy được kiểm tra: ${r?.error || ''}`, 'error'); return; }

  const lines = [];
  if (r.isDefaultUrl) {
    lines.push('⚠ Đang dùng Web App URL MẶC ĐỊNH có sẵn trong code, không phải URL của Sheet bạn.');
  }
  for (const [key, label] of [['get', 'GET'], ['post', 'POST']]) {
    const p = r[key];
    if (!p) continue;
    if (p.error) { lines.push(`${label}: LỖI — ${p.error}`); continue; }
    lines.push(`${label}: HTTP ${p.status} (${p.ms}ms)` +
      (p.looksLikeLogin ? ' — trả về trang ĐĂNG NHẬP' : p.looksLikeJson ? ' — trả JSON đúng' : ' — không phải JSON'));
  }
  const post = r.post || {};
  if (post.looksLikeLogin) {
    lines.push('→ Deploy đang đặt "Who has access" KHÔNG phải "Anyone". Vào Apps Script → Deploy → Manage deployments → sửa thành Anyone.');
  } else if (post.status && post.status >= 400) {
    lines.push('→ URL sai hoặc deployment đã bị xoá. Deploy lại và dán URL /exec mới.');
  } else if (post.looksLikeJson) {
    lines.push('→ Endpoint OK. Nếu vẫn Pending, bấm "Gửi lại".');
  }
  if (post.body) lines.push(`Phản hồi: ${String(post.body).slice(0, 160)}`);
  setSyncStatus(lines.join('\n'), post.looksLikeJson ? 'ok' : 'error');
  console.log('[OnPoint] chẩn đoán sync', r);
});

$('connectGoogle').addEventListener('click', async () => {
  const response = await sendRuntimeMessage({ type: 'OP_CONNECT_GOOGLE' }).catch((error) => ({
    ok: false, error: error.message || String(error)
  }));
  setSyncStatus(
    response?.ok
      ? 'Đã cấp quyền Google. Lần đồng bộ tới sẽ đi thẳng qua Sheets API.'
      : `Chưa kết nối được Google: ${response?.error || ''}`,
    response?.ok ? 'ok' : 'error'
  );
});

for (const id of ['sheetsSpreadsheetId', 'sheetsTabName']) {
  $(id).addEventListener('change', async (event) => {
    await chrome.storage.local.set({ [id]: String(event.target.value || '').trim() });
    await sendRuntimeMessage({ type: 'OP_SYNC_STATUS' }).catch(() => {});
  });
}

// Băng trạng thái đồng bộ: luôn thấy còn bao nhiêu dòng đang chờ, thay vì phải
// đoán xem sync đã xong chưa.
(function mountSyncUi() {
  if (!globalThis.OPPanel) return;
  const container = document.querySelector('.sync-config');
  if (container) OPPanel.mountSyncBar(container);
  OPPanel.watchSync();
  chrome.storage.local.get(['syncBackend', 'sheetsSpreadsheetId', 'sheetsTabName'], (data) => {
    let backend = data.syncBackend === 'sheets' ? 'sheets' : 'script';
    if (backend === 'sheets' && !oauthReady()) {
      backend = 'script';
      chrome.storage.local.set({ syncBackend: 'script' });
      setSyncStatus('Sheets API chưa cấu hình OAuth — đã tự chuyển về Apps Script.', 'ok');
    }
    $('syncBackend').value = backend;
    $('sheetsSpreadsheetId').value = String(data.sheetsSpreadsheetId || '');
    $('sheetsTabName').value = String(data.sheetsTabName || 'Ticket Master');
    renderBackendControls(backend);
  });
})();

function autoMapResultKey(result) {
  if (!result?.ticketId || !result?.capturedAt) return '';
  return `${result.ticketId}|||${result.groupKey || ''}|||${result.capturedAt}`;
}

async function handleTicketAutoMapResult(result) {
  const resultKey = autoMapResultKey(result);
  if (!resultKey) return;
  const alreadyHandledLocally = resultKey === lastAutoMapHandledKey;
  if (!alreadyHandledLocally) lastAutoMapHandledKey = resultKey;

  const stored = await chrome.storage.local.get([
    'ticketAutoMapHandledKey',
    'ticketAutoMapResult',
    'ticketLog',
    'currentDraft'
  ]);

  ticketLog = await loadTicketLog();
  currentDraft = stored.currentDraft || null;
  renderLog();
  renderDraft();
  renderGroups();

  const storedResult = stored.ticketAutoMapResult;
  const displayResult =
    autoMapResultKey(storedResult) === resultKey &&
    result.syncPending &&
    !storedResult.syncPending
      ? storedResult
      : result;

  if (displayResult.syncPending) {
    setSyncStatus(
      `Ticket ${displayResult.ticketId} đã lưu ${displayResult.mappedCount || 0} đơn · đang đồng bộ Google Sheet nền.`,
      'running'
    );
  } else {
    setSyncStatus(
      displayResult.syncOk
        ? `Ticket ${displayResult.ticketId} đã tự map ${displayResult.mappedCount || 0} đơn · Google Sheet đã đồng bộ.`
        : `Ticket ${displayResult.ticketId} đã tự map ${displayResult.mappedCount || 0} đơn · đang Pending sync: ${displayResult.syncError || 'chưa đồng bộ được'}`,
      displayResult.syncOk ? 'ok' : 'error'
    );
  }

  const alreadyHandled = alreadyHandledLocally || stored.ticketAutoMapHandledKey === resultKey;
  if (alreadyHandled) return;

  const batchChannelKey = String(result.batchChannelKey || '');
  if (batchChannelKey) {
    activeChannelBatchKey = batchChannelKey;
    selectedChannelKey = batchChannelKey;
    const nextGroupIndex = findNextPendingGroupIndex(batchChannelKey);
    if (nextGroupIndex >= 0) {
      await chrome.storage.local.set({
        activeChannelBatchKey,
        queueSelectedChannel: selectedChannelKey,
        ticketAutoMapHandledKey: resultKey
      });
      await createDraft(nextGroupIndex, {
        batch: true,
        suppressEvidenceAlert: true
      });
      return;
    }
    activeChannelBatchKey = '';
    await chrome.storage.local.set({
      queueSelectedChannel: selectedChannelKey,
      ticketAutoMapHandledKey: resultKey
    });
    await removeBacklogStorage('activeChannelBatchKey');
    renderGroups();
    return;
  }

  await chrome.storage.local.set({ ticketAutoMapHandledKey: resultKey });
}


/* ------------------------------------------------- v0.11.1 · điều khiển SLA */
$('slaWindow').addEventListener('change', async (event) => {
  slaWindowId = event.target.value;
  $('slaCustomRow').hidden = slaWindowId !== 'custom';
  await chrome.storage.local.set({ slaWindowId });
  renderGroups();
});

$('slaCustom').addEventListener('change', async (event) => {
  const value = event.target.value;
  slaCustomUntil = value ? new Date(value) : null;
  if (slaCustomUntil && Number.isNaN(slaCustomUntil.getTime())) slaCustomUntil = null;
  await chrome.storage.local.set({ slaCustomUntil: value || '' });
  renderGroups();
});

for (const [id, bucket] of [['slaD0', 'D0'], ['slaD1', 'D1']]) {
  $(id).addEventListener('change', async (event) => {
    slaBuckets[bucket] = event.target.checked;
    // Bỏ tick cả hai thì không còn gì để raise — bật lại cái vừa tắt.
    if (!slaBuckets.D0 && !slaBuckets.D1) {
      slaBuckets[bucket] = true;
      event.target.checked = true;
      opNotify('Phải giữ ít nhất một nhóm Order created.');
      return;
    }
    await chrome.storage.local.set({ slaBuckets });
    renderGroups();
  });
}

// Đếm ngược phải tự trôi: một nhóm "còn 2h05" sẽ thành "dưới 2h" mà không cần
// user bấm gì. Một phút một lần là đủ mịn và gần như không tốn CPU.
$('slaSource').addEventListener('change', async (event) => {
  slaSource = ['auto', 'rule', 'file'].includes(event.target.value) ? event.target.value : 'auto';
  await chrome.storage.local.set({ slaSource });
  renderGroups();
});

$('slaHideOutside').addEventListener('change', async (event) => {
  slaHideOutside = event.target.checked;
  await chrome.storage.local.set({ slaHideOutside });
  renderGroups();
});

setInterval(() => { if (queue.length) renderGroups(); }, 60000);

/* v0.11.9 — tiến trình từng bước của tab ticket hiện Ở ĐÂY, không còn popup
   nổi trên trang TikTok che mất form. */
const ticketSteps = new Map();
const STEP_ORDER = ['subject', 'fields', 'upload', 'submit', 'map'];
const STEP_ICON = { run: '◐', ok: '✓', err: '✗', need: '!', done: '✓' };

function renderTicketSteps() {
  const box = $('channelProgress');
  if (!box || !ticketSteps.size) return;
  const action = ticketSteps.get('action');
  const rows = STEP_ORDER
    .filter((k) => ticketSteps.has(k))
    .map((k) => {
      const s = ticketSteps.get(k);
      return `${STEP_ICON[s.state] || '·'} ${s.label}` +
        (s.ms ? ` ${(s.ms / 1000).toFixed(1)}s` : '') +
        (s.note ? ` — ${s.note}` : '');
    });
  if (action) rows.push(`${action.state === 'done' ? '✓' : '⚠'} ${action.note}`);
  box.textContent = rows.join('   ·   ');
}

chrome.runtime.onMessage.addListener((message) => {
  // Thông báo dạng câu từ tab ticket (thay cho popup cũ trên trang TikTok).
  if (message?.type === 'TICKET_STEP_TEXT') {
    const box = $('channelProgress');
    if (box) {
      box.textContent = message.text;
      box.style.color = message.warn ? '#b42318' : '';
    }
    return;
  }
  if (message?.type === 'TICKET_STEP') {
    ticketSteps.set(message.step, {
      label: message.label, state: message.state, ms: message.ms, note: message.note
    });
    renderTicketSteps();
    return;
  }
  if (message?.type === 'PBI_AUTOMATION_PROGRESS') {
    renderPbiStatus(message);
    if (message.queueReady) {
      reloadAutomaticQueue().catch((error) => {
        renderPbiStatus({
          step: 'error',
          message: `Excel đã split nhưng không hiển thị được Ticket queue: ${error.message}`
        });
      });
    }
  }
});

if (chrome.storage?.onChanged?.addListener) {
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== 'local') return;
    if (changes['sync:state']) renderPausedSync(changes['sync:state'].newValue);
    if (changes.queueSavedAt?.newValue) {
      reloadAutomaticQueue().catch(() => {});
    }
    if (changes.ticketOpenGroups) {
      ticketOpenGroups = changes.ticketOpenGroups.newValue &&
        typeof changes.ticketOpenGroups.newValue === 'object'
        ? changes.ticketOpenGroups.newValue
        : {};
      renderGroups();
    }
    // v0.11: nền không còn ghi cả mảng ticketLog vào storage, chỉ đổi con trỏ
    // phiên bản. Side panel nghe con trỏ đó rồi đọc lại từ store phân mảnh.
    // Bất kỳ chunk nào của Ticket Master đổi cũng phải nạp lại — không chỉ
    // meta. Trạng thái Synced được vá thẳng vào chunk, nếu chỉ nghe tl:meta thì
    // danh sách vẫn hiện Pending dù dữ liệu đã đúng.
    const ticketChunkChanged = Object.keys(changes).some((k) => /^tl:c\d+$/.test(k));
    if (changes.ticketLogVersion || changes['tl:meta'] || ticketChunkChanged) scheduleTicketLogReload();
    if (changes.currentDraft) {
      currentDraft = changes.currentDraft.newValue || null;
      renderDraft();
      renderGroups();
    }
    if (changes.ticketAutoMapResult?.newValue) {
      handleTicketAutoMapResult(changes.ticketAutoMapResult.newValue).catch((error) => {
        setSyncStatus(`Đã bắt được Ticket ID nhưng không cập nhật được panel: ${error.message || error}`, 'error');
      });
    }
    if (currentDraft) {
      const detectedTicketId = changes.detectedTicketId?.newValue;
      if (detectedTicketId) $('ticketId').value = detectedTicketId;
    }
  });
}

chrome.storage.local.get([
  'ticketLog',
  'sync:state',
  'currentDraft',
  'detectedTicketId',
  'pbiLastRun',
  'pbiWarehouseSelection',
  'evidenceFiles',
  'queueRows',
  'queueSourceFileName',
  'queueRawCount',
  'queueSelectedChannel',
  'activeChannelBatchKey',
  'ticketOpenGroups'
  ,'activePlatform'
  ,'shopeeEmail'
  ,'shopeeIssue'
  ,'shopeeFormChoice'
  ,'googleSyncUrl'
  ,'ticketAutoMapResult'
  ,'ticketAutoMapHandledKey'
  ,'slaWindowId'
  ,'slaCustomUntil'
  ,'slaBuckets'
  ,'slaSource'
  ,'slaHideOutside'
], (data) => {
  renderPausedSync(data['sync:state']);
  slaSource = ['auto', 'rule', 'file'].includes(data.slaSource) ? data.slaSource : 'auto';
  slaHideOutside = Boolean(data.slaHideOutside);
  $('slaSource').value = slaSource;
  $('slaHideOutside').checked = slaHideOutside;
  slaWindowId = String(data.slaWindowId || 'all');
  slaCustomUntil = data.slaCustomUntil ? new Date(data.slaCustomUntil) : null;
  if (slaCustomUntil && Number.isNaN(slaCustomUntil.getTime())) slaCustomUntil = null;
  if (data.slaCustomUntil) $('slaCustom').value = data.slaCustomUntil;
  if (data.slaBuckets && typeof data.slaBuckets === 'object') {
    slaBuckets = { D0: data.slaBuckets.D0 !== false, D1: data.slaBuckets.D1 !== false };
  }
  $('slaD0').checked = slaBuckets.D0;
  $('slaD1').checked = slaBuckets.D1;
  renderSlaControls();
  activePlatform = data.activePlatform === 'shopee' ? 'shopee' : 'tiktok';
  renderPlatformView();
  $('shopeeEmail').value = String(data.shopeeEmail || DEFAULT_SHOPEE_EMAIL);
  $('shopeeIssue').value = DEFAULT_SHOPEE_ISSUE;
  restoreShopeeFormChoice(data.shopeeFormChoice); // v2.2.4
  loadTicketLog().then((records) => { ticketLog = records; rebuildTicketIndex(true); renderLog(); renderGroups(); });
  currentDraft = data.currentDraft || null;
  evidenceFiles = Array.isArray(data.evidenceFiles) ? data.evidenceFiles : [];
  eligibleRows = Array.isArray(data.queueRows) ? data.queueRows : [];
  sourceFileName = String(data.queueSourceFileName || '');
  importedRawCount = Number(data.queueRawCount || eligibleRows.length);
  selectedChannelKey = String(data.queueSelectedChannel || 'all');
  activeChannelBatchKey = String(data.activeChannelBatchKey || '');
  googleSyncUrl = String(data.googleSyncUrl || DEFAULT_GOOGLE_SYNC_URL).trim();
  $('googleSyncUrl').value = googleSyncUrl;
  if (!data.googleSyncUrl) chrome.storage.local.set({ googleSyncUrl });
  ticketOpenGroups = data.ticketOpenGroups && typeof data.ticketOpenGroups === 'object'
    ? data.ticketOpenGroups
    : {};
  queue = groupRows(eligibleRows);
  applyWarehouseSelection(data.pbiWarehouseSelection);
  renderEvidence();
  renderLog();
  renderDraft();
  renderDataset();
  updateBadge();
  if (data.pbiLastRun) renderPbiStatus(data.pbiLastRun);
  if (data.detectedTicketId && currentDraft) $('ticketId').value = data.detectedTicketId;
  if (googleSyncUrl) {
    const pending = pendingSyncRecords().length;
    setSyncStatus(
      pending
        ? `Đã cấu hình · ${pending} record chờ đồng bộ.`
        : 'Đã cấu hình · không có record pending.',
      pending ? '' : 'ok'
    );
  }
  lastAutoMapHandledKey = String(data.ticketAutoMapHandledKey || '');
  if (data.ticketAutoMapResult && autoMapResultKey(data.ticketAutoMapResult) !== lastAutoMapHandledKey) {
    handleTicketAutoMapResult(data.ticketAutoMapResult).catch((error) => {
      setSyncStatus(`Đã bắt được Ticket ID nhưng không cập nhật được panel: ${error.message || error}`, 'error');
    });
  }
});

/* v2.2.4 — Pickup backlog Shopee: raise đúng webform Người bán (lib/op-shopee-pickup.js).
   Mặc định form Câu hỏi chung như cũ; có thể chọn 1 trong 2 form lấy hàng (2 form này cũng là Loại ticket riêng).
   Form chỉ có Vấn đề cần hỗ trợ + Mã đơn đại diện + file Danh sách đơn hàng (.xlsx) (+ Mô tả thêm ở form khiếu nại);
   ảnh bằng chứng không đính kèm được (form chỉ nhận .xlsx/.xls) nên tool chỉ gửi file Excel. */
function shopeeFormChoice() {
  return $('shopeeForm')?.value || 'general';
}
function applyShopeeFormChoice(draft, group, rows, issueType) {
  const pick = OPShopeePickup.parse(shopeeFormChoice());
  if (!pick) return draft;
  Object.assign(draft, { shopeeForm: pick.form.id, shopeeFormOption: pick.index, shopeeIssue: pick.option });
  draft.text = pick.form.note
    ? OPShopeePickup.note({ count: rows.length, carrier: group.carrier, channel: group.channel, reason: issueType === 'no_show' ? 'ĐVVC chưa đến lấy hàng dù shop đã chuẩn bị đúng hạn' : 'ĐVVC chưa lấy hết hàng dù shop đã chuẩn bị đúng hạn' })
    : '';
  return draft;
}
function syncShopeeFormView() {
  const pick = OPShopeePickup.parse(shopeeFormChoice());
  if ($('shopeeIssue')) $('shopeeIssue').value = pick ? `${pick.form.title} → ${pick.option}` : DEFAULT_SHOPEE_ISSUE;
  if ($('shopeeEmailRow')) $('shopeeEmailRow').hidden = Boolean(pick);
  const note = $('shopeeFormNote');
  if (note) note.innerHTML = pick
    ? `<b>Form "[Người bán] ${escapeHtml(pick.form.title)}"</b><br />Tool tự chọn <b>${escapeHtml(pick.option)}</b>, điền Mã đơn đại diện, tải file Excel vào <b>Danh sách đơn hàng</b>${pick.form.note ? ', điền Mô tả thêm' : ''} và tự bấm <b>Gửi</b> một lần; mã phiếu tự lưu vào Ticket Master. Form chỉ nhận .xlsx nên ảnh bằng chứng không gửi kèm. Theo dõi phiếu: seller-service.cs.shopee.vn → Yêu cầu của tôi.`
    : '<b>Form CSKH Shopee</b><br />Tool tự chọn <b>Người bán → Câu hỏi chung/ Vấn đề khác</b>, điền Email, nội dung tối đa 999 ký tự và upload file. Mã đơn đại diện nằm trong nội dung/file; tool tự tick đồng ý và bấm <b>Gửi</b> một lần.';
}
function restoreShopeeFormChoice(value) {
  const select = $('shopeeForm');
  if (select && [...select.options].some(option => option.value === value)) select.value = value;
  syncShopeeFormView();
}
$('shopeeForm')?.addEventListener('change', () => {
  syncShopeeFormView();
  if (currentDraft?.platform === 'shopee') { currentDraft = null; chrome.storage.local.remove(['currentDraft', 'currentAttachments']).catch(() => {}); renderDraft(); }
  chrome.storage.local.set({ shopeeFormChoice: shopeeFormChoice() }).catch(() => {});
});
