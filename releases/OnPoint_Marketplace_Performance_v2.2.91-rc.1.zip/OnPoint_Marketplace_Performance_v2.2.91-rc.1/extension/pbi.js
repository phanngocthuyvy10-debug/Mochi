(() => {
  if (globalThis.__ONPOINT_TTS_BACKLOG_AUTOMATION__) {
    return;
  }
  globalThis.__ONPOINT_TTS_BACKLOG_AUTOMATION__ = true;

  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  const FAST_POLL_MS = 90;
  const REPORT_QUIET_MS = 260;
  const REPORT_REACTION_GRACE_MS = 620;
  const SLICER_CLICK_CADENCE_MS = 180;

  let reportActionSequence = 0;
  let lastSettledReportActionSequence = -1;
  let lastReportActionAt = 0;
  let lastRelevantReportMutationAt = 0;

  function markReportAction() {
    reportActionSequence += 1;
    lastReportActionAt = Date.now();
    return reportActionSequence;
  }

  function isRelevantReportMutation(mutation) {
    const target =
      mutation.target instanceof Element
        ? mutation.target
        : mutation.target?.parentElement;
    if (!target) return false;
    return Boolean(
      target.closest(
        ".visual-container, .visualContainerHost, [class*='visual-container'], [class*='visualContainer'], [role='grid'], [role='table'], [role='listbox'], [role='dialog'], [aria-busy]",
      ),
    );
  }

  if (typeof MutationObserver === "function" && document.documentElement) {
    // v0.11 — GIỚI HẠN CHI PHÍ OBSERVER.
    //
    // Power BI bắn hàng nghìn mutation mỗi giây khi report đang render.
    // v0.10.x gọi isRelevantReportMutation() (bên trong là element.closest()
    // với một selector rất dài) cho TỪNG mutation → observer tự nó trở thành
    // nguồn giật. Nhưng thứ ta cần chỉ là một dấu thời gian "vừa có thay đổi
    // đáng kể", nên:
    //   • đã đánh dấu trong 50ms gần đây  → bỏ qua cả lô, không kiểm tra gì
    //   • ngược lại                        → chỉ kiểm tra tối đa 30 mutation đầu
    const MUTATION_MARK_THROTTLE_MS = 50;
    const MUTATION_SAMPLE_LIMIT = 30;
    const reportMutationObserver = new MutationObserver((mutations) => {
      const now = Date.now();
      if (now - lastRelevantReportMutationAt < MUTATION_MARK_THROTTLE_MS) return;
      const sample = mutations.length > MUTATION_SAMPLE_LIMIT
        ? mutations.slice(0, MUTATION_SAMPLE_LIMIT)
        : mutations;
      if (sample.some(isRelevantReportMutation)) {
        lastRelevantReportMutationAt = now;
      }
    });
    reportMutationObserver.observe(document.documentElement, {
      subtree: true,
      childList: true,
      characterData: true,
      attributes: true,
      attributeFilter: [
        "aria-busy",
        "aria-checked",
        "aria-expanded",
        "aria-label",
        "aria-selected",
        "value",
      ],
    });
  }
  const normalize = (value) =>
    String(value ?? "")
      .replace(/\u00a0/g, " ")
      .replace(/\s+/g, " ")
      .trim()
      .toLowerCase();

  // v0.11 — LỌC HAI TẦNG.
  // getClientRects() trả mảng rỗng cho display:none và cho node kích thước 0,
  // chỉ tốn một phép đọc layout. Chỉ node qua được tầng này mới phải chịu
  // getComputedStyle — thao tác đắt gấp nhiều lần và là thứ làm chậm mọi vòng
  // quét slicer của v0.10.x.
  const isVisible = (element) => {
    if (!(element instanceof Element)) {
      return false;
    }
    const rects = element.getClientRects();
    if (!rects.length || rects[0].width <= 2 || rects[0].height <= 2) {
      return false;
    }
    const style = getComputedStyle(element);
    return style.visibility !== "hidden" && Number(style.opacity || 1) > 0;
  };

  function horizontalOverlapRatio(firstRect, secondRect) {
    const overlap = Math.max(
      0,
      Math.min(firstRect.right, secondRect.right) -
        Math.max(firstRect.left, secondRect.left),
    );
    return overlap / Math.max(1, Math.min(firstRect.width, secondRect.width));
  }

  function isNearSlicer(element, visual, maxDistance = 650) {
    if (!isVisible(element) || !isVisible(visual)) {
      return false;
    }
    if (visual.contains(element)) {
      return true;
    }

    const elementRect = element.getBoundingClientRect();
    const visualRect = visual.getBoundingClientRect();
    const overlapsHorizontally =
      horizontalOverlapRatio(elementRect, visualRect) >= 0.25 ||
      (elementRect.left <= visualRect.left + visualRect.width / 2 &&
        elementRect.right >= visualRect.left + visualRect.width / 2);
    const verticalGap =
      elementRect.bottom < visualRect.top
        ? visualRect.top - elementRect.bottom
        : elementRect.top > visualRect.bottom
          ? elementRect.top - visualRect.bottom
          : 0;
    return overlapsHorizontally && verticalGap <= maxDistance;
  }

  const progress = (title, detail, percent, log) => {
    const step =
      percent >= 70 ? "export" :
      percent >= 62 ? "wait" :
      percent >= 12 ? "filter" :
      "start";
    const payload = {
      type: "PBI_AUTOMATION_PROGRESS",
      step,
      title,
      detail,
      message: detail || title,
      progress: percent,
      log,
      at: new Date().toISOString(),
    };
    chrome.storage.local.set({ pbiLastRun: payload }).catch(() => {});
    chrome.runtime
      .sendMessage(payload)
      .catch(() => {});
  };

  async function waitFor(test, timeoutMs, errorMessage, intervalMs = FAST_POLL_MS) {
    const deadline = Date.now() + timeoutMs;
    let lastError;
    while (Date.now() < deadline) {
      try {
        const result = test();
        if (result) {
          return result;
        }
      } catch (error) {
        lastError = error;
      }
      await sleep(intervalMs);
    }
    throw new Error(lastError?.message || errorMessage);
  }

  function rectIsStable(first, second) {
    if (!first || !second) return false;
    return (
      Math.abs(first.left - second.left) < 0.75 &&
      Math.abs(first.top - second.top) < 0.75 &&
      Math.abs(first.width - second.width) < 0.75 &&
      Math.abs(first.height - second.height) < 0.75
    );
  }

  async function waitForStableGeometry(element, timeoutMs = 500) {
    const deadline = Date.now() + timeoutMs;
    let previous = null;
    let stableRounds = 0;
    while (Date.now() < deadline) {
      const current = element.getBoundingClientRect();
      if (current.width > 2 && current.height > 2) {
        stableRounds = rectIsStable(previous, current) ? stableRounds + 1 : 0;
        if (stableRounds >= 1) return current;
      } else {
        stableRounds = 0;
      }
      previous = current;
      await sleep(45);
    }
    return element.getBoundingClientRect();
  }

  function clickElement(element, { ctrlKey = false } = {}) {
    if (!element) {
      throw new Error("Không tìm thấy phần tử cần bấm.");
    }
    element.scrollIntoView({ block: "center", inline: "center" });
    const mouseOptions = {
      bubbles: true,
      cancelable: true,
      composed: true,
      view: window,
      button: 0,
      ctrlKey,
    };
    const keyboardTarget = element.ownerDocument || document;

    if (ctrlKey) {
      keyboardTarget.dispatchEvent(
        new KeyboardEvent("keydown", {
          key: "Control",
          code: "ControlLeft",
          keyCode: 17,
          which: 17,
          ctrlKey: true,
          bubbles: true,
        }),
      );
    }

    const pointerOptions = { ...mouseOptions, pointerId: 1, pointerType: "mouse", isPrimary: true };
    try {
      if (typeof PointerEvent === "function") {
        element.dispatchEvent(new PointerEvent("pointerover", pointerOptions));
        element.dispatchEvent(new PointerEvent("pointerenter", pointerOptions));
      }
      element.dispatchEvent(new MouseEvent("mouseover", mouseOptions));
      element.dispatchEvent(new MouseEvent("mouseenter", mouseOptions));
      if (typeof PointerEvent === "function") {
        element.dispatchEvent(new PointerEvent("pointerdown", { ...pointerOptions, buttons: 1 }));
      }
      element.dispatchEvent(
        new MouseEvent("mousedown", { ...mouseOptions, buttons: 1 }),
      );
      if (typeof PointerEvent === "function") {
        element.dispatchEvent(new PointerEvent("pointerup", { ...pointerOptions, buttons: 0 }));
      }
      element.dispatchEvent(new MouseEvent("mouseup", { ...mouseOptions, buttons: 0 }));
      if (ctrlKey) {
        element.dispatchEvent(new MouseEvent("click", { ...mouseOptions, buttons: 0 }));
      } else {
        element.click();
      }
    } finally {
      if (ctrlKey) {
        keyboardTarget.dispatchEvent(
          new KeyboardEvent("keyup", {
            key: "Control",
            code: "ControlLeft",
            keyCode: 17,
            which: 17,
            ctrlKey: false,
            bubbles: true,
          }),
        );
      }
    }
  }

  const FRAME_POINT_CHANNEL = "__ONPOINT_PBI_TOP_VIEWPORT_POINT_V1__";
  const framePointWaiters = new Map();

  function childFrameForWindow(childWindow) {
    for (const frame of document.querySelectorAll("iframe, frame")) {
      try {
        if (frame.contentWindow === childWindow) {
          return frame;
        }
      } catch (_) {
        // Cross-origin frame access can throw for unrelated embeds.
      }
    }
    return null;
  }

  async function topViewportPoint(clientX, clientY) {
    if (window === window.top) {
      return { x: clientX, y: clientY };
    }

    const requestId = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        framePointWaiters.delete(requestId);
        reject(new Error("Không quy đổi được tọa độ nút Power BI lên cửa sổ chính."));
      }, 2500);
      framePointWaiters.set(requestId, {
        resolve: (point) => {
          clearTimeout(timeout);
          resolve(point);
        },
      });
      window.parent.postMessage(
        {
          channel: FRAME_POINT_CHANNEL,
          kind: "request",
          requestId,
          x: clientX,
          y: clientY,
        },
        "*",
      );
    });
  }

  window.addEventListener("message", (event) => {
    const message = event.data;
    if (!message || message.channel !== FRAME_POINT_CHANNEL) {
      return;
    }

    if (message.kind === "response") {
      if (event.source !== window.parent) {
        return;
      }
      const waiter = framePointWaiters.get(message.requestId);
      if (!waiter) {
        return;
      }
      framePointWaiters.delete(message.requestId);
      waiter.resolve({ x: Number(message.x), y: Number(message.y) });
      return;
    }

    if (message.kind !== "request") {
      return;
    }
    const childFrame = childFrameForWindow(event.source);
    if (!childFrame) {
      return;
    }
    const rect = childFrame.getBoundingClientRect();
    const scaleX = rect.width / Math.max(1, childFrame.offsetWidth || rect.width);
    const scaleY = rect.height / Math.max(1, childFrame.offsetHeight || rect.height);
    const parentX =
      rect.left + Number(childFrame.clientLeft || 0) * scaleX + Number(message.x || 0) * scaleX;
    const parentY =
      rect.top + Number(childFrame.clientTop || 0) * scaleY + Number(message.y || 0) * scaleY;

    topViewportPoint(parentX, parentY)
      .then((point) => {
        event.source?.postMessage(
          {
            channel: FRAME_POINT_CHANNEL,
            kind: "response",
            requestId: message.requestId,
            x: point.x,
            y: point.y,
          },
          "*",
        );
      })
      .catch(() => {});
  });

  async function trustedBrowserClick(element, { ctrlKey = false } = {}) {
    if (!element) {
      throw new Error("Không tìm thấy phần tử Power BI cần bấm thật.");
    }
    element.scrollIntoView({ block: "center", inline: "center" });
    const rect = await waitForStableGeometry(element);
    if (rect.width <= 2 || rect.height <= 2) {
      throw new Error("Nút Power BI chưa hiển thị đủ để bấm.");
    }
    const localX = Math.max(2, Math.min(window.innerWidth - 2, rect.left + rect.width / 2));
    const localY = Math.max(2, Math.min(window.innerHeight - 2, rect.top + rect.height / 2));
    const point = await topViewportPoint(localX, localY);
    const response = await chrome.runtime.sendMessage({
      type: "PBI_TRUSTED_BROWSER_CLICK",
      x: point.x,
      y: point.y,
      ctrlKey,
    });
    if (!response?.ok || response.mode !== "chrome-debugger") {
      throw new Error(
        response?.error || "Chrome chưa thực hiện được thao tác chuột thật trên Power BI.",
      );
    }
    return response;
  }

  function exactTextElements(text, root = document) {
    const target = normalize(text);
    const candidates = root.querySelectorAll(
      "button, [role='button'], [role='option'], [role='menuitem'], label, span, p, div",
    );
    return [...candidates].filter((element) => {
      if (!isVisible(element)) {
        return false;
      }
      if (element.children.length > 7) {
        return false;
      }
      const aria = normalize(element.getAttribute("aria-label"));
      const title = normalize(element.getAttribute("title"));
      const ownText = normalize(element.textContent);
      return aria === target || title === target || ownText === target;
    });
  }

  function firstExactText(text, root = document) {
    return exactTextElements(text, root)[0] || null;
  }

  function readUpdatedAt() {
    const labels = ["Updated At", "Cập nhật", "Last refreshed", "Last refresh", "Updated"];
    const re = /(\d{4})[-/](\d{1,2})[-/](\d{1,2})[ T]+(\d{1,2}):(\d{2})(?::(\d{2}))?/;
    const pad = (v) => String(v).padStart(2, "0");
    const fmt = (m) =>
      `${m[1]}${pad(m[2])}${pad(m[3])}_${pad(m[4])}${pad(m[5])}${pad(m[6] || 0)}`;
    for (const label of labels) {
      const el = firstExactText(label);
      if (!el) continue;
      const scope = nearestVisual(el) || el.parentElement || el;
      const text = (scope.innerText || scope.textContent || "").trim();
      const m = text.match(re);
      if (m) return fmt(m);
    }
    return null;
  }

  function clickableAncestor(element, stopAt) {
    let current = element;
    while (current && current !== stopAt && current !== document.body) {
      const role = current.getAttribute?.("role");
      if (
        current.matches?.(
          "button, label, [role='button'], [role='option'], [role='menuitem'], [role='radio'], [role='checkbox'], .slicerItemContainer, [class*='slicerItem']",
        ) ||
        role === "listitem"
      ) {
        return current;
      }
      current = current.parentElement;
    }
    return element;
  }

  function nearestVisual(element) {
    const direct = element.closest(
      ".visual-container, .visualContainerHost, .visual, [class*='visual-container'], [class*='visualContainer']",
    );
    if (direct) {
      return direct;
    }

    let current = element.parentElement;
    let best = null;
    for (let depth = 0; current && depth < 10; depth += 1, current = current.parentElement) {
      const rect = current.getBoundingClientRect();
      if (rect.width >= 120 && rect.width <= 700 && rect.height >= 45 && rect.height <= 650) {
        best = current;
      }
    }
    return best || element.parentElement;
  }

  function findSlicer(label) {
    const labelElement =
      firstExactText(label) ||
      [...document.querySelectorAll("[aria-label], [title]")].find((element) => {
        const value = normalize(
          element.getAttribute("aria-label") || element.getAttribute("title"),
        );
        return isVisible(element) && value === normalize(label);
      });
    return labelElement ? nearestVisual(labelElement) : null;
  }

  function findButtonByNames(names, root = document) {
    const normalizedNames = names.map(normalize);
    const candidates = root.querySelectorAll("button, [role='button'], [role='menuitem']");
    return (
      [...candidates].find((element) => {
        if (!isVisible(element) || element.getAttribute("aria-disabled") === "true") {
          return false;
        }
        const values = [
          element.textContent,
          element.getAttribute("aria-label"),
          element.getAttribute("title"),
        ].map(normalize);
        return values.some((value) =>
          normalizedNames.some((name) => value === name || value.includes(name)),
        );
      }) || null
    );
  }

  function setNativeInputValue(input, value) {
    const descriptor = Object.getOwnPropertyDescriptor(
      HTMLInputElement.prototype,
      "value",
    );
    descriptor?.set?.call(input, value);
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
  }

  async function clearTopGlobalSearch() {
    const inputs = [...document.querySelectorAll(searchInputSelector)].filter(
      (input) => isVisible(input) && isTopGlobalSearch(input),
    );
    for (const input of inputs) {
      if (input.value) {
        input.focus();
        setNativeInputValue(input, "");
      }
      input.dispatchEvent(
        new KeyboardEvent("keydown", {
          key: "Escape",
          code: "Escape",
          keyCode: 27,
          bubbles: true,
        }),
      );
      input.blur();
    }
    if (inputs.length) {
      await sleep(250);
    }
  }

  function captureDateRanges() {
    const labels = ["Order date", "SLA Date"];
    return labels
      .map((label) => {
        const visual = findSlicer(label);
        if (!visual) {
          return null;
        }
        const inputs = [...visual.querySelectorAll("input")].filter(isVisible);
        return {
          label,
          values: inputs.map((input) => input.value),
        };
      })
      .filter((entry) => entry?.values?.length);
  }

  async function restoreDateRanges(savedRanges) {
    for (const saved of savedRanges) {
      const visual = findSlicer(saved.label);
      if (!visual) {
        continue;
      }
      const inputs = [...visual.querySelectorAll("input")].filter(isVisible);
      for (let index = 0; index < Math.min(inputs.length, saved.values.length); index += 1) {
        if (saved.values[index]) {
          inputs[index].focus();
          setNativeInputValue(inputs[index], saved.values[index]);
          inputs[index].dispatchEvent(
            new KeyboardEvent("keydown", { key: "Enter", code: "Enter", bubbles: true }),
          );
          inputs[index].blur();
          await sleep(450);
        }
      }
    }
  }

  function visibleDateInputs(visual) {
    if (!visual) {
      return [];
    }
    return [...visual.querySelectorAll("input")]
      .filter((input) => {
        if (!isVisible(input)) {
          return false;
        }
        const type = normalize(input.getAttribute("type") || "text");
        const hint = normalize(
          `${input.getAttribute("placeholder") || ""} ` +
            `${input.getAttribute("aria-label") || ""}`,
        );
        return (
          !["checkbox", "radio", "search", "button", "submit"].includes(type) &&
          !hint.includes("search") &&
          !hint.includes("tìm")
        );
      })
      .sort((first, second) => {
        const firstRect = first.getBoundingClientRect();
        const secondRect = second.getBoundingClientRect();
        return firstRect.left - secondRect.left || firstRect.top - secondRect.top;
      });
  }

  function findDateRangeSlicer(label) {
    const labelCandidates = [
      ...exactTextElements(label),
      ...[...document.querySelectorAll("[aria-label], [title]")].filter(
        (element) => {
          const value = normalize(
            element.getAttribute("aria-label") || element.getAttribute("title"),
          );
          return isVisible(element) && value === normalize(label);
        },
      ),
    ];
    const visuals = [
      ...new Set(labelCandidates.map(nearestVisual).filter(Boolean)),
    ];
    return (
      visuals.find((candidate) => visibleDateInputs(candidate).length >= 2) ||
      findSlicer(label)
    );
  }

  function inferDateOrder(inputs) {
    const hints = inputs
      .flatMap((input) => [
        input.getAttribute("placeholder"),
        input.getAttribute("aria-label"),
        input.value,
      ])
      .filter(Boolean)
      .map((value) => String(value).toLowerCase());

    for (const hint of hints) {
      if (/y{2,4}\W+m{1,4}\W+d{1,2}/i.test(hint)) return "ymd";
      if (/d{1,2}\W+m{1,4}\W+y{2,4}/i.test(hint)) return "dmy";
      if (/m{1,4}\W+d{1,2}\W+y{2,4}/i.test(hint)) return "mdy";
    }

    for (const input of inputs) {
      const match = String(input.value || "").match(
        /(\d{1,4})[./-](\d{1,2})[./-](\d{1,4})/,
      );
      if (!match) continue;
      if (match[1].length === 4) return "ymd";
      const first = Number(match[1]);
      const second = Number(match[2]);
      if (first > 12) return "dmy";
      if (second > 12) return "mdy";
    }

    // The report currently renders its date inputs as M/D/YYYY.
    return "mdy";
  }

  function parseDateInputValue(value, order) {
    const match = String(value || "").match(
      /(\d{1,4})[./-](\d{1,2})[./-](\d{1,4})/,
    );
    if (!match) {
      return null;
    }

    let year;
    let month;
    let day;
    if (order === "ymd" || match[1].length === 4) {
      year = Number(match[1]);
      month = Number(match[2]);
      day = Number(match[3]);
    } else {
      year = Number(match[3]);
      month = order === "dmy" ? Number(match[2]) : Number(match[1]);
      day = order === "dmy" ? Number(match[1]) : Number(match[2]);
    }
    if (year < 100) {
      year += 2000;
    }

    const parsed = new Date(year, month - 1, day);
    if (
      Number.isNaN(parsed.getTime()) ||
      parsed.getFullYear() !== year ||
      parsed.getMonth() !== month - 1 ||
      parsed.getDate() !== day
    ) {
      return null;
    }
    return parsed;
  }

  function sameLocalDate(first, second) {
    return (
      first instanceof Date &&
      second instanceof Date &&
      first.getFullYear() === second.getFullYear() &&
      first.getMonth() === second.getMonth() &&
      first.getDate() === second.getDate()
    );
  }

  function formatDateInputValue(date, order, inputs) {
    const sample = inputs
      .flatMap((input) => [
        input.value,
        input.getAttribute("placeholder"),
      ])
      .find((value) => /\d|[dmy]/i.test(String(value || ""))) || "";
    const separator = String(sample).match(/[./-]/)?.[0] || "/";
    const padded =
      order === "ymd" ||
      inputs.some((input) => normalize(input.getAttribute("type")) === "date") ||
      /\b(?:dd|mm)\b/i.test(String(sample)) ||
      /^\d{2}[./-]\d{2}[./-]/.test(String(sample));
    const part = (value) =>
      padded ? String(value).padStart(2, "0") : String(value);
    const year = String(date.getFullYear());
    const month = part(date.getMonth() + 1);
    const day = part(date.getDate());

    if (order === "ymd") return `${year}${separator}${month}${separator}${day}`;
    if (order === "dmy") return `${day}${separator}${month}${separator}${year}`;
    return `${month}${separator}${day}${separator}${year}`;
  }

  function formatDateForLog(date) {
    return (
      `${String(date.getDate()).padStart(2, "0")}/` +
      `${String(date.getMonth() + 1).padStart(2, "0")}/` +
      `${date.getFullYear()}`
    );
  }

  async function commitDateInput(label, index, targetDate, order, {
    allowMinimumClamp = false,
  } = {}) {
    let lastValue = "";
    const today = new Date();
    today.setHours(23, 59, 59, 999);
    const yearStart = new Date(today.getFullYear(), 0, 1);
    for (let attempt = 0; attempt < 3; attempt += 1) {
      const visual = await waitFor(
        () => findDateRangeSlicer(label),
        12000,
        `Không tìm thấy slicer "${label}".`,
      );
      const inputs = visibleDateInputs(visual);
      if (inputs.length < 2 || !inputs[index]) {
        throw new Error(
          `Slicer "${label}" không hiển thị đủ 2 ô ngày From/To.`,
        );
      }

      const input = inputs[index];
      const value = formatDateInputValue(targetDate, order, inputs);
      input.scrollIntoView({ block: "center", inline: "center" });
      input.focus();
      input.select?.();
      input.dispatchEvent(
        new KeyboardEvent("keydown", {
          key: "a",
          code: "KeyA",
          keyCode: 65,
          ctrlKey: true,
          bubbles: true,
        }),
      );
      markReportAction();
      setNativeInputValue(input, value);
      input.dispatchEvent(
        new KeyboardEvent("keyup", {
          key: "a",
          code: "KeyA",
          keyCode: 65,
          ctrlKey: false,
          bubbles: true,
        }),
      );
      input.dispatchEvent(
        new KeyboardEvent("keyup", {
          key: value.slice(-1),
          bubbles: true,
        }),
      );
      input.dispatchEvent(
        new KeyboardEvent("keydown", {
          key: "Enter",
          code: "Enter",
          keyCode: 13,
          bubbles: true,
        }),
      );
      input.dispatchEvent(
        new KeyboardEvent("keyup", {
          key: "Enter",
          code: "Enter",
          keyCode: 13,
          bubbles: true,
        }),
      );
      input.blur();

      let stableValue = "";
      let stableSince = 0;
      const committed = await waitFor(
        () => {
          const currentVisual = findDateRangeSlicer(label);
          const currentInputs = visibleDateInputs(currentVisual);
          const currentInput = currentInputs[index];
          lastValue = currentInput?.value || "";
          const actualDate = parseDateInputValue(lastValue, order);
          const exact = actualDate && sameLocalDate(actualDate, targetDate);
          const acceptedClamp = Boolean(
            allowMinimumClamp &&
            actualDate &&
            actualDate >= yearStart &&
            actualDate <= today,
          );
          if (!exact && !acceptedClamp) {
            stableValue = "";
            stableSince = 0;
            return null;
          }
          if (lastValue !== stableValue) {
            stableValue = lastValue;
            stableSince = Date.now();
            return null;
          }
          if (Date.now() - stableSince < 180) return null;
          return { date: actualDate, clamped: !exact };
        },
        2200,
        "",
        70,
      ).catch(() => null);
      if (committed) return committed;

      if (attempt < 2) {
        await waitForReportToSettle({ reactionGraceMs: 700, quietMs: 280 });
      }
    }

    const actualDate = parseDateInputValue(lastValue, order);
    if (
      allowMinimumClamp &&
      actualDate &&
      actualDate >= yearStart &&
      actualDate <= today
    ) {
      return { date: actualDate, clamped: true };
    }

    throw new Error(
      `Đã nhập ${formatDateForLog(targetDate)} nhưng ô ${
        index === 0 ? "From" : "To"
      } của "${label}" chưa nhận giá trị.`,
    );
  }

  async function applySlaYearToDate(label = "SLA Date") {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const yearStart = new Date(today.getFullYear(), 0, 1);
    const visual = await waitFor(
      () => findDateRangeSlicer(label),
      12000,
      `Không tìm thấy slicer "${label}".`,
    );
    const initialInputs = visibleDateInputs(visual);
    if (initialInputs.length < 2) {
      throw new Error(
        `Slicer "${label}" không phải dạng khoảng ngày From/To.`,
      );
    }
    const order = inferDateOrder(initialInputs);

    const fromResult = await commitDateInput(
      label,
      0,
      yearStart,
      order,
      { allowMinimumClamp: true },
    );
    await waitForReportToSettle();
    const toResult = await commitDateInput(label, 1, today, order);
    await waitForReportToSettle();

    const finalVisual = findDateRangeSlicer(label);
    const finalInputs = visibleDateInputs(finalVisual);
    const finalFrom = parseDateInputValue(finalInputs[0]?.value, order);
    const finalTo = parseDateInputValue(finalInputs[1]?.value, order);
    if (
      !finalFrom ||
      !finalTo ||
      finalFrom.getFullYear() !== today.getFullYear() ||
      finalFrom < yearStart ||
      finalFrom > finalTo ||
      !sameLocalDate(finalTo, today)
    ) {
      throw new Error(
        `Slicer "${label}" chưa áp dụng đúng Year to date.`,
      );
    }

    return {
      from: finalFrom || fromResult.date,
      to: finalTo || toResult.date,
      fromWasClamped: fromResult.clamped,
    };
  }

  async function clearAllSlicers() {
    const findClearButton = () => {
      const seeds = new Set([
        ...document.querySelectorAll("button, [role='button'], [aria-label], [title]"),
        ...exactTextElements("Clear all slicers"),
        ...exactTextElements("Clear all filters"),
      ]);
      const candidates = [];
      for (const seed of seeds) {
        if (!isVisible(seed)) continue;
        const descriptor = normalize(
          [
            seed.textContent,
            seed.getAttribute?.("aria-label"),
            seed.getAttribute?.("title"),
          ].join(" "),
        );
        if (
          !descriptor.includes("clear all slicers") &&
          !descriptor.includes("clear all filters")
        ) {
          continue;
        }
        if (descriptor.includes("reset")) continue;
        const target = clickableAncestor(seed);
        const rect = target.getBoundingClientRect();
        if (rect.width <= 4 || rect.height <= 4) continue;
        let score = 0;
        if (target.matches?.("button, [role='button']")) score += 100;
        if (normalize(target.getAttribute?.("aria-label")) === "clear all slicers") score += 60;
        if (normalize(target.textContent) === "clear all slicers") score += 40;
        if (rect.width <= 320 && rect.height <= 120) score += 20;
        candidates.push({ target, score, area: rect.width * rect.height });
      }
      candidates.sort((first, second) =>
        second.score - first.score || first.area - second.area,
      );
      return candidates[0]?.target || null;
    };

    const target = await waitFor(
      findClearButton,
      10000,
      'Không tìm thấy đúng nút "Clear all slicers" trên report.',
      250,
    );
    // A JavaScript-dispatched MouseEvent always has isTrusted=false and is
    // ignored by Power BI report buttons that require Ctrl + click. Ask the
    // extension service worker to dispatch real browser input instead.
    markReportAction();
    await trustedBrowserClick(target, { ctrlKey: true });
  }

  function findDropdownTrigger(visual) {
    const semantic = [
      ...visual.querySelectorAll(
        "[role='combobox'], button[aria-haspopup], [role='button'][aria-haspopup], input[aria-haspopup]",
      ),
    ].find(isVisible);
    if (semantic) {
      return semantic;
    }

    const values = ["All", "Multiple selections", "Tất cả", "Nhiều lựa chọn"];
    for (const value of values) {
      const textElement = firstExactText(value, visual);
      if (textElement) {
        return clickableAncestor(textElement, visual.parentElement);
      }
    }

    const candidates = [...visual.querySelectorAll("div, span")].filter((element) => {
      if (!isVisible(element)) {
        return false;
      }
      const rect = element.getBoundingClientRect();
      return rect.height >= 20 && rect.height <= 55 && rect.width >= 70;
    });
    return candidates[candidates.length - 1] || null;
  }

  const searchInputSelector =
    "input[placeholder*='Search' i], input[aria-label*='Search' i], input[placeholder*='Tìm' i], input[aria-label*='Tìm' i]";
  const optionSelector =
    "[role='option'], [role='checkbox'], [role='menuitemcheckbox'], .slicerItemContainer, [class*='slicerItem']";
  const valueCandidateSelector = `${optionSelector}, li, label, span, p, div`;
  const safePrefixSlicerValues = new Set(["tnsl", "toll", "mcl", "tiktok", "shopee"]);
  const slicerPanelSelector = [
    "[role='listbox']",
    "[role='menu']",
    "[role='presentation']",
    "[role='dialog']",
    ".slicer-dropdown-menu",
    "[class*='slicer'][class*='dropdown']",
    "[class*='slicer'][class*='popup']",
    "[class*='dropdown'][class*='menu']",
    "[class*='dropdown'][class*='overlay']",
    "[class*='popup']",
    "[class*='popover']",
    "[class*='flyout']",
  ].join(", ");
  let activeSlicerDropdown = null;

  function triggerPanelIds(trigger) {
    return [trigger?.getAttribute?.("aria-controls"), trigger?.getAttribute?.("aria-owns")]
      .filter(Boolean)
      .flatMap((value) => String(value).split(/\s+/))
      .filter(Boolean);
  }

  function relatedPanelsForTrigger(trigger) {
    return triggerPanelIds(trigger)
      .map((id) => document.getElementById(id))
      .filter(Boolean);
  }

  function isTopGlobalSearch(input, visual = null) {
    if (!isVisible(input)) {
      return false;
    }
    if (visual?.contains(input)) {
      return false;
    }
    const rect = input.getBoundingClientRect();
    const visualRect = visual?.getBoundingClientRect();
    return (
      rect.top < 115 &&
      rect.width > 180 &&
      (!visualRect || rect.bottom < visualRect.top - 20)
    );
  }

  function findSearchInputForSlicer(visual, panel = null) {
    const candidates = new Set();
    for (const root of [panel, visual]) {
      if (root?.querySelectorAll) {
        for (const input of root.querySelectorAll(searchInputSelector)) {
          candidates.add(input);
        }
      }
    }
    for (const input of document.querySelectorAll(searchInputSelector)) {
      candidates.add(input);
    }

    return (
      [...candidates]
        .filter(
          (input) =>
            isVisible(input) &&
            !isTopGlobalSearch(input, visual) &&
            isNearSlicer(input, visual, 500),
        )
        .sort((first, second) => {
          const visualRect = visual.getBoundingClientRect();
          const firstRect = first.getBoundingClientRect();
          const secondRect = second.getBoundingClientRect();
          const firstDistance = Math.abs(firstRect.top - visualRect.bottom);
          const secondDistance = Math.abs(secondRect.top - visualRect.bottom);
          return firstDistance - secondDistance;
        })[0] || null
    );
  }

  function findSlicerPanel(visual) {
    if (!visual) {
      return null;
    }
    if (
      activeSlicerDropdown?.visual === visual &&
      activeSlicerDropdown.panel &&
      isVisible(activeSlicerDropdown.panel)
    ) {
      return activeSlicerDropdown.panel;
    }

    const trigger = findDropdownTrigger(visual);
    const relatedPanels = relatedPanelsForTrigger(trigger);
    const candidates = new Set([visual]);
    for (const candidate of relatedPanels) {
      candidates.add(candidate);
    }
    for (const candidate of document.querySelectorAll(slicerPanelSelector)) {
      candidates.add(candidate);
    }

    const scored = [...candidates]
      .filter((candidate) => {
        if (!isVisible(candidate) || !isNearSlicer(candidate, visual)) {
          return false;
        }
        const localSearch = [...candidate.querySelectorAll(searchInputSelector)].some(
          (input) => isVisible(input) && !isTopGlobalSearch(input, visual),
        );
        const localOptions = [...candidate.querySelectorAll(optionSelector)].some(
          isVisible,
        );
        return localSearch || localOptions;
      })
      .map((candidate) => {
        const className = normalize(candidate.className);
        const role = normalize(candidate.getAttribute("role"));
        const hasSearch = [...candidate.querySelectorAll(searchInputSelector)].some(
          (input) => isVisible(input) && !isTopGlobalSearch(input, visual),
        );
        const hasOptions = [...candidate.querySelectorAll(optionSelector)].some(
          isVisible,
        );
        const score =
          (relatedPanels.includes(candidate) ? 80 : 0) +
          (candidate.contains(document.activeElement) ? 20 : 0) +
          (candidate === visual ? 2 : 0) +
          (className.includes("slicer") ? 4 : 0) +
          (role === "listbox" ? 4 : 0) +
          (hasSearch ? 3 : 0) +
          (hasOptions ? 3 : 0) +
          (Number(getComputedStyle(candidate).zIndex) || 0) / 10000;
        return { candidate, score };
      })
      .sort((first, second) => second.score - first.score);

    return scored[0]?.candidate || null;
  }

  function slicerIsOpen(visual) {
    const trigger = findDropdownTrigger(visual);
    const expanded = trigger?.getAttribute("aria-expanded");
    if (expanded === "true") {
      return true;
    }
    if (expanded === "false") {
      return false;
    }
    if (findSearchInputForSlicer(visual, findSlicerPanel(visual))) {
      return true;
    }

    const panel = findSlicerPanel(visual);
    if (panel && panel !== visual) {
      return true;
    }

    const localOptions = [...visual.querySelectorAll(optionSelector)].filter(isVisible);
    if (localOptions.length > 1) {
      return true;
    }

    return [...document.querySelectorAll(optionSelector)].some(
      (option) =>
        isVisible(option) &&
        !visual.contains(option) &&
        isNearSlicer(option, visual, 650),
    );
  }

  async function closeActiveDropdown(visual = null) {
    const targetVisual = visual || activeSlicerDropdown?.visual || null;
    const knownPanel =
      (activeSlicerDropdown?.visual === targetVisual && activeSlicerDropdown.panel) ||
      (targetVisual ? findSlicerPanel(targetVisual) : null);
    const knownTrigger =
      (activeSlicerDropdown?.visual === targetVisual && activeSlicerDropdown.trigger) ||
      (targetVisual ? findDropdownTrigger(targetVisual) : null);

    const searchRoots = [knownPanel, targetVisual].filter(Boolean);
    for (const root of searchRoots) {
      for (const input of root.querySelectorAll?.(searchInputSelector) || []) {
        if (!isVisible(input) || !input.value) continue;
        input.focus();
        setNativeInputValue(input, "");
      }
    }

    const keyboardTarget =
      document.activeElement instanceof Element ? document.activeElement : document.body;
    keyboardTarget.dispatchEvent(
      new KeyboardEvent("keydown", {
        key: "Escape",
        code: "Escape",
        keyCode: 27,
        bubbles: true,
      }),
    );
    document.dispatchEvent(
      new KeyboardEvent("keydown", {
        key: "Escape",
        code: "Escape",
        keyCode: 27,
        bubbles: true,
      }),
    );

    const dropdownLooksClosed = () => {
      if (knownTrigger?.getAttribute?.("aria-expanded") === "true") return false;
      if (knownPanel && knownPanel !== targetVisual && isVisible(knownPanel)) return false;
      if (
        targetVisual &&
        findSearchInputForSlicer(targetVisual, knownPanel) &&
        slicerIsOpen(targetVisual)
      ) {
        return false;
      }
      return true;
    };
    const waitUntilClosed = (timeoutMs) =>
      waitFor(dropdownLooksClosed, timeoutMs, "", 60).catch(() => null);

    if (await waitUntilClosed(420)) {
      activeSlicerDropdown = null;
      return;
    }

    const expandedTriggers = new Set(
      [
        knownTrigger,
        ...document.querySelectorAll(
          "[aria-expanded='true'][aria-haspopup], [role='combobox'][aria-expanded='true']",
        ),
      ].filter(Boolean),
    );
    for (const trigger of expandedTriggers) {
      if (trigger.getAttribute?.("aria-expanded") === "true" && isVisible(trigger)) {
        clickElement(trigger);
      }
    }

    if (await waitUntilClosed(520)) {
      activeSlicerDropdown = null;
      return;
    }

    const panelStillVisible =
      knownPanel && knownPanel !== targetVisual && isVisible(knownPanel);
    if (panelStillVisible) {
      document.body.dispatchEvent(new MouseEvent("mousedown", { bubbles: true }));
      document.body.dispatchEvent(new MouseEvent("mouseup", { bubbles: true }));
      document.body.click();
      await waitUntilClosed(520);
    }

    activeSlicerDropdown = null;
  }

  async function openSlicer(label) {
    await closeActiveDropdown();
    const visual = await waitFor(
      () => findSlicer(label),
      12000,
      `Không tìm thấy slicer "${label}".`,
    );
    const trigger = findDropdownTrigger(visual);
    if (!trigger) {
      throw new Error(`Không tìm thấy ô dropdown của slicer "${label}".`);
    }
    const panelsBeforeClick = new Set(
      [...document.querySelectorAll(slicerPanelSelector)].filter(isVisible),
    );
    clickElement(trigger);
    await waitFor(
      () => slicerIsOpen(visual),
      5000,
      `Dropdown của slicer "${label}" không mở.`,
      80,
    );
    const readyPanel = await waitFor(
      () => {
        const related = relatedPanelsForTrigger(trigger).find(isVisible) || null;
        const panel = related || findSlicerPanel(visual);
        if (!panel) return null;
        const hasSearch = [...panel.querySelectorAll(searchInputSelector)].some(isVisible);
        const hasOption = [...panel.querySelectorAll(optionSelector)].some(isVisible);
        return hasSearch || hasOption ? panel : null;
      },
      1400,
      "",
      70,
    ).catch(() => null);
    const relatedPanel = relatedPanelsForTrigger(trigger).find(isVisible) || null;
    const newlyVisiblePanel = [...document.querySelectorAll(slicerPanelSelector)]
      .filter(
        (candidate) =>
          isVisible(candidate) &&
          !panelsBeforeClick.has(candidate) &&
          isNearSlicer(candidate, visual) &&
          ([...candidate.querySelectorAll(searchInputSelector)].some(isVisible) ||
            [...candidate.querySelectorAll(optionSelector)].some(isVisible)),
      )
      .sort((first, second) => {
        const firstRect = first.getBoundingClientRect();
        const secondRect = second.getBoundingClientRect();
        const visualRect = visual.getBoundingClientRect();
        const firstGap = Math.min(
          Math.abs(firstRect.top - visualRect.bottom),
          Math.abs(visualRect.top - firstRect.bottom),
        );
        const secondGap = Math.min(
          Math.abs(secondRect.top - visualRect.bottom),
          Math.abs(visualRect.top - secondRect.bottom),
        );
        return firstGap - secondGap;
      })[0] || null;
    activeSlicerDropdown = {
      label,
      visual,
      trigger,
      panel: readyPanel || relatedPanel || newlyVisiblePanel || findSlicerPanel(visual),
    };
    return visual;
  }

  function candidateValueTexts(element) {
    return [
      element?.textContent,
      element?.getAttribute?.("aria-label"),
      element?.getAttribute?.("title"),
    ]
      .map(normalize)
      .filter(Boolean);
  }

  function slicerValueMatchScore(candidate, target) {
    if (!candidate || !target) {
      return 0;
    }
    if (candidate === target) {
      return 100;
    }
    const suffix = candidate.slice(target.length).trim();
    if (
      candidate.startsWith(target) &&
      /^[,;:]?\s*(?:not\s+selected|selected|unchecked|checked|not\s+checked|checkbox(?:\s+(?:checked|unchecked))?|đã\s+chọn|chưa\s+chọn)$/i.test(suffix)
    ) {
      return 90;
    }
    if (!safePrefixSlicerValues.has(target)) {
      return 0;
    }
    const escaped = target.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    if (new RegExp(`^${escaped}(?:\\s*[-–—/:|>]\\s*|\\s+|\\s*\\()`, "i").test(candidate)) {
      return 70;
    }
    if (new RegExp(`(?:^|\\s)${escaped}(?:$|\\s|[-–—/:|>,(])`, "i").test(candidate)) {
      return 40;
    }
    return 0;
  }

  function bestSlicerValueScore(element, target) {
    return Math.max(0, ...candidateValueTexts(element).map((value) =>
      slicerValueMatchScore(value, target),
    ));
  }

  function optionForValue(value, root = document, requireOptionSemantics = false) {
    const target = normalize(value);
    const candidates = root.querySelectorAll(valueCandidateSelector);
    const matches = [...candidates]
      .filter((element) => isVisible(element) && element.children.length <= 8)
      .map((element) => ({
        element,
        score: bestSlicerValueScore(element, target),
      }))
      .filter((entry) => entry.score > 0)
      .sort((first, second) => {
        const firstClickable = clickableAncestor(first.element, root.parentElement);
        const secondClickable = clickableAncestor(second.element, root.parentElement);
        return (
          second.score - first.score ||
          Number(secondClickable.matches?.(optionSelector)) -
            Number(firstClickable.matches?.(optionSelector)) ||
          normalize(first.element.textContent).length -
            normalize(second.element.textContent).length
        );
      });
    if (!matches.length) {
      return null;
    }
    const preferred = matches
      .map(({ element }) => clickableAncestor(element, root.parentElement))
      .find((element) => element.matches?.(optionSelector));
    if (preferred) {
      return preferred;
    }
    return requireOptionSemantics
      ? null
      : clickableAncestor(matches[0].element, root.parentElement);
  }

  function optionForSlicer(value, visual, panel = null) {
    const roots = [...new Set([panel, visual].filter(Boolean))];
    for (const root of roots) {
      const option = optionForValue(value, root, root === visual && !panel);
      if (option && isNearSlicer(option, visual)) {
        return option;
      }
    }

    const target = normalize(value);
    const nearMatches = [...document.querySelectorAll(valueCandidateSelector)]
      .filter(
        (element) =>
          isVisible(element) &&
          element.children.length <= 8 &&
          isNearSlicer(element, visual) &&
          bestSlicerValueScore(element, target) > 0,
      )
      .map((element) => {
        const clickable = clickableAncestor(element);
        const rect = clickable.getBoundingClientRect();
        const visualRect = visual.getBoundingClientRect();
        const score =
          bestSlicerValueScore(element, target) * 2 +
          (clickable.matches?.(optionSelector) ? 80 : 0) +
          (panel?.contains(clickable) ? 40 : 0) +
          (!visual.contains(clickable) ? 25 : 0) +
          (rect.top >= visualRect.top - 10 ? 10 : 0) -
          Math.abs(rect.left - visualRect.left) / 100;
        return { clickable, score };
      })
      .sort((first, second) => second.score - first.score);
    return nearMatches[0]?.clickable || null;
  }

  function optionIsSelected(option) {
    const selectedNodes = [
      option,
      ...option.querySelectorAll(
        "[aria-selected], [aria-checked], input[type='checkbox'], [class*='selected'], [class*='checked']",
      ),
    ];
    return selectedNodes.some((node) => {
      const className = normalize(node.className);
      const hasSelectedClass =
        /(^|[\s_-])(selected|checked)([\s_-]|$)/.test(className) &&
        !/(^|[\s_-])(unselected|unchecked)([\s_-]|$)/.test(className);
      return (
        node.getAttribute?.("aria-selected") === "true" ||
        node.getAttribute?.("aria-checked") === "true" ||
        node.checked === true ||
        hasSelectedClass
      );
    });
  }

  function optionHasExplicitSelectedEvidence(option) {
    if (!option) {
      return false;
    }
    if (optionIsSelected(option)) {
      return true;
    }

    const stateNodes = [
      option,
      ...option.querySelectorAll(
        "[aria-selected], [aria-checked], [data-state], [data-checked], input[type='checkbox']",
      ),
    ];
    return stateNodes.some((node) => {
      const ariaSelected = normalize(node.getAttribute?.("aria-selected"));
      const ariaChecked = normalize(node.getAttribute?.("aria-checked"));
      const dataState = normalize(node.getAttribute?.("data-state"));
      const dataChecked = normalize(node.getAttribute?.("data-checked"));
      if (
        ariaSelected === "true" ||
        ariaChecked === "true" ||
        dataChecked === "true" ||
        ["checked", "selected", "on"].includes(dataState) ||
        node.checked === true
      ) {
        return true;
      }

      const accessibleState = normalize(
        `${node.getAttribute?.("aria-label") || ""} ${node.getAttribute?.("title") || ""}`,
      );
      if (
        !accessibleState ||
        /(?:not\s+selected|not\s+checked|unchecked|unselected|chưa\s+chọn|bỏ\s+chọn)/i.test(
          accessibleState,
        )
      ) {
        return false;
      }
      return /(?:^|[\s,;:])(?:selected|checked|đã\s+chọn)(?:$|[\s,;:])/i.test(
        accessibleState,
      );
    });
  }

  function optionHasExplicitUnselectedEvidence(option) {
    if (!option || optionHasExplicitSelectedEvidence(option)) {
      return false;
    }
    const stateNodes = [
      option,
      ...option.querySelectorAll(
        "[aria-selected], [aria-checked], [data-state], [data-checked], input[type='checkbox']",
      ),
    ];
    return stateNodes.some((node) => {
      const accessibleState = normalize(
        `${node.getAttribute?.("aria-label") || ""} ${node.getAttribute?.("title") || ""}`,
      );
      return (
        normalize(node.getAttribute?.("aria-selected")) === "false" ||
        normalize(node.getAttribute?.("aria-checked")) === "false" ||
        normalize(node.getAttribute?.("data-checked")) === "false" ||
        ["unchecked", "unselected", "off"].includes(
          normalize(node.getAttribute?.("data-state")),
        ) ||
        node.checked === false ||
        /(?:not\s+selected|not\s+checked|unchecked|unselected|chưa\s+chọn|bỏ\s+chọn)/i.test(
          accessibleState,
        )
      );
    });
  }

  function slicerShowsValue(visual, value) {
    const target = normalize(value);
    const trigger = findDropdownTrigger(visual);
    const values = [
      trigger?.textContent,
      trigger?.getAttribute?.("aria-label"),
      trigger?.getAttribute?.("title"),
    ].map(normalize);
    if (values.some((entry) => entry === target || entry.includes(target))) {
      return true;
    }
    return exactTextElements(value, visual).length > 0;
  }

  function selectedSlicerValueEvidence(label, value, previousOption = null) {
    const currentVisual = findSlicer(label);
    if (!currentVisual) {
      return null;
    }
    if (slicerShowsValue(currentVisual, value)) {
      return { source: "slicer", visual: currentVisual };
    }

    if (
      previousOption?.isConnected &&
      optionHasExplicitSelectedEvidence(previousOption)
    ) {
      return { source: "clicked-option", visual: currentVisual, option: previousOption };
    }

    const currentPanel = findSlicerPanel(currentVisual);
    const currentOption = optionForSlicer(value, currentVisual, currentPanel);
    if (currentOption && optionHasExplicitSelectedEvidence(currentOption)) {
      return { source: "selected-option", visual: currentVisual, option: currentOption };
    }
    return null;
  }

  async function confirmTikTokWarehouseSelection(
    label,
    value,
    slicerVisual,
    clickedOption,
    { ctrlKey = false } = {},
  ) {
    const waitForEvidence = (timeoutMs) =>
      waitFor(
        () => selectedSlicerValueEvidence(label, value, clickedOption),
        timeoutMs,
        "",
        90,
      ).catch(() => null);

    let evidence = await waitForEvidence(700);
    if (evidence) {
      return evidence;
    }

    const explicitlyUnselected = optionHasExplicitUnselectedEvidence(clickedOption);

    // Power BI sometimes keeps the trigger text at "All" until the popup closes.
    // Close once and re-check. A no-state canvas/SVG option is accepted after
    // the report settles; reopening every time was the largest normal-path delay.
    await closeActiveDropdown(slicerVisual);
    evidence = selectedSlicerValueEvidence(label, value, clickedOption);
    if (evidence) {
      return evidence;
    }

    let reopenedVisual = null;
    let reopenedOption = null;
    if (explicitlyUnselected) {
      reopenedVisual = await openSlicer(label);
      let panel = findSlicerPanel(reopenedVisual);
      reopenedOption = await waitFor(
        () => {
          panel = findSlicerPanel(reopenedVisual);
          return optionForSlicer(value, reopenedVisual, panel);
        },
        2200,
        "",
        80,
      ).catch(() => null);

      if (reopenedOption && optionHasExplicitSelectedEvidence(reopenedOption)) {
        return { source: "reopened-option", visual: reopenedVisual, option: reopenedOption };
      }

      // Retry exactly once only when Power BI explicitly reports unchecked.
      if (reopenedOption && optionHasExplicitUnselectedEvidence(reopenedOption)) {
        markReportAction();
        clickElement(reopenedOption, { ctrlKey });
        await sleep(SLICER_CLICK_CADENCE_MS);
        clickedOption = reopenedOption;
        evidence = await waitForEvidence(900);
        if (evidence) {
          return evidence;
        }
      }
    }

    // Some live Power BI slicers intentionally keep their checkbox state in a
    // canvas/SVG layer and expose neither aria-selected nor aria-checked. In
    // that layout the click has already been delivered, but a hard DOM-state
    // requirement creates a false failure and stops the TikTok export. Only
    // retry when Power BI explicitly says "unchecked"; after that, accept the
    // completed click and let report settling/data refresh be the final gate.
    await closeActiveDropdown(reopenedVisual || slicerVisual);
    await waitForReportToSettle({ reactionGraceMs: 700, quietMs: 280 });
    return {
      source: reopenedOption && optionHasExplicitUnselectedEvidence(reopenedOption)
        ? "click-retried-state-stale"
        : "click-completed-no-dom-state",
      visual: findSlicer(label) || reopenedVisual,
      option: reopenedOption || clickedOption,
      domStateUnavailable: true,
    };
  }

  function findSlicerScrollContainers(visual, panel = null) {
    const candidates = new Set();
    for (const root of [panel, visual].filter(Boolean)) {
      candidates.add(root);
      for (const element of root.querySelectorAll("div, ul, [role='listbox']")) {
        candidates.add(element);
      }
    }
    return [...candidates]
      .filter(
        (element) =>
          isVisible(element) &&
          isNearSlicer(element, visual, 650) &&
          element.scrollHeight > element.clientHeight + 8 &&
          element.clientHeight >= 40,
      )
      .sort(
        (first, second) =>
          second.scrollHeight - second.clientHeight -
          (first.scrollHeight - first.clientHeight),
      );
  }

  async function optionForSlicerWithScroll(value, visual, panel = null) {
    let option = optionForSlicer(value, visual, panel);
    if (option) {
      return option;
    }

    const containers = findSlicerScrollContainers(visual, panel);
    for (const container of containers.slice(0, 3)) {
      const originalTop = container.scrollTop;
      const step = Math.max(120, Math.floor(container.clientHeight * 0.8));
      for (let top = 0, round = 0; round < 12; top += step, round += 1) {
        container.scrollTop = Math.min(top, container.scrollHeight);
        container.dispatchEvent(new Event("scroll", { bubbles: true }));
        await sleep(110);
        panel = findSlicerPanel(visual) || panel;
        option = optionForSlicer(value, visual, panel);
        if (option) {
          return option;
        }
        if (container.scrollTop + container.clientHeight >= container.scrollHeight - 2) {
          break;
        }
      }
      container.scrollTop = originalTop;
      container.dispatchEvent(new Event("scroll", { bubbles: true }));
    }
    return null;
  }

  async function selectSlicerValue(
    label,
    value,
    {
      keepOpen = false,
      ctrlKey = false,
      forceOpen = false,
      forceClick = false,
      verifyTikTokWarehouse = false,
    } = {},
  ) {
    let slicerVisual = await waitFor(
      () => findSlicer(label),
      12000,
      `Không tìm thấy slicer "${label}".`,
    );
    if (!forceOpen && !ctrlKey && slicerShowsValue(slicerVisual, value)) {
      return;
    }

    if (forceOpen) {
      slicerVisual = await openSlicer(label);
    } else if (!slicerIsOpen(slicerVisual)) {
      slicerVisual = await openSlicer(label);
    }

    let panel = null;
    let localSearch = null;
    let option = null;
    for (let attempt = 0; attempt < 2 && !option; attempt += 1) {
      panel = findSlicerPanel(slicerVisual);
      option = optionForSlicer(value, slicerVisual, panel);

      if (!option) {
        localSearch = findSearchInputForSlicer(slicerVisual, panel);
        if (localSearch) {
          localSearch.focus();
          localSearch.select?.();
          setNativeInputValue(localSearch, "");
          setNativeInputValue(localSearch, value);
          localSearch.dispatchEvent(
            new KeyboardEvent("keyup", {
              key: value.slice(-1),
              bubbles: true,
            }),
          );
          option = await waitFor(
            () => {
              panel = findSlicerPanel(slicerVisual);
              return optionForSlicer(value, slicerVisual, panel);
            },
            3500,
            "",
            90,
          ).catch(() => null);
        }
      }

      if (!option) {
        panel = findSlicerPanel(slicerVisual);
        option = await optionForSlicerWithScroll(value, slicerVisual, panel);
      }

      if (!option && attempt === 0) {
        await closeActiveDropdown(slicerVisual);
        slicerVisual = await openSlicer(label);
      }
    }

    if (!option) {
      const visibleValues = [...document.querySelectorAll(optionSelector)]
        .filter((element) => isVisible(element) && isNearSlicer(element, slicerVisual))
        .map((element) => normalize(element.textContent))
        .filter(Boolean)
        .filter((entry, index, all) => all.indexOf(entry) === index)
        .slice(0, 8);
      const diagnostic = visibleValues.length
        ? ` Giá trị đang thấy: ${visibleValues.join(", ")}.`
        : " Dropdown không render option hợp lệ.";
      throw new Error(
        `Không thấy giá trị "${value}" trong slicer "${label}" sau 2 lần mở lại.${diagnostic}`,
      );
    }

    if (forceClick || !optionIsSelected(option)) {
      markReportAction();
      clickElement(option, { ctrlKey });
      await sleep(SLICER_CLICK_CADENCE_MS);
    }

    if (!keepOpen) {
      await closeActiveDropdown(slicerVisual);
    }

    if (verifyTikTokWarehouse) {
      await confirmTikTokWarehouseSelection(label, value, slicerVisual, option, {
        ctrlKey,
      });
    } else if (!ctrlKey) {
      await waitFor(
        () => {
          const currentVisual = findSlicer(label);
          return currentVisual && slicerShowsValue(currentVisual, value);
        },
        5000,
        `Đã bấm "${value}" nhưng slicer "${label}" chưa nhận lựa chọn.`,
        90,
      );
    }
  }

  async function applyStatusSelection(statuses) {
    if (!statuses.length) {
      return;
    }

    try {
      await selectSlicerValue("Order Status", statuses[0], {
        keepOpen: true,
        forceOpen: true,
        forceClick: true,
      });
    } catch (firstError) {
      // Report co the con dang settle sau Clear all slicers -> cho them roi thu lai 1 lan.
      await sleep(2000);
      await selectSlicerValue("Order Status", statuses[0], {
        keepOpen: true,
        forceOpen: true,
        forceClick: true,
      });
    }
    for (let index = 1; index < statuses.length; index += 1) {
      await selectSlicerValue("Order Status", statuses[index], {
        keepOpen: true,
        ctrlKey: true,
      });
    }

    await closeActiveDropdown(findSlicer("Order Status"));
  }

  async function applyBranchSelection(
    label,
    branches,
    { verifyTikTokWarehouse = false } = {},
  ) {
    if (!branches || !branches.length) {
      return;
    }
    await selectSlicerValue(label, branches[0], {
      keepOpen: true,
      forceOpen: true,
      forceClick: true,
      verifyTikTokWarehouse,
    });
    for (let index = 1; index < branches.length; index += 1) {
      await selectSlicerValue(label, branches[index], {
        keepOpen: true,
        ctrlKey: true,
        verifyTikTokWarehouse,
      });
    }
    await closeActiveDropdown(findSlicer(label));
  }

  function reportIsBusy() {
    return [...document.querySelectorAll("[aria-busy='true'], [aria-label]")].some(
      (element) => {
        if (!isVisible(element)) return false;
        const label = normalize(element.getAttribute("aria-label"));
        return (
          element.getAttribute("aria-busy") === "true" ||
          label.includes("loading") ||
          label.includes("đang tải")
        );
      },
    );
  }

  async function waitForReportToSettle({
    timeoutMs = 60000,
    reactionGraceMs = REPORT_REACTION_GRACE_MS,
    quietMs = REPORT_QUIET_MS,
  } = {}) {
    const targetSequence = reportActionSequence;
    if (
      targetSequence === lastSettledReportActionSequence &&
      !reportIsBusy()
    ) {
      return { reused: true };
    }

    const startedAt = Date.now();
    const actionAt = lastReportActionAt || startedAt;
    const deadline = startedAt + timeoutMs;
    let sawBusy = false;
    let lastBusyAt = 0;
    while (Date.now() < deadline) {
      const now = Date.now();
      const busy = reportIsBusy();
      if (busy) {
        sawBusy = true;
        lastBusyAt = now;
      } else {
        // If Power BI exposes a busy state, continue as soon as it clears and
        // the DOM becomes quiet. If it does not expose busy, keep a short
        // reaction window so a late visual refresh cannot be skipped.
        const reacted = sawBusy || now - startedAt >= reactionGraceMs;
        const lastActivityAt = Math.max(
          actionAt,
          lastRelevantReportMutationAt,
          lastBusyAt,
        );
        if (reacted && now - lastActivityAt >= quietMs) {
          lastSettledReportActionSequence = targetSequence;
          return {
            reused: false,
            sawBusy,
            elapsedMs: now - startedAt,
          };
        }
      }
      await sleep(80);
    }
    lastSettledReportActionSequence = targetSequence;
    return { timedOut: true, elapsedMs: Date.now() - startedAt };
  }

  const ordersTableHeaders = [
    "order no",
    "wh order no",
    "tracking code",
    "order type",
    "order created",
    "sla date",
    "warehouse branch",
    "groupbrand",
  ];
  function ancestorElements(element, maxDepth = 16) {
    const ancestors = [];
    let current = element;
    for (
      let depth = 0;
      current && current !== document.body && depth < maxDepth;
      depth += 1, current = current.parentElement
    ) {
      ancestors.push(current);
    }
    return ancestors;
  }

  function ordersHeaderCount(element) {
    const text = normalize(element?.textContent);
    return ordersTableHeaders.filter((header) => text.includes(header)).length;
  }

  function ordersVisualScore(element, orderNoHeader) {
    if (!isVisible(element) || !element.contains(orderNoHeader)) {
      return Number.NEGATIVE_INFINITY;
    }
    const rect = element.getBoundingClientRect();
    const headerRect = orderNoHeader.getBoundingClientRect();
    const headerCount = ordersHeaderCount(element);
    const topGap = headerRect.top - rect.top;
    const leftGap = Math.abs(headerRect.left - rect.left);
    if (
      headerCount < 3 ||
      rect.width < 420 ||
      rect.height < 90 ||
      topGap < -8 ||
      topGap > 140 ||
      leftGap > 180
    ) {
      return Number.NEGATIVE_INFINITY;
    }

    const className = normalize(element.className);
    const text = normalize(element.textContent);
    let score = headerCount * 35;
    if (
      text.includes("order no") &&
      text.includes("wh order no") &&
      text.includes("tracking code")
    ) {
      score += 80;
    }
    if (className.includes("visual-container")) {
      score += 150;
    } else if (className.includes("visualcontainer")) {
      score += 130;
    } else if (/(^|\s)visual(\s|$)/.test(className)) {
      score += 45;
    }
    if (rect.width >= 700) {
      score += 25;
    }
    if (rect.height >= 180) {
      score += 20;
    }
    score -= topGap / 3;
    score -= leftGap / 10;
    if (
      rect.width >= window.innerWidth * 0.98 &&
      rect.height >= window.innerHeight * 0.85
    ) {
      score -= 220;
    }
    return score;
  }

  function findOrdersVisual() {
    const candidateScores = new Map();
    for (const header of exactTextElements("Order No")) {
      for (const ancestor of ancestorElements(header)) {
        const score = ordersVisualScore(ancestor, header);
        if (score > (candidateScores.get(ancestor) ?? Number.NEGATIVE_INFINITY)) {
          candidateScores.set(ancestor, score);
        }
      }
    }

    const ranked = [...candidateScores]
      .map(([element, score]) => ({ element, score }))
      .filter(({ score }) => Number.isFinite(score))
      .sort((first, second) => second.score - first.score);
    return ranked[0]?.element || null;
  }

  function ordersVisualRoots(visual) {
    const roots = new Set([visual]);
    const visualRect = visual.getBoundingClientRect();
    let current = visual.parentElement;
    for (let depth = 0; current && current !== document.body && depth < 6; depth += 1) {
      const rect = current.getBoundingClientRect();
      if (
        Math.abs(rect.left - visualRect.left) <= 90 &&
        Math.abs(rect.top - visualRect.top) <= 100 &&
        rect.width <= visualRect.width + 180 &&
        rect.height <= visualRect.height + 180 &&
        horizontalOverlapRatio(rect, visualRect) >= 0.65
      ) {
        roots.add(current);
      }
      current = current.parentElement;
    }
    return [...roots];
  }

  function moreOptionsDescriptor(element) {
    return normalize(
      [
        element.textContent,
        element.getAttribute?.("aria-label"),
        element.getAttribute?.("title"),
        element.getAttribute?.("data-testid"),
        element.getAttribute?.("data-test-id"),
        element.className,
      ].join(" "),
    );
  }

  function isMoreOptionsControl(element) {
    const descriptor = moreOptionsDescriptor(element);
    return (
      descriptor === "..." ||
      descriptor === "…" ||
      descriptor.includes("more options") ||
      descriptor.includes("more actions") ||
      descriptor.includes("more commands") ||
      descriptor.includes("additional options") ||
      descriptor.includes("visual options") ||
      descriptor.includes("visual menu") ||
      descriptor.includes("options menu") ||
      descriptor.includes("ellipsis") ||
      descriptor.includes("thêm tùy chọn") ||
      descriptor.includes("các tùy chọn khác")
    );
  }

  function findMoreOptionsCandidates(visual) {
    const controls = new Set();
    const controlSelector =
      "button, [role='button'], [role='menuitem'], [aria-label], [title], [data-testid], [data-test-id]";

    for (const root of ordersVisualRoots(visual)) {
      for (const element of root.querySelectorAll(controlSelector)) {
        if (!isMoreOptionsControl(element)) {
          continue;
        }
        const clickable = clickableAncestor(element, root.parentElement);
        if (
          clickable?.isConnected &&
          clickable.getAttribute?.("aria-disabled") !== "true" &&
          !clickable.disabled
        ) {
          controls.add(clickable);
        }
      }
    }

    return [...controls].sort((first, second) => {
      const firstVisible = isVisible(first) ? 1 : 0;
      const secondVisible = isVisible(second) ? 1 : 0;
      if (firstVisible !== secondVisible) {
        return secondVisible - firstVisible;
      }
      return (
        second.getBoundingClientRect().right - first.getBoundingClientRect().right
      );
    });
  }

  function activateOrdersVisual(visual) {
    visual.scrollIntoView({ block: "center", inline: "nearest" });
    const rect = visual.getBoundingClientRect();
    const clientX = Math.max(
      4,
      Math.min(window.innerWidth - 4, rect.right - Math.min(24, rect.width / 4)),
    );
    const clientY = Math.max(
      4,
      Math.min(window.innerHeight - 4, rect.top + Math.min(30, rect.height / 4)),
    );
    const pointTarget = document.elementFromPoint(clientX, clientY);
    const targets = [
      visual,
      pointTarget,
      visual.querySelector("[role='grid'], [role='table'], [tabindex]"),
    ].filter((element, index, values) => element && values.indexOf(element) === index);

    for (const target of targets) {
      target.focus?.({ preventScroll: true });
      for (const eventName of ["mouseover", "mouseenter", "mousemove"]) {
        target.dispatchEvent(
          new MouseEvent(eventName, {
            bubbles: true,
            cancelable: true,
            composed: true,
            view: window,
            clientX,
            clientY,
          }),
        );
      }
    }
  }

  async function openOrdersMoreOptions(visual) {
    const tried = new Set();
    const deadline = Date.now() + 20000;
    while (Date.now() < deadline) {
      activateOrdersVisual(visual);

      await waitFor(
        () => findMoreOptionsCandidates(visual).find((candidate) => !tried.has(candidate)),
        1100,
        "",
        70,
      ).catch(() => null);

      for (const candidate of findMoreOptionsCandidates(visual)) {
        if (tried.has(candidate)) {
          continue;
        }
        tried.add(candidate);
        clickElement(candidate);
        const exportData = await waitFor(
          () => firstExactText("Export data") || firstExactText("Xuất dữ liệu"),
          1800,
          "",
          120,
        ).catch(() => null);
        if (exportData) {
          return exportData;
        }
        document.dispatchEvent(
          new KeyboardEvent("keydown", {
            key: "Escape",
            code: "Escape",
            keyCode: 27,
            bubbles: true,
          }),
        );
        await sleep(90);
      }
    }
    throw new Error("Không thấy nút More options của bảng Orders Detailed View.");
  }

  function currentLayoutPhraseScore(value) {
    const text = normalize(value);
    let score = 0;
    if (text.includes("data with current layout")) score = Math.max(score, 100);
    if (text.includes("current layout")) score = Math.max(score, 80);
    if (text.includes("dữ liệu với bố cục hiện tại")) score = Math.max(score, 100);
    if (text.includes("bố cục hiện tại")) score = Math.max(score, 80);
    if (!score) return 0;
    if (text.includes(".xlsx") || text.includes("excel")) score += 8;
    if (text.includes("summarized data") || text.includes("underlying data")) score -= 35;
    if (text.includes("dữ liệu tóm tắt") || text.includes("dữ liệu cơ bản")) score -= 35;
    return score;
  }

  function labelForInput(dialog, input) {
    if (!input?.id) return null;
    return [...dialog.querySelectorAll("label[for]")].find(
      (label) => label.htmlFor === input.id || label.getAttribute("for") === input.id,
    ) || null;
  }

  function currentLayoutDescriptor(element, dialog) {
    const values = [
      element.textContent,
      element.getAttribute?.("aria-label"),
      element.getAttribute?.("title"),
      element.getAttribute?.("value"),
      element.getAttribute?.("data-testid"),
      element.getAttribute?.("data-test-id"),
    ];
    if (element.id) {
      const label = labelForInput(dialog, element);
      if (label) values.push(label.textContent, label.getAttribute?.("aria-label"));
    }
    const wrappingLabel = element.closest?.("label");
    if (wrappingLabel && wrappingLabel !== dialog) {
      values.push(wrappingLabel.textContent, wrappingLabel.getAttribute?.("aria-label"));
    }
    const directDescriptor = normalize(values.filter(Boolean).join(" "));
    if (currentLayoutPhraseScore(directDescriptor) > 0) {
      return directDescriptor;
    }
    let current = element.parentElement;
    for (let depth = 0; current && current !== dialog && depth < 3; depth += 1) {
      const radioCount = current.querySelectorAll?.("input[type='radio'], [role='radio']").length || 0;
      if (radioCount > 1) break;
      const ancestorDescriptor = normalize(
        [current.textContent, current.getAttribute?.("aria-label")].filter(Boolean).join(" "),
      );
      if (currentLayoutPhraseScore(ancestorDescriptor) > 0) {
        return normalize(`${directDescriptor} ${ancestorDescriptor}`);
      }
      current = current.parentElement;
    }
    return directDescriptor;
  }

  function currentLayoutClickTarget(element, dialog) {
    if (element.matches?.("[role='radio']") && isVisible(element)) {
      return element;
    }
    if (element.matches?.("input[type='radio']")) {
      if (element.id) {
        const label = labelForInput(dialog, element);
        if (label && isVisible(label)) return label;
      }
      const wrappingLabel = element.closest("label");
      if (wrappingLabel && isVisible(wrappingLabel)) return wrappingLabel;
      if (isVisible(element)) return element;
    }
    const semantic = element.closest?.("[role='radio'], label, button, [role='button']");
    if (semantic && semantic !== dialog && isVisible(semantic)) {
      return semantic;
    }
    let current = element;
    for (let depth = 0; current && current !== dialog && depth < 5; depth += 1) {
      if (isVisible(current)) {
        const rect = current.getBoundingClientRect();
        const hasRadio = current.querySelector?.("input[type='radio'], [role='radio']");
        const descriptor = normalize(
          [current.textContent, current.getAttribute?.("aria-label")].join(" "),
        );
        if (
          currentLayoutPhraseScore(descriptor) > 0 &&
          (hasRadio || current.matches?.("[tabindex], [class*='card'], [class*='option']")) &&
          rect.height <= 220
        ) {
          return current;
        }
      }
      current = current.parentElement;
    }
    return isVisible(element) ? element : null;
  }

  function findCurrentLayoutOption(dialog) {
    const candidates = [];
    const addCandidate = (element, baseScore = 0) => {
      const descriptor = currentLayoutDescriptor(element, dialog);
      const phraseScore = currentLayoutPhraseScore(descriptor);
      if (!phraseScore) return;
      const clickTarget = currentLayoutClickTarget(element, dialog);
      if (!clickTarget || !isVisible(clickTarget)) return;
      const rect = clickTarget.getBoundingClientRect();
      let score = baseScore + phraseScore;
      if (element.matches?.("input[type='radio'], [role='radio']")) score += 100;
      if (clickTarget.matches?.("label, [role='radio']")) score += 45;
      if (rect.height >= 20 && rect.height <= 160) score += 15;
      candidates.push({ element, clickTarget, descriptor, score, area: rect.width * rect.height });
    };

    for (const radio of dialog.querySelectorAll("input[type='radio'], [role='radio']")) {
      addCandidate(radio, 120);
    }
    for (const element of dialog.querySelectorAll(
      "label, button, [role='button'], [aria-label], [title], span, p, div",
    )) {
      if (!isVisible(element) || element.children.length > 12) continue;
      const ownDescriptor = normalize(
        [
          element.textContent,
          element.getAttribute?.("aria-label"),
          element.getAttribute?.("title"),
        ].join(" "),
      );
      const ownScore = currentLayoutPhraseScore(ownDescriptor);
      if (!ownScore) continue;
      addCandidate(element, ownScore);
    }

    candidates.sort((first, second) =>
      second.score - first.score || first.area - second.area,
    );
    return candidates[0] || null;
  }

  function currentLayoutSelectionState(option) {
    const nodes = new Set([option?.element, option?.clickTarget]);
    for (const root of [...nodes]) {
      if (!root?.querySelectorAll) continue;
      for (const node of root.querySelectorAll("input[type='radio'], [role='radio'], [aria-checked], [aria-selected]")) {
        nodes.add(node);
      }
    }
    let exposed = false;
    for (const node of nodes) {
      if (!node) continue;
      if (node.matches?.("input[type='radio']")) {
        exposed = true;
        if (node.checked) return { selected: true, exposed: true };
      }
      for (const attribute of ["aria-checked", "aria-selected", "aria-pressed", "data-selected", "data-checked"]) {
        if (!node.hasAttribute?.(attribute)) continue;
        exposed = true;
        if (["true", "1", "checked", "selected"].includes(normalize(node.getAttribute(attribute)))) {
          return { selected: true, exposed: true };
        }
      }
      const className = normalize(
        typeof node.className === "string" ? node.className : node.getAttribute?.("class"),
      );
      if (/(^|[\s_-])(selected|checked)([\s_-]|$)/.test(className)) {
        return { selected: true, exposed };
      }
    }
    return { selected: false, exposed };
  }

  function enabledExportButton(dialog) {
    const buttons = dialog.querySelectorAll("button, [role='button']");
    return [...buttons].find((button) => {
      const descriptors = [
        button.textContent,
        button.getAttribute?.("aria-label"),
        button.getAttribute?.("title"),
      ].map(normalize).filter(Boolean);
      return (
        isVisible(button) &&
        button.getAttribute("aria-disabled") !== "true" &&
        !button.disabled &&
        descriptors.some((value) =>
          ["export", "export data", "xuất", "xuất dữ liệu"].includes(value),
        )
      );
    }) || null;
  }

  async function selectCurrentLayout(dialog) {
    let option = await waitFor(
      () => findCurrentLayoutOption(dialog),
      10000,
      'Không thấy lựa chọn "Data with current layout (.xlsx)".',
    );
    let state = currentLayoutSelectionState(option);
    if (state.selected) return option;

    await trustedBrowserClick(option.clickTarget);

    const verified = await waitFor(
      () => {
        option = findCurrentLayoutOption(dialog) || option;
        state = currentLayoutSelectionState(option);
        if (state.selected) return option;
        if (!state.exposed && enabledExportButton(dialog)) return option;
        return null;
      },
      6000,
      "",
      90,
    ).catch(() => null);
    if (!verified) {
      throw new Error(
        'Đã bấm nhưng Power BI chưa chọn "Data with current layout (.xlsx)".',
      );
    }
    return verified;
  }

  /* ---------------------------------------------------------------------------
   * v0.11.17 — BẤM "EXPORT DATA" PHẢI CÓ BẰNG CHỨNG, KHÔNG BẤM MÙ.
   *
   * Bản cũ: `clickElement(...)` một phát rồi coi như xong, tool báo "đang mở
   * Export data" trong khi thực tế chẳng có gì mở ra. Power BI dựng menu bằng
   * React và gắn handler SAU một nhịp render — click tổng hợp bắn quá sớm là
   * rơi vào hư không. Ngoài ra menu của Power BI nhiều chỗ chỉ ăn chuột THẬT.
   *
   * Nay mỗi lần thử: mở lại menu (lấy phần tử mới, tránh node đã chết) → nghỉ
   * cho menu ổn định → bấm → CHỜ hộp thoại làm bằng chứng. Không thấy thì leo
   * thang sang chuột thật qua Chrome debugger — đúng cách đang dùng cho nút
   * Export cuối cùng.
   * ------------------------------------------------------------------------ */
  const EXPORT_DIALOG_TITLES = [
    "Which data do you want to export?",
    "Bạn muốn xuất dữ liệu nào?",
  ];

  function findExportDialogTitle() {
    for (const title of EXPORT_DIALOG_TITLES) {
      const found = firstExactText(title);
      if (found) return found;
    }
    return null;
  }

  async function openExportDialog(visual) {
    let lastError = "";
    for (let attempt = 1; attempt <= 4; attempt += 1) {
      const exportData = await openOrdersMoreOptions(visual);
      const target = clickableAncestor(exportData) || exportData;
      // Nghỉ cho menu vẽ xong và React gắn xong handler. Lần sau nghỉ lâu hơn.
      await sleep(attempt === 1 ? 260 : 560);
      try {
        if (attempt === 1) {
          clickElement(target);
        } else {
          await trustedBrowserClick(target);
        }
      } catch (error) {
        lastError = error?.message || String(error);
      }
      const title = await waitFor(
        findExportDialogTitle,
        attempt === 1 ? 4000 : 9000,
        "",
        120,
      ).catch(() => null);
      if (title) {
        return title;
      }
      progress(
        "Đang mở Export data",
        `Lần ${attempt} chưa mở được hộp thoại, đang thử lại chậm hơn…`,
        68,
        `Export data: thử lần ${attempt} không mở được hộp thoại.`,
      );
      document.dispatchEvent(
        new KeyboardEvent("keydown", {
          key: "Escape",
          code: "Escape",
          keyCode: 27,
          bubbles: true,
        }),
      );
      await sleep(450);
    }
    throw new Error(
      `Không mở được hộp thoại export của Power BI sau 4 lần thử.${lastError ? ` Lỗi gần nhất: ${lastError}` : ""}`,
    );
  }

  async function exportCurrentLayout() {
    const visual = await waitFor(
      findOrdersVisual,
      45000,
      "Không tìm thấy visual Orders Detailed View để export.",
    );
    const dialogTitle = await openExportDialog(visual);
    const dialog =
      dialogTitle.closest("[role='dialog']") ||
      dialogTitle.closest("[class*='dialog']") ||
      dialogTitle.parentElement?.parentElement?.parentElement ||
      document;

    await selectCurrentLayout(dialog);

    const exportButton = await waitFor(
      () => enabledExportButton(dialog),
      8000,
      "Nút Export đang bị khóa hoặc không tìm thấy.",
    );
    await trustedBrowserClick(exportButton);

    /* v0.11.18 — kiểm chứng cú bấm Export CÓ ăn hay không.
     *
     * Không có bước này thì một cú bấm rơi vào hư không sẽ khiến tool đứng chờ
     * file suốt 6 phút rồi mới báo lỗi — sai chỗ, và phí thời gian của người
     * đang chạy hàng trăm phiếu. Bằng chứng đơn giản nhất và chắc nhất: hộp
     * thoại phải ĐÓNG. Còn nguyên sau 6 giây nghĩa là chưa ăn → bấm lại một
     * lần nữa rồi mới chịu đi tiếp. */
    const dialogClosed = await waitFor(
      () => (findExportDialogTitle() ? null : true),
      6000,
      "",
      150,
    ).catch(() => null);

    if (!dialogClosed) {
      progress(
        "Đang bấm Export",
        "Hộp thoại chưa đóng sau cú bấm đầu — đang bấm lại.",
        70,
        "Export: cú bấm đầu chưa ăn, thử lại lần 2.",
      );
      const retryButton = enabledExportButton(dialog) || exportButton;
      await sleep(500);
      await trustedBrowserClick(retryButton);
      const closedNow = await waitFor(
        () => (findExportDialogTitle() ? null : true),
        8000,
        "",
        150,
      ).catch(() => null);
      if (!closedNow) {
        throw new Error(
          "Đã bấm nút Export hai lần nhưng hộp thoại của Power BI không đóng — cú bấm chưa được ghi nhận.",
        );
      }
    }

    progress(
      "Đang chờ Power BI trả file",
      "Power BI dựng file phía máy chủ; bảng lớn có thể mất vài phút.",
      72,
      "Đã bấm Export, hộp thoại đã đóng. Đang chờ file Excel.",
    );
  }

  async function run(config) {
    const updatedAt = readUpdatedAt();
    chrome.runtime
      .sendMessage({ type: "PBI_SET_TIMESTAMP", timestamp: updatedAt })
      .catch(() => {});
    await clearTopGlobalSearch();
    progress(
      "Đang reset bộ lọc",
      "Bấm Clear all slicers (xóa hết bộ lọc, kể cả khoảng ngày).",
      12,
      "Đang bấm Clear all slicers.",
    );
    await clearAllSlicers();
    await waitForReportToSettle({ reactionGraceMs: 900, quietMs: 300 });

    progress(
      "Đang chọn Order Status",
      config.statuses.join(", "),
      24,
      `Đã reset slicer; bắt đầu chọn ${config.statuses.length} status backlog.`,
    );
    await applyStatusSelection(config.statuses);
    await waitForReportToSettle();

    const platformList =
      config.platformValues && config.platformValues.length
        ? config.platformValues
        : ["TIKTOK"];
    progress(
      "Đang chọn Platform",
      `${config.platformLabel} = ${platformList.join(", ")}`,
      36,
      `Đã chọn ${config.statuses.length} status backlog.`,
    );
    await applyBranchSelection(config.platformLabel, platformList);
    await waitForReportToSettle();

    const warehouseList =
      config.warehouses && config.warehouses.length
        ? config.warehouses
        : ["TNSL", "TOLL", "MCL"];
    progress(
      "Đang chọn Warehouse FFM",
      `${config.warehouseLabel} = ${warehouseList.join(", ")}`,
      47,
      `Đã chọn ${config.platformLabel} = ${platformList.join(", ")}.`,
    );
    await applyBranchSelection(config.warehouseLabel, warehouseList, {
      // Keep Shopee on the proven v0.10.23 path. The stronger post-click
      // verification is enabled only for the TikTok warehouse slicer.
      verifyTikTokWarehouse:
        platformList.length === 1 && normalize(platformList[0]) === "tiktok",
    });
    await waitForReportToSettle();

    progress(
      "Đang lọc SLA Date",
      "Year to date: từ đầu năm đến hôm nay.",
      56,
      `Đã chọn Warehouse FFM = ${warehouseList.join(", ")}; đang nhập khoảng SLA Date YTD.`,
    );
    const slaRange = await applySlaYearToDate(config.slaDateLabel);

    progress(
      "Đang chờ Power BI cập nhật",
      "Đợi visual Orders Detailed View tải xong.",
      64,
      `SLA Date = ${formatDateForLog(slaRange.from)} → ${formatDateForLog(
        slaRange.to,
      )}.`,
    );
    await waitForReportToSettle();

    progress(
      "Đang export dữ liệu",
      "Chọn Data with current layout (.xlsx).",
      72,
      `Đã áp dụng Warehouse FFM = ${warehouseList.join(", ")} và SLA Date = Year to date; đang mở Export data.`,
    );
    await exportCurrentLayout();
    return {
      ok: true,
      timestamp: updatedAt,
      slaDateFrom: formatDateForLog(slaRange.from),
      slaDateTo: formatDateForLog(slaRange.to),
      warehouses: warehouseList,
    };
  }

  let running = false;
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === "PROBE_PBI_AUTOMATION") {
      let score = 0;
      if (firstExactText("Order Status")) score += 3;
      if (firstExactText("Platform, Store")) score += 3;
      if (firstExactText("FFM Group, WH Branch")) score += 3;
      if (visibleDateInputs(findDateRangeSlicer("SLA Date")).length >= 2) score += 2;
      if (firstExactText("Clear all slicers")) score += 1;
      if (findOrdersVisual()) score += 5;
      sendResponse({ ok: true, score });
      return false;
    }

    if (message?.type !== "RUN_PBI_AUTOMATION") {
      return false;
    }
    if (running) {
      sendResponse({ ok: false, error: "Automation đang chạy, vui lòng chờ." });
      return false;
    }

    const allowedWarehouses = ["TNSL", "TOLL", "MCL"];
    const requestedWarehouses = Array.isArray(message.config?.warehouses)
      ? message.config.warehouses.map((value) =>
          String(value || "").trim().toUpperCase(),
        )
      : allowedWarehouses;
    const warehouses = allowedWarehouses.filter((value) =>
      requestedWarehouses.includes(value),
    );
    if (!warehouses.length) {
      sendResponse({
        ok: false,
        error: "Hãy chọn ít nhất 1 Warehouse FFM: TNSL, TOLL hoặc MCL.",
      });
      return false;
    }

    running = true;
    run({
      statuses: [
        "dl_pending",
        "new",
        "pending_warehouse",
        "wh_completed",
        "wh_processing",
      ],
      platformLabel: "Platform, Store",
      platformValues: [
        String(message.config?.platform || "TIKTOK").toUpperCase() === "SHOPEE"
          ? "SHOPEE"
          : "TIKTOK",
      ],
      warehouseLabel: "FFM Group, WH Branch",
      warehouses,
      slaDateLabel: "SLA Date",
    })
      .then((response) => sendResponse(response))
      .catch((error) => {
        const payload = {
          type: "PBI_AUTOMATION_PROGRESS",
          step: "error",
          message: error.message || String(error),
          at: new Date().toISOString(),
        };
        chrome.storage.local.set({ pbiLastRun: payload }).catch(() => {});
        chrome.runtime.sendMessage(payload).catch(() => {});
        sendResponse({ ok: false, error: error.message });
      })
      .finally(() => {
        running = false;
      });
    return true;
  });
})();
