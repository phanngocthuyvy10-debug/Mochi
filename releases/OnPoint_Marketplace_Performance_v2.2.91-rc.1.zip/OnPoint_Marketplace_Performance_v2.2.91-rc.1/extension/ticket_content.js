(function () {
  if (window.__OP_TTS_TICKET_AUTOFILL__) return;
  window.__OP_TTS_TICKET_AUTOFILL__ = true;

  const EXTENSION_BUILD = 'v0.11.28';
  let ticketContext = null, shopeeCapture = null;

  const SUBJECT_PATH = [
    'Thực hiện đơn hàng & Hậu cần (3PL/4PL)',
    'Quản lý sự vận chuyển',
    'Yêu cầu trợ cấp vận chuyển'
  ];
  const SUBJECT_FULL_TEXT = SUBJECT_PATH.join(' / ');
  let subjectSelectionFailure = '';

  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  const norm = (value) => String(value ?? '')
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/đ/g, 'd').replace(/Đ/g, 'D')
    .trim().toLowerCase().replace(/\s+/g, ' ');

  // v0.11 — LỌC HAI TẦNG (xem lib/op-dom.js để biết lý do đầy đủ).
  // Shopee form cũng bị quét rộng như TikTok; đổi riêng hàm này đã cắt phần
  // lớn chi phí vì getComputedStyle chỉ còn chạy trên node thật sự có hình.
  const visible = (el) => {
    if (!el || !(el instanceof Element)) return false;
    const rects = el.getClientRects();
    if (!rects.length || rects[0].width <= 1 || rects[0].height <= 1) return false;
    const style = getComputedStyle(el);
    return style.visibility !== 'hidden' && Number(style.opacity || 1) > 0;
  };

  const setNativeValue = (el, value) => {
    if (el?.isContentEditable) {
      el.focus();
      el.textContent = String(value ?? '');
      el.dispatchEvent(new InputEvent('input', {
        bubbles: true,
        inputType: 'insertText',
        data: String(value ?? '')
      }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
      el.blur();
      return;
    }
    if (el?.tagName === 'SELECT') {
      el.value = value;
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
      el.blur();
      return;
    }
    const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
    setter ? setter.call(el, value) : (el.value = value);
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.blur();
  };

  function textOf(el) {
    return `${el.getAttribute?.('placeholder') || ''} ${el.getAttribute?.('aria-label') || ''} ${el.closest?.('label')?.innerText || ''} ${el.parentElement?.innerText || ''}`.toLowerCase();
  }

  function fireClick(el, useExactElement = false) {
    if (!el) return false;
    const target = useExactElement
      ? el
      : (el.closest?.('button,[role="button"],[role="option"],[role="menuitem"],label') || el);
    target.scrollIntoView({ block: 'center', inline: 'center' });
    const pointerEvent = typeof PointerEvent === 'function' ? PointerEvent : MouseEvent;
    target.dispatchEvent(new pointerEvent('pointerover', { bubbles: true, cancelable: true, view: window }));
    target.dispatchEvent(new MouseEvent('mouseover', { bubbles: true, cancelable: true, view: window }));
    target.dispatchEvent(new pointerEvent('pointerdown', { bubbles: true, cancelable: true, view: window, button: 0 }));
    target.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, view: window }));
    target.focus?.({ preventScroll: true });
    target.dispatchEvent(new pointerEvent('pointerup', { bubbles: true, cancelable: true, view: window, button: 0 }));
    target.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true, view: window }));
    if (typeof target.click === 'function') target.click();
    else target.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window }));
    return true;
  }

  async function waitFor(fn, timeout = 10000, interval = 250) {
    const started = Date.now();
    while (Date.now() - started < timeout) {
      const result = fn();
      if (result) return result;
      await sleep(interval);
    }
    return null;
  }

  function runtimeMessage(message) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(message, (response) => {
        if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
        else resolve(response);
      });
    });
  }

  function elementText(el) {
    return el?.innerText ||
      el?.textContent ||
      el?.getAttribute?.('title') ||
      el?.getAttribute?.('aria-label') ||
      el?.value ||
      '';
  }

  function isTooltip(el) {
    if (!el) return false;
    return Boolean(
      el.closest?.('[role="tooltip"]') ||
      el.getAttribute?.('role') === 'tooltip' ||
      norm(el.className || '').includes('tooltip')
    );
  }

  function findVisibleText(target, exactOnly = false) {
    const wanted = norm(target);
    const candidates = [...document.querySelectorAll('[role="option"],[role="menuitem"],button,a,label,span,div,p')]
      .filter(visible)
      .filter((el) => !isTooltip(el))
      .filter((el) => {
        const value = norm(elementText(el));
        return value === wanted || (!exactOnly && value.includes(wanted));
      })
      .sort((a, b) => elementText(a).length - elementText(b).length);
    return candidates[0] || null;
  }

  function subjectAlreadySelected() {
    const wanted = norm(SUBJECT_FULL_TEXT);
    const path = SUBJECT_PATH.map(norm);
    const finalStep = path[path.length - 1];
    const controls = subjectTriggerCandidates();
    if (controls.some((el) => {
      const value = norm([
        elementText(el),
        el.getAttribute?.('aria-label'),
        el.getAttribute?.('title'),
        el.value
      ].filter(Boolean).join(' '));
      return !value.includes('chon mot chu de') &&
        (value === finalStep || value.includes(finalStep) || path.every((part) => value.includes(part)));
    })) return true;

    const nodes = [...document.querySelectorAll('input,[role="combobox"],button,span,div')]
      .filter(visible)
      .filter((el) => !isTooltip(el))
      .filter((el) => {
        const rect = el.getBoundingClientRect();
        return rect.height <= 110 && rect.width <= Math.max(1200, window.innerWidth);
      });

    return nodes.some((el) => {
      const value = norm(elementText(el));
      return value === wanted || path.every((part) => value.includes(part));
    });
  }

  function subjectLabels() {
    return [...document.querySelectorAll('label,div,span,p')]
      .filter(visible)
      .filter((el) => norm(el.innerText || el.textContent || '').replace(/^\*\s*/, '') === 'chu de');
  }

  function subjectTriggerCandidates() {
    const wanted = norm('Chọn một chủ đề');
    const scored = new Map();
    const add = (el, baseScore = 0) => {
      if (!el || !visible(el) || isTooltip(el) || el === document.body || el === document.documentElement) return;
      const rect = el.getBoundingClientRect();
      if (rect.width < 120 || rect.height < 24 || rect.height > 100) return;

      const classText = norm(typeof el.className === 'string' ? el.className : el.getAttribute?.('class') || '');
      const ownText = norm([
        elementText(el),
        el.getAttribute?.('placeholder'),
        el.getAttribute?.('aria-label'),
        el.getAttribute?.('title')
      ].filter(Boolean).join(' '));
      let score = baseScore;
      if (el.matches('[role="combobox"]')) score += 320;
      if (el.matches('[aria-haspopup]')) score += 250;
      if (el.matches('input')) score += 210;
      if (el.matches('button,[role="button"]')) score += 190;
      if (el.hasAttribute?.('tabindex')) score += 130;
      if (/(select|cascader|picker|trigger|selector)/.test(classText)) score += 220;
      if (getComputedStyle(el).cursor === 'pointer') score += 90;
      if (norm(el.getAttribute?.('placeholder')) === wanted) score += 180;
      if (ownText === wanted) score += 130;
      else if (ownText.includes(wanted)) score += 70;
      if (rect.height >= 32 && rect.height <= 64) score += 70;
      if (rect.width >= 280) score += 45;
      if (el.matches('span,p')) score -= 120;
      const previous = scored.get(el);
      if (previous === undefined || score > previous) scored.set(el, score);
    };

    const placeholderSeeds = [...document.querySelectorAll('input,button,[role="button"],[role="combobox"],[tabindex],span,div,p')]
      .filter(visible)
      .filter((el) => !isTooltip(el))
      .filter((el) => {
        const value = norm([
          elementText(el),
          el.getAttribute?.('placeholder'),
          el.getAttribute?.('aria-label')
        ].filter(Boolean).join(' '));
        return value === wanted;
      });
    for (const seed of placeholderSeeds) {
      let current = seed;
      for (let depth = 0; current && depth < 7 && current !== document.body; depth++, current = current.parentElement) {
        add(current, Math.max(0, 170 - depth * 18));
      }
    }

    for (const label of subjectLabels()) {
      let scope = label.parentElement;
      for (let depth = 0; scope && depth < 5 && scope !== document.body; depth++, scope = scope.parentElement) {
        const nodes = scope.querySelectorAll(
          'input,button,[role="button"],[role="combobox"],[aria-haspopup],[tabindex],div[class*="select"],div[class*="Select"],div[class*="cascader"],div[class*="Cascader"],div[class*="picker"],div[class*="Picker"]'
        );
        for (const node of nodes) {
          if (node === label || node.contains(label)) continue;
          const value = norm([
            elementText(node),
            node.getAttribute?.('placeholder'),
            node.getAttribute?.('aria-label')
          ].filter(Boolean).join(' '));
          const semantic = node.matches('input,button,[role="button"],[role="combobox"],[aria-haspopup],[tabindex]') ||
            /(select|cascader|picker|trigger|selector)/.test(norm(node.className || ''));
          if (value.includes(wanted) || semantic) add(node, Math.max(0, 110 - depth * 18));
        }
      }
    }

    return [...scored.entries()]
      .sort((a, b) => b[1] - a[1])
      .map(([el]) => el);
  }

  function findSubjectTrigger() {
    return subjectTriggerCandidates()[0] || null;
  }

  function subjectPopupVisible() {
    if (findSubjectOption(SUBJECT_PATH[0])) return true;
    const firstStep = norm(SUBJECT_PATH[0]);
    return [...document.querySelectorAll('[role="listbox"],[role="menu"],[role="tree"],[role="dialog"],div')]
      .filter(visible)
      .filter((el) => !isTooltip(el))
      .some((el) => {
        const rect = el.getBoundingClientRect();
        if (rect.width < 150 || rect.height < 70) return false;
        const classText = norm(typeof el.className === 'string' ? el.className : el.getAttribute?.('class') || '');
        const popupLike = el.matches('[role="listbox"],[role="menu"],[role="tree"],[role="dialog"]') ||
          /(cascader|dropdown|popup|popover|menu)/.test(classText);
        return popupLike && norm(elementText(el)).includes(firstStep);
      });
  }

  function pressOpenKey(el, key) {
    if (!el) return;
    el.focus?.({ preventScroll: true });
    const code = key === ' ' ? 'Space' : key;
    el.dispatchEvent(new KeyboardEvent('keydown', { key, code, bubbles: true, cancelable: true }));
    el.dispatchEvent(new KeyboardEvent('keyup', { key, code, bubbles: true, cancelable: true }));
  }

  async function openSubjectMenu() {
    if (subjectPopupVisible()) return true;
    const candidates = await waitFor(() => {
      const items = subjectTriggerCandidates();
      return items.length ? items : null;
    }, 10000, 180);
    if (!candidates) return false;

    for (const candidate of candidates.slice(0, 8)) {
      fireClick(candidate, true);
      if (await waitFor(subjectPopupVisible, 1800, 120)) return true;

      pressOpenKey(candidate, 'ArrowDown');
      if (await waitFor(subjectPopupVisible, 1200, 120)) return true;

      pressOpenKey(candidate, ' ');
      if (await waitFor(subjectPopupVisible, 1200, 120)) return true;
    }
    return false;
  }

  function subjectOptionText(value) {
    return norm(value)
      .replace(/[›»>⌄⌃→←]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function subjectOptionTargets(step) {
    const wanted = norm(step);
    const seeds = [...document.querySelectorAll(
      '[role="option"],[role="menuitem"],li,button,[tabindex],span,div,p'
    )]
      .filter(visible)
      .filter((el) => !isTooltip(el))
      .filter((el) => subjectOptionText(elementText(el)) === wanted);
    const scored = new Map();

    const add = (node, seed, depth) => {
      if (!node || !visible(node) || isTooltip(node) || node === document.body || node === document.documentElement) return;
      const rect = node.getBoundingClientRect();
      if (
        rect.width < 55 ||
        rect.height < 20 ||
        rect.height > 96 ||
        rect.width > Math.max(1500, window.innerWidth * 1.25) ||
        getComputedStyle(node).pointerEvents === 'none'
      ) return;

      const value = subjectOptionText(elementText(node));
      if (value !== wanted && !(value.includes(wanted) && value.length <= wanted.length + 8)) return;

      const classText = norm(
        typeof node.className === 'string'
          ? node.className
          : node.getAttribute?.('class') || ''
      );
      const style = getComputedStyle(node);
      let score = 0;
      if (node.matches('button,[role="option"],[role="menuitem"],li,[tabindex]')) score += 260;
      if (/(cascader|menu|option|item|category|row|node)/.test(classText)) score += 220;
      if (style.cursor === 'pointer') score += 170;
      if (node.querySelector?.('svg,[class*="arrow"],[class*="Arrow"],[class*="chevron"],[class*="Chevron"]')) score += 90;
      if (node.children.length > 0) score += 55;
      if (rect.height >= 28 && rect.height <= 58) score += 50;
      if (rect.width >= Math.max(140, seed.getBoundingClientRect().width * 1.2)) score += 65;
      if (node === seed) score += 20;
      score += Math.min(depth, 4) * 8;
      if (node.matches('span,p')) score -= 180;

      const previous = scored.get(node);
      if (previous === undefined || score > previous) scored.set(node, score);
    };

    for (const seed of seeds) {
      let current = seed;
      for (
        let depth = 0;
        current && depth < 9 && current !== document.body;
        depth++, current = current.parentElement
      ) {
        add(current, seed, depth);
      }
    }

    return [...scored.entries()]
      .sort((a, b) => b[1] - a[1])
      .map(([node]) => node);
  }

  function findSubjectOption(step) {
    return subjectOptionTargets(step)[0] || null;
  }

  function subjectScrollContainers() {
    return [...document.querySelectorAll('[role="menu"],[role="listbox"],ul,div')]
      .filter(visible)
      .filter((el) => !isTooltip(el))
      .filter((el) => {
        const rect = el.getBoundingClientRect();
        const style = getComputedStyle(el);
        return el.scrollHeight > el.clientHeight + 6 &&
          rect.width >= 100 &&
          rect.width <= 760 &&
          rect.height >= 70 &&
          rect.height <= 560 &&
          (/(auto|scroll)/.test(style.overflowY) || ['menu', 'listbox'].includes(el.getAttribute('role')));
      });
  }

  async function findSubjectOptionWithScroll(step, timeout = 9000) {
    const started = Date.now();
    let pass = 0;
    while (Date.now() - started < timeout) {
      const option = findSubjectOption(step);
      if (option) return option;

      const containers = subjectScrollContainers();
      for (const container of containers) {
        const max = Math.max(0, container.scrollHeight - container.clientHeight);
        if (!max) continue;
        const next = Math.min(max, container.scrollTop + Math.max(80, Math.floor(container.clientHeight * 0.72)));
        if (next === container.scrollTop && pass > 0) container.scrollTop = 0;
        else container.scrollTop = next;
        container.dispatchEvent(new Event('scroll', { bubbles: true }));
      }
      pass += 1;
      await sleep(260);
    }
    return null;
  }

  async function hoverSubjectOption(option) {
    if (!option) return false;
    option.scrollIntoView({ block: 'center', inline: 'nearest' });
    const pointerEvent = typeof PointerEvent === 'function' ? PointerEvent : MouseEvent;
    option.dispatchEvent(new pointerEvent('pointerover', { bubbles: true, cancelable: true, view: window }));
    option.dispatchEvent(new pointerEvent('pointerenter', { bubbles: false, cancelable: true, view: window }));
    option.dispatchEvent(new MouseEvent('mouseover', { bubbles: true, cancelable: true, view: window }));
    option.dispatchEvent(new MouseEvent('mouseenter', { bubbles: false, cancelable: true, view: window }));
    option.dispatchEvent(new pointerEvent('pointermove', { bubbles: true, cancelable: true, view: window }));
    option.dispatchEvent(new MouseEvent('mousemove', { bubbles: true, cancelable: true, view: window }));
    await sleep(260);
    return true;
  }

  async function expandSubjectBranch(step, nextStep) {
    const targets = await waitFor(() => {
      const items = subjectOptionTargets(step);
      return items.length ? items : null;
    }, 9000, 160);
    if (!targets) {
      subjectSelectionFailure = `không thấy tầng "${step}"`;
      return false;
    }

    // TikTok attaches the cascade handler to the row wrapper, not always to
    // the inner text span. Hover every plausible wrapper before clicking.
    for (const target of targets.slice(0, 8)) {
      await hoverSubjectOption(target);
      if (await waitFor(() => findSubjectOption(nextStep), 1500, 100)) return true;
    }

    for (const target of targets.slice(0, 8)) {
      await hoverSubjectOption(target);
      fireClick(target, true);
      if (await waitFor(() => findSubjectOption(nextStep), 2200, 100)) return true;
    }

    subjectSelectionFailure = `đã thấy "${step}" nhưng cột "${nextStep}" không mở`;
    return false;
  }

  async function chooseSubjectLeaf(step) {
    const targets = await waitFor(() => {
      const items = subjectOptionTargets(step);
      return items.length ? items : null;
    }, 9000, 160);
    if (!targets) {
      subjectSelectionFailure = `không thấy tầng cuối "${step}"`;
      return false;
    }

    for (const target of targets.slice(0, 8)) {
      await hoverSubjectOption(target);
      fireClick(target, true);
      if (await waitFor(subjectAlreadySelected, 2400, 120)) return true;
    }
    subjectSelectionFailure = `đã thấy "${step}" nhưng form chưa ghi nhận lựa chọn`;
    return false;
  }

  async function selectSubjectPath() {
    if (subjectAlreadySelected()) return true;
    subjectSelectionFailure = '';

    for (let attempt = 0; attempt < 3; attempt++) {
      if (!await openSubjectMenu()) {
        subjectSelectionFailure = 'không mở được ô "Chọn một chủ đề"';
        return false;
      }
      await sleep(300);

      const first = await findSubjectOptionWithScroll(SUBJECT_PATH[0], 9000);
      if (!first) {
        subjectSelectionFailure = `không thấy tầng "${SUBJECT_PATH[0]}"`;
        continue;
      }

      const level1 = await expandSubjectBranch(SUBJECT_PATH[0], SUBJECT_PATH[1]);
      if (!level1) {
        await sleep(350);
        continue;
      }

      const level2 = await expandSubjectBranch(SUBJECT_PATH[1], SUBJECT_PATH[2]);
      if (!level2) {
        await sleep(350);
        continue;
      }

      if (await chooseSubjectLeaf(SUBJECT_PATH[2])) return true;
      await sleep(450);
    }
    return false;
  }

  function base64ToBytes(base64) {
    const binary = atob(base64 || '');
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    return bytes;
  }

  function storedToFile(item) {
    return new File([base64ToBytes(item.base64)], item.name, {
      type: item.type || 'application/octet-stream',
      lastModified: Date.now()
    });
  }

  async function findFileInput() {
    let input = document.querySelector('input[type="file"]');
    if (input) return input;

    const uploadButton = [...document.querySelectorAll('button,[role="button"],span,div')]
      .filter(visible)
      .find((el) => /^(tai len|upload)$/.test(norm(el.innerText || el.textContent || '')));
    if (uploadButton) {
      fireClick(uploadButton);
      await sleep(450);
    }
    input = await waitFor(() => document.querySelector('input[type="file"]'), 5000);
    return input;
  }

  async function uploadAttachments(storedAttachments) {
    const items = Array.isArray(storedAttachments) ? storedAttachments.slice(0, 6) : [];
    if (!items.length) return { ok: false, count: 0 };
    const input = await findFileInput();
    if (!input) return { ok: false, count: 0 };

    const dt = new DataTransfer();
    for (const item of items) dt.items.add(storedToFile(item));
    input.files = dt.files;
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
    const expectedCount = dt.files.length;
    const completed = await waitFor(() => {
      const error = shopeeUploadError();
      if (error) return { error };
      const count = shopeeUploadedCount();
      if (count !== null && count >= expectedCount && !shopeeUploadInProgress()) {
        return { count };
      }
      return null;
    }, 30000, 250);

    if (completed?.error) {
      return { ok: false, count: shopeeUploadedCount() || 0, error: completed.error };
    }
    if (completed?.count >= expectedCount) {
      return { ok: true, count: expectedCount, renderedCount: completed.count };
    }

    const fallbackCount = Number(input.files?.length || 0);
    const counter = shopeeUploadedCount();
    const ok = !shopeeUploadError() && !shopeeUploadInProgress() && (
      counter !== null ? counter >= expectedCount : fallbackCount >= expectedCount
    );
    return { ok, count: ok ? expectedCount : Math.max(counter || 0, fallbackCount) };
  }

  function shopeeNativeUploadState() {
    const widgets = [...document.querySelectorAll('form .bb-upload,form .bb-proof')].filter(visible);
    if (!widgets.length) return null;
    const items = widgets.flatMap(widget => [...widget.querySelectorAll('.bb-upload-list-item,.bb-proof-list-item,.bb-upload-mobile-item')]);
    const failed = items.some(item => item.matches('.is-error') || item.querySelector('.bb-upload-mobile-item__retry'));
    const successful = items.filter(item => item.matches('.bb-upload-mobile-item')
      ? !item.matches('.is-uploading,.is-error') && !item.querySelector('.bb-upload-mobile-item__retry')
      : Boolean(item.querySelector('.upload-success')));
    const busy = widgets.some(widget => [...widget.querySelectorAll('.upload-under-pregress,.is-uploading,.bb-upload__loading-tip,[aria-busy="true"]')].some(visible));
    return { total: items.length, count: successful.length, pending: busy || items.length > successful.length, error: failed ? 'Shopee báo tải file thất bại.' : '' };
  }

  function shopeeUploadedCount() {
    const state = shopeeNativeUploadState();
    if (state) return state.count;
    const nodes = [...document.querySelectorAll('button,[role="button"],span,div')]
      .filter(visible)
      .map((el) => elementText(el));
    for (const text of nodes) {
      const match = String(text || '').match(/(?:\(\s*)?(\d+)\s*\/\s*5(?:\s*\))?/);
      if (match) return Number(match[1]);
    }
    return null;
  }

  function shopeeUploadError() {
    const state = shopeeNativeUploadState();
    if (state?.error) return state.error;
    const text = norm(document.body.innerText || document.body.textContent || '');
    const match = text.match(/(?:tai len (?:that bai|khong thanh cong)|khong the tai len tep|tep khong hop le|dinh dang (?:khong hop le|khong duoc ho tro)|vuot qua dung luong|file qua lon|upload failed|file upload failed)/);
    return match ? match[0] : '';
  }

  function shopeeUploadInProgress() {
    const state = shopeeNativeUploadState();
    if (state) return state.pending;
    const progress = [...document.querySelectorAll(
      '[class*="upload"] [class*="loading"],.upload-under-pregress,.is-uploading,[aria-busy="true"]'
    )].some(visible);
    const text = norm(document.body.innerText || document.body.textContent || '');
    return progress || /(?:dang tai len|uploading)/.test(text);
  }

  function fillDescription(draft) {
    const textareas = [...document.querySelectorAll('textarea')].filter((el) => !el.disabled && visible(el));
    if (textareas.length) {
      setNativeValue(textareas.sort((a, b) => b.clientHeight - a.clientHeight)[0], String(draft.text || '').slice(0, 500));
      return true;
    }

    const editables = [...document.querySelectorAll('[contenteditable="true"]')].filter(visible);
    if (editables.length) {
      editables[0].focus();
      document.execCommand('selectAll', false, null);
      document.execCommand('insertText', false, String(draft.text || '').slice(0, 500));
      editables[0].dispatchEvent(new Event('input', { bubbles: true }));
      return true;
    }
    return false;
  }

  async function fillRepresentativeOrderId(draft) {
    const value = draft.representativeOrderId || draft.rows?.[0]?.orderId || '';
    if (!value) return false;

    const input = await waitFor(() => {
      const inputs = [...document.querySelectorAll('input')].filter((el) => !el.disabled && el.type !== 'file' && visible(el));
      return inputs.find((el) => /order|don hang|ma don|id don/.test(norm(textOf(el)))) || null;
    }, 7000);
    if (!input) return false;
    setNativeValue(input, value);
    return true;
  }

  async function fillDraft(draft, attachments) {
    if (!draft) return { ok: false, error: 'Không có draft.' };
    const subjectOk = await selectSubjectPath();
    if (!subjectOk) {
      const detail = subjectSelectionFailure ? ` (${subjectSelectionFailure})` : '';
      showBanner(`Chưa chọn được Chủ đề${detail}. Tool đã dừng trước khi điền phần còn lại.`, true);
      return {
        ok: false,
        subjectOk: false,
        descriptionOk: false,
        orderOk: false,
        uploadOk: false,
        uploadCount: 0
      };
    }
    await sleep(650);
    const descriptionOk = fillDescription(draft);
    const orderOk = await fillRepresentativeOrderId(draft);
    const uploadResult = await uploadAttachments(attachments);

    const details = [
      subjectOk ? 'đã chọn đúng chủ đề' : 'chưa chọn được chủ đề',
      descriptionOk ? 'đã điền mô tả' : 'chưa thấy ô mô tả',
      orderOk ? 'đã điền Order ID đại diện' : 'chưa thấy ô Order ID',
      uploadResult.ok ? `đã đính kèm ${uploadResult.count} file` : 'chưa đính kèm được file'
    ].join(' · ');
    showBanner(`${details}. Kiểm tra lại rồi tự bấm Gửi.`, !(subjectOk && descriptionOk && orderOk && uploadResult.ok));
    return {
      ok: Boolean(subjectOk && descriptionOk && orderOk && uploadResult.ok),
      subjectOk,
      descriptionOk,
      orderOk,
      uploadOk: uploadResult.ok,
      uploadCount: uploadResult.count
    };
  }

  function showBanner(message, isWarning = false) {
    const old = document.getElementById('op-ticket-banner');
    if (old) old.remove();
    const bar = document.createElement('div');
    bar.id = 'op-ticket-banner';
    bar.textContent = `${EXTENSION_BUILD} · ${message}`;
    Object.assign(bar.style, {
      position: 'fixed', top: '12px', left: '50%', transform: 'translateX(-50%)', zIndex: '2147483647',
      background: isWarning ? '#b42318' : '#172033', color: '#fff', padding: '10px 14px', borderRadius: '10px',
      font: '600 12px system-ui', boxShadow: '0 8px 30px rgba(0,0,0,.25)', maxWidth: '82%', textAlign: 'center'
    });
    document.body.appendChild(bar);
    setTimeout(() => bar.remove(), 12000);
  }

  function findFieldByLabel(pattern, selector = 'input,textarea,[contenteditable="true"]') {
    const labels = [...document.querySelectorAll('label,div,span,p')]
      .filter(visible)
      .filter((el) => pattern.test(norm(el.innerText || el.textContent || '')))
      .sort((a, b) => (a.innerText || '').length - (b.innerText || '').length);
    for (const label of labels) {
      const container = label.closest('div[class],form,section') || label.parentElement;
      const field = container?.querySelector(selector);
      if (field && visible(field)) return field;
    }
    return null;
  }

  function shopeeLabelCandidates(pattern) {
    return [...document.querySelectorAll('label,legend,div,span,p')]
      .filter(visible)
      .filter((el) => {
        const value = norm(el.innerText || el.textContent || '').replace(/^\*\s*/, '');
        return pattern.test(value);
      })
      .sort((a, b) => {
        const textDiff = elementText(a).length - elementText(b).length;
        if (textDiff) return textDiff;
        const rectA = a.getBoundingClientRect();
        const rectB = b.getBoundingClientRect();
        return rectA.width * rectA.height - rectB.width * rectB.height;
      });
  }

  function shopeeFieldScope(pattern) {
    for (const label of shopeeLabelCandidates(pattern)) {
      let scope = label.parentElement;
      for (let depth = 0; scope && depth < 5 && scope !== document.body; depth++, scope = scope.parentElement) {
        const rect = scope.getBoundingClientRect();
        if (rect.width >= 180 && rect.height >= 55 && rect.height <= 380) {
          return { label, scope };
        }
      }
    }
    return null;
  }

  function shopeeControlByLabel(pattern, selector) {
    for (const label of shopeeLabelCandidates(pattern)) {
      if (label.htmlFor) {
        const linked = document.getElementById(label.htmlFor);
        if (linked && visible(linked) && linked.matches(selector)) return linked;
      }

      let scope = label.parentElement;
      for (let depth = 0; scope && depth < 6 && scope !== document.body; depth++, scope = scope.parentElement) {
        const candidates = [...scope.querySelectorAll(selector)]
          .filter(visible)
          .filter((el) => el !== label && !el.contains(label))
          .filter((el) => !el.disabled);
        if (!candidates.length) continue;

        const labelRect = label.getBoundingClientRect();
        candidates.sort((a, b) => {
          const score = (el) => {
            const rect = el.getBoundingClientRect();
            const classText = norm(
              typeof el.className === 'string'
                ? el.className
                : el.getAttribute?.('class') || ''
            );
            let value = 0;
            if (rect.top >= labelRect.top - 8) value += 140;
            value -= Math.min(120, Math.abs(rect.top - labelRect.bottom));
            if (el.matches('input,textarea,select,[role="combobox"]')) value += 180;
            if (el.matches('button,[role="button"],[aria-haspopup]')) value += 130;
            if (/(select|picker|trigger|input|textarea)/.test(classText)) value += 100;
            if (rect.width >= 160 && rect.height >= 30 && rect.height <= 90) value += 80;
            if (getComputedStyle(el).cursor === 'pointer') value += 35;
            return value;
          };
          return score(b) - score(a);
        });
        return candidates[0];
      }
    }
    return null;
  }

  function shopeeFieldGeometry(pattern) {
    const label = shopeeLabelCandidates(pattern)[0] || null;
    if (!label) return null;
    const rect = label.getBoundingClientRect();
    if (rect.width < 2 || rect.height < 2) return null;
    return { label, rect };
  }

  function shopeeControlCandidatesByGeometry(labelPattern) {
    const field = shopeeFieldGeometry(labelPattern);
    if (!field) return [];

    const scored = new Map();
    const add = (el, baseScore = 0) => {
      if (!el || !visible(el) || el === document.body || el === document.documentElement) return;
      if (el === field.label || el.contains(field.label) || el.disabled) return;
      const rect = el.getBoundingClientRect();
      if (rect.width < 150 || rect.height < 28 || rect.height > 96) return;
      if (rect.top < field.rect.bottom - 12 || rect.top > field.rect.bottom + 150) return;
      if (rect.right < field.rect.left - 20 || rect.left > field.rect.right + 900) return;
      if (getComputedStyle(el).pointerEvents === 'none') return;

      const classText = norm(
        typeof el.className === 'string'
          ? el.className
          : el.getAttribute?.('class') || ''
      );
      const value = norm([
        elementText(el),
        el.value,
        el.getAttribute?.('placeholder'),
        el.getAttribute?.('aria-label'),
        el.getAttribute?.('title')
      ].filter(Boolean).join(' '));
      let score = baseScore;
      if (value === 'chon gia tri') score += 500;
      else if (value.includes('chon gia tri')) score += 250;
      if (el.matches('[role="combobox"],select')) score += 360;
      if (el.matches('[aria-haspopup="listbox"],[aria-haspopup="menu"]')) score += 300;
      if (el.matches('button,[role="button"],input,[tabindex]')) score += 220;
      if (/(select|picker|trigger|selector|dropdown|input)/.test(classText)) score += 210;
      if (el.querySelector?.('svg,[class*="arrow"],[class*="Arrow"],[class*="chevron"],[class*="Chevron"]')) score += 150;
      if (getComputedStyle(el).cursor === 'pointer') score += 100;
      if (rect.height >= 38 && rect.height <= 72) score += 100;
      if (rect.width >= 300) score += 70;
      score -= Math.min(180, Math.abs(rect.top - field.rect.bottom));
      if (el.matches('span,p')) score -= 220;

      const previous = scored.get(el);
      if (previous === undefined || score > previous) scored.set(el, score);
    };

    const labelled = shopeeControlByLabel(
      labelPattern,
      'select,[role="combobox"],[aria-haspopup],button,[role="button"],input,[tabindex],div,span'
    );
    if (labelled) {
      let current = labelled;
      for (let depth = 0; current && depth < 5 && current !== document.body; depth++, current = current.parentElement) {
        add(current, Math.max(0, 240 - depth * 35));
      }
    }

    const nodes = document.querySelectorAll(
      'select,[role="combobox"],[aria-haspopup],button,[role="button"],input,[tabindex],div,span'
    );
    for (const node of nodes) add(node);

    return [...scored.entries()]
      .sort((a, b) => b[1] - a[1])
      .map(([node]) => node);
  }

  function shopeePlaceholderTriggers() {
    const wanted = 'chon gia tri';
    const scored = new Map();
    const seeds = [...document.querySelectorAll(
      'input,button,[role="button"],[role="combobox"],[aria-haspopup],[tabindex],span,div,p'
    )]
      .filter(visible)
      .filter((el) => {
        const value = norm([
          elementText(el),
          el.value,
          el.getAttribute?.('placeholder'),
          el.getAttribute?.('aria-label')
        ].filter(Boolean).join(' '));
        return value === wanted;
      });

    const add = (node, depth) => {
      if (!node || !visible(node) || node === document.body || node === document.documentElement) return;
      const rect = node.getBoundingClientRect();
      if (rect.width < 150 || rect.height < 28 || rect.height > 96) return;
      if (getComputedStyle(node).pointerEvents === 'none') return;
      const classText = norm(
        typeof node.className === 'string'
          ? node.className
          : node.getAttribute?.('class') || ''
      );
      let score = Math.max(0, 220 - depth * 25);
      if (node.matches('[role="combobox"],select')) score += 330;
      if (node.matches('[aria-haspopup]')) score += 270;
      if (node.matches('button,[role="button"],input,[tabindex]')) score += 190;
      if (/(select|picker|trigger|selector|dropdown|input)/.test(classText)) score += 200;
      if (node.querySelector?.('svg,[class*="arrow"],[class*="Arrow"],[class*="chevron"],[class*="Chevron"]')) score += 150;
      if (getComputedStyle(node).cursor === 'pointer') score += 90;
      if (rect.height >= 38 && rect.height <= 72) score += 90;
      if (rect.width >= 300) score += 60;
      if (node.matches('span,p')) score -= 180;
      const previous = scored.get(node);
      if (previous === undefined || score > previous) scored.set(node, score);
    };

    for (const seed of seeds) {
      let current = seed;
      for (let depth = 0; current && depth < 6 && current !== document.body; depth++, current = current.parentElement) {
        add(current, depth);
      }
    }

    const ranked = [...scored.entries()]
      .sort((a, b) => b[1] - a[1])
      .map(([node]) => node);
    const unique = [];
    for (const node of ranked) {
      const rect = node.getBoundingClientRect();
      const duplicate = unique.some((other) => {
        const otherRect = other.getBoundingClientRect();
        return Math.abs(rect.top - otherRect.top) < 10 &&
          Math.abs(rect.bottom - otherRect.bottom) < 10 &&
          (node.contains(other) || other.contains(node) || Math.abs(rect.left - otherRect.left) < 20);
      });
      if (!duplicate) unique.push(node);
    }
    return unique.sort((a, b) => {
      const rectA = a.getBoundingClientRect();
      const rectB = b.getBoundingClientRect();
      return rectA.top - rectB.top || rectA.left - rectB.left;
    });
  }

  function shopeeOptionCandidates(optionText) {
    const wanted = norm(optionText);
    const scored = new Map();
    const seeds = [...document.querySelectorAll(
      '[role="option"],[role="menuitem"],li,button,a,[role="button"],[tabindex],span,div,p'
    )]
      .filter(visible)
      .filter((el) => !isTooltip(el))
      .filter((el) => norm(elementText(el)) === wanted);

    const add = (node, depth) => {
      if (!node || !visible(node) || node === document.body || node === document.documentElement) return;
      const rect = node.getBoundingClientRect();
      if (
        rect.width < 70 ||
        rect.height < 22 ||
        rect.height > 100 ||
        getComputedStyle(node).pointerEvents === 'none'
      ) return;
      if (norm(elementText(node)) !== wanted) return;
      const classText = norm(
        typeof node.className === 'string'
          ? node.className
          : node.getAttribute?.('class') || ''
      );
      let score = 0;
      if (node.matches('[role="option"],[role="menuitem"],li')) score += 320;
      if (node.closest('[role="listbox"],[role="menu"],[role="dialog"]')) score += 250;
      if (/(option|menu|dropdown|popup|item)/.test(classText)) score += 170;
      if (node.matches('button,[role="button"],[tabindex]')) score += 120;
      if (getComputedStyle(node).cursor === 'pointer') score += 100;
      if (rect.height >= 30 && rect.height <= 64) score += 60;
      if (node.matches('span,p')) score -= 100;
      score += Math.min(depth, 4) * 10;
      const previous = scored.get(node);
      if (previous === undefined || score > previous) scored.set(node, score);
    };

    for (const seed of seeds) {
      let current = seed;
      for (let depth = 0; current && depth < 6 && current !== document.body; depth++, current = current.parentElement) {
        add(current, depth);
      }
    }
    return [...scored.entries()]
      .sort((a, b) => b[1] - a[1])
      .map(([node]) => node);
  }

  function shopeeFirstOptionCandidates(trigger) {
    const triggerRect = trigger?.getBoundingClientRect?.() || null;
    const popupRoots = [...document.querySelectorAll(
      '[role="listbox"],[role="menu"],[data-popper-placement],[class*="dropdown"],[class*="Dropdown"],[class*="popup"],[class*="Popup"],[class*="popover"],[class*="Popover"],[class*="menu"],[class*="Menu"]'
    )]
      .filter(visible)
      .filter((root) => root !== trigger)
      .map((root) => {
        const rect = root.getBoundingClientRect();
        const classText = norm(
          typeof root.className === 'string'
            ? root.className
            : root.getAttribute?.('class') || ''
        );
        let score = 0;
        if (root.matches('.shopee-react-select-option-popover')) score += 900;
        if (root.querySelector('.shopee-react-select-option')) score += 700;
        if (root.matches('[role="listbox"],[role="menu"]')) score += 600;
        if (root.matches('[data-popper-placement]')) score += 450;
        if (/(dropdown|popup|popover|menu)/.test(classText)) score += 260;
        if (root.querySelector('[role="option"],[role="menuitem"],li')) score += 420;
        if (triggerRect) {
          const horizontalOverlap = Math.max(
            0,
            Math.min(rect.right, triggerRect.right) - Math.max(rect.left, triggerRect.left)
          );
          if (horizontalOverlap >= Math.min(rect.width, triggerRect.width) * 0.35) score += 300;
          if (rect.top >= triggerRect.top - 20) score += 180;
          score -= Math.min(260, Math.abs(rect.top - triggerRect.bottom));
        }
        if (rect.width >= 120 && rect.width <= 1200) score += 80;
        if (rect.height >= 24 && rect.height <= 700) score += 80;
        return { root, score };
      })
      .filter(({ score }) => score > 0)
      .sort((a, b) => b.score - a.score);

    const candidates = [];
    const seen = new Set();
    const insideShopeeSelectPopover = (node) => Boolean(node?.closest?.(
      '.shopee-react-select-option-popover,.shopee-react-select-options-list'
    ));
    const addCandidate = (seed, rootRank, semanticBonus = 0) => {
      if (!seed || !visible(seed)) return;
      if (isTooltip(seed) && !insideShopeeSelectPopover(seed)) return;
      const root = popupRoots[rootRank]?.root;
      if (!root || !root.contains(seed)) return;

      const clickable = seed.closest(
        '[role="option"],[role="menuitem"],li,button,a,[role="button"],[tabindex]'
      );
      const node = clickable && root.contains(clickable) ? clickable : seed;
      if (!visible(node) || seen.has(node) || node.disabled) return;

      const value = norm(elementText(node));
      if (!value || value === 'chon gia tri') return;
      if (/^(close|dong|confirm|cancel|huy|tim kiem|search)$/.test(value)) return;

      const rect = node.getBoundingClientRect();
      if (
        rect.width < 60 ||
        rect.height < 20 ||
        rect.height > 110 ||
        getComputedStyle(node).pointerEvents === 'none'
      ) return;
      if (triggerRect && rect.bottom < triggerRect.top - 20) return;

      const classText = norm(
        typeof node.className === 'string'
          ? node.className
          : node.getAttribute?.('class') || ''
      );
      let score = semanticBonus;
      if (node.matches('[role="option"],[role="menuitem"],li')) score += 500;
      if (/(option|item)/.test(classText)) score += 260;
      if (node.matches('button,a,[role="button"],[tabindex]')) score += 160;
      if (getComputedStyle(node).cursor === 'pointer') score += 120;
      if (rect.height >= 28 && rect.height <= 72) score += 90;

      seen.add(node);
      candidates.push({ node, rootRank, score, rect });
    };

    popupRoots.forEach(({ root }, rootRank) => {
      const semantic = [...root.querySelectorAll(
        '[role="option"],[role="menuitem"],li,.shopee-react-select-option'
      )].filter(visible);
      semantic.forEach((node) => addCandidate(node, rootRank, 800));

      if (!semantic.length) {
        const fallback = [...root.querySelectorAll(
          'button,a,[role="button"],[tabindex],div,span,p'
        )]
          .filter(visible)
          .filter((node) => {
            const value = norm(elementText(node));
            if (!value || value === 'chon gia tri') return false;
            const visibleChildren = [...node.children].filter(visible);
            return !visibleChildren.some((child) => norm(elementText(child)) === value);
          });
        fallback.forEach((node) => addCandidate(node, rootRank));
      }
    });

    return candidates
      .sort((a, b) =>
        a.rootRank - b.rootRank ||
        a.rect.top - b.rect.top ||
        a.rect.left - b.rect.left ||
        b.score - a.score
      )
      .map(({ node }) => node);
  }

  function shopeeFieldHasValue(labelPattern, optionText) {
    const scoped = shopeeFieldScope(labelPattern);
    const wanted = norm(optionText);
    if (scoped) {
      const controls = [...scoped.scope.querySelectorAll(
        'select,input,button,[role="button"],[role="combobox"],[aria-haspopup],span,div'
      )]
        .filter(visible)
        .filter((el) => el !== scoped.label && !el.contains(scoped.label))
        .filter((el) => !el.closest?.('[role="listbox"],[role="menu"],.shopee-react-select-option-popover,.shopee-react-select-options-list'));
      if (controls.some((el) => {
        const value = norm([
          elementText(el),
          el.value,
          el.getAttribute?.('aria-label'),
          el.getAttribute?.('title')
        ].filter(Boolean).join(' '));
        return value === wanted;
      })) return true;
    }

    const field = shopeeFieldGeometry(labelPattern);
    if (!field) return false;
    return [...document.querySelectorAll(
      'select,input,button,[role="button"],[role="combobox"],[aria-haspopup],span,div,p'
    )]
      .filter(visible)
      .filter((el) => !el.closest?.('[role="listbox"],[role="menu"],[role="dialog"],.shopee-react-select-option-popover,.shopee-react-select-options-list'))
      .some((el) => {
        const rect = el.getBoundingClientRect();
        if (rect.top < field.rect.bottom - 12 || rect.top > field.rect.bottom + 150) return false;
        if (rect.right < field.rect.left - 20 || rect.left > field.rect.right + 900) return false;
        const value = norm([
          elementText(el),
          el.value,
          el.getAttribute?.('aria-label'),
          el.getAttribute?.('title')
        ].filter(Boolean).join(' '));
        return value === wanted;
      });
  }

  function shopeeFieldHasSelection(labelPattern, expectedText = '') {
    if (expectedText && shopeeFieldHasValue(labelPattern, expectedText)) return true;

    const nativeSelect = shopeeControlByLabel(labelPattern, 'select');
    if (nativeSelect) {
      const selected = nativeSelect.options[nativeSelect.selectedIndex];
      return Boolean(
        selected &&
        !selected.disabled &&
        norm(selected.textContent) &&
        norm(selected.textContent) !== 'chon gia tri' &&
        (!expectedText || norm(selected.textContent) === norm(expectedText))
      );
    }

    if (expectedText) return false;
    const candidates = shopeeControlCandidatesByGeometry(labelPattern);
    if (!candidates.length) return false;
    const primaryRect = candidates[0].getBoundingClientRect();
    const primaryControls = candidates
      .filter((control) => {
        const rect = control.getBoundingClientRect();
        return Math.abs(rect.top - primaryRect.top) <= 12 &&
          Math.abs(rect.bottom - primaryRect.bottom) <= 12;
      })
      .slice(0, 5);
    return primaryControls.some((control) => {
      const value = norm([
        control.value,
        control.getAttribute?.('aria-label'),
        control.getAttribute?.('title'),
        elementText(control)
      ].filter(Boolean).join(' '));
      if (!value || value === 'chon gia tri' || value.includes('chon gia tri')) return false;
      if (value.length > 90 || labelPattern.test(value)) return false;
      return true;
    });
  }

  async function selectShopeeFirstChoice(labelPattern, placeholderIndex = 0, expectedText = '') {
    if (shopeeFieldHasSelection(labelPattern, expectedText)) return true;

    const nativeSelect = shopeeControlByLabel(labelPattern, 'select');
    if (nativeSelect) {
      const option = [...nativeSelect.options].find((item) => {
        const text = norm(item.textContent);
        return !item.disabled && text && text !== 'chon gia tri' && String(item.value || '').trim() && (!expectedText || text === norm(expectedText));
      });
      if (!option) return false;
      setNativeValue(nativeSelect, option.value);
      return shopeeFieldHasSelection(labelPattern, option.textContent || expectedText);
    }

    const triggerFound = await waitFor(() => {
      const byGeometry = shopeeControlCandidatesByGeometry(labelPattern);
      if (byGeometry.length) return true;
      return Boolean(shopeePlaceholderTriggers()[placeholderIndex]);
    }, 8000, 180);
    if (!triggerFound) return false;

    for (let attempt = 0; attempt < 5; attempt++) {
      const byGeometry = shopeeControlCandidatesByGeometry(labelPattern);
      const fallback = shopeePlaceholderTriggers()[placeholderIndex] || null;
      const candidates = [...new Set([...byGeometry, fallback].filter(Boolean))];
      const trigger = candidates[Math.min(attempt, Math.max(0, candidates.length - 1))];
      if (!trigger) break;

      fireClick(trigger, true);
      const options = await waitFor(() => {
        const found = shopeeFirstOptionCandidates(trigger);
        return found.length ? found : null;
      }, 3500, 120);
      if (options) {
        const firstOption = expectedText ? options.find(item => norm(elementText(item)) === norm(expectedText)) : options[0];
        if (!firstOption) { pressOpenKey(trigger, 'Escape'); continue; }
        const selectedText = elementText(firstOption);
        fireClick(firstOption, true);
        if (await waitFor(
          () => shopeeFieldHasSelection(labelPattern, selectedText || expectedText),
          3000,
          120
        )) return true;
      }

      pressOpenKey(trigger, 'ArrowDown');
      await sleep(180);
      pressOpenKey(trigger, 'Enter');
      if (await waitFor(
        () => shopeeFieldHasSelection(labelPattern, expectedText),
        1800,
        120
      )) {
        return true;
      }

      if (!expectedText && options?.[0]) {
        fireClick(options[0], true);
        if (await waitFor(
          () => shopeeFieldHasSelection(labelPattern, elementText(options[0]) || expectedText),
          1800,
          120
        )) return true;
      }
      await sleep(250);
    }
    return shopeeFieldHasSelection(labelPattern, expectedText);
  }

  function shopeeDialog() {
    return [...document.querySelectorAll('[role="dialog"],[aria-modal="true"],div')]
      .filter(visible)
      .filter((el) => {
        const text = norm(el.innerText || el.textContent || '');
        const rect = el.getBoundingClientRect();
        return text.includes('nhap ma don hang') &&
          text.includes('confirm') &&
          rect.width >= 260 &&
          rect.height >= 130;
      })
      .sort((a, b) => {
        const rectA = a.getBoundingClientRect();
        const rectB = b.getBoundingClientRect();
        return rectA.width * rectA.height - rectB.width * rectB.height;
      })[0] || null;
  }

  async function openShopeeOrderDialog() {
    if (shopeeDialog()) return shopeeDialog();
    let link = await waitFor(
      () => shopeeOptionCandidates('Nhập mã đơn hàng')[0] || findVisibleText('Nhập mã đơn hàng', true),
      5000,
      180
    );

    if (!link) {
      const chooseButton = findVisibleText('Chọn đơn hàng', true);
      if (chooseButton) {
        fireClick(chooseButton);
        await sleep(350);
        link = await waitFor(() => findVisibleText('Nhập mã đơn hàng', true), 3500, 160);
      }
    }
    if (!link) return null;
    fireClick(link);
    return waitFor(shopeeDialog, 6000, 150);
  }

  function shopeeInlineOrderInput() {
    const labels = shopeeLabelCandidates(/^ma don hang$/);
    for (const label of labels) {
      const scope = label.closest?.('.form-group,.bb-view-container,[data-page-no]') || label.parentElement;
      if (!scope) continue;
      const input = [...scope.querySelectorAll('input')]
        .filter((el) => visible(el) && !el.disabled && el.type !== 'file')
        .find((el) => el.type === 'text' || !el.type);
      if (input) return input;
    }
    return null;
  }

  async function fillShopeeOrderId(draft) {
    const value = String(draft.representativeOrderId || draft.rows?.[0]?.orderId || '').trim();
    if (!value) return false;

    const inlineInput = await waitFor(shopeeInlineOrderInput, 6000, 150);
    if (inlineInput) {
      setNativeValue(inlineInput, value);
      return Boolean(await waitFor(
        () => String(inlineInput.value || '').trim() === value,
        2500,
        120
      ));
    }

    if (norm(document.body.innerText || document.body.textContent || '').includes(norm(value))) return true;

    const dialog = await openShopeeOrderDialog();
    if (!dialog) return false;
    const input = await waitFor(() => {
      const inputs = [...dialog.querySelectorAll('input')]
        .filter((el) => visible(el) && !el.disabled && el.type !== 'file');
      return inputs.find((el) => /ma don hang|order/.test(norm(textOf(el)))) || inputs[0] || null;
    }, 4000, 120);
    if (!input) return false;
    setNativeValue(input, value);
    await sleep(250);

    const confirm = [...dialog.querySelectorAll('button,[role="button"],span,div')]
      .filter(visible)
      .filter((el) => norm(elementText(el)) === 'confirm')
      .sort((a, b) => {
        const semanticA = a.matches('button,[role="button"]') ? 1 : 0;
        const semanticB = b.matches('button,[role="button"]') ? 1 : 0;
        return semanticB - semanticA || elementText(a).length - elementText(b).length;
      })[0];
    if (!confirm) return false;
    fireClick(confirm);
    const closed = await waitFor(() => !visible(dialog), 5000, 150);
    return Boolean(closed || norm(document.body.innerText || document.body.textContent || '').includes(norm(value)));
  }

  function shopeeEmailInput() {
    return shopeeControlByLabel(/email/, 'input') ||
      [...document.querySelectorAll('input')].filter(visible).find((el) =>
        el.type === 'email' || /email/.test(norm(textOf(el)))
      ) || null;
  }

  function shopeeDescriptionField() {
    const labelled = shopeeControlByLabel(
      /noi dung phan hoi/,
      'textarea,[contenteditable="true"]'
    );
    if (labelled) return labelled;
    const areas = [...document.querySelectorAll('textarea,[contenteditable="true"]')].filter(visible);
    return areas.find((el) => /noi dung phan hoi|thac mac|van de|chi tiet/.test(norm(textOf(el)))) ||
      areas[areas.length - 1] || null;
  }

  function shopeeControlValue(control) {
    if (!control) return '';
    return String(control.isContentEditable ? control.textContent : control.value || '')
      .replace(/\r\n/g, '\n')
      .trim();
  }

  function shopeeConsentCheckbox(strict = false) {
    const boxes = [...document.querySelectorAll('input[type="checkbox"]')]
      .filter((el) => !el.disabled);
    return boxes.find((box) => {
      const label = box.closest?.('label');
      const text = norm([
        box.value,
        box.getAttribute?.('aria-label'),
        label?.innerText,
        label?.textContent
      ].filter(Boolean).join(' '));
      return text.includes('toi dong y');
    }) || (!strict ? boxes[boxes.length - 1] : null) || null;
  }

  function shopeeSubmitButton() {
    return [...document.querySelectorAll('button,[role="button"],input[type="submit"]')]
      .filter(visible)
      .filter((el) => !el.disabled && norm(el.getAttribute?.('aria-disabled')) !== 'true')
      .filter((el) => /^(gui|submit)$/.test(norm(elementText(el))))
      .sort((a, b) => {
        const semanticA = a.matches('button,input[type="submit"]') ? 1 : 0;
        const semanticB = b.matches('button,input[type="submit"]') ? 1 : 0;
        return semanticB - semanticA || elementText(a).length - elementText(b).length;
      })[0] || null;
  }

  function shopeeSubmissionSucceeded(startUrl, clickedAt) {
    if (location.href !== startUrl) return true;
    const text = norm(document.body.innerText || document.body.textContent || '');
    if (/(gui thanh cong|da gui thanh cong|yeu cau cua ban da duoc gui|cam on ban|thank you)/.test(text)) {
      return true;
    }
    return Date.now() - clickedAt >= 2000 && !shopeeSubmitButton();
  }

  function shopeeReadyForSubmit(result) {
    if (result.pickupForm) return shopeePickupReady(result); // v2.2.4 form lấy hàng
    const inlineOrder = shopeeInlineOrderInput();
    const email = shopeeEmailInput();
    const description = shopeeDescriptionField();
    const expectedUploads = Number(result.uploadCount || 0);
    const uploadCount = shopeeUploadedCount();
    const uploadsReady = expectedUploads > 0 && !shopeeUploadError() && !shopeeUploadInProgress() && (
      uploadCount !== null
        ? uploadCount >= expectedUploads
        : result.uploadResult?.ok === true
    );
    return Boolean(
      shopeeFieldHasSelection(/ban can ho tro voi vai tro la nguoi ban hay nguoi mua/, 'Người bán') &&
      shopeeFieldHasSelection(/ban thac mac ve van de nao/, result.issueText || OPShopeeForm.ISSUE) &&
      (inlineOrder ? shopeeControlValue(inlineOrder) === result.orderValue : !result.orderRequired) &&
      email && shopeeControlValue(email) === result.emailValue &&
      description && result.descriptionText.length <= OPShopeeForm.MAX_TEXT && shopeeControlValue(description) === result.descriptionText &&
      uploadsReady
    );
  }

  async function armShopeeSubmit(result) {
    if (!result?.ok || window.__OP_SHOPEE_SUBMIT_ARMED__) return;
    window.__OP_SHOPEE_SUBMIT_ARMED__ = true;
    const startedAt = Date.now();

    while (Date.now() - startedAt < 10 * 60 * 1000) {
      const consent = result.pickupForm ? (shopeeConsentCheckbox(true) || { checked: true }) : shopeeConsentCheckbox(Boolean(result.handover || result.cancelReturn)); // form lấy hàng không có ô Tôi đồng ý
      if (result.autoSubmit && consent && !consent.checked && shopeeReadyForSubmit(result)) fireClick(consent, true);
      if (!consent?.checked) {
        await sleep(250);
        continue;
      }

      if (!shopeeReadyForSubmit(result)) {
        showBanner('Đã tick đồng ý nhưng form/file chưa sẵn sàng; tool đang chờ hoàn tất.', true);
        await sleep(600);
        continue;
      }

      let submit = shopeeSubmitButton();
      if (!submit) {
        showBanner('Không tìm thấy nút Gửi đang hoạt động.', true);
        return;
      }

      await sleep(650);
      submit = shopeeSubmitButton();
      if (!submit || !consent.checked || !shopeeReadyForSubmit(result)) continue;

      const context = await runtimeMessage({ type: 'GET_TICKET_TAB_PAYLOAD' });
      if (!context?.draft || context.submissionSaved || context.ticketCapture?.startedAt) {
        showBanner('Đơn đã bắt đầu gửi; đang chờ Shopee trả mã phiếu.'); return;
      }
      if (result.handover) {
        const shop = await runtimeMessage({ type: 'CHECK_HANDOVER_SHOP' });
        if (!shop?.ok) { showBanner(shop?.error || 'Chưa nhận được đúng shop Shopee.', true); return; }
      }
      shopeeCapture = { orderId: result.orderValue, startedAt: Date.now(), baselineIds: [] };
      const persisted = await runtimeMessage({ type: 'TICKET_SUBMIT_STARTED', capture: shopeeCapture });
      if (!persisted?.ok) { showBanner('Chưa lưu được trạng thái gửi; hãy thử lại.', true); return; }
      window.postMessage({ source: 'op-shopee-probe-arm', json: JSON.stringify(shopeeCapture) }, location.origin);
      // Fields and evidence may change during the background round trip.
      if (!consent.checked || !shopeeReadyForSubmit(result)) {
        await runtimeMessage({ type: 'TICKET_SUBMIT_STARTED', capture: { ...shopeeCapture, startedAt: 0 } }); shopeeCapture = null; continue;
      }
      window.__OP_SHOPEE_SUBMIT_CLICKED__ = true;
      const startUrl = location.href;
      const clickedAt = Date.now();
      fireClick(submit, true);
      showBanner('Đã bấm Gửi đúng 1 lần; đang chờ Shopee xác nhận.');

      const submitted = await waitFor(
        () => shopeeSubmissionSucceeded(startUrl, clickedAt),
        25000,
        250
      );
      const finalStatus = { ...result, submitClicked: true, submitted: Boolean(submitted) };
      await runtimeMessage({ type: 'TICKET_AUTOFILL_STATUS', autofill: finalStatus }).catch(() => null);
      if (submitted) {
        showBanner('✓ Shopee đã nhận thao tác Gửi.');
      } else {
        showBanner('Đã bấm Gửi nhưng Shopee chưa chuyển trang; kiểm tra lỗi đỏ hoặc CAPTCHA trên form.', true);
      }
      return;
    }
  }

  async function fillShopeeForm(draft, attachments) {
    const handover = draft.issueType === 'handover_unscanned';
    // v2.2.67 — Đòi hàng Shopee (hàng đợi tuần tự): tự tick đồng ý + tự Gửi như kháng nghị.
    // v2.2.68 — vấn đề "Vận chuyển" (draft.shopeeIssue) → Mã đơn hàng bắt buộc, điền mã đơn đại diện như kháng nghị bàn giao.
    const cancelReturn = draft.issueType === 'cancel_return';
    if (handover) {
      const shop = await runtimeMessage({ type: 'CHECK_HANDOVER_SHOP' });
      if (!shop?.ok) return { ok: false, reason: 'shop-not-ready', details: shop?.error || 'Mở đúng shop Shopee.' };
    }
    // Some form revisions show a seller entry card before the role dropdown.
    if (!shopeeLabelCandidates(/ban can ho tro voi vai tro la nguoi ban hay nguoi mua/).length) {
      const entry = shopeeOptionCandidates('Người bán')[0] || shopeeOptionCandidates('Tôi là Người bán')[0];
      if (entry) { fireClick(entry, true); await sleep(500); }
    }
    const sellerOk = await selectShopeeFirstChoice(
      /ban can ho tro voi vai tro la nguoi ban hay nguoi mua/,
      0,
      'Người bán'
    );
    if (!sellerOk) { showBanner('Chưa chọn được vai trò Người bán; tool chưa gửi.', true); return { ok: false, roleOk: false, reason: 'seller-not-selected' }; }
    await sleep(500);

    const issueText = handover || cancelReturn ? (draft.shopeeIssue || 'Vận chuyển') : OPShopeeForm.ISSUE;
    const issueOk = await selectShopeeFirstChoice(
      /ban thac mac ve van de nao/,
      0,
      issueText
    );
    if (!issueOk) { showBanner(`Chưa chọn được ${issueText}; tool chưa gửi.`, true); return { ok: false, roleOk: true, issueOk: false, reason: 'issue-not-selected' }; }
    await sleep(600);

    const orderRequired = issueText !== OPShopeeForm.ISSUE;
    const hasOrderControl = Boolean(shopeeInlineOrderInput() || findVisibleText('Chọn đơn hàng', true) || findVisibleText('Nhập mã đơn hàng', true));
    const orderOk = orderRequired || hasOrderControl ? await fillShopeeOrderId(draft) : true;
    await sleep(500);

    const email = await waitFor(shopeeEmailInput, 7000);
    const shopeeEmail = String(draft.shopeeEmail || 'operation@onpoint.vn').trim();
    if (email) setNativeValue(email, shopeeEmail);
    const emailOk = Boolean(email && await waitFor(
      () => shopeeControlValue(email) === shopeeEmail,
      2500,
      120
    ));

    const description = await waitFor(shopeeDescriptionField, 7000);
    const declaredLimit = Number(description?.maxLength || description?.getAttribute?.('maxlength'));
    const descriptionText = OPShopeeForm.description(draft.text, draft.representativeOrderId || draft.rows?.[0]?.orderId, declaredLimit > 0 ? declaredLimit : OPShopeeForm.MAX_TEXT);
    if (description) setNativeValue(description, descriptionText);
    const descriptionOk = Boolean(description && descriptionText && await waitFor(
      () => shopeeControlValue(description) === descriptionText,
      2500,
      120
    ));

    const uploadResult = ticketContext?.attachmentTransport === 'background-page'
      ? await uploadShopeeHandoverAttachments(attachments || [])
      : await uploadAttachments((attachments || []).slice(0, 5));
    const result = {
      ok: Boolean(sellerOk && issueOk && orderOk && emailOk && descriptionOk && uploadResult.ok),
      handover, cancelReturn, autoSubmit: handover || cancelReturn || draft.mode === 'claim', orderRequired, uploadResult,
      reason: !uploadResult.ok ? 'attachments-not-ready' : '',
      details: !uploadResult.ok ? `Chưa đủ biên bản: ${uploadResult.error || 'file chưa tải lên xong'}. Tool chưa gửi; bấm Thử lại đính kèm.` : '',
      roleOk: sellerOk,
      issueOk,
      orderOk,
      emailOk,
      descriptionOk,
      uploadOk: uploadResult.ok,
      uploadCount: uploadResult.count,
      issueText,
      orderValue: String(draft.representativeOrderId || draft.rows?.[0]?.orderId || '').trim(),
      emailValue: shopeeEmail,
      descriptionText
    };
    showBanner(
      [
        sellerOk ? 'đã chọn Người bán' : 'chưa chọn được Người bán',
        issueOk ? `đã chọn ${issueText}` : `chưa chọn được ${issueText}`,
        orderOk ? (hasOrderControl || orderRequired ? 'đã điền Mã đơn hàng' : 'mã đơn đại diện nằm trong nội dung/file') : 'chưa nhập được mã đơn',
        result.emailOk ? 'đã điền Email' : 'chưa điền Email',
        result.descriptionOk ? `đã điền đủ nội dung (${descriptionText.length} ký tự)` : 'nội dung bị thiếu hoặc bị cắt',
        uploadResult.ok ? `đã đính kèm ${uploadResult.count}/5 file` : 'chưa đính kèm file',
        result.ok ? (result.autoSubmit ? 'tool tự gửi và lưu ticket' : 'tick Tôi đồng ý để tool tự bấm Gửi') : 'tool chưa thể gửi'
      ].join(' · '),
      !result.ok
    );
    if (result.ok) {
      armShopeeSubmit(result).catch((error) => {
        showBanner(`Luồng Gửi Shopee lỗi: ${error.message || error}`, true);
      });
    }
    return result;
  }

  /* v2.2.4 — webform Shopee "[Người bán] Khiếu nại cập nhật sai trạng thái lấy hàng" / "[Người bán] Yêu cầu hối lấy hàng"
     (lib/op-shopee-pickup.js). Form chỉ có: Vấn đề cần hỗ trợ · Mã đơn hàng (1 đơn đại diện) · Danh sách đơn hàng (.xlsx)
     · Mô tả thêm (chỉ form khiếu nại) · Gửi — không có vai trò, email, nội dung 999 ký tự. */
  const PICKUP_ISSUE_LABEL = /^van de can ho tro$/;
  const PICKUP_NOTE_LABEL = /^mo ta them van de can ho tro/;
  const shopeeLoginGate = () => /dang nhap de tiep tuc/.test(norm(document.body.innerText || document.body.textContent || ''));
  function shopeePickupNoteField() {
    return shopeeControlByLabel(PICKUP_NOTE_LABEL, 'input:not([type="file"]),textarea,[contenteditable="true"]');
  }
  function shopeePickupOrderOk(value) {
    if (!value) return false;
    const input = shopeeInlineOrderInput();
    return input ? shopeeControlValue(input) === value : norm(document.body.innerText || document.body.textContent || '').includes(norm(value));
  }
  // "Nhập mã đơn hàng" dialog bản tiếng Việt (nút Xác nhận) — fillShopeeOrderId chỉ nhận dialog có nút Confirm.
  async function fillShopeePickupOrderDialog(value) {
    if (shopeePickupOrderOk(value)) return true;
    const dialogOf = () => [...document.querySelectorAll('[role="dialog"],[aria-modal="true"],[class*="modal"],[class*="Modal"],[class*="dialog"]')]
      .filter(visible).filter(el => [...el.querySelectorAll('input')].some(i => visible(i) && !i.disabled && i.type !== 'file'))
      .sort((a, b) => { const ra = a.getBoundingClientRect(), rb = b.getBoundingClientRect(); return ra.width * ra.height - rb.width * rb.height; })[0] || null;
    let dialog = dialogOf();
    if (!dialog) {
      const link = findVisibleText('Nhập mã đơn hàng', true) || shopeeOptionCandidates('Nhập mã đơn hàng')[0];
      if (!link) return false;
      fireClick(link); dialog = await waitFor(dialogOf, 5000, 150);
    }
    if (!dialog) return false;
    const input = [...dialog.querySelectorAll('input')].find(i => visible(i) && !i.disabled && i.type !== 'file');
    if (!input) return false;
    setNativeValue(input, value); await sleep(250);
    const confirm = [...dialog.querySelectorAll('button,[role="button"]')].filter(visible)
      .find(el => /^(xac nhan|confirm|ok|dong y|ap dung|luu)$/.test(norm(elementText(el))) && !el.disabled);
    if (!confirm) return false;
    fireClick(confirm);
    return Boolean(await waitFor(() => !visible(dialog) && shopeePickupOrderOk(value), 5000, 150));
  }
  function shopeePickupReady(result) {
    const expected = Number(result.uploadCount || 0), count = shopeeUploadedCount();
    const uploadsReady = !expected || (!shopeeUploadError() && !shopeeUploadInProgress() && (count !== null ? count >= expected : result.uploadResult?.ok === true));
    const noteField = result.noteText ? shopeePickupNoteField() : null;
    return Boolean(
      !shopeeLoginGate() &&
      shopeeFieldHasSelection(PICKUP_ISSUE_LABEL, result.issueText) &&
      shopeePickupOrderOk(result.orderValue) &&
      (!result.noteText || (noteField && shopeeControlValue(noteField) === result.noteText)) &&
      uploadsReady
    );
  }
  async function fillShopeePickupForm(draft, attachments) {
    const pick = OPShopeePickup.ofDraft(draft);
    if (!pick) return { ok: false, reason: 'pickup-form-unknown' };
    const page = OPShopeePickup.onPage(location.href);
    if (page && page.id !== pick.form.id) { showBanner(`Tab đang mở form khác "${page.title}"; tool chưa điền.`, true); return { ok: false, reason: 'wrong-form' }; }
    if (shopeeLoginGate()) {
      showBanner(`Đăng nhập Shopee bằng tài khoản shop ngay trên trang này — tool tự điền "${pick.form.title}" và tự gửi sau khi đăng nhập.`, true);
      if (!await waitFor(() => !shopeeLoginGate(), 10 * 60 * 1000, 1000)) return { ok: false, reason: 'login-required' };
      await sleep(1200);
    }
    const issueText = pick.option;
    const issueOk = await selectShopeeFirstChoice(PICKUP_ISSUE_LABEL, 0, issueText);
    if (!issueOk) { showBanner(`Chưa chọn được "${issueText}"; tool chưa gửi.`, true); return { ok: false, issueOk: false, reason: 'issue-not-selected', issueText }; }
    await sleep(500);

    const orderValue = String(draft.representativeOrderId || draft.rows?.[0]?.orderId || '').trim().toUpperCase().slice(0, OPShopeePickup.ORDER_MAX);
    const orderOk = Boolean(orderValue) && (await fillShopeeOrderId({ ...draft, representativeOrderId: orderValue }) && shopeePickupOrderOk(orderValue) || await fillShopeePickupOrderDialog(orderValue));
    await sleep(400);

    let noteText = '', noteOk = true;
    if (pick.form.note && String(draft.text || '').trim()) {
      const field = await waitFor(shopeePickupNoteField, 3000, 150);
      if (field) {
        const limit = Number(field.maxLength > 0 ? field.maxLength : field.getAttribute?.('maxlength')) || OPShopeePickup.NOTE_MAX;
        noteText = String(draft.text).replace(/\s+/g, ' ').trim().slice(0, Math.min(limit, OPShopeePickup.NOTE_MAX)).replace(/[\uD800-\uDBFF]$/, '').trimEnd();
        setNativeValue(field, noteText);
        noteOk = Boolean(await waitFor(() => shopeeControlValue(field) === noteText, 2500, 120));
      }
    }

    const sheets = (attachments || []).filter(OPShopeePickup.isSheet).slice(0, OPShopeePickup.MAX_FILES);
    const needsFile = (draft.rows || []).length > 1;
    const uploadResult = sheets.length ? await uploadAttachments(sheets) : { ok: !needsFile, count: 0, error: needsFile ? 'thiếu file Danh sách đơn hàng (.xlsx)' : '' };
    const result = {
      ok: Boolean(issueOk && orderOk && noteOk && uploadResult.ok),
      pickupForm: pick.form.id, autoSubmit: true, orderRequired: true, uploadResult,
      reason: !orderOk ? 'order-not-filled' : !uploadResult.ok ? 'attachments-not-ready' : !noteOk ? 'note-not-filled' : '',
      details: !uploadResult.ok ? `Danh sách đơn hàng: ${uploadResult.error || 'file chưa tải lên xong'}. Tool chưa gửi.` : '',
      issueOk, orderOk, noteOk, uploadOk: uploadResult.ok, uploadCount: uploadResult.count,
      issueText, orderValue, noteText
    };
    showBanner([
      `${pick.form.title}`,
      `đã chọn "${issueText}"`,
      orderOk ? `đã điền Mã đơn hàng ${orderValue}` : 'chưa nhập được Mã đơn hàng',
      pick.form.note ? (noteText ? (noteOk ? 'đã điền Mô tả thêm' : 'chưa điền được Mô tả thêm') : 'bỏ trống Mô tả thêm') : '',
      uploadResult.ok ? (uploadResult.count ? `đã tải Danh sách đơn hàng (${uploadResult.count} file, ${(draft.rows || []).length} đơn)` : 'không cần file') : 'chưa tải được Danh sách đơn hàng',
      result.ok ? 'tool tự bấm Gửi và lưu mã phiếu' : 'tool chưa thể gửi'
    ].filter(Boolean).join(' · '), !result.ok);
    if (result.ok) armShopeeSubmit(result).catch(error => showBanner(`Luồng Gửi Shopee lỗi: ${error.message || error}`, true));
    return result;
  }

  async function uploadShopeeHandoverAttachments(items) {
    if (!items.length || items.length > 5) return { ok: false, count: 0, error: 'Cần 1–5 file bằng chứng.' };
    if ((shopeeNativeUploadState()?.total || shopeeUploadedCount()) > 0) return { ok: false, count: shopeeUploadedCount(), error: 'Form đã có file; tải lại form trước khi thử lại để tránh đính kèm trùng.' };
    for (let index = 0; index < items.length; index++) {
      const dispatched = await runtimeMessage({ type: 'UPLOAD_SHOPEE_ATTACHMENT_FILES', indices: [items[index].index ?? index] }).catch(error => ({ ok: false, error: error.message }));
      if (!dispatched?.ok) return { ok: false, count: index, error: `${items[index].name}: ${dispatched?.error || 'chưa đính kèm được'}` };
      await sleep(700);
      const completed = await waitFor(() => {
        const error = shopeeUploadError();
        if (error) return { error };
        const count = shopeeUploadedCount();
        return count !== null && count >= index + 1 && !shopeeUploadInProgress() ? { count } : null;
      }, 60000, 250);
      if (!completed || completed.error) return { ok: false, count: index, error: `${items[index].name}: ${completed?.error || 'chưa thấy tải lên thành công trên form'}` };
    }
    await sleep(750);
    const ok = shopeeUploadedCount() >= items.length && !shopeeUploadError() && !shopeeUploadInProgress();
    return { ok, count: ok ? items.length : 0, error: ok ? '' : 'Tệp đang tải hoặc Shopee báo lỗi.' };
  }

  /* v2.2.4 — danh sách phiếu Shopee đã gửi để theo dõi ở seller-service.cs.shopee.vn (Yêu cầu của tôi). */
  async function rememberShopeeFollow(draft, ticketId = '', submissionId = '') {
    try {
      const pick = globalThis.OPShopeePickup?.ofDraft(draft);
      const item = {
        ticketId: String(ticketId || ''), submissionId: String(submissionId || ''),
        form: pick ? pick.form.title : draft?.mode === 'claim' ? `Khiếu nại ${draft.claim?.metric || ''}`.trim() : draft?.issueType === 'handover_unscanned' ? 'Kháng nghị bàn giao (Vận chuyển)' : draft?.issueType === 'cancel_return' ? `Đòi hàng (đơn hủy đã bàn giao)${draft.carrier ? ` · ${draft.carrier}` : ''}` : 'Câu hỏi chung/ Vấn đề khác',
        option: pick?.option || '', orderId: String(draft?.representativeOrderId || draft?.rows?.[0]?.orderId || ''), orders: (draft?.rows || []).length,
        channel: String(draft?.channel || ''), at: new Date().toISOString()
      };
      const { shopeeFollowTickets = [] } = await chrome.storage.local.get('shopeeFollowTickets');
      const rest = (Array.isArray(shopeeFollowTickets) ? shopeeFollowTickets : []).filter(x => !(item.submissionId && x.submissionId === item.submissionId) && !(item.ticketId && x.ticketId === item.ticketId));
      await chrome.storage.local.set({ shopeeFollowTickets: [item, ...rest].slice(0, 300) });
    } catch (_) {}
  }

  function watchShopeeTicket(context) {
    shopeeCapture = context.ticketCapture || null;
    let saving = Promise.resolve();
    const saved = new Set();
    function arm() {
      if (!shopeeCapture?.startedAt) return;
      window.postMessage({ source: 'op-shopee-probe-arm', json: JSON.stringify({ ...shopeeCapture, ...(context.submission ? { lookup: context.submission } : {}) }) }, location.origin);
      window.postMessage({ source: 'op-shopee-probe-ask' }, location.origin);
    }
    async function save(record) {
      if (!shopeeCapture?.startedAt || record.orderId !== shopeeCapture.orderId || record.startedAt < shopeeCapture.startedAt || !record.confirmed) return;
      const submissionId = OPShopeeCapture.identifier(record.submissionId);
      const ticketId = OPShopeeCapture.identifier(record.ticketId);
      if (!submissionId || !ticketId && context.draft?.issueType !== 'handover_unscanned') return;
      const key = `${submissionId}:${ticketId}`;
      if (saved.has(key)) return;
      const result = await runtimeMessage({ type: 'SHOPEE_SUBMISSION_CONFIRMED', orderId: record.orderId, submission: { submissionId, ticketId, csUserId: OPShopeeCapture.identifier(record.csUserId), submitUrl: record.submitUrl, startedAt: record.startedAt } }).catch(() => null);
      if (result?.ok) {
        saved.add(key);
        rememberShopeeFollow(context.draft, ticketId, submissionId); // v2.2.4 theo dõi phiếu
        showBanner(ticketId ? `✓ Đã tự lưu Ticket ${ticketId} cho đơn ${record.orderId}.` : `✓ Đã tự lưu đơn ${record.orderId} đã gửi · đang chờ Shopee cấp mã phiếu.`);
      } else showBanner(result?.error || 'Shopee đã nhận đơn, tool đang thử lưu lại.', true);
    }
    window.addEventListener('message', event => {
      if (event.source !== window || event.origin !== location.origin || event.data?.source !== 'op-shopee-probe') return;
      try {
        const records = JSON.parse(event.data.json)?.records || [];
        saving = saving.catch(() => {}).then(async () => { for (const record of records) await save(record); });
      } catch (_) {}
    });
    async function scan() {
      if (!shopeeCapture?.startedAt) return;
      // A labeled ID on a confirmation page is a second route to the real case ID.
      const text = document.body.innerText || '';
      if (shopeeSubmitButton() || !/(gui thanh cong|yeu cau cua ban da duoc gui|cam on ban|thank you)/.test(norm(text))) return;
      const ids = [...new Set([...text.matchAll(/(?:mã\s*(?:phiếu|yêu cầu|hỗ trợ|ticket|case)|(?:ticket|case)\s*(?:id|number|no\.?))\s*[:#]\s*([A-Z0-9][A-Z0-9_-]{4,79})/ig)].map(match => match[1]))].filter(id => !(shopeeCapture.baselineIds || []).includes(id));
      if (ids.length !== 1 || saved.has(`dom:${ids[0]}`)) return;
      const result = await runtimeMessage({ type: 'TICKET_ID_DETECTED_FROM_TAB', ticketId: ids[0], orderId: shopeeCapture.orderId }).catch(() => null);
      if (result?.ok) { saved.add(`dom:${ids[0]}`); rememberShopeeFollow(context.draft, ids[0]); showBanner(`✓ Đã tự lưu Ticket ${ids[0]}.`); }
    }
    setInterval(() => { arm(); scan().catch(() => {}); }, 1500);
    arm();
  }

  function watchTicketId(tabScoped) {
    let lastText = '';
    let lastTicketId = '';
    const scan = async () => {
      const txt = document.body.innerText || '';
      if (txt === lastText) return;
      lastText = txt;
      const matches = [...txt.matchAll(/(?:ticket|case|phieu)\s*(?:id|number|no\.?|ma)?\s*[:#]?\s*([A-Z]{0,8}[-_]?[A-Z0-9]{6,})/ig)];
      if (!matches.length) return;
      const ticketId = matches[matches.length - 1][1];
      if (!ticketId || ticketId === lastTicketId) return;
      lastTicketId = ticketId;

      if (!tabScoped) {
        chrome.storage.local.set({ detectedTicketId: ticketId });
        showBanner(`Phát hiện mã ticket ${ticketId}. Mở extension để lưu mapping.`);
        return;
      }

      try {
        const result = await runtimeMessage({
          type: 'TICKET_ID_DETECTED_FROM_TAB',
          ticketId
        });
        if (result?.autoMapped) {
          showBanner(`✓ Ticket ${ticketId} đã tự map ${result.mappedCount} đơn. Nhóm trong extension đã chuyển xanh.`);
        } else {
          showBanner(`Phát hiện mã ticket ${ticketId}, nhưng chưa tự map được.`, true);
        }
      } catch (error) {
        showBanner(`Đã thấy Ticket ${ticketId} nhưng auto-map lỗi: ${error.message || error}`, true);
      }
    };
    new MutationObserver(() => { scan().catch(() => {}); }).observe(
      document.documentElement,
      { childList: true, subtree: true, characterData: true }
    );
    scan().catch(() => {});
  }

  (async () => {
    await sleep(1800);
    try {
      const context = await runtimeMessage({ type: 'GET_TICKET_TAB_PAYLOAD' });
      ticketContext = context;
      if (context?.ok && context.savedTicket) { showBanner(`✓ Đơn này đã lưu Ticket ${context.savedTicket.ticketId}.`); return; }
      if (!context?.ok || !context.draft) {
        throw new Error(context?.error || 'Không lấy được dữ liệu riêng của tab.');
      }
      ticketContext = context;
      const scopedShopee = location.hostname === 'help.shopee.vn' && context.tabScoped;
      if (scopedShopee) watchShopeeTicket(context); else watchTicketId(Boolean(context.tabScoped));
      if (scopedShopee && (context.submissionSaved || context.ticketCapture?.startedAt)) {
        showBanner(context.submissionSaved ? 'Đã tự lưu yêu cầu gửi · đang chờ Shopee cấp mã phiếu.' : 'Đơn đã bắt đầu gửi · đang chờ Shopee xác nhận, không gửi lại.'); return;
      }
      const isShopee = location.hostname === 'help.shopee.vn';
      if (isShopee && !/\/portal\/webform\//.test(location.pathname)) return;
      if (!isShopee && !/\/ticket\/create(?:\/|$)/i.test(location.pathname)) return;
      const autofill = isShopee
        ? (globalThis.OPShopeePickup?.ofDraft(context.draft) ? await fillShopeePickupForm(context.draft, context.attachments) : await fillShopeeForm(context.draft, context.attachments))
        : await fillDraft(context.draft, context.attachments);
      await runtimeMessage({
        type: 'TICKET_AUTOFILL_STATUS',
        autofill
      }).catch(() => null);
    } catch (error) {
      console.error('[OnPoint TTS autofill]', error);
      showBanner(`Auto-fill lỗi: ${error.message || error}`, true);
      if (!ticketContext?.tabScoped) watchTicketId(false);
    }
  })();
})();
