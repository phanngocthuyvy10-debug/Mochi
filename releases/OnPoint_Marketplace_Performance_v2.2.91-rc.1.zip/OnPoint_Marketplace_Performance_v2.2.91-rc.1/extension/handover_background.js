/* Durable, sequential queue: advance only after the current order is mapped. */
const HANDOVER_NEXT_ALARM = 'op-handover-next';

const SHOPEE_SELLER_URL = 'https://banhang.shopee.vn/';
const SHOPEE_SELLER_ORIGINS = [SHOPEE_SELLER_URL, 'https://seller.shopee.vn/'];
const isShopeeSellerTab = tab => [tab?.url, tab?.pendingUrl].some(url => SHOPEE_SELLER_ORIGINS.some(origin => String(url || '').startsWith(origin)));
let shopeeSellerOpening = null;
let rememberedShopeeTabId = null;

async function findShopeeSellerTabs() {
  const results = await Promise.all(SHOPEE_SELLER_ORIGINS.map(origin => chrome.tabs.query({ url: `${origin}*`, currentWindow: true })));
  return [...new Map(results.flat().filter(isShopeeSellerTab).map(tab => [tab.id, tab])).values()];
}

async function openShopeeSellerTab(windowId) {
  if (shopeeSellerOpening) return shopeeSellerOpening;
  shopeeSellerOpening = (async () => {
    // Check again inside the shared promise: simultaneous panel refreshes open one tab.
    if (rememberedShopeeTabId) {
      try { const tab = await chrome.tabs.get(rememberedShopeeTabId); if (isShopeeSellerTab(tab) && (!Number.isInteger(windowId) || tab.windowId === windowId)) return tab; } catch (_) {}
    }
    const candidates = await findShopeeSellerTabs();
    if (candidates.length > 1) throw new Error('Có nhiều tab shop Shopee. Chọn tab đúng shop để tool nhận tên.');
    const tab = candidates[0] || await chrome.tabs.create({ url: SHOPEE_SELLER_URL, active: true, ...(Number.isInteger(windowId) ? { windowId } : {}) });
    if (!tab?.id) throw new Error('Chrome chưa mở được Kênh Người Bán Shopee.');
    rememberedShopeeTabId = tab.id;
    await chrome.storage.local.set({ shopeeSellerSourceTabId: tab.id });
    return tab;
  })().finally(() => { shopeeSellerOpening = null; });
  return shopeeSellerOpening;
}

/* v2.2.57 — đọc tên shop có giới hạn 10 giây: hàm này hay được gọi TRONG khóa hàng đợi; tab TikTok không phản hồi
   (tab nền bị Chrome tạm ngưng…) từng làm khóa bị giữ mãi → cả hàng đợi raise đứng im. */
function getLoggedInMarketplaceShop(platform = 'tiktok', preferredTabId = null, options = {}) {
  // Giới hạn thời gian chỉ áp dụng trong service worker thật (môi trường test giả lập setTimeout chạy ngay).
  if (typeof ServiceWorkerGlobalScope === 'undefined') return getLoggedInMarketplaceShopRaw(platform, preferredTabId, options);
  const timeoutMs = platform === 'shopee' && options.ensureOpen ? 30000 : 10000;
  let timer;
  return Promise.race([
    getLoggedInMarketplaceShopRaw(platform, preferredTabId, options),
    new Promise(resolve => { timer = setTimeout(() => resolve({ ok: false, error: `Tab ${platform === 'shopee' ? 'Shopee' : 'TikTok'} không phản hồi khi đọc tên shop (quá ${timeoutMs / 1000} giây). Bấm vào tab đó cho hiện lên rồi bấm Tiếp tục.` }), timeoutMs); })
  ]).finally(() => { try { clearTimeout(timer); } catch (_) {} });
}
async function getLoggedInMarketplaceShopRaw(platform = 'tiktok', preferredTabId = null, { ensureOpen = false } = {}) {
  const shopee = platform === 'shopee';
  const origin = 'https://seller-vn.tiktok.com/';
  const label = shopee ? 'Shopee Kênh Người Bán' : 'TikTok Shop';
  const isSeller = shopee ? isShopeeSellerTab : tab => (tab?.url || '').startsWith(origin);
  const active = await chrome.tabs.query({ active: true, currentWindow: true });
  let tab = active.find(isSeller);
  if (!tab && preferredTabId) {
    try { const candidate = await chrome.tabs.get(Number(preferredTabId)); if (isSeller(candidate)) tab = candidate; } catch (_) {}
  }
  if (shopee && !tab) {
    const saved = await chrome.storage.local.get('shopeeSellerSourceTabId');
    const sourceId = rememberedShopeeTabId || saved.shopeeSellerSourceTabId;
    if (sourceId) {
      try {
        const candidate = await chrome.tabs.get(Number(sourceId));
        const sameWindow = active[0]?.windowId == null || candidate.windowId === active[0].windowId;
        if (sameWindow && isSeller(candidate)) tab = candidate;
        else if (sameWindow && /^https:\/\/(?:[^/]+\.)?shopee\.vn\/(?:.*\/)?(?:login|signin|sign-in|account)(?:[/?]|$)/i.test(candidate.url || '')) {
          return { ok: false, pending: true, tabId: candidate.id, error: 'Đã mở Kênh Người Bán Shopee. Đăng nhập rồi tool sẽ tự nhận tên shop.' };
        }
      } catch (_) {}
    }
  }
  // v2.2.84 — TikTok: nhiều tab seller-vn (Nhật ký phiếu, tab raise, tab phụ fast mode…) và tab trước mặt không phải TikTok
  // → trước đây báo lỗi "Mở đúng tab". Mọi tab TikTok dùng chung phiên đăng nhập (cùng 1 shop) → đọc lần lượt từ tab dùng gần nhất.
  if (!tab && !shopee) {
    const all = await chrome.tabs.query({ url: `${origin}*`, currentWindow: true });
    const pool = all.length ? all : await chrome.tabs.query({ url: `${origin}*` });
    const ordered = pool.filter(item => !/\/account\/login/.test(item.url || '')).sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0) || (a.status === 'loading') - (b.status === 'loading'));
    for (const candidate of ordered.slice(0, 4)) {
      try {
        const results = await chrome.scripting.executeScript({ target: { tabId: candidate.id }, func: OPTikTokShop.readFromPage });
        const result = results?.[0]?.result;
        if (result?.ok) return { ok: true, name: result.name, tabId: candidate.id };
      } catch (_) {}
    }
    if (pool.length && !ordered.length) return { ok: false, error: 'TikTok Shop đang ở trang đăng nhập — đăng nhập rồi tool tự nhận shop.' };
  }
  if (!tab) {
    const candidates = shopee ? await findShopeeSellerTabs() : await chrome.tabs.query({ url: `${origin}*`, currentWindow: true });
    if (candidates.length === 1) tab = candidates[0];
    else if (shopee && candidates.length > 1) return { ok: false, error: 'Có nhiều tab shop Shopee. Chọn tab đúng shop để tool nhận tên.' };
    else if (shopee && ensureOpen) tab = await openShopeeSellerTab(active[0]?.windowId);
  }
  if (!tab) return { ok: false, error: shopee ? 'Bấm ↻ hoặc Auto raise để tool mở Kênh Người Bán Shopee.' : `Mở đúng tab ${label} để tự nhận tên shop.` };
  if (shopee) {
    rememberedShopeeTabId = tab.id;
    await chrome.storage.local.set({ shopeeSellerSourceTabId: tab.id });
    if (ensureOpen && !tab.active) tab = await chrome.tabs.update(tab.id, { active: true });
  }
  const attempts = shopee && ensureOpen ? 25 : 1;
  let error = '';
  for (let attempt = 0; attempt < attempts; attempt++) {
    try {
      if (shopee) tab = await chrome.tabs.get(tab.id);
      if (!isSeller(tab)) return { ok: false, pending: shopee, tabId: tab.id, error: 'Kênh Người Bán đã chuyển trang. Hoàn tất đăng nhập Shopee rồi tool tự nhận shop.' };
      if (!shopee || tab.status !== 'loading') {
        const results = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: shopee ? OPShopeeShop.readFromPage : OPTikTokShop.readFromPage });
        const result = results?.[0]?.result;
        if (result?.ok) return { ok: true, name: result.name, tabId: tab.id };
        error = result?.error || `Đang chờ tên shop trên ${label}.`;
      }
    } catch (_) { error = `Tab ${label} đang tải. Tên shop sẽ được tự nhận khi trang sẵn sàng.`; }
    if (attempt + 1 < attempts) await new Promise(resolve => setTimeout(resolve, 400));
  }
  return { ok: false, ...(shopee ? { pending: true, tabId: tab.id } : {}), error: shopee ? 'Đã mở Kênh Người Bán Shopee; đang chờ trang sẵn sàng/tên shop. Tool sẽ tự nhận lại.' : error };
}

const getLoggedInTikTokShop = preferredTabId => getLoggedInMarketplaceShop('tiktok', preferredTabId);

async function clearBacklogTicketState() {
  return withTicketStateLock(async () => {
    const data = await chrome.storage.local.get(['ticketTabPayloads', 'ticketBatchEvidence', 'ticketOpenGroups']);
    const payloads = Object.fromEntries(Object.entries(data.ticketTabPayloads || {}).filter(([, item]) => OPHandover.pageAppeal(item?.draft)));
    const batchIds = new Set(Object.values(payloads).map(item => item.batchId));
    const evidence = Object.fromEntries(Object.entries(data.ticketBatchEvidence || {}).filter(([key]) => batchIds.has(key)));
    const groups = Object.fromEntries(Object.entries(data.ticketOpenGroups || {}).filter(([key]) => /^(handover|cancel_return):/.test(key)));
    await chrome.storage.local.set({ ticketTabPayloads: payloads, ticketBatchEvidence: evidence, ticketOpenGroups: groups });
    return { ok: true };
  });
}

async function startHandoverRun(sessionId, rowIds) {
  const initial = await chrome.storage.local.get('handoverSessions');
  const source = OPHandover.platform(initial.handoverSessions?.[sessionId]);
  const shop = await getLoggedInMarketplaceShop(source, null, { ensureOpen: source === 'shopee' });
  if (!shop.ok) throw new Error(shop.error);
  const result = await withTicketStateLock(async () => {
    const data = await chrome.storage.local.get(['handoverSessions', 'handoverTicketHistory', 'handoverRun', 'ticketOpenGroups']);
    const session = data.handoverSessions?.[sessionId];
    if (!session) throw new Error('Không tìm thấy phiên bàn giao.');
    session.channel = shop.name;
    delete session.name; delete session.warehouse; delete session.handedAt;
    if (data.handoverRun?.activeKey) throw new Error('Đang có 1 đơn kháng nghị xử lý. Chờ map Ticket ID hoặc đóng tab đó trước khi chạy phiên khác.');
    if (Object.keys(data.ticketOpenGroups || {}).some(key => key.startsWith('cancel_return:'))) throw new Error('Đang có ticket đòi hàng (đơn hủy đã bàn giao) xử lý. Chờ lưu Ticket ID trước.');
    if (Object.keys(data.ticketOpenGroups || {}).some(key => !key.startsWith('handover:'))) throw new Error('Đang có form pickup backlog xử lý. Hoàn tất hoặc đóng các tab đó trước khi chạy kháng nghị từng đơn.');
    const requested = new Set(rowIds || []);
    const orders = (session.orders || []).filter(order => requested.has(order.id));
    const errors = OPHandover.validate(session, orders);
    if (errors.length) throw new Error(errors.join('\n'));
    const history = data.handoverTicketHistory || [];
    for (const order of orders) {
      if (history.some(item => OPHandover.matches(item, order.orderId, session))) throw new Error(`Đơn ${order.orderId} đã có ticket kháng nghị bàn giao. Bỏ chọn đơn đã gửi.`);
      if (data.ticketOpenGroups?.[OPHandover.groupKey(order.orderId, session)]) throw new Error(`Đơn ${order.orderId} đã mở form.`);
    }
    const run = { id: `handover_run_${Date.now()}`, platform: source, sessionId, shopName: shop.name, shopTabId: shop.tabId, pending: orders.map(order => order.id), activeKey: '', activeTabId: null, paused: false, startedAt: new Date().toISOString(), error: '' };
    await chrome.storage.local.set({ handoverRun: run, handoverSessions: { ...data.handoverSessions, [sessionId]: session } });
    return { ok: true, count: orders.length };
  });
  await advanceHandoverRun();
  return result;
}

async function advanceHandoverRun() {
  return withTicketStateLock(async () => {
    const data = await chrome.storage.local.get(['handoverSessions', 'handoverRun', 'handoverTicketHistory', 'ticketTabPayloads', 'ticketBatchEvidence', 'ticketOpenGroups']);
    const run = data.handoverRun;
    if (!run || run.paused || run.activeKey || run.doneAt) return { ok: true };
    const session = data.handoverSessions?.[run.sessionId];
    if (!session) return { ok: false };
    const history = data.handoverTicketHistory || [];
    if (run.pending?.length) {
      const shop = await getLoggedInMarketplaceShop(OPHandover.platform(session), run.shopTabId);
      if (!shop.ok || (run.shopName && shop.name !== run.shopName)) {
        run.paused = true; run.error = shop.ok ? `Shop đang đăng nhập là ${shop.name}, hàng đợi thuộc ${run.shopName}. Mở đúng shop rồi bấm Tiếp tục.` : shop.error;
        await chrome.storage.local.set({ handoverRun: run });
        return { ok: false, error: run.error };
      }
      session.channel = shop.name; run.shopName = shop.name; run.shopTabId = shop.tabId;
    }
    while (run.pending?.length) {
      const order = (session.orders || []).find(item => item.id === run.pending[0]);
      if (!order) {
        run.paused = true; run.error = 'Đơn trong hàng đợi đã bị xóa. Chọn lại các đơn để chạy.';
        await chrome.storage.local.set({ handoverRun: run });
        return { ok: false };
      }
      if (history.some(item => OPHandover.matches(item, order.orderId, session))) { run.pending.shift(); continue; }
      const errors = OPHandover.validate(session, [order]);
      if (errors.length) {
        run.paused = true; run.error = errors.join('\n');
        await chrome.storage.local.set({ handoverRun: run });
        return { ok: false };
      }
      let tab;
      try {
        // v2.2.9 — Auto raise từng đơn chạy ở tab nền (tự điền, tự tick, tự Gửi); lib/op-keepalive.js giữ tab thức.
        tab = await chrome.tabs.create({ url: 'about:blank', active: false });
        if (!tab?.id) throw new Error('Chrome không tạo được tab ticket.');
        const draft = OPHandover.draft(session, order);
        const tabPayloads = { ...(data.ticketTabPayloads || {}) };
        const evidence = { ...(data.ticketBatchEvidence || {}), [run.id]: session.files || [] };
        const groups = { ...(data.ticketOpenGroups || {}) };
        tabPayloads[String(tab.id)] = { batchId: run.id, groupKey: draft.groupKey, draft, orderEvidence: order.files || [], createdAt: draft.createdAt };
        groups[draft.groupKey] = { batchId: run.id, tabId: tab.id, status: 'opening', channel: session.channel, carrier: session.carrier, openedAt: draft.createdAt, handoverSessionId: session.id, handoverRowId: order.id };
        run.activeKey = draft.groupKey; run.activeTabId = tab.id; run.error = '';
        await chrome.storage.local.set({ ticketTabPayloads: tabPayloads, ticketBatchEvidence: evidence, ticketOpenGroups: groups, handoverRun: run });
        await chrome.tabs.update(tab.id, { url: OPHandover.platform(session) === 'shopee' ? 'https://help.shopee.vn/portal/webform/9e0e87184cf14246aabe6af0d78b2aa9?previousPage=other%20articles' : 'https://seller-vn.tiktok.com/ticket/create?shop_region=VN' });
        return { ok: true, tabId: tab.id };
      } catch (error) {
        if (tab?.id) { try { await chrome.tabs.remove(tab.id); } catch (_) {} }
        run.activeKey = ''; run.activeTabId = null; run.paused = true; run.error = error.message || String(error);
        const tabPayloads = { ...(data.ticketTabPayloads || {}) };
        const groups = { ...(data.ticketOpenGroups || {}) };
        if (tab?.id) delete tabPayloads[String(tab.id)];
        delete groups[OPHandover.groupKey(order.orderId, session)];
        await chrome.storage.local.set({ handoverRun: run, ticketTabPayloads: tabPayloads, ticketOpenGroups: groups });
        return { ok: false, error: run.error };
      }
    }
    run.doneAt = new Date().toISOString(); run.error = '';
    await chrome.storage.local.set({ handoverRun: run });
    return { ok: true, done: true };
  });
}

async function pauseHandoverRun() {
  return withTicketStateLock(async () => {
    const { handoverRun: run } = await chrome.storage.local.get('handoverRun');
    if (run) { run.paused = true; await chrome.storage.local.set({ handoverRun: run }); }
    return { ok: true };
  });
}

async function resumeHandoverRun() {
  const retryTabId = await withTicketStateLock(async () => {
    const data = await chrome.storage.local.get(['handoverRun', 'ticketOpenGroups', 'ticketTabPayloads']);
    const run = data.handoverRun;
    if (!run || run.doneAt) throw new Error('Không có hàng đợi đang tạm dừng.');
    let retryTabId = null;
    if (run.activeKey && data.ticketOpenGroups?.[run.activeKey]?.autofill?.reason === 'attachments-not-ready') {
      if (data.ticketTabPayloads?.[String(run.activeTabId)]?.ticketCapture?.startedAt) throw new Error('Đơn đã bắt đầu gửi; đang chờ Ticket ID, không gửi lại.');
      retryTabId = run.activeTabId;
      const ticketOpenGroups = { ...data.ticketOpenGroups, [run.activeKey]: { ...data.ticketOpenGroups[run.activeKey], status: 'opened', autofill: {} } };
      await chrome.storage.local.set({ ticketOpenGroups });
    }
    run.paused = false; run.error = '';
    await chrome.storage.local.set({ handoverRun: run });
    return retryTabId;
  });
  if (retryTabId != null) { await chrome.tabs.reload(retryTabId); return { ok: true, retryingUpload: true }; }
  return advanceHandoverRun();
}

async function recoverHandoverRun() {
  const { handoverRun: run } = await chrome.storage.local.get('handoverRun');
  if (!run || run.doneAt) return;
  if (run.activeKey) {
    let tab;
    try { tab = await chrome.tabs.get(Number(run.activeTabId)); } catch (_) {}
    if (!tab || !/^(about:blank|https:\/\/seller-vn\.tiktok\.com\/ticket|https:\/\/help\.shopee\.vn\/portal\/)/.test(tab.url || '')) {
      await cleanupTicketTabState(run.activeTabId);
      await handoverTabClosed(run.activeTabId);
    }
  } else if (!run.paused) chrome.alarms.create(HANDOVER_NEXT_ALARM, { when: Date.now() + 500 });
}

async function handoverTabClosed(tabId) {
  return withTicketStateLock(async () => {
    const { handoverRun: run } = await chrome.storage.local.get('handoverRun');
    if (!run?.activeKey || Number(run.activeTabId) !== Number(tabId)) return;
    run.activeKey = ''; run.activeTabId = null; run.paused = true;
    run.error = 'Tab đã đóng trước khi map Ticket ID. Nếu đã gửi, nhập Ticket ID trên đơn rồi lưu; nếu chưa gửi, bấm Tiếp tục.';
    await chrome.storage.local.set({ handoverRun: run });
  });
}

async function mapHandoverManually(sessionId, rowId, ticketId) {
  if (!String(ticketId || '').trim()) throw new Error('Nhập Ticket ID trước khi lưu.');
  let tabId = -Date.now();
  await withTicketStateLock(async () => {
    const data = await chrome.storage.local.get(['handoverSessions', 'handoverTicketHistory', 'ticketTabPayloads']);
    const session = data.handoverSessions?.[sessionId];
    const order = session?.orders?.find(item => item.id === rowId);
    if (!session || !order) throw new Error('Không tìm thấy đơn.');
    if (!OPHandover.validOrder(order.orderId, session)) throw new Error(`Cần mã đơn ${OPHandover.label(session)} hợp lệ trước khi lưu.`);
    if ((data.handoverTicketHistory || []).some(item => OPHandover.matches(item, order.orderId, session) && item.TicketID)) throw new Error('Đơn đã được map ticket kháng nghị.');
    const active = Object.entries(data.ticketTabPayloads || {}).find(([, payload]) => payload.draft?.handover?.sessionId === sessionId && payload.draft?.handover?.rowId === rowId);
    if (active) { tabId = Number(active[0]); return; }
    const draft = OPHandover.draft(session, order);
    await chrome.storage.local.set({ ticketTabPayloads: { ...(data.ticketTabPayloads || {}), [String(tabId)]: { groupKey: draft.groupKey, draft, batchId: '' } } });
  });
  return recordTicketFromTab(tabId, ticketId);
}

chrome.alarms.onAlarm.addListener(alarm => {
  if (alarm.name === HANDOVER_NEXT_ALARM) advanceHandoverRun().catch(console.error);
});
chrome.tabs.onRemoved.addListener(tabId => { handoverTabClosed(tabId).catch(console.error); });
chrome.runtime.onMessage.addListener((message, sender, respond) => {
  if (!['START_HANDOVER_TICKETS', 'PAUSE_HANDOVER_TICKETS', 'RESUME_HANDOVER_TICKETS', 'MAP_HANDOVER_MANUALLY', 'CLEAR_BACKLOG_TICKET_STATE', 'GET_LOGGED_IN_TIKTOK_SHOP', 'GET_LOGGED_IN_SHOPEE_SHOP'].includes(message?.type)) return;
  if (sender.tab || sender.id !== chrome.runtime.id) { respond({ ok: false, error: 'Chỉ chạy từ Side Panel.' }); return false; }
  const task = message.type === 'START_HANDOVER_TICKETS' ? startHandoverRun(message.sessionId, message.rowIds)
    : message.type === 'PAUSE_HANDOVER_TICKETS' ? pauseHandoverRun()
    : message.type === 'RESUME_HANDOVER_TICKETS' ? resumeHandoverRun()
    : message.type === 'CLEAR_BACKLOG_TICKET_STATE' ? clearBacklogTicketState()
    : message.type === 'GET_LOGGED_IN_TIKTOK_SHOP' ? getLoggedInTikTokShop()
    : message.type === 'GET_LOGGED_IN_SHOPEE_SHOP' ? getLoggedInMarketplaceShop('shopee', null, { ensureOpen: message.ensureOpen !== false })
    : mapHandoverManually(message.sessionId, message.rowId, message.ticketId);
  task.then(respond).catch(error => respond({ ok: false, error: error.message || String(error) }));
  return true;
});
