/* Panel v2.2.4 — Shopee: 2 webform Người bán về lấy hàng + theo dõi phiếu (lib/op-shopee-pickup.js).
   - "Khiếu nại cập nhật sai trạng thái lấy hàng": đơn đã giao ĐVVC nhưng chưa cập nhật lấy hàng / bị hủy, hoặc shipper chưa tới mà báo lấy thất bại.
   - "Yêu cầu hối lấy hàng": đơn đã sẵn sàng nhưng ĐVVC chưa tới lấy / muốn Shopee điều phối sớm hơn.
   1 ticket = 1 mã đơn đại diện + file Excel "Danh sách đơn hàng" chứa toàn bộ đơn; tool tự điền, tự Gửi, tự lưu mã phiếu.
   Nguồn đơn: phiên Kháng nghị bàn giao đang chọn, đơn lỗi của store vừa lấy, hoặc dán danh sách. */
(() => {
  const $p = id => document.getElementById(id);
  const escP = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const SN = /^\d{6}[A-Z0-9]{6,14}$/;
  let choice = 'status:0', rows = [], source = '', meta = {}, lastFollow = '';

  function parseList(text) {
    const out = [], seen = new Set();
    for (const line of String(text || '').split(/\r?\n/)) {
      const cells = line.split(/\t|;|,/).map(s => s.trim());
      const id = cells.map(c => c.toUpperCase()).find(c => SN.test(c)); if (!id || seen.has(id)) continue; seen.add(id);
      const rest = cells.filter(c => c && c.toUpperCase() !== id);
      out.push({ orderId: id, trackingId: rest.find(c => /^[A-Z0-9]{8,30}$/i.test(c) && /\d/.test(c)) || '', carrier: rest.find(c => /[a-zà-ỹ]{3,}/i.test(c) && !/^\d/.test(c)) || '' });
    }
    return out;
  }
  async function fromSession() {
    const st = await chrome.storage.local.get(['handoverSessions', 'handoverSelectedByPlatform', 'handoverSelectedSession']);
    const sessions = st.handoverSessions || {}, id = st.handoverSelectedByPlatform?.shopee || st.handoverSelectedSession;
    const s = sessions[id]?.platform === 'shopee' ? sessions[id] : Object.values(sessions).filter(x => x.platform === 'shopee').sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)))[0];
    if (!s) throw Error('Chưa có phiên Kháng nghị Shopee. Tạo phiên trong Ticket Assistant hoặc dán danh sách đơn.');
    const list = (s.orders || []).filter(o => o.selected !== false && SN.test(String(o.orderId || '').trim().toUpperCase()))
      .map(o => ({ orderId: String(o.orderId).trim().toUpperCase(), trackingId: o.trackingId || '', carrier: s.carrier || '', note: [o.status === 'cancelled' ? 'Đơn đã bị hủy' : '', o.sequence ? `STT biên bản ${o.sequence}` : '', o.note || ''].filter(Boolean).join(' · ') }));
    if (!list.length) throw Error('Phiên Kháng nghị Shopee chưa có mã đơn hợp lệ.');
    meta = { channel: s.channel || '', carrier: s.carrier || '', shopId: s.source?.shopId || '' };
    if (list.some(o => /hủy/.test(o.note))) choice = 'status:0';
    return list;
  }
  async function fromRun() {
    const data = await chrome.runtime.sendMessage({ type: 'EXPORT' }).catch(() => null);
    const run = data?.run; if (!run || String(run.platform || '').toUpperCase() !== 'SHOPEE') throw Error('Lấy dữ liệu 1 store Shopee trước.');
    const seen = new Set(), list = [];
    for (const o of data.orders || []) {
      const id = String(o.order_sn || o.order_id || '').trim().toUpperCase();
      if (!SN.test(id) || seen.has(id) || globalThis.OPClaim?.tooOld(o)) continue; seen.add(id);
      list.push({ orderId: id, trackingId: String(o.tracking_id || ''), carrier: String(o.carrier || ''), orderDate: o.created_at || '', slaAt: o.deadline || '', note: [o.metric, String(o.reason || '').slice(0, 120)].filter(Boolean).join(' · ') });
    }
    if (!list.length) throw Error('Store vừa lấy không có đơn lỗi trong 30 ngày.');
    meta = { channel: run.channel_name || run.shopName || '', shopId: run.shopId || '', warehouse: run.warehouse || '' };
    return list;
  }
  const label = s => s === 'session' ? 'phiên Kháng nghị bàn giao' : s === 'run' ? 'đơn lỗi store vừa lấy' : s === 'paste' ? 'danh sách dán' : '';
  function stamp(v) { const d = new Date(v); return Number.isNaN(d.getTime()) ? '' : d.toLocaleString('vi-VN', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit' }); }

  async function renderFollow() {
    const el = $p('pickupFollow'); if (!el) return;
    const list = await OPShopeePickup.followList().catch(() => []);
    const { shopeeCaseSeen } = await chrome.storage.local.get('shopeeCaseSeen');
    const sig = JSON.stringify([list.slice(0, 15), shopeeCaseSeen?.at]); if (sig === lastFollow) return; lastFollow = sig;
    el.innerHTML = `<div class="buttons"><button id="pickupFollowOpen">Theo dõi trên Seller Service (Yêu cầu của tôi)</button></div>
      <p class="hint">Mở trang và đăng nhập tài khoản shop (nếu cần); tool tự đọc trạng thái phiếu từ dữ liệu trang trả về.${shopeeCaseSeen?.at ? ` Lần đọc gần nhất ${escP(stamp(shopeeCaseSeen.at))}: ${shopeeCaseSeen.records} phiếu, khớp ${shopeeCaseSeen.matched}.` : ''}</p>
      ${list.length ? `<table class="pickup-follow"><tr><th>Mã phiếu</th><th>Form</th><th>Đơn</th><th>Trạng thái</th></tr>${list.slice(0, 15).map(t => `<tr><td>${escP(t.ticketId || 'chờ mã…')}</td><td>${escP(t.form)}${t.option ? `<br><span class="muted">${escP(t.option)}</span>` : ''}</td><td>${escP(t.orderId)}${t.orders > 1 ? ` +${t.orders - 1}` : ''}<br><span class="muted">${escP(stamp(t.at))}</span></td><td>${t.status ? `<b>${escP(t.status.status || (t.status.code ? '#' + t.status.code : '?'))}</b><br><span class="muted">${escP(stamp(t.status.seenAt))}</span>` : '<span class="muted">chưa đọc</span>'}</td></tr>`).join('')}</table>` : '<p class="hint">Chưa có phiếu Shopee nào do tool gửi.</p>'}`;
    $p('pickupFollowOpen').onclick = () => chrome.tabs.create({ url: OPShopeePickup.FOLLOW_URL, active: true });
  }
  function render() {
    const box = $p('pickupBox'); if (!box) return;
    const pick = OPShopeePickup.parse(choice);
    // v2.2.9 — gói gọn trong 1 mục thu gọn; chỉ hiện khi khối khiếu nại đang ở Shopee (panel.css · body[data-claim-plat]).
    const wasOpen = box.querySelector(':scope > details')?.open;
    box.innerHTML = `<details class="ap-sub" ${wasOpen ? 'open' : ''}><summary>Shopee · Webform lấy hàng (trạng thái / hối lấy hàng)</summary>
      <label>Form<select id="pickupChoice">${OPShopeePickup.choices().map(c => `<option value="${c.value}" ${c.value === choice ? 'selected' : ''}>${escP(c.label)}</option>`).join('')}</select></label>
      <p class="hint">${pick.form.id === 'status' ? 'Kho đã giao ĐVVC nhưng Shopee chưa cập nhật "đã lấy hàng" (hoặc đơn bị hủy), hoặc shipper chưa liên hệ mà báo lấy hàng không thành công.' : 'Đơn đã sẵn sàng mà ĐVVC chưa tới lấy, hoặc cần Shopee điều phối ĐVVC sớm hơn.'} 1 ticket = 1 đơn đại diện + file Excel toàn bộ đơn; tool tự điền, tự Gửi, tự lưu mã phiếu.</p>
      <div class="buttons"><button id="pickupFromSession">Từ phiên Kháng nghị</button><button id="pickupFromRun">Từ đơn lỗi store</button></div>
      <textarea id="pickupPaste" rows="3" placeholder="Hoặc dán mã đơn Shopee, mỗi dòng 1 đơn (kèm mã vận đơn, ĐVVC nếu có)"></textarea>
      <p class="hint" id="pickupCount">${rows.length ? `<b>${rows.length}</b> đơn từ ${escP(label(source))}${meta.channel ? ` · ${escP(meta.channel)}` : ''} · đơn đại diện <b>${escP(rows[0].orderId)}</b>` : 'Chưa có đơn.'}</p>
      <button class="primary" id="pickupRaise" ${rows.length ? '' : 'disabled'}>Raise "${escP(pick.form.title)}"</button>
      <details id="pickupFollowCard"><summary>Theo dõi phiếu Shopee đã raise</summary><div id="pickupFollow"></div></details></details>`;
    $p('pickupChoice').onchange = e => { choice = e.target.value; render(); };
    const load = async (fn, s) => { try { rows = await fn(); source = s; render(); } catch (e) { message(e.message, true); } };
    $p('pickupFromSession').onclick = () => load(fromSession, 'session');
    $p('pickupFromRun').onclick = () => load(fromRun, 'run');
    $p('pickupPaste').onchange = e => { const list = parseList(e.target.value); if (!list.length) return message('Không thấy mã đơn Shopee hợp lệ (dạng 251009ABCD1234).', true); rows = list; source = 'paste'; meta = { channel: meta.channel || '' }; render(); };
    $p('pickupRaise').onclick = async e => {
      e.target.disabled = true;
      try {
        if (meta.channel) { const shop = await chrome.runtime.sendMessage({ type: 'GET_LOGGED_IN_SHOPEE_SHOP', ensureOpen: false }).catch(() => null); const n = v => String(v || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]/g, ''), a = n(shop?.name), b = n(meta.channel); if (shop?.ok && a && b && !a.includes(b) && !b.includes(a)) throw Error(`Shop đang đăng nhập là "${shop.name}", đơn thuộc "${meta.channel}". Chuyển đúng shop rồi raise.`); }
        const r = await OPShopeePickup.raise({ choice, rows, channel: meta.channel || '', carrier: meta.carrier || '', warehouse: meta.warehouse || '', shopId: meta.shopId || '', reason: source === 'session' ? 'Kho đã bàn giao đúng hạn (có biên bản) nhưng ĐVVC chưa cập nhật đúng trạng thái lấy hàng' : '' });
        message(`Đã mở form "${r.form}" (${r.orders} đơn, file ${r.file}). Tool tự điền, tải file và Gửi; giữ tab mở tới khi có mã phiếu.`);
      } catch (err) { message(err.message, true); } finally { e.target.disabled = !rows.length; }
    };
    $p('pickupFollowCard').ontoggle = () => { lastFollow = ''; renderFollow().catch(() => {}); };
    lastFollow = ''; renderFollow().catch(() => {});
  }
  globalThis.OPPickupPanel = { render, parseList, fromSession, fromRun, renderFollow };
  render();
  chrome.storage.onChanged.addListener((ch, area) => { if (area === 'local' && (ch.shopeeFollowTickets || ch.shopeeCaseStatus)) renderFollow().catch(() => {}); });
})();
