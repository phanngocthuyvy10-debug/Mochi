importScripts('core.js', 'order-details.js', 'shopee-core.js', 'db.js', 'auto-workflow.js');
const VERSION = chrome.runtime.getManifest?.()?.version || '2.2.91'; // header Side Panel = đúng bản đang cài
// Shopee's public Shop Code is its verified Shop ID, including saved runs from older versions.
function withShopCode(id) { return id?.platform === 'SHOPEE' && /^\d{5,24}$/.test(String(id.shopId || '')) ? { ...id, shopCode: String(id.shopId) } : id; }
let serial = Promise.resolve();
const mutate = f => { const p = serial.then(f); serial = p.catch(() => {}); return p; };
// Non-secret defaults only. Connection keys belong to the user's local settings.
let cfgCache;
async function config() { if (cfgCache) return cfgCache; try { const c = await (await fetch(chrome.runtime.getURL('config.json'))).json(); cfgCache = Object.fromEntries(Object.entries(c).filter(([k, v]) => ['endpoint', 'dashboardUrl', 'autoSync', 'autoStart', 'collector'].includes(k) && v !== '' && v != null)); } catch { cfgCache = {}; } return cfgCache; }
const read = async () => {
  const x = await chrome.storage.local.get(['state', 'settings']), s = x.state || {};
  const saved = Object.fromEntries(Object.entries(x.settings || {}).filter(([, v]) => v !== '' && v != null)), defaults = await config();
  return { state: { run: withShopCode(s.run || null), detected: Object.fromEntries(Object.entries(s.detected || {}).map(([k, v]) => [k, withShopCode(v)])), bindings: s.bindings || {}, log: s.log || [], outbox: (s.outbox || []).map(j => ({ ...j, run: withShopCode(j.run) })), catalog: s.catalog, history: s.history || {}, daily: s.daily || {} }, settings: { endpoint: '', secret: '', autoSync: true, dashboardUrl: '', collector: '', ...defaults, ...saved } };
};
const save = async s => { await chrome.storage.local.set({ state: s }); };
function note(s, msg) { s.log = [...(s.log || []), { at: new Date().toISOString(), msg }].slice(-120); }
function dirty(r) { r.dataVersion = (r.dataVersion || 0) + 1; r.syncStatus = 'CHƯA LƯU'; }
function serverWarning(remote,platform='TIKTOK') {
  if(platform==='SHOPEE')return remote.order_schema>=3&&remote.platforms?.includes('SHOPEE')?'':'Apps Script chưa hỗ trợ Shopee. Cập nhật Code.gs + Dashboard.html v2.0.3 rồi triển khai Phiên bản mới. Dữ liệu Shopee được giữ ở máy.';
  const v=String(remote.version || ''),p=v.split('.').map(Number);
  const supported=remote.order_schema>=2 || p[0]>1 || p[0]===1 && (p[1]>5 || p[1]===5 && p[2]>=1);
  return supported?'':`Apps Script ${v?'v'+v:'chưa báo phiên bản'} chưa xác nhận hỗ trợ Actual handover time và các cột hiệu suất. Cập nhật Code.gs + Dashboard.html rồi triển khai Phiên bản mới.`;
}
function serverInfo(remote) {return {connectionVerifiedAt:new Date().toISOString(),sheetName:remote.sheet_name,serverVersion:String(remote.version || ''),serverOrderSchema:Number(remote.order_schema)||0,serverPlatforms:Array.isArray(remote.platforms)?remote.platforms:[],serverWarning:serverWarning(remote),serverMaxChunk:Number(remote.max_chunk)||500};}
function keyError(settings) {
  if (!settings.endpoint) return 'Chưa cấu hình URL Web App. Dữ liệu vẫn nằm trong hàng đợi.';
  if (typeof settings.secret !== 'string' || settings.secret.trim().length < 24) return 'Chưa có Khóa kết nối hợp lệ. Dán khóa vào Kết nối Google Sheet rồi bấm Kết nối & gửi dữ liệu chờ.';
  return '';
}
function pendingSummary(s) {
  const groups = new Map();
  for (const job of s.outbox || []) {
    const code = job.run.channel_code; let g = groups.get(code);
    if (!g) groups.set(code, g = { code, name: job.run.shopName || job.run.channel_name, uploads: 0, orders: new Set(), daily: new Set(), sent: 0, parts: 0 });
    g.uploads++; g.sent += (job.next || 0) + (job.finalized ? 1 : 0) + (job.dailyNext || 0); g.parts += (job.chunks || []).length + 1 + (job.dailyChunks || []).length;
    for (const chunk of job.chunks || []) for (const row of chunk) g.orders.add(`${row.metric}|${row.order_id}`);
    for (const chunk of job.dailyChunks || []) for (const row of chunk) g.daily.add(`${row.metric}|${row.date}`);
  }
  return [...groups.values()].map(g => ({ code: g.code, name: g.name, uploads: g.uploads, orders: g.orders.size, daily: g.daily.size, sent: g.sent, parts: g.parts }));
}
async function connectAndRetry(s, next) {
  const remote = await post(next, { action: 'ping' });
  await chrome.storage.local.set({ settings: { ...next, ...serverInfo(remote) } });
  if (Array.isArray(remote.catalog)) s.catalog = remote.catalog;
  note(s, 'Đã kiểm tra kết nối: ' + remote.sheet_name); await save(s);
  const sync = s.outbox.length ? await flushOutbox(s) : { ok: true, empty: true };
  return { ok: true, connected: true, sheet_name: remote.sheet_name, warning:serverWarning(remote), sync };
}
const SELLER = 'https://seller-vn.tiktok.com/';
const SHOPEE='https://banhang.shopee.vn/';
const platformOf=x=>x?.platform==='SHOPEE'?'SHOPEE':'TIKTOK';
const tabPlatform=url=>String(url||'').startsWith(SHOPEE)?'SHOPEE':String(url||'').startsWith(SELLER)?'TIKTOK':'';
// A post-login landing page can have ?is_from_login=true. Authentication
// routes are determined by path segments, never query strings or fragments.
function isLoginURL(value){
  try{const path=decodeURIComponent(new URL(value).pathname);return /(?:^|\/)(?:login|logout|passport|signin|sign-in|university|edu)(?:\/|$)/i.test(path)||/^\/account\/(?:register|signup)(?:\/|$)/i.test(path);}
  catch{return false;}
}
const bindingKey=x=>platformOf(x)==='SHOPEE'?'SHOPEE:'+x.shopId:x.shopId;
const sameShop=(a,b)=>a?.shopId===b?.shopId&&platformOf(a)===platformOf(b);
const defsFor=x=>platformOf(x)==='SHOPEE'?OPShopee.defs:OPCore.defs;
const summaryFor=(r,rows)=>platformOf(r)==='SHOPEE'?OPShopee.summary(rows):OPDetails.summary(rows);
const validCode=(code,platform)=>new RegExp('^'+(platform==='SHOPEE'?'SPE':'TTK')+'[A-Z0-9]+$').test(code||'');
function shopeeStore(id){return {platform:'SHOPEE',shop_id:id.shopId,shop_code:String(id.shopId),shop_name:id.shopName,channel_name:id.shopName+' - Shopee',channel_code:'SPE'+id.shopId,warehouse:'',mapping_note:'Internal channel key generated from the verified Shopee Shop ID; editable in SPE_Stores.'};}
// Existing verified Shop ID mappings win. A new identity gets its own key,
// even when another unbound channel has a similar name, just like Shopee.
function tiktokStore(id){return {platform:'TIKTOK',shop_id:id.shopId,shop_name:id.shopName,channel_name:id.shopName+' - TikTok',channel_code:'TTK'+id.shopId,warehouse:'',mapping_note:'Internal channel key generated from the verified TikTok Shop ID; editable in TTS_Stores.'};}
async function autoStoreFor(s,id){
  if(!/^\d{5,24}$/.test(id?.shopId||''))return null;
  return platformOf(id)==='SHOPEE'?shopeeStore(id):tiktokStore(id);
}

function blankMetric(d) { return { code: d.code, name: d.name, value: null, raw: '', source: '', threshold: null, expected: null, denominator: null, period_start: '', period_end: '', scopeVerified: false, pages: 0, count: 0, coverage: 'CHƯA LẤY', notes: '', done: false }; }

async function askTab(tabId, message) {
  try { return await chrome.tabs.sendMessage(tabId, message, { frameId: 0 }); }
  catch { throw Error('Chưa kết nối được trang Seller Center. F5 tab TikTok (sau khi Reload extension) rồi thử lại.'); }
}
async function sellerTab(tabId) {
  const tab = await chrome.tabs.get(tabId).catch(() => null);
  if (!tabPlatform(tab?.url)) throw Error('Mở tab TikTok Seller Center hoặc Kênh Người Bán Shopee đã đăng nhập.');
  if (isLoginURL(tab.url)) throw Error('Tab đang ở trang đăng nhập/học viện. Login store và mở trang Seller Center.');
  return tab;
}
async function detect(tabId) {
  const tab=await sellerTab(tabId);
  const r = await askTab(tabId, { type: 'IDENTITY_NOW' });
  if (r?.error) throw Error(r.error);
  if(!/^\d{5,24}$/.test(r.identity?.shopId||''))throw Error('Chưa xác nhận Shop ID của phiên hiện tại.');
  return withShopCode({...r.identity,platform:tabPlatform(tab.url)});
}

async function knownStores(s) {
  const bundled=await (await fetch(chrome.runtime.getURL('stores.json'))).json();
  const speSeed=await (await fetch(chrome.runtime.getURL('shopee-stores.json'))).json();
  const remote=(s.catalog||[]).map(x=>({...x,platform:platformOf(x)}));
  const list=[...(s.catalog?remote:bundled.map(x=>({...x,platform:'TIKTOK'})))];
  for(const x of speSeed)if(!list.some(r=>platformOf(r)==='SHOPEE'&&String(r.shop_id)===String(x.shop_id)))list.push({...shopeeStore({shopId:String(x.shop_id),shopName:x.shop_name}),...x,channel_code:'SPE'+x.shop_id});
  const local=Object.fromEntries(bundled.filter(x=>x.shop_id).map(x=>[String(x.shop_id),{...x,platform:'TIKTOK'}]));
  for(const r of [...(s.outbox||[]).map(j=>j.run),s.run].filter(Boolean))if(/^\d{5,24}$/.test(r.shopId||''))local[bindingKey(r)]={shop_id:r.shopId,channel_code:r.channel_code,channel_name:r.channel_name,warehouse:r.warehouse,platform:platformOf(r)};
  Object.assign(local,s.bindings||{});
  for(const [key,b]of Object.entries(local)){
    const sid=String(b.shop_id||key.replace(/^SHOPEE:/,'')),platform=key.startsWith('SHOPEE:')?'SHOPEE':platformOf(b);
    if(!/^\d{5,24}$/.test(sid)||!validCode(b.channel_code,platform))continue;
    const exact=list.find(x=>platformOf(x)===platform&&String(x.shop_id||'')===sid);
    if(exact){if(exact.mapping_note?.startsWith('Internal')||(!remote.some(x=>platformOf(x)===platform&&String(x.shop_id||'')===sid)&&platform==='SHOPEE'))Object.assign(exact,b,{shop_id:sid,platform});continue;}
    const row=list.find(x=>platformOf(x)===platform&&x.channel_code===b.channel_code);
    if(row){if(!row.shop_id){row.shop_id=sid;row.binding_source='local';}}
    else if(b.channel_name)list.push({...b,shop_id:sid,platform,binding_source:'local'});
  }
  return list.map(x=>platformOf(x)==='SHOPEE'&&/^\d{5,24}$/.test(String(x.shop_id||''))?{...x,shop_code:String(x.shop_id)}:x);
}
// The run owns a tab ID, not whichever tab happens to be active later.
// Persist the handoff BEFORE navigating; the new document/worker can resume it.
async function readyShopeeTab(s,url,reason='shopee-primary'){
  const r=s.run,tabId=r.tabId;
  if(!['https://banhang.shopee.vn/portal/accounthealth/home','https://banhang.shopee.vn/portal/accounthealth/official-seller/'].includes(url))throw Error('Link Shopee không hợp lệ.');
  if(!sameShop(await detect(tabId),r))throw Error('Store Shopee đã đổi.');
  r.phase='collecting';r.navigation={url,reason,tabId,until:Date.now()+60000};r.lastActivityAt=Date.now();
  note(s,'Đang chuyển trang sức khỏe Shopee trên tab hiện tại…');await save(s);
  try{await chrome.tabs.update(tabId,{url});}catch(e){r.navigation=null;await save(s);throw e;}
  return tabId;
}
async function dispatchCollect(s){
  const r=s.run;r.collectTaskId=crypto.randomUUID();r.lastActivityAt=Date.now();await save(s);
  const reply=await askTab(r.tabId,{type:'COLLECT',runId:r.id,taskId:r.collectTaskId,historyDays:r.historyDays});
  if(reply?.error)throw Error(reply.error);
}
function matchesRoute(url,target){
  const a=new URL(url),b=new URL(target);
  return a.origin===b.origin && a.pathname.replace(/\/$/,'')===b.pathname.replace(/\/$/,'') && [...b.searchParams].every(([k,v])=>a.searchParams.get(k)===v);
}
async function resumeNavigation(s,tabId){
  const r=s.run,n=r?.navigation;if(!n||r.closed||tabId!==r.tabId||tabId!==n.tabId)return false;
  try{
    const tab=await sellerTab(tabId);
    if(tab.status==='loading'||!matchesRoute(tab.url,n.url))throw Error('Đang chờ trang nguồn sẵn sàng.');
    if(!sameShop(await detect(tabId),r))throw Error('Store Shopee đã đổi.');
    r.navigation=null;await save(s);await dispatchCollect(s);return true;
  }catch(e){
    if(Date.now()<n.until&&!/đã đổi|đăng nhập|Login|login/i.test(e.message)){r.navigation=n;await save(s);return false;}
    r.navigation=null;r.phase='done';r.workflow ||= {active:true,problems:[],stage:'upload'};
    await OPAuto.finish(s,'Không tiếp tục được trên tab nguồn: '+e.message);return true;
  }
}
async function collectShopeeSecondary(s){
  const r=s.run;if(r.shopeeSecondaryAttempted)return false;r.shopeeSecondaryAttempted=true;
  const url=r.shopeeInitialOfficial?SHOPEE+'portal/accounthealth/home':SHOPEE+'portal/accounthealth/official-seller/';
  await readyShopeeTab(s,url,'shopee-secondary');return true;
}
async function applyShopeeCollected(s,data){
  const r=s.run;if(!sameShop(r,data.identity)){r.phase='error';note(s,'Phiên Shopee đã đổi; giữ phần cũ và dừng ghép dữ liệu.');return;}
  for(const k of data.metrics||[]){const a=r.metrics.find(m=>m.code===k.code);if(!a||k.value==null)continue;if(a.source&&(a.period_start!==k.period_start||a.period_end!==k.period_end)){r.shopeeIgnoredCodes=[...new Set([...(r.shopeeIgnoredCodes||[]),k.code])];r.captureNotes=[...(r.captureNotes||[]),k.code+': trang thứ hai trả kỳ khác; giữ kỳ ban đầu và không trộn đơn.'];continue;}if(r.shopeeIgnoredCodes?.includes(k.code))continue;const rows=(k.orders||[]).filter(o=>OPShopee.id(o.order_id)&&['API_FAILURE_LIST','API_FAILURE_FLAG','DOM_FAILURE_ROW'].includes(o.evidence));if(rows.length)await OPDB.put(r.id,k.code,rows);
    const priorComplete=a.listComplete===true,priorNotes=a.notes;const all=(await OPDB.list(r.id)).filter(o=>o.metric===k.code),orderMetric=['NFR','LSR','FHR'].includes(k.code),complete=priorComplete&&k.lineTotal==null || k.lineTotal!=null&&k.linesFetched===k.lineTotal&&k.scopeVerified===true;
    Object.assign(a,{...k,orders:undefined,count:all.length,done:true,listComplete:orderMetric?complete:true,scopeVerified:orderMetric?complete:false,expected:orderMetric?(complete?all.length:k.expected??null):null,denominator:k.denominator??null,skipped:!!k.skipped,coverage:k.skipped?'ĐẠT · BỎ QUA ĐƠN':orderMetric?(complete?'ĐỦ ĐƠN':'CHƯA ĐỦ DANH SÁCH'):'KPI · KHÔNG CÓ DANH SÁCH ĐƠN',notes:[k.note,complete?priorNotes||'':'Chưa xác nhận đủ kỳ/danh sách',`${all.length} Order ID duy nhất`].filter(Boolean).join(' · ')});
  }
  if(data.apiComplete)r.shopeeSecondaryAttempted=true;
  const history=(data.daily||[]).filter(d=>/^\d{4}-\d{2}-\d{2}$/.test(d.date||'')&&(OPShopee.metric(d.metric)||/^X_[A-Z0-9_]{2,60}$/.test(d.metric||'')||d.metric==='PP')&&Number.isFinite(d.value));
  const by=new Map([...(s.daily[r.id]||[]),...history].map(d=>[`${d.metric}|${d.date}|${d.window_start}|${d.window_end}`,d]));s.daily[r.id]=[...by.values()];r.dailyRows=by.size;
  r.captureNotes=[...new Set([...(r.captureNotes||[]),...(data.notes||[])])];r.details=summaryFor(r,await OPDB.list(r.id));r.phase='done';r.capturedAt=data.at||r.capturedAt;dirty(r);note(s,`Shopee ${r.channel_code}: ${r.metrics.filter(m=>m.source).length} KPI · ${r.details.total} Order ID · lịch sử ${r.dailyRows} dòng.`);
}
async function startCollect(s, settings, tabId, store, days, autoAll=false) {
  const id = await detect(tabId);
  if (settings.endpoint) { try { const remote = await post(settings, { action: 'ping' }); await chrome.storage.local.set({settings:{...settings,...serverInfo(remote)}}); if (Array.isArray(remote.catalog)) s.catalog = remote.catalog; if(serverWarning(remote,platformOf(id)))note(s,serverWarning(remote,platformOf(id))); } catch (e) { note(s, 'Chưa đọc được mapping Sheet, vẫn thu thập cục bộ: ' + e.message); } }
  const catalog=await knownStores(s), exact=catalog.filter(x=>platformOf(x)===platformOf(id)&&String(x.shop_id||'')===id.shopId);
  if(exact.length>1)throw Error('Seller ID đang gắn nhiều channel. Sửa mapping TTS_Stores trước khi lấy.');
  if(exact.length===1)store=exact[0];
  const binding = catalog.find(x => platformOf(x)===platformOf(id)&&x.channel_code === store.channel_code);
  if (binding?.enabled === false) throw Error('Store đã tắt trong TTS_Stores.');
  if (binding?.shop_id && binding.shop_id !== id.shopId) throw Error(`${store.channel_code} đã gắn Shop ID ${binding.shop_id}, nhưng tab đang login ${id.shopName} (${id.shopId}). Chọn đúng channel hoặc sửa TTS_Stores.`);
  const other = catalog.find(x => platformOf(x)===platformOf(id)&&String(x.shop_id||'') === id.shopId && x.channel_code !== store.channel_code);
  if (other) throw Error(`Shop ${id.shopName} (${id.shopId}) đang gắn với ${other.channel_code}. Chọn channel ${other.channel_code}.`);
  s.detected[tabId] = { ...id, at: Date.now() };
  s.bindings[bindingKey(id)]={platform:platformOf(id),shop_id:id.shopId,channel_code:store.channel_code,channel_name:store.channel_name,warehouse:store.warehouse || ''};
  s.run = { id: crypto.randomUUID(), platform:platformOf(id), tabId, mainTabId:tabId, shopId: id.shopId, shopName: id.shopName, shopCode: platformOf(id)==='SHOPEE'?id.shopId:id.shopCode || store.shop_code || '', business_code: store.business_code || '', identitySource: 'API', channel_name: store.channel_name, channel_code: store.channel_code, warehouse: store.warehouse || '', capturedAt: new Date().toISOString(), week: weekVN(), metrics: defsFor(id).map(blankMetric), phase: 'collecting', closed: false, diagnostics: [], syncStatus: 'CHƯA LƯU', revision: 0, dataVersion: 0, version: VERSION, collector: settings.collector || '',autoAll };
  note(s, `Bắt đầu ${store.channel_code} · ${id.shopName} · ${id.shopId}`);
  await save(s);
  const historyDays = Math.max(14,Math.min(3650,Math.floor(Number(days) || 30)));
  s.run.historyDays = historyDays;
  s.run.lastActivityAt=Date.now();
  await save(s);
  // v2.2.18 — tự mở trang "FHR tính lại" ở tab nền, đọc xong tự đóng và lưu cùng lượt này (appeal-background.js).
  if(platformOf(id)==='SHOPEE'&&typeof fhrAutoOpen==='function')fhrAutoOpen(id.shopId,{reason:'collect',username:id.username||''}).catch(()=>{});
  if(platformOf(id)==='SHOPEE'){const source=await sellerTab(tabId);s.run.shopeeInitialOfficial=source.url.includes('/official-seller');if(!source.url.includes('/portal/accounthealth/')){await readyShopeeTab(s,SHOPEE+'portal/accounthealth/home');return {ok:true,identity:id,navigating:true};}await save(s);}
  await dispatchCollect(s);
  return { ok: true, identity: id };
}

async function applyCollected(s, settings, data) {
  const r = s.run;
  if(platformOf(r)==='SHOPEE')return applyShopeeCollected(s,data);
  if (data?.identity?.shopId !== r.shopId) { r.phase = 'error'; note(s, 'Store trong tab đã đổi trong lúc lấy dữ liệu. Không ghi dữ liệu.'); return; }
  for (const a of r.metrics) {
    const k = (data.metrics || []).find(x => x.code === a.code);
    if (!k) { Object.assign(a, { value: null, raw: '', source: '', coverage: 'CHƯA LẤY', notes: 'TikTok không hiển thị KPI này cho store', done: true }); continue; }
    const orders = (k.orders || []).filter(o => o && /^\d{10,24}$/.test(o.order_id));
    if (orders.length) await OPDB.put(r.id, a.code, orders);
    const prior = (k.historyOrders || []).filter(o => o && /^\d{10,24}$/.test(o.order_id) && !orders.some(x => x.order_id === o.order_id)).map(o => ({ ...o, prior_window: 1 }));
    if (prior.length) await OPDB.put(r.id, a.code, prior);
    const complete = k.linesFetched === k.lineTotal;
    Object.assign(a, {
      value: k.value, raw: k.raw, source: 'API_ACCOUNT_HEALTH', threshold: k.threshold, period_start: k.period_start, period_end: k.period_end,
      denominator: k.lineTotal, pages: Math.ceil((k.linesFetched || 0) / 1000), count: orders.length, scopeVerified: true,
      expected: k.value === null && !k.lineTotal ? null : complete ? orders.length : null,
      notes: [`${orders.length} Order ID duy nhất`, prior.length ? `+${prior.length} đơn lỗi các kỳ trước` : '', k.listDate && k.listDate !== k.period_end ? `đơn lỗi theo cửa sổ ${k.listStart} → ${k.listDate}` : '', k.note].filter(Boolean).join(' · ').slice(0, 480),
      done: true
    });
    a.listComplete = complete;
    a.scopeVerified = !k.listDate || k.listDate === k.period_end;
    a.skipped = !!k.skipped;
    a.coverage = a.skipped ? 'ĐẠT · BỎ QUA ĐƠN' : !complete ? 'CHƯA ĐỦ DANH SÁCH' : OPCore.completeness(a,a.count);
  }
  const daily = (data.daily || []).filter(x => x && /^\d{4}-\d{2}-\d{2}$/.test(x.date) && typeof x.value === 'number' && (OPCore.defs.some(d => d.code === x.metric) || x.metric === 'SHOP_SCORE' || /^X_[A-Z0-9_]{2,60}$/.test(x.metric || '')) && Number.isFinite(x.value));
  if (Array.isArray(data.notes) && data.notes.length) r.captureNotes = [...new Set([...(r.captureNotes || []), ...data.notes])].slice(-30);
  const keep = new Set([r.id,...s.outbox.map(j=>j.run.id)]);
  s.daily = {...Object.fromEntries(Object.entries(s.daily || {}).filter(([id])=>keep.has(id))),[r.id]:daily}; r.dailyRows = daily.length;
  r.details = summaryFor(r,await OPDB.list(r.id));
  r.phase = 'done'; r.capturedAt = data.at || r.capturedAt; dirty(r);
  note(s, `Xong ${r.channel_code}: ` + r.metrics.map(m => `${m.code} ${m.value == null ? '--' : (m.value * 100).toFixed(2) + '%'}/${m.count} đơn`).join(' · ') + ` · lịch sử ${daily.length} dòng ngày`);
}

async function applyDetailRows(s, rows) {
  const r = s.run, originals = await OPDB.list(r.id), by = new Map();
  for (const row of rows || []) {
    const model=platformOf(r)==='SHOPEE'?OPShopee:OPDetails;const oid = model.id(row.order_id); if (!oid) continue;
    by.set(oid,model.merge(by.get(oid) || {},model.flat(row)));
  }
  let matched = 0, updated = 0;
  for (const code of defsFor(r).map(d=>d.code)) {
    const patch = [];
    for (const old of originals.filter(o=>o.metric === code)) {
      if (!by.has(old.order_id)) continue;
      matched++;
      const merged = (platformOf(r)==='SHOPEE'?OPShopee:OPDetails).merge(old,by.get(old.order_id));
      if (OPCore.orderChanged(old,merged)) { patch.push(merged); updated++; }
    }
    if (patch.length) await OPDB.put(r.id,code,patch);
  }
  r.details = summaryFor(r,await OPDB.list(r.id));
  if (updated) { dirty(r); r.capturedAt = new Date().toISOString(); }
  return {matched,updated,details:r.details};
}

async function startObservedPerformance(s) {
  const r=s.run;if(!r?.details?.total||platformOf(r)==='SHOPEE')return false;
  const status=(await askTab(r.tabId,{type:'SOURCE_DIAGNOSTIC'})).result?.status;
  const metric=r.metrics.find(m=>m.code===status?.metric);
  if(!status?.performanceReady||!metric?.scopeVerified||!status.period?.start||!status.period?.end||status.period.start!==metric.period_start||status.period.end!==metric.period_end)return false;
  const ids=[...new Set((await OPDB.list(r.id)).filter(o=>o.metric===metric.code&&!o.prior_window).map(o=>o.order_id))];
  if(!ids.length)return false;
  r.phase='enriching';r.detailTabId=r.tabId;r.detailError='';
  note(s,`Tự đọc bảng ${metric.code} đúng kỳ để bổ sung Actual handover time.`);await save(s);
  try{await askTab(r.tabId,{type:'ENRICH_ORDERS',runId:r.id,shopId:r.shopId,orderIds:ids,mode:'performance',code:metric.code,period:{start:metric.period_start,end:metric.period_end}});}
  catch(e){r.phase='done';await save(s);throw e;}
  return true;
}

async function handle(m, sender) {
  const { state: s, settings } = await read();
  const fromTab = !!sender.tab && !String(sender.url || '').startsWith(chrome.runtime.getURL(''));
  if (m.type === 'GET') {
    if (fromTab) return { run: s.run?.tabId === sender.tab.id ? s.run : null };
    if (s.run && !s.run.details) s.run.details = summaryFor(s.run,await OPDB.list(s.run.id));
    return { state: s, settings, pending: pendingSummary(s), connectionError: keyError(settings), stores: await knownStores(s), version: VERSION };
  }
  if (m.type === 'IDENTITY' && fromTab) { m.identity=withShopCode({...m.identity,platform:tabPlatform(sender.url||sender.tab.url)});s.detected[sender.tab.id] = { ...m.identity, at: Date.now() }; await save(s);try{await resumeNavigation(s,sender.tab.id);await OPAuto.tick(s,sender.tab.id);await OPAuto.maybeStart(s,settings,sender.tab.id,m.identity);}catch(e){note(s,'Chưa tự chạy: '+e.message);await save(s);} return { ok: true }; }
  if (m.type === 'DETECT') { try{const id = await detect(m.tabId); s.detected[m.tabId] = { ...id, at: Date.now() }; await save(s);if(settings.autoStart)await OPAuto.maybeStart(s,settings,m.tabId,id);return { identity: id };}catch(e){delete s.detected[m.tabId];await save(s);throw e;} }
  if(fromTab && ['COLLECT_SNAPSHOT','COLLECT_BATCH','COLLECTED','COLLECT_FAILED'].includes(m.type) && s.run?.id===m.runId && (s.run.navigation || s.run.collectTaskId && s.run.collectTaskId!==m.taskId))return {ok:false};
  if (m.type === 'PROGRESS' && fromTab) { if (s.run?.id === m.runId && [s.run.tabId,s.run.detailTabId].includes(sender.tab.id)) { s.run.lastActivityAt=Date.now();note(s, m.msg); await save(s); } return { ok: true }; }
  if(m.type==='COLLECT_SNAPSHOT'&&fromTab){const r=s.run;if(r?.id!==m.runId||r.tabId!==sender.tab.id||r.phase!=='collecting'||platformOf(r)!=='SHOPEE'||r.shopId!==m.shopId)return {ok:false};r.shopeeIgnoredCodes=[];await applyShopeeCollected(s,{identity:{shopId:m.shopId,platform:'SHOPEE'},metrics:m.metrics});r.phase='collecting';await save(s);return {ok:true};}
  if(m.type==='COLLECT_BATCH'&&fromTab){const r=s.run;if(r?.id!==m.runId||r.phase!=='collecting'||r.tabId!==sender.tab.id||platformOf(r)!=='SHOPEE'||m.shopId!==r.shopId||!OPShopee.metric(m.metric)||r.shopeeIgnoredCodes?.includes(m.metric))return {ok:false};if(!Array.isArray(m.rows)||m.rows.length>5000)throw Error('Shopee batch quá lớn.');const rows=m.rows.filter(o=>OPShopee.id(o.order_id)&&['API_FAILURE_LIST','API_FAILURE_FLAG','DOM_FAILURE_ROW'].includes(o.evidence));await OPDB.put(r.id,m.metric,rows);r.details=summaryFor(r,await OPDB.list(r.id));r.lastActivityAt=Date.now();dirty(r);note(s,m.msg);await save(s);return {ok:true};}
  if (m.type === 'COLLECTED' && fromTab) {
    if (s.run?.id !== m.runId || sender.tab.id !== s.run.tabId || s.run.closed || s.run.phase !== 'collecting') return { ok: false };
    await applyCollected(s, settings, m.data); await save(s);
    if(s.run.phase==='done' && s.run.autoAll){try{await OPAuto.begin(s);}catch(e){await OPAuto.finish(s,'Luồng tự động dừng: '+e.message);}return {ok:true,automatic:true};}
    if(s.run.phase==='done'){
      try{if(await startObservedPerformance(s))return {ok:true,readingPerformance:true};}
      catch(e){note(s,'Chưa tự đọc bảng hiệu suất: '+e.message);await save(s);}
    }
    if(s.run.phase==='done'&&s.run.details.total&&!s.run.details.counts.actual_handover_at){note(s,'Danh sách lỗi đã lấy; Actual handover time chưa có. Mở bảng hiệu suất đúng kỳ rồi Lấy mốc từ bảng đang mở trước khi kết thúc store.');await save(s);}
    if (s.run.phase === 'done' && settings.autoSync && settings.endpoint) await enqueueAndSync(s);
    return { ok: true };
  }
  if (m.type === 'COLLECT_FAILED' && fromTab) { if (s.run?.id === m.runId && sender.tab.id===s.run.tabId && s.run.phase==='collecting') { if(platformOf(s.run)==='SHOPEE'&&(s.run.metrics.some(k=>k.source)||(await OPDB.list(s.run.id)).length)){s.run.phase='done';s.run.captureNotes=[...(s.run.captureNotes||[]),m.error];s.run.shopeeSecondaryAttempted=true;await OPAuto.begin(s);}else{s.run.phase='error';note(s,'Lỗi lấy dữ liệu: '+m.error);await save(s);} } return { ok: true }; }
  if (m.type === 'DETAILS_BATCH' && fromTab) {
    if (s.run?.id !== m.runId || sender.tab.id !== s.run.detailTabId || s.run.phase !== 'enriching' || m.shopId !== s.run.shopId) return {ok:false};
    if(s.run.workflow?.active && s.run.detailTaskId!==m.taskId)return {ok:false};
    if (!Array.isArray(m.rows) || m.rows.length > 100) throw Error('Batch chi tiết không hợp lệ.');
    await applyDetailRows(s,m.rows);s.run.lastActivityAt=Date.now(); note(s,m.msg); await save(s); return {ok:true};
  }
  if (['DETAILS_DONE','DETAILS_FAILED'].includes(m.type) && fromTab) {
    if (s.run?.id !== m.runId || sender.tab.id !== s.run.detailTabId || s.run.phase !== 'enriching') return {ok:false};
    if(s.run.workflow?.active && s.run.detailTaskId!==m.taskId)return {ok:false};
    s.run.phase = 'done';
    if (m.type === 'DETAILS_FAILED') { s.run.detailError = String(m.error || '').slice(0,600); note(s,'Chi tiết chưa xong: '+s.run.detailError); }
    else {
      if (m.result?.shopId !== s.run.shopId) throw Error('Store chi tiết không khớp.');
      s.run.detailError = ''; s.run.detailResult = m.result;
      note(s, m.result.handoverFound!=null ? `Đã đọc bảng: Actual handover time ${m.result.handoverFound}/${m.result.total} Order ID. ${m.result.note || 'Xem số liệu từng cột trong panel.'}` : `Đã kiểm tra ${m.result.total} đơn: ${m.result.found} có chi tiết; ${m.result.missing} chưa có. ${m.result.note || 'Xem số liệu từng cột trong panel.'}`);
    }
    await save(s);
    if(s.run.autoAll && s.run.workflow?.active){try{await OPAuto.done(s,m);}catch(e){await OPAuto.finish(s,'Luồng tự động dừng: '+e.message);}return {ok:true,automatic:true};}
    if (settings.autoSync && settings.endpoint && s.run.syncStatus !== 'ĐÃ LƯU') await enqueueAndSync(s);
    return {ok:true};
  }
  if (fromTab) return { ok: false };
  if(m.type==='REPORT_IMPORT'||m.type==='ENABLER_SUBMIT'){if(!Array.isArray(m.rows)||m.rows.length>(m.type==='ENABLER_SUBMIT'?1000:6000)||!m.rows.length)throw Error('File không có dữ liệu hợp lệ.');const remote=await post(settings,{action:'ping'});if(serverWarning(remote,'SHOPEE'))throw Error(serverWarning(remote,'SHOPEE'));if(!remote.enabler_submit||m.type==='REPORT_IMPORT'&&remote.enabler_schema!==2)throw Error('Cập nhật Code.gs + Dashboard.html v2.2.8 và triển khai Phiên bản mới trước khi nhập report Enabler.');return post(settings,{action:m.type==='ENABLER_SUBMIT'?'enabler_submit':'shopee_report',rows:m.rows,summary:m.type==='REPORT_IMPORT'?m.summary:undefined,report_schema:m.type==='REPORT_IMPORT'?2:undefined,source:String(m.source||'').slice(0,250)});}

  if(m.type==='AUTO_START'){await chrome.storage.local.set({settings:{...settings,autoStart:!!m.enabled}});return {ok:true};}
  if(m.type==='AUTO_TICK'){await OPAuto.tick(s,m.tabId);return {ok:true};}
  if(m.type==='RUN_ALL') {
    if(s.run && (['collecting','enriching'].includes(s.run.phase)||s.run.workflow?.active))throw Error('Đang tự lấy và lưu. Chờ thông báo hoàn tất.');
    const id=await detect(m.tabId);
    if(!m.refresh && platformOf(id)!=='SHOPEE' && sameShop(s.run,id) && s.run.phase==='done' && s.run.syncStatus!=='ĐÃ LƯU'){await OPAuto.resume(s,m.tabId);return {ok:true,resumed:true};}
    const exact=(await knownStores(s)).filter(x=>platformOf(x)===platformOf(id)&&String(x.shop_id||'')===id.shopId);
    const store=exact.length===1?exact[0]:m.store|| await autoStoreFor(s,id);
    if(!validCode(store?.channel_code,platformOf(id)) || !store.channel_name)throw Error('Chọn channel một lần cho store chưa có mapping.');
    if(s.run && !s.run.closed){if(s.run.phase==='done' && s.run.syncStatus!=='ĐÃ LƯU')await enqueueAndSync(s);s.run.closed=true;}
    return startCollect(s,settings,m.tabId,store,m.historyDays,true);
  }

  if (m.type === 'SETTINGS') {
    const u = new URL(m.settings.endpoint); if (u.protocol !== 'https:' || u.hostname !== 'script.google.com' || !/^\/macros\/s\/[^/]+\/exec$/.test(u.pathname)) throw Error('Dán URL Web App dạng https://script.google.com/macros/s/.../exec');
    const secret = String(m.settings.secret || '').trim(); if (secret.length < 24) throw Error('Khóa kết nối phải có ít nhất 24 ký tự.');
    return connectAndRetry(s, { ...settings, endpoint: u.href, secret, autoSync: !!m.settings.autoSync });
  }
  if (m.type === 'COLLECTOR') { await chrome.storage.local.set({ settings: { ...settings, collector: String(m.name || '').trim().slice(0, 80) } }); return { ok: true }; }
  if (m.type === 'CONNECT_CODE') {
    let c; try { const raw = String(m.code || '').trim().replace(/^OPTTS1\./, ''); c = JSON.parse(decodeURIComponent(escape(atob(raw)))); } catch { throw Error('Mã kết nối không đúng. Copy lại nguyên mã bắt đầu bằng OPTTS1.'); }
    const u = new URL(c.e || ''); if (u.protocol !== 'https:' || u.hostname !== 'script.google.com' || !/^\/macros\/s\/[^/]+\/exec$/.test(u.pathname) || String(c.s || '').trim().length < 24) throw Error('Mã kết nối thiếu URL Web App hoặc khóa.');
    return connectAndRetry(s, { ...settings, endpoint: u.href, secret: String(c.s).trim(), autoSync: true, dashboardUrl: c.d || settings.dashboardUrl || '' });
  }
  if (m.type === 'INVITE_CODE') { if (!settings.endpoint || !settings.secret) throw Error('Chưa kết nối Sheet nên chưa có mã để mời.'); return { code: 'OPTTS1.' + btoa(unescape(encodeURIComponent(JSON.stringify({ e: settings.endpoint, s: settings.secret, d: settings.dashboardUrl || '' })))) }; }
  if (m.type === 'VIEW_URL') { if (!settings.endpoint || !settings.secret) throw Error('Extension chưa kết nối Google Sheet. Vào Quản trị → Kết nối Google Sheet.'); if (settings.viewKey && settings.viewEndpoint === settings.endpoint && !m.renew) return { url: settings.endpoint + '?k=' + settings.viewKey }; const r = await post(settings, { action: 'share_create', scope: 'full', label: 'Extension · ' + (settings.collector || 'chưa đặt tên'), by: settings.collector }); if (!/^[a-f0-9]{16,64}$/i.test(String(r.key || ''))) throw Error('Apps Script chưa trả link xem.'); await chrome.storage.local.set({ settings: { ...settings, viewKey: r.key, viewEndpoint: settings.endpoint } }); return { url: settings.endpoint + '?k=' + r.key }; }
  if (m.type === 'SHARE_CREATE') { const r = await post(settings, { action: 'share_create', scope: m.scope, label: m.label, by: settings.collector }); return { ...r, url: settings.endpoint + '?k=' + r.key }; }
  if (m.type === 'SHARE_LIST') { const r = await post(settings, { action: 'share_list' }); return { links: (r.links || []).map(l => ({ ...l, url: settings.endpoint + '?k=' + l.key })) }; }
  if (m.type === 'SHARE_REVOKE') return post(settings, { action: 'share_revoke', key: m.key });
  if (m.type === 'DASHBOARD_URL') { const v = String(m.url || '').trim(); if (v) { const u = new URL(v); if (u.protocol !== 'https:' || !/^script\.google(usercontent)?\.com$/.test(u.hostname)) throw Error('Dán link Web App dashboard dạng https://script.google.com/macros/s/.../exec'); } await chrome.storage.local.set({ settings: { ...settings, dashboardUrl: v } }); return { ok: true }; }
  if (m.type === 'BEGIN') {
    if (s.run && ['collecting','enriching'].includes(s.run.phase)) throw Error('Đang lấy dữ liệu store hiện tại, chờ xong.');
    if (!/^TTK[A-Z0-9]+$/i.test(m.store?.channel_code || '') || !m.store.channel_name) throw Error('Chọn channel (code bắt đầu TTK).');
    if (s.run && !s.run.closed) {
      if (['collecting','enriching'].includes(s.run.phase)) throw Error('Đang lấy dữ liệu store hiện tại, chờ xong.');
      if (s.run.syncStatus === 'ĐÃ LƯU' || !s.run.metrics.some(x => x.source)) s.run.closed = true;
      else if (s.run.channel_code === m.store.channel_code) { if (s.run.phase === 'done' && s.run.syncStatus === 'CHƯA LƯU') await enqueueAndSync(s); s.run.closed = true; }
      else throw Error(`${s.run.channel_code} chưa lưu Sheet. Bấm "Lưu vào Performance" hoặc "Kết thúc & giữ cục bộ" trước khi đổi store.`);
    }
    return startCollect(s, settings, m.tabId, m.store,m.historyDays);
  }
  if (m.type === 'ENRICH') {
    if (!s.run || s.run.phase !== 'done') throw Error('Lấy xong danh sách đơn lỗi trước khi bổ sung chi tiết.');
    const id = await detect(m.tabId);
    if (!sameShop(id,s.run)) throw Error('Login đúng store '+s.run.channel_code+' để bổ sung chi tiết.');
    const rows = await OPDB.list(s.run.id), chosen=m.mode==='performance'?s.run.metrics.find(x=>x.code===m.code):null;
    if(m.mode==='performance'&&!chosen)throw Error('Chọn KPI của bảng hiệu suất đang mở.');
    const orderIds = [...new Set(rows.filter(o=>!chosen||o.metric===chosen.code&&!o.prior_window).map(o=>o.order_id))];
    if (!orderIds.length) throw Error('Store này chưa có đơn lỗi để bổ sung.');
    s.run.phase = 'enriching'; s.run.detailTabId = m.tabId; s.run.detailError = '';
    await save(s);
    try { await askTab(m.tabId,{type:'ENRICH_ORDERS',runId:s.run.id,shopId:s.run.shopId,orderIds,mode:m.mode,code:chosen?.code,period:chosen?{start:chosen.period_start,end:chosen.period_end}:null}); }
    catch(e) { s.run.phase='done';s.run.detailError=e.message;await save(s);throw e; }
    return {ok:true,total:orderIds.length};
  }
  if(m.type==='SOURCE_DIAGNOSTIC'){await sellerTab(m.tabId);const id=await detect(m.tabId);const r=await askTab(m.tabId,{type:'SOURCE_DIAGNOSTIC'});if(r.error)throw Error(r.error);return {shopId:id.shopId,shopName:id.shopName,...r.result};}
  if (m.type === 'DETAILS_IMPORT') {
    if (!s.run || s.run.phase !== 'done' || s.run.id !== m.runId || s.run.shopId !== m.shopId) throw Error('Phiên store đã đổi. Chọn lại file của store hiện tại.');
    if (!Array.isArray(m.rows) || m.rows.length > 200000) throw Error('File chi tiết không hợp lệ hoặc quá lớn. Chia file theo tháng.');
    const result = await applyDetailRows(s,m.rows);
    if (!result.matched) throw Error('File không có mã đơn nào khớp danh sách lỗi của '+s.run.channel_code+'. Không ghi dữ liệu.');
    note(s,`File đơn hàng: khớp ${result.matched} dòng theo KPI, bổ sung ${result.updated} dòng. Các đơn ngoài danh sách lỗi được bỏ qua.`);
    await save(s);
    const sync = settings.autoSync && settings.endpoint && result.updated ? await enqueueAndSync(s) : null;
    return {...result,sync};
  }
  if (m.type === 'SYNC') { if (!s.run) throw Error('Chưa có dữ liệu.'); if (s.run.phase !== 'done') throw Error('Chưa lấy xong dữ liệu.'); return enqueueAndSync(s); }
  if (m.type === 'CLOSE') { if (!s.run) return { ok: true }; if (s.run.syncStatus === 'CHƯA LƯU' && s.run.phase === 'done' && !m.keepLocal) throw Error('Chưa lưu Sheet. Lưu trước hoặc chọn "Kết thúc & giữ cục bộ".'); if (s.run.syncStatus === 'CHƯA LƯU' && s.run.phase === 'done' && m.keepLocal) await enqueueAndSync(s); s.run.closed = true; note(s, 'Đã kết thúc store. Logout và login store tiếp theo.'); await save(s); return { ok: true }; }
  if (m.type === 'EXPORT') { if (!s.run) throw Error('Chưa có phiên.'); return { run: s.run, orders: await OPDB.list(s.run.id) }; }
  if (m.type === 'EXPORT_BACKUP') {
    const ids = new Set([s.run?.id, ...s.outbox.map(j => j.run.id)].filter(Boolean)), orders = [];
    for (const id of ids) orders.push(...await OPDB.list(id));
    return { format: 'OP_TTS_BACKUP', version: 1, extensionVersion: VERSION, exportedAt: new Date().toISOString(), state: { run: s.run, outbox: s.outbox, daily: s.daily, history: s.history }, orders };
  }
  if (m.type === 'RETRY') return flushOutbox(s);
  if (m.type === 'TEST') { const remote = await post(settings, { action: 'ping' }); await chrome.storage.local.set({ settings: { ...settings, ...serverInfo(remote) } }); if (Array.isArray(remote.catalog)) { s.catalog = remote.catalog; await save(s); } return {...remote,warning:serverWarning(remote)}; }
  return { ok: false };
}
function weekVN() { const date = new Date(new Date().toLocaleString('en-US', { timeZone: 'Asia/Ho_Chi_Minh' })); const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate())); const day = d.getUTCDay() || 7; d.setUTCDate(d.getUTCDate() + 4 - day); const y = d.getUTCFullYear(); return y + '-W' + String(Math.ceil((((d - new Date(Date.UTC(y, 0, 1))) / 86400000) + 1) / 7)).padStart(2, '0'); }
// v2.2.17 — Apps Script đôi lúc trả trang HTML (quá tải / hết giờ phía Google) hoặc "Busy" khi nhiều máy gửi cùng lúc.
// Các lệnh ingest/finalize/daily/ping đều idempotent (server bỏ qua chunk đã nhận) → tự thử lại ngay tại chỗ, không đứng chờ 2 phút.
const RETRY_ACTIONS = new Set(['ping', 'ingest', 'finalize', 'daily']);
const RETRY_WAIT_MS = [4000, 10000, 20000];
function transientError_(e) { return !!e && (e.transient || /^(TimeoutError|AbortError|TypeError)$/.test(e.name || '') || /Busy\. Retry|Duplicate nonce|Service (Spreadsheets )?(timed out|unavailable|error)|Exceeded maximum|try again|Thử lại|Failed to fetch|NetworkError/i.test(e.message || '')); }
async function postOnce(settings, payload) {
  const body = JSON.stringify(payload), ts = Date.now(), nonce = crypto.randomUUID();
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(settings.secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const bytes = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(ts + '\n' + nonce + '\n' + body));
  const signature = [...new Uint8Array(bytes)].map(x => x.toString(16).padStart(2, '0')).join('');
  const heavy = ['ingest', 'finalize', 'daily', 'shopee_report', 'enabler_submit'].includes(payload.action);
  const response = await fetch(settings.endpoint, { method: 'POST', headers: { 'Content-Type': 'text/plain;charset=utf-8' }, body: JSON.stringify({ ts, nonce, body, signature }), redirect: 'follow', signal: AbortSignal.timeout(heavy ? 150000 : 60000) });
  const raw = await response.text(); let result;
  try { result = JSON.parse(raw); } catch {
    const title = (raw.match(/<title[^>]*>([^<]{0,80})/i) || [])[1] || '';
    const login = /accounts\.google\.com|ServiceLogin|signin/i.test(response.url + ' ' + raw.slice(0, 4000));
    const err = Error(login
      ? 'Web App đòi đăng nhập Google (trả trang login). Kiểm tra deployment: Execute as Me, Who has access: Anyone, URL kết thúc /exec.'
      : `Apps Script trả trang lỗi thay vì dữ liệu (HTTP ${response.status}${title ? ' · ' + title.trim() : ''}) — thường do Google quá tải/hết giờ xử lý. Tự thử lại.`);
    err.transient = !login; throw err;
  }
  if (!response.ok || !result.ok) {
    if (/^Invalid signature\.?$/i.test(result.error || '')) throw Error('Khóa kết nối không khớp Apps Script (Invalid signature). Lấy lại khóa hiện tại rồi Kết nối & gửi dữ liệu chờ.');
    const err = Error(result.error || `HTTP ${response.status}`); err.transient = response.status >= 500 || /Busy\. Retry|Duplicate nonce/i.test(result.error || ''); throw err;
  }
  return result;
}
async function post(settings, payload) {
  const invalid = keyError(settings); if (invalid) throw Error(invalid);
  const retry = RETRY_ACTIONS.has(payload.action);
  for (let attempt = 0; ; attempt++) {
    try { return await postOnce(settings, payload); }
    catch (e) { if (!retry || attempt >= RETRY_WAIT_MS.length || !transientError_(e)) throw e; await new Promise(r => setTimeout(r, RETRY_WAIT_MS[attempt])); }
  }
}
// v2.2.17 — Phần gửi lớn hơn khi Apps Script hỗ trợ (max_chunk), có chặn dung lượng để không vượt giới hạn 2 MB/lần gửi.
function orderChunks_(rows, settings) {
  const max = Math.max(1, Math.min(Number(settings?.serverMaxChunk) || 500, 1500)), maxBytes = 800000, out = [];
  let cur = [], bytes = 0;
  for (const row of rows) { const b = JSON.stringify(row).length + 1; if (cur.length && (cur.length >= max || bytes + b > maxBytes)) { out.push(cur); cur = []; bytes = 0; } cur.push(row); bytes += b; }
  if (cur.length) out.push(cur);
  return out;
}
async function enqueueAndSync(s) {
  // v2.2.9 — Shopee: ghép các tuần "FHR tính lại (xét nhãn Mall)" đã đọc của đúng Shop ID (appeal-background.js) vào lịch sử ngày.
  if (typeof mergeFhrRecalc_ === 'function' && await mergeFhrRecalc_(s).catch(() => 0)) dirty(s.run);
  const existing = s.outbox.find(j => j.run.id === s.run.id && (j.run.dataVersion || 0) === (s.run.dataVersion || 0));
  if (existing) return flushOutbox(s);
  if (s.run.syncStatus === 'ĐÃ LƯU') return { ok: true, alreadySaved: true };
  const rows = await OPDB.list(s.run.id), r = s.run; const revision = (r.revision || 0) + 1; r.revision = revision;
  for (const a of r.metrics) { a.count = rows.filter(o => o.metric === a.code && !o.prior_window).length; a.prior_count = rows.filter(o => o.metric === a.code && o.prior_window).length; a.coverage = a.skipped ? 'ĐẠT · BỎ QUA ĐƠN' : platformOf(r)==='SHOPEE'&&!['NFR','LSR','FHR'].includes(a.code)?'KPI · KHÔNG CÓ DANH SÁCH ĐƠN':a.listComplete === false ? 'CHƯA ĐỦ DANH SÁCH' : OPCore.completeness(a,a.count); }
  const uploadId = r.id + '-r' + revision; const chunks = orderChunks_(rows, (await read()).settings); if (!chunks.length) chunks.push([]);
  const daily = s.daily?.[r.id] || [], dailyChunks = []; for (let i = 0; i < daily.length; i += 500) dailyChunks.push(daily.slice(i, i + 500));
  const job = { id: uploadId, run: JSON.parse(JSON.stringify(r)), chunks, next: 0, dailyChunks, dailyNext: 0, finalized: false, createdAt: new Date().toISOString() };
  // v2.2.17 — Lấy lại cùng store khi lượt cũ còn đang gửi dở: gửi bản MỚI trước (Sheet giữ dữ liệu mới nhất theo thời điểm lấy),
  // lượt cũ vẫn giữ và gửi sau — Code.gs không cho bản cũ ghi đè bản mới.
  const stale = s.outbox.some(j => !j.finalized && j.run.shopId === r.shopId && platformOf(j.run) === platformOf(r));
  if (stale) { s.outbox.unshift(job); note(s, `${r.channel_code}: còn lượt gửi cũ dở dang — gửi bản mới trước, bản cũ gửi sau.`); } else s.outbox.push(job);
  r.syncStatus = 'CHỜ GỬI'; await save(s); return flushOutbox(s);
}
// v2.2.17 — Không giữ hàng đợi xử lý quá lâu: mỗi lượt gửi tối đa ~75 giây rồi nhường cho panel (nút bấm, đổi store),
// sau đó tự gửi tiếp phần còn lại. Trước đây store nhiều đơn (66 phần × ~20 giây) khóa toàn bộ panel nhiều phút → "treo".
const FLUSH_BUDGET_MS = 75000;
const overBudget_ = (started, sent) => sent > 0 && Date.now() - started > (globalThis.OP_FLUSH_BUDGET_MS || FLUSH_BUDGET_MS); // luôn gửi được ít nhất 1 phần mỗi lượt
let flushTimer = null;
async function continueFlush_(s, job) {
  await save(s);
  clearTimeout(flushTimer);
  flushTimer = setTimeout(() => mutate(async () => { const { state } = await read(); if (state.outbox.length) await flushOutbox(state); }).catch(() => {}), 800);
  return { ok: false, queued: true, continuing: true, sent: job.next, total: job.chunks.length };
}
async function flushOutbox(s) {
  const { settings } = await read();
  if (!s.outbox.length) return { ok: true, empty: true };
  const invalid = keyError(settings);
  if (invalid) { if (s.log.at(-1)?.msg !== invalid) note(s, invalid); await save(s); return { ok: false, queued: true, error: invalid }; }
  const started = Date.now(); let sentNow = 0;
  while (s.outbox.length) {
    const job = s.outbox[0];
    try {
      if(platformOf(job.run)==='SHOPEE'||job.chunks.some(chunk=>chunk.some(row=>['actual_handover_at','shipping_location','delivery_type','pickup_type','is_preorder','sla_rule'].some(k=>!!row[k])))) {
        const remote=await post(settings,{action:'ping'});
        await chrome.storage.local.set({settings:{...settings,...serverInfo(remote)}});
        if(serverWarning(remote,platformOf(job.run)))throw Error(serverWarning(remote,platformOf(job.run))+' Dữ liệu bổ sung vẫn được giữ trong hàng đợi.');
      }
      while (job.next < job.chunks.length) { if (overBudget_(started, sentNow)) return continueFlush_(s, job); await post(settings, { action: 'ingest', upload_id: job.id, chunk: job.next, chunk_count: job.chunks.length, run: job.run, orders: job.chunks[job.next] }); job.next++; sentNow++; note(s, `Gửi ${job.run.channel_code}: ${job.next}/${job.chunks.length} phần`); await save(s); }
      if (!job.finalized) { await post(settings, { action: 'finalize', upload_id: job.id, run: job.run, chunk_count: job.chunks.length }); job.finalized = true; await save(s); }
      while ((job.dailyNext || 0) < (job.dailyChunks || []).length) {
        if (overBudget_(started, sentNow)) return continueFlush_(s, job);
        try { await post(settings, { action: 'daily', upload_id: job.id, run: job.run, chunk_count: job.chunks.length, rows: job.dailyChunks[job.dailyNext] }); }
        catch (e) { if (/Unsupported action/i.test(e.message)) throw Error('KPI/đơn đã gửi, nhưng Apps Script chưa hỗ trợ lịch sử ngày. Lịch sử được giữ trong hàng đợi; cập nhật Code.gs rồi Gửi lại.'); throw e; }
        job.dailyNext++; sentNow++; note(s, `Lịch sử ngày ${job.run.channel_code}: ${job.dailyNext}/${job.dailyChunks.length} phần`);
        if (job.dailyNext === job.dailyChunks.length && (job.run.historyDays || 0) >= 180) s.history[bindingKey(job.run)] = new Date().toISOString();
        await save(s);
      }
      s.outbox.shift(); if (job.fhrOnly) { note(s, `Đã lưu FHR tính lại ${job.run.channel_code} lên Performance.`); await save(s); continue; }
      if (s.run?.id === job.run.id) s.run.syncStatus = (s.run.dataVersion || 0) === (job.run.dataVersion || 0) ? 'ĐÃ LƯU' : 'CHƯA LƯU';
      const d=job.run.details, pending=d?.total && ['created_at','actual_handover_at','shipping_location','delivery_type','pickup_type'].some(k=>(d.counts[k]||0)<d.total);
      if(s.run?.id===job.run.id && s.run.syncStatus==='ĐÃ LƯU' && s.run.workflow?.status==='queued' && !s.run.workflow.active){const w=s.run.workflow;w.status=pending||w.problems?.length?'partial':'saved';w.message=w.status==='partial'?'Đã tự lưu phần nhận được. Còn trường trống hoặc nguồn chưa đọc được.':'Đã tự lưu dữ liệu nhận được về Performance. Xem số đơn có dữ liệu ở từng cột bên dưới.';}
      note(s, `Đã lưu Sheet: ${job.run.channel_code}.` + (pending ? ` Actual handover ${d.counts.actual_handover_at||0}/${d.total} đơn; còn cột trống, xem bảng Chi tiết.` : '')); await save(s);
    } catch (e) { note(s, 'Chờ gửi lại: ' + e.message); if (s.run?.id === job.run.id) s.run.syncStatus = 'CHỜ GỬI'; await save(s); return { ok: false, queued: true, error: e.message }; }
  }
  return { ok: true };
}
// v2.2.0: one extension with the Ticket Assistant — answer only Performance message types so ticket/handover messages reach their own listeners.
const PERF_TYPES = new Set(['GET','BEGIN','CLOSE','COLLECTED','COLLECTOR','COLLECT_FAILED','COLLECT_SNAPSHOT','COLLECT_BATCH','CONNECT_CODE','DASHBOARD_URL','DETAILS_BATCH','DETAILS_DONE','DETAILS_FAILED','DETAILS_IMPORT','DETECT','ENRICH','EXPORT','EXPORT_BACKUP','IDENTITY','INVITE_CODE','PROGRESS','RETRY','SETTINGS','SHARE_CREATE','SHARE_LIST','SHARE_REVOKE','SYNC','TEST','VIEW_URL','AUTO_START','AUTO_TICK','REPORT_IMPORT','ENABLER_SUBMIT','RUN_ALL','SOURCE_DIAGNOSTIC']);
chrome.runtime.onMessage.addListener((m, sender, respond) => {
  if (sender.id !== chrome.runtime.id || !PERF_TYPES.has(m?.type)) return false;
  const page = !String(sender.url || '').startsWith(chrome.runtime.getURL(''));
  if (page && !(sender.tab && tabPlatform(sender.url||sender.tab.url))) return false;
  const task = m.type === 'GET' ? handle(m, sender) : mutate(() => handle(m, sender));
  task.then(respond, e => respond({ error: e.message })); return true;
});
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
chrome.alarms.create('op-retry', { periodInMinutes: 2 });
chrome.alarms.create('op-auto', { periodInMinutes: 0.5 });
chrome.alarms.onAlarm.addListener(a => { if(a.name==='op-auto')mutate(async()=>{const {state}=await read();await OPAuto.watch(state);}).catch(()=>{}); });
chrome.alarms.onAlarm.addListener(a => { if (a.name === 'op-retry') mutate(async () => { const { state } = await read(); if (state.outbox.length) await flushOutbox(state); }); });
chrome.tabs.onUpdated.addListener((tabId, change) => {
  if(change.status==='complete')setTimeout(()=>mutate(async()=>{const {state}=await read();await resumeNavigation(state,tabId);await OPAuto.tick(state,tabId);}).catch(()=>{}),1800);
  if (change.url && (tabPlatform(change.url)||/^https:\/\/accounts\.shopee\.vn\//.test(change.url)) && isLoginURL(change.url)) mutate(async () => {
    const { state } = await read(); delete state.detected[tabId];
    if (state.run && (state.run.tabId === tabId || state.run.detailTabId === tabId) && ['collecting','enriching'].includes(state.run.phase)) {
      state.run.navigation=null;state.run.phase=state.run.phase==='enriching'?'done':'error';
      note(state,'Đã logout giữa chừng. Giữ phần đã đọc; login lại đúng store để lấy tiếp.');
      if(state.run.autoAll){state.run.workflow ||= {active:true,problems:[],stage:'upload'};await OPAuto.finish(state,'Phiên đăng nhập thay đổi, đã dừng lấy thêm và giữ phần nhận được.');}
    }
    await save(state);
  });
});
chrome.tabs.onRemoved.addListener(tabId => mutate(async () => { const { state } = await read();if(state.run && (state.run.workflow?.active || state.run.navigation || state.run.autoAll && ['collecting','enriching'].includes(state.run.phase)) && [state.run.tabId,state.run.detailTabId].includes(tabId)){state.run.navigation=null;state.run.workflow ||= {active:true,problems:[],stage:'upload'};await OPAuto.finish(state,'Tab nguồn đã đóng; đã giữ dữ liệu đọc được.');} if (state.detected[tabId]) { delete state.detected[tabId]; await save(state); } }));
