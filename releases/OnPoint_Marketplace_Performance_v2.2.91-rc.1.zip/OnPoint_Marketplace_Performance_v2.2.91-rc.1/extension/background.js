/* OnPoint Marketplace Performance v2.2.0 — một extension gồm 2 phần:
   perf-background.js   : lấy KPI / đơn lỗi TikTok Shop + Shopee, lưu Google Sheet Performance
   ticket-background.js : Ticket Assistant (ticket pickup, kháng nghị từng đơn, Ticket Master) — giữ nguyên văn bản v0.11.28
   Extension dùng key của Ticket Assistant (ID inalelipnbmnlnpbmefampanmimiiijb) để giữ lịch sử ticket, biên bản và native helper. */
importScripts('perf-background.js', 'performance-appeals.js', 'ticket-background.js', 'appeal-background.js', 'keepalive-background.js');
