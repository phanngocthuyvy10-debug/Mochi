/* MAIN world trên shopee.vn/m/tylegiaohangnhanhtinhlai: trang Shopee "Tỷ lệ giao hàng nhanh tính lại của shop trong tuần qua".
   Chỉ đọc: bắt JSON trang tự tải (fetch/XHR) và quét chữ trên trang. Không gọi API riêng, không thao tác.
   - Danh sách đơn trễ hạn bàn giao (order_sn, tối đa 20 đơn) + shop_id nếu có.
   - v2.2.9: tỷ lệ tính lại (dùng xét duyệt nhãn Mall) của "Chỉ số tuần trước" và "Chỉ số 2 tuần trước" kèm "Ngày cập nhật". */
(() => {
  if (window.__opFhrRecalc) return; window.__opFhrRecalc = true;
  const SN = /\b\d{6}[A-Z0-9]{8}\b/g, found = new Set(); let shopId = '', timer = 0, weeks = [], weeksSig = '';
  const flush = () => { clearTimeout(timer); timer = setTimeout(() => { if (found.size || weeks.length) window.postMessage({ type: 'OP_FHR_RECALC', orders: [...found], shopId, weeks, username: account() }, location.origin); }, 600); };
  /* v2.2.18 — tài khoản đang đăng nhập shopee.vn (chỉ đọc chữ trên header / localStorage của chính trang, không gọi API): dùng để đối chiếu đúng shop. */
  const account = () => { try { const t = document.querySelector('.navbar__username')?.textContent?.trim(); if (t) return t.slice(0, 80); const j = JSON.parse(localStorage.getItem('@shopee/account-basic-info') || 'null'); return String(j?.username || '').slice(0, 80); } catch (_) { return ''; } };
  const walk = (o, d = 0) => { if (!o || typeof o !== 'object' || d > 8) return; if (Array.isArray(o)) { o.forEach(x => walk(x, d + 1)); return; }
    for (const [k, v] of Object.entries(o)) { if (/^(order_?sn|ordersn)$/i.test(k) && typeof v === 'string' && /^\d{6}[A-Z0-9]{6,14}$/.test(v)) found.add(v.toUpperCase());
      else if (/^shop_?id$/i.test(k) && /^\d{5,15}$/.test(String(v)) && !shopId) shopId = String(v); else if (v && typeof v === 'object') walk(v, d + 1); } };
  const take = t => { try { const before = found.size, sid = shopId; walk(JSON.parse(t)); if (found.size > before || shopId !== sid) flush(); } catch (_) {} };
  const f = window.fetch; window.fetch = async function (...a) { const r = await f.apply(this, a); try { if (/json/.test(r.headers.get('content-type') || '')) r.clone().text().then(take).catch(() => {}); } catch (_) {} return r; };
  const send = XMLHttpRequest.prototype.send; XMLHttpRequest.prototype.send = function (...a) { this.addEventListener('load', () => { try { if (typeof this.responseText === 'string' && this.responseText[0] === '{') take(this.responseText); } catch (_) {} }); return send.apply(this, a); };
  /* Bảng trên trang: "Ngày cập nhật | 05/10/2026 | 28/09/2026" rồi "Tỷ lệ giao hàng nhanh tính lại (dùng để xét duyệt nhãn) | 94% | 95%".
     Cột 1 = tuần trước, cột 2 = 2 tuần trước. Chỉ nhận khi đọc được đủ cặp ngày + % hợp lệ. */
  /* Trang thật (10/2026): nhãn "Ngày cập nhật" / "Tỷ lệ … tính lại" là HÌNH; chỉ ngày và % là chữ, theo thứ tự cột
     "05/10/2026 · 92% · 28/09/2026 · 93%" (tuần trước rồi 2 tuần trước). Bố cục dạng bảng "ngày, ngày, %, %" vẫn đọc được.
     Lấy các token ngày / % đầu tiên kể từ ngày đầu tiên trên trang, ghép theo cột; chỉ nhận khi đủ cặp hợp lệ. */
  const readWeeks = (text) => {
    const toks = [...text.matchAll(/\b(\d{1,2})\/(\d{1,2})\/(20\d{2})\b|(?<![\d.,])(\d{1,3}(?:[.,]\d{1,2})?)\s*%/g)].slice(0, 16)
      .map(m => m[3] ? { d: `${m[3]}-${m[2].padStart(2, '0')}-${m[1].padStart(2, '0')}` } : { p: Number(m[4].replace(',', '.')) / 100 });
    const first = toks.findIndex(t => t.d); if (first < 0) return [];
    const seq = toks.slice(first, first + 4), dates = [], pcts = [];
    if (seq[1]?.p != null) { for (let i = 0; i + 1 < seq.length && dates.length < 2; i += 2) if (seq[i].d && seq[i + 1].p != null) { dates.push(seq[i].d); pcts.push(seq[i + 1].p); } }
    else for (const t of seq) { if (t.d && dates.length < 2 && !pcts.length) dates.push(t.d); else if (t.p != null && pcts.length < dates.length) pcts.push(t.p); }
    const out = [];
    dates.forEach((date, i) => { const v = pcts[i]; if (Number.isFinite(v) && v >= 0 && v <= 1) out.push({ date, value: Math.round(v * 10000) / 10000, label: i === 0 ? 'Chỉ số tuần trước' : 'Chỉ số 2 tuần trước' }); });
    return out;
  };
  const scan = () => {
    const text = document.body?.innerText || '', before = found.size;
    for (const m of text.match(SN) || []) found.add(m);
    const w = readWeeks(text), sig = JSON.stringify(w);
    if (w.length && sig !== weeksSig) { weeks = w; weeksSig = sig; flush(); }
    else if (found.size > before) flush();
  };
  addEventListener('DOMContentLoaded', () => { scan(); new MutationObserver(() => { clearTimeout(scan.t); scan.t = setTimeout(scan, 400); }).observe(document.body, { childList: true, subtree: true, characterData: true }); });
})();
