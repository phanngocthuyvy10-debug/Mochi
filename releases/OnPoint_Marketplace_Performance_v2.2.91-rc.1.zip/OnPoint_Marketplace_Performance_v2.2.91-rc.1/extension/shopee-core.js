/* Shopee data model. Values and thresholds come from the source, not policy guesses. */
(function(root){
 'use strict';
 const norm=v=>String(v??'').replace(/([a-z\d])([A-Z])/g,'$1 $2').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/gi,'d').toLowerCase().replace(/[_-]+/g,' ').replace(/\s+/g,' ').trim();
 const defs=[
  {code:'NFR',name:'Tỷ lệ đơn hàng không thành công',unit:'rate',aliases:['ty le don khong thanh cong','nfr','non fulfillment rate','non fulfilment rate','nonfulfillment rate','ty le don hang khong thanh cong']},
  {code:'LSR',name:'Tỷ lệ giao hàng trễ',unit:'rate',aliases:['ty le giao tre','lsr','late shipment rate','late shipping rate','ty le giao hang tre']},
  {code:'FHR',name:'Tỷ lệ giao hàng nhanh',unit:'rate',aliases:['fhr','fast handover rate','fast shipping rate','ty le giao hang nhanh']},
  {code:'SPH',name:'Bàn giao bưu kiện thứ Bảy',unit:'count',aliases:['sph','saturday parcel handover','sat parcel','ban giao buu kien thu bay']},
  {code:'PP',name:'Điểm phạt Sao Quả Tạ',unit:'points',aliases:['pp','penalty points','penalty point','diem phat','diem sao qua ta']},
  {code:'CRR',name:'Tỷ lệ phản hồi chat',unit:'rate',aliases:['crr','chat response rate','ty le phan hoi chat']},
  {code:'APT',name:'Thời gian chuẩn bị hàng',unit:'days',aliases:['thoi gian chuan bi hang trung binh','apt','average preparation time','average processing time','processing time','thoi gian chuan bi hang']},
  {code:'PREORDER_RATE',name:'Tỷ lệ hàng đặt trước',unit:'rate',aliases:['preorder ratio','pre order percentage','preorder rate','pre order rate','pre order ratio','ty le hang dat truoc','ty le don hang dat truoc']}
 ];
 const metric=v=>defs.find(d=>d.aliases.some(a=>norm(a)===norm(v)))||null;
 const labelMetric=v=>{const n=' '+norm(v)+' ',hits=defs.filter(d=>d.aliases.some(a=>n.includes(' '+norm(a)+' ')));return hits.length===1?hits[0]:null;};
 const scalar=v=>typeof v==='string'||typeof v==='boolean'||typeof v==='number'&&Number.isFinite(v);
 function first(o,ks){for(const k of ks){const found=Object.keys(o||{}).find(x=>norm(x)===norm(k));if(found && scalar(o[found]))return o[found];}return null;}
 function id(v){if(typeof v==='number'&&!Number.isSafeInteger(v))return '';const x=String(v??'').trim().replace(/^'/,'');return /^\d{10,24}$/.test(x)||/^\d{6}[A-Z0-9]{5,20}$/.test(x)?x:'';}
 function shopId(v){if(typeof v==='number'&&!Number.isSafeInteger(v))return '';return /^\d{5,24}$/.test(String(v??''))?String(v):'';}
 function value(v,unit,sourceUnit){if(v==null||v===''||/^(?:[-–—]+|n\/a)$/i.test(String(v).trim()))return null;const raw=String(v).trim().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/gi,'d').toLowerCase();const m=raw.replace(',','.').match(/^(\d+(?:\.\d+)?(?:e[-+]?\d+)?)(?:\s*(%|points?|diem|ngay|days?|hours?|gio|minutes?|phut|seconds?|giay|milliseconds?|don|orders?|parcels?|buu kien))?$/);if(!m)return null;const n=Number(m[1]),u=norm(m[2]||sourceUnit||'');let x=n;
  if(unit==='rate'){if(['%','percent','percentage'].includes(u))x=n/100;else if(u&&!['rate','ratio','fraction'].includes(u))return null;return Number.isFinite(x)&&x<=1?x:null;}
  if(unit==='days'){if(/^(?:hours?|gio)$/.test(u))x=n/24;else if(/^(?:minutes?|phut)$/.test(u))x=n/1440;else if(/^(?:seconds?|giay)$/.test(u))x=n/86400;else if(/^milliseconds?$/.test(u))x=n/86400000;else if(u&&!/^(?:days?|ngay)$/.test(u))return null;}
  if(unit==='points'&&u&&!/^(?:points?|diem)$/.test(u))return null;if(unit==='count'&&u&&!/^(?:count|don|orders?|parcels?|buu kien)$/.test(u))return null;return Number.isFinite(x)?x:null;
 }
 function day(v){const m=String(v||'').match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);if(m){const d=m[3]+'-'+m[2].padStart(2,'0')+'-'+m[1].padStart(2,'0');return Number.isFinite(Date.parse(d+'T00:00:00Z'))?d:'';}if(/^\d{4}-\d{2}-\d{2}$/.test(String(v||'')))return String(v);const t=root.OPDetails?.time(v);return /^\d{4}-\d{2}-\d{2}/.test(t||'')?t.slice(0,10):'';}
 function threshold(v,unit){const m=String(v||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/gi,'d').match(/(>=|<=|≥|≤|>|<)\s*(-?\d+(?:[.,]\d+)?)\s*(%|points?|diem|ngay|days?|hours?|gio|minutes?|phut|seconds?|giay|parcels?|buu kien)?/i);if(!m)return null;const target=value(m[2]+(m[3]||''),unit,m[3]);return target==null?null:{direction:m[1].replace('≥','>=').replace('≤','<='),target,source:'SELLER_CENTER'};}
 function period(o){return {start:day(first(o,['period_start','start_date','start_time','from_date'])),end:day(first(o,['period_end','end_date','end_time','to_date']))};}
 function identity(payload){const all=new Map();walk(payload,(o,path)=>{const isShop=/\.(?:shop|shop_info|shopinfo|profile)$/.test(path);const sid=shopId(first(o,['shop_id','shopid'])||(isShop?first(o,['id']):null)),name=first(o,['shop_name','shopname'])||(/\.(?:data|shop|shop_info|shopinfo|profile)$/.test(path)?first(o,['name']):null);if(sid&&name)all.set(sid,{shopId:sid,shopCode:sid,shopName:String(name).slice(0,250),platform:'SHOPEE'});});return all.size===1?[...all.values()][0]:null;}
 function walk(payload,fn){let nodes=0;function visit(o,path,depth){if(!o||typeof o!=='object'||depth>14||++nodes>100000)return;if(Array.isArray(o)){for(const x of o)visit(x,path+'[]',depth+1);return;}fn(o,path);for(const [k,v]of Object.entries(o))if(v&&typeof v==='object'&&!/^(?:buyer|recipient|recipient_address|address|payment|price|line_items|products|skus)$/i.test(k)&&!(k==='items'&&id(first(o,['order_id','orderid','order_sn','ordersn']))))visit(v,path+'.'+k,depth+1);}visit(payload,'$',0);}
 function metrics(payload,includeDated=false){const out=new Map(),periods=new Map();walk(payload,(o,path)=>{
  if(!includeDated&&(/history|trend|chart|time_series|points/.test(path)||day(first(o,['date','report_date','stat_date','day','timestamp']))&&!period(o).start&&!period(o).end))return;
  let p=period(o);if(!p.start&&!p.end){let parent=path;while(parent.includes('.')){parent=parent.slice(0,parent.lastIndexOf('.'));if(periods.has(parent)){p=periods.get(parent);break;}}}periods.set(path,p);const named=metric(first(o,['metric_name','metric_code','indicator_name','name','code','metric']))||metric(path.split('.').pop().replace(/\[\]/g,''));
  function add(d,v,unit){const n=value(v,d.unit,unit);if(n==null)return;const t=first(o,['target_value','target','threshold_value']),direction=first(o,['comparator','direction','target_direction']);const bound=value(t,d.unit,unit);const th=bound!=null&&['>=','>','<=','<'].includes(direction)?{direction,target:bound,source:'SELLER_CENTER'}:threshold(first(o,['target_text','threshold_text','requirement']),d.unit);
   out.set(d.code,{code:d.code,name:d.name,unit:d.unit,value:n,raw:String(v),threshold:th,period_start:p.start,period_end:p.end,source:'SHOPEE_OBSERVED_API',expected:count(first(o,['failed_order_count','error_order_count','late_order_count'])),denominator:count(first(o,['eligible_order_count','total_order_count'])),orders:[],linesFetched:0,lineTotal:null});}
  if(named)add(named,first(o,['actual_value','metric_value','rate','value','percentage']),first(o,['unit','value_unit']));
  for(const [k,v]of Object.entries(o)){const d=metric(k);if(d&&scalar(v))add(d,v,/percent|percentage/i.test(k)?'percent':first(o,['unit','value_unit']));}
 });return [...out.values()];}
 function historyRows(payload,code){const rows=[];walk(payload,o=>{const date=day(first(o,['date','report_date','stat_date','day','timestamp']));if(!date)return;let ms=metrics(o,true);if(!ms.length&&metric(code)){const d=metric(code),v=value(first(o,['value','rate','metric_value']),d.unit,first(o,['unit','value_unit']));if(v!=null)ms=[{code:d.code,value:v}];}for(const m of ms)rows.push({date,metric:m.code,value:m.value,window_start:m.period_start||'',window_end:m.period_end||'',source:'SHOPEE_OBSERVED_HISTORY'});});return rows;}
 function count(v){if(typeof v!=='number'&&typeof v!=='string')return null;const n=Number(v);return v!=null&&v!==''&&Number.isSafeInteger(n)&&n>=0?n:null;}
 const extra={confirmed_at:['confirmed_at','confirm_time','order_confirm_time','Thời gian xác nhận đơn'],first_attempt_at:['first_attempt_at','first_delivery_attempt_time','Thời gian giao lần đầu'],estimated_delivery_at:['estimated_delivery_at','estimated_delivery_time','Thời gian giao hàng dự kiến']};
 function flat(o){const out=root.OPDetails.flat(o);for(const [field,aliases]of Object.entries(extra)){const t=root.OPDetails.time(first(o,aliases));if(t)out[field]=t;}const internal=id(first(o,['order_id','orderid'])),sn=id(first(o,['order_sn','ordersn','Mã đơn hàng']));if(internal)out.platform_order_id=internal;if(sn)out.order_sn=sn;return out;}
 function orders(payload,context){const found=new Map();const code=context?.code;walk(payload,(o,path)=>{
  const oid=id(first(o,['order_sn','ordersn','Mã đơn hàng']))||id(first(o,['order_id','orderid','Order ID']));if(!oid)return;
  const marked=first(o,['is_failed','failed','is_violation','is_late','seller_fault']);const negative=code==='FHR'&&first(o,['is_fast_handover','fast_handover_success'])===false;
  const reason=first(o,['violation_reason','failure_reason','fail_reason']);const scope=/(?:failed|failure|defective|error|late|non_?fulfil(?:l)?ment)[ _-]*(?:orders?|list)/i.test(path)||context?.failureConfirmed;
  if(!scope && !(marked===true||marked===1||negative||reason))return;
  const row={order_id:oid,...flat(o),reason:String(reason||first(o,['cancel_reason','return_reason'])||''),evidence:scope?'API_FAILURE_LIST':'API_FAILURE_FLAG'};
  // Logistics children can extend this actual order, while buyer/payment branches are excluded.
  walk(o,(child,path)=>{if(child===o)return;const own=id(first(child,['order_sn','ordersn','order_id','orderid']));if(own&&![oid,row.platform_order_id].includes(own))return;const f=flat(child);delete f.created_at;delete f.status;delete f.platform_order_id;delete f.order_sn;Object.assign(row,f);});
  found.set(oid,{...(found.get(oid)||{}),...row});
 });return [...found.values()];}
 function detail(payload,target){const by=new Map();walk(payload,o=>{const oid=id(first(o,['order_sn','ordersn']))||id(first(o,['order_id','orderid']));if(!oid)return;const row={order_id:oid,...flat(o)};walk(o,child=>{if(child===o)return;const own=id(first(child,['order_sn','ordersn','order_id','orderid']));if(own&&![oid,row.platform_order_id].includes(own))return;const f=flat(child);delete f.created_at;delete f.status;delete f.platform_order_id;delete f.order_sn;Object.assign(row,f);});by.set(oid,row);});return target?by.get(target)||null:[...by.values()];}
 function merge(a,b){const out=root.OPDetails.merge(a,b);for(const k of [...Object.keys(extra),'platform_order_id','order_sn'])if(b?.[k])out[k]=b[k];return out;}
 function summary(rows){const by=new Map();for(const r of rows||[])if(id(r.order_id))by.set(r.order_id,{...(by.get(r.order_id)||{}),...r});const vals=[...by.values()],fields=[...root.OPDetails.required,...Object.keys(extra)];return {total:vals.length,withDetails:vals.filter(r=>fields.some(k=>k!=='created_at'&&r[k])).length,counts:Object.fromEntries(fields.map(k=>[k,vals.filter(r=>!!r[k]).length]))};}
 function fromTable(table){const start=table.findIndex(row=>row.some(h=>/^(?:ma don hang|order id|order sn|order number)$/.test(norm(h))));if(start<0)throw Error('Không có cột mã đơn Shopee.');const headers=table[start];return table.slice(start+1).map(row=>{const o=Object.fromEntries(headers.map((h,i)=>[h,row[i]])),oid=id(first(o,['Mã đơn hàng','Order ID','Order SN','Order Number']));if(!oid)return null;return {order_id:oid,...flat(o)};}).filter(Boolean);}
 // Program weeks are Monday scorecards. Week 1 starts on the first Monday ON/AFTER the quarter start.
 function enablerPeriod(date){const d=day(date),t=Date.parse(d+'T00:00:00Z');if(!d||!Number.isFinite(t))throw Error('Ngày báo cáo không hợp lệ.');const dt=new Date(t),year=dt.getUTCFullYear(),quarter=Math.floor(dt.getUTCMonth()/3)+1;
  const first=new Date(Date.UTC(year,(quarter-1)*3,1));first.setUTCDate(first.getUTCDate()+(8-first.getUTCDay())%7);
  const week=Math.floor((t-first.getTime())/(7*86400000))+1;
  if(dt.getUTCDay()!==1||week<1||week>13)throw Error('Ngày scorecard phải là thứ Hai trong 13 tuần của quý.');
  return {year,quarter,week,totalWeeks:13,periodStart:d,periodEnd:new Date(t+6*86400000).toISOString().slice(0,10)};}
 function reportBundle(book,date){const table=book.Summary;if(!table||norm(table[1]?.[0])!=='shopid'||norm(table[2]?.[11])!=='nfr')throw Error('Chọn file OnPoint_summary gốc có sheet Summary.');
  const serialDate=v=>typeof v==='number'&&v>=30000&&v<80000?new Date(Date.UTC(1899,11,30)+Math.floor(v)*86400000).toISOString().slice(0,10):v instanceof Date?v.toISOString().slice(0,10):day(v);
  const markerDates=table.filter(r=>!shopId(r[0])).map(r=>serialDate(r[2])).filter(Boolean).sort(),asOf=markerDates.at(-1)||day(date);
  enablerPeriod(asOf);
  const opCodes=['NFR','LSR','FHR','SPH','PP','CRR'],engCodes=['ENB_FLASH','ENB_VOUCHER_DAYS','ENB_ADS_USD','ENB_PROMO_DAYS','ENB_DECO','ENB_VIDEO'];
  const finite=v=>typeof v==='number'&&Number.isFinite(v)?v:null,rows=[],summaries=[];let aggregation='QTD',at=asOf,thresholds={},ids=new Set(),total=null;
  const flush=()=>{if(!ids.size)return;const per=enablerPeriod(at);summaries.push({date:at,aggregation,...per,scorecardDate:asOf,operational_score:finite(total?.[4]),engagement_score:finite(total?.[18]),shopCount:ids.size,metric_scores:Object.fromEntries([...opCodes,...engCodes].map((k,j)=>[k,finite(total?.[j<6?5+j:19+j-6])]))});ids=new Set();total=null;};
  for(let i=3;i<table.length;i++){const r=table[i];if(norm(r[2])==='quarter to date'){flush();aggregation='QTD';at=asOf;thresholds={};continue;}
   const marker=!shopId(r[0])?serialDate(r[2]):'';if(marker){flush();aggregation='WEEKLY';at=marker;thresholds={};continue;}
   if(norm(r[1]).includes('scoring thresholds')){thresholds=Object.fromEntries([...opCodes,...engCodes].map((k,j)=>[k,String(r[j<6?11+j:25+j-6]||'')]));continue;}
   const sid=shopId(r[0]);if(!sid){if(finite(r[4])!=null||finite(r[18])!=null)total=r;continue;}if(!r[1])continue;
   ids.add(sid);const per=enablerPeriod(at);if(per.year!==enablerPeriod(asOf).year||per.quarter!==enablerPeriod(asOf).quarter)throw Error('File Summary chứa tuần khác quý. Tách file theo quý trước khi nhập.');
   const common={shopId:sid,shopName:String(r[1]),date:at,aggregation,...per,scorecardDate:asOf,operational_score:finite(r[4]),engagement_score:finite(r[18]),source:'SUPPLIED_SHOPEE_REPORT'};
   opCodes.forEach((code,j)=>{const d=defs.find(x=>x.code===code);rows.push({...common,metric:code,value:value(r[11+j],d.unit,code==='CRR'?'percent':''),score:finite(r[5+j]),unit:d.unit,threshold:thresholds[code]||''});});
   engCodes.forEach((code,j)=>{const raw=r[25+j],v=raw===''||raw==null?null:Number(raw);rows.push({...common,metric:code,value:v!=null&&Number.isFinite(v)&&v>=0?Math.round(v*1e4)/1e4:null,score:finite(r[19+j]),unit:code==='ENB_ADS_USD'?'usd':/DAYS/.test(code)?'days':'count',threshold:thresholds[code]||''});});
  }flush();if(!rows.length)throw Error('Summary không có dữ liệu shop.');
  return {rows,summary:summaries,periods:[...new Map(summaries.map(r=>[r.year+'-Q'+r.quarter+'-W'+r.week,{year:r.year,quarter:r.quarter,week:r.week,date:r.date}])).values()]};}
 function report(book,date){return reportBundle(book,date).rows;}
 function submitList(book){const by=new Map(),key=v=>norm(v).replace(/[ _-]/g,'');
  for(const table of (book.Summary?[book.Summary]:Object.values(book))){if(!Array.isArray(table))continue;const header=table.findIndex(row=>row.some(h=>/^(shopid|sellerid)$/.test(key(h))));if(header<0)continue;const hs=table[header],idCol=hs.findIndex(h=>/^(shopid|sellerid)$/.test(key(h))),nameCol=hs.findIndex(h=>/^(shopname|sellername|tenshop|tengianhang)$/.test(key(h)));if(nameCol<0)continue;
   for(const row of table.slice(header+1)){const sid=shopId(row[idCol]);if(!sid){if(row[idCol]!==''&&row[idCol]!=null&&/^\d/.test(String(row[idCol])))throw Error('Shop ID không hợp lệ hoặc bị Excel làm tròn.');continue;}const name=String(row[nameCol]||'').trim();if(!name||name.length>250)throw Error('Tên shop trống/quá dài trong list submit.');by.set(sid,{shopId:sid,shopName:name});}}
  if(!by.size)throw Error('Chọn file có cột Shop ID và Shop Name (hoặc sheet Summary của report Shopee).');return [...by.values()];}
 root.OPShopee={defs,norm,metric,labelMetric,id,shopId,value,day,period,threshold,identity,metrics,orders,detail,summary,flat,merge,fromTable,report,reportBundle,enablerPeriod,submitList,count,walk,first,historyRows};
 if(typeof module!=='undefined'&&module.exports)module.exports=root.OPShopee;
})(globalThis);
