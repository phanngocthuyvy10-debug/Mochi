/* OnPoint Marketplace Performance 2.2.19. Standalone Apps Script; do not replace the Ticket Assistant project.
   Web App #1 (Execute as Me, Anyone): extension upload.  Web App #2 (Execute as User accessing, Anyone with Google account): Dashboard. */
const PERFORMANCE_ID='1eE8vcNq23ys0_aTM4WJfjMD562rZlLdQk_e4inHc0Bg';
const HEADERS={
 TTS_Overview:['Channel Name','Channel Code','Warehouse','Shop ID','Shop Name','Captured At (UTC)','ISO Week (VN)','NDDR','FDR','LDR','SFCR','Instant LDR','Same-day LDR','KPI Status','Unique Error Orders','Detail Coverage','Run ID','Identity Source','Last Sync (UTC)','Collected By'],
 TTS_Metrics:['Key','Run ID','Captured At (UTC)','ISO Week (VN)','Channel Name','Channel Code','Warehouse','Shop ID','Metric','Metric Name','Rate','Rate Raw','Target','Comparator','Target Source','KPI Status','Period Start','Period End','Expected Error Orders','Eligible Orders','Captured Error Orders','Coverage','Pages','Source','Capture Note','Evaluation Period'],
 TTS_Orders:['Key','Shop ID','Channel Name','Channel Code','Warehouse','Metric','Order ID','Tracking ID','Order Status','Violation Reason','Created At','Paid At','Ready To Ship At','Pickup At','Delivered At','Deadline','Shipping Type','Carrier','Period Start','Period End','First Seen (UTC)','Last Seen (UTC)','Violation ID','Appeal Status','Evidence','Latest Run ID','Owner','Root Cause','Ops Fault','Ticket ID','Action Status','Review Notes','Actual Handover Time (Platform)','Shipping Location','Delivery Type','Pickup Type','Is Preorder','SLA Rule'],
 TTS_Stores:['Channel Name','Channel Code','Warehouse','Shop ID','Shop Name','Enabled','Last Collected (UTC)','Mapping Note'],
 TTS_Daily:['Key','Report Date','ISO Week','Channel Name','Channel Code','Warehouse','Shop ID','Shop Name','Metric','Metric Name','Value','Target','Comparator','KPI Status','Error Orders (window)','Window Start','Window End','Source','Updated (UTC)','Evaluation Period'],
 TTS_Sync_Log:['Upload ID','Run ID','Channel Code','Shop ID','Captured At (UTC)','Last Sync (UTC)','State','Chunk Count','Received Chunks','Orders in Upload','Detail Coverage','Collected By']
};
const SPE_CODES=['NFR','LSR','FHR','SPH','PP','CRR','APT','PREORDER_RATE'];
// Shopee-Certified Enabler Program report (OnPoint_summary.xlsx) — engagement metrics, stored only in SPE_Report.
const ENB_CODES=['ENB_FLASH','ENB_VOUCHER_DAYS','ENB_ADS_USD','ENB_PROMO_DAYS','ENB_DECO','ENB_VIDEO'];
const SPE_UNITS={NFR:'rate',LSR:'rate',FHR:'rate',SPH:'count',PP:'points',CRR:'rate',APT:'days',PREORDER_RATE:'rate',ENB_FLASH:'count',ENB_VOUCHER_DAYS:'days',ENB_ADS_USD:'usd',ENB_PROMO_DAYS:'days',ENB_DECO:'count',ENB_VIDEO:'count'};
const SPE_NAMES={NFR:'Tỷ lệ đơn hàng không thành công',LSR:'Tỷ lệ giao hàng trễ',FHR:'Tỷ lệ giao hàng nhanh',SPH:'Bàn giao bưu kiện thứ Bảy',PP:'Điểm phạt Sao Quả Tạ',CRR:'Tỷ lệ phản hồi chat',APT:'Thời gian chuẩn bị hàng',PREORDER_RATE:'Tỷ lệ hàng đặt trước'};
HEADERS.SPE_Stores=HEADERS.TTS_Stores.slice();
HEADERS.SPE_Overview=HEADERS.TTS_Overview.slice(0,7).concat(SPE_CODES,HEADERS.TTS_Overview.slice(13));
HEADERS.SPE_Metrics=HEADERS.TTS_Metrics.map(x=>x==='Rate'?'Value':x==='Rate Raw'?'Value Raw':x).concat(['Unit']);
HEADERS.SPE_Orders=HEADERS.TTS_Orders.concat(['Confirmed At','First Delivery Attempt At','Estimated Delivery At','Internal Order ID','Order SN']);
HEADERS.SPE_Daily=HEADERS.TTS_Daily.concat(['Unit']);
HEADERS.SPE_Sync_Log=HEADERS.TTS_Sync_Log.slice();
HEADERS.SPE_Report=['Key','Shop ID','Shop Name','Report Date','Aggregation','Metric','Value','Metric Score','Operational Score','Engagement Score','Unit','Source File','Imported (UTC)'];
HEADERS.SPE_Report=HEADERS.SPE_Report.concat(['Year','Quarter','Week In Quarter','Total Weeks','Period Start','Period End','Scorecard Date','Threshold']);
HEADERS.SPE_Enabler_Scorecards=['Key','Report Date','Aggregation','Year','Quarter','Week In Quarter','Total Weeks','Period Start','Period End','Operational Score','Engagement Score','Shop Count'].concat(['NFR','LSR','FHR','SPH','PP','CRR'].concat(ENB_CODES).map(c=>c+' Score'),['Source File','Imported (UTC)','Scorecard Date']);
HEADERS.SPE_Enabler_Submit=['Shop ID','Shop Name','Source File','Updated (UTC)'];
function platformSheets_(s,platform){if(platform!=='SHOPEE')return s;return Object.fromEntries(Object.keys(s).filter(n=>n.startsWith('SPE_')).map(n=>[n.replace(/^SPE_/,'TTS_'),s[n]]));}
/* v2.2.17 — nhận tối đa 2.000 đơn / phần: store nhiều đơn gửi ít lượt hơn (mỗi lượt tốn ~10–20 giây cố định cho mở file, kiểm master, đọc chỉ mục). Extension cũ vẫn gửi 500/phần. */
const MAX_CHUNK_ORDERS=2000;
function versionInfo_(){return {version:'2.2.19',max_chunk:MAX_CHUNK_ORDERS,enabler_schema:2,master_schema:1,enabler_submit:true,order_schema:3,appeal_tickets:1,platforms:['TIKTOK','SHOPEE'],order_fields:ORDER_FIELDS.concat(['confirmed_at','first_attempt_at','estimated_delivery_at','platform_order_id','order_sn'])};}
const CODES=['NDDR','FDR','LDR','SFCR','INSTANT_LDR','SAME_DAY_LDR'];
const DAILY_CODES=CODES.concat(['SHOP_SCORE']);
const ORDER_FIELDS=['created_at','actual_handover_at','shipping_location','delivery_type','pickup_type','paid_at','is_preorder','sla_rule','tracking_id','status','rts_at','pickup_at','delivered_at','deadline','carrier'];
const METRIC_NAMES={NDDR:'Tỷ lệ giao nhanh 24h',FDR:'Tỷ lệ gửi hàng nhanh',LDR:'Tỷ lệ gửi hàng muộn',SFCR:'Tỷ lệ hủy do lỗi người bán',INSTANT_LDR:'Gửi muộn đơn Hỏa tốc',SAME_DAY_LDR:'Gửi muộn đơn Trong ngày',SHOP_SCORE:'Điểm cửa hàng'};
function setupPerformance(){
 const p=PropertiesService.getScriptProperties();if(!p.getProperty('SYNC_SECRET'))p.setProperty('SYNC_SECRET',Utilities.getUuid().replace(/-/g,'')+Utilities.getUuid().replace(/-/g,''));
 const ss=SpreadsheetApp.openById(PERFORMANCE_ID);const sh={};Object.keys(HEADERS).forEach(n=>sh[n]=ensureSheet_(ss,n));migrateLatest_(sh);
 console.log('Khóa kết nối (chỉ dán vào extension): '+p.getProperty('SYNC_SECRET'));console.log('Sheet: '+ss.getName());
}
function rotateConnectionKey(){PropertiesService.getScriptProperties().setProperty('SYNC_SECRET',Utilities.getUuid().replace(/-/g,'')+Utilities.getUuid().replace(/-/g,''));setupPerformance();}
function upgradeEnablerSchema(){const lock=LockService.getScriptLock();if(!lock.tryLock(25000))throw Error('Busy. Retry.');try{const ss=SpreadsheetApp.openById(PERFORMANCE_ID);for(const n of ['SPE_Report','SPE_Enabler_Scorecards','SPE_Enabler_Submit'])ensureSheet_(ss,n);SpreadsheetApp.flush();console.log('Enabler v2.2.8 schema 2 ready. Existing reports and submit list preserved.');}finally{lock.releaseLock();}}
function doGet(e){if(e&&e.parameter&&e.parameter.ping)return json_({ok:true,service:'OnPoint Marketplace Performance',...versionInfo_()});
 const t=HtmlService.createTemplateFromFile('Dashboard');t.shareKey=String((e&&e.parameter&&e.parameter.k)||'').replace(/[^a-f0-9]/gi,'').slice(0,64);
 return t.evaluate().setTitle('Marketplace Performance · OnPoint').addMetaTag('viewport','width=device-width, initial-scale=1').setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);}
function doPost(e){let lock;try{
 if(!e||!e.postData||e.postData.contents.length>2000000)throw Error('Invalid payload.');
 const envelope=JSON.parse(e.postData.contents);verify_(envelope);const q=JSON.parse(envelope.body);const ss=SpreadsheetApp.openById(PERFORMANCE_ID);
 if(q.action==='ping'){const catalog=[];for(const platform of ['TIKTOK','SHOPEE']){const cat=ensureSheet_(ss,platform==='SHOPEE'?'SPE_Stores':'TTS_Stores');for(const x of masterStores_(cat).filter(x=>x.collectorCode))catalog.push({platform,channel_name:x.name,channel_code:x.collectorCode,warehouse:x.wh,shop_id:x.shopId,shop_name:x.shopName,enabled:x.enabled,tracked:x.tracked,business_code:x.businessCode,shop_code:x.shopCode||''});}return json_({ok:true,sheet_name:ss.getName(),...versionInfo_(),catalog});}
 if(q.action==='appeal_ticket'){lock=LockService.getScriptLock();if(!lock.tryLock(25000))throw Error('Busy. Retry.');return json_(recordPerformanceAppeal_(q.ticket,ss));}
 if(q.action==='shopee_report'){lock=LockService.getScriptLock();if(!lock.tryLock(25000))throw Error('Busy. Retry.');return json_(shopeeReport_(q,ss));}
 if(q.action==='enabler_submit'){lock=LockService.getScriptLock();if(!lock.tryLock(25000))throw Error('Busy. Retry.');return json_(enablerSubmit_(q,ss));}
 if(q.action==='share_create'||q.action==='share_list'||q.action==='share_revoke')return json_(share_(q));
 if(!['ingest','finalize','daily'].includes(q.action))throw Error('Unsupported action.');validate_(q);
 lock=LockService.getScriptLock();if(!lock.tryLock(25000))throw Error('Busy. Retry.');
 const sheets=uploadSheets_(ss,q.run.platform,q.action);
 masterGuard_(sheets.TTS_Stores,q.run);
 if(q.action==='ingest')return json_(ingest_(q,sheets));
 if(q.action==='daily')return json_(daily_(q,sheets));
 return json_(finalize_(q,sheets));
 }catch(err){return json_({ok:false,error:String(err.message||err).slice(0,350)});}finally{if(lock&&lock.hasLock())lock.releaseLock();}}
function verify_(e){const secret=PropertiesService.getScriptProperties().getProperty('SYNC_SECRET');if(!secret)throw Error('Run setupPerformance first.');
 if(typeof e.body!=='string'||typeof e.nonce!=='string'||e.nonce.length>80||!Number.isFinite(e.ts)||Math.abs(Date.now()-e.ts)>300000)throw Error('Invalid/expired signature.');
 const bytes=Utilities.computeHmacSha256Signature(e.ts+'\n'+e.nonce+'\n'+e.body,secret,Utilities.Charset.UTF_8),hex=bytes.map(x=>('0'+((x+256)%256).toString(16)).slice(-2)).join('');
 if(typeof e.signature!=='string'||e.signature.length!==hex.length)throw Error('Invalid signature.');let diff=0;for(let i=0;i<hex.length;i++)diff|=hex.charCodeAt(i)^e.signature.charCodeAt(i);if(diff)throw Error('Invalid signature.');
 const cache=CacheService.getScriptCache(),key='nonce:'+e.nonce;if(cache.get(key))throw Error('Duplicate nonce. Retry with a new request.');cache.put(key,'1',600);
}
function validate_(q){if(q.run?.shopCode&&!/^[A-Z0-9_-]{3,40}$/i.test(String(q.run.shopCode)))throw Error('Invalid Shop Code.');if(q.run?.platform==='SHOPEE')return validateShopee_(q);if(q.run?.platform&&q.run.platform!=='TIKTOK')throw Error('Unsupported platform.');const r=q.run;if(r&&r.collector!=null&&(typeof r.collector!=='string'||r.collector.length>80))throw Error('Invalid collector.');if(!r||typeof r.id!=='string'||r.id.length>80||!/^\d{5,24}$/.test(r.shopId)||typeof r.channel_code!=='string'||!r.channel_code.startsWith('TTK'))throw Error('Invalid store/run.');
 if(!/^\d{4}-\d{2}-\d{2}T/.test(r.capturedAt)||typeof q.upload_id!=='string'||!q.upload_id.startsWith(r.id+'-r')||q.upload_id.length>110)throw Error('Invalid upload.');
 if(!Array.isArray(r.metrics)||r.metrics.length!==6||new Set(r.metrics.map(m=>m.code)).size!==6||r.metrics.some(m=>!CODES.includes(m.code)||m.value!==null&&(!Number.isFinite(m.value)||m.value<0||m.value>1)))throw Error('Invalid metrics.');
 if(!Number.isInteger(q.chunk_count)||q.chunk_count<1||q.chunk_count>10000)throw Error('Invalid chunk count.');
 if(q.action==='daily'){if(!Array.isArray(q.rows)||q.rows.length>1000)throw Error('Invalid daily chunk.');for(const d of q.rows){const x=/^X_[A-Z0-9_]{2,60}$/.test(String(d.metric));if(!(x||DAILY_CODES.includes(d.metric))||!/^\d{4}-\d{2}-\d{2}$/.test(d.date)||typeof d.value!=='number'||!Number.isFinite(d.value)||!x&&(d.value<0||d.value>(d.metric==='SHOP_SCORE'?5:1)))throw Error('Invalid daily row.');}}
 if(q.action==='ingest'){
  if(!Number.isInteger(q.chunk)||q.chunk<0||q.chunk>=q.chunk_count||!Array.isArray(q.orders)||q.orders.length>MAX_CHUNK_ORDERS)throw Error('Invalid chunk.');
  for(const o of q.orders){if(!/^\d{10,24}$/.test(o.order_id)||typeof o.order_id!=='string'||!CODES.includes(o.metric)||!['API_FAILURE_LIST','API_FAILURE_FLAG','CONFIRMED_FILTER','DOM_FAILURE_ROW','SELLER_EXPORT_CONFIRMED'].includes(o.evidence))throw Error('Unverified order row.');}
 }
}
/* Uploads preserve existing Sheet/table column formats. Formatting is not part of data ingestion. */
function ensureSheet_(ss,name){const h=HEADERS[name];let s=ss.getSheetByName(name);if(!s)s=ss.insertSheet(name);
 if(/^(TTS|SPE)_Stores$/.test(name)&&s.getLastRow()>0){masterLayout_(s);return s;}
 if(s.getMaxColumns()<h.length)s.insertColumnsAfter(s.getMaxColumns(),h.length-s.getMaxColumns());
 if(s.getLastRow()>0){const existing=s.getRange(1,1,1,h.length).getValues()[0];const n=existing.findIndex(x=>x===''||x==null);const known=n<0?existing:existing.slice(0,n);
  if(known.some((x,i)=>x!==h[i])||(n>=0&&existing.slice(n).some(x=>x!==''&&x!=null)))throw Error(name+': header mismatch; preserve existing sheet and repair headers.');
  if(known.length<h.length)s.getRange(1,known.length+1,1,h.length-known.length).setValues([h.slice(known.length)]).setBackground('#12283b').setFontColor('#ffffff').setFontWeight('bold').setWrap(true);}
 else{s.getRange(1,1,1,h.length).setValues([h]);s.setFrozenRows(1);s.getRange(1,1,1,h.length).setBackground('#12283b').setFontColor('#ffffff').setFontWeight('bold').setWrap(true);s.setRowHeight(1,44);s.setColumnWidths(1,h.length,150);}
 return s;
}
/* v2.2.9 — Sheet bị gắn dropdown / quy tắc xác thực dữ liệu (vd. bấm "Chuyển thành bảng" hoặc "Dropdown" trên cột Period Start)
   làm setValues bị từ chối ("vi phạm các quy tắc xác thực dữ liệu") → cả hàng đợi đồng bộ kẹt.
   Gặp lỗi đó: bỏ quy tắc trên ĐÚNG vùng đang ghi rồi ghi lại một lần. Header và dòng khác giữ nguyên. */
function isValidationError_(e){return /validation|xác thực|quy tắc/i.test(String(e&&e.message||e));}
function setVals_(range,values){
 try{range.setValues(values);return range;}catch(e){if(!isValidationError_(e))throw e;}
 const where=range.getSheet().getName()+'!'+range.getA1Notation();
 try{range.clearDataValidations();range.setValues(values);console.warn('Đã bỏ dropdown/xác thực dữ liệu trên '+where+' để ghi dữ liệu.');return range;}
 catch(e2){throw Error('Tab '+range.getSheet().getName()+' có cột đang là dropdown/kiểu dữ liệu cố định (thường do "Chuyển thành bảng") nên không ghi được '+where+'. Mở Sheet, chọn cột đó → Dữ liệu → Xác thực dữ liệu → Xoá quy tắc (hoặc đổi kiểu cột Bảng về "Không có"), rồi bấm Gửi lại.');}
}
function safe_(v){if(v===null||v===undefined)return '';if(typeof v==='number')return Number.isFinite(v)?v:'';if(typeof v==='boolean')return v;const s=String(v).slice(0,1800);return /^[=+\-@]/.test(s)?"'"+s:s;}
function uploadSheets_(ss,platform,action){
 const prefix=platform==='SHOPEE'?'SPE_':'TTS_',names=action==='ingest'?['Stores','Sync_Log','Orders']:action==='daily'?['Stores','Daily']:['Stores','Sync_Log','Orders','Metrics','Overview'];
 return Object.fromEntries(names.map(n=>['TTS_'+n,ensureSheet_(ss,prefix+n)]));
}
function key_(parts){return parts.map(x=>String(x??'').replace(/\|/g,'_')).join('|');}
function coverage_(m){if(SPE_CODES.includes(m.code)&&!['NFR','LSR','FHR'].includes(m.code))return m.value==null?'N/A':'KPI · KHÔNG CÓ DANH SÁCH ĐƠN';if(m.value===null)return 'N/A';if(m.listComplete===false)return 'CHƯA ĐỦ DANH SÁCH';if(m.expected===null||m.expected===undefined)return 'CHƯA ĐỐI CHIẾU';if(m.count!==m.expected)return m.count<m.expected?'THIẾU ĐƠN':'LỆCH SỐ ĐƠN';return m.scopeVerified?'ĐỦ ĐƠN':'CẦN KIỂM TRA FILTER';}
function kpi_(m){if(m.value===null)return 'N/A';if(!m.threshold||m.threshold.source!=='SELLER_CENTER')return 'CHƯA CÓ MỤC TIÊU';const t=m.threshold;const ok=t.direction==='>='?m.value>=t.target:t.direction==='>'?m.value>t.target:t.direction==='<='?m.value<=t.target:t.direction==='='?m.value===t.target:m.value<t.target;return ok?'PASS':'FAIL';}
function coverageSummary_(r){return r.metrics.map(m=>m.code+': '+coverage_(m)).join(' | ');}
function index_(s,col){if(s.getLastRow()<2)return {};const rows=s.getRange(2,col, s.getLastRow()-1,1).getDisplayValues(),out={};rows.forEach((r,i)=>{if(r[0])out[r[0]]=i+2;});return out;}
function upsert_(s,rows,keyCol,width){const ix=index_(s,keyCol);const append=[];for(const row of rows){const clean=row.map(safe_),key=String(row[keyCol-1]);if(ix[key])setVals_(s.getRange(ix[key],1,1,width),[clean.slice(0,width)]);else{append.push(clean.slice(0,width));ix[key]=-1;}}
 if(append.length){const start=s.getLastRow()+1;if(start+append.length-1>s.getMaxRows())s.insertRowsAfter(s.getMaxRows(),start+append.length-1-s.getMaxRows());setVals_(s.getRange(start,1,append.length,width),append);}
}
function evalLabel_(a,b){const f=x=>/^\d{4}-\d{2}-\d{2}$/.test(String(x||''))?String(x).slice(8,10)+'/'+String(x).slice(5,7)+'/'+String(x).slice(0,4):'';return a&&b?f(a)+' - '+f(b):'';}
function ingest_(q,s){const r=q.run,spe=r.platform==='SHOPEE',log=s.TTS_Sync_Log,ix=index_(log,1);let received=[],existingOrders=0;
 if(ix[q.upload_id]){const row=log.getRange(ix[q.upload_id],1,1,11).getValues()[0];if(Number(row[7])!==q.chunk_count)throw Error('Chunk count mismatch.');received=String(row[8]??'').split(',').filter(Boolean).map(Number);existingOrders=Number(row[9])||0;if(received.includes(q.chunk))return {ok:true,duplicate:true};}
 const now=new Date().toISOString();
 // One row per Shop × KPI × Order: re-collecting overwrites with the latest snapshot; review columns 27:32 and First Seen are kept.
 const orders=q.orders.map(o=>{const m=r.metrics.find(x=>x.code===o.metric);return [key_([r.shopId,o.metric,o.order_id]),r.shopId,r.channel_name,r.channel_code,o.warehouse||r.warehouse,o.metric,o.order_id,o.tracking_id,o.status,o.reason,o.created_at,o.paid_at,o.rts_at,o.pickup_at,o.delivered_at,o.deadline,o.shipping_type,o.carrier,o.period_start||m.period_start,o.period_end||m.period_end,r.capturedAt,r.capturedAt,o.violation_id,o.appeal_status,o.evidence,r.id,'','','','','','',o.actual_handover_at,o.shipping_location,o.delivery_type,o.pickup_type,o.is_preorder,o.sla_rule,...(spe?[o.confirmed_at,o.first_attempt_at,o.estimated_delivery_at,o.platform_order_id,o.order_sn]:[])];});
 bulkUpsert_(s.TTS_Orders,orders,spe?43:38,['B','G','H','S','T','U','V','AG',...(spe?['AM','AN','AO','AP','AQ']:[])],{tsCol:22,keepCols:[21,27,28,29,30,31,32],keepNonEmptyCols:[8,9,11,12,13,14,15,16,17,18,23,24,33,34,35,36,37,38,...(spe?[39,40,41,42,43]:[])]});
 received.push(q.chunk);received.sort((a,b)=>a-b);upsert_(log,[[q.upload_id,r.id,r.channel_code,r.shopId,r.capturedAt,now,'RECEIVING',q.chunk_count,received.join(','),existingOrders+q.orders.length,coverageSummary_(r),r.collector||'']],1,12);
 SpreadsheetApp.flush();return {ok:true,chunk:q.chunk,orders:q.orders.length};
}
function finalize_(q,s){const r=q.run,spe=r.platform==='SHOPEE',codes=spe?SPE_CODES:CODES,log=s.TTS_Sync_Log,ix=index_(log,1);if(!ix[q.upload_id])throw Error('No chunks received.');const entry=log.getRange(ix[q.upload_id],1,1,11).getValues()[0];const received=String(entry[8]).split(',').filter(Boolean).map(Number);if(received.length!==q.chunk_count||received.some((x,i)=>x!==i))throw Error('Missing chunks. Retry pending upload.');
 if(entry[6]==='DONE')return {ok:true,duplicate:true};const now=new Date().toISOString();
 const orderSheet=s.TTS_Orders;if(!spe)migrateLatest_(s);
 const expected=r.metrics.reduce((a,m)=>a+(m.count||0)+(Number(m.prior_count)||0),0);if(Number(entry[9])!==expected)throw Error('Uploaded order count differs ('+entry[9]+' / '+expected+'). Resend data.');
// One row per Shop × KPI × Thời gian đánh giá: same period collected again → latest overwrites.
 const metrics=r.metrics.map(m=>[key_([r.shopId,m.code,m.period_start,m.period_end]),r.id,r.capturedAt,r.week,r.channel_name,r.channel_code,r.warehouse,r.shopId,m.code,m.name,m.value,m.raw,m.threshold?.target,m.threshold?.direction,m.threshold?.source,kpi_(m),m.period_start,m.period_end,m.expected,m.denominator,m.count,coverage_(m),m.pages,m.source,m.notes,evalLabel_(m.period_start,m.period_end),...(spe?[SPE_UNITS[m.code]]:[])]);
 bulkUpsert_(s.TTS_Metrics,metrics,spe?27:26,['C','H','Q','R','Z'],{tsCol:3});
 const overview=s.TTS_Overview,overIx=index_(overview,2);const oldTime=overIx[r.channel_code]?overview.getRange(overIx[r.channel_code],6).getDisplayValue():'';
 if(!oldTime||oldTime<=r.capturedAt){const get=c=>r.metrics.find(m=>m.code===c)?.value;const uniqueOrders=new Set();
  const on=orderSheet.getLastRow()-1;if(on>0){const ids=orderSheet.getRange(2,7,on,1).getDisplayValues(),runs=orderSheet.getRange(2,26,on,1).getDisplayValues();runs.forEach((x,i)=>{if(x[0]===r.id)uniqueOrders.add(ids[i][0]);});}
  const failures=r.metrics.filter(m=>kpi_(m)==='FAIL').map(m=>m.code);const status=failures.length?'FAIL: '+failures.join(', '):r.metrics.some(m=>kpi_(m)==='PASS')?'PASS':r.metrics.some(m=>kpi_(m)==='CHƯA CÓ MỤC TIÊU')?'CHƯA CÓ MỤC TIÊU':'PASS / N/A';
  upsert_(overview,[[r.channel_name,r.channel_code,r.warehouse,r.shopId,r.shopName,r.capturedAt,r.week,...codes.map(get),status,uniqueOrders.size,coverageSummary_(r),r.id,r.identitySource,now,r.collector||'']],2,spe?22:20);
 }
 masterCollected_(s.TTS_Stores,r);
 entry[5]=now;entry[6]='DONE';setVals_(log.getRange(ix[q.upload_id],1,1,11),[entry]);SpreadsheetApp.flush();return {ok:true,sheet_name:'Performance',metrics:codes.length,platform:spe?'SHOPEE':'TIKTOK'};
}
function json_(o){return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);}

/* ---------- Daily history (one row per Shop × Metric × Date, latest write wins) ---------- */
function isoWeek_(ymd){const d=new Date(ymd+'T00:00:00Z');const day=d.getUTCDay()||7;d.setUTCDate(d.getUTCDate()+4-day);const y=d.getUTCFullYear();return y+'-W'+String(Math.ceil((((d-new Date(Date.UTC(y,0,1)))/86400000)+1)/7)).padStart(2,'0');}
function bulkUpsert_(sheet,rows,width,textCols,opt){opt=opt||{};if(!rows.length)return {added:0,updated:0,skipped:0};
 // Batch only consecutive changed rows. Never read/write the gap between distant stores or periods.
 // tsCol: an existing row with a newer timestamp is kept (late offline uploads never overwrite newer data).
 const n=sheet.getLastRow()-1,keys=n>0?sheet.getRange(2,1,n,1).getDisplayValues():[],ts=opt.tsCol&&n>0?sheet.getRange(2,opt.tsCol,n,1).getDisplayValues():null,ix={};
 keys.forEach((r,i)=>{if(r[0])ix[r[0]]=i;});
 const upd={},append=[],at={};let skipped=0;
 for(const row of rows){const k=String(row[0]),clean=row.map(safe_);
  if(ix[k]!==undefined){const i=ix[k];if(ts&&String(ts[i][0])>String(row[opt.tsCol-1])){skipped++;continue;}upd[i]=clean;}
  else if(at[k]!==undefined)append[at[k]]=clean;else{at[k]=append.length;append.push(clean);}}
 const idx=Object.keys(upd).map(Number).sort((a,b)=>a-b),groups=[];
 for(const i of idx){const g=groups[groups.length-1];if(g&&i===g[g.length-1]+1&&g.length<500)g.push(i);else groups.push([i]);}
 const preserve=(opt.keepCols||[]).length||(opt.keepNonEmptyCols||[]).length;
 const writes=groups.map(g=>{const block=preserve?sheet.getRange(g[0]+2,1,g.length,width).getValues():null;
  const values=g.map((i,j)=>{const row=upd[i];if(block){(opt.keepCols||[]).forEach(c=>{const v=block[j][c-1];if(v!==''&&v!=null)row[c-1]=v;});(opt.keepNonEmptyCols||[]).forEach(c=>{if((row[c-1]===''||row[c-1]==null)&&block[j][c-1]!==''&&block[j][c-1]!=null)row[c-1]=block[j][c-1];});}return row;});return {start:g[0]+2,values};});
 for(const w of writes)setVals_(sheet.getRange(w.start,1,w.values.length,width),w.values);
 if(append.length){const start=Math.max(sheet.getLastRow(),1)+1;if(start+append.length-1>sheet.getMaxRows())sheet.insertRowsAfter(sheet.getMaxRows(),start+append.length-1-sheet.getMaxRows());setVals_(sheet.getRange(start,1,append.length,width),append);}
 return {added:append.length,updated:idx.length,skipped};
}
/* One-time, idempotent: older versions keyed rows per run. Re-key to the latest-wins keys and drop duplicates. */
function migrateLatest_(s){
 const mt=s.TTS_Metrics,mn=mt.getLastRow()-1;
 if(mn>0&&String(mt.getRange(2,1).getDisplayValue()).split('|').length===2){const rows=mt.getRange(2,1,mn,26).getValues(),keep={};
  for(const r of rows){if(!r[1])continue;const d=x=>x instanceof Date?Utilities.formatDate(x,'Asia/Ho_Chi_Minh','yyyy-MM-dd'):String(x||'');r[16]=d(r[16]);r[17]=d(r[17]);r[0]=key_([r[7],r[8],r[16],r[17]]);r[25]=evalLabel_(r[16],r[17]);if(!keep[r[0]]||String(keep[r[0]][2])<=String(r[2]))keep[r[0]]=r;}
  rewrite_(mt,Object.values(keep),mn,26,['H','Q','R','Z']);}
 const od=s.TTS_Orders,on=od.getLastRow()-1;
 if(on>0&&String(od.getRange(2,1).getDisplayValue()).split('|').length===4){const rows=od.getRange(2,1,on,32).getValues(),keep={};
  for(const r of rows){if(!r[6])continue;const k=key_([r[1],r[5],r[6]]);const cur=keep[k];r[0]=k;
   if(!cur){keep[k]=r;continue;}const newer=String(r[21])>=String(cur[21])?r:cur,older=newer===r?cur:r;
   for(let c=26;c<32;c++)if((newer[c]===''||newer[c]==null)&&older[c]!==''&&older[c]!=null)newer[c]=older[c];
   if(String(older[20])<String(newer[20]))newer[20]=older[20];keep[k]=newer;}
  rewrite_(od,Object.values(keep),on,32,['B','G','H','S','T']);}
}
function rewrite_(sh,rows,oldCount,width,textCols){if(rows.length)setVals_(sh.getRange(2,1,rows.length,width),rows);if(oldCount>rows.length)sh.getRange(rows.length+2,1,oldCount-rows.length,width).clearContent();}
function daily_(q,s){const r=q.run,spe=r.platform==='SHOPEE',now=new Date().toISOString();
 const th={};(r.metrics||[]).forEach(m=>{th[m.code]=m.threshold||null;});
 const rows=q.rows.map(d=>{const t=th[d.metric];const st=t&&t.source==='SELLER_CENTER'?kpi_({value:d.value,threshold:t}):'';
  return [key_([r.shopId,d.metric,d.date,...(spe?[d.window_start||'',d.window_end||'']:[])]),d.date,isoWeek_(d.date),r.channel_name,r.channel_code,r.warehouse,r.shopId,r.shopName,d.metric,(spe?SPE_NAMES:METRIC_NAMES)[d.metric]||String(d.name||d.metric).slice(0,120),d.value,t?t.target:'',t?t.direction:'',st,d.errors==null?'':d.errors,d.window_start||'',d.window_end||'',spe?d.source||'SHOPEE_OBSERVED_HISTORY':'TIKTOK_TREND',r.capturedAt,evalLabel_(d.window_start,d.window_end),...(spe?[SPE_UNITS[d.metric]||String(d.unit||'').slice(0,20)]:[])];});
 const res=bulkUpsert_(s.TTS_Daily,rows,spe?21:20,['B','G','P','Q','S','T'],{tsCol:19});
 SpreadsheetApp.flush();return {ok:true,rows:rows.length,added:res.added,updated:res.updated,skipped:res.skipped};}

/* ---------- Dashboard (served by doGet; data only for signed-in users with access to the Sheet) ---------- */
function shares_(){try{return JSON.parse(PropertiesService.getScriptProperties().getProperty('SHARE_LINKS')||'{}');}catch(e){return {};}}
function share_(q){const p=PropertiesService.getScriptProperties(),all=shares_();
 if(q.action==='enabler_submit'){lock=LockService.getScriptLock();if(!lock.tryLock(25000))throw Error('Busy. Retry.');return json_(enablerSubmit_(q,ss));}
 if(q.action==='share_create'){const scope=q.scope==='full'?'full':'kpi';const label=String(q.label||'').slice(0,80)||'Link chia sẻ';const key=(Utilities.getUuid()+Utilities.getUuid()).replace(/-/g,'').slice(0,40);
  all[key]={scope,label,by:String(q.by||'').slice(0,80),created:new Date().toISOString()};p.setProperty('SHARE_LINKS',JSON.stringify(all));return {ok:true,key,scope,label};}
 if(q.action==='share_revoke'){if(!all[q.key])throw Error('Link không tồn tại.');delete all[q.key];p.setProperty('SHARE_LINKS',JSON.stringify(all));return {ok:true};}
 return {ok:true,links:Object.keys(all).map(k=>({key:k,...all[k]}))};}
/* Access: a valid share key (anyone with the link, no login) or a signed-in Google user with access to the Sheet. */
function access_(key){key=String(key||'');
 if(key){const l=shares_()[key];if(!l)throw Error('Link chia sẻ không hợp lệ hoặc đã bị thu hồi.');return {ss:SpreadsheetApp.openById(PERFORMANCE_ID),scope:l.scope,viewer:l.label,shared:true};}
 const active=Session.getActiveUser().getEmail(),eff=Session.getEffectiveUser().getEmail();
 if(!active)throw Error('Link này cần đăng nhập Google, hoặc dùng link chia sẻ (có ?k=...) do người quản lý tạo trong extension.');
 if(eff&&active!==eff&&PropertiesService.getScriptProperties().getProperty('DASHBOARD_OPEN')!=='true')throw Error('Link này là link upload của extension. Mở bằng link Dashboard hoặc link chia sẻ.');
 try{return {ss:SpreadsheetApp.openById(PERFORMANCE_ID),scope:'full',viewer:active,shared:false};}catch(err){throw Error('Tài khoản '+active+' chưa có quyền xem file Performance. Xin quyền Viewer từ chủ file.');}}
function table_(ss,name,width){const sh=ss.getSheetByName(name);if(!sh||sh.getLastRow()<2)return [];return sh.getRange(2,1,sh.getLastRow()-1,width).getDisplayValues();}
function num_(v){if(v===''||v==null)return null;const s=String(v).trim();const n=Number(s.replace('%','').replace(',','.'));return Number.isFinite(n)?(s.endsWith('%')?n/100:n):null;}
function dashData(days,key){const acc=access_(key),ss=acc.ss;days=Math.max(7,Math.min(200,Number(days)||30));
 const from=Utilities.formatDate(new Date(Date.now()-days*86400000),'Asia/Ho_Chi_Minh','yyyy-MM-dd');
 const stores=masterStores_(ss.getSheetByName('TTS_Stores'));
 const overview=table_(ss,'TTS_Overview',20).filter(r=>r[1]).map(r=>({code:r[1],shopId:r[3],shopName:r[4],channelName:r[0],at:r[5],week:r[6],kpi:CODES.reduce((o,c,i)=>(o[c]=num_(r[7+i]),o),{}),status:r[13],errors:Number(r[14])||0,coverage:r[15],runId:r[16],by:r[19]||''}));
 const metrics=table_(ss,'TTS_Metrics',26).filter(r=>r[1]);const latestRun={};overview.forEach(o=>latestRun[o.runId]=o.code);
 const targets={};metrics.forEach(r=>{if(latestRun[r[1]])(targets[r[5]]=targets[r[5]]||{})[r[8]]={target:num_(r[12]),dir:r[13],status:r[15],start:r[16],end:r[17],count:Number(r[20])||0,coverage:r[21],note:r[24]};});
 const dsh=ss.getSheetByName('TTS_Daily'),dn=dsh?dsh.getLastRow()-1:0,col=c=>dn>0?dsh.getRange(2,c,dn,1).getDisplayValues():[];
 const dD=col(2),dC=col(5),dM=col(9),dV=col(11),dE=col(15),dS=col(16),dT=col(17),daily=[];for(let i=0;i<dn;i++)if(dD[i][0]>=from&&!/^X_/.test(dM[i][0]))daily.push([dD[i][0],dC[i][0],dM[i][0],num_(dV[i][0]),num_(dE[i][0]),dS[i][0],dT[i][0]]);
 const periods=metrics.map(r=>[r[5],r[8],r[16],r[17],num_(r[10]),num_(r[12]),r[13],r[15],Number(r[20])||0,r[2],r[21]]);
 const shopee=dashShopeeData_(ss,from);stores.forEach(x=>x.platform='TIKTOK');overview.forEach(x=>x.platform='TIKTOK');stores.push(...shopee.stores);overview.push(...shopee.overview);Object.assign(targets,shopee.targets);daily.push(...shopee.daily);periods.push(...shopee.periods);
 masterProgress_(stores,overview);
 if(acc.scope!=='full'){stores.forEach(x=>{x.shopId='';});shopee.reports.forEach(x=>{x.shopId='';});shopee.enablerSubmit.forEach(x=>{x.shopId='';});}
 return {version:versionInfo_().version,enabler_schema:2,master_schema:1,reports:shopee.reports,enablerSubmit:shopee.enablerSubmit,enablerScorecards:shopee.enablerScorecards,generatedAt:new Date().toISOString(),viewer:acc.viewer,scope:acc.scope,shared:acc.shared,from,days,stores,overview,targets,daily,periods};}
function dashOrders(channelCode,key){if(/^SPE[A-Z0-9]+$/.test(channelCode))return dashShopeeOrders_(channelCode,key);const acc=access_(key),ss=acc.ss;if(acc.scope!=='full')throw Error('Link này chỉ xem KPI, không xem danh sách đơn lỗi.');const ov=table_(ss,'TTS_Overview',19).find(r=>r[1]===channelCode);if(!ov)return {runId:'',rows:[]};
 const runId=ov[16],sh=ss.getSheetByName('TTS_Orders');if(!sh||sh.getLastRow()<2)return {runId,rows:[]};
 const runs=sh.getRange(2,26,sh.getLastRow()-1,1).getDisplayValues();let a=-1,b=-1;runs.forEach((r,i)=>{if(r[0]===runId){if(a<0)a=i;b=i;}});if(a<0)return {runId,rows:[]};
 const width=Math.min(sh.getMaxColumns(),38);
 const rows=sh.getRange(a+2,1,b-a+1,width).getDisplayValues().filter(r=>r[25]===runId).map(r=>[r[5],r[6],r[10],r[9],r[26],r[27],r[28],r[29],r[30],r[31],r[7],r[8],r[11],r[12],r[13],r[14],r[15],r[16],r[17],r[32]||'',r[33]||'',r[34]||'',r[35]||'',r[36]||'',r[37]||'']);
 return {runId,rows};}

/* Shopee uses separate sheets and accepts a real Shopee order number, not SKU rows. */
function validShopeeValue_(code,v){return v===null||Number.isFinite(v)&&v>=0&&(SPE_UNITS[code]!=='rate'||v<=1);}
function validateShopee_(q){const r=q.run;
 if(!r||typeof r.id!=='string'||r.id.length>80||!/^\d{5,24}$/.test(r.shopId)||!/^SPE[A-Z0-9]+$/.test(r.channel_code)||typeof r.channel_name!=='string'||r.channel_name.length>250)throw Error('Invalid Shopee store/run.');
 if(r.collector!=null&&(typeof r.collector!=='string'||r.collector.length>80))throw Error('Invalid collector.');
 if(!/^\d{4}-\d{2}-\d{2}T/.test(r.capturedAt)||typeof q.upload_id!=='string'||!q.upload_id.startsWith(r.id+'-r')||q.upload_id.length>110)throw Error('Invalid upload.');
 if(!Array.isArray(r.metrics)||r.metrics.length!==SPE_CODES.length||new Set(r.metrics.map(m=>m.code)).size!==SPE_CODES.length||r.metrics.some(m=>!SPE_CODES.includes(m.code)||!validShopeeValue_(m.code,m.value)))throw Error('Invalid Shopee metrics/units.');
 if(!Number.isInteger(q.chunk_count)||q.chunk_count<1||q.chunk_count>10000)throw Error('Invalid chunk count.');
 if(q.action==='ingest'){if(!Number.isInteger(q.chunk)||q.chunk<0||q.chunk>=q.chunk_count||!Array.isArray(q.orders)||q.orders.length>MAX_CHUNK_ORDERS)throw Error('Invalid chunk.');for(const o of q.orders)if(typeof o.order_id!=='string'||!(/^(?:\d{10,24}|\d{6}[A-Z0-9]{5,20})$/.test(o.order_id))||!['NFR','LSR','FHR'].includes(o.metric)||!['API_FAILURE_LIST','API_FAILURE_FLAG','DOM_FAILURE_ROW'].includes(o.evidence))throw Error('Unverified Shopee error order.');}
 if(q.action==='daily'){if(!Array.isArray(q.rows)||q.rows.length>1000||q.rows.some(d=>!(SPE_CODES.includes(d.metric)||/^X_[A-Z0-9_]{2,60}$/.test(String(d.metric)))||!/^\d{4}-\d{2}-\d{2}$/.test(d.date)||d.value===null||!validShopeeValue_(d.metric,d.value)))throw Error('Invalid Shopee history.');}
}
function enablerPeriod_(date){if(!/^\d{4}-\d{2}-\d{2}$/.test(String(date)))throw Error('Invalid scorecard date.');const t=Date.parse(date+'T00:00:00Z'),d=new Date(t);if(!Number.isFinite(t)||d.toISOString().slice(0,10)!==date)throw Error('Invalid scorecard date.');const year=d.getUTCFullYear(),quarter=Math.floor(d.getUTCMonth()/3)+1,start=new Date(Date.UTC(year,(quarter-1)*3,1));start.setUTCDate(start.getUTCDate()+(8-start.getUTCDay())%7);const week=Math.floor((t-start.getTime())/(7*86400000))+1;if(d.getUTCDay()!==1||week<1||week>13)throw Error('Scorecard must be a Monday in the 13 program weeks.');return {year,quarter,week,totalWeeks:13,periodStart:date,periodEnd:new Date(t+6*86400000).toISOString().slice(0,10)};}
function validEnablerScore_(v,eng){return v===null||Number.isFinite(v)&&v>=(eng?0:-1)&&v<=(eng?2:1);}
function reportPeriod_(r){const p=enablerPeriod_(r.date);for(const k of ['year','quarter','week','totalWeeks','periodStart','periodEnd'])if(r[k]!=null&&r[k]!==p[k])throw Error('Report period mismatch.');const asOf=r.scorecardDate||r.date;const a=enablerPeriod_(asOf);if(a.year!==p.year||a.quarter!==p.quarter||asOf<r.date)throw Error('Scorecard date mismatch.');return {...p,scorecardDate:asOf};}
// Replace each complete scorecard block together. A corrected file may remove shops or metrics.
function mergeEnablerGroups_(sh,rows,width,dateCol,aggCol,asOfCol,textCols){const oldCount=Math.max(0,sh.getLastRow()-1),old=oldCount?sh.getRange(2,1,oldCount,width).getValues():[],incoming=new Map(),latest=new Map();const group=r=>key_([r[dateCol-1],r[aggCol-1]]);
 for(const r of old){const k=group(r),v=String(r[asOfCol-1]||r[dateCol-1]);if(v>(latest.get(k)||''))latest.set(k,v);}
 for(const r of rows){const k=group(r);if(!incoming.has(k))incoming.set(k,[]);incoming.get(k).push(r);}
 const accept=new Map();let skipped=0;for(const [k,rs] of incoming){if(String(rs[0][asOfCol-1])<(latest.get(k)||''))skipped+=rs.length;else accept.set(k,rs);}
 const keys=new Set(old.map(r=>String(r[0]))),next=old.filter(r=>!accept.has(group(r))),accepted=[...accept.values()].flat(),added=accepted.filter(r=>!keys.has(String(r[0]))).length,updated=accepted.length-added;
 const keepKeys=new Set(accepted.map(r=>String(r[0]))),removed=old.filter(r=>accept.has(group(r))&&!keepKeys.has(String(r[0]))).length;next.push(...accepted.map(r=>r.map(safe_)));
 if(accept.size){if(next.length+1>sh.getMaxRows())sh.insertRowsAfter(sh.getMaxRows(),next.length+1-sh.getMaxRows());rewrite_(sh,next,oldCount,width,textCols);}return {added,updated,skipped,removed};}
function shopeeReport_(q,ss){if(!Array.isArray(q.rows)||!q.rows.length||q.rows.length>6000||typeof q.source!=='string'||q.source.length>250)throw Error('Invalid report.');
 const periods=q.rows.map(r=>{if(!/^\d{5,24}$/.test(r.shopId)||typeof r.shopName!=='string'||!r.shopName.trim()||r.shopName.length>250||!['QTD','WEEKLY'].includes(r.aggregation)||!(SPE_CODES.includes(r.metric)||ENB_CODES.includes(r.metric))||!validShopeeValue_(r.metric,r.value)||!validEnablerScore_(r.score,ENB_CODES.includes(r.metric))||!validEnablerScore_(r.operational_score,false)||!validEnablerScore_(r.engagement_score,true))throw Error('Invalid report row.');return reportPeriod_(r);});
 const summaries=q.summary||[];if(!Array.isArray(summaries)||summaries.length>30||q.report_schema===2&&!summaries.length)throw Error('Missing official scorecard totals.');
 const group=new Map();q.rows.forEach(r=>{const k=key_([r.date,r.aggregation]);if(!group.has(k))group.set(k,new Set());group.get(k).add(r.shopId);});
 const summaryPeriods=summaries.map(r=>{const p=reportPeriod_(r),g=group.get(key_([r.date,r.aggregation]));if(!g||g.size!==r.shopCount||!validEnablerScore_(r.operational_score,false)||!validEnablerScore_(r.engagement_score,true)||!r.metric_scores||['NFR','LSR','FHR','SPH','PP','CRR'].concat(ENB_CODES).some(c=>!validEnablerScore_(r.metric_scores[c],ENB_CODES.includes(c))))throw Error('Invalid official scorecard total.');return p;});
 if(q.report_schema===2&&(summaries.length!==group.size||new Set(summaries.map(r=>key_([r.date,r.aggregation]))).size!==group.size))throw Error('Scorecard totals incomplete.');
 const now=new Date().toISOString(),rows=q.rows.map((r,i)=>{const p=periods[i];return [key_([r.shopId,r.date,r.aggregation,r.metric]),r.shopId,r.shopName,r.date,r.aggregation,r.metric,r.value,r.score,r.operational_score,r.engagement_score,SPE_UNITS[r.metric],q.source,now,p.year,p.quarter,p.week,p.totalWeeks,p.periodStart,p.periodEnd,p.scorecardDate,String(r.threshold||'').slice(0,100)];});
 const totalRows=summaries.map((r,i)=>{const p=summaryPeriods[i];return [key_([r.date,r.aggregation]),r.date,r.aggregation,p.year,p.quarter,p.week,p.totalWeeks,p.periodStart,p.periodEnd,r.operational_score,r.engagement_score,r.shopCount,...['NFR','LSR','FHR','SPH','PP','CRR'].concat(ENB_CODES).map(c=>r.metric_scores[c]),q.source,now,p.scorecardDate];});
 const res=q.report_schema===2?mergeEnablerGroups_(ensureSheet_(ss,'SPE_Report'),rows,21,4,5,20,['B','D','M','R','S','T']):bulkUpsert_(ensureSheet_(ss,'SPE_Report'),rows,21,['B','D','M','R','S','T'],{tsCol:20});if(totalRows.length)mergeEnablerGroups_(ensureSheet_(ss,'SPE_Enabler_Scorecards'),totalRows,27,2,3,27,['B','H','I','Z','AA']);
 // Reporting never mutates SPE_Enabler_Submit. Official membership is read from each report period.
 SpreadsheetApp.flush();return {ok:true,rows:rows.length,scorecards:totalRows.length,...res};}
// Run manually in the Apps Script editor to clear imported Enabler reports only. Keeps headers and submit list.
function clearShopeeEnablerRawData(){const lock=LockService.getScriptLock();if(!lock.tryLock(25000))throw Error('Busy. Retry.');try{const ss=SpreadsheetApp.openById(PERFORMANCE_ID);for(const n of ['SPE_Report','SPE_Enabler_Scorecards']){const sh=ss.getSheetByName(n);if(sh&&sh.getLastRow()>1)sh.getRange(2,1,sh.getLastRow()-1,HEADERS[n].length).clearContent();}SpreadsheetApp.flush();console.log('Đã xóa raw Enabler. Giữ list submit và các tab vận hành.');}finally{lock.releaseLock();}}
function enablerRoster_(ss){const saved=table_(ss,'SPE_Enabler_Submit',4);if(saved.length)return saved.map(r=>({shopId:r[0],name:r[1],source:r[2],updated:r[3]}));
 const reports=table_(ss,'SPE_Report',13),date=reports.map(r=>r[3]).sort().pop(),by=new Map();for(const r of reports)if(r[3]===date)by.set(r[1],{shopId:r[1],name:r[2],source:r[11],updated:r[12],legacy:true});return [...by.values()];}
function enablerSubmit_(q,ss){if(!Array.isArray(q.rows)||!q.rows.length||q.rows.length>1000||typeof q.source!=='string'||q.source.length>250)throw Error('List submit không hợp lệ.');
 const by=new Map();for(const r of q.rows){if(typeof r.shopId!=='string'||!/^\d{5,24}$/.test(r.shopId)||typeof r.shopName!=='string'||!r.shopName.trim()||r.shopName.length>250)throw Error('Shop ID/tên shop không hợp lệ.');by.set(r.shopId,r);}
 const sh=ensureSheet_(ss,'SPE_Enabler_Submit'),now=new Date().toISOString(),rows=[...by.values()].map(r=>[r.shopId,r.shopName,q.source,now]);
 if(rows.length+1>sh.getMaxRows())sh.insertRowsAfter(sh.getMaxRows(),rows.length+1-sh.getMaxRows());
 setVals_(sh.getRange(2,1,rows.length,4).setNumberFormat('@'),rows.map(r=>r.map(safe_)));
 const extra=sh.getLastRow()-rows.length-1;if(extra>0)sh.getRange(rows.length+2,1,extra,4).clearContent();SpreadsheetApp.flush();return {ok:true,shops:rows.length};}
const SPE_TARGET_OVERRIDE={FHR:{target:0.8,dir:'>='}};
// Read both collector layouts without changing headers, warehouse cells or checkbox settings.
function ensureShopCodeColumn_(sh){
 const h=sh.getRange(1,1,1,sh.getMaxColumns()).getDisplayValues()[0];
 let at=h.findIndex(v=>String(v).trim().toLowerCase()==='shop code')+1;if(at)return at;
 at=h.reduce((n,v,i)=>String(v||'').trim()?i+2:n,1);
 if(at>sh.getMaxColumns())sh.insertColumnsAfter(sh.getMaxColumns(),at-sh.getMaxColumns());
 sh.getRange(1,at).setValue('Shop Code');return at;
}
function masterLayout_(sh){
 const h=sh.getRange(1,1,1,sh.getMaxColumns()).getDisplayValues()[0];
 // Resolve by header name so an inserted Opollo column or reordered columns
 // cannot move collector writes into business mapping or progress fields.
 const norm=v=>String(v||'').replace(/\s+/g,' ').trim().toLowerCase(),names=h.map(norm);
 const col=name=>{const key=norm(name),at=names.indexOf(key);if(at<0)return 0;
 if(names.indexOf(key,at+1)>=0)throw Error(sh.getName()+': trùng header '+name+'. Giữ nguyên Sheet để kiểm tra.');return at+1;};
 const cols=HEADERS.TTS_Stores.map(col),missing=HEADERS.TTS_Stores.slice(0,5).filter((_,i)=>!cols[i]);
 if(missing.length)throw Error(sh.getName()+': thiếu header '+missing.join(', ')+'. Giữ nguyên Sheet để kiểm tra.');
 const watch=col('Cần theo dõi');
 if(!cols[5])cols[5]=watch;
 if(!cols[6])cols[6]=col('Dữ liệu lấy lúc (VN)');
 if(!cols[7])cols[7]=col('Ghi chú theo dõi');
 return {cols,offset:cols[0]-1,width:h.length,watch,business:col('Opollo Channel Code'),businessName:col('Opollo Channel Name'),shopCode:col('Shop Code'),coupled:watch>0&&watch===cols[5]};
}
function verifyMasterLayouts(){
 const ss=SpreadsheetApp.openById(PERFORMANCE_ID),result={};
 for(const name of ['TTS_Stores','SPE_Stores']){const sh=ss.getSheetByName(name);if(!sh)throw Error('Thiếu sheet '+name);const l=masterLayout_(sh);
 result[name]={ok:true,channelColumn:l.cols[1],shopIdColumn:l.cols[3],opolloColumn:l.business,trackingColumn:l.watch,storeCount:masterStores_(sh).length};}
 console.log(JSON.stringify(result));return result;
}
function masterRows_(sh){
 if(!sh)return [];const l=masterLayout_(sh);if(sh.getLastRow()<2)return [];
 const platform=sh.getName()==='SPE_Stores'?'SHOPEE':'TIKTOK';
 return sh.getRange(2,1,sh.getLastRow()-1,l.width).getDisplayValues().map((r,i)=>{
 const v=l.cols.map(c=>c?String(r[c-1]||'').trim():''),business=l.business?String(r[l.business-1]||'').trim():v[1];
 const businessName=l.businessName?String(r[l.businessName-1]||'').trim():'';
 const enabled=v[5].toLowerCase()!=='false',tracked=l.watch?String(r[l.watch-1]).toLowerCase()==='true':enabled;
 return {platform,name:businessName||v[0]||v[4]||business,code:v[1]||'MASTER_'+platform+'_'+(business||i+2),collectorCode:v[1],businessCode:business,shopId:v[3],shopName:v[4],shopCode:platform==='SHOPEE'?(/^\d{5,24}$/.test(v[3])?v[3]:''):l.shopCode?String(r[l.shopCode-1]||'').trim():'',wh:/^(true|false)$/i.test(v[2])?'':v[2],enabled,tracked,last:v[6],master:true,masterRow:i+2,masterSheet:sh.getName(),trackingCoupled:l.coupled,masterIssues:[],layout:l};
 }).filter(x=>x.collectorCode||x.businessCode||x.name);
}
function masterStores_(sh){
 const rows=masterRows_(sh),out=[],groups={};
 for(const x of rows)(groups[x.code]=groups[x.code]||[]).push(x);
 for(const group of Object.values(groups)){
 group.sort((a,b)=>Number(b.tracked)-Number(a.tracked)||Number(b.enabled)-Number(a.enabled)||Number(!!b.shopId)-Number(!!a.shopId));
 const first=group[0],s={...first,masterIssues:[]};delete s.layout;
 const ids=[...new Set(group.map(x=>x.shopId).filter(Boolean))];if(!s.shopId&&ids.length===1)s.shopId=ids[0];
 if(s.platform==='SHOPEE')s.shopCode=/^\d{5,24}$/.test(s.shopId)?s.shopId:'';
 s.tracked=group.some(x=>x.tracked);s.enabled=first.enabled;
 if(group.length>1)s.masterIssues.push('TRÙNG MÃ CHANNEL');if(ids.length>1)s.masterIssues.push('SHOP ID XUNG ĐỘT');
 if(!s.collectorCode)s.masterIssues.push('CHƯA GẮN CHANNEL COLLECTOR');if(!s.shopId)s.masterIssues.push('CHƯA GẮN SHOP ID');if(!s.enabled)s.masterIssues.push('TẮT NHẬN DỮ LIỆU');
 if(rows.some(x=>x.shopId&&x.shopId===s.shopId&&x.collectorCode&&x.collectorCode!==s.collectorCode))s.masterIssues.push('SHOP ID GẮN NHIỀU CHANNEL');
 out.push(s);
 }return out;
}
function masterGuard_(sh,run){
 dedupeMasterStores_(sh);
 const rows=masterRows_(sh),same=rows.filter(x=>x.collectorCode===run.channel_code);
 const conflict=same.find(x=>x.shopId&&x.shopId!==run.shopId);if(conflict)throw Error('Channel đã gắn Shop ID khác. Kiểm tra master '+sh.getName()+'.');
 if(same.length&&(same.every(x=>!x.enabled)||same.some(x=>x.tracked&&!x.enabled)))throw Error('Store bị tắt trong '+sh.getName()+' (Enabled = FALSE).');
 if(run.platform==='SHOPEE'&&rows.some(x=>x.shopId===run.shopId&&x.collectorCode&&x.collectorCode!==run.channel_code))throw Error('Shopee Shop ID đã gắn channel khác trong SPE_Stores.');
 const pending=rows.filter(x=>!x.collectorCode&&x.shopId===run.shopId);if(!same.length&&pending.length>1)throw Error('Shop ID gắn nhiều dòng master chưa có mã collector. Kiểm tra master.');
 if(!same.length&&pending.length===1&&!pending[0].enabled)throw Error('Store bị tắt trong '+sh.getName()+'.');
}
function masterCollected_(sh,run){
 const shopCode=sh.getName()==='SPE_Stores'?String(run.shopId||''):String(run.shopCode||'');
 if(shopCode)ensureShopCodeColumn_(sh);
 const l=masterLayout_(sh),rows=masterRows_(sh);
 const candidates=rows.filter(x=>x.collectorCode===run.channel_code||(!x.collectorCode&&x.shopId===run.shopId));
 candidates.sort((a,b)=>Number(b.tracked)-Number(a.tracked)||Number(b.enabled)-Number(a.enabled));
 const x=candidates[0];
 if(x){if(x.last&&x.last>run.capturedAt)return;
 // Collector updates only identity and timestamp; keeps Enabled, tracking, business names and notes.
 if(!x.collectorCode)sh.getRange(x.masterRow,l.cols[1]).setValue(run.channel_code);
 if(!sh.getRange(x.masterRow,l.cols[0]).getDisplayValue())sh.getRange(x.masterRow,l.cols[0]).setValue(run.channel_name);
 sh.getRange(x.masterRow,l.cols[3]).setValue(String(run.shopId));
 sh.getRange(x.masterRow,l.cols[4]).setValue(run.shopName);
 if(l.shopCode&&shopCode)sh.getRange(x.masterRow,l.shopCode).setNumberFormat('@').setValue(safe_(shopCode));
 if(l.cols[6])sh.getRange(x.masterRow,l.cols[6]).setValue(run.capturedAt);return;
 }
 const v=[run.channel_name,run.channel_code,run.warehouse,run.shopId,run.shopName,true,run.capturedAt,'Added by collector'];
 /* v2.2.10 — Store mới (vd TikTok tự tạo TTK + Shop ID): ghi vào DÒNG TRỐNG ĐẦU TIÊN của master thay vì appendRow
    (master có sẵn ~1000 dòng checkbox/định dạng → appendRow đẩy store xuống tận dòng 1000+, không ai thấy),
    và tick "Cần theo dõi" để Dashboard hiện store ngay. */
 const n=Math.max(sh.getLastRow()-1,0),identity=[l.cols[0],l.cols[1],l.cols[3],l.cols[4],l.business,l.businessName,l.shopCode].filter(Boolean);
 const key=n?sh.getRange(2,1,n,Math.max(...identity)).getDisplayValues():[];
 let at=-1;for(let i=0;i<key.length;i++){if(identity.every(c=>!String(key[i][c-1]||'').trim())){at=i+2;break;}}
 if(at<0)at=sh.getLastRow()+1;if(at>sh.getMaxRows())sh.insertRowsAfter(sh.getMaxRows(),at-sh.getMaxRows());
 l.cols.forEach((c,i)=>{if(c)sh.getRange(at,c).setValue(safe_(v[i]));});
 if(l.watch>0&&l.watch!==l.cols[5])sh.getRange(at,l.watch).setValue(true);
 if(l.shopCode&&shopCode)sh.getRange(at,l.shopCode).setNumberFormat('@').setValue(safe_(shopCode));
}
/* Keep the business mapping row; use the latest committed Overview to resolve Shop ID conflicts.
   Without a verified winner, keep conflicting rows for review rather than guessing an identity. */
function masterStamp_(v){if(v instanceof Date)return v.getTime();if(typeof v==='number')return (v-25569)*86400000;const n=Date.parse(String(v||''));return Number.isFinite(n)?n:0;}
function dedupeMasterStores_(sh){
 if(!sh)return {removed:0,unresolved:[]};
 const l=masterLayout_(sh),rows=masterRows_(sh),groups={};
 for(const x of rows){const key=String(x.collectorCode||'').trim().toUpperCase();if(key)(groups[key]=groups[key]||[]).push(x);}
 const duplicates=Object.entries(groups).filter(([,g])=>g.length>1);if(!duplicates.length)return {removed:0,unresolved:[]};
 const ss=SpreadsheetApp.openById(PERFORMANCE_ID),spe=sh.getName()==='SPE_Stores';
 const overview=table_(ss,spe?'SPE_Overview':'TTS_Overview',spe?22:20),latest={};
 for(const r of overview){const key=String(r[1]||'').trim().toUpperCase();if(key&&(!latest[key]||masterStamp_(r[5])>masterStamp_(latest[key][5])))latest[key]=r;}
 const dataRange=sh.getRange(2,1,sh.getLastRow()-1,l.width),data=dataRange.getValues(),formulas=typeof dataRange.getFormulas==='function'?dataRange.getFormulas():[];let removed=0;const unresolved=[];
 for(const [code,g] of duplicates){
  const ov=latest[code],ids=[...new Set(g.map(x=>x.shopId).filter(Boolean))],id=ov&&String(ov[3]||'').trim()|| (ids.length===1?ids[0]:'');
  if(!id&&ids.length>1){unresolved.push(code);continue;}
  const valid=g.filter(x=>!id||!x.shopId||x.shopId===id);if(!valid.length){unresolved.push(code);continue;}
  valid.sort((a,b)=>Number(b.tracked)-Number(a.tracked)||Number(!!b.businessCode&&l.business>0)-Number(!!a.businessCode&&l.business>0)||Number(!!b.wh)-Number(!!a.wh)||a.masterRow-b.masterRow);
  const keep=valid[0],merged=data[keep.masterRow-2].slice();while(merged.length<l.width)merged.push('');
  const donors=valid.slice().sort((a,b)=>masterStamp_(data[b.masterRow-2][l.cols[6]-1])-masterStamp_(data[a.masterRow-2][l.cols[6]-1]));
  for(const x of donors){const r=data[x.masterRow-2];for(let i=0;i<l.width;i++)if((merged[i]===''||merged[i]==null)&&r[i]!==''&&r[i]!=null)merged[i]=r[i];}
  merged[l.cols[1]-1]=code;if(id)merged[l.cols[3]-1]=id;
  if(ov&&String(ov[3]||'')===id&&ov[4])merged[l.cols[4]-1]=ov[4];
  if(l.cols[6]){const stamps=valid.map(x=>data[x.masterRow-2][l.cols[6]-1]);if(ov&&String(ov[3]||'')===id)stamps.push(ov[5]);stamps.sort((a,b)=>masterStamp_(b)-masterStamp_(a));if(masterStamp_(stamps[0]))merged[l.cols[6]-1]=stamps[0];}
  if(l.watch)merged[l.watch-1]=valid.some(x=>x.tracked);
  const original=data[keep.masterRow-2];for(let i=0;i<l.width;i++)if(!formulas[keep.masterRow-2]?.[i]&&merged[i]!==original[i])setVals_(sh.getRange(keep.masterRow,i+1),[[merged[i]]]);
  for(const x of g)if(x.masterRow!==keep.masterRow){sh.getRange(x.masterRow,1,1,l.width).clearContent();removed++;}
 }
 return {removed,unresolved};
}
function deduplicateMasterStores(){
 const lock=LockService.getScriptLock();if(!lock.tryLock(25000))throw Error('Busy. Retry.');
 try{const ss=SpreadsheetApp.openById(PERFORMANCE_ID),result={};for(const n of ['TTS_Stores','SPE_Stores'])result[n]=dedupeMasterStores_(ss.getSheetByName(n));SpreadsheetApp.flush();console.log(JSON.stringify(result));return result;}finally{lock.releaseLock();}
}
function masterProgress_(stores,overview){
 const today=Utilities.formatDate(new Date(),'Asia/Ho_Chi_Minh','yyyy-MM-dd'),week=isoWeek_(today),seen=new Set(stores.map(s=>s.platform+'|'+s.code));
 for(const o of overview)if(!seen.has(o.platform+'|'+o.code)){stores.push({platform:o.platform,code:o.code,collectorCode:o.code,businessCode:'',name:o.shopName||o.channelName||'Chưa có mapping',shopName:o.shopName||'',shopId:o.shopId||'',shopCode:o.platform==='SHOPEE'?String(o.shopId||''):'',wh:'',enabled:true,tracked:false,master:false,masterIssues:['CHƯA CÓ TRONG MASTER']});seen.add(o.platform+'|'+o.code);}
 for(const s of stores){const o=overview.find(o=>o.platform===s.platform&&o.code===s.code),at=o&&Date.parse(o.at);
 const date=Number.isFinite(at)?Utilities.formatDate(new Date(at),'Asia/Ho_Chi_Minh','yyyy-MM-dd'):'';
 s.capturedDate=date;s.collectedToday=!!date&&date===today;s.collectedWeek=!!date&&date<=today&&isoWeek_(date)===week;
 s.dataQuality=!o?'CHƯA CÓ SNAPSHOT':!Object.values(o.kpi||{}).some(v=>typeof v==='number'&&Number.isFinite(v))?'CHƯA CÓ KPI':/CHƯA|THIẾU|LỆCH|CẦN/.test(o.coverage||'')?'CẦN KIỂM TRA NGUỒN':'CÓ KPI';
 }
}
function dashShopeeData_(ss,from){
 const stores=masterStores_(ss.getSheetByName('SPE_Stores'));
 const overview=table_(ss,'SPE_Overview',22).filter(r=>r[1]).map(r=>({platform:'SHOPEE',code:r[1],shopId:r[3],shopName:r[4],channelName:r[0],at:r[5],week:r[6],kpi:Object.fromEntries(SPE_CODES.map((c,i)=>[c,num_(r[7+i])])),status:r[15],errors:Number(r[16])||0,coverage:r[17],runId:r[18],by:r[21]||''}));
 const metrics=table_(ss,'SPE_Metrics',27),latest=new Set(overview.map(o=>o.runId)),targets={};for(const r of metrics)if(latest.has(r[1]))(targets[r[5]]=targets[r[5]]||{})[r[8]]={target:num_(r[12]),dir:r[13],status:r[15],start:r[16],end:r[17],count:Number(r[20])||0,coverage:r[21],note:r[24],unit:r[26]};
 const daily=table_(ss,'SPE_Daily',21).filter(r=>r[1]>=from).map(r=>[r[1],r[4],r[8],num_(r[10]),num_(r[14]),r[15],r[16],r[20],r[9],r[17]]);
 const periods=metrics.map(r=>[r[5],r[8],r[16],r[17],num_(r[10]),num_(r[12]),r[13],r[15],Number(r[20])||0,r[2],r[21]]);
 const codes=Object.fromEntries(stores.map(x=>[x.shopId,x.code]));const reports=table_(ss,'SPE_Report',21).filter(r=>r[1]).map(r=>{let p={};try{p=enablerPeriod_(r[3]);}catch(e){}return {shopId:r[1],code:codes[r[1]]||'',name:r[2],date:r[3],aggregation:r[4],metric:r[5],value:num_(r[6]),score:num_(r[7]),operational_score:num_(r[8]),engagement_score:num_(r[9]),unit:r[10],source:r[11],year:Number(r[13])||p.year,quarter:Number(r[14])||p.quarter,week:Number(r[15])||p.week,totalWeeks:Number(r[16])||13,periodStart:r[17]||p.periodStart,periodEnd:r[18]||p.periodEnd,scorecardDate:r[19]||r[3],threshold:r[20]||''};});
 const enablerScorecards=table_(ss,'SPE_Enabler_Scorecards',27).filter(r=>r[0]).map(r=>({date:r[1],aggregation:r[2],year:Number(r[3]),quarter:Number(r[4]),week:Number(r[5]),totalWeeks:Number(r[6]),periodStart:r[7],periodEnd:r[8],operational_score:num_(r[9]),engagement_score:num_(r[10]),shopCount:Number(r[11]),metric_scores:Object.fromEntries(['NFR','LSR','FHR','SPH','PP','CRR'].concat(ENB_CODES).map((c,i)=>[c,num_(r[12+i])])),source:r[24],scorecardDate:r[26]}));
 // OnPoint rule: FHR (Tỷ lệ giao hàng nhanh) đánh giá theo mục tiêu Mall/Yêu Thích ≥ 80%, không theo mục tiêu Account Health (90%). Áp cho Dashboard; số gốc trong sheet giữ nguyên.
 for(const o of overview){const t=(targets[o.code]=targets[o.code]||{});for(const [m,ov] of Object.entries(SPE_TARGET_OVERRIDE))t[m]={...(t[m]||{}),target:ov.target,dir:ov.dir,source:'ONPOINT_RULE'};
  const fails=SPE_CODES.filter(m=>{const g=t[m],v=o.kpi[m];if(v==null||!g||g.target==null||!g.dir)return false;return !(g.dir==='>='?v>=g.target:g.dir==='>'?v>g.target:g.dir==='<='?v<=g.target:g.dir==='<'?v<g.target:v===g.target);});
  if(/^(FAIL|PASS)/.test(String(o.status||'')))o.status=fails.length?'FAIL: '+fails.join(', '):'PASS';}
 for(const p of periods){const ov=SPE_TARGET_OVERRIDE[p[1]];if(!ov)continue;p[5]=ov.target;p[6]=ov.dir;if(p[4]!=null)p[7]=(ov.dir==='>='?p[4]>=ov.target:p[4]<=ov.target)?'PASS':'FAIL';}
 const enablerSubmit=enablerRoster_(ss).map(r=>({...r,code:codes[r.shopId]||''}));return {stores,overview,targets,daily,periods,reports,enablerSubmit,enablerScorecards};}
function dashShopeeOrders_(channel,key){const acc=access_(key);if(acc.scope!=='full')throw Error('Link này chỉ xem KPI.');const ov=table_(acc.ss,'SPE_Overview',22).find(r=>r[1]===channel);if(!ov)return {runId:'',rows:[]};const runId=ov[18];const rows=table_(acc.ss,'SPE_Orders',43).filter(r=>r[25]===runId).map(r=>[r[5],r[6],r[10],r[9],r[26],r[27],r[28],r[29],r[30],r[31],r[7],r[8],r[11],r[12],r[13],r[14],r[15],r[16],r[17],r[32]||'',r[33]||'',r[34]||'',r[35]||'',r[36]||'',r[37]||'',r[38]||'',r[39]||'',r[40]||'',r[41]||'',r[42]||'']);return {runId,rows};}


// Included into Code.gs in the delivered standalone backend.
const APPEAL_HEADERS=['Channel Name','Opollo Channel Code','Channel Code','Warehouse','Shop ID','Shop Name','Ticket raise','Metric','Platform','Shop Code','Ticket Created At (UTC)','Ticket Recorded At (UTC)','Period Start','Period End','Order Count','Representative Order ID','Source File','Subject','Ticket URL','Sync Key','Status'];
function appealSheet_(ss){
 const sh=ss.getSheetByName('Ticket Raise')||ss.insertSheet('Ticket Raise');
 const h=sh.getRange(1,1,1,sh.getMaxColumns()).getDisplayValues()[0],norm=v=>String(v||'').replace(/\s+/g,' ').trim().toLowerCase();
 let next=h.reduce((n,v,i)=>String(v||'').trim()?i+1:n,0);const cols={};
 for(const name of APPEAL_HEADERS){const matches=h.map((v,i)=>norm(v)===norm(name)?i+1:0).filter(Boolean);if(matches.length>1)throw Error('Ticket Raise: trùng header '+name);
 if(matches.length)cols[name]=matches[0];else{next++;if(next>sh.getMaxColumns())sh.insertColumnsAfter(sh.getMaxColumns(),next-sh.getMaxColumns());sh.getRange(1,next).setValue(name);h[next-1]=name;cols[name]=next;}}
 return {sh,cols,width:Math.max(...Object.values(cols))};
}
function upgradeAppealRegistry(){
 const ss=SpreadsheetApp.openById(PERFORMANCE_ID);const result={};
 for(const name of ['TTS_Stores','SPE_Stores']){const sh=ss.getSheetByName(name);masterLayout_(sh);result[name]={shopCodeColumn:ensureShopCodeColumn_(sh)};}
 const a=appealSheet_(ss);a.sh.setFrozenRows(1);a.sh.getRange(1,1,1,a.width).setBackground('#11283a').setFontColor('#ffffff').setFontWeight('bold').setWrap(true);
 result.tickets={sheet:a.sh.getName(),columns:a.width};console.log(JSON.stringify(result));return result;
}
function recordPerformanceAppeal_(t,ss){
 const allow={TIKTOK:['FDR','LDR'],SHOPEE:['FHR','LSR']};
 if(!t||!allow[t.platform]?.includes(t.metric)||typeof t.shopId!=='string'||!/^\d{5,24}$/.test(t.shopId))throw Error('Invalid appeal shop/platform/metric.');
 if(typeof t.ticketId!=='string')throw Error('Ticket ID must be lossless text.');
 const id=String(t.ticketId||'').replace(/^#/,'').trim();const validTicket=t.platform==='SHOPEE'?/^[A-Z0-9][A-Z0-9_-]{4,49}$/i.test(id):/^\d{8,30}$/.test(id);if(!validTicket)throw Error('Invalid captured Ticket ID.');
 if(!Number.isInteger(t.orderCount)||t.orderCount<1||t.orderCount>100000)throw Error('Invalid appeal order count.');
 for(const v of [t.createdAt,t.recordedAt])if(!/^\d{4}-\d{2}-\d{2}T/.test(String(v||''))||!Number.isFinite(Date.parse(v)))throw Error('Invalid appeal timestamp.');
 if(t.shopCode&&!/^[A-Z0-9_-]{3,40}$/i.test(String(t.shopCode)))throw Error('Invalid Shop Code.');
 const url=String(t.ticketUrl||'');if(url&&!/^https:\/\/(?:seller-vn\.tiktok\.com|help\.shopee\.vn|seller-service\.cs\.shopee\.vn)\//.test(url))throw Error('Invalid ticket URL.');
 const sh=ss.getSheetByName(t.platform==='TIKTOK'?'TTS_Stores':'SPE_Stores'),stores=sh?masterStores_(sh):[];
 const candidates=stores.filter(s=>s.shopId===String(t.shopId)),store=candidates.length===1?candidates[0]:candidates.find(s=>s.collectorCode===t.channelCode);
 const a=appealSheet_(ss),{cols}=a,n=a.sh.getLastRow()-1,rows=n>0?a.sh.getRange(2,1,n,a.width).getDisplayValues():[],key=[t.platform,t.shopId,t.metric,id].join('|');
 const same=r=>r[cols['Sync Key']-1]===key||(String(r[cols['Ticket raise']-1]).replace(/^#/,'')===id&&r[cols['Metric']-1]===t.metric&&r[cols['Shop ID']-1]===String(t.shopId));
 const found=rows.findIndex(same),at=found>=0?found+2:a.sh.getLastRow()+1;
 if(at>a.sh.getMaxRows())a.sh.insertRowsAfter(a.sh.getMaxRows(),at-a.sh.getMaxRows());
 const clip=(v,n=300)=>String(v||'').slice(0,n);
 const values={'Channel Name':store?.name||clip(t.channelName||t.shopName),'Opollo Channel Code':store?store.businessCode:clip(t.opolloCode,80),'Channel Code':store?.collectorCode||clip(t.channelCode,80),'Warehouse':store?.wh||clip(t.warehouse,80),'Shop ID':String(t.shopId),'Shop Name':store?.shopName||clip(t.shopName),'Ticket raise':id,'Metric':t.metric,'Platform':t.platform,'Shop Code':store?.shopCode||clip(t.shopCode,40),'Ticket Created At (UTC)':t.createdAt,'Ticket Recorded At (UTC)':t.recordedAt,'Period Start':clip(t.periodStart,10),'Period End':clip(t.periodEnd,10),'Order Count':t.orderCount,'Representative Order ID':clip(t.representativeOrderId,40),'Source File':clip(t.sourceFile),'Subject':clip(t.subject),'Ticket URL':url,'Sync Key':key,'Status':found>=0?rows[found][cols.Status-1]||'Submitted':'Submitted'};
 for(const [name,value] of Object.entries(values)){const cell=a.sh.getRange(at,cols[name]);if(name==='Order Count')cell.setValue(value);else cell.setNumberFormat('@').setValue(safe_(value));}
 return {ok:true,sheet:'Ticket Raise',ticketId:id,duplicate:found>=0,row:at};
}
