/* =============================================================================
 * OnPoint Ticket Master — Apps Script v2.1.0  (extension v2.2.9)
 * -----------------------------------------------------------------------------
 * v2.0 (giữ nguyên): chỉ đọc MỘT cột OrderID + cache chỉ mục, ghi theo dải, lock ngắn.
 *
 * v2.1 — TỰ DỌN DỮ LIỆU CŨ (> 90 NGÀY) KHI SHEET QUÁ DÒNG
 *   Google Sheets giới hạn 10.000.000 ô / file. Ticket Master chỉ thêm dòng nên sớm muộn sẽ chạm giới hạn và
 *   mọi lần ghi đều lỗi ("above the limit of 10000000 cells") → extension retry mãi, máy giật.
 *
 *   1. Mỗi request: nếu số ô của file vượt CLEANUP_AT_CELLS (mặc định 8 triệu) hoặc sheet vượt CLEANUP_AT_ROWS
 *      dòng → xoá các dòng có ngày ghi nhận cũ hơn RETENTION_DAYS (90) rồi mới ghi.
 *   2. Nếu lần ghi vẫn báo vượt giới hạn ô → dọn ngay rồi ghi lại MỘT lần.
 *   3. Trigger hằng ngày (2–3h sáng) dọn định kỳ — cài bằng cách chạy setupCheck một lần.
 *   4. Dọn luôn dòng / cột trống thừa cuối sheet (vẫn bị tính vào giới hạn ô).
 *   Ngày ghi nhận lấy theo cột đầu tiên có trong sheet: TicketRecordedAt → SyncReceivedAt → SyncedAt.
 *   Dòng không đọc được ngày sẽ được GIỮ (không xoá nhầm).
 *
 * CÀI ĐẶT / NÂNG CẤP
 *   1. Mở file Google Sheets "OnPoint TTS Tracking Master" → Tiện ích mở rộng → Apps Script.
 *   2. Xoá hết code cũ, dán file này, Lưu.
 *   3. Chọn hàm setupCheck → Run (cấp quyền + cài trigger dọn hằng ngày).
 *   4. Triển khai → Quản lý các bản triển khai → ✎ Sửa bản đang dùng → Phiên bản: "Phiên bản mới" → Triển khai.
 *      (Sửa bản cũ thì URL /exec GIỮ NGUYÊN, không phải dán lại vào extension.)
 * ========================================================================== */

var MASTER_SHEET_NAME = 'Ticket Master';
var ORDER_ID_HEADERS = ['OrderID', 'Platform Order ID', 'Order ID'];
var DATE_HEADERS = ['TicketRecordedAt', 'SyncReceivedAt', 'SyncedAt'];
var LOCK_WAIT_MS = 20000;
var CACHE_TTL_SEC = 300;
var TIMEZONE = 'Asia/Ho_Chi_Minh';

var RETENTION_DAYS = 90;
var CELL_LIMIT = 10000000;
var CLEANUP_AT_CELLS = 8000000;   // 80% giới hạn của Google
var CLEANUP_AT_ROWS = 150000;
var CLEANUP_CHECK_EVERY_SEC = 600; // kiểm tra kích thước tối đa 10 phút / lần (rẻ, nhưng không cần mỗi request)

function doGet() {
  return json_({ ok: true, service: 'OnPoint Ticket Master', version: '2.1.0', retentionDays: RETENTION_DAYS });
}

function doPost(e) {
  var started = new Date().getTime();
  try {
    var payload = JSON.parse((e && e.postData && e.postData.contents) || '{}');
    if (payload.action !== 'appendTicketMaster') throw new Error('Unsupported action.');
    var rows = payload.rows && payload.rows.length ? payload.rows : [];
    var result = upsertRows_(rows);
    result.ms = new Date().getTime() - started;
    result.ok = true;
    return json_(result);
  } catch (error) {
    return json_({ ok: false, error: (error && error.message) || String(error) });
  }
}

/* ---------------------------------------------------------------- chỉ mục -- */

/* Thế hệ chỉ mục: tăng mỗi lần xoá dòng để cache cũ (số dòng → OrderID) không bao giờ bị dùng lại sai. */
function indexGen_() {
  return PropertiesService.getDocumentProperties().getProperty('idxGen') || '0';
}
function bumpIndexGen_() {
  var props = PropertiesService.getDocumentProperties();
  props.setProperty('idxGen', String(Number(props.getProperty('idxGen') || 0) + 1));
}

function loadIndex_(sheet, headers) {
  var cache = CacheService.getDocumentCache();
  var lastRow = sheet.getLastRow();
  var cacheKey = 'idx:' + indexGen_() + ':' + headers.length + ':' + lastRow;

  if (cache) {
    var cached = cache.get(cacheKey);
    if (cached) {
      try { return { map: JSON.parse(cached), lastRow: lastRow }; } catch (_) {}
    }
  }

  var map = {};
  if (lastRow > 1) {
    var column = findColumn_(headers, ORDER_ID_HEADERS);
    if (column >= 0) {
      var values = sheet.getRange(2, column + 1, lastRow - 1, 1).getDisplayValues();
      for (var r = 0; r < values.length; r++) {
        var id = String(values[r][0] || '').trim().toUpperCase();
        if (id && !map[id]) map[id] = r + 2;
      }
    }
  }

  if (cache) {
    try { cache.put(cacheKey, JSON.stringify(map), CACHE_TTL_SEC); } catch (_) {
      // Chỉ mục vượt giới hạn 100KB của cache — bỏ qua, lần sau đọc lại cột.
    }
  }
  return { map: map, lastRow: lastRow };
}

function findColumn_(headers, names) {
  for (var i = 0; i < names.length; i++) {
    var found = headers.indexOf(names[i]);
    if (found >= 0) return found;
  }
  return -1;
}

/* ------------------------------------------------------------------ ghi ---- */

function masterSheet_() {
  var spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
  if (!spreadsheet) throw new Error('Apps Script phải được tạo từ chính file Tracking Master.');
  return spreadsheet.getSheetByName(MASTER_SHEET_NAME) || spreadsheet.insertSheet(MASTER_SHEET_NAME);
}

function withLock_(fn) {
  var lock = LockService.getDocumentLock();
  if (!lock.tryLock(LOCK_WAIT_MS)) {
    throw new Error('Sheet đang bận (' + (LOCK_WAIT_MS / 1000) + 's). Extension sẽ tự gửi lại.');
  }
  try { return fn(); } finally { try { lock.releaseLock(); } catch (_) {} }
}

function isCellLimitError_(error) {
  return /10[.,]?000[.,]?000|limit of .*cells|giới hạn.*ô|too many cells/i.test(String(error && error.message || error));
}

function upsertRows_(rows) {
  if (!rows.length) return { inserted: 0, updated: 0, duplicates: 0, received: 0 };
  return withLock_(function () {
    var cleaned = maybeCleanup_();
    try {
      var r = writeRows_(rows);
      r.cleaned = cleaned;
      return r;
    } catch (error) {
      if (!isCellLimitError_(error)) throw error;
      // Sheet đầy giữa chừng: dọn ngay rồi ghi lại một lần.
      var removed = cleanupOldRows_(RETENTION_DAYS).deleted;
      if (!removed) throw new Error('Sheet đã chạm giới hạn 10 triệu ô và không còn dòng nào cũ hơn ' + RETENTION_DAYS + ' ngày để xoá. Cần chuyển bớt dữ liệu sang file khác.');
      var again = writeRows_(rows);
      again.cleaned = cleaned + removed;
      return again;
    }
  });
}

function writeRows_(rows) {
  var sheet = masterSheet_();

  // --- Header ---------------------------------------------------------------
  var lastColumn = sheet.getLastColumn();
  var currentHeaders = lastColumn
    ? sheet.getRange(1, 1, 1, lastColumn).getDisplayValues()[0].filter(String)
    : [];
  var headers = currentHeaders.slice();
  var known = {};
  for (var h = 0; h < headers.length; h++) known[headers[h]] = true;

  for (var i = 0; i < rows.length; i++) {
    for (var key in rows[i]) {
      if (key && !known[key]) { known[key] = true; headers.push(key); }
    }
  }
  var required = ['OrderID', 'SyncStatus', 'SyncedAt', 'SyncError', 'SyncReceivedAt'];
  for (var q = 0; q < required.length; q++) {
    if (!known[required[q]]) { known[required[q]] = true; headers.push(required[q]); }
  }
  var headersChanged = !currentHeaders.length || headers.length !== currentHeaders.length;

  var index = loadIndex_(sheet, headers);
  var stamp = Utilities.formatDate(new Date(), TIMEZONE, 'yyyy-MM-dd HH:mm:ss');

  var appendValues = [];
  var updateByRow = {};
  var duplicates = 0;
  var seen = {};
  var appendPos = {};

  for (var n = 0; n < rows.length; n++) {
    var row = rows[n] || {};
    var orderId = String(row.OrderID || row['Platform Order ID'] || row['Order ID'] || '')
      .trim().toUpperCase();
    if (!orderId) { duplicates++; continue; }

    // Một lô có thể chứa cùng OrderID hai lần (retry chồng lô) — giữ bản sau.
    if (seen[orderId]) duplicates++;
    seen[orderId] = true;

    row.OrderID = orderId;
    row.SyncStatus = 'Synced';
    row.SyncedAt = stamp;
    row.SyncError = '';
    row.SyncReceivedAt = stamp;

    var line = [];
    for (var c = 0; c < headers.length; c++) line.push(safeCell_(row[headers[c]]));

    var existingRow = index.map[orderId];
    if (appendPos[orderId] !== undefined) {
      appendValues[appendPos[orderId]] = line; // trùng trong cùng lô với một dòng MỚI → thay dòng sắp thêm
    } else if (existingRow) {
      updateByRow[existingRow] = line;
    } else {
      appendPos[orderId] = appendValues.length;
      index.map[orderId] = index.lastRow + 1 + appendValues.length;
      appendValues.push(line);
    }
  }

  if (headersChanged) {
    if (sheet.getMaxColumns() < headers.length) sheet.insertColumnsAfter(sheet.getMaxColumns(), headers.length - sheet.getMaxColumns());
    sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
    sheet.setFrozenRows(1);
  }

  // Gom các dòng cập nhật LIỀN KỀ thành dải, ghi mỗi dải một lời gọi.
  var rowNumbers = [];
  for (var rowKey in updateByRow) rowNumbers.push(Number(rowKey));
  rowNumbers.sort(function (a, b) { return a - b; });

  var updated = 0;
  var runStart = -1;
  var runValues = [];
  for (var k = 0; k < rowNumbers.length; k++) {
    var current = rowNumbers[k];
    if (runStart < 0) { runStart = current; runValues = [updateByRow[current]]; continue; }
    if (current === runStart + runValues.length) { runValues.push(updateByRow[current]); continue; }
    sheet.getRange(runStart, 1, runValues.length, headers.length).setValues(runValues);
    updated += runValues.length;
    runStart = current;
    runValues = [updateByRow[current]];
  }
  if (runStart >= 0 && runValues.length) {
    sheet.getRange(runStart, 1, runValues.length, headers.length).setValues(runValues);
    updated += runValues.length;
  }

  // Dòng mới: đúng MỘT lời gọi cho cả lô.
  if (appendValues.length) {
    sheet.getRange(sheet.getLastRow() + 1, 1, appendValues.length, headers.length).setValues(appendValues);
  }

  var cache = CacheService.getDocumentCache();
  if (cache) {
    try { cache.put('idx:' + indexGen_() + ':' + headers.length + ':' + sheet.getLastRow(), JSON.stringify(index.map), CACHE_TTL_SEC); } catch (_) {}
  }

  return { inserted: appendValues.length, updated: updated, duplicates: duplicates, received: rows.length };
}

/* --------------------------------------------------------------- dọn dẹp --- */

/** Số ô đang chiếm của cả file (kể cả ô trống thừa — Google vẫn tính). */
function workbookCells_() {
  var sheets = SpreadsheetApp.getActiveSpreadsheet().getSheets();
  var total = 0;
  for (var i = 0; i < sheets.length; i++) total += sheets[i].getMaxRows() * sheets[i].getMaxColumns();
  return total;
}

/** Gọi trong lock trước mỗi lần ghi; chỉ thật sự đo kích thước tối đa 10 phút / lần. */
function maybeCleanup_() {
  var cache = CacheService.getDocumentCache();
  if (cache && cache.get('sizeChecked')) return 0;
  if (cache) cache.put('sizeChecked', '1', CLEANUP_CHECK_EVERY_SEC);
  var sheet = masterSheet_();
  if (workbookCells_() < CLEANUP_AT_CELLS && sheet.getLastRow() < CLEANUP_AT_ROWS) return 0;
  return cleanupOldRows_(RETENTION_DAYS).deleted;
}

function parseDate_(value) {
  if (value instanceof Date) return value.getTime();
  var s = String(value || '').trim();
  if (!s) return NaN;
  var m = s.match(/^(\d{4})-(\d{2})-(\d{2})(?:[ T](\d{2}):(\d{2})(?::(\d{2}))?)?/);
  if (m) {
    if (/[zZ]|[+-]\d{2}:?\d{2}$/.test(s)) return new Date(s).getTime();
    return Date.UTC(+m[1], +m[2] - 1, +m[3], +(m[4] || 0) - 7, +(m[5] || 0), +(m[6] || 0)); // giờ VN
  }
  var d = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})(?:\s+(\d{1,2}):(\d{2})(?::(\d{2}))?)?/); // dd/MM/yyyy
  if (d) return Date.UTC(+d[3], +d[2] - 1, +d[1], +(d[4] || 0) - 7, +(d[5] || 0), +(d[6] || 0));
  return NaN;
}

/**
 * Xoá các dòng có ngày ghi nhận cũ hơn `days` ngày. Dòng cũ thường nằm liền nhau ở đầu sheet nên chỉ tốn vài lời gọi
 * deleteRows (xoá từ dưới lên để số dòng không lệch). Sau đó cắt dòng / cột trống thừa cuối sheet.
 * Phải gọi khi đang giữ lock.
 */
function cleanupOldRows_(days) {
  var sheet = masterSheet_();
  var lastRow = sheet.getLastRow(), lastCol = sheet.getLastColumn();
  var result = { deleted: 0, trimmedRows: 0, trimmedCols: 0, retentionDays: days };
  if (lastRow > 1 && lastCol) {
    var headers = sheet.getRange(1, 1, 1, lastCol).getDisplayValues()[0];
    var cols = [];
    for (var i = 0; i < DATE_HEADERS.length; i++) { var c = headers.indexOf(DATE_HEADERS[i]); if (c >= 0) cols.push(c); }
    if (cols.length) {
      var cutoff = new Date().getTime() - days * 864e5;
      var minCol = Math.min.apply(null, cols), maxCol = Math.max.apply(null, cols);
      var values = sheet.getRange(2, minCol + 1, lastRow - 1, maxCol - minCol + 1).getValues();
      var runs = [], start = -1;
      for (var r = 0; r < values.length; r++) {
        var t = NaN;
        for (var j = 0; j < cols.length && isNaN(t); j++) t = parseDate_(values[r][cols[j] - minCol]);
        var old = !isNaN(t) && t < cutoff;
        if (old && start < 0) start = r;
        if (!old && start >= 0) { runs.push([start + 2, r - start]); start = -1; }
      }
      if (start >= 0) runs.push([start + 2, values.length - start]);
      // Không được xoá hết mọi dòng dữ liệu (Sheets cấm xoá toàn bộ dòng không đóng băng) → chừa lại khi cần.
      var total = 0;
      for (var x = 0; x < runs.length; x++) total += runs[x][1];
      if (total && total >= sheet.getMaxRows() - 1) sheet.insertRowsAfter(sheet.getMaxRows(), 1);
      for (var y = runs.length - 1; y >= 0; y--) sheet.deleteRows(runs[y][0], runs[y][1]);
      result.deleted = total;
    }
  }
  // Dòng / cột trống thừa (tính vào giới hạn ô): giữ dư 500 dòng cho lần ghi tiếp theo.
  var keepRows = Math.max(sheet.getLastRow(), 1) + 500, maxRows = sheet.getMaxRows();
  if (maxRows > keepRows) { sheet.deleteRows(keepRows + 1, maxRows - keepRows); result.trimmedRows = maxRows - keepRows; }
  var keepCols = Math.max(sheet.getLastColumn(), 1) + 2, maxCols = sheet.getMaxColumns();
  if (maxCols > keepCols) { sheet.deleteColumns(keepCols + 1, maxCols - keepCols); result.trimmedCols = maxCols - keepCols; }
  if (result.deleted) bumpIndexGen_();
  SpreadsheetApp.flush();
  Logger.log('Dọn Ticket Master: xoá %s dòng > %s ngày · cắt %s dòng / %s cột trống', result.deleted, days, result.trimmedRows, result.trimmedCols);
  return result;
}

/** Trigger hằng ngày (cài bởi setupCheck). */
function dailyCleanup() {
  withLock_(function () { return cleanupOldRows_(RETENTION_DAYS); });
}

/** Chạy tay khi muốn dọn ngay: Apps Script → chọn cleanupNow → Run. */
function cleanupNow() {
  var r = withLock_(function () { return cleanupOldRows_(RETENTION_DAYS); });
  Logger.log(JSON.stringify(r));
}

/* --------------------------------------------------------------- tiện ích -- */

function safeCell_(value) {
  if (value === null || value === undefined) return '';
  if (value instanceof Date) return value;
  if (typeof value === 'object') return JSON.stringify(value);
  var text = String(value);
  // Chặn công thức bị chèn qua dữ liệu (formula injection).
  return /^[=+\-@]/.test(text) ? "'" + text : text;
}

function json_(value) {
  return ContentService.createTextOutput(JSON.stringify(value)).setMimeType(ContentService.MimeType.JSON);
}

/* -----------------------------------------------------------------------------
 * Chạy tay MỘT LẦN sau khi dán code: cấp quyền, kiểm tra chỉ mục, cài trigger dọn hằng ngày.
 * Apps Script → chọn hàm setupCheck → Run.
 * -------------------------------------------------------------------------- */
function setupCheck() {
  var sheet = masterSheet_();
  var lastColumn = sheet.getLastColumn();
  var headers = lastColumn ? sheet.getRange(1, 1, 1, lastColumn).getDisplayValues()[0].filter(String) : [];
  var index = loadIndex_(sheet, headers);
  var count = 0;
  for (var key in index.map) count++;

  var triggers = ScriptApp.getProjectTriggers(), has = false;
  for (var i = 0; i < triggers.length; i++) if (triggers[i].getHandlerFunction() === 'dailyCleanup') has = true;
  if (!has) ScriptApp.newTrigger('dailyCleanup').timeBased().everyDays(1).atHour(2).inTimezone(TIMEZONE).create();

  Logger.log('Sheet: %s · dòng: %s · OrderID trong chỉ mục: %s · ô cả file: %s / %s · trigger dọn hằng ngày: %s',
    MASTER_SHEET_NAME, sheet.getLastRow(), count, workbookCells_(), CELL_LIMIT, has ? 'đã có' : 'vừa cài');
}
