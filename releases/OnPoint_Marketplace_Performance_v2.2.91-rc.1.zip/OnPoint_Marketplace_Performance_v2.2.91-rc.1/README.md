# OnPoint Marketplace Performance 2.2.91

Enhanced **release candidate**, based on the uploaded package whose actual manifest was 2.2.90. Read [RELEASE_NOTES.md](RELEASE_NOTES.md) for changes and remaining production gates.

## Install or upgrade

Use Chrome 120+ on a host that permits unpacked extensions. For upgrades, back up local data using the existing export controls, close active ticket/collection runs, and replace the files in the **same extension folder**. At `chrome://extensions`, enable Developer mode and load/reload that folder's `extension` directory. Refresh existing Seller Center tabs. Do not remove the extension during an upgrade: removing it can erase local data. The public key/ID is unchanged.

New installs: open **Quản trị → Kết nối Google Sheet**, enter your team's Web App URL and connection key privately, and test the connection. Configure Ticket Master's URL separately under **Kháng nghị → Ticket vận hành**. The package has no shared write key or default write destination. Existing locally stored settings remain in place; update the key after the administrator rotates it.

The optional Windows native helper is installed by `Install.cmd` and removed by `Uninstall.cmd`. It has not been executed on Windows during this validation. Apps Script setup remains in `google_apps_script/SETUP.txt`; Performance and Ticket Master are separate projects. This candidate does not require or claim a new backend deployment.

## Develop and validate

Node 20.11+ and Python 3 are needed for the included tooling. No npm packages are needed to run the extension itself.

```sh
npm ci --ignore-scripts
npm run check
npm test
# Use a local Chromium binary; all included browser fixtures mock remote services:
OP_CHROMIUM_EXECUTABLE=/usr/bin/chromium npm run test:browser
npm run preview:build
npm run package:candidate
```

On Windows, set `OP_CHROMIUM_EXECUTABLE` through your shell if needed, or install Playwright's test browser using its documented install command. Extension-installation suites need an approved host and are separately listed as skipped. The Q3/Q4 official-workbook suite needs its original files; no missing report was invented. Historical reporting fixtures use a fixed October 2026 clock with advancing elapsed time. Ticket timing suites use their normal clocks.

`test-results/summary.json` and per-suite logs record passed, failed and skipped outcomes. `docs/UI_PREVIEW.html` is a self-contained dashboard with synthetic shops/orders; open it locally. Test/source archives exclude node_modules, cloud snapshots and old deployment backups.

`npm run package:candidate` verifies sources and produces extension and source ZIPs with checksums. Production release remains blocked by the parser upgrade, exposed-key rotation and the acceptance checks in [RELEASE_CHECKLIST.md](RELEASE_CHECKLIST.md). The package tool refuses a production release while these gates are open.
