@echo off
setlocal
set "PACKAGE_ROOT=%~dp0"
echo.
echo Installing OnPoint TTS Pickup Download + Query helper...
echo.
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -LiteralPath $env:PACKAGE_ROOT -Recurse -File | Unblock-File -ErrorAction SilentlyContinue"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%PACKAGE_ROOT%native\Install-NativeHost.ps1" -PackageRoot "%PACKAGE_ROOT%."
if errorlevel 1 (
  echo.
  echo INSTALL FAILED. Please take a screenshot of this window.
  pause
  exit /b 1
)
echo.
echo Installation completed.
pause
